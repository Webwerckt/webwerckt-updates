<?php
/**
 * Meertalig (beslissing 0040), onderdeel links: de linkfilters per taal, home_url, dezelfde slug in twee talen en de
 * taalvoorwaarde in de query's (pre_get_posts).
 *
 * Een link naar een object volgt de taal van dat object, niet de huidige taal. De filters bouwen daarom op het adres
 * zonder voorvoegsel (_ww_languages_relink() haalt een voorvoegsel weg) en zetten het voorvoegsel van de taal van het
 * object ervoor. Zo maakt het niet uit of home_url() tijdens het opbouwen al een voorvoegsel gaf. Archieven, termen,
 * paginering en zoeken krijgen de huidige taal, ook in de admin en in REST (waar home_url() geen voorvoegsel krijgt).
 *
 * Een bericht in een verborgen taal houdt zijn voorvoegsel; voor een bezoeker geeft die link een 404 (zie de spec,
 * "Zichtbaarheid per taal"). In de uit-stand hangen de linkfilters niet, het query-filter wel (met de standaardtaal).
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Zet een adres op deze site in een taal: haalt een voorvoegsel van een extra taal (ook een verborgen) direct na het pad
 * van de site weg, en zet /{lang} ervoor als $lang een extra taal is. Adressen op een andere host, relatieve adressen
 * en gereserveerde paden (wp-admin, wp-json, …) blijven ongemoeid. Twee keer toepassen geeft hetzelfde.
 *
 * Het pad van de site komt uit de ruwe optie home, nooit uit het gefilterde home_url().
 *
 * @param string $url  Volledig adres.
 * @param string $lang Taalcode; de standaardtaal of '' geeft het adres zonder voorvoegsel.
 */
function _ww_languages_relink( string $url, string $lang ): string {
	$host = wp_parse_url( (string) get_option( 'home' ) );
	if ( ! is_array( $host ) || empty( $host['host'] ) ) {
		return $url;
	}
	$authority = $host['host'] . ( isset( $host['port'] ) ? ':' . $host['port'] : '' );
	$home      = _ww_languages_home_path();
	$pattern   = '#^((?:https?:)?//' . preg_quote( $authority, '#' ) . preg_quote( $home, '#' ) . ')(?=[/?\#]|$)(.*)$#is';
	if ( 1 !== preg_match( $pattern, $url, $match ) ) {
		return $url;
	}
	$base = $match[1];
	$rest = $match[2];

	if ( 1 === preg_match( '#^/([^/?\#]+)(.*)$#s', $rest, $segment ) ) {
		if ( in_array( $segment[1], WW_LANGUAGES_RESERVED_PATHS, true ) ) {
			return $url;
		}
		if ( in_array( $segment[1], _ww_extra_language_codes(), true ) ) {
			$rest = $segment[2];
		}
	}

	if ( ! in_array( $lang, _ww_extra_language_codes(), true ) ) {
		return $base . $rest;
	}
	// Zonder pad (alleen een querystring of niets) komt er een slash na de taal: /en/?page_id=5, niet /en?page_id=5.
	if ( '' === $rest || ! str_starts_with( $rest, '/' ) ) {
		$rest = '/' . $rest;
	}
	return $base . '/' . $lang . $rest;
}

/**
 * Filter post_link en post_type_link: het voorvoegsel van de taal van het bericht. Een niet-vertaalbaar post type heeft
 * geen taal en dus geen voorvoegsel.
 *
 * @param mixed $link Permalink; iets anders dan een string (null van een andere plugin) komt ongewijzigd terug.
 * @param mixed $post Bericht (WP_Post of ID).
 * @return mixed
 */
function _ww_languages_post_link( mixed $link, mixed $post ): mixed {
	if ( ! is_string( $link ) ) {
		return $link;
	}
	$id = $post instanceof WP_Post ? $post->ID : (int) $post;
	return _ww_languages_relink( $link, _ww_post_language( $id ) );
}

/**
 * Filter page_link: het voorvoegsel van de taal van de pagina. De voorpagina en haar vertalingen zijn de hoofdpagina
 * van hun taal (/ en /en/), ook als de optie page_on_front op dit moment de voorpagina van een andere taal geeft.
 *
 * Een Engelse pagina onder een Nederlandse ouder krijgt /en/{pad van de ouder}/{slug}/; die is niet te routeren, want
 * de routing loopt het pad per taal af.
 *
 * @param mixed $link    Permalink; iets anders dan een string (null van een andere plugin) komt ongewijzigd terug.
 * @param mixed $post_id Post-ID.
 * @param mixed $sample  Of het een voorbeeldlink met %pagename% is (de bewerker).
 * @return mixed
 */
function _ww_languages_page_link( mixed $link, mixed $post_id, mixed $sample = false ): mixed {
	if ( ! is_string( $link ) ) {
		return $link;
	}
	$post_id = (int) $post_id;
	$lang    = _ww_post_language( $post_id );
	if ( ! $sample && _ww_languages_is_front_page( $post_id ) ) {
		$link = trailingslashit( (string) get_option( 'home' ) );
	}
	return _ww_languages_relink( $link, $lang );
}

/**
 * Of een pagina de voorpagina is of een gepubliceerde of concept-vertaling ervan.
 */
function _ww_languages_is_front_page( int $post_id ): bool {
	if ( 'page' !== get_option( 'show_on_front' ) ) {
		return false;
	}
	$front = _ww_languages_raw_page_option( 'page_on_front' );
	return $front > 0 && ( $front === $post_id || in_array( $post_id, _ww_translations( $front ), true ) );
}

/**
 * Filter post_type_archive_link, term_link, get_pagenum_link en search_link: het voorvoegsel van de huidige taal. Een
 * term heeft in de kern geen taal. Werkt ook in REST, waar home_url() geen voorvoegsel krijgt: ww_filter_url() bouwt
 * next_url van het kaarten-endpoint met get_post_type_archive_link().
 *
 * @param mixed $link Adres.
 * @return mixed
 */
function _ww_languages_current_link( mixed $link ): mixed {
	if ( ! is_string( $link ) || '' === $link ) {
		return $link;
	}
	return _ww_languages_relink( $link, ww_current_language() );
}

/**
 * Filter home_url: het voorvoegsel van de huidige taal, alleen op de voorkant en alleen in een extra taal. Alleen voor
 * losse paden (home_url( '/' ), filter- en pagineer-URL's): home_url() zonder pad blijft de ruwe home, want die
 * gebruiken WordPress en het thema om de host en het pad van de site te bepalen. Nooit voor rest_url(), gereserveerde
 * paden, een bestand (robots.txt, wp-login.php) of een pad dat al met een taalcode begint.
 *
 * @param string $url         Adres.
 * @param mixed  $path        Gevraagd pad (een plugin kan null meegeven).
 * @param mixed  $orig_scheme Gevraagd schema.
 */
function _ww_languages_home_url( string $url, mixed $path = '', mixed $orig_scheme = null ): string {
	$path = is_string( $path ) ? $path : '';
	if ( '' === $path || 'rest' === $orig_scheme || is_admin() || wp_is_serving_rest_request() ) {
		return $url;
	}
	$current = ww_current_language();
	if ( ! in_array( $current, _ww_extra_language_codes(), true ) ) {
		return $url;
	}
	$first = (string) strtok( ltrim( $path, '/' ), '/?#' );
	// Een pad dat al met een taal begint (home_url( '/de/' ) voor een taalwisselaar) blijft in die taal.
	if ( in_array( $first, _ww_extra_language_codes(), true ) || in_array( $first, WW_LANGUAGES_RESERVED_PATHS, true ) || rest_get_url_prefix() === $first || str_contains( $first, '.' ) ) {
		return $url;
	}
	return _ww_languages_relink( $url, $current );
}

/**
 * De taal van het bericht waarvoor een slug wordt bepaald: de term; zonder term ww_lang uit het formulier (de metabox
 * stuurt hem mee, en de term komt pas na de slug); anders de standaardtaal.
 */
function _ww_languages_slug_language( int $post_id ): string {
	if ( $post_id > 0 && taxonomy_exists( 'ww_language' ) ) {
		$terms = wp_get_object_terms( $post_id, 'ww_language', array( 'fields' => 'slugs' ) );
		if ( is_array( $terms ) && isset( $terms[0] ) && in_array( $terms[0], _ww_language_codes(), true ) ) {
			return (string) $terms[0];
		}
	}
	// Alleen onder dezelfde voorwaarden als het opslaan van de metabox (_ww_languages_metabox_save()): zijn nonce en
	// manage_options. Anders kiest iemand die de metabox niet heeft een taal voor de slug, en krijgt een tweede
	// Nederlandse pagina dezelfde slug.
	$nonce = isset( $_POST['ww_language_box_nonce'] ) && is_string( $_POST['ww_language_box_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['ww_language_box_nonce'] ) ) : '';
	if ( '' === $nonce || ! wp_verify_nonce( $nonce, 'ww_language_box' ) || ! current_user_can( 'manage_options' ) ) {
		return _ww_default_language();
	}
	$posted = isset( $_POST['ww_lang'] ) && is_string( $_POST['ww_lang'] ) ? sanitize_key( wp_unslash( $_POST['ww_lang'] ) ) : '';
	return in_array( $posted, _ww_language_codes(), true ) ? $posted : _ww_default_language();
}

/**
 * Filter wp_unique_post_slug: dezelfde slug mag als het andere bericht in een andere taal is. Hetzelfde post type,
 * dezelfde ouder en verder dezelfde regels als WordPress: alleen als WordPress de slug weigerde om een bestaand bericht,
 * en alle berichten met die slug in een andere taal zijn, blijft de oorspronkelijke slug staan. Binnen een taal, bij een
 * bijlage met die slug en bij een gereserveerde slug (feed, embed, een getal) blijft de -2 van WordPress.
 *
 * @param string $slug     Slug van WordPress (eventueel met achtervoegsel).
 * @param int    $post_id  Post-ID (0 bij een nieuw bericht).
 * @param string $status   Status.
 * @param string $type     Post type.
 * @param int    $parent   Ouder.
 * @param string $original De gevraagde slug.
 */
function _ww_languages_unique_slug( string $slug, int $post_id, string $status, string $type, int $parent, string $original = '' ): string {
	unset( $status );
	if ( $slug === $original || '' === $original || ! _ww_is_translatable( $type ) ) {
		return $slug;
	}

	global $wpdb, $wp_rewrite;
	$hierarchical = is_post_type_hierarchical( $type );

	// Een slug die WordPress om een andere reden weigert, blijft geweigerd.
	$feeds = is_array( $wp_rewrite->feeds ) ? $wp_rewrite->feeds : array();
	if ( in_array( $original, $feeds, true ) || 'embed' === $original || 1 === preg_match( '/^\d+$/', $original ) ) {
		return $slug;
	}
	if ( $hierarchical ) {
		if ( 1 === preg_match( '@^(' . $wp_rewrite->pagination_base . ')?\d+$@', $original ) || apply_filters( 'wp_unique_post_slug_is_bad_hierarchical_slug', false, $original, $type, $parent ) ) {
			return $slug;
		}
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_type FROM $wpdb->posts WHERE post_name = %s AND post_type IN ( %s, 'attachment' ) AND ID != %d AND post_parent = %d", $original, $type, $post_id, $parent ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- dezelfde controle als wp_unique_post_slug(), zonder LIMIT.
	} else {
		if ( apply_filters( 'wp_unique_post_slug_is_bad_flat_slug', false, $original, $type ) ) {
			return $slug;
		}
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_type FROM $wpdb->posts WHERE post_name = %s AND post_type = %s AND ID != %d", $original, $type, $post_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- dezelfde controle als wp_unique_post_slug(), zonder LIMIT.
	}
	if ( ! is_array( $rows ) || array() === $rows ) {
		return $slug;
	}

	$lang = _ww_languages_slug_language( $post_id );
	foreach ( $rows as $row ) {
		if ( 'attachment' === $row->post_type || _ww_post_language( (int) $row->ID ) === $lang ) {
			return $slug;
		}
	}
	return $original;
}

/**
 * Een gevraagde taal (het argument lang, ?lang= op het kaarten-endpoint) als taal die de bezoeker mag zien. De
 * standaardtaal en een bereikbare extra taal blijven staan. Een verborgen taal wordt stil de standaardtaal, want hij
 * bestaat wel. Een onbekende code wordt ook de standaardtaal, met WP_DEBUG plus een _doing_it_wrong. In de uit-stand
 * bestaat alleen de standaardtaal.
 *
 * @param string $lang     Gevraagde taalcode.
 * @param string $function Functie voor de melding.
 */
function _ww_languages_valid_language( string $lang, string $function ): string {
	$default = _ww_default_language();
	if ( $lang === $default ) {
		return $lang;
	}
	if ( _ww_languages_active() && in_array( $lang, _ww_routable_language_codes(), true ) ) {
		return $lang;
	}
	if ( ! in_array( $lang, _ww_language_codes(), true ) && defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		_doing_it_wrong(
			esc_html( $function ),
			esc_html( sprintf( 'De taal "%1$s" bestaat niet; de query gebruikt de standaardtaal "%2$s".', $lang, $default ) ),
			'0.24.0'
		);
	}
	return $default;
}

/**
 * Of dit een REST-verzoek naar het kaarten-endpoint is. Andere REST-verzoeken worden niet op taal gefilterd.
 */
function _ww_languages_is_cards_request(): bool {
	// rest_api_loaded() leest de route ook uit deze query var, bij /wp-json/… en bij ?rest_route=….
	$wp    = $GLOBALS['wp'] ?? null;
	$route = $wp instanceof WP && isset( $wp->query_vars['rest_route'] ) && is_string( $wp->query_vars['rest_route'] ) ? $wp->query_vars['rest_route'] : '';
	return '/' . WW_REST_NAMESPACE . '/cards' === untrailingslashit( $route );
}

/**
 * De post types van een query, zoals WP_Query ze straks invult: 'any' en zoeken zijn de doorzoekbare types, een
 * termarchief zonder post type de types van die taxonomieën, en verder 'post'.
 *
 * @return string[]
 */
function _ww_languages_query_post_types( WP_Query $query ): array {
	$type = $query->get( 'post_type' );
	if ( 'any' === $type || ( ( '' === $type || array() === $type ) && $query->is_search() ) ) {
		return array_values( get_post_types( array( 'exclude_from_search' => false ) ) );
	}
	if ( is_string( $type ) && '' !== $type ) {
		return array( $type );
	}
	if ( is_array( $type ) && array() !== $type ) {
		return array_values( array_filter( $type, 'is_string' ) );
	}
	if ( $query->tax_query instanceof WP_Tax_Query && ( $query->is_tax() || $query->is_category() || $query->is_tag() ) ) {
		$types = array();
		foreach ( array_keys( $query->tax_query->queried_terms ) as $taxonomy ) {
			$object = get_taxonomy( (string) $taxonomy );
			if ( $object instanceof WP_Taxonomy ) {
				$types = array_merge( $types, $object->object_type );
			}
		}
		return array_values( array_unique( $types ) );
	}
	return array( 'post' );
}

/**
 * Of een (geneste) tax_query al een voorwaarde op ww_language heeft, zoals de opzoekquery's van de routing en het
 * taalfilter in de berichtenlijst.
 *
 * @param mixed $tax_query Waarde van de query var tax_query.
 */
function _ww_languages_has_language_clause( mixed $tax_query ): bool {
	if ( ! is_array( $tax_query ) ) {
		return false;
	}
	if ( 'ww_language' === ( $tax_query['taxonomy'] ?? null ) ) {
		return true;
	}
	foreach ( $tax_query as $clause ) {
		if ( is_array( $clause ) && _ww_languages_has_language_clause( $clause ) ) {
			return true;
		}
	}
	return false;
}

/**
 * De taal waarop een query gefilterd wordt, of null voor geen taalvoorwaarde.
 *
 * - In de admin alleen met de query var ww_lang (het taalfilter in de berichtenlijst), en dan elke ingestelde taal.
 * - Het argument lang gaat voor: '' is alle talen (in de uit-stand de standaardtaal), anders zie
 *   _ww_languages_valid_language().
 * - Anders de taal van het verzoek; in de uit-stand altijd de standaardtaal.
 *
 * @param WP_Query    $query     De query.
 * @param string|null $requested Het argument lang, of null als het niet (als string) is meegegeven.
 */
function _ww_languages_query_language( WP_Query $query, ?string $requested = null ): ?string {
	if ( is_admin() ) {
		$lang = $query->get( 'ww_lang' );
		return is_string( $lang ) && in_array( $lang, _ww_language_codes(), true ) ? $lang : null;
	}

	if ( null !== $requested ) {
		if ( '' === $requested ) {
			return _ww_languages_active() ? null : _ww_default_language();
		}
		return _ww_languages_valid_language( $requested, 'WP_Query lang' );
	}
	return _ww_languages_active() ? _ww_languages_request_language() : _ww_default_language();
}

/**
 * Actie pre_get_posts: geeft een query voor vertaalbare post types de taalvoorwaarde (_ww_languages_tax_query()), met
 * AND naast een bestaande tax_query. Draait ook bij suppress_filters (get_posts()).
 *
 * Overgeslagen: met alleen de standaardtaal; onder WP-CLI en cron (alleen de frontend wordt gefilterd); in de admin
 * zonder ww_lang; in REST, behalve het kaarten-endpoint; een query op ID (p, page_id, attachment_id, post__in); een
 * query die al een voorwaarde op ww_language heeft; en een query zonder vertaalbaar post type.
 *
 * Een expliciet argument lang wordt in de admin en in REST (behalve het kaarten-endpoint) genegeerd: daar filtert de
 * module niet. Een bericht zonder taalterm hoort bij de standaardtaal, dus zoeken en termarchieven in een extra taal
 * laten niet-vertaalbare post types (die nooit een taalterm hebben) weg. De sticky posts van de blog staan in
 * _ww_languages_sticky_posts().
 */
function _ww_languages_pre_get_posts( WP_Query $query ): void {
	if ( array() === _ww_extra_language_codes() || ! taxonomy_exists( 'ww_language' ) || _ww_languages_cli_or_cron() ) {
		return;
	}
	// Het argument lang is hier van de module: met een vertaalplugin actief draait hij niet. Het gaat uit de query vars,
	// zodat een taxonomie van een plugin met de query var lang hem niet leest.
	$requested = isset( $query->query_vars['lang'] ) && is_string( $query->query_vars['lang'] ) ? $query->query_vars['lang'] : null;
	unset( $query->query_vars['lang'] );

	if ( is_admin() && '' === $query->get( 'ww_lang' ) ) {
		return;
	}
	if ( wp_is_serving_rest_request() && ! _ww_languages_is_cards_request() ) {
		return;
	}
	foreach ( array( 'p', 'page_id', 'attachment_id' ) as $key ) {
		if ( (int) $query->get( $key ) > 0 ) {
			return;
		}
	}
	$in = $query->get( 'post__in' );
	if ( is_array( $in ) && array() !== $in ) {
		return;
	}
	$tax_query = $query->get( 'tax_query' );
	if ( _ww_languages_has_language_clause( $tax_query ) ) {
		return;
	}
	if ( array() === array_intersect( _ww_languages_query_post_types( $query ), _ww_translatable_post_types() ) ) {
		return;
	}

	$lang = _ww_languages_query_language( $query, $requested );
	if ( null === $lang ) {
		return;
	}

	// Altijd met AND erboven: WP_Query zet de taxonomie-query vars (project_category=x) op het hoogste niveau erbij, en
	// naast de OR van de standaardtaal zou dat elke categorie doorlaten.
	$clauses = array( 'relation' => 'AND' );
	if ( is_array( $tax_query ) && array() !== $tax_query ) {
		$clauses[] = $tax_query;
	}
	$clauses[] = _ww_languages_tax_query( $lang );
	$query->set( 'tax_query', $clauses );
	$query->set( '_ww_language', $lang );
}

/**
 * Actie parse_tax_query: haalt de taal uit queried_terms als het query-filter hem heeft toegevoegd. Anders wordt de
 * taalterm het object van een termarchief (get_queried_object()) en zet WP_Query hem als query var taxonomy.
 */
function _ww_languages_parse_tax_query( WP_Query $query ): void {
	if ( '' !== $query->get( '_ww_language' ) && $query->tax_query instanceof WP_Tax_Query ) {
		unset( $query->tax_query->queried_terms['ww_language'] );
	}
}

/**
 * Of dit verzoek WP-CLI of cron is. Die zijn geen frontend en worden niet op taal gefilterd.
 */
function _ww_languages_cli_or_cron(): bool {
	return ( defined( 'WP_CLI' ) && WP_CLI ) || wp_doing_cron();
}

/**
 * Filter option_sticky_posts, alleen op de frontend: alleen de sticky posts in de taal van het verzoek (in de uit-stand
 * de standaardtaal). WP_Query haalt de ontbrekende sticky posts van de blog op met post__in, en die subquery slaat het
 * query-filter over; zonder dit kwamen sticky posts uit een andere of verborgen taal bovenaan.
 *
 * Nooit in de admin, REST, WP-CLI of cron: stick_post() en unstick_post() lezen de optie, passen hem aan en schrijven
 * hem terug, en zouden de gefilterde lijst opslaan. Hooguit één termquery voor alle sticky posts
 * (update_object_term_cache()); daarna staan de termen in de cache, dus is_sticky(), dat de optie per bericht leest, kost
 * geen query meer. Een lege optie kost niets.
 *
 * @param mixed $ids Waarde van de optie.
 * @return mixed
 */
function _ww_languages_sticky_posts( mixed $ids ): mixed {
	if ( ! is_array( $ids ) || array() === $ids || is_admin() || wp_is_serving_rest_request() || _ww_languages_cli_or_cron() ) {
		return $ids;
	}
	if ( ! taxonomy_exists( 'ww_language' ) || ! _ww_is_translatable( 'post' ) ) {
		return $ids;
	}

	$lang = _ww_languages_active() ? _ww_languages_request_language() : _ww_default_language();
	$ids  = array_values( array_filter( array_map( 'intval', $ids ) ) );

	// De termen van alle sticky posts in één query in de cache (alleen wat er nog niet in stond), daarna per bericht uit
	// de cache. Zonder term hoort een bericht bij de standaardtaal.
	update_object_term_cache( $ids, 'post' );
	$kept = array();
	foreach ( $ids as $id ) {
		$terms = get_object_term_cache( $id, 'ww_language' );
		$code  = is_array( $terms ) && isset( $terms[0] ) && in_array( $terms[0]->slug, _ww_language_codes(), true ) ? $terms[0]->slug : _ww_default_language();
		if ( $code === $lang ) {
			$kept[] = $id;
		}
	}
	return $kept;
}

/**
 * Hangt het query-filter op. Ook in de uit-stand, dan met de standaardtaal.
 */
function _ww_languages_hook_query(): void {
	add_action( 'pre_get_posts', '_ww_languages_pre_get_posts' );
	add_action( 'parse_tax_query', '_ww_languages_parse_tax_query' );
	add_filter( 'option_sticky_posts', '_ww_languages_sticky_posts' );
}

/**
 * De query van de menu-items waarvan de termen nog in de cache moeten (zie _ww_languages_prime_menu()).
 *
 * @param WP_Query|null $query Zet de query; null leest hem alleen.
 * @param bool          $clear Haalt hem weg.
 */
function _ww_languages_menu_query( ?WP_Query $query = null, bool $clear = false ): ?WP_Query {
	static $pending = null;
	if ( $clear ) {
		$pending = null;
	} elseif ( null !== $query ) {
		$pending = $query;
	}
	return $pending;
}

/**
 * Hook pre_get_posts: onthoudt de query van wp_get_nav_menu_items(). Die draait met suppress_filters, dus the_posts
 * komt niet langs; de termen gaan pas bij het eerste item in de cache (_ww_languages_prime_menu()).
 *
 * @param WP_Query $query Query.
 */
function _ww_languages_remember_menu_query( WP_Query $query ): void {
	if ( 'nav_menu_item' === $query->get( 'post_type' ) && $query->get( 'update_menu_item_cache' ) ) {
		_ww_languages_menu_query( $query );
	}
}

/**
 * Filter pre_wp_setup_nav_menu_item: bij het eerste item van een menu zet hij de taaltermen van alle berichten waar het
 * menu naar linkt in één keer in de cache. Anders kost elk item een termquery voor zijn link (_ww_post_language()).
 * WordPress zet die berichten zelf al in de cache (update_menu_item_cache()), hun termen niet. De metadata van de
 * items staat er op dit moment al in.
 *
 * @param mixed $pre       Waarde van een ander filter; komt altijd ongewijzigd terug.
 * @param mixed $menu_item Het menu-item.
 * @return mixed
 */
function _ww_languages_prime_menu( mixed $pre, mixed $menu_item ): mixed {
	$query = _ww_languages_menu_query();
	if ( null === $query || ! $menu_item instanceof WP_Post || ! in_array( $menu_item->ID, wp_list_pluck( $query->posts, 'ID' ), true ) ) {
		return $pre;
	}
	_ww_languages_menu_query( null, true );

	$ids   = array();
	$types = array();
	foreach ( $query->posts as $item ) {
		if ( ! $item instanceof WP_Post || 'post_type' !== get_post_meta( $item->ID, '_menu_item_type', true ) ) {
			continue;
		}
		$type = (string) get_post_meta( $item->ID, '_menu_item_object', true );
		if ( _ww_is_translatable( $type ) ) {
			$ids[]          = (int) get_post_meta( $item->ID, '_menu_item_object_id', true );
			$types[ $type ] = true;
		}
	}
	if ( array() !== $ids ) {
		update_object_term_cache( array_values( array_unique( $ids ) ), array_keys( $types ) );
	}
	return $pre;
}

/**
 * Hangt de hooks van dit onderdeel op. Draait ook na init (zie _ww_languages_boot()). Met alleen de standaardtaal is er
 * geen voorvoegsel, geen tweede taal voor een slug en niets te filteren.
 */
function _ww_languages_boot_links(): void {
	if ( array() === _ww_extra_language_codes() ) {
		return;
	}
	_ww_languages_hook_query();
	add_filter( 'post_link', '_ww_languages_post_link', 10, 2 );
	add_filter( 'post_type_link', '_ww_languages_post_link', 10, 2 );
	add_filter( 'page_link', '_ww_languages_page_link', 10, 3 );
	add_filter( 'post_type_archive_link', '_ww_languages_current_link' );
	add_filter( 'term_link', '_ww_languages_current_link' );
	add_filter( 'get_pagenum_link', '_ww_languages_current_link' );
	add_filter( 'search_link', '_ww_languages_current_link' );
	add_filter( 'home_url', '_ww_languages_home_url', 10, 3 );
	add_filter( 'wp_unique_post_slug', '_ww_languages_unique_slug', 10, 6 );
	add_action( 'pre_get_posts', '_ww_languages_remember_menu_query' );
	add_filter( 'pre_wp_setup_nav_menu_item', '_ww_languages_prime_menu', 10, 2 );
}
