<?php
/**
 * Meertalig (beslissing 0040), onderdeel admin: de pagina Talen, de metabox Taal en de kolom en het filter in de
 * berichtenlijst. WP-CLI (wp ww languages) staat in inc/languages-cli.php.
 *
 * Alles hangt alleen als de module actief is (_ww_languages_boot_admin() vanuit _ww_languages_boot()): met het vinkje
 * uit, in de uit-stand en met een vertaalplugin is er geen menu-item, metabox, kolom of filter. De opslag van de talen
 * (_ww_languages_save()) en de tellingen staan hier ook, want de pagina en WP-CLI gebruiken ze.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Het hoofdmenu-item Talen. Ook gedefinieerd als de module uit staat, want inc/admin-menu.php gebruikt het.
const WW_LANGUAGES_PAGE = 'ww-languages';

/**
 * De statussen die meetellen als "berichten in een taal": alles behalve auto-draft, dus ook concepten en de prullenbak.
 * Een bericht in de prullenbak houdt zijn taalterm en komt bij terugzetten terug.
 *
 * @return string[]
 */
function _ww_languages_counted_statuses(): array {
	return array_values( array_diff( get_post_stati(), array( 'auto-draft' ) ) );
}

/**
 * Het aantal berichten met de taalterm van deze taal, per vertaalbaar post type (alleen de post types met berichten).
 *
 * @param string $code Taalcode.
 * @return array<string,int>
 */
function _ww_languages_post_counts( string $code ): array {
	$counts = array();
	foreach ( _ww_translatable_post_types() as $type ) {
		$query = new WP_Query(
			array(
				'post_type'           => $type,
				'post_status'         => _ww_languages_counted_statuses(),
				'tax_query'           => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- alleen in het beheer en WP-CLI.
					array(
						'taxonomy' => 'ww_language',
						'field'    => 'slug',
						'terms'    => array( $code ),
					),
				),
				'fields'              => 'ids',
				'posts_per_page'      => 1,
				'ignore_sticky_posts' => true,
			)
		);
		if ( $query->found_posts > 0 ) {
			$counts[ $type ] = (int) $query->found_posts;
		}
	}
	return $counts;
}

/**
 * Of er een vertaalbaar bericht met een taalterm is. Dan ligt de standaardtaal vast: een bericht zonder term hoort bij
 * de standaardtaal, dus wisselen zou die berichten van taal laten veranderen.
 */
function _ww_languages_has_tagged_posts(): bool {
	if ( ! taxonomy_exists( 'ww_language' ) ) {
		return false;
	}
	$query = new WP_Query(
		array(
			'post_type'           => _ww_translatable_post_types(),
			'post_status'         => _ww_languages_counted_statuses(),
			'tax_query'           => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- alleen in het beheer.
				array(
					'taxonomy' => 'ww_language',
					'operator' => 'EXISTS',
				),
			),
			'fields'              => 'ids',
			'posts_per_page'      => 1,
			'no_found_rows'       => true,
			'ignore_sticky_posts' => true,
		)
	);
	return array() !== $query->posts;
}

/**
 * Bewaart een gecontroleerde configuratie en doet wat erbij hoort: termen bijwerken, rewrite rules flushen en de hele
 * paginacache legen (de taalwisselaar en hreflang staan op elke pagina).
 *
 * @param array{default:string,languages:array<int,array{code:string,locale:string,name:string,visible:bool,bases?:array<string,string>,tagline?:string}>,default_bases?:array<string,string>} $clean Uit _ww_languages_sanitize().
 */
function _ww_languages_store( array $clean ): void {
	update_option( 'ww_languages', $clean, true );
	_ww_languages_sync_terms();
	flush_rewrite_rules( false );
	do_action( '_ww_purge_all' );
}

/**
 * Slaat de talen op (pagina Talen). Weigert, naast de controles van _ww_languages_sanitize():
 *
 * - ww_languages_duplicate_tag: twee talen met dezelfde BCP 47-code voor hreflang (de_DE en de_DE_formal);
 * - ww_languages_in_use: een taal verwijderen die nog berichten heeft, met de aantallen per post type als data;
 * - ww_languages_default_locked: de standaardtaal wisselen terwijl er berichten met een taalterm zijn (dat kan alleen
 *   met wp ww languages set-default).
 *
 * Na het opslaan: termen bijwerken (bestaande blijven staan), flushen en de hele cache legen, ook als er niets
 * veranderde. Zo leegt ook een wissel van Zichtbaar voor bezoekers de cache. De URL-basis en de ondertitel per taal
 * blijven staan als de invoer ze niet meegeeft (_ww_languages_keep_extras()).
 *
 * @param array<string,mixed> $input { default, languages: [ { code, locale, name, visible } ] }.
 * @return true|WP_Error
 */
function _ww_languages_save( array $input ): true|WP_Error {
	$clean = _ww_languages_sanitize( _ww_languages_keep_extras( $input ) );
	if ( $clean instanceof WP_Error ) {
		return $clean;
	}

	$tags = array();
	foreach ( $clean['languages'] as $language ) {
		$tag = strtolower( _ww_languages_bcp47( $language['locale'], $language['code'] ) );
		if ( isset( $tags[ $tag ] ) ) {
			return new WP_Error(
				'ww_languages_duplicate_tag',
				/* translators: 1: eerste taalcode, 2: tweede taalcode, 3: BCP 47-code zoals en-GB */
				sprintf( __( 'De talen "%1$s" en "%2$s" krijgen allebei de taalcode %3$s voor zoekmachines. Kies voor een van beide een andere locale.', 'webwerckt-base' ), $tags[ $tag ], $language['code'], _ww_languages_bcp47( $language['locale'], $language['code'] ) )
			);
		}
		$tags[ $tag ] = $language['code'];
	}

	$old     = _ww_languages_config();
	$removed = array_diff( array_column( $old['languages'], 'code' ), array_column( $clean['languages'], 'code' ) );
	foreach ( $removed as $code ) {
		$counts = taxonomy_exists( 'ww_language' ) ? _ww_languages_post_counts( $code ) : array();
		if ( array() !== $counts ) {
			return new WP_Error(
				'ww_languages_in_use',
				sprintf(
					/* translators: 1: taalcode, 2: aantallen per soort inhoud, zoals "Pagina's: 2, Berichten: 1" */
					__( 'De taal "%1$s" heeft nog inhoud (%2$s, ook concepten en prullenbak) en kan niet weg. Verberg de taal met Zichtbaar voor bezoekers: zo zet je een taal uit.', 'webwerckt-base' ),
					$code,
					_ww_languages_counts_label( $counts )
				),
				$counts
			);
		}
	}

	if ( '' !== $old['default'] && $clean['default'] !== $old['default'] && _ww_languages_has_tagged_posts() ) {
		return new WP_Error(
			'ww_languages_default_locked',
			/* translators: %s: WP-CLI-commando */
			sprintf( __( 'De standaardtaal ligt vast zodra er inhoud met een taal is. Wissel hem met WP-CLI: %s', 'webwerckt-base' ), 'wp ww languages set-default <code>' )
		);
	}

	_ww_languages_store( $clean );
	return true;
}

/**
 * Neemt de URL-basissen en de ondertitel per taal (op code, niet op volgorde) en default_bases over uit de opgeslagen
 * optie als de invoer ze niet meegeeft. Het formulier met de talen en WP-CLI kennen die sleutels niet; zonder dit zou
 * elke opslag ze wissen.
 *
 * @param array<string,mixed> $input { default, languages, default_bases }.
 * @return array<string,mixed>
 */
function _ww_languages_keep_extras( array $input ): array {
	$old = _ww_languages_config();
	if ( ! array_key_exists( 'default_bases', $input ) && isset( $old['default_bases'] ) ) {
		$input['default_bases'] = $old['default_bases'];
	}
	if ( ! isset( $input['languages'] ) || ! is_array( $input['languages'] ) ) {
		return $input;
	}

	$stored = array_column( $old['languages'], null, 'code' );
	foreach ( $input['languages'] as $index => $row ) {
		$code = is_array( $row ) && isset( $row['code'] ) && is_string( $row['code'] ) ? trim( $row['code'] ) : '';
		if ( ! isset( $stored[ $code ] ) ) {
			continue;
		}
		foreach ( array( 'bases', 'tagline' ) as $key ) {
			if ( ! array_key_exists( $key, $row ) && isset( $stored[ $code ][ $key ] ) ) {
				$input['languages'][ $index ][ $key ] = $stored[ $code ][ $key ];
			}
		}
	}
	return $input;
}

/**
 * Aantallen per post type als tekst: "Pagina's: 2, Berichten: 1".
 *
 * @param array<string,int> $counts Post type => aantal.
 */
function _ww_languages_counts_label( array $counts ): string {
	$parts = array();
	foreach ( $counts as $type => $count ) {
		$object  = get_post_type_object( $type );
		$parts[] = ( $object ? $object->labels->name : $type ) . ': ' . $count;
	}
	return implode( ', ', $parts );
}

/**
 * De ID's van menu-items die naar een bericht in deze taal wijzen. De pagina Talen noemt ze bij een verborgen taal:
 * voor een bezoeker geven ze een 404.
 *
 * @param string $code Taalcode.
 * @return int[]
 */
function _ww_languages_menu_items_in( string $code ): array {
	$items = get_posts(
		array(
			'post_type'        => 'nav_menu_item',
			'post_status'      => 'any',
			'posts_per_page'   => -1,
			'fields'           => 'ids',
			'orderby'          => 'ID',
			'order'            => 'ASC',
			'meta_key'         => '_menu_item_type', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- alleen in het beheer.
			'meta_value'       => 'post_type', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- alleen in het beheer.
			'suppress_filters' => false,
		)
	);

	$found = array();
	foreach ( $items as $item ) {
		$target = (int) get_post_meta( (int) $item, '_menu_item_object_id', true );
		if ( $target > 0 && _ww_post_language( $target ) === $code ) {
			$found[] = (int) $item;
		}
	}
	return $found;
}

/**
 * De taalcodes die gelijk zijn aan de slug van een pagina op het hoogste niveau. De taal gaat voor: zo'n pagina is op
 * dat adres niet meer bereikbaar (ook de standaardtaal: /nl/... stuurt door zonder voorvoegsel).
 *
 * @return string[]
 */
function _ww_languages_slug_conflicts(): array {
	$codes = _ww_language_codes();
	if ( array() === $codes ) {
		return array();
	}
	$pages = get_posts(
		array(
			'post_type'        => 'page',
			'post_status'      => array( 'publish', 'future', 'draft', 'pending', 'private' ),
			'post_parent'      => 0,
			'post_name__in'    => $codes,
			'posts_per_page'   => -1,
			'lang'             => '',
			'suppress_filters' => false,
		)
	);
	$slugs = wp_list_pluck( $pages, 'post_name' );
	return array_values( array_intersect( $codes, $slugs ) );
}

/**
 * De locales zonder vertaling van het thema (languages/{locale}.mo in de parent, of een bestand in dezelfde taal): die tonen de bronstrings. Nederlands
 * is de brontaal en heeft geen .mo nodig.
 *
 * @return string[]
 */
function _ww_languages_missing_mo(): array {
	$missing = array();
	foreach ( _ww_languages_config()['languages'] as $language ) {
		$locale = $language['locale'];
		if ( 1 === preg_match( '/^nl(_|$)/', $locale ) || in_array( $locale, $missing, true ) ) {
			continue;
		}
		// Met de terugval op dezelfde taal (en_US naar en_GB) telt een bestand in die taal als vertaling.
		$wanted = get_template_directory() . '/languages/' . $locale . '.mo';
		if ( ! file_exists( _ww_mofile_fallback( $wanted, 'webwerckt-base' ) ) ) {
			$missing[] = $locale;
		}
	}
	return $missing;
}

/*
 * Pagina Talen.
 */

/**
 * Voegt Talen toe als hoofditem, in het Webwerckt-blok (beslissing 0035). Alleen met de module aan.
 */
function _ww_languages_admin_menu(): void {
	add_menu_page(
		__( 'Talen', 'webwerckt-base' ),
		__( 'Talen', 'webwerckt-base' ),
		'manage_options',
		WW_LANGUAGES_PAGE,
		'_ww_languages_admin_render',
		'dashicons-translation'
	);
}

/**
 * URL van de pagina Talen.
 *
 * @param array<string,string> $args Queryvariabelen.
 */
function _ww_languages_admin_url( array $args = array() ): string {
	return add_query_arg( array_map( 'rawurlencode', array( 'page' => WW_LANGUAGES_PAGE ) + $args ), admin_url( 'admin.php' ) );
}

/**
 * De rijen zoals de beheerder ze invulde, na een fout bij opslaan, zodat het formulier niet leeg terugkomt.
 *
 * @param array<string,mixed>|null $set Met een waarde: onthoud die.
 * @return array<string,mixed>|null
 */
function _ww_languages_admin_form( ?array $set = null ): ?array {
	static $form = null;
	if ( null !== $set ) {
		$form = array() === $set ? null : $set;
	}
	return $form;
}

/**
 * Maakt van het formulier een invoer voor _ww_languages_save(): de rijen op volgorde, zonder de verwijderde en zonder
 * een lege nieuwe rij. Met $keep_removed blijven de verwijderde rijen staan: voor het formulier na een geweigerde
 * opslag, zodat een taal die niet weg kon nog in de tabel staat (met de schakelaar om hem te verbergen).
 *
 * @param array<mixed> $post         De velden van het formulier (zonder slashes).
 * @param bool         $keep_removed Verwijderde rijen niet overslaan.
 * @return array{default:string,languages:array<int,array{code:string,locale:string,name:string,visible:bool}>}
 */
function _ww_languages_admin_input( array $post, bool $keep_removed = false ): array {
	$rows   = isset( $post['ww_rows'] ) && is_array( $post['ww_rows'] ) ? $post['ww_rows'] : array();
	$sorted = array();
	$index  = 0;

	foreach ( $rows as $key => $row ) {
		if ( ! is_array( $row ) || ( ! $keep_removed && ! empty( $row['remove'] ) ) ) {
			continue;
		}
		$code = strtolower( trim( _ww_data_to_string( $row['code'] ?? '' ) ) );
		if ( 'new' === $key && '' === $code ) {
			continue;
		}
		$order    = trim( _ww_data_to_string( $row['order'] ?? '' ) );
		$sorted[] = array(
			is_numeric( $order ) ? (int) $order : PHP_INT_MAX,
			$index++,
			array(
				'code'    => $code,
				'locale'  => trim( _ww_data_to_string( $row['locale'] ?? '' ) ),
				'name'    => trim( _ww_data_to_string( $row['name'] ?? '' ) ),
				'visible' => ! empty( $row['visible'] ),
			),
		);
	}
	usort( $sorted, static fn( array $a, array $b ): int => array( $a[0], $a[1] ) <=> array( $b[0], $b[1] ) );

	return array(
		'default'   => strtolower( trim( _ww_data_to_string( $post['ww_default'] ?? '' ) ) ),
		'languages' => array_column( $sorted, 2 ),
	);
}

/**
 * Slaat het formulier op (admin_init, ww_languages_action=save met nonce ww_languages_save) en stuurt terug naar de
 * pagina. Bij een fout blijft de invoer staan en toont de pagina de melding.
 */
function _ww_languages_admin_handle(): void {
	// phpcs:ignore WordPress.Security.NonceVerification -- de nonce wordt hieronder gecontroleerd.
	$action = isset( $_REQUEST['ww_languages_action'] ) && is_string( $_REQUEST['ww_languages_action'] ) ? $_REQUEST['ww_languages_action'] : '';
	if ( 'save_bases' === $action ) {
		_ww_languages_admin_handle_bases();
		return;
	}
	if ( 'save_tagline' === $action ) {
		_ww_languages_admin_handle_tagline();
		return;
	}
	if ( 'save' !== $action ) {
		return;
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Je hebt geen rechten om de talen te beheren.', 'webwerckt-base' ), 403 );
	}
	check_admin_referer( 'ww_languages_save' );

	$post   = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- _ww_languages_save() controleert elk veld.
	$result = _ww_languages_save( _ww_languages_admin_input( $post ) );
	if ( $result instanceof WP_Error ) {
		_ww_languages_admin_form( _ww_languages_admin_input( $post, true ) );
		add_settings_error( 'ww_languages', (string) $result->get_error_code(), esc_html( $result->get_error_message() ) );
		return;
	}

	_ww_languages_admin_form( array() );
	add_settings_error( 'ww_languages', 'ww_languages_saved', esc_html__( 'De talen zijn opgeslagen.', 'webwerckt-base' ), 'success' );
	set_transient( 'settings_errors', get_settings_errors(), 30 );
	if ( wp_safe_redirect( _ww_languages_admin_url( array( 'settings-updated' => 'true' ) ) ) ) {
		exit;
	}
}

/**
 * De URL-basissen zoals de beheerder ze invulde, na een geweigerde opslag: taalcode => naam => basis.
 *
 * @param array<string,array<string,string>>|null $set Met een waarde: onthoud die.
 * @return array<string,array<string,string>>
 */
function _ww_languages_admin_bases_form( ?array $set = null ): array {
	static $form = array();
	if ( null !== $set ) {
		$form = $set;
	}
	return $form;
}

/**
 * Slaat de URL-basis van één extra taal op (admin_init, ww_languages_action=save_bases met nonce ww_languages_bases,
 * velden ww_bases_lang en ww_bases[naam]) en stuurt terug naar de pagina. Bij een fout blijft de invoer staan en toont de
 * pagina de melding.
 */
function _ww_languages_admin_handle_bases(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Je hebt geen rechten om de talen te beheren.', 'webwerckt-base' ), 403 );
	}
	check_admin_referer( 'ww_languages_bases' );

	$lang  = isset( $_POST['ww_bases_lang'] ) && is_string( $_POST['ww_bases_lang'] ) ? sanitize_key( wp_unslash( $_POST['ww_bases_lang'] ) ) : '';
	$raw   = isset( $_POST['ww_bases'] ) && is_array( $_POST['ww_bases'] ) ? wp_unslash( $_POST['ww_bases'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- _ww_language_save_bases() maakt elke waarde schoon.
	$bases = array();
	foreach ( (array) $raw as $name => $base ) {
		$bases[ sanitize_key( (string) $name ) ] = trim( _ww_data_to_string( $base ) );
	}

	$result = _ww_language_save_bases( $lang, $bases );
	if ( $result instanceof WP_Error ) {
		_ww_languages_admin_bases_form( array( $lang => $bases ) );
		add_settings_error( 'ww_languages', (string) $result->get_error_code(), esc_html( $result->get_error_message() ) );
		return;
	}

	_ww_languages_admin_bases_form( array() );
	add_settings_error( 'ww_languages', 'ww_language_bases_saved', esc_html__( 'De URL-basis is opgeslagen.', 'webwerckt-base' ), 'success' );
	set_transient( 'settings_errors', get_settings_errors(), 30 );
	if ( wp_safe_redirect( _ww_languages_admin_url( array( 'settings-updated' => 'true' ) ) ) ) {
		exit;
	}
}

/**
 * Slaat de ondertitel van één extra taal op (admin_init, ww_languages_action=save_tagline met nonce ww_languages_tagline,
 * velden ww_tagline_lang en ww_tagline) en stuurt terug naar de pagina. Een fout komt als melding boven de pagina.
 */
function _ww_languages_admin_handle_tagline(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Je hebt geen rechten om de talen te beheren.', 'webwerckt-base' ), 403 );
	}
	check_admin_referer( 'ww_languages_tagline' );

	$lang    = isset( $_POST['ww_tagline_lang'] ) && is_string( $_POST['ww_tagline_lang'] ) ? sanitize_key( wp_unslash( $_POST['ww_tagline_lang'] ) ) : '';
	$tagline = isset( $_POST['ww_tagline'] ) && is_string( $_POST['ww_tagline'] ) ? sanitize_text_field( wp_unslash( $_POST['ww_tagline'] ) ) : '';

	$result = _ww_language_save_tagline( $lang, $tagline );
	if ( $result instanceof WP_Error ) {
		add_settings_error( 'ww_languages', (string) $result->get_error_code(), esc_html( $result->get_error_message() ) );
		return;
	}

	add_settings_error( 'ww_languages', 'ww_language_tagline_saved', esc_html__( 'De ondertitel is opgeslagen.', 'webwerckt-base' ), 'success' );
	set_transient( 'settings_errors', get_settings_errors(), 30 );
	if ( wp_safe_redirect( _ww_languages_admin_url( array( 'settings-updated' => 'true' ) ) ) ) {
		exit;
	}
}

/**
 * Een melding boven de pagina.
 *
 * @param string $type    warning, info of error.
 * @param string $message Tekst (wordt geëscapet).
 */
function _ww_languages_admin_notice( string $type, string $message ): void {
	printf( '<div class="notice notice-%1$s"><p>%2$s</p></div>', esc_attr( $type ), esc_html( $message ) );
}

/**
 * De waarschuwingen boven de pagina: codes die een pagina verdringen, locales zonder vertaling van het thema en
 * menu-items naar een verborgen taal.
 */
function _ww_languages_admin_notices(): void {
	foreach ( _ww_languages_slug_conflicts() as $code ) {
		_ww_languages_admin_notice(
			'warning',
			/* translators: %s: taalcode */
			sprintf( __( 'Er is een pagina met de slug "%s". De taal gaat voor: die pagina is op dat adres niet meer bereikbaar. Geef de pagina een andere slug.', 'webwerckt-base' ), $code )
		);
	}

	foreach ( _ww_extra_language_codes() as $code ) {
		$language = _ww_language( $code );
		foreach ( _ww_language_base_conflicts( $code, _ww_language_bases( $code ) ) as $name => $reason ) {
			_ww_languages_admin_notice(
				'warning',
				sprintf(
					/* translators: 1: naam van een post type of taxonomie, 2: naam van de taal, 3: de botsing */
					__( 'De URL-basis van %1$s in %2$s botst: %3$s Tot je een andere basis kiest, gaat de basis voor.', 'webwerckt-base' ),
					_ww_language_base_objects()[ $name ]['label'] ?? $name,
					null !== $language ? $language['name'] : $code,
					$reason
				)
			);
		}
	}

	$missing = _ww_languages_missing_mo();
	if ( array() !== $missing ) {
		_ww_languages_admin_notice(
			'info',
			/* translators: %s: locales, zoals "en_GB, de_DE" */
			sprintf( __( 'Het thema heeft nog geen vertaling voor %s. Knoppen en vaste teksten van het thema blijven daar Nederlands.', 'webwerckt-base' ), implode( ', ', $missing ) )
		);
	}

	foreach ( _ww_languages_config()['languages'] as $language ) {
		if ( $language['visible'] ) {
			continue;
		}
		$titles = array();
		foreach ( _ww_languages_menu_items_in( $language['code'] ) as $item_id ) {
			$item     = wp_setup_nav_menu_item( get_post( $item_id ) );
			$titles[] = isset( $item->title ) && '' !== (string) $item->title ? (string) $item->title : '#' . $item_id;
		}
		if ( array() !== $titles ) {
			_ww_languages_admin_notice(
				'warning',
				/* translators: 1: naam van de taal, 2: titels van menu-items */
				sprintf( __( '%1$s is verborgen, maar deze menu-items wijzen naar inhoud in die taal: %2$s. Een bezoeker krijgt daar een 404.', 'webwerckt-base' ), $language['name'], implode( ', ', $titles ) )
			);
		}
	}
}

/**
 * Toont de pagina Talen: meldingen, en een formulier met per taal code, locale, naam, volgorde, Zichtbaar voor
 * bezoekers en verwijderen, een rij om een taal toe te voegen en de keuze van de standaardtaal.
 */
function _ww_languages_admin_render(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	echo '<div class="wrap">';
	echo '<h1 class="wp-heading-inline">' . esc_html__( 'Talen', 'webwerckt-base' ) . '</h1>';
	echo '<hr class="wp-header-end">';

	if ( _ww_languages_plugin_active() ) {
		_ww_languages_admin_notice( 'warning', _ww_languages_plugin_message() );
		echo '</div>';
		return;
	}

	settings_errors( 'ww_languages' );
	_ww_languages_admin_notices();

	$config  = _ww_languages_config();
	$form    = _ww_languages_admin_form();
	$rows    = null !== $form ? $form['languages'] : $config['languages'];
	$default = null !== $form ? (string) $form['default'] : $config['default'];
	$locked  = _ww_languages_has_tagged_posts();

	echo '<p>' . esc_html__( 'De standaardtaal staat op de adressen zonder voorvoegsel; elke extra taal krijgt zijn code ervoor (/en/). Een nieuwe taal is eerst verborgen: alleen redacteuren zien hem, zodat je hem kunt vullen. Verbergen is ook de manier om een taal uit te zetten; een taal met inhoud kan niet weg.', 'webwerckt-base' ) . '</p>';

	echo '<form method="post" action="' . esc_url( _ww_languages_admin_url() ) . '">';
	wp_nonce_field( 'ww_languages_save' );
	echo '<input type="hidden" name="ww_languages_action" value="save">';
	if ( $locked ) {
		echo '<input type="hidden" name="ww_default" value="' . esc_attr( $config['default'] ) . '">';
	}

	echo '<table class="widefat striped"><thead><tr>';
	foreach ( array( __( 'Standaard', 'webwerckt-base' ), __( 'Code', 'webwerckt-base' ), __( 'Locale', 'webwerckt-base' ), __( 'Naam', 'webwerckt-base' ), __( 'Volgorde', 'webwerckt-base' ), __( 'Zichtbaar voor bezoekers', 'webwerckt-base' ), __( 'Status', 'webwerckt-base' ), __( 'Verwijderen', 'webwerckt-base' ) ) as $label ) {
		echo '<th scope="col">' . esc_html( $label ) . '</th>';
	}
	echo '</tr></thead><tbody>';

	$position = 0;
	foreach ( $rows as $index => $row ) {
		$row = is_array( $row ) ? $row : array();
		++$position;
		_ww_languages_admin_render_row( (string) $index, $row, $position, $default, $locked );
	}
	_ww_languages_admin_render_row( 'new', array(), $position + 1, $default, $locked );
	echo '</tbody></table>';

	if ( $locked ) {
		echo '<p class="description">' . esc_html(
			sprintf(
				/* translators: %s: WP-CLI-commando */
				__( 'Er is al inhoud met een taal, dus de standaardtaal ligt vast. Wisselen kan alleen met WP-CLI: %s. Dat geeft de inhoud zonder taal eerst de oude standaardtaal.', 'webwerckt-base' ),
				'wp ww languages set-default <code>'
			)
		) . '</p>';
	}

	submit_button( __( 'Talen opslaan', 'webwerckt-base' ) );
	echo '</form>';

	_ww_languages_admin_render_bases();
	_ww_languages_admin_render_taglines();
	echo '</div>';
}

/**
 * Per extra taal een formulier met de URL-basis: de post types en taxonomieën met een eigen adres, hun echte basis en
 * een veld voor de vertaling. Leeg is de echte basis.
 */
function _ww_languages_admin_render_bases(): void {
	$objects = _ww_language_base_objects();
	$extra   = _ww_extra_language_codes();
	if ( array() === $objects || array() === $extra ) {
		return;
	}
	$posted = _ww_languages_admin_bases_form();

	echo '<h2>' . esc_html__( 'URL-basis per taal', 'webwerckt-base' ) . '</h2>';
	echo '<p>' . esc_html__( 'Het eerste deel van het adres van archieven en categorieën, vertaald per taal (/en/projects/ in plaats van /en/projecten/). Leeg houdt de basis van de standaardtaal. Een nieuwe basis verandert adressen die zoekmachines kennen: het oude adres stuurt door.', 'webwerckt-base' ) . '</p>';

	foreach ( $extra as $code ) {
		$language = _ww_language( $code );
		$values   = $posted[ $code ] ?? _ww_language_bases( $code );

		echo '<form method="post" action="' . esc_url( _ww_languages_admin_url() ) . '">';
		wp_nonce_field( 'ww_languages_bases' );
		echo '<input type="hidden" name="ww_languages_action" value="save_bases">';
		echo '<input type="hidden" name="ww_bases_lang" value="' . esc_attr( $code ) . '">';
		echo '<h3>' . esc_html( null !== $language ? $language['name'] : $code ) . '</h3>';
		echo '<table class="widefat striped"><thead><tr>';
		foreach ( array( __( 'URL-basis', 'webwerckt-base' ), __( 'Standaard', 'webwerckt-base' ), __( 'Vertaling', 'webwerckt-base' ) ) as $label ) {
			echo '<th scope="col">' . esc_html( $label ) . '</th>';
		}
		echo '</tr></thead><tbody>';
		foreach ( $objects as $name => $object ) {
			printf(
				'<tr><td>%1$s</td><td><code>%2$s</code></td><td><input type="text" class="regular-text" name="ww_bases[%3$s]" value="%4$s" aria-label="%5$s" placeholder="%2$s"></td></tr>',
				esc_html( $object['label'] ),
				esc_html( $object['base'] ),
				esc_attr( $name ),
				esc_attr( $values[ $name ] ?? '' ),
				/* translators: 1: naam van een post type of taxonomie, 2: naam van de taal */
				esc_attr( sprintf( __( 'Vertaling van de URL-basis van %1$s in %2$s', 'webwerckt-base' ), $object['label'], null !== $language ? $language['name'] : $code ) )
			);
		}
		echo '</tbody></table>';
		submit_button( __( 'URL-basis opslaan', 'webwerckt-base' ), 'secondary', 'submit-bases-' . $code );
		echo '</form>';
	}
}

/**
 * Per extra taal een veld voor de ondertitel. Leeg is de ondertitel van de standaardtaal (Instellingen → Algemeen).
 */
function _ww_languages_admin_render_taglines(): void {
	$extra = _ww_extra_language_codes();
	if ( array() === $extra ) {
		return;
	}

	echo '<h2>' . esc_html__( 'Ondertitel per taal', 'webwerckt-base' ) . '</h2>';
	echo '<p>' . esc_html__( 'De ondertitel van de site in een extra taal: hij komt in de titel van de homepage en in de structured data. Leeg houdt de ondertitel van de standaardtaal.', 'webwerckt-base' ) . '</p>';

	foreach ( $extra as $code ) {
		$language = _ww_language( $code );
		$name     = null !== $language ? $language['name'] : $code;

		echo '<form method="post" action="' . esc_url( _ww_languages_admin_url() ) . '">';
		wp_nonce_field( 'ww_languages_tagline' );
		echo '<input type="hidden" name="ww_languages_action" value="save_tagline">';
		echo '<input type="hidden" name="ww_tagline_lang" value="' . esc_attr( $code ) . '">';
		echo '<p><label for="ww-tagline-' . esc_attr( $code ) . '"><strong>' . esc_html( $name ) . '</strong>: ' . esc_html__( 'Ondertitel', 'webwerckt-base' ) . '</label><br>';
		echo '<input type="text" class="large-text" id="ww-tagline-' . esc_attr( $code ) . '" name="ww_tagline" value="' . esc_attr( _ww_language_tagline( $code ) ) . '" placeholder="' . esc_attr( _ww_language_tagline( _ww_default_language() ) ) . '"></p>';
		submit_button( __( 'Ondertitel opslaan', 'webwerckt-base' ), 'secondary', 'submit-tagline-' . $code );
		echo '</form>';
	}
}

/**
 * Eén rij van de tabel. De rij 'new' is leeg en voegt een taal toe.
 *
 * @param string              $key      Index van de rij in ww_rows, of 'new'.
 * @param array<string,mixed> $row      code, locale, name, visible.
 * @param int                 $position Volgorde.
 * @param string              $default  Code van de standaardtaal.
 * @param bool                $locked   Of de standaardtaal vastligt.
 */
function _ww_languages_admin_render_row( string $key, array $row, int $position, string $default, bool $locked ): void {
	$code       = _ww_data_to_string( $row['code'] ?? '' );
	$is_new     = 'new' === $key;
	$is_default = ! $is_new && $code === $default;
	$visible    = ! empty( $row['visible'] );
	$name       = 'ww_rows[' . $key . ']';

	echo '<tr>';
	if ( $is_new ) {
		echo '<td colspan="1"><strong>' . esc_html__( 'Nieuw', 'webwerckt-base' ) . '</strong></td>';
	} else {
		printf(
			'<td><input type="radio" name="ww_default" value="%1$s" aria-label="%2$s"%3$s%4$s></td>',
			esc_attr( $code ),
			esc_attr__( 'Standaardtaal', 'webwerckt-base' ),
			checked( $is_default, true, false ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- vaste attribuutstring.
			$locked ? ' disabled="disabled"' : '' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- vaste string.
		);
	}
	printf( '<td><input type="text" class="small-text" name="%1$s[code]" value="%2$s" aria-label="%3$s" placeholder="en"></td>', esc_attr( $name ), esc_attr( $code ), esc_attr__( 'Code', 'webwerckt-base' ) );
	printf( '<td><input type="text" class="regular-text" style="width:8em" name="%1$s[locale]" value="%2$s" aria-label="%3$s" placeholder="en_GB"></td>', esc_attr( $name ), esc_attr( _ww_data_to_string( $row['locale'] ?? '' ) ), esc_attr__( 'Locale', 'webwerckt-base' ) );
	printf( '<td><input type="text" class="regular-text" maxlength="50" name="%1$s[name]" value="%2$s" aria-label="%3$s" placeholder="English"></td>', esc_attr( $name ), esc_attr( _ww_data_to_string( $row['name'] ?? '' ) ), esc_attr__( 'Naam', 'webwerckt-base' ) );
	printf( '<td><input type="number" class="small-text" name="%1$s[order]" value="%2$d" aria-label="%3$s"></td>', esc_attr( $name ), (int) $position, esc_attr__( 'Volgorde', 'webwerckt-base' ) );

	if ( $is_default ) {
		printf( '<td><input type="hidden" name="%1$s[visible]" value="1">%2$s</td>', esc_attr( $name ), esc_html__( 'Altijd', 'webwerckt-base' ) );
		echo '<td>' . esc_html__( 'Standaardtaal', 'webwerckt-base' ) . '</td><td></td>';
	} else {
		printf(
			'<td><label><input type="checkbox" name="%1$s[visible]" value="1"%2$s> %3$s</label></td>',
			esc_attr( $name ),
			checked( $visible, true, false ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- vaste attribuutstring.
			esc_html__( 'Zichtbaar', 'webwerckt-base' )
		);
		if ( $is_new ) {
			echo '<td>' . esc_html__( 'Begint verborgen', 'webwerckt-base' ) . '</td><td></td>';
		} else {
			echo '<td>' . esc_html( $visible ? __( 'Zichtbaar', 'webwerckt-base' ) : __( 'Verborgen, alleen voor redacteuren', 'webwerckt-base' ) ) . '</td>';
			printf( '<td><input type="checkbox" name="%1$s[remove]" value="1" aria-label="%2$s"></td>', esc_attr( $name ), esc_attr__( 'Verwijderen', 'webwerckt-base' ) );
		}
	}
	echo '</tr>';
}

/*
 * Metabox Taal.
 */

/**
 * Zet de metabox Taal op het bewerkscherm van een vertaalbaar post type, alleen voor beheerders.
 *
 * @param string $post_type Post type van het bewerkscherm.
 */
function _ww_languages_add_metabox( string $post_type ): void {
	if ( ! current_user_can( 'manage_options' ) || ! _ww_is_translatable( $post_type ) ) {
		return;
	}
	add_meta_box( 'ww-language', __( 'Taal', 'webwerckt-base' ), '_ww_languages_metabox_render', $post_type, 'side', 'default' );
}

/**
 * De taalcode uit ?ww_lang= (post-new.php), of '' als die geen ingestelde taal is.
 */
function _ww_languages_requested_new_language(): string {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen gelezen en gecontroleerd tegen de ingestelde talen.
	$lang = isset( $_GET['ww_lang'] ) && is_string( $_GET['ww_lang'] ) ? sanitize_key( wp_unslash( $_GET['ww_lang'] ) ) : '';
	return in_array( $lang, _ww_language_codes(), true ) ? $lang : '';
}

/**
 * Berichten van dit post type in deze taal, als kandidaat om te koppelen (titel op volgorde, hoogstens 200).
 *
 * @param string $post_type Post type.
 * @param string $code      Taalcode.
 * @param int    $exclude   Het bericht zelf.
 * @return WP_Post[]
 */
function _ww_languages_link_candidates( string $post_type, string $code, int $exclude ): array {
	$posts = get_posts(
		array(
			'post_type'        => $post_type,
			'post_status'      => array( 'publish', 'future', 'draft', 'pending', 'private' ),
			'tax_query'        => _ww_languages_tax_query( $code ), // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- alleen in het beheer.
			'post__not_in'     => array( $exclude ),
			'posts_per_page'   => 200,
			'orderby'          => 'title',
			'order'            => 'ASC',
			'suppress_filters' => false,
		)
	);
	return array_values( $posts );
}

/**
 * De metabox: de taal van het bericht, per andere taal de gekoppelde vertaling (link) of een keuzelijst om er een te
 * koppelen, en ontkoppelen. Een nieuw bericht toont de taal van ?ww_lang=, anders de standaardtaal.
 *
 * @param WP_Post $post Het bericht.
 */
function _ww_languages_metabox_render( WP_Post $post ): void {
	$current = _ww_post_language( $post->ID );
	if ( 'auto-draft' === $post->post_status && '' !== _ww_languages_requested_new_language() ) {
		$current = _ww_languages_requested_new_language();
	}
	$group = _ww_translations( $post->ID );

	wp_nonce_field( 'ww_language_box', 'ww_language_box_nonce' );
	echo '<p><label for="ww-lang"><strong>' . esc_html__( 'Taal van deze inhoud', 'webwerckt-base' ) . '</strong></label><br>';
	echo '<select name="ww_lang" id="ww-lang">';
	foreach ( _ww_languages_config()['languages'] as $language ) {
		printf( '<option value="%1$s"%2$s>%3$s</option>', esc_attr( $language['code'] ), selected( $language['code'], $current, false ), esc_html( $language['name'] ) );
	}
	echo '</select></p>';

	if ( 'auto-draft' === $post->post_status ) {
		echo '<p class="description">' . esc_html__( 'Koppelen kan na het eerste opslaan.', 'webwerckt-base' ) . '</p>';
		return;
	}

	echo '<p><strong>' . esc_html__( 'Vertalingen', 'webwerckt-base' ) . '</strong></p>';
	foreach ( _ww_languages_config()['languages'] as $language ) {
		$code = $language['code'];
		if ( $code === $current ) {
			continue;
		}
		$linked = $group[ $code ] ?? 0;
		if ( $linked > 0 && $linked !== $post->ID ) {
			$link = get_edit_post_link( $linked );
			echo '<p>' . esc_html( $language['name'] ) . ': ';
			if ( is_string( $link ) && '' !== $link ) {
				echo '<a href="' . esc_url( $link ) . '">' . esc_html( get_the_title( $linked ) ) . '</a>';
			} else {
				echo esc_html( get_the_title( $linked ) );
			}
			echo '</p>';
			continue;
		}

		$field = 'ww-link-' . $code;
		echo '<p><label for="' . esc_attr( $field ) . '">' . esc_html( $language['name'] ) . '</label><br>';
		echo '<select name="ww_link[' . esc_attr( $code ) . ']" id="' . esc_attr( $field ) . '" style="max-width:100%">';
		echo '<option value="0">' . esc_html__( '— Geen vertaling —', 'webwerckt-base' ) . '</option>';
		foreach ( _ww_languages_link_candidates( $post->post_type, $code, $post->ID ) as $candidate ) {
			$title = get_the_title( $candidate );
			printf( '<option value="%1$d">%2$s</option>', (int) $candidate->ID, esc_html( '' !== $title ? $title : '#' . $candidate->ID ) );
		}
		echo '</select>';
		if ( in_array( $code, _ww_extra_language_codes(), true ) && _ww_translation_can_create( $post->ID ) ) {
			$url = add_query_arg(
				array(
					'action'  => 'ww_create_translation',
					'post_id' => $post->ID,
					'lang'    => $code,
				),
				admin_url( 'admin-post.php' )
			);
			echo '<br><a class="button button-small" style="margin-top:4px" href="' . esc_url( wp_nonce_url( $url, 'ww_create_translation_' . $post->ID ) ) . '">' . esc_html__( 'Vertaling maken', 'webwerckt-base' ) . '</a>';
		}
		echo '</p>';
	}

	if ( count( $group ) > 1 ) {
		echo '<p><label><input type="checkbox" name="ww_unlink" value="1"> ' . esc_html__( 'Uit deze vertaalgroep halen', 'webwerckt-base' ) . '</label></p>';
	}
}

/**
 * Sleutel van de transient met de meldingen van de metabox, per bericht en gebruiker.
 *
 * @param int $post_id Bericht.
 */
function _ww_languages_metabox_notice_key( int $post_id ): string {
	return 'ww_language_box_' . $post_id . '_' . get_current_user_id();
}

/**
 * Slaat de metabox op (save_post, prioriteit 20): eerst de taal, dan ontkoppelen of koppelen. Een weigering komt als
 * melding op het bewerkscherm (transient, één keer getoond).
 *
 * @param int|string $post_id Bericht.
 * @param mixed      $post    Het bericht.
 */
function _ww_languages_metabox_save( $post_id, $post = null ): void {
	$post_id = (int) $post_id;
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
		return;
	}
	$nonce = isset( $_POST['ww_language_box_nonce'] ) && is_string( $_POST['ww_language_box_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['ww_language_box_nonce'] ) ) : '';
	// Alleen het bericht uit het formulier: een bericht dat tijdens dezelfde opslag wordt aangemaakt, blijft buiten schot.
	$form_id = isset( $_POST['post_ID'] ) ? absint( _ww_data_to_string( wp_unslash( $_POST['post_ID'] ) ) ) : 0;
	if ( '' === $nonce || ! wp_verify_nonce( $nonce, 'ww_language_box' ) || $form_id !== $post_id ) {
		return;
	}
	$type = get_post_type( $post_id );
	if ( ! current_user_can( 'manage_options' ) || ! current_user_can( 'edit_post', $post_id ) || false === $type || ! _ww_is_translatable( $type ) ) {
		return;
	}

	$errors = array();
	$lang   = isset( $_POST['ww_lang'] ) && is_string( $_POST['ww_lang'] ) ? sanitize_key( wp_unslash( $_POST['ww_lang'] ) ) : '';
	if ( '' !== $lang && $lang !== _ww_post_language( $post_id ) ) {
		$result = _ww_set_post_language( $post_id, $lang );
		if ( $result instanceof WP_Error ) {
			$errors[] = $result->get_error_message();
		}
	}

	if ( ! empty( $_POST['ww_unlink'] ) ) {
		_ww_unlink_translation( $post_id );
	} else {
		$links = isset( $_POST['ww_link'] ) && is_array( $_POST['ww_link'] ) ? wp_unslash( $_POST['ww_link'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- elke waarde wordt hieronder een int en gecontroleerd.
		foreach ( $links as $code => $other ) {
			$other = absint( _ww_data_to_string( $other ) );
			if ( $other <= 0 || $other === $post_id ) {
				continue;
			}
			if ( get_post_type( $other ) !== $type || _ww_post_language( $other ) !== (string) $code || ! current_user_can( 'edit_post', $other ) ) {
				$errors[] = __( 'Deze vertaling kan niet worden gekoppeld: ze is van een ander soort of in een andere taal.', 'webwerckt-base' );
				continue;
			}
			$result = _ww_link_translation( $post_id, $other );
			if ( $result instanceof WP_Error ) {
				$errors[] = $result->get_error_message();
			}
		}
	}

	$key = _ww_languages_metabox_notice_key( $post_id );
	if ( array() !== $errors ) {
		set_transient( $key, $errors, 60 );
	} else {
		delete_transient( $key );
	}
}

/**
 * Toont de weigeringen van de laatste opslag één keer op het bewerkscherm van dat bericht.
 */
function _ww_languages_metabox_notice(): void {
	$screen = get_current_screen();
	$post   = get_post();
	if ( ! $screen instanceof WP_Screen || 'post' !== $screen->base || ! $post instanceof WP_Post ) {
		return;
	}
	$key    = _ww_languages_metabox_notice_key( $post->ID );
	$errors = get_transient( $key );
	if ( ! is_array( $errors ) ) {
		return;
	}
	delete_transient( $key );
	foreach ( $errors as $error ) {
		_ww_languages_admin_notice( 'error', _ww_data_to_string( $error ) );
	}
}

/**
 * De knop Vertaling maken uit de metabox (admin-post.php?action=ww_create_translation, met post_id, lang en de nonce
 * ww_create_translation_{post_id}). Maakt het concept en gaat naar Visueel bewerken of het bewerkscherm van de vertaling.
 * Bij een fout terug naar het bewerkscherm van de bron, met de melding via de metabox-melding. De lijst `dropped` wordt
 * hier niet getoond: het oude bewerkscherm heeft er geen plek voor.
 */
function _ww_languages_create_translation_handle(): void {
	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- de nonce wordt hieronder gecontroleerd.
	$post_id = isset( $_REQUEST['post_id'] ) ? absint( _ww_data_to_string( wp_unslash( $_REQUEST['post_id'] ) ) ) : 0;
	$lang    = isset( $_REQUEST['lang'] ) && is_string( $_REQUEST['lang'] ) ? sanitize_key( wp_unslash( $_REQUEST['lang'] ) ) : '';
	// phpcs:enable WordPress.Security.NonceVerification.Recommended
	check_admin_referer( 'ww_create_translation_' . $post_id );
	if ( $post_id <= 0 || ! _ww_translation_can_create( $post_id ) ) {
		wp_die( esc_html__( 'Je hebt geen rechten om een vertaling van deze inhoud te maken.', 'webwerckt-base' ), 403 );
	}

	$result = _ww_translation_create( $post_id, $lang );
	if ( $result instanceof WP_Error ) {
		set_transient( _ww_languages_metabox_notice_key( $post_id ), array( $result->get_error_message() ), 60 );
		$back = get_edit_post_link( $post_id, 'raw' );
		wp_safe_redirect( is_string( $back ) && '' !== $back ? $back : admin_url() );
		exit;
	}

	wp_safe_redirect( $result['edit_url'] );
	exit;
}

/**
 * Een nieuw bericht (post-new.php) krijgt de taal van ?ww_lang= zodra WordPress het concept aanmaakt. Zo kent ook de
 * slug zijn taal al. Zonder ww_lang blijft het zonder term: het hoort bij de standaardtaal.
 *
 * @param int|string $post_id Bericht.
 * @param mixed      $post    Het bericht.
 */
function _ww_languages_new_post_language( $post_id, $post = null ): void {
	global $pagenow;
	if ( 'post-new.php' !== $pagenow || ! $post instanceof WP_Post || 'auto-draft' !== $post->post_status || ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$lang = _ww_languages_requested_new_language();
	if ( '' !== $lang && _ww_is_translatable( $post->post_type ) ) {
		_ww_set_post_language( (int) $post_id, $lang );
	}
}

/*
 * Kolom en filter in de berichtenlijst.
 */

/**
 * Het post type van de lijst die nu getoond wordt.
 */
function _ww_languages_list_post_type(): string {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	return $screen instanceof WP_Screen && '' !== $screen->post_type ? $screen->post_type : 'post';
}

/**
 * Filter manage_posts_columns en manage_pages_columns: de kolom Taal na de titel, bij een vertaalbaar post type.
 *
 * @param mixed $columns   Kolommen.
 * @param mixed $post_type Post type (manage_posts_columns geeft het mee; manage_pages_columns niet).
 * @return mixed
 */
function _ww_languages_add_column( $columns, $post_type = '' ) {
	$post_type = is_string( $post_type ) && '' !== $post_type ? $post_type : _ww_languages_list_post_type();
	if ( ! is_array( $columns ) || ! _ww_is_translatable( $post_type ) ) {
		return $columns;
	}
	$out = array();
	foreach ( $columns as $key => $label ) {
		$out[ $key ] = $label;
		if ( 'title' === $key ) {
			$out['ww_language'] = __( 'Taal', 'webwerckt-base' );
		}
	}
	if ( ! isset( $out['ww_language'] ) ) {
		$out['ww_language'] = __( 'Taal', 'webwerckt-base' );
	}
	return $out;
}

/**
 * De kolom Taal: de eigen code vet, en de codes van de gekoppelde vertalingen als link.
 *
 * @param mixed $column  Kolom.
 * @param mixed $post_id Bericht.
 */
function _ww_languages_render_column( $column, $post_id ): void {
	$post_id = (int) $post_id;
	if ( 'ww_language' !== $column || '' === _ww_post_language( $post_id ) ) {
		return;
	}
	$own   = _ww_post_language( $post_id );
	$parts = array( '<strong>' . esc_html( $own ) . '</strong>' );
	foreach ( _ww_translations( $post_id ) as $code => $id ) {
		if ( $code === $own || $id <= 0 ) {
			continue;
		}
		$link    = current_user_can( 'edit_post', $id ) ? get_edit_post_link( $id ) : '';
		$parts[] = is_string( $link ) && '' !== $link ? '<a href="' . esc_url( $link ) . '">' . esc_html( $code ) . '</a>' : esc_html( $code );
	}
	echo implode( ' ', $parts ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- elk deel is hierboven geëscapet.
}

/**
 * De keuzelijst Taal boven de berichtenlijst van een vertaalbaar post type.
 *
 * @param mixed $post_type Post type.
 */
function _ww_languages_list_filter( $post_type ): void {
	if ( ! is_string( $post_type ) || ! _ww_is_translatable( $post_type ) ) {
		return;
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen een filter kiezen.
	$chosen = isset( $_GET['ww_lang'] ) && is_string( $_GET['ww_lang'] ) ? sanitize_key( wp_unslash( $_GET['ww_lang'] ) ) : '';

	echo '<label class="screen-reader-text" for="ww-lang-filter">' . esc_html__( 'Filter op taal', 'webwerckt-base' ) . '</label>';
	echo '<select name="ww_lang" id="ww-lang-filter">';
	echo '<option value="">' . esc_html__( 'Alle talen', 'webwerckt-base' ) . '</option>';
	foreach ( _ww_languages_config()['languages'] as $language ) {
		printf( '<option value="%1$s"%2$s>%3$s</option>', esc_attr( $language['code'] ), selected( $language['code'], $chosen, false ), esc_html( $language['name'] ) );
	}
	echo '</select>';
}

/**
 * Filter query_vars: ww_lang is in de admin een publieke query var, zodat edit.php hem aan de query doorgeeft. Het
 * query-filter (_ww_languages_pre_get_posts()) filtert de admin alleen daarmee.
 *
 * @param mixed $vars Publieke query vars.
 * @return mixed
 */
function _ww_languages_query_vars( $vars ) {
	if ( is_array( $vars ) && is_admin() ) {
		$vars[] = 'ww_lang';
	}
	return $vars;
}

/**
 * Hangt de hooks van dit onderdeel op. Draait ook na init (zie _ww_languages_boot()). Post types en rechten worden in
 * de callbacks gecontroleerd: bij het booten zijn de post types van het thema nog niet geregistreerd.
 */
function _ww_languages_boot_admin(): void {
	add_action( 'admin_menu', '_ww_languages_admin_menu' );
	add_action( 'admin_init', '_ww_languages_admin_handle' );
	add_action( 'add_meta_boxes', '_ww_languages_add_metabox' );
	add_action( 'admin_post_ww_create_translation', '_ww_languages_create_translation_handle' );
	add_action( 'save_post', '_ww_languages_new_post_language', 10, 2 );
	add_action( 'save_post', '_ww_languages_metabox_save', 20, 2 );
	add_action( 'admin_notices', '_ww_languages_metabox_notice' );
	add_filter( 'manage_posts_columns', '_ww_languages_add_column', 10, 2 );
	add_filter( 'manage_pages_columns', '_ww_languages_add_column' );
	add_action( 'manage_posts_custom_column', '_ww_languages_render_column', 10, 2 );
	add_action( 'manage_pages_custom_column', '_ww_languages_render_column', 10, 2 );
	add_action( 'restrict_manage_posts', '_ww_languages_list_filter' );
	add_filter( 'query_vars', '_ww_languages_query_vars' );
}
