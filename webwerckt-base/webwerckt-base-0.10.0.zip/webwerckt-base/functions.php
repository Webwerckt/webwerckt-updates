<?php
/**
 * Parent-thema webwerckt-base: laadt de onderdelen uit inc/.
 *
 * Bij een child-thema draait diens functions.php eerst, daarna deze.
 * De volgorde hieronder doet er niet toe: onderdelen die op elkaar wachten, doen dat met de prioriteit van hun hook.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WW_BASE_SLUG', 'webwerckt-base' );
define( 'WW_BASE_VERSION', wp_get_theme( WW_BASE_SLUG )->get( 'Version' ) ?: '0.0.0' );
define( 'WW_BASE_DIR', get_template_directory() );

foreach ( [
	'util',
	'i18n',
	'data',
	'helpers',
	'sections',
	'post-types',
	'loop',
	'terms',
	'filter',
	'menu',
	'rest',
	'revisions',
	'content',
	'admin',
	'lifecycle',
	'updater',
	'cleanup',
	'integrations/pods',
	'integrations/litespeed',
	'integrations/multilingual',
] as $ww_file ) {
	require_once WW_BASE_DIR . '/inc/' . $ww_file . '.php';
}
unset( $ww_file );
