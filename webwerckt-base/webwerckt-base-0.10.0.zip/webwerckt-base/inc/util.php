<?php
/**
 * Kleine gedeelde hulpfuncties voor de andere onderdelen van de parent.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Hoofdquery van WordPress, of null buiten een request.
 */
function _ww_main_query(): ?WP_Query {
	$query = $GLOBALS['wp_query'] ?? null;
	return $query instanceof WP_Query ? $query : null;
}

/**
 * Is dit een webverzoek van een bezoeker die niet is ingelogd, buiten de admin en de REST API? Voor zo'n verzoek
 * hoeft WordPress niets te registreren dat alleen bij bewerken nodig is. Betrouwbaar vanaf init: dan is de gebruiker bekend.
 * De REST API telt nooit als bezoeker: een applicatiewachtwoord logt pas na init in.
 *
 * @param string $sapi Server-API van PHP; WP-CLI, cron via de commandoregel en de tests zijn nooit een bezoeker.
 */
function _ww_is_visitor_request( string $sapi = PHP_SAPI ): bool {
	if ( 'cli' === $sapi || is_admin() || wp_doing_ajax() || wp_doing_cron() || is_user_logged_in() ) {
		return false;
	}
	if ( ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) || isset( $_GET['rest_route'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return false;
	}
	$path = (string) wp_parse_url( _ww_data_to_string( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	return ! str_contains( $path . '/', '/' . trim( rest_get_url_prefix(), '/' ) . '/' );
}

/**
 * Laadt de uitgelichte afbeeldingen van een lijst berichten in één query, met hun meta (afmetingen, alt-tekst).
 * WordPress doet dat alleen in een lus met the_post(); kaarten gebruiken setup_postdata(), dus zonder dit kost
 * elke kaart met een afbeelding twee eigen query's.
 *
 * @param int[] $post_ids Bericht-ID's.
 */
function _ww_prime_thumbnails( array $post_ids ): void {
	if ( array() === $post_ids ) {
		return;
	}
	// Meestal al geladen door WP_Query of _prime_post_caches(); dan doet dit niets.
	update_meta_cache( 'post', $post_ids );
	$thumbnails = array_filter( array_map( static fn( int $id ): int => (int) get_post_thumbnail_id( $id ), $post_ids ) );
	_prime_post_caches( array_values( array_unique( $thumbnails ) ), false );
}

/**
 * data-ww-attributen, ge-escaped.
 *
 * @param array<string,string> $attrs Naam zonder 'data-ww-' => waarde.
 */
function _ww_html_attrs( array $attrs ): string {
	$out = array();
	foreach ( $attrs as $name => $value ) {
		$out[] = sprintf( 'data-ww-%s="%s"', sanitize_key( $name ), esc_attr( $value ) );
	}
	return implode( ' ', $out );
}

/**
 * Laadt een script uit assets/js/ als ES-module, met de gedeelde module 'ww-rest' als afhankelijkheid.
 *
 * @param string $name Bestandsnaam zonder .js, bijvoorbeeld 'load-more'.
 */
function _ww_enqueue_module( string $name ): void {
	$base = get_template_directory_uri() . '/assets/js/';
	wp_register_script_module( 'ww-rest', $base . 'rest.js', array(), WW_BASE_VERSION );
	wp_enqueue_script_module( 'ww-' . $name, $base . $name . '.js', array( 'ww-rest' ), WW_BASE_VERSION );
}

/**
 * Meldt (met WP_DEBUG aan) dat een registratie te laat komt: na $hook heeft hij geen effect meer.
 * Zonder deze melding doet zo'n aanroep stil niets. Registraties uit het child-thema horen in after_setup_theme.
 *
 * @param string $function Naam van de publieke functie.
 * @param string $hook     Hook waarna de registratie niet meer meetelt.
 */
function _ww_warn_if_too_late( string $function, string $hook ): void {
	if ( did_action( $hook ) ) {
		_doing_it_wrong(
			esc_html( $function ),
			esc_html( sprintf( 'Roep %1$s() aan in de hook after_setup_theme; na %2$s heeft de registratie geen effect meer.', $function, $hook ) ),
			'0.2.0'
		);
	}
}
