<?php
/**
 * Pods-configuratie als JSON-bestanden in de thema's (invoerlaag in de admin; de frontend leest via inc/data.php).
 *
 * Elk bestand beschrijft één pod met zijn groepen en velden. De parent levert de Site-instellingen,
 * de tekstpagina, de blogberichten en de velden van de gekozen standaard post types; het child-thema zet zijn eigen
 * bestanden in pods/. Pods leest zelf alleen pods.json, en een tweede bestand voor dezelfde pod vervangt
 * daar de eerste. Daarom voegt de parent alle bestanden per pod samen en registreert hij ze zelf;
 * het child-thema kan daarbij alleen aanvullen (_ww_pods_merge()).
 *
 * Alle groepen en velden uit het child-thema beginnen met `child_` (_ww_child_prefix()); andere slaat de parent over.
 *
 * Veldgroepen met een naam `template_{naam}` (in het child-thema `child_template_{naam}`) verschijnen alleen
 * bij dat paginatemplate: `child_template_home` bij page-home.php, `template_default` bij het standaardtemplate.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Is dit een bestandsnaam die Pods zelf inleest (pods.json, pods-groups.json)? Die slaat de parent over.
 */
function _ww_pods_is_reserved_file( string $file ): bool {
	return 1 === preg_match( '/^pods(-[a-z]+)?\.(json|yml)$/', basename( $file ) );
}

/**
 * Configuratiebestanden in laadvolgorde: eerst de parent, dan het child-thema.
 *
 * @return string[]
 */
function _ww_pods_config_files(): array {
	$parent = get_template_directory() . '/pods/';
	$files  = array( $parent . 'settings.json', $parent . 'page.json', $parent . 'post.json' );
	foreach ( _ww_used_post_types() as $post_type ) {
		$files[] = $parent . $post_type . '.json';
	}

	if ( get_stylesheet_directory() !== get_template_directory() ) {
		$files = array_merge( $files, glob( get_stylesheet_directory() . '/pods/*.json' ) ?: array() );
	}

	return array_values(
		array_filter(
			$files,
			static fn( string $file ): bool => is_readable( $file ) && ! _ww_pods_is_reserved_file( $file )
		)
	);
}

/**
 * Voegt pod-configuraties samen per type en naam. Een later bestand vult alleen aan, het vervangt nooit:
 *
 * - instellingen van de pod (zoals het label) die er al zijn, blijven staan; nieuwe komen erbij;
 * - een groep met een naam die de pod al heeft, wordt overgeslagen;
 * - een veld met een naam die de pod al heeft (in welke groep ook), wordt overgeslagen.
 *
 * Omdat de parent eerst laadt, kan het child-thema zo geen velden of groepen van de parent vervangen,
 * alleen een eigen groep (een extra box) toevoegen. Velden staan altijd in een groep.
 *
 * @param array<int|string,mixed> $configs Gedecodeerde bestanden, met het bestandspad als sleutel.
 * @return array<int,array<string,mixed>>
 */
function _ww_pods_merge( array $configs ): array {
	$pods = array();
	foreach ( $configs as $source => $config ) {
		$type = is_array( $config ) ? _ww_data_to_string( $config['type'] ?? '' ) : '';
		$name = is_array( $config ) ? _ww_data_to_string( $config['name'] ?? '' ) : '';
		if ( '' === $type || '' === $name ) {
			continue;
		}

		$key    = $type . ':' . $name;
		$groups = is_array( $config['groups'] ?? null ) ? $config['groups'] : array();
		if ( isset( $config['fields'] ) ) {
			_ww_pods_skipped( (string) $source, 'velden staan altijd in een groep; losse velden van pod ' . $name . ' zijn overgeslagen' );
		}
		unset( $config['groups'], $config['fields'] );

		$pods[ $key ] = ( $pods[ $key ] ?? array( 'groups' => array() ) ) + $config;
		foreach ( array_filter( $groups, 'is_array' ) as $group ) {
			$group = _ww_pods_new_group( $pods[ $key ], $group, (string) $source );
			if ( null !== $group ) {
				$pods[ $key ]['groups'][] = $group;
			}
		}
	}
	return array_values( $pods );
}

/**
 * De groep zonder velden die de pod al heeft, of null als de pod de groep al heeft (of hij geen naam heeft).
 *
 * @param array<string,mixed> $pod    Pod tot nu toe.
 * @param array<string,mixed> $group  Nieuwe groep.
 * @param string              $source Bestand, voor de melding.
 * @return array<string,mixed>|null
 */
function _ww_pods_new_group( array $pod, array $group, string $source ): ?array {
	$name = _ww_data_to_string( $group['name'] ?? '' );
	if ( '' === $name ) {
		return null;
	}
	if ( in_array( $name, array_column( $pod['groups'], 'name' ), true ) ) {
		_ww_pods_skipped( $source, sprintf( 'groep %s bestaat al in pod %s', $name, $pod['name'] ) );
		return null;
	}

	$taken  = _ww_pods_field_names( $pod );
	$fields = array();
	foreach ( is_array( $group['fields'] ?? null ) ? array_filter( $group['fields'], 'is_array' ) : array() as $field ) {
		$field_name = _ww_data_to_string( $field['name'] ?? '' );
		if ( in_array( $field_name, $taken, true ) ) {
			_ww_pods_skipped( $source, sprintf( 'veld %s bestaat al in pod %s', $field_name, $pod['name'] ) );
			continue;
		}
		$taken[]  = $field_name;
		$fields[] = $field;
	}

	$group['fields'] = $fields;
	return $group;
}

/**
 * Namen van alle velden in de groepen van een pod.
 *
 * @param array<string,mixed> $pod
 * @return string[]
 */
function _ww_pods_field_names( array $pod ): array {
	$names = array();
	foreach ( $pod['groups'] as $group ) {
		foreach ( $group['fields'] as $field ) {
			$names[] = _ww_data_to_string( $field['name'] ?? '' );
		}
	}
	return $names;
}

/**
 * Meldt (met WP_DEBUG aan) dat een deel van een configuratiebestand is overgeslagen.
 */
function _ww_pods_skipped( string $source, string $reason ): void {
	_doing_it_wrong(
		'_ww_pods_merge',
		esc_html( sprintf( 'Pods-configuratie %s: %s. Een later bestand kan alleen aanvullen, niet vervangen.', basename( $source ), $reason ) ),
		'0.1.0'
	);
}

/**
 * Begint deze naam met het child-voorvoegsel?
 */
function _ww_has_child_prefix( string $name ): bool {
	return str_starts_with( $name, _ww_child_prefix() ) && strlen( $name ) > strlen( _ww_child_prefix() );
}

/**
 * Configuratie uit het child-thema zonder groepen en velden die niet met `child_` beginnen.
 *
 * @param mixed  $config Gedecodeerd bestand.
 * @param string $source Bestand, voor de melding.
 * @return mixed
 */
function _ww_pods_child_config( $config, string $source ) {
	if ( ! is_array( $config ) || ! is_array( $config['groups'] ?? null ) ) {
		return $config;
	}

	$groups = array();
	foreach ( array_filter( $config['groups'], 'is_array' ) as $group ) {
		$name = _ww_data_to_string( $group['name'] ?? '' );
		if ( ! _ww_has_child_prefix( $name ) ) {
			_ww_pods_skipped( $source, sprintf( 'groep %s begint niet met %s', $name, _ww_child_prefix() ) );
			continue;
		}

		$fields = array();
		foreach ( is_array( $group['fields'] ?? null ) ? array_filter( $group['fields'], 'is_array' ) : array() as $field ) {
			$field_name = _ww_data_to_string( $field['name'] ?? '' );
			if ( _ww_has_child_prefix( $field_name ) ) {
				$fields[] = $field;
			} else {
				_ww_pods_skipped( $source, sprintf( 'veld %s begint niet met %s', $field_name, _ww_child_prefix() ) );
			}
		}
		$group['fields'] = $fields;
		$groups[]        = $group;
	}

	$config['groups'] = $groups;
	return $config;
}

/**
 * Alle pods uit de configuratiebestanden, samengevoegd. Bestanden van het child-thema houden alleen
 * groepen en velden met het child-voorvoegsel.
 *
 * @return array<int,array<string,mixed>>
 */
function _ww_pods_config(): array {
	// Eén keer per request inlezen; de lijst met bestanden is de sleutel, want die verandert met de gekozen post types.
	static $cache = array();

	$files = _ww_pods_config_files();
	$key   = implode( '|', $files );
	if ( isset( $cache[ $key ] ) ) {
		return $cache[ $key ];
	}

	$child   = get_stylesheet_directory() !== get_template_directory() ? trailingslashit( get_stylesheet_directory() ) : '';
	$configs = array();
	foreach ( $files as $file ) {
		$config           = json_decode( (string) file_get_contents( $file ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- lokaal themabestand.
		$configs[ $file ] = '' !== $child && str_starts_with( $file, $child ) ? _ww_pods_child_config( $config, $file ) : $config;
	}
	$cache[ $key ] = _ww_pods_merge( $configs );
	return $cache[ $key ];
}

/**
 * Registreert de pods bij Pods. Zonder Pods gebeurt er niets; de frontend heeft Pods niet nodig.
 */
function _ww_pods_register(): void {
	if ( ! function_exists( 'pods_register_type' ) ) {
		return;
	}
	foreach ( _ww_pods_config() as $pod ) {
		pods_register_type( $pod['type'], $pod['name'], $pod );
	}
}
// Na de standaard post types (prioriteit 5) en vóór Pods op prioriteit 11 zijn lijst met instellingen-pods
// en content types opbouwt.
add_action( 'init', '_ww_pods_register', 10 );

/**
 * Naam van de veldgroep voor het paginatemplate van een bericht: page-home.php wordt `template_home`,
 * het standaardtemplate (ook bij een nieuw bericht) `template_default`.
 */
function _ww_template_group_name( int $post_id ): string {
	$file = $post_id > 0 ? (string) get_page_template_slug( $post_id ) : '';
	$slug = '' === $file ? 'default' : (string) preg_replace( '/^page-/', '', basename( $file, '.php' ) );
	return 'template_' . sanitize_key( $slug );
}

/**
 * Toont van de template-groepen alleen die van het gekozen template. Andere groepen blijven staan.
 *
 * Pods bewaart alleen velden uit de getoonde groepen. Wie het template wijzigt, slaat eerst op en vult daarna de nieuwe velden.
 *
 * @param mixed           $groups Groepen van Pods (arrays of objecten met ArrayAccess).
 * @param string          $type   Pod-type.
 * @param string          $name   Podnaam.
 * @param int|string|null $id     Bericht-ID.
 * @return mixed
 */
function _ww_pods_template_groups( $groups, $type, $name, $id ) {
	if ( 'post_type' !== $type || ! is_array( $groups ) ) {
		return $groups;
	}

	// Pods geeft bij het maken van de metaboxen geen ID mee; op het bewerkscherm is het bericht dan het globale $post.
	$current = _ww_template_group_name( (int) $id ?: (int) get_the_ID() );
	return array_filter(
		$groups,
		static function ( $group ) use ( $current ): bool {
			// Groepen uit het child-thema heten child_template_{naam}.
			$template = (string) preg_replace( '/^' . preg_quote( _ww_child_prefix(), '/' ) . '/', '', (string) ( $group['name'] ?? '' ) );
			return ! str_starts_with( $template, 'template_' ) || $current === $template;
		}
	);
}
add_filter( 'pods_meta_groups_get', '_ww_pods_template_groups', 10, 4 );

/**
 * Velden van een post type uit de configuratiebestanden, in de volgorde van de bestanden. De bestanden zijn
 * de bron, dus dit werkt ook zonder actieve Pods. Met een bericht-ID alleen de velden die bij dat bericht
 * op het scherm staan: van de template-groepen alleen die van zijn paginatemplate.
 *
 * @param int $post_id Bericht-ID; 0 geeft de velden van alle groepen.
 * @return array<int,array<string,mixed>>
 */
function _ww_pods_fields( string $post_type, int $post_id = 0 ): array {
	$fields = array();
	foreach ( _ww_pods_config() as $pod ) {
		if ( 'post_type' !== ( $pod['type'] ?? '' ) || $post_type !== ( $pod['name'] ?? '' ) ) {
			continue;
		}
		$groups = $post_id > 0 ? _ww_pods_template_groups( $pod['groups'], 'post_type', $post_type, $post_id ) : $pod['groups'];
		foreach ( $groups as $group ) {
			array_push( $fields, ...$group['fields'] );
		}
	}
	return $fields;
}

/**
 * Velden van de Site-instellingen uit de configuratiebestanden, ook zonder actieve Pods.
 *
 * @return array<int,array<string,mixed>>
 */
function _ww_pods_setting_fields(): array {
	$fields = array();
	foreach ( _ww_pods_config() as $pod ) {
		if ( 'settings' !== ( $pod['type'] ?? '' ) ) {
			continue;
		}
		foreach ( $pod['groups'] as $group ) {
			array_push( $fields, ...$group['fields'] );
		}
	}
	return $fields;
}

/**
 * De klant die pagina's van anderen bewerkt (Redacteur) bewerkt de Site-instellingen. Pods schermt een
 * instellingenpagina af met pods_edit_{pod}; dat recht krijgt hij alleen voor de instellingen-pods uit de
 * configuratiebestanden. Andere pods en het beheer van Pods zelf blijven bij de beheerder.
 *
 * @param array<string,bool> $allcaps Rechten van de gebruiker.
 * @param string[]           $caps    Gevraagde basisrechten.
 * @param mixed[]            $args    Het gevraagde recht en eventuele argumenten.
 * @return array<string,bool>
 */
function _ww_pods_grant_settings_cap( array $allcaps, array $caps, array $args ): array {
	$cap = _ww_data_to_string( $args[0] ?? '' );
	if ( ! str_starts_with( $cap, 'pods_edit_' ) || ! _ww_is_client_editor( $allcaps ) ) {
		return $allcaps;
	}
	foreach ( _ww_pods_config() as $pod ) {
		if ( 'settings' === ( $pod['type'] ?? '' ) && 'pods_edit_' . $pod['name'] === $cap ) {
			$allcaps[ $cap ] = true;
		}
	}
	return $allcaps;
}
add_filter( 'user_has_cap', '_ww_pods_grant_settings_cap', 10, 3 );

/**
 * Veldnamen van een post type die in revisies passen (enkelvoudige waarden).
 *
 * @return string[]
 */
function _ww_pods_revision_fields( string $post_type ): array {
	$simple = array( 'text', 'paragraph', 'wysiwyg', 'code', 'number', 'currency', 'date', 'datetime', 'time', 'boolean', 'color', 'website', 'email', 'phone' );
	$names  = array();
	foreach ( _ww_pods_fields( $post_type ) as $field ) {
		$type = _ww_data_to_string( $field['type'] ?? '' );
		if ( in_array( $type, $simple, true ) || ( 'file' === $type && 'single' === ( $field['file_format_type'] ?? 'single' ) ) ) {
			$names[] = _ww_data_to_string( $field['name'] ?? '' );
		}
	}
	return array_values( array_filter( $names ) );
}

/**
 * Adminmelding als Pods ontbreekt: de site toont zijn velden nog, maar ze zijn niet te bewerken.
 */
function _ww_pods_missing_notice(): void {
	if ( function_exists( 'pods' ) || ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	printf(
		'<div class="notice notice-error"><p>%s</p></div>',
		esc_html__( 'Webwerckt Base: de plugin Pods is niet actief. Velden zijn niet te bewerken totdat Pods is geïnstalleerd en geactiveerd.', 'webwerckt-base' )
	);
}
add_action( 'admin_notices', '_ww_pods_missing_notice' );

/**
 * Zet de mu-plugin die Pods op de frontend overslaat in wp-content/mu-plugins, en ververst hem als het thema
 * een andere versie meebrengt. Een thema laadt pas na de plugins en kan Pods dus niet zelf tegenhouden.
 * Zonder schrijfrechten (of als bestandswijzigingen uit staan) blijft alles werken, alleen laadt Pods dan ook voor bezoekers.
 *
 * @param string $dir Map van de mu-plugins.
 */
function _ww_install_mu_plugin( string $dir = WPMU_PLUGIN_DIR ): void {
	$source = WW_BASE_DIR . '/mu-plugins/webwerckt-base-frontend.php';
	$target = trailingslashit( $dir ) . 'webwerckt-base-frontend.php';
	if ( ( is_readable( $target ) && md5_file( $target ) === md5_file( $source ) ) || ! wp_is_file_mod_allowed( 'ww_mu_plugin' ) ) {
		return;
	}
	if ( wp_mkdir_p( $dir ) ) {
		// phpcs:ignore WordPress.PHP.NoSilencedErrors -- een map zonder schrijfrechten is geen fout, alleen een gemiste optimalisatie.
		@copy( $source, $target );
	}
}
add_action( 'admin_init', '_ww_install_mu_plugin' );
