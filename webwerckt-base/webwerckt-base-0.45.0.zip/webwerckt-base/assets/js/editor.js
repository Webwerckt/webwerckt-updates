// Visueel bewerken: het vaste zijpaneel links van de pagina in het iframe (ADR 0019).
// De pagina (editor-frame.js) meldt welk element is aangeklikt; dit script toont de velden ervan in het midden van het
// paneel, laat wijzigingen direct in de pagina zien en slaat ze in één keer op via ww/v1/editor/{id}. Na het opslaan
// laadt de pagina opnieuw, zodat PHP alles weer zelf rendert. Opslaan en de status van de wijzigingen staan in de voet
// van het paneel (renderFooter()), meldingen onderaan.
// Het midden toont één weergave per niveau (viewKind()): zonder keuze Op deze pagina met de secties van de pagina,
// anders een kruimelregel met terugknop en daaronder een veld, een sectie (schakelaar, de velden in de pagina als links
// en de velden die nergens gemarkeerd zijn), een lijst met kaarten (zijn relatieveld, of bij een automatische lijst
// uitleg en een link naar de berichten), de Pagina- of Site-instellingen (settings) of één veldgroep. Een groep toont
// eerst zijn velden die in de pagina staan, in de volgorde van de pagina, en daaronder de rest. Terug en Escape gaan
// één niveau terug (back()), met de focus op het item waarmee de weergave werd geopend. Velden
// uit de Site-instellingen (ww_setting_attrs(), en secties met bron settings) zijn groen en hebben de melding dat ze
// voor de hele site gelden. Onder de secties van Op deze pagina staan Deze pagina en Hele site, met per ingang de
// groepen die erachter zitten. De 404 en de zoekpagina hebben geen eigen bericht (data.view): daar zijn alleen
// Site-instellingen te bewerken en is er geen Deze pagina. De paginatitel opent een menu met alle pagina's
// (data.pages) en daaronder de 404 en de zoekpagina (data.views); een keuze opent de editor van die pagina, en bij
// wijzigingen die nog niet zijn opgeslagen waarschuwt de browser (beforeunload). Het vergrootglas en Ctrl+K / ⌘K
// openen het zoekvenster (editor-search.js) met secties, velden, groepen en, als je typt, andere pagina's; een
// resultaat kiezen zet het in beeld in de pagina (REVEAL) en opent zijn weergave, of opent die andere pagina.

import { MESSAGE } from 'ww-editor-protocol';
import { menuButton } from 'ww-editor-menu';
import { searchDialog, isSearchShortcut } from 'ww-editor-search';
import { INLINE_GROUPS, withoutPrefix, sectionOfGroup, pageSettingsGroups, PREVIEW_MARGIN, previewScale, groupSummary, zoomLabel } from 'ww-editor-layout';
import { changedFields, versionChanges } from 'ww-editor-changes';

const root = document.querySelector('[data-ww-editor]');
const data = JSON.parse(document.getElementById('ww-editor-data').textContent);
const { strings, fields } = data;
const frame = root.querySelector('[data-ww-editor-frame]');
const canvas = root.querySelector('[data-ww-editor-canvas]');
const panel = root.querySelector('[data-ww-editor-panel]');
const body = root.querySelector('[data-ww-editor-body]');
// De kruimelregel boven de weergave (terugknop en titel); leeg en verborgen op Op deze pagina.
const crumbBox = root.querySelector('[data-ww-editor-crumb]');
const fieldsBox = root.querySelector('[data-ww-editor-fields]');
// Deze pagina en Hele site (in Op deze pagina) en Versies (in de voet).
const settingsLinks = [...root.querySelectorAll('[data-ww-editor-open]')];
// Het blok met Deze pagina en Hele site; navContent() zet het onder de secties.
const scopesBox = root.querySelector('[data-ww-editor-settings]');
const statusBox = root.querySelector('[data-ww-editor-status]');
const statusLabel = root.querySelector('[data-ww-editor-status-label]');
const reviewButton = root.querySelector('[data-ww-editor-review]');
const actionsBox = root.querySelector('[data-ww-editor-actions]');
const viewLink = root.querySelector('[data-ww-editor-view]');
const viewLabel = root.querySelector('[data-ww-editor-view-label]');
const toastsBox = root.querySelector('[data-ww-editor-toasts]');
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
// Tot en met 782px (het breekpunt van de WordPress-admin) is het paneel de hele pagina en is het voorbeeld een aparte weergave.
const mobile = window.matchMedia('(max-width: 782px)');
const collapseButton = root.querySelector('[data-ww-editor-collapse]');
const expandButton = root.querySelector('[data-ww-editor-expand]');
// De vaste balk onderin de voorbeeldweergave op mobiel (Bewerken en opslaan); renderFooter() vult hem.
const mobileBar = document.createElement('div');
mobileBar.className = 'ww-editor__mobile-bar';
root.querySelector('.ww-editor__main').append(mobileBar);
// Het menu onder de paginatitel; de titel staat in een h1, de container direct daarna.
const pagesToggle = root.querySelector('[data-ww-editor-pages]');
const menus = [menuButton(pagesToggle, pagesToggle.parentElement.nextElementSibling, { items: pageItems, onPick: goTo, align: 'start' })];
// Het taalmenu naast de titel, alleen als Meertalig actief is en de pagina vertaalbaar (data.languages).
if (data.languages) {
	const languagesToggle = createLanguagesToggle(pagesToggle.parentElement.nextElementSibling);
	menus.push(menuButton(languagesToggle, languagesToggle.nextElementSibling, { items: languageItems, onPick: pickLanguage, align: 'start' }));
}
const searchButton = root.querySelector('[data-ww-editor-search]');
const search = searchDialog(root.querySelector('[data-ww-editor-search-dialog]'), { strings, entries: searchEntries, onPick: pick });

// Veldnaam => nieuwe waarde, alleen voor velden die afwijken van wat is opgeslagen.
const changes = new Map();
// Veldnaam => voorbeeld-URL van een net gekozen foto.
const previews = new Map();
// ID van het tekstvak => veldnaam, voor de WYSIWYG-editors die nu in het paneel staan.
const editors = new Map();
// Post-ID => bericht (titel, gepubliceerd) voor relatievelden, uit de velden en uit zoekresultaten.
const items = new Map();
let post = data.post;
// De velden van het aangeklikte element, of de gekozen sectie; zonder die twee toont het paneel de gekozen lijst of
// veldgroep, als die er is.
let selected = null;
let section = null;
// De gekozen lijst met kaarten als bron en naam, zodat hij na opslaan terug te vinden is, ook als de nummers
// veranderen.
let list = null;
// De veldgroep uit de lijst van de pagina- of site-instellingen: { source: 'page' | 'site', key }.
let group = null;
// Welke instellingen open zijn: 'page', 'site' of null. Met een groep is het de bron van die groep, zodat terug weet
// waar het heen moet.
let settings = null;
// Het veld dat na de volgende keer renderen de focus krijgt (select({ focus })), één keer.
let focusing = null;
// Het eerste veld krijgt de focus als de weergave via een klik in de pagina of het zoekvenster opent (select({ auto })),
// één keer: niet na opslaan of een nieuwe READY, want dan pakt het de focus af van het zoekvenster of een menu.
let autoFocus = false;
// Per niveau (DEPTH) waarmee de weergave van dat niveau werd geopend: { element, key }, of null als dat niet in het
// paneel was (een klik in de pagina). key vindt een item terug dat opnieuw is getekend (data-ww-view-item).
let returnFocus = [];
// Wat na een stap terug (back()) de focus krijgt, één keer; undefined als de laatste wissel geen stap terug was.
let returning;
// Of de pagina al een keer READY heeft gestuurd; tot dan zijn de secties niet bekend.
let readyOnce = false;
// Wat de pagina in het iframe meldt: welke velden er gemarkeerd zijn en welke secties er staan.
let marks = new Set();
let sections = [];
let lists = [];
let scrollY = 0;
// De schaal van het voorbeeld in het iframe (applyPreview()).
let currentScale = 1;
// De LOAD_ID van de laatst verwerkte READY (editor-frame.js): een READY met dezelfde id is een herhaling van dezelfde
// pagina (HELLO én het laden sturen er elk één) en wordt niet opnieuw verwerkt; een nieuwe pagina heeft een andere id.
let readyLoad = null;
let busy = false;
// De eerdere versies van de pagina: null = nog niet opgehaald, 'loading', 'error', of de lijst van de route. Na opslaan
// weer null, want dan is er een nieuwe versie bij.
let versionsState = null;
// Een gekozen versie wordt nog opgehaald.
let picking = false;
// Telt de ophaalrondes van de lijst, zodat een oudere ronde een nieuwere niet overschrijft.
let versionsRequest = 0;
// Wat het paneel nu toont (viewKey()), om te weten of het iets anders gaat tonen; alleen dan verhuist de focus.
let shown = JSON.stringify([null, null, null, null, null]);
// Wat de statusregel nu zegt; alleen een andere tekst wordt opnieuw geschreven (en voorgelezen). Begint met wat de
// server al rendert, zodat de eerste renderFooter() dezelfde tekst niet opnieuw schrijft.
let statusText = statusBox.textContent.trim();
if (!statusBox.dataset.wwState) {
	statusBox.dataset.wwState = 'clean';
}
let toastTimer;

// Titel en slug: velden van het bericht zelf, die opslaan apart meestuurt. Ze staan in de groep Algemeen.
const PAGE_FIELDS = ['post_title', 'post_name'];
// Velden van de Site-instellingen staan in fields met dit voorvoegsel, net als in data-ww-edit (ww_setting_attrs()).
const SITE = 'site:';
const INPUT_TYPES = { text: 'text', slug: 'text', email: 'email', phone: 'tel', number: 'number' };
// Wat je in een linkveld typt, telt meteen als link als het er een lijkt; anders zoekt het veld een pagina.
const LOOKS_LIKE_LINK = /^([a-z]+:|\/|#)|\./i;
// De parameter van de editormodus in de URL van het iframe (WW_EDITOR_PARAM in inc/editor.php).
const EDITOR_PARAM = 'ww-edit';
// Waarmee de melding over wat een nieuwe vertaling niet heeft overgenomen de volgende pagina bereikt (sessionStorage).
const DROPPED_KEY = 'ww-editor-dropped';
// Zoeken wacht tot je even niet typt, in milliseconden.
const SEARCH_DELAY = 250;
// Hoe lang een veld oplicht als het de focus krijgt vanuit het zoekvenster, in milliseconden.
const FLASH = 900;
// Wat in een veld de focus kan krijgen; niet het zoekveld van een relatie, dat klapt bij focus zijn resultaten uit.
// Een WYSIWYG-veld krijgt de focus van TinyMCE zelf (startEditor()).
const FOCUSABLE = 'input:not([type="search"]), textarea:not(.wp-editor-area), .ww-editor__image button, a.button';
// Het niveau van een weergave: terug gaat van een groep naar de instellingen en van de rest naar Op deze pagina.
const DEPTH = { nav: 0, field: 1, section: 1, list: 1, settings: 1, group: 2 };
const TOAST_ICONS = { success: 'yes-alt', error: 'warning', warning: 'lock', info: 'info-outline' };

// Roept fn pas aan als de functie een tijd niet is aangeroepen, met de argumenten van de laatste aanroep.
function debounce(fn, delay = SEARCH_DELAY) {
	let timer;
	return (...args) => {
		clearTimeout(timer);
		timer = setTimeout(() => fn(...args), delay);
	};
}

function send(payload) {
	frame.contentWindow?.postMessage(payload, data.origin);
}

// Stuurt de accentkleur en de schaal naar de pagina, die daarop met READY antwoordt. Aanroepen bij elke load van het
// iframe, en één keer meteen, voor het geval het iframe al klaar is: zo gaat READY niet verloren.
function hello() {
	// Het kleurenschema van de admin zet de variabele op body.admin-color-*, niet op :root.
	const accent = getComputedStyle(root).getPropertyValue('--wp-admin-theme-color').trim() || '#2271b1';
	send({ type: MESSAGE.HELLO, accent, scale: currentScale });
}

function valueOf(name) {
	return changes.has(name) ? changes.get(name) : fields[name].value;
}

// Gelijk, ook voor de lijst met ID's van een relatie.
function same(a, b) {
	return a === b || JSON.stringify(a) === JSON.stringify(b);
}

function remember(list) {
	list.forEach((item) => items.set(item.id, item));
}

function isSite(name) {
	return name.startsWith(SITE);
}

// Zet de velden van de Site-instellingen bij de velden van de pagina, met site: voor hun naam.
function addSettings(settings) {
	Object.entries(settings || {}).forEach(([name, field]) => (fields[SITE + name] = { ...field, site: true }));
}

/*
 * Secties.
 */

// Bron van een sectie: page (velden van de pagina) of settings (Site-instellingen).
function sourceOf(name) {
	return sections.find((item) => item.name === name)?.source ?? 'page';
}

function toggleOf(name, source = sourceOf(name)) {
	return `${source === 'settings' ? SITE : ''}${data.prefix}${name}_enabled`;
}

// De sectie waar een veld bij hoort: {voorvoegsel}{sectie} of {voorvoegsel}{sectie}_…, de langste naam als er meer
// passen (hero en hero_extra). Een veld van de pagina hoort bij een sectie van de pagina, een Site-instelling bij een
// sectie uit de Site-instellingen.
function ownerOf(name) {
	const source = isSite(name) ? 'settings' : 'page';
	const bare = isSite(name) ? name.slice(SITE.length) : name;
	return sections
		.filter((item) => item.source === source && (bare === data.prefix + item.name || bare.startsWith(`${data.prefix}${item.name}_`)))
		.reduce((best, item) => (!best || item.name.length > best.length ? item.name : best), null);
}

// Velden van een sectie die nergens in de pagina te klikken zijn, de schakelaar eerst.
function sectionFields(name) {
	const own = Object.keys(fields).filter((field) => !marks.has(field) && ownerOf(field) === name);
	return own.sort((a, b) => (b === toggleOf(name)) - (a === toggleOf(name)));
}

// De naam van een sectie: wat de meeste veldlabels voor de dubbele punt hebben ('Diensten: titel'), anders het label
// van de schakelaar ('Diensten tonen'), anders de sectienaam.
function sectionLabel(name) {
	const counts = new Map();
	Object.keys(fields)
		.filter((field) => ownerOf(field) === name)
		.forEach((field) => {
			const [head, ...rest] = fields[field].label.split(':');
			if (rest.length > 0 && head.trim()) {
				counts.set(head.trim(), (counts.get(head.trim()) || 0) + 1);
			}
		});
	const best = [...counts].sort((a, b) => b[1] - a[1])[0];
	return best?.[0] || fields[toggleOf(name)]?.label || name;
}

function sectionInfo() {
	return Object.fromEntries(
		sections.map(({ name, source }) => {
			const editable = sectionFields(name).length > 0;
			// Een sectie uit de Site-instellingen die de gebruiker hier niet kan bewerken, krijgt alleen een label.
			if (source === 'settings' && !editable) {
				return [name, { settings: true }];
			}
			const toggle = toggleOf(name, source);
			const off = Object.hasOwn(fields, toggle) && !valueOf(toggle);
			return [name, { label: sectionLabel(name), editable, off, site: source === 'settings' }];
		})
	);
}

/*
 * Veldgroepen.
 */

// Een siteveld hoort bij een groep op label: twee groepen met hetzelfde label zijn één groep.
function groupKeyOf(name) {
	return isSite(name) ? fields[name].group : fields[name].groupKey;
}

function fieldsOf(source) {
	return Object.keys(fields).filter((name) => isSite(name) === (source === 'site'));
}

// De groepen in de volgorde van fields, alleen met velden; Algemeen (titel en slug) eerst.
function groupsOf(source) {
	const groups = new Map();
	fieldsOf(source).forEach((name) => groups.has(groupKeyOf(name)) || groups.set(groupKeyOf(name), fields[name].group));
	const all = [...groups].map(([key, label]) => ({ key, label }));
	return all.sort((a, b) => (b.key === 'general') - (a.key === 'general'));
}

// De velden van een groep: wat in de pagina staat in de volgorde van de pagina (marks), dan de rest in de volgorde
// van fields. Titel en slug zijn nooit gemarkeerd en staan dus in rest.
function groupFields(source, key) {
	const own = fieldsOf(source).filter((name) => groupKeyOf(name) === key);
	return { onPage: [...marks].filter((name) => own.includes(name)), rest: own.filter((name) => !marks.has(name)) };
}

function groupExists(item) {
	return groupsOf(item.source).some((other) => other.key === item.key);
}

// De namen van de secties van de pagina zelf (niet die uit de Site-instellingen).
function pageSectionNames() {
	return sections.filter((item) => item.source === 'page').map((item) => item.name);
}

// De groepen die de weergave Pagina-instellingen toont: zonder de groepen van een sectie op de pagina.
function pageGroups() {
	return pageSettingsGroups(groupsOf('page'), pageSectionNames());
}

/*
 * Van pagina wisselen.
 */

// De pagina die nu open is: een bericht, of de 404 of de zoekpagina (data.view).
function isCurrentPage(item) {
	return item.view ? item.view === data.view : !data.view && item.id === post.id;
}

// Alle pagina's (subpagina's ingesprongen, concepten met een label) en na een scheidingslijn de 404 en de zoekpagina.
// De id van een item is de URL van zijn editor.
function pageItems() {
	const pages = (data.pages || []).map((page) => ({
		id: page.url,
		label: page.title || strings.untitled,
		detail: page.published ? '' : strings.draft,
		depth: page.depth,
		current: isCurrentPage(page),
	}));
	const views = (data.views || []).map((view, index) => ({ id: view.url, label: view.label, current: isCurrentPage(view), separator: index === 0 && pages.length > 0 }));
	// Op mobiel staat Bekijk live (of Voorbeeld bij een concept) onderaan het menu, na een scheidingslijn.
	const live = mobile.matches ? [{ id: VIEW_LIVE, label: viewText(), separator: true }] : [];
	// Helemaal onderaan: deze pagina dupliceren, als je dat mag (niet op de 404 en de zoekpagina).
	const duplicate = data.canDuplicate ? [{ id: DUPLICATE, label: strings.duplicate, separator: true }] : [];
	return [...pages, ...views, ...live, ...duplicate];
}

// De id van het menu-item Bekijk live: een link naar de pagina zelf, geen andere editor.
const VIEW_LIVE = 'ww-view-live';
// De id van het menu-item dat deze pagina dupliceert en de kopie opent.
const DUPLICATE = 'ww-duplicate';

// Opent de editor van een andere pagina; bij wijzigingen die nog niet zijn opgeslagen vraagt de browser eerst of dat
// mag (beforeunload). De pagina die al open is, blijft gewoon open.
function goTo(url) {
	if (url === VIEW_LIVE) {
		window.open(viewHref(), '_blank', 'noopener');
		return;
	}
	if (url === DUPLICATE) {
		duplicatePage();
		return;
	}
	if (pageItems().some((item) => item.id === url && item.current)) {
		return;
	}
	window.location.assign(url);
}

// De editor van de kopie die deze pagina al maakte: een tweede klik opent die, in plaats van nog een kopie te maken.
let copyUrl = '';
// Waar naartoe is al gevraagd (dupliceren): de beforeunload-vraag slaat dan over.
let leaving = false;

// Dupliceert deze pagina als concept en opent de kopie. Met wijzigingen die nog niet zijn opgeslagen komt eerst de vraag
// of dupliceren toch mag (de kopie krijgt de opgeslagen versie), vóór er een kopie is: annuleren laat geen concept
// achter. Wat niet meeging, meldt de editor van de kopie (data.copyDropped).
async function duplicatePage() {
	if (busy || (changes.size > 0 && !window.confirm(strings.duplicateUnsaved))) {
		return;
	}
	if (copyUrl) {
		leaveTo(copyUrl);
		return;
	}
	busy = true;
	renderFooter();
	toast('');
	try {
		const result = await window.wp.apiFetch({ path: `${data.endpoint}/duplicate`, method: 'POST' });
		copyUrl = result.editor_url;
		leaveTo(copyUrl);
	} catch (error) {
		toast(error?.message || strings.error, 'error');
	}
	busy = false;
	renderFooter();
}

// Naar een andere pagina zonder de beforeunload-vraag: de vraag is al gesteld.
function leaveTo(url) {
	leaving = true;
	window.location.assign(url);
}

/*
 * Talen (alleen met Meertalig, data.languages).
 */

// De knop met de taalcode van de open pagina en de container van zijn menu, direct na het menu van de pagina's.
function createLanguagesToggle(after) {
	const toggle = element('button', { type: 'button', className: 'ww-editor__lang-button', ariaLabel: strings.switchLanguage, title: strings.switchLanguage }, [
		element('span', { className: 'ww-editor__lang-code', textContent: data.languages.current.toUpperCase() }),
		element('span', { className: 'dashicons dashicons-arrow-down-alt2 ww-editor__caret', ariaHidden: 'true' }),
	]);
	toggle.setAttribute('aria-haspopup', 'menu');
	after.after(toggle, element('div', { hidden: true }));
	return toggle;
}

// Per taal de naam, of die verborgen is en of de vertaling concept of gepubliceerd is; zonder vertaling de keuze om
// hem te maken. Is de bron nieuwer dan de vertaling, dan staat daar een grijze regel onder.
function languageItems() {
	return data.languages.items.map((item) => {
		// De 404 en de zoekpagina bestaan in elke taal: geen status en geen "Vertaling maken".
		const status = data.view ? '' : item.status === 'publish' ? strings.published : strings.draft;
		const details = [item.visible ? '' : strings.hidden, data.view ? '' : item.id > 0 ? status : strings.createTranslation].filter(Boolean);
		const date = item.source_newer && item.source_modified ? new Date(item.source_modified) : null;
		return {
			id: item.code,
			label: item.name,
			detail: details.join(' · '),
			note: date && !Number.isNaN(date.getTime()) ? strings.sourceNewer.replace('%s', date.toLocaleDateString('nl-NL')) : '',
			current: item.code === data.languages.current,
		};
	});
}

// Een vertaling opent in de editor via goTo(), dus met dezelfde vraag bij wijzigingen die nog niet zijn opgeslagen; een
// taal zonder vertaling maakt er eerst een.
function pickLanguage(code) {
	const item = data.languages.items.find((other) => other.code === code);
	if (!item || code === data.languages.current) {
		return;
	}
	if (data.view ? item.url : item.id > 0) {
		// Een 404- of zoekweergave is "current" per weergave, niet per taal: de taalwissel navigeert altijd, ook als de url
		// gelijk is aan die van de weergave in het menu van de pagina's (de standaardtaal heeft geen lang).
		data.view ? window.location.assign(item.url) : goTo(item.url);
	} else {
		createTranslation(item);
	}
}

// Wat een nieuwe vertaling niet heeft overgenomen (relaties die nog niet vertaald zijn) wordt onthouden voor de pagina
// die opent: de editor laadt opnieuw, dus een melding hier zou verdwijnen. Alleen de ID's; titels halen we niet op.
function rememberDropped(id, dropped) {
	// Alleen wat vertaald kan worden: de bovenliggende pagina en relaties met berichten, met een echt ID. Een ongeldige
	// waarde (ID 0) of een verwijderde foto is niet "nog niet vertaald".
	const ids = dropped
		.filter((entry) => entry.id > 0 && (entry.field === 'post_parent' || (fields[entry.field]?.type === 'pick' && fields[entry.field].editable)))
		.map((entry) => entry.id);
	if (ids.length === 0) {
		return;
	}
	try {
		window.sessionStorage.setItem(DROPPED_KEY, JSON.stringify({ id, ids: [...new Set(ids)] }));
	} catch (error) {
		// Geen opslag (privévenster): de vertaling is er wel, alleen de melding ontbreekt.
	}
}

// Toont de onthouden melding als deze pagina de vertaling is waarvoor hij bedoeld was; één keer.
function showDropped() {
	try {
		const stored = JSON.parse(window.sessionStorage.getItem(DROPPED_KEY) || 'null');
		if (!stored || stored.id !== post.id) {
			return false;
		}
		window.sessionStorage.removeItem(DROPPED_KEY);
		const ids = (Array.isArray(stored.ids) ? stored.ids : []).filter(Number.isInteger).map((id) => `#${id}`);
		if (ids.length === 0) {
			return false;
		}
		toast(strings.notTranslated.replace('%s', ids.join(', ')), 'warning');
		return true;
	} catch (error) {
		return false;
	}
}

async function createTranslation(item) {
	if (busy) {
		return;
	}
	busy = true;
	renderFooter();
	toast('');
	try {
		const result = await window.wp.apiFetch({ path: `${data.endpoint}/translations`, method: 'POST', data: { lang: item.code } });
		// Blijft deze pagina open (de vraag bij wijzigingen is geweigerd), dan opent het menu de vertaling voortaan.
		Object.assign(item, { id: result.id, url: result.editor_url, status: result.status || 'draft' });
		if (Array.isArray(result.dropped) && result.dropped.length > 0) {
			rememberDropped(result.id, result.dropped);
		}
		goTo(result.editor_url);
	} catch (error) {
		toast(error?.message || strings.error, 'error');
	}
	busy = false;
	renderFooter();
}

/*
 * Lijsten met kaarten.
 */

// Een relatie is alleen als lijst te kiezen als het paneel hem kan bewerken; een automatische lijst altijd.
function listLabel(item) {
	if (item.source === 'relation') {
		return fields[item.name]?.type === 'pick' && fields[item.name].editable ? fields[item.name].label : null;
	}
	return data.postTypes[item.name]?.label || item.name;
}

function listInfo() {
	return Object.fromEntries(
		lists
			.filter((item) => listLabel(item) !== null)
			.map((item) => {
				const text = item.source === 'relation' ? strings.linked.replace('%d', String(relationIds(item.name).length)) : strings.automatic;
				return [item.index, { label: listLabel(item), text }];
			})
	);
}

// Het nummer van de gekozen lijst in de pagina zoals hij nu geladen is, of null.
function listIndex() {
	return lists.find((item) => item.source === list?.source && item.name === list?.name)?.index ?? null;
}

// Een automatische lijst: wat hij toont en waar je de berichten beheert.
function autoListControls(name) {
	const type = data.postTypes[name];
	const label = type?.label || name;
	const controls = [element('p', { className: 'ww-editor__auto', textContent: strings.autoList.replace('%s', label) })];
	if (type?.admin) {
		controls.push(
			element('p', {}, [
				element('a', { className: 'button', href: type.admin, target: '_blank', rel: 'noopener' }, [
					element('span', { className: 'dashicons dashicons-external', ariaHidden: 'true' }),
					` ${strings.manage.replace('%s', label)}`,
				]),
			])
		);
	}
	return controls;
}

// Wat de pagina toont voor een waarde: tekst zoals hij is, een foto als URL, WYSIWYG als HTML met alinea's
// (Pods bewaart de tekst zonder <p>, net als het gewone bewerkscherm).
function display(name) {
	let value = valueOf(name);
	// Een lege vertaling toont de pagina in de standaardtaal, net als de site (Meertalig).
	if (fields[name].translatable === true && String(value ?? '').trim() === '') {
		value = fields[name].fallback ?? '';
	}
	// Een relatie toont de pagina pas na opslaan: de kaarten rendert PHP.
	if (fields[name].type === 'pick') {
		return null;
	}
	if (fields[name].type === 'wysiwyg') {
		return { html: window.wp.editor.autop(value || '') };
	}
	if (fields[name].type !== 'file') {
		return value;
	}
	return { url: value ? previews.get(name) || fields[name].preview : '' };
}

function change(name, value) {
	if (same(value, fields[name].value)) {
		changes.delete(name);
	} else {
		changes.set(name, value);
	}
	toggleFallback(name, value);
	send({ type: MESSAGE.VALUE, name, value: display(name) });
	if (sections.some((item) => toggleOf(item.name, item.source) === name)) {
		send({ type: MESSAGE.SECTIONS, sections: sectionInfo() });
	}
	if (lists.some((item) => item.source === 'relation' && item.name === name)) {
		send({ type: MESSAGE.LISTS, lists: listInfo() });
	}
	if (name === 'post_title') {
		root.querySelector('[data-ww-editor-title]').textContent = value;
		pagesToggle.title = value;
	}
	syncRevert(name);
	renderFooter();
}

// Zet een veld terug op zijn opgeslagen waarde en tekent het paneel opnieuw, ook de WYSIWYG-velden. Met focus (standaard)
// krijgt het veld de focus; de lijst in Wijzigingen zet dat uit, want de focus blijft daar.
function revert(name, { focus = true } = {}) {
	if (busy) {
		return;
	}
	previews.delete(name);
	change(name, fields[name].value);
	if (focus) {
		focusing = name;
	}
	renderFields();
}

// Zet de gegeven velden terug op hun opgeslagen waarde, zonder te vragen; de knop Alle wijzigingen weggooien geeft alle
// namen. Tekent zelf niets opnieuw behalve de voet: wie dit aanroept, kiest daarna de weergave.
function discardChanges(names) {
	if (busy) {
		return;
	}
	names.forEach((name) => {
		previews.delete(name);
		change(name, fields[name].value);
	});
	renderFooter();
}

// Opent de weergave Wijzigingen (Bekijken in de voet).
function openChanges() {
	select({ settings: 'changes' });
}

// Toont of verbergt alleen de knop Terugzetten van een veld, bij elke toetsaanslag; tekent niets opnieuw.
function syncRevert(name) {
	const button = fieldsBox.querySelector(`[data-ww-field="${CSS.escape(name)}"] .ww-editor__revert`);
	if (button) {
		button.hidden = !changes.has(name);
	}
}

/*
 * Velden.
 */

function element(tag, props = {}, children = []) {
	const node = Object.assign(document.createElement(tag), props);
	node.append(...children);
	return node;
}

// De waarde in de standaardtaal van een vertaalbaar veld (Meertalig) als platte tekst op één regel, of ''. Het veld
// komt uit onze eigen PHP, maar WYSIWYG-tekst is HTML: via DOMParser, nooit als markup in dit document.
function fallbackText(field) {
	if (field.translatable !== true || typeof field.fallback !== 'string') {
		return '';
	}
	return field.type === 'wysiwyg' ? plainText(field.fallback).replace(/\s+/g, ' ').trim() : field.fallback;
}

function textControl(name, field, id) {
	const multiline = field.type === 'paragraph';
	const input = element(multiline ? 'textarea' : 'input', { id, className: multiline ? 'large-text' : 'regular-text' });
	if (multiline) {
		input.rows = 5;
	} else {
		input.type = INPUT_TYPES[field.type];
	}
	// Een lege vertaling toont de standaardtaal als placeholder, zonder extra tekst.
	input.placeholder = fallbackText(field);
	input.value = valueOf(name) ?? '';
	input.addEventListener('input', () => change(name, input.value));
	return input;
}

// Tekst als HTML: TinyMCE met de editor-style van het child-thema, gestart door renderFields() zodra het tekstvak
// in het paneel staat. De codeweergave schrijft direct in het tekstvak.
function wysiwygControl(name, field, id) {
	const textarea = element('textarea', { id, className: 'wp-editor-area', rows: 12 });
	textarea.value = valueOf(name) ?? '';
	textarea.addEventListener('input', () => change(name, textarea.value));
	editors.set(id, name);
	// Een placeholder kan TinyMCE niet tonen: een grijze regel boven het veld, zolang de vertaling leeg is.
	const fallback = fallbackText(fields[name]);
	if (fallback === '') {
		return textarea;
	}
	const hint = element('p', { className: 'ww-editor__fallback', textContent: strings.emptyFallback.replace('%s', () => fallback), hidden: (valueOf(name) ?? '').trim() !== '' });
	return element('div', {}, [hint, textarea]);
}

// Verbergt de regel "Leeg: …" van een WYSIWYG-veld zodra er tekst staat.
function toggleFallback(name, value) {
	const hint = fieldsBox.querySelector(`[data-ww-field="${CSS.escape(name)}"] .ww-editor__fallback`);
	if (hint) {
		hint.hidden = String(value ?? '').trim() !== '';
	}
}

function startEditor(id, name, focus = false) {
	window.wp.editor.initialize(id, {
		tinymce: {
			wpautop: true,
			toolbar1: 'formatselect,bold,italic,bullist,numlist,link,unlink,undo,redo',
			toolbar2: '',
			block_formats: strings.blockFormats,
			content_css: data.editorStyles.join(','),
			setup(editor) {
				editor.on('input change undo redo ExecCommand', () => change(name, window.wp.editor.getContent(id)));
				// Ctrl+K opent het zoekvenster, niet de link-dialoog van WordPress: vooraan in de rij (prepend), zodat de
				// sneltoetsen van TinyMCE hem niet eerst krijgen.
				editor.on('keydown', (event) => onSearchShortcut(event), true);
				// Het eerste veld van een weergave die via de pagina of het zoekvenster opent, krijgt de focus, ook als dat
				// deze editor is; net als het veld dat select({ focus }) noemt.
				editor.on('init', () => focus && editor.focus());
				// Escape gaat ook vanuit de editor één niveau terug; de toetsen in zijn iframe bereiken het document niet.
				// Niet als Escape een popup van TinyMCE sluit (de linkbalk, een menu): vooraan in de rij (prepend), zodat
				// die nog open is als we kijken. Na de toets, want back() haalt deze editor weg; wat er getypt is, staat
				// al in changes.
				editor.on('keydown', (event) => event.key === 'Escape' && !tinyPopupOpen() && canGoBack() && setTimeout(back), true);
			},
		},
		quicktags: { buttons: 'strong,em,link,ul,ol,li' },
		mediaButtons: true,
	});
	// Media toevoegen zet de foto in de editor die hier actief is.
	window.wpActiveEditor = id;
}

// Een zichtbare popup van TinyMCE: een menu, een zwevend paneel of de werkbalk bij een link (in dit document).
function tinyPopupOpen() {
	return [...document.querySelectorAll('.mce-menu, .mce-floatpanel, .mce-inline-toolbar-grp')].some((node) => node.getClientRects().length > 0 && getComputedStyle(node).visibility !== 'hidden');
}

function stopEditors() {
	editors.forEach((name, id) => window.wp.editor.remove(id));
	editors.clear();
}

// Titel uit de zoekresultaten van WordPress, met entiteiten (&#8211;) als gewone tekens.
function plainText(html) {
	return new DOMParser().parseFromString(html, 'text/html').body.textContent || '';
}

// Linkveld: zoek een pagina of bericht van de site, of typ zelf een URL, tel: of mailto:.
function linkControl(name, field, id) {
	const input = element('input', { id, type: 'text', className: 'regular-text', placeholder: strings.searchLink, autocomplete: 'off' });
	const results = element('ul', { className: 'ww-editor__results' });
	input.value = valueOf(name) ?? '';

	const pick = (url) => {
		input.value = url;
		change(name, url);
		results.replaceChildren();
	};
	const search = async (term) => {
		if (term.length < 2 || LOOKS_LIKE_LINK.test(term)) {
			results.replaceChildren();
			return;
		}
		try {
			const query = new URLSearchParams({ search: term, type: 'post', per_page: '8' });
			const items = await window.wp.apiFetch({ path: `/wp/v2/search?${query}` });
			if (input.value.trim() !== term) {
				return;
			}
			results.replaceChildren(
				...items.map((item) =>
					element('li', {}, [
						element('button', { type: 'button', className: 'button-link', onclick: () => pick(item.url) }, [
							element('span', { textContent: plainText(item.title) }),
							element('span', { className: 'ww-editor__result-url', textContent: item.url }),
						]),
					])
				)
			);
			if (items.length === 0) {
				results.replaceChildren(element('li', { className: 'description', textContent: strings.noLinkResults }));
			}
		} catch (error) {
			results.replaceChildren();
		}
	};

	const searchLater = debounce(search);
	input.addEventListener('input', () => {
		const term = input.value.trim();
		if (term === '' || LOOKS_LIKE_LINK.test(term)) {
			change(name, term);
		}
		searchLater(term);
	});
	return element('div', { className: 'ww-editor__link' }, [input, results]);
}

function booleanControl(name, field, id) {
	const input = element('input', { id, type: 'checkbox', checked: Boolean(valueOf(name)) });
	input.addEventListener('change', () => change(name, input.checked));
	return input;
}

function imageControl(name, field) {
	const box = element('div', { className: 'ww-editor__image' });
	const render = () => {
		const { url } = display(name);
		const buttons = [element('button', { type: 'button', className: 'button', textContent: strings.chooseImage, onclick: choose })];
		if (url) {
			buttons.push(element('button', { type: 'button', className: 'button-link ww-editor__remove', textContent: strings.removeImage, onclick: remove }));
		}
		box.replaceChildren(...(url ? [element('img', { src: url, alt: '' })] : []), element('p', {}, buttons));
	};
	const choose = () => {
		const media = window.wp.media({
			title: field.label,
			library: { type: 'image' },
			multiple: false,
			button: { text: strings.useImage },
		});
		media.on('select', () => {
			const attachment = media.state().get('selection').first().toJSON();
			const sizes = attachment.sizes || {};
			previews.set(name, (sizes.large || sizes.full || attachment).url);
			change(name, attachment.id);
			render();
		});
		media.open();
	};
	const remove = () => {
		change(name, 0);
		render();
	};
	render();
	return box;
}

function itemTitle(item) {
	return `${item.title || strings.untitled}${item.published ? '' : ` (${strings.notPublished})`}`;
}

function iconButton(icon, label, onclick, disabled = false) {
	return element('button', { type: 'button', className: 'button-link ww-editor__item-button', disabled, onclick }, [
		element('span', { className: `dashicons dashicons-${icon}` }),
		element('span', { className: 'screen-reader-text', textContent: label }),
	]);
}

function relationIds(name) {
	const value = valueOf(name);
	if (fields[name].multiple) {
		return Array.isArray(value) ? [...value] : [];
	}
	return value ? [value] : [];
}

// Link naar het bewerkscherm van een bericht in een relatie, als de gebruiker het mag bewerken. Een bericht invullen
// gebeurt daar, in een nieuw tabblad, zodat deze pagina openblijft.
function editLink(item) {
	if (!item.edit) {
		return [];
	}
	return [
		element('a', { className: 'button-link ww-editor__item-button', href: item.edit, target: '_blank', rel: 'noopener', title: strings.editItem }, [
			element('span', { className: 'dashicons dashicons-external' }),
			element('span', { className: 'screen-reader-text', textContent: strings.editItem }),
		]),
	];
}

// Relatie: de gekozen berichten in hun volgorde, te slepen of met de pijltjes te verplaatsen, en zoeken om er een
// toe te voegen (relationSearch()). Bij één waarde vervangt een gekozen bericht het vorige.
function relationControl(name, field, id) {
	const list = element('ol', { className: 'ww-editor__items' });
	let dragged = null;

	const render = () => {
		const ids = relationIds(name);
		if (ids.length === 0) {
			list.replaceChildren(element('li', { className: 'description', textContent: strings.noItems }));
			return;
		}
		list.replaceChildren(
			...ids.map((itemId, index) => {
				const item = items.get(itemId) || { id: itemId, title: '', published: true, edit: '' };
				const buttons = field.multiple
					? [
							iconButton('arrow-up-alt2', strings.moveUp, () => move(index, index - 1, 0), index === 0),
							iconButton('arrow-down-alt2', strings.moveDown, () => move(index, index + 1, 1), index === ids.length - 1),
						]
					: [];
				const row = element('li', { className: 'ww-editor__item', draggable: field.multiple }, [
					element('span', { className: 'ww-editor__item-title', textContent: itemTitle(item) }),
					...editLink(item),
					...buttons,
					iconButton('no-alt', strings.removeItem, () => set(ids.filter((other) => other !== itemId))),
				]);
				row.addEventListener('dragstart', (event) => {
					dragged = index;
					event.dataTransfer.effectAllowed = 'move';
					event.dataTransfer.setData('text/plain', String(itemId));
				});
				row.addEventListener('dragover', (event) => dragged !== null && event.preventDefault());
				row.addEventListener('drop', (event) => {
					event.preventDefault();
					if (dragged !== null && dragged !== index) {
						move(dragged, index);
					}
					dragged = null;
				});
				row.addEventListener('dragend', () => (dragged = null));
				return row;
			})
		);
	};
	const set = (ids, focus) => {
		change(name, field.multiple ? ids : (ids[0] ?? 0));
		render();
		// Na verplaatsen houdt de knop de focus, op de nieuwe plek.
		if (focus) {
			list.children[focus.index]?.querySelectorAll('button')[focus.button]?.focus();
		}
	};
	const move = (from, to, button) => {
		const ids = relationIds(name);
		ids.splice(to, 0, ...ids.splice(from, 1));
		set(ids, button === undefined ? null : { index: to, button });
	};
	const add = (itemId) => set(field.multiple ? [...relationIds(name), itemId] : [itemId]);

	render();
	return element('div', { className: 'ww-editor__relation' }, [list, ...relationSearch(name, field, id, add), element('p', { className: 'description', textContent: strings.afterSave })]);
}

// Het zoekveld van een relatie met zijn resultaten: berichten van het post type van het veld die nog niet gekozen
// zijn, en als het getypte bericht niet bestaat en de gebruiker het mag maken, een knop om het aan te maken. add
// voegt een post-ID toe aan de relatie.
function relationSearch(name, field, id, add) {
	const input = element('input', { id, type: 'search', className: 'regular-text', placeholder: strings.addItem, autocomplete: 'off' });
	const results = element('ul', { className: 'ww-editor__results' });

	const choose = (itemId) => {
		add(itemId);
		input.value = '';
		results.replaceChildren();
		input.focus();
	};
	// Maakt een concept met deze titel en koppelt het; de pagina toont het pas als het is ingevuld en gepubliceerd.
	const create = async (title, trigger) => {
		// Eén keer: een dubbelklik zou anders twee concepten maken.
		trigger.disabled = true;
		try {
			const item = await window.wp.apiFetch({ path: `${data.endpoint}/items`, method: 'POST', data: { field: name, title } });
			remember([item]);
			choose(item.id);
			toast(strings.created.replace('%s', title), 'info');
		} catch (error) {
			toast(error?.message || strings.createError, 'error');
			trigger.disabled = false;
		}
	};
	const search = async () => {
		const term = input.value.trim();
		try {
			const query = new URLSearchParams({ field: isSite(name) ? name.slice(SITE.length) : name, search: term });
			const base = isSite(name) ? '/ww/v1/editor/settings' : data.endpoint;
			const found = await window.wp.apiFetch({ path: `${base}/items?${query}` });
			if (input.value.trim() !== term) {
				return;
			}
			remember(found);
			const chosen = relationIds(name);
			const options = found.filter((item) => !chosen.includes(item.id));
			results.replaceChildren(
				...options.map((item) => element('li', {}, [element('button', { type: 'button', className: 'button-link', textContent: itemTitle(item), onclick: () => choose(item.id) })]))
			);
			// Bestaat het nog niet, dan kan het hier meteen worden aangemaakt (als de gebruiker dat mag).
			const exists = found.some((item) => item.title.trim().toLowerCase() === term.toLowerCase());
			if (field.create && term !== '' && !exists) {
				const label = strings.createItem.replace('%1$s', term).replace('%2$s', field.create);
				results.append(element('li', {}, [element('button', { type: 'button', className: 'button-link ww-editor__create', textContent: label, onclick: (event) => create(term, event.currentTarget) })]));
			} else if (options.length === 0) {
				results.replaceChildren(element('li', { className: 'description', textContent: strings.noMatches }));
			}
		} catch (error) {
			results.replaceChildren();
		}
	};

	input.addEventListener('input', debounce(search));
	input.addEventListener('focus', search);
	return [input, results];
}

// Invoer per soort veld; een bestandsveld is alleen als één foto te bewerken, een relatie alleen met berichten.
const CONTROLS = {
	...Object.fromEntries(Object.keys(INPUT_TYPES).map((type) => [type, textControl])),
	paragraph: textControl,
	website: linkControl,
	wysiwyg: wysiwygControl,
	boolean: booleanControl,
	image: imageControl,
	pick: relationControl,
};

function kindOf(field) {
	if (field.type === 'pick') {
		return field.editable ? 'pick' : '';
	}
	if (field.type !== 'file') {
		return field.type;
	}
	return field.images && !field.multiple ? 'image' : '';
}

// prefix: de naam van de sectie of groep die al in de kruimel staat; het label toont dan alleen de rest ('Titel').
function control(name, prefix = '') {
	const field = fields[name];
	const text = withoutPrefix(field.label, prefix);
	// Een id zonder de dubbele punt van site:, want TinyMCE zoekt het tekstvak met een CSS-selector.
	const id = `ww-editor-${name.replace(/[^a-z0-9_-]/gi, '-')}`;
	const kind = kindOf(field);
	const build = Object.hasOwn(CONTROLS, kind) ? CONTROLS[kind] : null;
	const input = build ? build(name, field, id) : element('p', { className: 'description', textContent: strings.notYet });
	// Een foto of een veld zonder invoer heeft een kop in plaats van een label; een vinkje staat vóór zijn label.
	const caption =
		build && kind !== 'image'
			? element('label', { htmlFor: id, className: 'ww-editor__label', textContent: text })
			: element('p', { className: 'ww-editor__label', textContent: text });
	// Terugzetten staat in de labelregel, achter het label; verborgen zolang het veld niet gewijzigd is.
	const undo = element(
		'button',
		{
			type: 'button',
			className: 'button-link ww-editor__revert',
			hidden: !changes.has(name),
			disabled: busy,
			onclick: () => revert(name),
		},
		[element('span', { className: 'dashicons dashicons-undo', ariaHidden: 'true' }), strings.revert]
	);
	undo.setAttribute('aria-label', strings.revertField.replace('%s', text));
	const label = element('div', { className: 'ww-editor__label-row' }, [caption, undo]);
	const box =
		kind === 'boolean'
			? element('div', { className: 'ww-editor__field ww-editor__field--check' }, [input, label])
			: element('div', { className: 'ww-editor__field' }, [label, input]);
	// Om het veld terug te vinden als het de focus krijgt (select({ focus })).
	box.dataset.wwField = name;
	// Een Site-instelling die niet te vertalen is, geldt voor alle talen (alleen met Meertalig in een extra taal).
	if (field.translatable === false) {
		(kind === 'boolean' ? box.lastElementChild : box.firstElementChild).after(element('p', { className: 'ww-editor__field-note', textContent: strings.allLanguages }));
	}
	// In een vertaling: de tekst van hetzelfde veld in de standaardtaal, ingeklapt (field.source is platte tekst).
	if (typeof field.source === 'string' && field.source !== '') {
		box.append(
			element('details', { className: 'ww-editor__source' }, [
				element('summary', { textContent: strings.showSource }),
				element('p', { className: 'ww-editor__source-text', textContent: field.source }),
			])
		);
	}
	return box;
}

/*
 * Weergaven in het midden.
 */

// Welke weergave het midden toont, in deze volgorde: een gekozen element, sectie, lijst of groep, dan de Pagina- of
// Site-instellingen, anders Op deze pagina (nav).
function viewKind() {
	if (selected) {
		return 'field';
	}
	if (section) {
		return 'section';
	}
	if (list) {
		return 'list';
	}
	if (group) {
		return 'group';
	}
	return settings ? 'settings' : 'nav';
}

function viewKey() {
	return JSON.stringify([selected, section, list, group, settings]);
}

// Wat het midden toont: de titel voor de kruimelregel (niet op Op deze pagina), of het voor de hele site geldt, en de
// inhoud.
function panelContent() {
	const kind = viewKind();
	if (kind === 'field') {
		// De sectie waarin het element staat, anders de groep van zijn eerste veld (bij een siteveld die uit de
		// Site-instellingen). De labels laten die naam weg.
		const first = selected[0];
		const owner = ownerOf(first);
		const title = owner ? sectionLabel(owner) : fields[first].group || fields[first].label;
		const site = selected.some(isSite);
		return { title, site, controls: [...siteNotice(site), ...selected.map((name) => control(name, title))] };
	}
	if (kind === 'section') {
		return { title: sectionLabel(section), site: sourceOf(section) === 'settings', controls: sectionControls(section) };
	}
	if (kind === 'list') {
		// Een automatische lijst heet naar zijn post type. Een relatie heet naar de sectie waarin ze staat ('Diensten'),
		// anders naar het deel van haar label voor de dubbele punt; het label van het veld laat die naam dan weg, zoals
		// bij een veld ('Welke en in welke volgorde').
		if (list.source !== 'relation') {
			return { title: listLabel(list) ?? list.name, controls: autoListControls(list.name) };
		}
		const owner = ownerOf(list.name);
		const title = owner ? sectionLabel(owner) : (listLabel(list) ?? list.name).split(': ')[0];
		return { title, controls: [control(list.name, title)] };
	}
	if (kind === 'group') {
		const title = groupsOf(group.source).find((item) => item.key === group.key)?.label ?? group.key;
		return { title, controls: groupControls(group.source, group.key) };
	}
	// Vóór de laatste tak hieronder, want die tekent Pagina-instellingen voor elke andere bron.
	if (kind === 'settings' && settings === 'changes') {
		return { title: strings.changesTitle, controls: changesControls() };
	}
	if (kind === 'settings' && settings === 'versions') {
		return { title: strings.versions, controls: versionsControls() };
	}
	if (kind === 'settings' && settings === 'site') {
		// Zonder het groene label Hele site: de titel zegt het al.
		return { title: strings.site, controls: [groupList('site', groupsOf('site'))] };
	}
	if (kind === 'settings') {
		// Hooguit drie groepen: de velden direct, met de naam van elke groep als tussenkop; meer: een lijst.
		const groups = pageGroups();
		const controls =
			groups.length <= INLINE_GROUPS ? groups.flatMap(({ key, label }) => [subhead(label), ...groupControls('page', key, true)]) : [groupList('page', groups)];
		return { title: strings.page, controls };
	}
	return { title: null, controls: navContent() };
}

// De weergave Versies. De lijst wordt bij het eerste openen opgehaald; tot dan staat er een spinner. Is de weergave klaar
// met laden terwijl ze nog open staat, dan tekent ze zich opnieuw.
function versionsControls() {
	if (versionsState === null) {
		versionsState = 'loading';
		const token = ++versionsRequest;
		window.wp
			.apiFetch({ path: `${data.endpoint}/versions` })
			.then((result) => (Array.isArray(result?.versions) ? result.versions : 'error'))
			.catch(() => 'error')
			.then((state) => {
				// Een opslag maakte de lijst al ongeldig (en startte misschien een nieuwe ronde): dit antwoord is verouderd.
				if (token !== versionsRequest) {
					return;
				}
				versionsState = state;
				if (settings === 'versions') {
					renderFields();
				}
			});
	}
	if (versionsState === 'loading') {
		return [element('span', { className: 'spinner is-active ww-editor__versions-loading', role: 'status' }, [element('span', { className: 'screen-reader-text' }, strings.loading)])];
	}
	if (versionsState === 'error') {
		return [element('p', { className: 'ww-editor__empty', textContent: strings.versionsError })];
	}
	const note = element('p', { className: 'ww-editor__hint', textContent: strings.versionsNote });
	if (versionsState.length <= 1) {
		return [element('p', { className: 'ww-editor__empty', textContent: strings.noVersions }), note];
	}
	const rows = versionsState.map(({ id, date, author, current }) => {
		if (current) {
			return element('li', {}, [
				element('div', { className: 'ww-editor__version ww-editor__version--current' }, [
					element('span', { className: 'ww-editor__version-text' }, [
						element('span', { className: 'ww-editor__version-date', textContent: date }),
						element('span', { className: 'ww-editor__version-author', textContent: author }),
					]),
					element('span', { className: 'ww-editor__tag', textContent: strings.currentVersion }),
				]),
			]);
		}
		const item = viewItem(`version:${id}`, `${date}, ${author}`, [], () => pickVersion(id, date));
		// Tijdens opslaan of ophalen doet een klik niets, en dat is te zien (renderFooter zet disabled bij busy).
		item.dataset.wwLock = '';
		item.dataset.wwVersion = '';
		item.disabled = busy || picking;
		const text = item.querySelector('.ww-editor__nav-label');
		text.classList.add('ww-editor__version-text');
		text.replaceChildren(
			element('span', { className: 'ww-editor__version-date', textContent: date }),
			element('span', { className: 'ww-editor__version-author', textContent: author })
		);
		return element('li', {}, [item]);
	});
	return [element('ul', { className: 'ww-editor__nav ww-editor__list' }, rows), note];
}

// Zet de waarden van een eerdere versie als wijziging in de pagina. De wijzigingen van de pagina (niet die van de
// Site-instellingen) worden vervangen, na een vraag als er zijn. Wat de versie niet verandert, blijft ongemoeid.
async function pickVersion(id, date) {
	if (busy || picking) {
		return;
	}
	picking = true;
	fieldsBox.querySelectorAll('[data-ww-version]').forEach((button) => (button.disabled = true));
	try {
		const result = await window.wp.apiFetch({ path: `${data.endpoint}/versions/${id}` });
		// Tijdens het ophalen kan er opgeslagen zijn of de gebruiker de weergave hebben verlaten: dan niets doen.
		if (busy || settings !== 'versions' || viewKind() !== 'settings') {
			return;
		}
		const pageNames = [...changes.keys()].filter((name) => !isSite(name));
		if (pageNames.length > 0 && !window.confirm(strings.versionReplace)) {
			return;
		}
		discardChanges(pageNames);
		const found = versionChanges(fields, result);
		found.forEach(({ value, preview }, name) => {
			if (preview) {
				previews.set(name, preview);
			}
			change(name, value);
		});
		if (found.size === 0) {
			toast(strings.versionSame, 'info');
			renderFields();
			return;
		}
		openChanges();
		toast(strings.versionLoaded.replace('%s', date));
	} catch (error) {
		toast(strings.versionsError, 'error');
	} finally {
		picking = false;
		fieldsBox.querySelectorAll('[data-ww-version]').forEach((button) => (button.disabled = busy));
	}
}

// De weergave Wijzigingen: per gewijzigd veld een regel (het label opent het veld, daaronder de groep, rechts Terugzetten)
// en onderaan Alle wijzigingen weggooien. Zonder wijzigingen alleen "Geen wijzigingen". Tijdens opslaan zijn de knoppen
// uitgeschakeld (data-ww-lock; renderFooter zet dat).
function changesControls() {
	const items = changedFields(changes, fields);
	if (items.length === 0) {
		return [element('p', { className: 'ww-editor__empty', textContent: strings.noChanges })];
	}
	const rows = items.map(({ name, label, group, site }, index) => {
		const open = element('button', { type: 'button', className: 'ww-editor__change-open', onclick: () => openChanged(name) }, [
			element('span', { className: 'ww-editor__change-label', textContent: label }),
			element('span', { className: 'ww-editor__change-group', textContent: site ? strings.site : group }),
		]);
		const undo = iconButton('undo', strings.revertField.replace('%s', label), () => {
			revert(name, { focus: false });
			// De focus naar de regel die op deze plaats is gekomen, anders de vorige; leeg: de kop (zet renderFields al).
			const buttons = fieldsBox.querySelectorAll('.ww-editor__change .ww-editor__item-button');
			buttons[Math.min(index, buttons.length - 1)]?.focus();
		}, busy);
		undo.dataset.wwLock = '';
		return element('li', { className: 'ww-editor__change' }, [open, undo]);
	});
	const discard = element('button', { type: 'button', className: 'button ww-editor__discard', disabled: busy, textContent: strings.discardAll, onclick: confirmDiscard });
	discard.dataset.wwLock = '';
	return [element('ul', { className: 'ww-editor__list ww-editor__changes' }, rows), discard];
}

// Een klik op het label in Wijzigingen: het veld zelf, in de pagina als het daar staat, anders zijn groep.
function openChanged(name) {
	if (marks.has(name)) {
		send({ type: MESSAGE.REVEAL, field: name });
		select({ fields: [name], auto: true });
	} else {
		openGroup(isSite(name) ? 'site' : 'page', groupKeyOf(name), name);
	}
}

// Alle wijzigingen weggooien, na bevestiging: alles terug, het midden naar Op deze pagina en een melding.
function confirmDiscard() {
	const names = [...changes.keys()];
	if (busy || names.length === 0) {
		return;
	}
	const question = names.length === 1 ? strings.discardConfirmOne : strings.discardConfirmMany.replace('%d', String(names.length));
	if (!window.confirm(question)) {
		return;
	}
	discardChanges(names);
	select();
	toast(strings.discarded);
}

// Op deze pagina: de kop met de uitleg en de bewerkbare secties van de pagina in documentvolgorde. Een uitgezette
// sectie is "verborgen", een sectie uit de Site-instellingen "hele site". Een klik zet de sectie in beeld in de pagina
// en opent haar. Daaronder Deze pagina en Hele site (scopes()) en een regel naar het zoekvenster.
function navContent() {
	const head = [
		element('h2', { className: 'ww-editor__heading', tabIndex: -1, textContent: strings.onThisPage }),
		element('p', { className: 'ww-editor__hint', textContent: strings.onThisPageHint }),
	];
	// Voor de eerste READY zijn de secties nog niet bekend; dan ook nog niet "geen secties".
	if (!readyOnce) {
		return [...head, ...scopes()];
	}
	const info = sectionInfo();
	const editable = sections.filter(({ name }) => info[name]?.editable);
	if (editable.length === 0) {
		return [...head, element('p', { className: 'ww-editor__empty', textContent: strings.noSections }), ...scopes()];
	}
	const items = editable.map(({ name }) => {
		const tags = [
			...(info[name].off ? [element('span', { className: 'ww-editor__tag', textContent: strings.hidden })] : []),
			...(info[name].site ? [element('span', { className: 'ww-editor__tag ww-editor__tag--site', textContent: strings.siteShort })] : []),
		];
		const item = viewItem(`section:${name}`, info[name].label, tags, () => {
			send({ type: MESSAGE.REVEAL, section: name });
			select({ section: name });
		});
		item.toggleAttribute('data-ww-off', Boolean(info[name].off));
		return element('li', {}, [item]);
	});
	return [...head, element('ul', { className: 'ww-editor__nav ww-editor__list' }, items), ...scopes()];
}

// Deze pagina en Hele site, met onder elke ingang de groepen die erachter zitten (Titel en adres voor Algemeen), zodat je
// ziet waar een veld staat dat je niet in de pagina kunt aanklikken. Een ingang zonder groepen valt weg, het hele blok
// als er geen ingang overblijft. Het blok komt uit de HTML (de links hebben hun eigen klik) en wordt hergebruikt.
function scopes() {
	if (!scopesBox) {
		return [searchHint()];
	}
	let visible = 0;
	scopesBox.querySelectorAll('[data-ww-editor-scope]').forEach((item) => {
		const source = item.dataset.wwEditorScope;
		const groups = source === 'page' ? pageGroups() : groupsOf('site');
		const note = groupSummary(groups.map(({ key, label }) => (source === 'page' && key === 'general' ? strings.generalGroup : label)));
		item.querySelector('[data-ww-editor-note]').textContent = note;
		item.hidden = groups.length === 0;
		visible += groups.length === 0 ? 0 : 1;
	});
	scopesBox.hidden = visible === 0;
	return [scopesBox, searchHint()];
}

// Onderaan Op deze pagina: wie iets niet vindt, kan zoeken (dezelfde knop als het vergrootglas en Ctrl+K).
function searchHint() {
	const shortcut = /Mac|iPhone|iPad/.test(navigator.platform) ? '⌘K' : 'Ctrl+K';
	return element('p', { className: 'ww-editor__hint ww-editor__search-hint' }, [
		`${strings.cantFind} `,
		element('button', { type: 'button', className: 'button-link', textContent: strings.searchAction, onclick: openSearch }),
		' ',
		element('kbd', { textContent: shortcut }),
	]);
}

// Een regel in een lijst in het midden: het label, eventuele labels rechts en een pijl. key vindt de regel terug als
// de focus er na een stap terug weer heen moet.
function viewItem(key, label, tags, onclick) {
	const node = element('button', { type: 'button', title: label, onclick }, [
		element('span', { className: 'ww-editor__nav-label', textContent: label }),
		...tags,
		element('span', { className: 'dashicons dashicons-arrow-right-alt2 ww-editor__nav-arrow', ariaHidden: 'true' }),
	]);
	node.dataset.wwViewItem = key;
	return node;
}

// Een sectie: de schakelaar, dan de velden die in de pagina staan als links (een klik doet hetzelfde als een klik op
// het element in de pagina), dan de velden die nergens in de pagina staan om direct in te vullen. Een leeg deel
// vervalt met zijn kopje.
function sectionControls(name) {
	const label = sectionLabel(name);
	const toggle = toggleOf(name);
	const onPage = [...marks].filter((field) => field !== toggle && Object.hasOwn(fields, field) && ownerOf(field) === name);
	const rest = sectionFields(name).filter((field) => field !== toggle);
	const links = onPage.map((field) =>
		element('li', {}, [
			viewItem(`field:${field}`, withoutPrefix(fields[field].label, label), [], () => {
				send({ type: MESSAGE.REVEAL, field });
				select({ fields: [field], auto: true });
			}),
		])
	);
	return [
		...siteNotice(sourceOf(name) === 'settings'),
		...(Object.hasOwn(fields, toggle) ? [control(toggle)] : []),
		...(links.length > 0 ? [subhead(strings.inPage), element('ul', { className: 'ww-editor__nav ww-editor__list' }, links)] : []),
		...(rest.length > 0 ? [subhead(strings.notOnPage), ...rest.map((field) => control(field, label))] : []),
	];
}

// De groepen van de Pagina- of Site-instellingen als lijst; een klik opent de groep. Lange namen kappen af, de hele
// naam staat in title.
function groupList(source, groups) {
	return element(
		'ul',
		{ className: 'ww-editor__nav ww-editor__list' },
		groups.map(({ key, label }) => element('li', {}, [viewItem(`group:${source}:${key}`, label, [], () => select({ group: { source, key } }))]))
	);
}

// Een tussenkop; minor is de kleinere binnen een groep in de Pagina-instellingen.
function subhead(text, minor = false) {
	return element(minor ? 'h4' : 'h3', { className: minor ? 'ww-editor__subhead ww-editor__subhead--minor' : 'ww-editor__subhead', textContent: text });
}

// Eerst de velden die in de pagina staan, dan onder een tussenkop de rest; is een van de twee leeg, dan zonder. In de
// Pagina-instellingen met de groepen onder elkaar (nested) is die tussenkop kleiner dan de naam van de groep.
function groupControls(source, key, nested = false) {
	const { onPage, rest } = groupFields(source, key);
	const divider = onPage.length > 0 && rest.length > 0 ? [subhead(strings.notOnPage, nested)] : [];
	return [...siteNotice(source === 'site'), ...onPage.map((name) => control(name)), ...divider, ...rest.map((name) => control(name))];
}

// De melding bovenaan bij een veld, sectie of groep uit de Site-instellingen, met een groene streep links.
function siteNotice(site) {
	if (!site) {
		return [];
	}
	return [element('div', { className: 'ww-editor__site-notice' }, [element('p', { textContent: strings.siteNotice })])];
}

// De kruimelregel: terug (naar de instellingen vanuit een groep, anders naar Op deze pagina), de titel als kop die de
// focus kan krijgen, en bij iets van de site het groene label "Hele site".
function crumb(title, site) {
	const label = strings.backTo.replace('%s', viewKind() === 'group' ? strings[settings] : strings.onThisPage);
	const siteLabel = element('span', { className: 'ww-editor__site-label' }, [element('span', { className: 'dashicons dashicons-admin-site-alt3', ariaHidden: 'true' }), strings.siteLong]);
	return [
		element('button', { type: 'button', className: 'ww-editor__icon-button ww-editor__back', ariaLabel: label, title: label, onclick: back }, [
			element('span', { className: 'dashicons dashicons-arrow-left-alt2', ariaHidden: 'true' }),
		]),
		element('h2', { className: 'ww-editor__crumb-title', tabIndex: -1, title, textContent: title }),
		...(site ? [siteLabel] : []),
	];
}

// Tekent de weergave. Alleen als het midden iets anders gaat tonen, verhuist de focus: na een stap terug naar het item
// waarmee de weergave werd geopend, na een klik in de pagina of het zoekvenster naar het eerste veld, anders naar de
// kop van de kruimelregel. Na opslaan of een nieuwe READY blijft de focus waar hij is.
function renderFields() {
	// Staat de focus in het midden en blijft de weergave dezelfde (een nieuwe READY), dan komt hij daarna terug op
	// hetzelfde item, of op de kop; anders valt hij met het oude midden weg op body.
	const kept = viewKey() === shown && body.contains(document.activeElement) ? openerOf(document.activeElement) : null;
	stopEditors();
	const kind = viewKind();
	const content = panelContent();
	// Het veld dat de focus krijgt, alleen deze keer: na opslaan of een nieuwe READY niet opnieuw.
	const target = focusing;
	focusing = null;
	const auto = autoFocus;
	autoFocus = false;
	const returnTo = returning;
	returning = undefined;
	const key = viewKey();
	const switched = key !== shown;
	shown = key;
	renderSettings();
	crumbBox.hidden = kind === 'nav';
	crumbBox.replaceChildren(...(kind === 'nav' ? [] : crumb(content.title, content.site)));
	fieldsBox.replaceChildren(...content.controls);
	if (switched) {
		body.scrollTop = 0;
	}
	// Is het eerste veld een WYSIWYG-veld, dan geeft TinyMCE het de focus zodra de editor klaar is.
	const first = fieldsBox.querySelector('[data-ww-field]')?.dataset.wwField;
	const firstEditor = auto && switched && [...editors.values()].includes(first) ? first : null;
	editors.forEach((name, id) => startEditor(id, name, name === target || name === firstEditor));
	const box = target ? fieldsBox.querySelector(`[data-ww-field="${CSS.escape(target)}"]`) : null;
	if (box) {
		focusField(box);
	} else if (returnTo !== undefined) {
		focusReturn(returnTo, kind);
	} else if (!switched) {
		if (kept && document.activeElement === document.body) {
			focusReturn(kept, kind);
		}
	} else if (firstEditor) {
		// TinyMCE zet de focus zelf.
	} else if (kind === 'nav') {
		// De weergave bestaat niet meer (na READY) en de focus stond erin: naar de kop.
		if (document.activeElement === document.body) {
			fieldsBox.querySelector('.ww-editor__heading')?.focus();
		}
	} else if (!(auto && focusFirst())) {
		crumbBox.querySelector('h2')?.focus();
	}
}

// Het eerste veld krijgt de focus, als er een is.
function focusFirst() {
	const node = fieldsBox.querySelector(FOCUSABLE);
	node?.focus();
	return Boolean(node);
}

// Na een stap terug: het item waarmee de weergave werd geopend, ook als het opnieuw is getekend; anders de kop van Op
// deze pagina (of van de instellingen, bij terug uit een groep).
function focusReturn(item, kind) {
	const node = item?.element?.isConnected ? item.element : item?.key ? fieldsBox.querySelector(`[data-ww-view-item="${CSS.escape(item.key)}"]`) : null;
	(node || (kind === 'nav' ? fieldsBox.querySelector('.ww-editor__heading') : crumbBox.querySelector('h2')))?.focus();
}

// Het item van de open instellingen krijgt de actieve stijl.
function renderSettings() {
	settingsLinks.forEach((link) => (link.dataset.wwEditorOpen === settings ? link.setAttribute('aria-current', 'true') : link.removeAttribute('aria-current')));
}

// Zet een veld in beeld in het paneel, geeft het de focus en laat het even oplichten. Een veld zonder iets dat de focus
// kan krijgen (een lege relatie), geeft hem aan de kop van de kruimelregel; een WYSIWYG-veld pakt hem daarna zelf.
function focusField(box) {
	box.scrollIntoView({ block: 'nearest', behavior: reducedMotion.matches ? 'auto' : 'smooth' });
	(box.querySelector(FOCUSABLE) || crumbBox.querySelector('h2'))?.focus({ preventScroll: true });
	box.dataset.wwFlash = '';
	setTimeout(() => delete box.dataset.wwFlash, FLASH);
}

// Waarmee een weergave wordt geopend, als dat in het paneel staat: het element, en de sleutel van zijn regel als die
// in het midden staat en dus opnieuw getekend wordt.
function openerOf(node) {
	if (!node || !panel.contains(node)) {
		return null;
	}
	return { element: node, key: node.closest('[data-ww-view-item]')?.dataset.wwViewItem ?? null };
}

// Kiest wat het paneel toont: velden (fields), een sectie, een lijst (list, als bron en naam), een veldgroep (group,
// als { source, key }) of de Pagina- of Site-instellingen (settings). Een element, sectie of lijst kiezen sluit de
// groep en de instellingen; een groep zet settings op zijn bron, zodat terug weet waar het heen moet; niets kiezen
// (select()) toont Op deze pagina. focus noemt een veld dat na het renderen in beeld komt, de focus krijgt en even
// oplicht; auto geeft het eerste veld de focus (een klik in de pagina of het zoekvenster). returnTo is er alleen bij
// een stap terug (back()): wat daarna de focus krijgt.
function select({ fields: names = null, section: sectionName = null, list: listItem = null, group: groupItem = null, settings: source = null, focus = null, auto = false, returnTo } = {}) {
	const opener = openerOf(document.activeElement);
	// De instellingen van de vorige weergave (ook met een groep open), voor wat terug na een groep doet.
	const previousSettings = settings;
	selected = names && names.length > 0 ? names : null;
	section = selected ? null : sectionName;
	list = selected || section ? null : listItem;
	group = selected || section || list ? null : groupItem;
	settings = selected || section || list ? null : (group?.source ?? source);
	focusing = focus;
	autoFocus = auto;
	// Wat de weergave opende, onthouden op haar niveau; een stap terug laat de niveaus eronder staan.
	const depth = DEPTH[viewKind()];
	returning = returnTo;
	if (returnTo !== undefined) {
		returnFocus.length = Math.min(returnFocus.length, depth);
	} else {
		returnFocus = returnFocus.slice(0, Math.max(0, depth - 1));
		// Een groep die niet vanuit zijn instellingen opent (het zoekvenster): wat de instellingen ooit opende, is hier niet
		// meer van toepassing.
		if (depth > 1 && previousSettings !== settings) {
			returnFocus.fill(null);
		}
		if (depth > 0) {
			returnFocus[depth - 1] = opener;
		}
	}
	if (!selected && !section && !list) {
		send({ type: MESSAGE.DESELECT });
	}
	menus.forEach((menu) => menu.close());
	renderFields();
}

// Eén niveau terug: van een groep naar zijn instellingen, van de instellingen of een element, sectie of lijst naar Op
// deze pagina (de pagina heft haar selectie op). De focus gaat naar het item waarmee de weergave werd geopend.
function back() {
	const kind = viewKind();
	if (kind === 'nav') {
		return;
	}
	const returnTo = returnFocus[DEPTH[kind] - 1] ?? null;
	select(kind === 'group' ? { settings, returnTo } : { returnTo });
}

// Een klik op Pagina- of Site-instellingen opent die weergave; een tweede klik op het actieve item gaat terug.
function openSettings(source) {
	select(settings === source ? {} : { settings: source });
}

// Escape gaat één niveau terug als de focus in het paneel staat (ook in een TinyMCE-editor daar) en er geen
// zoekvenster, menu of mediavenster open is. Op Op deze pagina doet Escape niets.
function canGoBack() {
	return viewKind() !== 'nav' && panel.contains(document.activeElement) && !search.isOpen() && !menus.some((menu) => menu.isOpen()) && !mediaOpen();
}

// Of er een mediavenster open is. wp.media laat er een per frame in de DOM staan, verborgen; position: fixed, dus
// offsetParent zegt niets.
function mediaOpen() {
	return [...document.querySelectorAll('.media-modal')].some((modal) => modal.getClientRects().length > 0);
}

/*
 * Zoekvenster.
 */

// Wat het zoekvenster kan vinden: de bewerkbare secties, alle velden (van de pagina en de site), de veldgroepen en de
// andere pagina's (met de URL van hun editor als id).
function searchEntries() {
	const info = sectionInfo();
	const found = sections.filter(({ name }) => info[name]?.editable).map(({ name }) => ({ kind: 'section', id: name, label: info[name].label, detail: strings.sectionKind }));
	Object.keys(fields).forEach((name) => found.push({ kind: isSite(name) ? 'site' : 'page', id: name, label: fields[name].label, detail: fields[name].group || '' }));
	['page', 'site'].forEach((source) => groupsOf(source).forEach(({ key, label }) => found.push({ kind: 'group', id: `${source}:${key}`, label, detail: strings[source === 'site' ? 'site' : 'thisPage'] })));
	pageItems()
		.filter((item) => !item.current && item.id !== VIEW_LIVE && item.id !== DUPLICATE)
		.forEach((item) => found.push({ kind: 'goto', id: item.id, label: item.label, detail: item.detail || '' }));
	return found;
}

// Een resultaat uit het zoekvenster: een sectie of gemarkeerd veld komt in beeld in de pagina en opent zijn weergave,
// een groep opent waar hij in het paneel staat (openGroup()), en een veld dat nergens in de pagina staat opent
// dezelfde weergave als zijn groep, met dat veld in beeld en met de focus.
function pick({ kind, id }) {
	if (kind === 'goto') {
		goTo(id);
		return;
	}
	// Een ingeklapt paneel (of op mobiel de voorbeeldweergave) komt eerst terug, dan pas scrolt de pagina.
	reveal();
	if (kind === 'section') {
		send({ type: MESSAGE.REVEAL, section: id });
		select({ section: id, auto: true });
	} else if (kind === 'group') {
		// De sleutel van een sitegroep is zijn label en kan zelf een dubbele punt hebben.
		const at = id.indexOf(':');
		openGroup(id.slice(0, at), id.slice(at + 1));
	} else if (marks.has(id)) {
		send({ type: MESSAGE.REVEAL, field: id });
		select({ fields: [id], auto: true });
	} else {
		openGroup(kind === 'site' ? 'site' : 'page', groupKeyOf(id), id);
	}
}

// Een veldgroep uit het zoekvenster: een paginagroep van een sectie op de pagina opent die sectie (in beeld in de
// pagina), een andere paginagroep de Pagina-instellingen als die de groepen direct tonen, anders de weergave Groep; een
// groep van de Site-instellingen ook de weergave Groep, met terug naar Site-instellingen. focus: een veld van de groep.
function openGroup(source, key, focus = null) {
	if (source === 'page') {
		const owner = sectionOfGroup(key, pageSectionNames());
		// Een veld van de groep dat niet bij de sectie hoort (op naam), staat niet in de weergave Sectie.
		if (owner && sectionInfo()[owner]?.editable && (!focus || ownerOf(focus) === owner)) {
			send({ type: MESSAGE.REVEAL, section: owner });
			select({ section: owner, focus, auto: true });
			return;
		}
		const groups = pageGroups();
		if (groups.length <= INLINE_GROUPS && groups.some((item) => item.key === key)) {
			select({ settings: 'page', focus, auto: true });
			return;
		}
	}
	select({ group: { source, key }, focus, auto: true });
}

// Opent het zoekvenster, of zet de focus terug in het zoekveld als het al open is. Niet boven de mediabibliotheek.
function openSearch() {
	if (mediaOpen()) {
		return;
	}
	// Een open menu sluit met de focus terug op zijn knop; Escape in het zoekvenster brengt hem daar weer.
	menus.forEach((menu) => menu.isOpen() && menu.close(true));
	search.open();
}

// Ctrl+K / ⌘K, in dit document en in de TinyMCE-editors. WordPress heeft zelf een opdrachtpaneel op Ctrl+K; op dit
// scherm gaat het zoekvenster voor (dat paneel blijft bereikbaar via de adminbalk).
function onSearchShortcut(event) {
	if (!isSearchShortcut(event)) {
		return;
	}
	event.preventDefault();
	event.stopImmediatePropagation();
	openSearch();
}

/*
 * Meldingen en opslaan.
 */

// Een melding onderaan: opgeslagen verdwijnt vanzelf, een fout of waarschuwing blijft tot je hem sluit of opnieuw
// opslaat.
function toast(text, kind = 'success') {
	clearTimeout(toastTimer);
	if (!text) {
		toastsBox.replaceChildren();
		return;
	}
	const parts = [element('span', { className: `dashicons dashicons-${TOAST_ICONS[kind]}`, ariaHidden: 'true' }), element('span', { className: 'ww-editor__toast-text', textContent: text })];
	if (kind === 'success') {
		toastTimer = setTimeout(() => toast(''), 3000);
	} else {
		parts.push(
			element('button', { type: 'button', className: 'button-link', onclick: () => toast('') }, [
				element('span', { className: 'dashicons dashicons-no-alt', ariaHidden: 'true' }),
				element('span', { className: 'screen-reader-text', textContent: strings.close }),
			])
		);
	}
	const node = element('div', { className: 'ww-editor__toast', role: kind === 'success' ? 'status' : 'alert' }, parts);
	node.dataset.wwKind = kind;
	toastsBox.replaceChildren(node);
	if (!reducedMotion.matches) {
		node.animate([{ opacity: 0, transform: 'translateY(12px)' }, { opacity: 1, transform: 'none' }], { duration: 200, easing: 'ease-out' });
	}
}

// Een knop in de voet. De primaire knop krijgt tijdens het opslaan een spinner; Publiceren kan altijd (het slaat ook
// alles op), de andere knoppen alleen met wijzigingen.
function footerButton(text, status, { primary = false, always = false } = {}) {
	const node = element('button', {
		type: 'button',
		className: primary ? 'button button-primary ww-editor__primary' : 'button',
		disabled: busy || (!always && changes.size === 0),
		onclick: () => save(status),
	});
	node.append(...(primary && busy ? [element('span', { className: 'spinner is-active', ariaHidden: 'true' })] : []), text);
	return node;
}

// De voorbeeldlink van een concept: de URL van het iframe zonder de editormodus.
function previewLink() {
	try {
		const url = new URL(post.frame, window.location.href);
		url.searchParams.delete(EDITOR_PARAM);
		return url.href;
	} catch (error) {
		return post.link;
	}
}

// De voet: het label in de kop (Live of Concept), de statusregel (met wijzigingen een knop met de stip die de weergave
// Wijzigingen opent), Bekijk live of Voorbeeld als icoon en de knoppen. Het aantal wijzigingen staat alleen in de
// statusregel. De 404 en de zoekpagina zijn geen bericht: Opslaan, zonder status.
function renderFooter() {
	statusLabel.hidden = Boolean(data.view);
	statusLabel.textContent = data.view ? '' : post.published ? strings.live : strings.draft;
	statusLabel.dataset.wwState = post.published ? 'live' : 'draft';
	const count = changes.size;
	const text = busy ? strings.saving : count ? strings[count === 1 ? 'changesOne' : 'changesMany'].replace('%d', String(count)) : strings.noChanges;
	const state = busy ? 'busy' : count ? 'changed' : 'clean';
	if (text !== statusText || statusBox.dataset.wwState !== state) {
		statusText = text;
		statusBox.dataset.wwState = state;
		// De knop staat in de statusregel, zodat de tekst één keer wordt voorgelezen; zonder wijzigingen is het gewone tekst.
		reviewButton.textContent = text;
		statusBox.replaceChildren(...(state === 'changed' ? [element('span', { className: 'ww-editor__dot', ariaHidden: 'true' }), reviewButton] : [text]));
	}
	fieldsBox.querySelectorAll('.ww-editor__revert, [data-ww-lock]').forEach((button) => (button.disabled = busy || (picking && 'wwVersion' in button.dataset)));
	reviewButton.hidden = state !== 'changed';
	viewLabel.textContent = viewText();
	viewLink.title = viewText();
	viewLink.href = viewHref();
	// Opslaan staat in de voet en op mobiel ook in de balk van de voorbeeldweergave: elk hun eigen knoppen.
	const buttons = () => {
		if (data.view) {
			return [footerButton(strings.save, '', { primary: true })];
		}
		if (post.published) {
			return [footerButton(strings.update, '', { primary: true })];
		}
		if (data.canPublish) {
			return [footerButton(strings.saveDraft, ''), footerButton(strings.publish, 'publish', { primary: true, always: true })];
		}
		return [footerButton(strings.saveDraft, '', { primary: true })];
	};
	// Op mobiel is Voorbeeld een knop die de pagina toont, in plaats van de link Bekijk live.
	const previewButton = element('button', { type: 'button', className: 'button', textContent: strings.preview, onclick: () => setMobileView('preview', true) });
	previewButton.dataset.wwEditorPreview = '';
	actionsBox.replaceChildren(mobile.matches ? previewButton : viewLink, element('span', { className: 'ww-editor__buttons' }, buttons()));
	const editButton = element('button', { type: 'button', className: 'button', textContent: strings.edit, onclick: () => setMobileView('panel', true) });
	editButton.dataset.wwEditorEdit = '';
	mobileBar.replaceChildren(editButton, element('span', { className: 'ww-editor__buttons' }, buttons()));
}

// De tekst en de link van Bekijk live; een concept heeft nog geen live pagina en toont Voorbeeld.
function viewText() {
	return !data.view && !post.published ? strings.preview : strings.viewLive;
}

function viewHref() {
	return !data.view && !post.published ? previewLink() : post.link;
}

// Waar in de voet (of de balk op mobiel) de focus staat: welke container, de primaire knop of de hoeveelste knop of link.
function footerFocusOf(node) {
	const box = [actionsBox, mobileBar].find((other) => other.contains(node));
	if (!box || !node.matches('a, button')) {
		return null;
	}
	return { box, primary: node.matches('.ww-editor__primary'), index: [...box.querySelectorAll('a, button')].indexOf(node) };
}

// renderFooter() tekent de knoppen opnieuw; de focus komt terug op dezelfde knop, anders op de primaire, anders op de
// eerste die nog kan (na opslaan staat Bijwerken uit). Alleen als de focus nergens anders heen is gegaan.
function restoreFooterFocus(place) {
	if (!place || (document.activeElement && document.activeElement !== document.body)) {
		return;
	}
	const controls = [...place.box.querySelectorAll('a, button')];
	const target = place.primary ? place.box.querySelector('.ww-editor__primary') : controls[place.index];
	[target, place.box.querySelector('.ww-editor__primary'), ...controls].find((node) => node && !node.disabled)?.focus();
}

// Wat de gebruiker tijdens het opslaan nog verandert, is niet verstuurd en blijft dus als wijziging staan.
async function save(status) {
	// De eerste renderFooter() hieronder haalt de knop al weg; daarom nu onthouden waar de focus stond.
	const refocus = footerFocusOf(document.activeElement);
	const sent = new Map(changes);
	const body = { fields: {}, settings: {}, post: {}, status, view: data.view };
	// De 404 en de zoekpagina hebben een eigen taal (data.lang); een pagina krijgt de zijne van de server.
	if (data.view) {
		body.lang = data.lang || '';
	}
	sent.forEach((value, name) => {
		if (isSite(name)) {
			body.settings[name.slice(SITE.length)] = value;
		} else {
			(PAGE_FIELDS.includes(name) ? body.post : body.fields)[name] = value;
		}
	});
	busy = true;
	toast('');
	renderFooter();
	try {
		const result = await window.wp.apiFetch({ path: data.endpoint, method: 'POST', data: body });
		post = result.post;
		Object.assign(fields, result.fields);
		addSettings(result.settings);
		Object.values(fields).forEach((field) => remember(field.items || []));
		sent.forEach((value, name) => {
			if (changes.get(name) === value) {
				changes.delete(name);
				previews.delete(name);
			}
		});
		// Opslaan maakt een nieuwe versie: de lijst is verouderd, ook een ronde die nog loopt.
		versionsState = null;
		versionsRequest++;
		toast(strings.saved);
		frame.src = post.frame;
		renderFields();
	} catch (error) {
		toast(error?.message || strings.error, 'error');
	}
	busy = false;
	renderFooter();
	restoreFooterFocus(refocus);
}

/*
 * Berichten van de pagina in het iframe.
 */

window.addEventListener('message', (event) => {
	if (event.source !== frame.contentWindow || event.origin !== data.origin) {
		return;
	}
	const { type } = event.data || {};
	if (type === MESSAGE.READY) {
		marks = new Set((event.data.marks || []).filter((name) => typeof name === 'string'));
		sections = (event.data.sections || []).filter((item) => typeof item?.name === 'string');
		lists = (event.data.lists || []).filter((item) => Number.isInteger(item?.index) && ['relation', 'auto'].includes(item.source) && typeof item.name === 'string');
		readyOnce = true;
		// Welke velden en secties het paneel toont, hangt af van wat de pagina markeert. Na het opslaan staat dezelfde
		// weergave weer open, als ze er nog is. Een open veld blijft staan zoals het is.
		// Een herhaalde READY van dezelfde pagina tekent het paneel niet opnieuw (dat zou een veld in bewerking verstoren).
		const load = typeof event.data.load === 'string' ? event.data.load : null;
		const repeated = load !== null && load === readyLoad;
		readyLoad = load;
		// Een nieuwe pagina laadt nog: de accentkleur en de schaal meteen, niet pas bij load. Het antwoord is een herhaling;
		// alleen met een id, anders zou elk antwoord weer een HELLO uitlokken.
		if (!repeated && load !== null) {
			hello();
		}
		if (repeated) {
			// Niets veranderd in de pagina; alleen het antwoord hieronder.
		} else if ((section && !sectionInfo()[section]?.editable) || (list && listIndex() === null) || (group && !groupExists(group))) {
			select();
		} else if (!selected) {
			renderFields();
		}
		const labels = Object.fromEntries(Object.entries(fields).map(([name, field]) => [name, { label: field.label, type: field.type, site: Boolean(field.site) }]));
		const frameStrings = { hidden: strings.hidden, inSettings: strings.inSettings, siteShort: strings.siteShort };
		// Een herhaling van dezelfde pagina heeft alles al: geen FIELDS opnieuw, want dat zet de scrollpositie terug.
		if (!repeated) {
			send({ type: MESSAGE.FIELDS, fields: labels, strings: frameStrings, sections: sectionInfo(), lists: listInfo(), scroll: scrollY, selected, section, list: listIndex() });
			changes.forEach((value, name) => send({ type: MESSAGE.VALUE, name, value: display(name) }));
		}
	} else if (type === MESSAGE.SELECT) {
		// Een klik in de pagina opent zijn weergave, ook als de Pagina- of Site-instellingen open staan (select()).
		reveal();
		select({ fields: (event.data.fields || []).filter((name) => Object.hasOwn(fields, name)), auto: true });
	} else if (type === MESSAGE.SECTION) {
		if (sectionInfo()[event.data.name]?.editable) {
			reveal();
			select({ section: event.data.name, auto: true });
		}
	} else if (type === MESSAGE.LIST) {
		const item = lists.find((other) => other.index === event.data.index);
		if (item && listLabel(item) !== null) {
			reveal();
			select({ list: { source: item.source, name: item.name }, auto: true });
		}
	} else if (type === MESSAGE.SCROLL) {
		scrollY = Number(event.data.y) || 0;
	} else if (type === MESSAGE.SEARCH) {
		openSearch();
	}
});

// Het voorbeeld rendert op de breedte van het venster (of 768 of 375 bij Tablet en Mobiel) en schaalt naar het vlak.
// De pagina rekent zelf in paginacoördinaten (editor-frame.js), dus hier is alleen de transform nodig.
const DEVICE_WIDTHS = { tablet: 768, mobile: 375 };
const zoomRow = root.querySelector('[data-ww-editor-zoom]');
let zoom = 'fit';
try {
	zoom = localStorage.getItem('ww-editor-zoom') === '100' ? '100' : 'fit';
} catch (error) {
	// Zonder opslag blijft het Passend.
}
let zoomToggle;
let zoomText;

// Rechts naast het schermformaat: op Desktop met iets te schalen een menuknop Passend / 100% (met de schaal in de knop),
// anders alleen de breedte en de schaal als tekst. Zo staat er altijd iets en springt de rij niet. Eén keer gebouwd;
// applyPreview() werkt bij.
function buildZoomRow() {
	zoomToggle = element('button', { type: 'button', className: 'ww-editor__zoom-button' }, [
		element('span', { className: 'ww-editor__zoom-label' }),
		element('span', { className: 'dashicons dashicons-arrow-down-alt2 ww-editor__caret', ariaHidden: 'true' }),
	]);
	zoomToggle.setAttribute('aria-haspopup', 'menu');
	zoomText = element('span', { className: 'ww-editor__zoom-text' });
	const container = element('div', { hidden: true });
	zoomRow.append(zoomText, zoomToggle, container);
	menus.push(
		menuButton(zoomToggle, container, {
			items: () => [
				{ id: 'fit', label: strings.fit, detail: `${Math.round(fitScale * 100)}%`, current: zoom === 'fit' },
				{ id: '100', label: strings.fullSize, current: zoom === '100' },
			],
			onPick: (value) => {
				zoom = value;
				try {
					localStorage.setItem('ww-editor-zoom', value);
				} catch (error) {
					// De keuze geldt dan alleen voor deze sessie.
				}
				applyPreview();
				zoomToggle.focus();
			},
		})
	);
}

// De schaal waarmee Passend het voorbeeld zou tonen, ook als 100% gekozen is: het menu noemt hem.
let fitScale = 1;

function applyPreview() {
	// Mobiel kent geen schermformaat: je ziet de pagina al op je telefoon.
	const device = mobile.matches ? '' : root.querySelector('[data-ww-device][aria-pressed="true"]')?.dataset.wwDevice || '';
	// Ingeklapt en op mobiel vult de pagina het hele vlak, op schaal 1 en zonder marge.
	const collapsed = root.dataset.wwCollapsed === 'true' || mobile.matches;
	const available = canvas.clientWidth;
	const height = canvas.clientHeight;
	const viewport = DEVICE_WIDTHS[device] || window.innerWidth;
	let scale = 1;
	let mode = 'fit';
	if (collapsed) {
		mode = '';
		frame.style.width = frame.style.height = frame.style.transform = '';
	} else {
		let x = 0;
		let y = 0;
		let frameHeight = height;
		if (device === '' && zoom === '100') {
			mode = '100';
		} else {
			scale = previewScale({ viewport, available });
			x = device === '' ? PREVIEW_MARGIN : Math.max(PREVIEW_MARGIN, (available - viewport * scale) / 2);
			y = PREVIEW_MARGIN;
			frameHeight = (height - 2 * PREVIEW_MARGIN) / scale;
		}
		frame.style.width = `${viewport}px`;
		frame.style.height = `${frameHeight}px`;
		frame.style.transform = `translate(${x}px, ${y}px) scale(${scale})`;
	}
	canvas.dataset.wwZoom = mode;
	canvas.dataset.wwDevice = device;
	if (scale !== currentScale) {
		currentScale = scale;
		send({ type: MESSAGE.SCALE, scale });
	}
	if (!zoomToggle) {
		buildZoomRow();
	}
	fitScale = previewScale({ viewport, available });
	// De breedte staat in de tooltip van het schermformaat; Desktop volgt het venster.
	root.querySelectorAll('[data-ww-device]').forEach((toggle) => {
		const key = toggle.dataset.wwDevice;
		const text = (key === 'mobile' ? strings.mobileWidth : key === 'tablet' ? strings.tabletWidth : strings.desktopWidth).replace('%d', String(DEVICE_WIDTHS[key] || window.innerWidth));
		toggle.title = text;
		toggle.setAttribute('aria-label', text);
	});
	// Passend / 100% kiest alleen op Desktop, en alleen als er iets te schalen valt.
	const choice = device === '' && (zoom === '100' || scale < 1);
	const label = zoomLabel({ choice, zoom, scale, viewport, strings });
	zoomToggle.hidden = !choice;
	zoomText.hidden = choice;
	zoomToggle.firstChild.textContent = label;
	zoomToggle.setAttribute('aria-label', `${strings.zoom}: ${label}`);
	zoomText.textContent = label;
	zoomRow.hidden = collapsed;
}

root.querySelectorAll('[data-ww-device]').forEach((toggle, index, all) => {
	toggle.addEventListener('click', () => {
		all.forEach((other) => other.setAttribute('aria-pressed', String(other === toggle)));
		applyPreview();
	});
});
window.addEventListener('resize', applyPreview);
new ResizeObserver(applyPreview).observe(canvas);

/*
 * Inklappen (desktop) en de twee weergaven op mobiel.
 */

// Zet het paneel in of uit beeld en onthoudt dat per browser; applyPreview() maakt de pagina dan volle breedte (schaal 1).
function setCollapsed(collapsed, { focus = false } = {}) {
	if (collapsed) {
		root.dataset.wwCollapsed = 'true';
	} else {
		delete root.dataset.wwCollapsed;
	}
	try {
		localStorage.setItem('ww-editor-collapsed', collapsed ? 'true' : 'false');
	} catch (error) {
		// De stand geldt dan alleen voor deze sessie.
	}
	syncCollapse();
	if (focus) {
		(collapsed ? expandButton : collapseButton).focus();
	}
	applyPreview();
}

// De knop Paneel tonen staat er alleen als het paneel is ingeklapt; op mobiel bestaat inklappen niet.
function syncCollapse() {
	expandButton.hidden = !(root.dataset.wwCollapsed === 'true' && !mobile.matches);
	expandButton.setAttribute('aria-expanded', 'false');
	collapseButton.setAttribute('aria-expanded', String(!(root.dataset.wwCollapsed === 'true' && !mobile.matches)));
}

// Op mobiel: 'panel' (het paneel, de hele pagina) of 'preview' (de pagina met onderin een balk). De focus verhuist alleen
// als de gebruiker er zelf om vroeg (een knop), niet bij een klik in de pagina.
function setMobileView(view, focus = false) {
	if (!mobile.matches) {
		delete root.dataset.wwMobileView;
		return;
	}
	root.dataset.wwMobileView = view;
	applyPreview();
	if (focus) {
		root.querySelector(view === 'preview' ? '[data-ww-editor-edit]' : '[data-ww-editor-preview]')?.focus();
	}
}

// Een klik in de pagina op een element, sectie of lijst: het paneel komt terug, ingeklapt of (mobiel) verborgen.
function reveal() {
	const hidden = mobile.matches ? root.dataset.wwMobileView === 'preview' : root.dataset.wwCollapsed === 'true';
	if (!hidden) {
		return;
	}
	// Het paneel komt in beeld, ook met dezelfde weergave als toen het verdween: dan hoort de focus alsnog naar het eerste veld.
	shown = '';
	if (mobile.matches) {
		setMobileView('panel');
	} else {
		setCollapsed(false);
	}
}

collapseButton.addEventListener('click', () => setCollapsed(true, { focus: true }));
expandButton.addEventListener('click', () => setCollapsed(false, { focus: true }));
try {
	if (localStorage.getItem('ww-editor-collapsed') === 'true') {
		root.dataset.wwCollapsed = 'true';
	}
} catch (error) {
	// Zonder opslag begint het paneel open.
}
syncCollapse();
setMobileView('panel');
// Wisselt het venster over het breekpunt, dan kloppen de voet (Voorbeeld of Bekijk live) en het menu weer.
mobile.addEventListener('change', () => {
	syncCollapse();
	setMobileView('panel');
	renderFooter();
	applyPreview();
});
applyPreview();

// De pagina meldt zich met READY als antwoord op HELLO; het kan zijn dat het iframe al geladen is voordat hij luistert.
// Een nieuwe pagina (ook na opslaan) herkent het paneel aan haar LOAD_ID, niet aan deze load: haar eerste READY komt
// meestal al eerder.
frame.addEventListener('load', hello);
hello();
settingsLinks.forEach((link) =>
	link.addEventListener('click', (event) => {
		event.preventDefault();
		openSettings(link.dataset.wwEditorOpen);
	})
);
reviewButton.addEventListener('click', openChanges);
searchButton?.addEventListener('click', openSearch);
// In de capture-fase op window, zodat het opdrachtpaneel van WordPress de sneltoets niet ook krijgt.
window.addEventListener('keydown', onSearchShortcut, { capture: true });

// Escape sluit alleen het bovenste: het mediavenster, het zoekvenster en een open menu vangen hun eigen Escape
// (editor-search.js, editor-menu.js), anders gaat het paneel één niveau terug (canGoBack()).
document.addEventListener('keydown', (event) => {
	if (event.key === 'Escape' && canGoBack()) {
		event.preventDefault();
		back();
	}
});

window.addEventListener('beforeunload', (event) => {
	if (changes.size > 0 && !leaving) {
		event.preventDefault();
		event.returnValue = strings.leave;
	}
});

addSettings(data.settings);
Object.values(fields).forEach((field) => remember(field.items || []));
renderFields();
renderFooter();
if (data.lockedBy) {
	toast(strings.locked.replace('%s', data.lockedBy), 'warning');
} else if (data.view) {
	toast(strings.viewHint, 'info');
}
// Wat een net gemaakte vertaling niet heeft overgenomen gaat voor de andere meldingen, en daarna wat er bij het
// dupliceren niet meeging.
if (!showDropped() && Array.isArray(data.copyDropped) && data.copyDropped.length > 0) {
	toast(strings.notCopied.replace('%s', data.copyDropped.join(', ')), 'warning');
}
