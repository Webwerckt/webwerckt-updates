<?php
/**
 * Meertalig vertaalwerk (beslissing 0041): een vertaling maken als concept, en de vergelijking met de bron.
 *
 * Eén functie, _ww_translation_create(), doet het werk voor de ability create-translation, de editor en de metabox:
 * ze maakt een concept in de doeltaal, koppelt de groep (de kern) en kopieert de velden zoals update-fields ze schrijft
 * (via Pods, met _ww_post_copy() uit post-copy.php). De bron van een groep is het bericht in de standaardtaal; er wordt niets extra bewaard om te weten of de
 * bron later is gewijzigd: de twee wijzigingsdatums bestaan al.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Mag de huidige gebruiker van dit bericht een vertaling maken? edit_post op de bron en edit_posts van het post type.
 */
function _ww_translation_can_create( int $source_id ): bool {
	$type = get_post_type_object( (string) get_post_type( $source_id ) );
	// Een formulier vraagt de rechten van formulieren (0032): edit_others_pages.
	return $type instanceof WP_Post_Type && current_user_can( 'edit_post', $source_id ) && current_user_can( $type->cap->edit_posts )
		&& ( WW_FORM_POST_TYPE !== $type->name || current_user_can( 'edit_others_pages' ) );
}

/**
 * Het bericht in de standaardtaal van de groep, of 0 (voor het bericht in de standaardtaal zelf, een groep zonder
 * bericht in de standaardtaal en een bericht zonder taal).
 */
function _ww_translation_source_id( int $post_id ): int {
	$lang = _ww_post_language( $post_id );
	if ( '' === $lang || _ww_default_language() === $lang ) {
		return 0;
	}
	return _ww_translations( $post_id )[ _ww_default_language() ] ?? 0;
}

/**
 * Is de bron later gewijzigd dan dit bericht? False zonder bron.
 */
function _ww_translation_source_newer( int $post_id ): bool {
	$source = _ww_translation_source_id( $post_id );
	return $source > 0 && get_post_field( 'post_modified_gmt', $source ) > get_post_field( 'post_modified_gmt', $post_id );
}

/**
 * De andere leden van de groep, per taalcode: ID, status, laatste wijziging (ISO 8601) en of de bron nieuwer is.
 *
 * @return array<string,array{id:int,status:string,modified:string,source_newer:bool}>
 */
function _ww_translation_overview( int $post_id ): array {
	$overview = array();
	foreach ( _ww_translations( $post_id ) as $lang => $id ) {
		if ( $id === $post_id ) {
			continue;
		}
		$overview[ $lang ] = array(
			'id'           => $id,
			'status'       => (string) get_post_status( $id ),
			'modified'     => (string) get_post_modified_time( 'c', true, $id ),
			'source_newer' => _ww_translation_source_newer( $id ),
		);
	}
	return $overview;
}

/**
 * Het bericht in een taal dat bij dit bericht hoort (elke status behalve prullenbak), of 0.
 */
function _ww_translation_target( int $post_id, string $lang ): int {
	$id = _ww_translations( $post_id )[ $lang ] ?? 0;
	return $id > 0 && ! in_array( get_post_status( $id ), array( false, 'trash' ), true ) ? $id : 0;
}

/**
 * De ID's van een relatie in de doeltaal: een bericht van een niet-vertaalbaar post type blijft, de rest wordt zijn
 * vertaling. Zonder vertaling, of als het bericht verwijderd is of in de prullenbak ligt, valt het weg en komt het in
 * $dropped. De volgorde blijft.
 *
 * @param int[]                                 $ids     ID's in de bron.
 * @param string                                $lang    Doeltaal.
 * @param string                                $field   Veldnaam, voor $dropped.
 * @param array<int,array{field:string,id:int}> $dropped Wat wegvalt (wordt aangevuld).
 * @return int[]
 */
function _ww_translation_map_relation( array $ids, string $lang, string $field, array &$dropped ): array {
	$mapped = array();
	foreach ( $ids as $id ) {
		$type = get_post_type( $id );
		// Een formulier houdt altijd het ID van de bron, ook in de prullenbak: _ww_form_resolve() kiest bij het tonen.
		if ( WW_FORM_POST_TYPE === $type || ( false !== $type && ! _ww_is_translatable( $type ) && 'trash' !== get_post_status( $id ) ) ) {
			$mapped[] = $id;
			continue;
		}
		$target = false !== $type && _ww_is_translatable( $type ) ? _ww_translation_target( $id, $lang ) : 0;
		if ( $target > 0 ) {
			$mapped[] = $target;
		} else {
			$dropped[] = array(
				'field' => $field,
				'id'    => $id,
			);
		}
	}
	return $mapped;
}

/**
 * De toegestane waarden van een keuzeveld met een vaste lijst (pick_custom: "waarde|label" per regel).
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @return string[]
 */
function _ww_translation_pick_keys( array $field ): array {
	$custom = $field['pick_custom'] ?? '';
	$lines  = is_array( $custom ) ? $custom : preg_split( '/\R/', _ww_data_to_string( $custom ) );
	$keys   = array();
	foreach ( false === $lines ? array() : $lines as $line ) {
		$key = trim( explode( '|', _ww_data_to_string( $line ) )[0] );
		if ( '' !== $key ) {
			$keys[] = $key;
		}
	}
	return $keys;
}

/**
 * Maakt een vertaling van een bericht als concept, in een extra taal.
 *
 * @param int                  $source_id Bericht om van te vertalen (mag zelf een vertaling zijn).
 * @param string               $lang      Doeltaal: een extra taal uit de optie.
 * @param array<string,string> $args      title en slug (optioneel, al vertaald); anders die van de bron.
 * @return array{id:int,lang:string,source_id:int,status:string,edit_url:string,dropped:array<int,array{field:string,id:int}>}|WP_Error
 */
function _ww_translation_create( int $source_id, string $lang, array $args = array() ): array|WP_Error {
	if ( ! _ww_languages_active() ) {
		return new WP_Error( 'ww_languages_inactive', __( 'Meertalig staat niet aan.', 'webwerckt-base' ), array( 'status' => 400 ) );
	}
	if ( ! in_array( $lang, _ww_extra_language_codes(), true ) ) {
		return new WP_Error( 'ww_translation_lang', __( 'Kies een extra taal; de standaardtaal heeft geen vertaling nodig.', 'webwerckt-base' ), array( 'status' => 400 ) );
	}
	$source = get_post( $source_id );
	if ( ! $source instanceof WP_Post ) {
		return new WP_Error( 'ww_translation_source', __( 'Het bericht om te vertalen bestaat niet.', 'webwerckt-base' ), array( 'status' => 404 ) );
	}
	if ( ! _ww_is_translatable( $source->post_type ) ) {
		return new WP_Error( 'ww_translation_type', __( 'Dit soort inhoud is niet vertaalbaar.', 'webwerckt-base' ), array( 'status' => 400 ) );
	}
	$existing = _ww_translation_target( $source_id, $lang );
	if ( $existing > 0 ) {
		return new WP_Error(
			'ww_translation_exists',
			__( 'Er is al een vertaling in deze taal.', 'webwerckt-base' ),
			array(
				'status' => 400,
				'id'     => $existing,
			)
		);
	}

	$dropped = array();
	$parent  = 0;
	if ( $source->post_parent > 0 ) {
		$parent_type = get_post_type( $source->post_parent );
		$parent      = false !== $parent_type && ! _ww_is_translatable( $parent_type ) ? $source->post_parent : _ww_translation_target( $source->post_parent, $lang );
		if ( 0 === $parent ) {
			$dropped[] = array(
				'field' => 'post_parent',
				'id'    => $source->post_parent,
			);
		}
	}

	$title  = isset( $args['title'] ) && '' !== trim( $args['title'] ) ? $args['title'] : $source->post_title;
	$slug   = isset( $args['slug'] ) && '' !== trim( $args['slug'] ) ? sanitize_title( $args['slug'] ) : $source->post_name;
	$copied = _ww_post_copy(
		$source,
		'translation',
		array(
			'title'        => $title,
			'slug'         => $slug,
			'parent'       => $parent,
			'lang'         => $lang,
			'after_insert' => static fn( int $id ): true|WP_Error => _ww_link_translation( $source_id, $id ),
		)
	);
	if ( is_wp_error( $copied ) ) {
		return $copied;
	}
	$new     = $copied['id'];
	$dropped = array_merge( $dropped, $copied['dropped'] );
	$target  = get_post( $new );

	$edit_url = $target instanceof WP_Post && _ww_editor_supports( $target )
		? _ww_editor_url( $new )
		: ( get_edit_post_link( $new, 'raw' ) ?? admin_url( 'post.php?post=' . $new . '&action=edit' ) );

	return array(
		'id'        => $new,
		'lang'      => $lang,
		'source_id' => _ww_translation_source_id( $new ),
		'status'    => 'draft',
		'edit_url'  => $edit_url,
		'dropped'   => $dropped,
	);
}
