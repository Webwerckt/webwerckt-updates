<?php
/**
 * Helpers voor child-thema's. Alle uitvoer is hier al ge-escaped.
 *
 * Een helper geeft altijd de afgesproken lege waarde terug, nooit een fatal error:
 * '' voor tekst, 0 voor een foto, array() voor een relatie.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tekstveld als veilige HTML-string (wp_kses_post). Voor gebruik tussen tags.
 *
 * @param string $name    Veldnaam.
 * @param int    $post_id Bericht-ID; 0 is het huidige bericht.
 */
function ww_field( string $name, int $post_id = 0 ): string {
	return wp_kses_post( _ww_data_to_string( _ww_data_get( $name, $post_id ) ) );
}

/**
 * Meerregelig tekstveld of WYSIWYG-veld als HTML, voor gebruik tussen blokelementen. Doet wat WordPress met
 * de inhoud van een bericht doet, in dezelfde volgorde:
 *
 * - een video-link op een eigen regel wordt een embed (YouTube, Vimeo);
 * - alinea's (Pods bewaart WYSIWYG-tekst zonder <p>-tags en voegt die pas toe bij de eigen weergave);
 * - shortcodes, bijvoorbeeld een formulier;
 * - foto's uit de mediabibliotheek krijgen srcset, sizes, breedte, hoogte en loading="lazy".
 * - een foto die naar zijn eigen mediabestand linkt, opent groot in de lightbox (inc/lightbox.php).
 *
 * Shortcodes en embeds draaien na wp_kses_post(), anders zou die hun iframes en formulieren weghalen.
 *
 * @param string $name    Veldnaam.
 * @param int    $post_id Bericht-ID; 0 is het huidige bericht.
 */
function ww_text( string $name, int $post_id = 0 ): string {
	global $wp_embed;

	$html = ww_field( $name, $post_id );
	if ( '' === $html ) {
		return '';
	}
	if ( $wp_embed instanceof WP_Embed ) {
		$html = $wp_embed->autoembed( $wp_embed->run_shortcode( $html ) );
	}
	$html = do_shortcode( shortcode_unautop( wpautop( $html ) ) );
	return _ww_lightbox_content( wp_filter_content_tags( $html, 'ww_text' ) );
}

/**
 * Tekstveld als ge-escapete URL, voor href en src.
 */
function ww_url( string $name, int $post_id = 0 ): string {
	return esc_url( _ww_data_to_string( _ww_data_get( $name, $post_id ) ) );
}

/**
 * Tekstveld ge-escaped voor gebruik in een attribuut.
 */
function ww_attr( string $name, int $post_id = 0 ): string {
	return esc_attr( _ww_data_to_string( _ww_data_get( $name, $post_id ) ) );
}

/**
 * Foto-veld als attachment-ID (0 als er geen foto is).
 */
function ww_image_id( string $name, int $post_id = 0 ): int {
	return _ww_data_to_attachment_id( _ww_data_get( $name, $post_id ) );
}

/**
 * Foto-veld als <img> met srcset, sizes, breedte en hoogte.
 *
 * In Visueel bewerken is de foto van de bewerkte pagina aan te klikken, en staat er een leeg vlak als er nog
 * geen foto is (inc/editor.php).
 *
 * @param string               $name    Veldnaam.
 * @param string               $size    Geregistreerd afbeeldingsformaat.
 * @param array<string,string|bool> $attr   Extra attributen, bijvoorbeeld class en alt, en 'lightbox' (zie ww_image_by_id()).
 * @param int                  $post_id Bericht-ID; 0 is het huidige bericht.
 * @param bool                 $hero    Hero-afbeelding: eager laden met hoge prioriteit.
 */
function ww_image( string $name, string $size = 'large', array $attr = array(), int $post_id = 0, bool $hero = false ): string {
	$attachment_id = ww_image_id( $name, $post_id );
	if ( _ww_editor_marks( $post_id ) ) {
		$attr = array( 'data-ww-edit' => sanitize_key( $name ) ) + $attr;
		if ( $attachment_id <= 0 ) {
			unset( $attr['lightbox'] );
			return _ww_editor_image_placeholder( $size, $attr );
		}
	}
	return ww_image_by_id( $attachment_id, $size, $attr, $hero );
}

/**
 * Meerdere-foto's-veld als array met attachment-ID's, in de volgorde van het veld. Alleen bijlagen die bestaan en
 * een afbeelding zijn.
 *
 * @param string $name    Veldnaam.
 * @param int    $post_id Bericht-ID; 0 is het huidige bericht.
 * @return int[]
 */
function ww_image_ids( string $name, int $post_id = 0 ): array {
	$ids = _ww_data_to_ids( _ww_data_get( $name, $post_id ) );
	return array_values( array_filter( $ids, 'wp_attachment_is_image' ) );
}

/**
 * Zelfde als ww_image(), maar voor een attachment-ID (bijvoorbeeld de uitgelichte afbeelding).
 * Zijn er AVIF- of WebP-versies, dan komt de <img> in een <picture> (inc/images.php).
 *
 * Met de sleutel 'lightbox' in $attr opent de foto groot in een dialoog (inc/lightbox.php): true is een losse foto,
 * een tekst is de naam van een groep foto's die samen bladeren. Het onderschrift komt uit de mediabibliotheek.
 * Zonder de sleutel, of met false, is de uitvoer ongewijzigd.
 *
 * @param array<string,string|bool> $attr
 */
function ww_image_by_id( int $attachment_id, string $size = 'large', array $attr = array(), bool $hero = false ): string {
	if ( $attachment_id <= 0 ) {
		return '';
	}
	$lightbox = $attr['lightbox'] ?? false;
	unset( $attr['lightbox'] );
	if ( $hero ) {
		$attr += array(
			'loading'       => 'eager',
			'fetchpriority' => 'high',
		);
	}
	$html = _ww_images_picture( wp_get_attachment_image( $attachment_id, $size, false, $attr ), $attachment_id );
	if ( ! $lightbox ) {
		return $html;
	}
	$alt = isset( $attr['alt'] ) ? (string) $attr['alt'] : (string) get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
	return _ww_lightbox_link(
		$html,
		$attachment_id,
		is_string( $lightbox ) ? sanitize_key( $lightbox ) : '',
		_ww_lightbox_caption_text( (string) wp_get_attachment_caption( $attachment_id ) ),
		$alt
	);
}

/**
 * Relatieveld als array met post-ID's, alleen van items die bezoekers mogen zien.
 *
 * @return int[]
 */
function ww_related( string $name, int $post_id = 0 ): array {
	$ids = _ww_data_to_ids( _ww_data_get( $name, $post_id ) );
	// Alle items, velden en termen in een paar query's, in plaats van een query per item.
	_prime_post_caches( $ids );
	$ids = array_values( array_filter( $ids, '_ww_data_is_published' ) );
	_ww_prime_thumbnails( $ids );

	// De pagina toont deze items, ook als het child-thema hun velden direct leest in plaats van via ww_card():
	// wijzigt een item, dan moet de pagina uit de cache.
	foreach ( array_unique( array_map( 'get_post_type', $ids ) ) as $post_type ) {
		do_action( 'ww_shows_post_type', (string) $post_type );
	}
	// In Visueel bewerken weet de editor zo bij welk veld de kaarten horen (ADR 0019).
	_ww_editor_add_list( 'relation', sanitize_key( $name ), $ids, $post_id );
	return $ids;
}

/**
 * Laadt vóór het template de items van alle relatievelden van de pagina in één keer: berichten, velden, termen en
 * uitgelichte afbeeldingen. Anders doet elke ww_related() dat apart, en kost elke sectie met een relatie twee tot
 * vier query's; nu vindt ww_related() alles in de cache. Welke velden een relatie zijn, staat in de
 * configuratiebestanden van Pods, dus dit werkt ook zonder actieve Pods.
 */
function _ww_prime_related(): void {
	$post_id = is_singular() ? (int) get_queried_object_id() : 0;
	if ( $post_id <= 0 || post_password_required( $post_id ) ) {
		return;
	}

	$ids = array();
	foreach ( _ww_pods_fields( (string) get_post_type( $post_id ), $post_id ) as $field ) {
		if ( _ww_field_is_post_relation( $field ) ) {
			$name = _ww_data_to_string( $field['name'] ?? '' );
			array_push( $ids, ..._ww_data_to_ids( _ww_data_get_stored( $name, $post_id ) ) );
		}
	}
	$ids = array_values( array_unique( $ids ) );
	if ( array() === $ids ) {
		return;
	}
	_prime_post_caches( $ids );
	_ww_prime_thumbnails( array_values( array_filter( $ids, '_ww_data_is_published' ) ) );
}
add_action( 'template_redirect', '_ww_prime_related' );

/**
 * Site-instelling als veilige HTML-string.
 */
function ww_setting( string $name ): string {
	return wp_kses_post( _ww_setting_string( $name ) );
}

/**
 * Site-instelling als ge-escapete URL.
 */
function ww_setting_url( string $name ): string {
	return esc_url( _ww_setting_string( $name ) );
}

/**
 * Site-instelling als attachment-ID.
 */
function ww_setting_image_id( string $name ): int {
	return _ww_data_to_attachment_id( _ww_data_get_setting( $name ) );
}
