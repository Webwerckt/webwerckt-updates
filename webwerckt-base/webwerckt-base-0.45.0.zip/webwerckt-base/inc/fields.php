<?php
/**
 * De veldlaag van de abilities (inc/abilities.php) en Visueel bewerken (inc/editor.php): welke velden een bericht en
 * de Site-instellingen hebben, hun waarde als gewone waarde, de controle van nieuwe waarden en het opslaan via Pods.
 *
 * - Een bericht krijgt alleen de velden die in de admin bij zijn paginatemplate staan, de Site-instellingen alleen
 *   de velden die de gebruiker mag bewerken. Velden met restrict_capability verbergt Pods in zijn eigen schermen;
 *   hier vallen ze ook weg.
 * - Onbekende velden en verkeerde waarden worden geweigerd, nog voordat er iets is opgeslagen.
 * - Schrijven loopt via Pods (de invoerlaag), zodat de validatie van Pods meedoet.
 *
 * De foutcodes beginnen met ww_abilities_: ze zijn deel van de antwoorden van de abilities (semver).
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * Welke velden.
 */

/**
 * Velden van een bericht bij zijn template, op naam.
 *
 * @return array<string,array<string,mixed>>
 */
function _ww_fields_for_post( WP_Post $post ): array {
	$fields = array_filter( _ww_pods_fields( $post->post_type, $post->ID ), static fn( array $field ): bool => ! _ww_field_restricted( $field ) );
	return array_column( $fields, null, 'name' );
}

/**
 * Velden van de Site-instellingen die de gebruiker mag bewerken, op naam. Elk veld heeft zijn instellingen-pod als
 * `pod` en het label van zijn groep als `group`.
 *
 * @return array<string,array<string,mixed>>
 */
function _ww_fields_for_settings(): array {
	$admin  = current_user_can( 'edit_theme_options' );
	$fields = array_filter(
		_ww_pods_setting_fields(),
		static fn( array $field ): bool => ( $admin || current_user_can( 'pods_edit_' . _ww_data_to_string( $field['pod'] ?? '' ) ) ) && ! _ww_field_restricted( $field )
	);
	return array_column( $fields, null, 'name' );
}

/**
 * Is dit veld afgeschermd voor de huidige gebruiker? Pods kent per veld restrict_capability met capability_allowed
 * (een of meer rechten, gescheiden door komma's; één ervan is genoeg). Pods verbergt zo'n veld in zijn eigen
 * schermen; de abilities en de editor gebruiken dit om hetzelfde te doen.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 */
function _ww_field_restricted( array $field ): bool {
	if ( 1 !== (int) ( $field['restrict_capability'] ?? 0 ) ) {
		return false;
	}
	$caps = array_filter( array_map( 'trim', explode( ',', _ww_data_to_string( $field['capability_allowed'] ?? '' ) ) ) );
	foreach ( $caps as $cap ) {
		if ( current_user_can( $cap ) ) {
			return false;
		}
	}
	return true;
}

/*
 * Soorten velden.
 */

/**
 * Is dit veld er een met meerdere waarden (relatie of bestanden)?
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 */
function _ww_fields_is_multi( array $field ): bool {
	$format = 'pick' === ( $field['type'] ?? '' ) ? ( $field['pick_format_type'] ?? 'single' ) : ( $field['file_format_type'] ?? 'single' );
	return 'multi' === $format;
}

/**
 * Is dit veld een relatie met berichten? Alleen die zijn te bewerken; Pods kent ook relaties met gebruikers,
 * termen en meer.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 */
function _ww_field_is_post_relation( array $field ): bool {
	return 'pick' === ( $field['type'] ?? '' ) && 'post_type' === ( $field['pick_object'] ?? '' );
}

/**
 * Mag dit bericht in een relatie met dit post type staan? Het bestaat, heeft dat type en ligt niet in de prullenbak.
 *
 * @param mixed $post Bericht, bijvoorbeeld uit get_post().
 */
function _ww_is_relatable_post( $post, string $post_type ): bool {
	return $post instanceof WP_Post && $post_type === $post->post_type && 'trash' !== $post->post_status;
}

/*
 * Lezen.
 */

/**
 * Opgeslagen waarde als gewone waarde: ID's voor relaties en foto's, bool voor ja/nee, anders tekst.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @param mixed               $raw   Opgeslagen waarde.
 * @return mixed
 */
function _ww_fields_value( array $field, $raw ) {
	$type = _ww_data_to_string( $field['type'] ?? '' );
	if ( 'pick' === $type || 'file' === $type ) {
		$ids = _ww_data_to_ids( $raw );
		return _ww_fields_is_multi( $field ) ? $ids : ( $ids[0] ?? 0 );
	}
	if ( 'boolean' === $type ) {
		return _ww_data_to_bool( $raw );
	}
	return _ww_data_to_string( $raw );
}

/**
 * Een veld met label, type en waarde, en bij een relatie of bestand of het meerdere waarden heeft. De abilities en
 * de editor vullen dit aan met wat zij nodig hebben.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @param mixed               $raw   Opgeslagen waarde.
 * @return array<string,mixed>
 */
function _ww_fields_describe( array $field, $raw ): array {
	$item = array(
		'label' => _ww_data_to_string( $field['label'] ?? '' ),
		'type'  => _ww_data_to_string( $field['type'] ?? '' ),
		'value' => _ww_fields_value( $field, $raw ),
	);
	if ( in_array( $item['type'], array( 'pick', 'file' ), true ) ) {
		$item['multiple'] = _ww_fields_is_multi( $field );
	}
	return $item;
}

/*
 * Controleren.
 */

/**
 * ID's uit de invoer van een relatie- of bestandsveld, of een fout.
 *
 * @param mixed $value Invoer: één ID, een lijst met ID's, of leeg.
 * @return int[]|WP_Error
 */
function _ww_fields_input_ids( $value ) {
	if ( null === $value || '' === $value ) {
		return array();
	}
	$list = is_array( $value ) ? $value : array( $value );
	$ids  = array();
	foreach ( $list as $id ) {
		if ( ! is_int( $id ) && ! ( is_string( $id ) && ctype_digit( $id ) ) ) {
			return new WP_Error( 'ww_abilities_value', __( 'Verwacht een post-ID of een lijst met post-ID\'s.', 'webwerckt-base' ) );
		}
		$ids[] = (int) $id;
	}
	return array_values( array_unique( array_filter( $ids ) ) );
}

/**
 * Fout als een ID niet het verwachte soort bericht is, anders null.
 *
 * @param int[]  $ids       Post-ID's.
 * @param string $post_type Verwacht post type ('attachment' voor bestanden).
 * @param bool   $images    Alleen afbeeldingen.
 */
function _ww_fields_ids_error( array $ids, string $post_type, bool $images ): ?WP_Error {
	foreach ( $ids as $id ) {
		$post = get_post( $id );
		if ( ! _ww_is_relatable_post( $post, $post_type ) || ( $images && ! wp_attachment_is_image( $post ) ) ) {
			/* translators: 1: post-ID, 2: verwacht soort bericht. */
			return new WP_Error( 'ww_abilities_value', sprintf( __( 'ID %1$d is geen %2$s.', 'webwerckt-base' ), $id, $images ? 'afbeelding' : $post_type ) );
		}
	}
	return null;
}

/**
 * De opties van een keuzelijst met eigen opties: waarde => label, uit `pick_custom`.
 *
 * Elke regel is `waarde|label`, of alleen `waarde` (het label is dan gelijk). Lege regels vallen weg.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @return array<string,string>
 */
function _ww_fields_custom_options( array $field ): array {
	$options = array();
	foreach ( preg_split( '/\R/', _ww_data_to_string( $field['pick_custom'] ?? '' ) ) ?: array() as $line ) {
		$line = trim( $line );
		if ( '' === $line ) {
			continue;
		}
		$parts = explode( '|', $line, 2 );
		$value = trim( $parts[0] );
		if ( '' === $value ) {
			continue;
		}
		$options[ $value ] = isset( $parts[1] ) && '' !== trim( $parts[1] ) ? trim( $parts[1] ) : $value;
	}
	return $options;
}

/**
 * Invoerwaarde van een veld, gecontroleerd en klaar voor Pods, of een fout.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @param mixed               $value Invoer.
 * @return mixed
 */
function _ww_fields_input_value( array $field, $value ) {
	$type = _ww_data_to_string( $field['type'] ?? '' );

	if ( 'pick' === $type && 'custom-simple' === ( $field['pick_object'] ?? '' ) && ! _ww_fields_is_multi( $field ) ) {
		if ( null === $value ) {
			return '';
		}
		if ( ! is_string( $value ) ) {
			return new WP_Error( 'ww_abilities_value', __( 'Kies een van de opties.', 'webwerckt-base' ) );
		}
		if ( '' !== $value && ! isset( _ww_fields_custom_options( $field )[ $value ] ) ) {
			return new WP_Error( 'ww_abilities_value', __( 'Kies een van de opties.', 'webwerckt-base' ) );
		}
		return $value;
	}

	if ( 'pick' === $type || 'file' === $type ) {
		if ( 'pick' === $type && ! _ww_field_is_post_relation( $field ) ) {
			return new WP_Error( 'ww_abilities_value', __( 'Alleen relaties met berichten zijn te bewerken.', 'webwerckt-base' ) );
		}
		$ids = _ww_fields_input_ids( $value );
		if ( is_wp_error( $ids ) ) {
			return $ids;
		}
		if ( ! _ww_fields_is_multi( $field ) && count( $ids ) > 1 ) {
			return new WP_Error( 'ww_abilities_value', __( 'Dit veld heeft één waarde.', 'webwerckt-base' ) );
		}
		$error = 'pick' === $type
			? _ww_fields_ids_error( $ids, _ww_data_to_string( $field['pick_val'] ?? '' ), false )
			: _ww_fields_ids_error( $ids, 'attachment', 'images' === ( $field['file_type'] ?? 'images' ) );
		if ( null !== $error ) {
			return $error;
		}
		return _ww_fields_is_multi( $field ) ? $ids : ( $ids[0] ?? '' );
	}

	if ( 'boolean' === $type ) {
		if ( ! is_bool( $value ) && ! in_array( $value, array( 0, 1, '0', '1' ), true ) ) {
			return new WP_Error( 'ww_abilities_value', __( 'Verwacht true of false.', 'webwerckt-base' ) );
		}
		return (int) (bool) $value;
	}

	if ( null === $value ) {
		return '';
	}
	if ( ! is_string( $value ) && ! is_int( $value ) && ! is_float( $value ) ) {
		return new WP_Error( 'ww_abilities_value', __( 'Verwacht tekst.', 'webwerckt-base' ) );
	}
	if ( 'email' === $type && '' !== $value && ! is_email( (string) $value ) ) {
		return new WP_Error( 'ww_abilities_value', __( 'Geen geldig e-mailadres.', 'webwerckt-base' ) );
	}
	return (string) $value;
}

/**
 * Alle invoerwaarden gecontroleerd tegen de toegestane velden: de waarden klaar voor Pods, of de eerste fout.
 *
 * @param mixed                             $input   Invoer (veldnaam => waarde).
 * @param array<string,array<string,mixed>> $allowed Toegestane velden op naam.
 * @return array<string,mixed>|WP_Error
 */
function _ww_fields_input( $input, array $allowed ) {
	$data = array();
	foreach ( is_array( $input ) ? $input : array() as $name => $value ) {
		$name = (string) $name;
		if ( ! isset( $allowed[ $name ] ) ) {
			/* translators: 1: veldnaam, 2: toegestane velden. */
			return new WP_Error( 'ww_abilities_field', sprintf( __( 'Onbekend veld %1$s. Velden: %2$s.', 'webwerckt-base' ), $name, implode( ', ', array_keys( $allowed ) ) ), array( 'status' => 400 ) );
		}
		$clean = _ww_fields_input_value( $allowed[ $name ], $value );
		if ( is_wp_error( $clean ) ) {
			/* translators: 1: veldnaam, 2: foutmelding. */
			return new WP_Error( 'ww_abilities_value', sprintf( __( 'Veld %1$s: %2$s', 'webwerckt-base' ), $name, $clean->get_error_message() ), array( 'status' => 400 ) );
		}
		$data[ $name ] = $clean;
	}
	return $data;
}

/*
 * Opslaan.
 */

/**
 * Slaat waarden op via Pods, de invoerlaag. Geeft null of een fout.
 *
 * @param array<string,mixed> $data Veldnaam => waarde.
 */
function _ww_fields_pods_save( string $pod, int $id, array $data ): ?WP_Error {
	if ( ! function_exists( 'pods' ) ) {
		return new WP_Error( 'ww_abilities_pods', __( 'De plugin Pods is niet actief.', 'webwerckt-base' ), array( 'status' => 503 ) );
	}
	// Pods stopt bij een fout (een veld dat de validatie weigert) anders het hele verzoek met exit of eigen JSON.
	$exception = static fn(): string => 'exception';
	add_filter( 'pods_error_mode', $exception );
	try {
		$item  = $id > 0 ? pods( $pod, $id ) : pods( $pod );
		$saved = is_object( $item ) ? $item->save( $data ) : false;
	} catch ( Throwable $e ) {
		/* translators: %s: foutmelding van Pods. */
		return new WP_Error( 'ww_abilities_pods', sprintf( __( 'Pods kon niet opslaan: %s', 'webwerckt-base' ), wp_strip_all_tags( $e->getMessage() ) ), array( 'status' => 400 ) );
	} finally {
		remove_filter( 'pods_error_mode', $exception );
	}
	return false === $saved || is_wp_error( $saved ) ? new WP_Error( 'ww_abilities_pods', __( 'Pods kon niet opslaan.', 'webwerckt-base' ), array( 'status' => 400 ) ) : null;
}

/**
 * Slaat gecontroleerde waarden van de Site-instellingen op, per instellingen-pod. Geeft null of een fout.
 *
 * @param array<string,mixed>               $data    Veldnaam => gecontroleerde waarde.
 * @param array<string,array<string,mixed>> $allowed Velden op naam, met hun pod.
 */
function _ww_fields_save_settings( array $data, array $allowed ): ?WP_Error {
	$per_pod = array();
	foreach ( $data as $name => $value ) {
		$per_pod[ _ww_data_to_string( $allowed[ $name ]['pod'] ?? '' ) ][ $name ] = $value;
	}
	foreach ( $per_pod as $pod => $values ) {
		$error = _ww_fields_pods_save( $pod, 0, $values );
		if ( null !== $error ) {
			return $error;
		}
	}
	return null;
}
