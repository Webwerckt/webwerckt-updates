<?php
/**
 * Een bericht kopiëren als concept: gedeeld door vertalen (beslissing 0041) en dupliceren.
 *
 * _ww_post_copy() maakt het concept, zet template, taal, velden en termen. De aanroeper doet zijn eigen controles en
 * zet de bovenliggende pagina om. De modus bepaalt wat er verschilt:
 * - translation: relaties wijzen naar de vertalingen, een keuze uit termen of gebruikers gaat niet mee (termen
 *   verschillen per taal), afgeschermde velden vallen stil weg.
 * - duplicate: relaties houden dezelfde ID's, een keuze uit termen of gebruikers gaat mee, canonical en noindex gaan
 *   niet mee, afgeschermde velden met een waarde komen in $dropped, en de uitgelichte afbeelding en de samenvatting
 *   gaan mee.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Maakt een concept als kopie van een bericht.
 *
 * Volgorde: invoegen, template, taal, after_insert, velden (bij een formulier de configuratie), termen. Mislukt een
 * stap na het invoegen, dan verwijdert de functie de kopie en geeft ze de fout, met status 400 als die er geen heeft.
 *
 * @param WP_Post                                                                                                   $source Bron.
 * @param string                                                                                                    $mode   'translation' of 'duplicate'.
 * @param array{title:string,slug:string,parent:int,lang:string,after_insert?:(callable(int):(true|WP_Error))|null} $args   parent al omgezet; lang '' zet geen taal; after_insert draait na de taal en vóór de velden.
 * @return array{id:int,dropped:array<int,array{field:string,id:int}>}|WP_Error
 */
function _ww_post_copy( WP_Post $source, string $mode, array $args ): array|WP_Error {
	$duplicate = 'duplicate' === $mode;
	$insert    = array(
		'post_type'   => $source->post_type,
		'post_status' => 'draft',
		'post_author' => get_current_user_id(),
		'post_title'  => $args['title'],
		'post_name'   => $args['slug'],
		'menu_order'  => $source->menu_order,
		'post_parent' => $args['parent'],
	);
	if ( $duplicate ) {
		$insert['post_excerpt'] = $source->post_excerpt;
	}
	$new = wp_insert_post( wp_slash( $insert ), true );
	if ( is_wp_error( $new ) ) {
		return $new;
	}

	// De template gaat als meta mee, niet als page_template: wp_insert_post() weigert een template dat niet in de lijst
	// staat, en voor de klant staat die lijst leeg (_ww_lock_templates()). Ook een klant (redacteur) maakt zo een kopie
	// met het template van de bron: de bewaking van _ww_guard_template_meta() gaat hier niet over.
	$template = get_post_meta( $source->ID, '_wp_page_template', true );
	if ( is_string( $template ) && '' !== $template ) {
		$guarded = array_filter(
			array( 'add_post_metadata', 'update_post_metadata' ),
			static fn( string $hook ): bool => false !== has_filter( $hook, '_ww_guard_template_meta' )
		);
		foreach ( $guarded as $hook ) {
			remove_filter( $hook, '_ww_guard_template_meta', 10 );
		}
		try {
			update_post_meta( $new, '_wp_page_template', $template );
		} finally {
			foreach ( $guarded as $hook ) {
				add_filter( $hook, '_ww_guard_template_meta', 10, 4 );
			}
		}
	}

	$thumbnail = get_post_thumbnail_id( $source );
	if ( $duplicate && $thumbnail > 0 && post_type_supports( $source->post_type, 'thumbnail' ) ) {
		set_post_thumbnail( $new, $thumbnail );
	}

	$dropped = array();
	$result  = '' !== $args['lang'] ? _ww_set_post_language( $new, $args['lang'] ) : true;
	if ( true === $result && isset( $args['after_insert'] ) ) {
		$result = ( $args['after_insert'] )( $new );
	}
	$target = get_post( $new );
	if ( true === $result && $target instanceof WP_Post && WW_FORM_POST_TYPE === $source->post_type ) {
		// Een formulier heeft geen Pods-velden: de configuratie gaat mee, met dezelfde sleutels, stappen en instellingen.
		_ww_form_save_config( $new, _ww_form_config( $source->ID ) ?? _ww_form_default_config() );
	} elseif ( true === $result && $target instanceof WP_Post ) {
		$result = _ww_post_copy_fields( $source, $target, $mode, $args['lang'], $dropped );
	}
	if ( is_wp_error( $result ) ) {
		wp_delete_post( $new, true );
		$data = $result->get_error_data();
		if ( ! is_array( $data ) || ! isset( $data['status'] ) ) {
			$result->add_data( array( 'status' => 400 ) + ( is_array( $data ) ? $data : array() ) );
		}
		return $result;
	}

	// Dezelfde termen als de bron, voor elke taxonomie van het post type behalve de taal (ook een niet-vertaalbare).
	foreach ( array_diff( get_object_taxonomies( $source->post_type ), array( 'ww_language' ) ) as $taxonomy ) {
		$term_ids = wp_get_object_terms( $source->ID, $taxonomy, array( 'fields' => 'ids' ) );
		if ( is_array( $term_ids ) && array() !== $term_ids ) {
			wp_set_object_terms( $new, array_map( 'intval', $term_ids ), $taxonomy );
		}
	}

	return array(
		'id'      => $new,
		'dropped' => $dropped,
	);
}

/**
 * Kopieert de velden die de admin bij de template toont (zoals get-fields ze leest) van de bron naar de kopie en
 * schrijft ze via Pods (zoals update-fields), daarna "Bijwerken". Velden die niet in de configuratie van de template
 * staan, worden niet gekopieerd.
 *
 * Een opgeslagen waarde die de controle van update-fields niet doorstaat (een verwijderde foto, een oud ongeldig
 * e-mailadres) laat de kopie niet mislukken: een foto of bestand valt weg en komt met zijn ID in $dropped, een
 * andere waarde blijft leeg en komt met ID 0 in $dropped.
 *
 * Per modus (zie de kop van dit bestand): relaties met berichten wijzen bij translation naar de vertalingen en houden
 * bij duplicate dezelfde ID's, zonder wat niet bestaat of in de prullenbak ligt (dat komt met zijn ID in $dropped).
 * Een keuze uit termen of gebruikers gaat bij duplicate mee, zonder een verwijderde term of gebruiker (die komt met zijn
 * ID in $dropped); bij translation komt hij, als de bron er een heeft, met ID 0 in $dropped. Bij duplicate gaan canonical en noindex niet mee, en komt een afgeschermd veld met een waarde met
 * ID 0 in $dropped.
 *
 * @param string                                $lang    Doeltaal (alleen voor translation).
 * @param array<int,array{field:string,id:int}> $dropped Wat wegvalt (wordt aangevuld).
 */
function _ww_post_copy_fields( WP_Post $source, WP_Post $target, string $mode, string $lang, array &$dropped ): ?WP_Error {
	$duplicate = 'duplicate' === $mode;
	$allowed   = _ww_fields_for_post( $target );
	$data      = array();
	foreach ( $allowed as $name => $field ) {
		if ( $duplicate && in_array( $name, array( 'ww_seo_canonical', 'ww_seo_noindex' ), true ) ) {
			continue;
		}
		$type  = _ww_data_to_string( $field['type'] ?? '' );
		$value = _ww_fields_describe( $field, _ww_data_get_stored( $name, $source->ID ) )['value'];
		if ( 'pick' === $type ) {
			if ( _ww_field_is_post_relation( $field ) ) {
				// Zonder de controle van _ww_fields_input(): die eist één post type per veld, en de bron kan een niet-vertaalbaar type bevatten.
				$ids           = $duplicate
					? _ww_post_copy_existing( array_map( 'intval', (array) $value ), $name, $dropped )
					: _ww_translation_map_relation( array_map( 'intval', (array) $value ), $lang, $name, $dropped );
				$data[ $name ] = _ww_fields_is_multi( $field ) ? $ids : ( $ids[0] ?? '' );
			} elseif ( 'custom-simple' === ( $field['pick_object'] ?? '' ) ) {
				// Een vaste lijst (de soort pagina voor zoekmachines): de opgeslagen waarde gaat mee, als hij nog in de lijst staat.
				$stored = _ww_data_get_stored( $name, $source->ID );
				$text   = is_scalar( $stored ) ? (string) $stored : '';
				if ( '' !== $text ) {
					if ( in_array( $text, _ww_translation_pick_keys( $field ), true ) ) {
						$data[ $name ] = $text;
					} else {
						$dropped[] = array(
							'field' => $name,
							'id'    => 0,
						);
					}
				}
			} elseif ( $duplicate ) {
				// Een keuze uit termen of gebruikers: in dezelfde taal gaat de opgeslagen waarde mee, zonder wat niet meer bestaat.
				$stored = _ww_data_get_stored( $name, $source->ID );
				if ( null !== $stored ) {
					$kept          = _ww_post_copy_existing_picks( array_values( (array) $stored ), $field, $name, $dropped );
					$data[ $name ] = _ww_fields_is_multi( $field ) ? $kept : ( $kept[0] ?? '' );
				}
			} elseif ( null !== _ww_data_get_stored( $name, $source->ID ) ) {
				// Een keuze uit termen of gebruikers: niet te vertalen, wel te melden.
				$dropped[] = array(
					'field' => $name,
					'id'    => 0,
				);
			}
			continue;
		}

		// Bestanden één voor één: een ongeldig ID laat de andere staan.
		$values = 'file' === $type ? array_filter( array_map( 'intval', (array) $value ) ) : array( $value );
		$kept   = array();
		foreach ( $values as $item ) {
			$checked = _ww_fields_input( array( $name => $item ), $allowed );
			if ( is_wp_error( $checked ) ) {
				$dropped[] = array(
					'field' => $name,
					'id'    => 'file' === $type ? (int) $item : 0,
				);
				continue;
			}
			$kept[] = $checked[ $name ];
		}
		if ( 'file' === $type ) {
			$data[ $name ] = _ww_fields_is_multi( $field ) ? $kept : ( $kept[0] ?? '' );
		} else {
			$data[ $name ] = $kept[0] ?? '';
		}
	}

	if ( $duplicate ) {
		// Afgeschermde velden laat _ww_fields_for_post() weg; bij dupliceren meldt de kopie ze als de bron er een waarde in heeft.
		foreach ( _ww_pods_fields( $target->post_type, $target->ID ) as $field ) {
			$name = _ww_data_to_string( $field['name'] ?? '' );
			if ( ! _ww_field_restricted( $field ) || isset( $allowed[ $name ] ) ) {
				continue;
			}
			$stored = _ww_data_get_stored( $name, $source->ID );
			if ( null !== $stored && '' !== $stored ) {
				$dropped[] = array(
					'field' => $name,
					'id'    => 0,
				);
			}
		}
	}

	$error = _ww_fields_pods_save( $target->post_type, $target->ID, $data );
	if ( null !== $error ) {
		return $error;
	}

	$result = _ww_update_post( array( 'ID' => $target->ID ) );
	return is_wp_error( $result ) ? $result : null;
}

/**
 * De ID's van een relatie die nog bestaan en niet in de prullenbak liggen. De rest komt met zijn ID in $dropped. De
 * volgorde blijft.
 *
 * @param int[]                                 $ids     ID's in de bron.
 * @param string                                $field   Veldnaam, voor $dropped.
 * @param array<int,array{field:string,id:int}> $dropped Wat wegvalt (wordt aangevuld).
 * @return int[]
 */
function _ww_post_copy_existing( array $ids, string $field, array &$dropped ): array {
	$kept = array();
	foreach ( $ids as $id ) {
		if ( in_array( get_post_status( $id ), array( false, 'trash' ), true ) ) {
			$dropped[] = array(
				'field' => $field,
				'id'    => $id,
			);
			continue;
		}
		$kept[] = $id;
	}
	return $kept;
}

/**
 * De waarden van een keuze uit gebruikers of termen die nog bestaan. Een verwijderde gebruiker of term komt met zijn ID
 * in $dropped. Andere keuzes gaan ongewijzigd mee. De volgorde blijft.
 *
 * @param array<int|string,mixed>               $values  Opgeslagen waarden.
 * @param array<string,mixed>                   $field   Pods-veld.
 * @param string                                $name    Veldnaam, voor $dropped.
 * @param array<int,array{field:string,id:int}> $dropped Wat wegvalt (wordt aangevuld).
 * @return array<int,mixed>
 */
function _ww_post_copy_existing_picks( array $values, array $field, string $name, array &$dropped ): array {
	$object = _ww_data_to_string( $field['pick_object'] ?? '' );
	$kept   = array();
	foreach ( $values as $value ) {
		$id     = is_numeric( $value ) ? (int) $value : 0;
		$exists = match ( $object ) {
			'user'     => $id > 0 && false !== get_userdata( $id ),
			'taxonomy' => $id > 0 && get_term( $id ) instanceof WP_Term,
			default    => true,
		};
		if ( ! $exists ) {
			$dropped[] = array(
				'field' => $name,
				'id'    => $id,
			);
			continue;
		}
		$kept[] = $value;
	}
	return $kept;
}
