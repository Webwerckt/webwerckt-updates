<?php
/**
 * Contactgegevens en openingstijden uit de Site-instellingen, voor de pagina en voor het schema (inc/schema.php).
 *
 * Het adres staat in aparte velden (straat, postcode, plaats, land); het oude tekstveld address blijft werken voor
 * de weergave. Openingstijden zijn per dag een tekstveld als 09:00-17:00, met meerdere blokken gescheiden door een
 * komma. Pods weigert bij het opslaan een notatie die niet te lezen is, maar de helpers vangen ook een waarde op die
 * buiten Pods om is opgeslagen: die geeft nooit een fout.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Landnummers voor telefoonnummers die met een 0 beginnen, op landcode.
 */
const WW_CALLING_CODES = array(
	'NL' => '31',
	'BE' => '32',
	'DE' => '49',
	'FR' => '33',
	'LU' => '352',
	'GB' => '44',
);

/**
 * Hoe lang een pagina met "nu open" in een paginacache mag blijven, in seconden.
 */
const WW_OPEN_NOW_TTL = 15 * MINUTE_IN_SECONDS;

/*
 * Adres, telefoon en e-mail.
 */

/**
 * Landcode van twee hoofdletters uit de Site-instellingen, standaard NL.
 */
function _ww_country(): string {
	$country = strtoupper( trim( _ww_setting_string( 'country' ) ) );
	return 1 === preg_match( '/^[A-Z]{2}$/', $country ) ? $country : 'NL';
}

/**
 * Straat, postcode en plaats uit de Site-instellingen als platte tekst. De pagina (ww_address()) en het schema
 * gebruiken dezelfde delen, dus ze tonen nooit een ander adres.
 *
 * @return array{street:string,postal_code:string,city:string}
 */
function _ww_address_parts(): array {
	$parts = array();
	foreach ( array( 'street', 'postal_code', 'city' ) as $field ) {
		$parts[ $field ] = _ww_plain_text( _ww_setting_string( $field ) );
	}
	return $parts;
}

/**
 * Het adres als regels platte tekst: straat, en postcode met plaats. Leeg als straat, postcode en plaats leeg zijn.
 *
 * @return string[]
 */
function _ww_address_lines(): array {
	$parts = _ww_address_parts();
	$lines = array( $parts['street'], trim( $parts['postal_code'] . ' ' . $parts['city'] ) );
	return array_values( array_filter( $lines, static fn( string $line ): bool => '' !== $line ) );
}

/**
 * Het adres als HTML, met een <br> tussen de regels: uit straat, postcode en plaats, en zolang die leeg zijn uit het
 * oude tekstveld address. Zonder adres ''.
 */
function ww_address(): string {
	$lines = _ww_address_lines();
	if ( array() !== $lines ) {
		return implode( '<br>', array_map( 'esc_html', $lines ) );
	}
	return nl2br( ww_setting( 'address' ), false );
}

/**
 * Telefoonnummer als tel:-link voor href, met landnummer en zonder spaties: "06 12 34 56 78" wordt tel:+31612345678.
 * Een nummer met een 0 vooraan krijgt het landnummer van het land uit de Site-instellingen. Zonder cijfers ''.
 *
 *     <a href="<?php echo ww_tel_url( ww_setting( 'phone' ) ); ?>"><?php echo ww_setting( 'phone' ); ?></a>
 *
 * @param string $number Telefoonnummer zoals de klant het typte.
 */
function ww_tel_url( string $number ): string {
	$number = _ww_tel_number( $number );
	return '' === $number ? '' : esc_url( 'tel:' . $number, array( 'tel' ) );
}

/**
 * Telefoonnummer met landnummer en zonder opmaak (+31612345678), zoals ww_tel_url() en het schema het gebruiken.
 * Zonder cijfers ''.
 */
function _ww_tel_number( string $number ): string {
	// Na een landnummer hoort de (0) er niet bij: +31 (0)30 123 45 67 is +31301234567.
	$number = (string) preg_replace( '/^(\s*(?:\+|00)\s*\d{1,3})\s*\(\s*0\s*\)/', '$1', wp_strip_all_tags( $number ) );
	$number = (string) preg_replace( '/[^\d+]/', '', $number );
	$number = str_starts_with( $number, '00' ) ? '+' . substr( $number, 2 ) : $number;
	// Een + kan alleen vooraan staan.
	$number = ( str_starts_with( $number, '+' ) ? '+' : '' ) . str_replace( '+', '', $number );
	if ( '' === trim( $number, '+' ) ) {
		return '';
	}
	$code = WW_CALLING_CODES[ _ww_country() ] ?? '';
	return '' !== $code && str_starts_with( $number, '0' ) ? '+' . $code . substr( $number, 1 ) : $number;
}

/**
 * E-mailadres als mailto:-link voor href, gecodeerd tegen spambots. Geen geldig adres: ''.
 *
 * @param string $email E-mailadres.
 */
function ww_email_url( string $email ): string {
	$email = _ww_valid_email( $email );
	return '' !== $email ? esc_url( 'mailto:' . antispambot( $email, 1 ), array( 'mailto' ) ) : '';
}

/**
 * E-mailadres om te tonen, gecodeerd tegen spambots (de browser toont het gewoon). Geen geldig adres: ''.
 *
 * @param string $email E-mailadres.
 */
function ww_email_label( string $email ): string {
	$email = _ww_valid_email( $email );
	return '' !== $email ? antispambot( $email ) : '';
}

/**
 * Het e-mailadres zonder HTML en gesaneerd, of '' als het geen geldig adres is. Voor de links, de weergave en het
 * schema.
 */
function _ww_valid_email( string $email ): string {
	$email = sanitize_email( wp_strip_all_tags( $email ) );
	return is_email( $email ) ? $email : '';
}

/*
 * Openingstijden.
 */

/**
 * De dagen van de week, maandag eerst, met hun naam.
 *
 * @return array<string,string> Dag in het Engels (zoals PHP hem noemt) => naam.
 */
function _ww_hours_days(): array {
	return array(
		'monday'    => __( 'Maandag', 'webwerckt-base' ),
		'tuesday'   => __( 'Dinsdag', 'webwerckt-base' ),
		'wednesday' => __( 'Woensdag', 'webwerckt-base' ),
		'thursday'  => __( 'Donderdag', 'webwerckt-base' ),
		'friday'    => __( 'Vrijdag', 'webwerckt-base' ),
		'saturday'  => __( 'Zaterdag', 'webwerckt-base' ),
		'sunday'    => __( 'Zondag', 'webwerckt-base' ),
	);
}

/**
 * Veldnaam in de Site-instellingen van de openingstijden van een dag.
 */
function _ww_hours_field( string $day ): string {
	return 'hours_' . $day;
}

/**
 * De blokken van een dag uit de notatie 09:00-17:00, 13:00-17:00, als minuten na middernacht. Ook 9.00 - 17.00 en een
 * streepje als – mag. 00:00 als sluitingstijd is middernacht (24:00). Leeg of "gesloten": array(). Niet te lezen
 * (verkeerde notatie, sluiten vóór openen, blokken die overlappen of door elkaar staan): null.
 *
 * @return array<int,array{from:int,to:int}>|null
 */
function _ww_hours_parse( string $value ): ?array {
	$value = trim( wp_strip_all_tags( $value ) );
	if ( '' === $value || in_array( strtolower( $value ), array( 'gesloten', 'closed', '-' ), true ) ) {
		return array();
	}

	$ranges = array();
	foreach ( explode( ',', $value ) as $part ) {
		if ( 1 !== preg_match( '/^\s*(\d{1,2})[:.](\d{2})\s*[-–—]\s*(\d{1,2})[:.](\d{2})\s*$/u', $part, $time ) ) {
			return null;
		}
		$from = (int) $time[1] * 60 + (int) $time[2];
		$to   = (int) $time[3] * 60 + (int) $time[4];
		$to   = 0 === $to ? 24 * 60 : $to;
		$last = end( $ranges );
		if ( (int) $time[2] > 59 || (int) $time[4] > 59 || $to > 24 * 60 || $to <= $from || ( false !== $last && $from < $last['to'] ) ) {
			return null;
		}
		$ranges[] = array(
			'from' => $from,
			'to'   => $to,
		);
	}
	return $ranges;
}

/**
 * Minuten na middernacht als 09:00; middernacht aan het eind van de dag is 24:00.
 */
function _ww_hours_time( int $minutes ): string {
	return sprintf( '%02d:%02d', intdiv( $minutes, 60 ), $minutes % 60 );
}

/**
 * Openingstijden op een moment, zoals ww_opening_hours().
 *
 * @return array<int,array<string,mixed>>
 */
function _ww_opening_hours_at( DateTimeImmutable $now ): array {
	$today  = strtolower( $now->format( 'l' ) );
	$days   = array();
	$filled = false;
	foreach ( _ww_hours_days() as $day => $label ) {
		$raw    = _ww_setting_string( _ww_hours_field( $day ) );
		$ranges = _ww_hours_parse( $raw );
		$filled = $filled || '' !== trim( $raw );
		$times  = array_map(
			static fn( array $range ): array => array(
				'open'  => _ww_hours_time( $range['from'] ),
				'close' => _ww_hours_time( $range['to'] ),
			),
			$ranges ?? array()
		);
		$days[] = array(
			'day'    => $day,
			'label'  => esc_html( $label ),
			'ranges' => $times,
			'closed' => array() === $ranges,
			// Een notatie die niet te lezen is, komt er letterlijk te staan: beter dan "gesloten" bij een tikfout.
			'text'   => esc_html( null === $ranges ? wp_strip_all_tags( $raw ) : implode( ', ', array_map( static fn( array $time ): string => $time['open'] . '–' . $time['close'], $times ) ) ),
			'today'  => $today === $day,
		);
	}
	return $filled ? $days : array();
}

/**
 * Openingstijden van de week, maandag eerst. Zonder ingevulde openingstijden array().
 *
 * Elke dag is een array met day (monday), label (Maandag, vertaald en ge-escaped), ranges (lijst met open en close
 * als 09:00), closed (bool), text (de tijden als 09:00–12:00, 13:00–17:00, ge-escaped; leeg als gesloten) en today
 * (bool, volgens de tijdzone van de site). Omdat today om middernacht verspringt, blijft een pagina die dit toont
 * hoogstens tot middernacht in een paginacache (actie ww_cache_ttl):
 *
 *     <?php foreach ( ww_opening_hours() as $day ) : ?>
 *         <dt><?php echo $day['label']; ?></dt>
 *         <dd><?php echo $day['closed'] ? 'Gesloten' : $day['text']; ?></dd>
 *     <?php endforeach; ?>
 *
 * @return array<int,array<string,mixed>>
 */
function ww_opening_hours(): array {
	$now  = current_datetime();
	$days = _ww_opening_hours_at( $now );
	if ( array() !== $days ) {
		do_action( 'ww_cache_ttl', _ww_seconds_until_midnight( $now ) );
	}
	return $days;
}

/**
 * Seconden tot de volgende middernacht in de tijdzone van $now, minstens 1.
 */
function _ww_seconds_until_midnight( DateTimeImmutable $now ): int {
	return max( 1, $now->modify( 'tomorrow' )->getTimestamp() - $now->getTimestamp() );
}

/**
 * Open op een moment, zoals ww_is_open_now().
 */
function _ww_is_open_at( DateTimeImmutable $now ): bool {
	$day     = strtolower( $now->format( 'l' ) );
	$minutes = (int) $now->format( 'G' ) * 60 + (int) $now->format( 'i' );
	foreach ( _ww_hours_parse( _ww_setting_string( _ww_hours_field( $day ) ) ) ?? array() as $range ) {
		if ( $minutes >= $range['from'] && $minutes < $range['to'] ) {
			return true;
		}
	}
	return false;
}

/**
 * Is de organisatie nu open, volgens de openingstijden en de tijdzone van de site? Dat is maar even waar: een pagina
 * die dit toont, blijft hoogstens een kwartier in een paginacache (actie ww_cache_ttl).
 */
function ww_is_open_now(): bool {
	do_action( 'ww_cache_ttl', WW_OPEN_NOW_TTL );
	return _ww_is_open_at( current_datetime() );
}

/**
 * Pods weigert openingstijden in een notatie die niet te lezen is, in zijn eigen scherm, in Visueel bewerken en bij
 * de abilities (die slaan allemaal op via Pods).
 *
 * @param mixed $valid Uitkomst tot nu toe: true, of een lijst met foutmeldingen.
 * @param mixed $value Nieuwe waarde.
 * @param mixed $name  Veldnaam.
 * @return mixed
 */
function _ww_hours_validate( $valid, $value, $name ) {
	$fields = array_map( '_ww_hours_field', array_keys( _ww_hours_days() ) );
	if ( ! in_array( $name, $fields, true ) || null !== _ww_hours_parse( _ww_data_to_string( $value ) ) ) {
		return $valid;
	}
	return array_merge(
		is_array( $valid ) ? $valid : array(),
		/* translators: %s: de ingevulde tekst. */
		array( sprintf( __( 'Openingstijden "%s" zijn niet te lezen. Schrijf ze als 09:00-17:00, meerdere blokken met een komma: 09:00-12:00, 13:00-17:00. Laat het veld leeg als je gesloten bent.', 'webwerckt-base' ), wp_strip_all_tags( _ww_data_to_string( $value ) ) ) )
	);
}
add_filter( 'pods_field_validate_text', '_ww_hours_validate', 10, 3 );
