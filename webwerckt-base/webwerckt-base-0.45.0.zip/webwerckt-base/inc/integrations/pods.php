<?php
/**
 * Pods als invoerlaag in de admin: registreert de pods uit de veldconfiguratie (inc/config.php), toont per
 * paginatemplate alleen zijn veldgroepen, en geeft de klant de Site-instellingen. De mu-plugin die Pods
 * op de frontend overslaat, installeert inc/lifecycle.php. De frontend leest de velden zonder Pods (inc/data.php).
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registreert de pods bij Pods. Zonder Pods gebeurt er niets; de frontend heeft Pods niet nodig.
 */
function _ww_pods_register(): void {
	if ( ! function_exists( 'pods_register_type' ) ) {
		return;
	}
	foreach ( _ww_pods_config() as $pod ) {
		pods_register_type( $pod['type'], $pod['name'], _ww_settings_strip_pages( $pod ) );
	}
}
// Na de standaard post types (prioriteit 5) en vóór Pods op prioriteit 11 zijn lijst met instellingen-pods
// en content types opbouwt.
add_action( 'init', '_ww_pods_register', 10 );

/**
 * Laat Pods alle groepen en velden van een pod laden. Pods houdt standaard op bij 300, en de pod page krijgt de
 * velden van alle paginatemplates samen. Een veld na de 300e kent Pods dan niet: hij slaat het op als losse meta,
 * en een relatie met meerdere berichten komt als één array in elke bestaande rij, die niet meer te lezen is.
 *
 * @param mixed $limit Maximum van Pods.
 */
function _ww_pods_find_limit( $limit ): int {
	$count = 0;
	foreach ( _ww_pods_config() as $pod ) {
		$count += count( $pod['groups'] ) + count( _ww_pods_groups_fields( $pod['groups'] ) );
	}
	return max( (int) $limit, $count );
}
add_filter( 'pods_whatsit_storage_post_type_find_limit', '_ww_pods_find_limit' );

/*
 * Pods toont van de template-groepen alleen die van het gekozen template (_ww_pods_template_groups() in inc/config.php).
 */
add_filter( 'pods_meta_groups_get', '_ww_pods_template_groups', 10, 4 );

/**
 * De klant die pagina's van anderen bewerkt (Redacteur) bewerkt de Site-instellingen. Pods schermt een
 * instellingenpagina af met pods_edit_{pod}; dat recht krijgt hij alleen voor de instellingen-pods uit de
 * configuratiebestanden. Andere pods en het beheer van Pods zelf blijven bij de beheerder.
 *
 * @param array<string,bool> $allcaps Rechten van de gebruiker.
 * @param string[]           $caps    Gevraagde basisrechten.
 * @param mixed[]            $args    Het gevraagde recht en eventuele argumenten.
 * @return array<string,bool>
 */
function _ww_pods_grant_settings_cap( array $allcaps, array $caps, array $args ): array {
	$cap = _ww_data_to_string( $args[0] ?? '' );
	if ( ! str_starts_with( $cap, 'pods_edit_' ) || ! _ww_is_client_editor( $allcaps ) ) {
		return $allcaps;
	}
	foreach ( _ww_pods_config() as $pod ) {
		if ( 'settings' === ( $pod['type'] ?? '' ) && 'pods_edit_' . $pod['name'] === $cap ) {
			$allcaps[ $cap ] = true;
		}
	}
	return $allcaps;
}
add_filter( 'user_has_cap', '_ww_pods_grant_settings_cap', 10, 3 );

/**
 * Shortcodes van Pods doen niets: Pods is alleen de invoerlaag (beslissingen 0003 en 0017), en ww_text() voert de
 * shortcodes uit een WYSIWYG-veld uit (_ww_pods_allow_shortcodes() laat Pods ze bewaren, voor [ww_form]). Met
 * [pods form="1"] kon een Auteur zo een formulier van Pods op de pagina zetten waarmee elke bezoeker gepubliceerde
 * berichten of pagina's maakt (B6 van de security-audit van 2026-11-15). Geldt overal, ook buiten ww_text().
 *
 * @param false|string $output Uitvoer; false laat de shortcode gewoon draaien.
 * @param string       $tag    Naam van de shortcode.
 * @return false|string
 */
function _ww_pods_block_shortcodes( $output, $tag ) {
	/**
	 * Shortcodes die het thema niet uitvoert. Standaard die van Pods: pods, pods-form en acf (Pods' vervanger van ACF).
	 *
	 * @param string[] $tags Namen van shortcodes.
	 */
	$blocked = (array) apply_filters( 'ww_blocked_shortcodes', array( 'pods', 'pods-form', 'acf' ) );
	return in_array( $tag, $blocked, true ) ? '' : $output;
}
add_filter( 'pre_do_shortcode_tag', '_ww_pods_block_shortcodes', 10, 2 );

/**
 * Blokken van Pods (pods/*) doen ook niets: ze roepen pods_shortcode_form() en pods_shortcode() direct aan, buiten
 * do_shortcode() om. Een Auteur kan zo'n blok via REST in post_content zetten (B6 van de audit).
 *
 * @param string|null         $output Uitvoer; null laat het blok gewoon renderen.
 * @param array<string,mixed> $block  Het blok.
 * @return string|null
 */
function _ww_pods_block_blocks( $output, $block ) {
	return str_starts_with( _ww_data_to_string( $block['blockName'] ?? '' ), 'pods/' ) ? '' : $output;
}
add_filter( 'pre_render_block', '_ww_pods_block_blocks', 10, 2 );

// De dynamische functies van Pods (shortcodes, blokken en widgets die inhoud of formulieren op de site zetten) staan
// uit: het thema gebruikt ze nergens (beslissing 0017). Pods' meta-registratie hangt aan een eigen instelling, die
// standaard uit staat en hier niet verandert.
add_filter( 'pods_access_can_use_dynamic_features', '__return_false' );

/**
 * Adminmelding als Pods ontbreekt: de site toont zijn velden nog, maar ze zijn niet te bewerken.
 */
function _ww_pods_missing_notice(): void {
	if ( function_exists( 'pods' ) || ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	printf(
		'<div class="notice notice-error"><p>%s</p></div>',
		esc_html__( 'Webwerckt Base: de plugin Pods is niet actief. Velden zijn niet te bewerken totdat Pods is geïnstalleerd en geactiveerd.', 'webwerckt-base' )
	);
}
add_action( 'admin_notices', '_ww_pods_missing_notice' );
