<?php
/**
 * Visueel bewerken (ADR 0019): een adminscherm met de pagina in een iframe en een zijpaneel. Klik je in de pagina
 * op een gemarkeerd element (ww_edit_attrs(), ww_image()), dan toont het zijpaneel de velden ervan; een sectie
 * (ww_section()) toont zijn schakelaar, relaties en de velden die nergens in de pagina gemarkeerd zijn. Wijzigingen
 * gaan in één keer naar de REST-route ww/v1/editor/{id}, die opslaat zoals "Bijwerken" in de admin.
 *
 * De klant (inc/admin.php) ziet alleen Visueel bewerken; een beheerder houdt ook het gewone bewerkscherm.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Slug van het adminscherm en de queryparameter van de pagina in het iframe.
const WW_EDITOR_PAGE  = 'ww-visual-editor';
const WW_EDITOR_PARAM = 'ww-edit';
// Voorvoegsel van een veld uit de Site-instellingen in data-ww-edit, zodat het niet botst met een paginaveld.
const WW_EDITOR_SITE = 'site:';
// Pagina's zonder eigen bericht die de editor kan openen: alleen hun teksten uit de Site-instellingen zijn te bewerken.
const WW_EDITOR_VIEWS = array( '404', 'search' );
// Zoekopdracht waarmee de editor de zoekpagina opent: zonder treffers, zodat de lege staat te zien is.
const WW_EDITOR_SEARCH = 'ww-voorbeeld-zonder-resultaten';
// Bericht-ID waarmee de editor de 404 opent.
const WW_EDITOR_MISSING_ID = 999999999;

/*
 * Markeren in de pagina.
 */

/**
 * Attribuut dat een element in Visueel bewerken aanklikbaar maakt voor deze velden van de huidige pagina; buiten
 * de editor ''. Het eerste veld is de inhoud van het element, de andere velden zijn attributen (de href van een knop).
 *
 * @param string ...$fields Veldnamen, of post_title voor de titel van de pagina.
 */
function ww_edit_attrs( string ...$fields ): string {
	$names = array_filter( array_map( 'sanitize_key', $fields ) );
	if ( array() === $names || ! _ww_editor_marks( 0 ) ) {
		return '';
	}
	return _ww_html_attrs( array( 'edit' => implode( ' ', $names ) ) );
}

/**
 * Zoals ww_edit_attrs(), maar voor velden uit de Site-instellingen: in Visueel bewerken is het element op elke pagina
 * aan te klikken, met de melding dat de wijziging voor de hele site geldt. Buiten de editor ''.
 *
 * @param string ...$fields Veldnamen van de Site-instellingen, zoals bij ww_setting().
 */
function ww_setting_attrs( string ...$fields ): string {
	$names = array_filter( array_map( 'sanitize_key', $fields ) );
	if ( array() === $names || ( 0 === _ww_editor_post_id() && '' === _ww_editor_view() ) ) {
		return '';
	}
	return _ww_html_attrs( array( 'edit' => implode( ' ', array_map( static fn( string $name ): string => WW_EDITOR_SITE . $name, $names ) ) ) );
}

/**
 * ID van de pagina die in deze frontend-request in het iframe van de editor staat, anders 0.
 * Pas betrouwbaar vanaf de actie wp: dan is de hoofdquery bekend.
 */
function _ww_editor_post_id(): int {
	if ( ! isset( $_GET[ WW_EDITOR_PARAM ] ) || is_admin() || ! did_action( 'wp' ) || ! ( is_singular() || _ww_editor_is_posts_page() ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen lezen; het recht wordt hieronder gecontroleerd.
		return 0;
	}
	$post = get_queried_object();
	return $post instanceof WP_Post && _ww_editor_can_edit( $post ) ? $post->ID : 0;
}

/**
 * De pagina zonder eigen bericht (404 of zoeken) die in deze frontend-request in het iframe van de editor staat, of ''.
 * Daar zijn alleen velden van de Site-instellingen aan te klikken, dus alleen voor wie die mag bewerken.
 */
function _ww_editor_view(): string {
	$view = _ww_query_key( WW_EDITOR_PARAM ); // Alleen lezen; het recht wordt hieronder gecontroleerd.
	if ( is_admin() || ! did_action( 'wp' ) || ! in_array( $view, WW_EDITOR_VIEWS, true ) || ! _ww_editor_can_edit_settings() ) {
		return '';
	}
	return ( '404' === $view && is_404() ) || ( 'search' === $view && is_search() ) ? $view : '';
}

/**
 * Is dit de berichtenpagina (Instellingen → Lezen)? Voor WordPress is dat een overzicht (is_home()), geen pagina,
 * maar de pagina zelf is wel het gevraagde object en heeft haar eigen velden.
 */
function _ww_editor_is_posts_page(): bool {
	$page = (int) get_option( 'page_for_posts' );
	return $page > 0 && is_home() && get_queried_object_id() === $page;
}

/**
 * Hoort een veld van dit bericht een markering te krijgen? Alleen in de editor en alleen voor de pagina die
 * bewerkt wordt, niet voor een kaart of relatie van een ander bericht op die pagina.
 *
 * @param int $post_id Bericht-ID van het veld; 0 is het huidige bericht.
 */
function _ww_editor_marks( int $post_id ): bool {
	$editing = _ww_editor_post_id();
	return 0 !== $editing && ( $post_id ?: _ww_editor_current_id() ) === $editing;
}

/**
 * Het huidige bericht voor een markering. Op de berichtenpagina is het globale bericht buiten de lus het eerste
 * blogbericht, niet de pagina; daar telt buiten de lus en buiten een kaart dus de pagina zelf. Alleen voor de
 * markeringen: ww_field() zonder ID houdt zijn gedrag (publieke API, ADR 0011).
 */
function _ww_editor_current_id(): int {
	if ( _ww_editor_is_posts_page() && ! in_the_loop() && 0 === _ww_card_depth() ) {
		return (int) get_queried_object_id();
	}
	return _ww_current_id();
}

/**
 * Leeg vlak in plaats van een foto, zodat een leeg fotoveld in de editor aan te klikken is. Zo groot als het
 * afbeeldingsformaat; zonder vaste hoogte 16:9.
 *
 * @param string               $size Geregistreerd afbeeldingsformaat.
 * @param array<string,string> $attr Attributen, met data-ww-edit.
 */
function _ww_editor_image_placeholder( string $size, array $attr ): string {
	$sizes  = wp_get_registered_image_subsizes();
	$width  = (int) ( $sizes[ $size ]['width'] ?? 0 ) ?: 1200;
	$height = (int) ( $sizes[ $size ]['height'] ?? 0 ) ?: (int) round( $width * 9 / 16 );
	$svg    = sprintf( '<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d"/>', $width, $height );

	$attr = array(
		'src'           => 'data:image/svg+xml,' . rawurlencode( $svg ),
		'width'         => (string) $width,
		'height'        => (string) $height,
		'alt'           => '',
		'data-ww-empty' => '',
	) + $attr;

	$html = '';
	foreach ( $attr as $name => $value ) {
		$html .= sprintf( ' %s="%s"', esc_attr( $name ), esc_attr( $value ) );
	}
	return '<img' . $html . '>';
}

/*
 * Lijsten met kaarten in de pagina.
 */

/**
 * De lijsten met kaarten op de pagina in de editor. ww_related() en ww_get_posts() melden hier welke berichten ze
 * teruggeven; ww_card() zoekt de lijst van zijn bericht op. Zo weet de editor welke kaarten bij welk relatieveld of
 * post type horen, zonder dat het child-thema iets markeert.
 *
 * @param array<int,array{source:string,name:string,ids:int[]}>|null $replace Nieuwe lijsten, of null om alleen te lezen.
 * @return array<int,array{source:string,name:string,ids:int[]}> Per lijst de bron (relation of auto), het veld of post
 *                                                               type, en de berichten die nog geen kaart hebben.
 */
function _ww_editor_list_registry( ?array $replace = null ): array {
	static $lists = array();
	if ( null !== $replace ) {
		$lists = $replace;
	}
	return $lists;
}

/**
 * Meldt een lijst met berichten aan, alleen in de editor. Een relatie telt alleen als hij van de pagina is die
 * bewerkt wordt, niet van een kaart of ander bericht op die pagina.
 *
 * @param string $source  'relation' (veld van een bericht) of 'auto' (berichten van een post type).
 * @param string $name    Veldnaam of post type.
 * @param int[]  $ids     De berichten, in de volgorde van de pagina.
 * @param int    $post_id Bericht van het relatieveld; 0 is het huidige bericht.
 */
function _ww_editor_add_list( string $source, string $name, array $ids, int $post_id = 0 ): void {
	$editing = 'relation' === $source ? _ww_editor_marks( $post_id ) : 0 !== _ww_editor_post_id();
	if ( ! $editing || array() === $ids ) {
		return;
	}
	$lists   = _ww_editor_list_registry();
	$lists[] = array(
		'source' => $source,
		'name'   => $name,
		'ids'    => array_map( 'intval', $ids ),
	);
	_ww_editor_list_registry( $lists );
}

/**
 * Nummer van de lijst waar de kaart van dit bericht bij hoort, of -1. De laatst aangemelde lijst die het bericht
 * nog heeft, zodat een bericht dat in twee lijsten staat, bij elke lijst één kaart krijgt.
 */
function _ww_editor_card_list( int $post_id ): int {
	$lists = _ww_editor_list_registry();
	for ( $index = count( $lists ) - 1; $index >= 0; $index-- ) {
		$position = array_search( $post_id, $lists[ $index ]['ids'], true );
		if ( false !== $position ) {
			array_splice( $lists[ $index ]['ids'], (int) $position, 1 );
			_ww_editor_list_registry( $lists );
			return $index;
		}
	}
	return -1;
}

/**
 * Een kaart in de editor tussen twee HTML-commentaren met het nummer van zijn lijst, net als een sectie
 * (ww_section()). Buiten de editor, of als de kaart bij geen lijst hoort, ongewijzigd.
 */
function _ww_editor_wrap_card( string $html, int $post_id ): string {
	if ( '' === $html || 0 === _ww_editor_post_id() ) {
		return $html;
	}
	$list = _ww_editor_card_list( $post_id );
	return $list < 0 ? $html : '<!--ww-card:' . $list . '-->' . $html . '<!--/ww-card:' . $list . '-->';
}

/**
 * De lijsten voor editor-frame.js: per nummer de bron en het veld of post type.
 *
 * @return array<int,array{source:string,name:string}>
 */
function _ww_editor_lists(): array {
	return array_map(
		static fn( array $list ): array => array(
			'source' => $list['source'],
			'name'   => $list['name'],
		),
		_ww_editor_list_registry()
	);
}

/**
 * Post types met een eigen adminlijst, voor het paneel van een automatische lijst: de naam en, als de gebruiker
 * berichten van dat type mag bewerken, de link naar die lijst.
 *
 * @return array<string,array{label:string,admin:string}>
 */
function _ww_editor_post_types(): array {
	$types = array();
	foreach ( get_post_types( array( 'show_ui' => true ), 'objects' ) as $type ) {
		$types[ $type->name ] = array(
			'label' => (string) $type->labels->name,
			'admin' => current_user_can( $type->cap->edit_posts ) ? add_query_arg( 'post_type', $type->name, admin_url( 'edit.php' ) ) : '',
		);
	}
	return $types;
}

/*
 * De pagina in het iframe.
 */

/**
 * Kan deze pagina visueel bewerkt worden? Voorlopig alleen pagina's (ADR 0019, fase 1).
 */
function _ww_editor_supports( WP_Post $post ): bool {
	return 'page' === $post->post_type && 'trash' !== $post->post_status;
}

/**
 * Mag de huidige gebruiker deze pagina visueel bewerken?
 */
function _ww_editor_can_edit( WP_Post $post ): bool {
	return _ww_editor_supports( $post ) && current_user_can( 'edit_post', $post->ID );
}

/**
 * Mag de huidige gebruiker berichten van dit type publiceren?
 */
function _ww_editor_can_publish( WP_Post $post ): bool {
	$type = get_post_type_object( $post->post_type );
	return $type instanceof WP_Post_Type && current_user_can( $type->cap->publish_posts );
}

/**
 * Zet de pagina in editormodus: zonder adminbalk, niet in de cache, alleen in een frame van dezelfde site, met het
 * script dat klikken doorgeeft aan het zijpaneel.
 */
function _ww_editor_frame_setup(): void {
	if ( 0 === _ww_editor_post_id() && '' === _ww_editor_view() ) {
		return;
	}
	add_filter( 'show_admin_bar', '__return_false' );
	// De 404 in de editor blijft een 404, ook als er een bericht met een lijkende slug bestaat.
	add_filter( 'do_redirect_guess_404_permalink', '__return_false' );
	nocache_headers();
	send_frame_options_header();
	do_action( 'ww_cacheable', false, 'ww visual editor' );
	add_action( 'wp_enqueue_scripts', '_ww_editor_frame_assets' );
	add_action( 'wp_footer', '_ww_editor_frame_data' );
}
add_action( 'wp', '_ww_editor_frame_setup' );

/**
 * Script en stijl van de editormodus.
 */
function _ww_editor_frame_assets(): void {
	wp_enqueue_style( 'ww-editor-frame', _ww_asset_url( 'css/editor-frame.css' ), array(), WW_BASE_VERSION );
	_ww_enqueue_module( 'editor-frame', 'editor-protocol' );
}

/**
 * Gegevens voor editor-frame.js: naar welke herkomst het berichten stuurt (het adminscherm) en de lijsten met
 * kaarten. In de footer, dus nadat de pagina alle kaarten heeft getoond.
 */
function _ww_editor_frame_data(): void {
	_ww_editor_print_json(
		'ww-editor-frame-data',
		array(
			'origin' => _ww_origin( admin_url() ),
			'lists'  => _ww_editor_lists(),
		)
	);
}

/**
 * Herkomst (schema, host en eventueel poort) van een URL, voor postMessage.
 */
function _ww_origin( string $url ): string {
	$parts = wp_parse_url( $url );
	if ( ! is_array( $parts ) || empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
		return '';
	}
	return $parts['scheme'] . '://' . $parts['host'] . ( isset( $parts['port'] ) ? ':' . $parts['port'] : '' );
}

/**
 * Print gegevens voor een script als JSON in een script-element, veilig binnen HTML.
 *
 * @param array<string,mixed> $data
 */
function _ww_editor_print_json( string $id, array $data ): void {
	printf(
		'<script type="application/json" id="%s">%s</script>',
		esc_attr( $id ),
		wp_json_encode( $data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON met < en & als \u-codes.
	);
}

/*
 * Knoppen en links in de admin.
 */

/**
 * URL van de visuele editor voor een bericht.
 */
function _ww_editor_url( int $post_id ): string {
	return add_query_arg(
		array(
			'page' => WW_EDITOR_PAGE,
			'post' => $post_id,
		),
		admin_url( 'admin.php' )
	);
}

/**
 * Zet Visueel bewerken vooraan bij een pagina in de tabel. De klant ziet de gewone Bewerken-link niet meer.
 *
 * @param array<string,string> $actions Acties per sleutel, als HTML.
 * @return array<string,string>
 */
function _ww_editor_row_actions( array $actions, WP_Post $post ): array {
	if ( ! _ww_editor_can_edit( $post ) ) {
		return $actions;
	}
	if ( _ww_is_client() ) {
		unset( $actions['edit'] );
	}
	$link = sprintf( '<a href="%s">%s</a>', esc_url( _ww_editor_url( $post->ID ) ), esc_html__( 'Visueel bewerken', 'webwerckt-base' ) );
	return array( 'ww_visual_edit' => $link ) + $actions;
}
add_filter( 'page_row_actions', '_ww_editor_row_actions', 10, 2 );

/**
 * Elke bewerklink naar een pagina (titel in de tabel, "Pagina bewerken" in de adminbalk) wijst voor de klant naar
 * de visuele editor. Het gewone scherm blijft bereikbaar via de URL: dit is opruimen, geen beveiliging.
 *
 * @param mixed $link    Bewerklink van WordPress.
 * @param mixed $post_id Bericht-ID.
 * @param mixed $context 'display' geeft een link met &amp;.
 * @return mixed
 */
function _ww_editor_edit_link( $link, $post_id, $context ) {
	$post = get_post( (int) $post_id );
	if ( ! $post instanceof WP_Post || ! _ww_editor_supports( $post ) || ! _ww_is_client() ) {
		return $link;
	}
	$url = _ww_editor_url( $post->ID );
	return 'display' === $context ? esc_url( $url ) : $url;
}
add_filter( 'get_edit_post_link', '_ww_editor_edit_link', 10, 3 );

/**
 * URL van de visuele editor voor de 404 of de zoekpagina, in een extra taal met lang (de standaardtaal en een
 * onbekende taal krijgen geen lang).
 */
function _ww_editor_view_url( string $view, string $lang = '' ): string {
	$args = array(
		'page' => WW_EDITOR_PAGE,
		'view' => $view,
	);
	if ( '' !== _ww_settings_edit_language( $lang ) ) {
		$args['lang'] = $lang;
	}
	return add_query_arg( $args, admin_url( 'admin.php' ) );
}

/**
 * De editor van de huidige 404 of zoekpagina, in de taal van de pagina (op /en/ de Engelse weergave), of '' op een
 * andere pagina of zonder rechten op de Site-instellingen.
 */
function _ww_editor_current_view_url(): string {
	$view = is_404() ? '404' : ( is_search() ? 'search' : '' );
	return '' !== $view && _ww_editor_can_edit_settings() ? _ww_editor_view_url( $view, ww_current_language() ) : '';
}

/**
 * Visueel bewerken in de adminbalk op een pagina, voor wie ook het gewone bewerkscherm heeft (bij de klant wijst
 * "Pagina bewerken" er al naartoe), en op de 404 en de zoekpagina voor iedereen die de Site-instellingen bewerkt.
 */
function _ww_editor_admin_bar( WP_Admin_Bar $bar ): void {
	if ( is_admin() ) {
		return;
	}
	$post = get_queried_object();
	$url  = _ww_editor_current_view_url();
	if ( '' === $url && ! _ww_is_client() && $post instanceof WP_Post && _ww_editor_can_edit( $post ) ) {
		$url = _ww_editor_url( $post->ID );
	}
	if ( '' === $url ) {
		return;
	}
	$bar->add_node(
		array(
			'id'    => 'ww-visual-edit',
			'title' => esc_html__( 'Visueel bewerken', 'webwerckt-base' ),
			'href'  => $url,
		)
	);
}
add_action( 'admin_bar_menu', '_ww_editor_admin_bar', 81 );

/**
 * Op de pagina 404 & zoeken van de Site-instellingen (inc/settings-pages.php) een melding met de links naar Visueel
 * bewerken van de 404 en de zoekpagina: hun teksten staan daar in de groep Standaardpagina's.
 */
function _ww_editor_settings_notice(): void {
	if ( ! _ww_settings_is_screen() || 'notfound' !== _ww_settings_current_page() || ! _ww_editor_can_edit_settings() ) {
		return;
	}
	$links = array_map(
		static fn( array $view ): string => sprintf( '<a class="button" href="%s">%s</a>', esc_url( $view['url'] ), esc_html( $view['label'] ) ),
		_ww_editor_views()
	);
	printf(
		'<div class="notice notice-info"><p>%s</p><p>%s</p></div>',
		esc_html__( 'De teksten van de 404 en de zoekpagina (Standaardpagina\'s) bewerk je ook in de pagina zelf.', 'webwerckt-base' ),
		implode( ' ', $links ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hierboven ge-escaped.
	);
}
add_action( 'admin_notices', '_ww_editor_settings_notice' );

/*
 * Het adminscherm.
 */

/**
 * Registreert het scherm zonder menu-item: je komt er via de knop bij een pagina.
 */
function _ww_editor_register_page(): void {
	$hook = add_submenu_page( '', __( 'Visueel bewerken', 'webwerckt-base' ), '', 'edit_pages', WW_EDITOR_PAGE, '_ww_editor_render' );
	if ( false !== $hook ) {
		add_action( 'load-' . $hook, '_ww_editor_load' );
	}
}
add_action( 'admin_menu', '_ww_editor_register_page' );

/**
 * De pagina uit de URL van het scherm, als de gebruiker hem visueel mag bewerken; anders null.
 */
function _ww_editor_requested_post(): ?WP_Post {
	$post = get_post( isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen lezen; het recht wordt hieronder gecontroleerd.
	return $post instanceof WP_Post && _ww_editor_can_edit( $post ) ? $post : null;
}

/**
 * De 404 of de zoekpagina uit de URL van het scherm (&view=), als de gebruiker de Site-instellingen mag bewerken;
 * anders ''.
 */
function _ww_editor_requested_view(): string {
	$view = _ww_query_key( 'view' ); // Alleen lezen; het recht wordt hieronder gecontroleerd.
	return in_array( $view, WW_EDITOR_VIEWS, true ) && _ww_editor_can_edit_settings() ? $view : '';
}

/**
 * Vóór de uitvoer van het scherm: rechten, vergrendeling en scripts.
 */
function _ww_editor_load(): void {
	$post = _ww_editor_requested_post();
	if ( null === $post && '' === _ww_editor_requested_view() ) {
		wp_die( esc_html__( 'Deze pagina bestaat niet of je mag hem niet bewerken.', 'webwerckt-base' ), 403 );
	}
	if ( null !== $post && ! wp_check_post_lock( $post->ID ) ) {
		wp_set_post_lock( $post->ID );
	}
	// Een scherm zonder menu-item heeft geen titel voor het tabblad van de browser.
	$GLOBALS['title'] = __( 'Visueel bewerken', 'webwerckt-base' ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- de titel van admin-header.php.

	wp_enqueue_media( null === $post ? array() : array( 'post' => $post->ID ) );
	wp_enqueue_editor();
	wp_enqueue_script( 'wp-api-fetch' );
	wp_enqueue_style( 'ww-editor', _ww_asset_url( 'css/editor.css' ), array(), WW_BASE_VERSION );
	_ww_enqueue_module( 'editor', array( 'editor-protocol', 'editor-menu', 'editor-search', 'editor-layout', 'editor-changes' ) );
}

/**
 * Het scherm: links een vast zijpaneel en rechts de pagina in een iframe. Het paneel heeft een kop van twee rijen (terug,
 * de paginatitel met de status, zoeken en inklappen; het schermformaat en de zoom), een midden dat schuift en dat
 * editor.js vult (met Deze pagina en Hele site onder de secties), en een voet met de status van de wijzigingen,
 * Versies en opslaan.
 */
function _ww_editor_render(): void {
	$post = _ww_editor_requested_post();
	$view = null === $post ? _ww_editor_requested_view() : '';
	if ( null === $post && '' === $view ) {
		return;
	}
	$locked = null === $post ? false : wp_check_post_lock( $post->ID );
	$data   = ( null === $post ? _ww_editor_view_data( $view, _ww_settings_edit_language( _ww_query_key( 'lang' ) ) ) : _ww_editor_data( $post ) ) + array(
		'lockedBy'     => $locked ? get_the_author_meta( 'display_name', $locked ) : '',
		// De editor-style van het child-thema (add_editor_style()), zodat WYSIWYG-tekst eruitziet als op de site.
		'editorStyles' => array_values( get_editor_stylesheets() ),
		// Velden van sectie {naam} beginnen met {voorvoegsel}{naam}_, de schakelaar is {voorvoegsel}{naam}_enabled.
		'prefix'       => _ww_child_prefix(),
		'strings'      => _ww_editor_strings(),
	);
	$title = null === $post ? $data['post']['title'] : get_the_title( $post );
	// Deze pagina alleen bij een bericht (niet op de 404 en de zoekpagina), Hele site alleen met rechten op de
	// Site-instellingen. Ze staan in Op deze pagina, onder de secties; editor.js zet ze daar neer.
	$scopes = array();
	if ( null !== $post ) {
		$scopes['page'] = array( 'admin-page', __( 'Deze pagina', 'webwerckt-base' ) );
	}
	if ( _ww_editor_can_edit_settings() ) {
		$scopes['site'] = array( 'admin-site-alt3', __( 'Hele site', 'webwerckt-base' ) );
	}
	// Eerdere versies alleen als WordPress revisies bewaart voor dit bericht; de knop staat in de voet.
	$versions = null !== $post && wp_revisions_enabled( $post );
	$devices  = array(
		''       => array( 'desktop', __( 'Desktop', 'webwerckt-base' ) ),
		'tablet' => array( 'tablet', __( 'Tablet', 'webwerckt-base' ) ),
		'mobile' => array( 'smartphone', __( 'Mobiel', 'webwerckt-base' ) ),
	);
	?>
	<div class="ww-editor" data-ww-editor>
		<?php // Een ingeklapt paneel (ww-editor-collapsed) staat er voor de eerste verf al, zonder flits; editor.js neemt het daarna over. ?>
		<script>
			try {
				if ( localStorage.getItem( 'ww-editor-collapsed' ) === 'true' && ! window.matchMedia( '(max-width: 782px)' ).matches ) {
					document.currentScript.parentNode.dataset.wwCollapsed = 'true';
				}
			} catch ( error ) {}
		</script>
		<div class="ww-editor__main">
			<aside class="ww-editor__panel" id="ww-editor-panel" aria-label="<?php esc_attr_e( 'Visueel bewerken', 'webwerckt-base' ); ?>" data-ww-editor-panel>
				<div class="ww-editor__head" data-ww-editor-head>
					<?php // Rij 1: waar ben je. Terug naar de lijst, de paginatitel (wisselt van pagina) met de status, zoeken en inklappen. ?>
					<div class="ww-editor__row ww-editor__page-row">
						<a class="ww-editor__icon-button ww-editor__all" href="<?php echo esc_url( admin_url( 'edit.php?post_type=page' ) ); ?>" aria-label="<?php esc_attr_e( 'Terug naar alle pagina\'s', 'webwerckt-base' ); ?>" title="<?php esc_attr_e( 'Terug naar alle pagina\'s', 'webwerckt-base' ); ?>">
							<span class="dashicons dashicons-arrow-left-alt2" aria-hidden="true"></span>
						</a>
						<h1 class="ww-editor__title"><button type="button" class="ww-editor__title-button" aria-haspopup="menu" aria-expanded="false" title="<?php echo esc_attr( $title ); ?>" data-ww-editor-pages>
							<span class="screen-reader-text"><?php esc_html_e( 'Wissel van pagina', 'webwerckt-base' ); ?>: </span>
							<span class="ww-editor__title-text" data-ww-editor-title><?php echo esc_html( $title ); ?></span>
							<span class="dashicons dashicons-arrow-down-alt2 ww-editor__caret" aria-hidden="true"></span>
						</button></h1>
						<div data-ww-editor-menu hidden></div>
						<span class="ww-editor__state-label" hidden data-ww-editor-status-label></span>
						<span class="ww-editor__tools">
							<button type="button" class="ww-editor__icon-button" data-ww-editor-search aria-label="<?php esc_attr_e( 'Zoeken (Ctrl+K)', 'webwerckt-base' ); ?>" title="<?php esc_attr_e( 'Zoeken (Ctrl+K)', 'webwerckt-base' ); ?>">
								<span class="dashicons dashicons-search" aria-hidden="true"></span>
							</button>
							<button type="button" class="ww-editor__icon-button" data-ww-editor-collapse aria-expanded="true" aria-controls="ww-editor-panel" aria-label="<?php esc_attr_e( 'Paneel inklappen', 'webwerckt-base' ); ?>" title="<?php esc_attr_e( 'Paneel inklappen', 'webwerckt-base' ); ?>">
								<?php _ww_editor_panel_icon(); ?>
							</button>
						</span>
					</div>
					<?php // Rij 2: hoe bekijk je hem. Het schermformaat als iconen (breedte in de tooltip, editor.js) en rechts de zoom. ?>
					<div class="ww-editor__row ww-editor__view-row">
						<div class="ww-editor__devices" role="group" aria-label="<?php esc_attr_e( 'Schermformaat', 'webwerckt-base' ); ?>">
							<?php foreach ( $devices as $device => list( $icon, $label ) ) : ?>
								<button type="button" class="ww-editor__device" data-ww-device="<?php echo esc_attr( $device ); ?>" aria-pressed="<?php echo '' === $device ? 'true' : 'false'; ?>" aria-label="<?php echo esc_attr( $label ); ?>" title="<?php echo esc_attr( $label ); ?>">
									<span class="dashicons dashicons-<?php echo esc_attr( $icon ); ?>" aria-hidden="true"></span>
								</button>
							<?php endforeach; ?>
						</div>
						<div class="ww-editor__zoom" data-ww-editor-zoom></div>
					</div>
				</div>
				<div class="ww-editor__body" data-ww-editor-body>
					<div class="ww-editor__crumb" hidden data-ww-editor-crumb></div>
					<div class="ww-editor__fields" data-ww-editor-fields></div>
					<?php if ( array() !== $scopes ) : ?>
						<?php // Velden die je niet in de pagina kunt aanklikken. editor.js zet dit blok in Op deze pagina en vult per ingang de groepen in. ?>
						<div class="ww-editor__scopes" hidden data-ww-editor-settings>
							<h3 class="ww-editor__subhead"><?php esc_html_e( 'Niet in de pagina aan te klikken', 'webwerckt-base' ); ?></h3>
							<ul class="ww-editor__nav ww-editor__list">
								<?php foreach ( $scopes as $source => list( $icon, $label ) ) : ?>
									<li data-ww-editor-scope="<?php echo esc_attr( $source ); ?>"><a href="#" data-ww-editor-open="<?php echo esc_attr( $source ); ?>">
										<span class="dashicons dashicons-<?php echo esc_attr( $icon ); ?>" aria-hidden="true"></span>
										<span class="ww-editor__nav-text">
											<span class="ww-editor__nav-label"><?php echo esc_html( $label ); ?></span>
											<span class="ww-editor__nav-note" data-ww-editor-note></span>
										</span>
										<span class="dashicons dashicons-arrow-right-alt2 ww-editor__nav-arrow" aria-hidden="true"></span>
									</a></li>
								<?php endforeach; ?>
							</ul>
						</div>
					<?php endif; ?>
				</div>
				<div class="ww-editor__foot" data-ww-editor-foot>
					<div class="ww-editor__state-row">
						<?php // De statusregel; met wijzigingen zet editor.js er een knop van die de weergave Wijzigingen opent. ?>
						<p class="ww-editor__state" role="status" data-ww-editor-status><?php esc_html_e( 'Geen wijzigingen', 'webwerckt-base' ); ?></p>
						<button type="button" class="button-link ww-editor__review" hidden title="<?php esc_attr_e( 'Wijzigingen bekijken', 'webwerckt-base' ); ?>" data-ww-editor-review></button>
						<?php if ( $versions ) : ?>
							<button type="button" class="button-link ww-editor__versions" data-ww-editor-open="versions">
								<span class="dashicons dashicons-backup" aria-hidden="true"></span>
								<?php esc_html_e( 'Versies', 'webwerckt-base' ); ?>
							</button>
						<?php endif; ?>
					</div>
					<div class="ww-editor__actions" data-ww-editor-actions>
						<a class="button ww-editor__view" href="<?php echo esc_url( $data['post']['link'] ); ?>" target="_blank" rel="noopener" data-ww-editor-view>
							<span class="dashicons dashicons-external" aria-hidden="true"></span>
							<span class="screen-reader-text"><span data-ww-editor-view-label><?php esc_html_e( 'Bekijk live', 'webwerckt-base' ); ?></span> <?php esc_html_e( '(opent in een nieuw tabblad)', 'webwerckt-base' ); ?></span>
						</a>
					</div>
				</div>
			</aside>
			<?php // Brengt een ingeklapt paneel terug; linksboven over de pagina, standaard verborgen (editor.js). ?>
			<button type="button" class="ww-editor__expand" hidden aria-expanded="false" aria-controls="ww-editor-panel" aria-label="<?php esc_attr_e( 'Paneel tonen', 'webwerckt-base' ); ?>" title="<?php esc_attr_e( 'Paneel tonen', 'webwerckt-base' ); ?>" data-ww-editor-expand>
				<?php _ww_editor_panel_icon(); ?>
			</button>
			<div class="ww-editor__canvas" data-ww-editor-canvas>
				<iframe class="ww-editor__frame" src="<?php echo esc_url( $data['post']['frame'] ); ?>" title="<?php esc_attr_e( 'Voorbeeld van de pagina', 'webwerckt-base' ); ?>" data-ww-editor-frame></iframe>
			</div>
		</div>
		<div data-ww-editor-search-dialog hidden></div>
		<div class="ww-editor__toasts" aria-live="polite" data-ww-editor-toasts></div>
		<?php _ww_editor_print_json( 'ww-editor-data', $data ); ?>
	</div>
	<?php
}

/**
 * Het icoon van inklappen en tonen: een venster met een zijbalk links (drawerLeft uit @wordpress/icons). Dashicons heeft
 * er geen; editor-outdent is een opmaakicoon en las als "inspringen".
 */
function _ww_editor_panel_icon(): void {
	echo '<svg class="ww-editor__panel-icon" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M18 4H6c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zM8.5 18.5H6c-.3 0-.5-.2-.5-.5V6c0-.3.2-.5.5-.5h2.5v13zm10-.5c0 .3-.2.5-.5.5h-8v-13h8c.3 0 .5.2.5.5v12z"/></svg>';
}

/**
 * Gegevens van de pagina en haar velden voor het zijpaneel; ook het antwoord na opslaan.
 *
 * @return array<string,mixed>
 */
function _ww_editor_data( WP_Post $post ): array {
	$lang = _ww_editor_language( $post );
	$data = array(
		'post'       => array(
			'id'        => $post->ID,
			'title'     => $post->post_title,
			'slug'      => $post->post_name,
			'status'    => $post->post_status,
			'published' => _ww_editor_is_published( $post ),
			'link'      => (string) get_permalink( $post ),
			'frame'     => _ww_editor_frame_url( $post ),
		),
		'fields'     => _ww_editor_fields( $post ),
		// Velden van de Site-instellingen (fase 4); editor.js zet er site: voor, zodat ze niet botsen met de pagina.
		'settings'   => _ww_editor_settings( $lang ),
		'views'      => _ww_editor_views(),
		'pages'      => _ww_editor_pages( $lang ),
		'canPublish' => _ww_editor_can_publish( $post ),
		'view'       => '',
		'endpoint'   => '/' . WW_REST_NAMESPACE . '/editor/' . $post->ID,
		'postTypes'  => _ww_editor_post_types(),
		'origin'     => _ww_origin( home_url() ),
		// Dupliceren (spec pagina-dupliceren): het menu-item, en één keer wat er bij het dupliceren niet meeging.
		'canDuplicate' => _ww_post_can_duplicate( $post->ID ),
		// Leest en wist de transient van _ww_duplicate_take(), ook in het antwoord na opslaan.
		'copyDropped'  => _ww_duplicate_take( $post->ID ),
	);
	if ( '' !== $lang ) {
		// Meertalig (beslissing 0041): het taalmenu. Per Site-instelling staat in translatable of hij per taal is.
		$data['languages'] = _ww_editor_languages( $post );
	}
	return $data;
}

/**
 * De taal van de pagina in de editor, of '' als Meertalig uit staat of het post type niet vertaalbaar is.
 */
function _ww_editor_language( WP_Post $post ): string {
	return _ww_languages_active() && _ww_is_translatable( $post->post_type ) ? _ww_post_language( $post->ID ) : '';
}

/**
 * Het taalmenu: per taal (in de volgorde van de optie) de vertaling van deze pagina, het huidige bericht inbegrepen.
 * Zonder vertaling is id 0, de status '' en de url ''. source_modified is de wijzigingsdatum van de bron (ISO 8601)
 * als die later is dan de vertaling, anders ''.
 *
 * @return array{current:string,items:array<int,array{code:string,name:string,visible:bool,id:int,status:string,source_newer:bool,source_modified:string,url:string}>}
 */
function _ww_editor_languages( WP_Post $post ): array {
	$current = _ww_post_language( $post->ID );
	$items   = array();
	foreach ( _ww_language_codes() as $code ) {
		$language = _ww_language( $code );
		if ( null === $language ) {
			continue;
		}
		$id      = $code === $current ? $post->ID : _ww_translation_target( $post->ID, $code );
		$newer   = $id > 0 && _ww_translation_source_newer( $id );
		$source  = $newer ? _ww_translation_source_id( $id ) : 0;
		$items[] = array(
			'code'            => $code,
			'name'            => $language['name'],
			'visible'         => $language['visible'],
			'id'              => $id,
			'status'          => $id > 0 ? (string) get_post_status( $id ) : '',
			'source_newer'    => $newer,
			'source_modified' => $source > 0 ? (string) get_post_modified_time( 'c', true, $source ) : '',
			'url'             => $id > 0 ? _ww_editor_url( $id ) : '',
		);
	}
	return array(
		'current' => $current,
		'items'   => $items,
	);
}

/**
 * Gegevens voor het zijpaneel bij de 404 of de zoekpagina: geen bericht en geen eigen velden, alleen de
 * Site-instellingen. Opslaan gaat naar ww/v1/editor/settings. Ook het antwoord na opslaan.
 *
 * Met een extra taal (beslissing 0042) krijgt het iframe het voorvoegsel van die taal (/en/?p=…), tonen en bewaren de
 * vertaalbare velden die taal, en staat in lang de code; zonder is lang ''. Met Meertalig actief staat in languages
 * het taalmenu, zonder "Vertaling maken": per taal een url naar dezelfde weergave met lang.
 *
 * @param string $view '404' of 'search'.
 * @param string $lang Taalcode van een extra taal, of '' voor de standaardtaal.
 * @return array<string,mixed>
 */
function _ww_editor_view_data( string $view, string $lang = '' ): array {
	$lang = _ww_settings_edit_language( $lang );
	// Een bericht-ID dat niet bestaat: een 404 bij elke permalinkinstelling.
	$frame = '404' === $view ? add_query_arg( 'p', WW_EDITOR_MISSING_ID, home_url( '/' ) ) : add_query_arg( 's', WW_EDITOR_SEARCH, home_url( '/' ) );
	$frame = '' === $lang ? $frame : _ww_languages_relink( $frame, $lang );
	$data  = array(
		'post'       => array(
			'id'        => 0,
			'title'     => '404' === $view ? __( 'Pagina niet gevonden (404)', 'webwerckt-base' ) : __( 'Zoekresultaten', 'webwerckt-base' ),
			'slug'      => '',
			'status'    => 'publish',
			'published' => true,
			'link'      => $frame,
			'frame'     => add_query_arg( WW_EDITOR_PARAM, $view, $frame ),
		),
		'view'       => $view,
		'lang'       => $lang,
		'fields'     => array(),
		'settings'   => _ww_editor_settings( $lang ),
		'views'      => _ww_editor_views(),
		'pages'      => _ww_editor_pages(),
		'canPublish' => false,
		'endpoint'   => '/' . WW_REST_NAMESPACE . '/editor/settings',
		'postTypes'  => _ww_editor_post_types(),
		'origin'     => _ww_origin( home_url() ),
	);
	if ( _ww_languages_active() ) {
		$data['languages'] = _ww_editor_view_languages( $view, '' === $lang ? _ww_default_language() : $lang );
	}
	return $data;
}

/**
 * Het taalmenu van de 404 en de zoekpagina: per taal (in de volgorde van de optie) de url van dezelfde weergave in die
 * taal. De standaardtaal krijgt geen lang in de url. Geen "Vertaling maken": de weergave bestaat in elke taal.
 *
 * @param string $view    '404' of 'search'.
 * @param string $current Code van de taal van deze weergave.
 * @return array{current:string,items:array<int,array{code:string,name:string,visible:bool,url:string}>}
 */
function _ww_editor_view_languages( string $view, string $current ): array {
	$items = array();
	foreach ( _ww_language_codes() as $code ) {
		$language = _ww_language( $code );
		if ( null === $language ) {
			continue;
		}
		$items[] = array(
			'code'    => $code,
			'name'    => $language['name'],
			'visible' => $language['visible'],
			'url'     => _ww_editor_view_url( $view, $code ),
		);
	}
	return array(
		'current' => $current,
		'items'   => $items,
	);
}

/**
 * Links naar de editor van de 404 en de zoekpagina, voor het menu onder de paginatitel; leeg zonder rechten op de
 * Site-instellingen, want daar staan hun teksten.
 *
 * @return array<int,array{view:string,label:string,url:string}>
 */
function _ww_editor_views(): array {
	if ( ! _ww_editor_can_edit_settings() ) {
		return array();
	}
	return array(
		array(
			'view'  => '404',
			'label' => __( 'Bewerk de 404-pagina', 'webwerckt-base' ),
			'url'   => _ww_editor_view_url( '404' ),
		),
		array(
			'view'  => 'search',
			'label' => __( 'Bewerk de zoekpagina', 'webwerckt-base' ),
			'url'   => _ww_editor_view_url( 'search' ),
		),
	);
}

/**
 * De pagina's waarnaar de editor kan wisselen (het menu onder de paginatitel en Ctrl+K): alles wat de gebruiker mag
 * bewerken, behalve de prullenbak, in de volgorde van de paginalijst. Subpagina's staan onder hun hoofdpagina met
 * een diepte; een subpagina waarvan de hoofdpagina ontbreekt (prullenbak, geen rechten, of in een andere taal), staat
 * als hoofdpagina. Met een taal alleen de pagina's in die taal.
 *
 * @param string $lang Taalcode, of '' voor alle talen.
 * @return array<int,array{id:int,title:string,depth:int,published:bool,url:string}>
 */
function _ww_editor_pages( string $lang = '' ): array {
	$query = array(
		'post_type'              => 'page',
		'post_status'            => array( 'publish', 'future', 'draft', 'pending', 'private' ),
		'numberposts'            => -1,
		'orderby'                => array(
			'menu_order' => 'ASC',
			'title'      => 'ASC',
		),
		'update_post_meta_cache' => false,
		'update_post_term_cache' => false,
	);
	if ( '' !== $lang ) {
		// De kern filtert de REST API en de admin niet, dus de taal staat hier expliciet in de query.
		$query['tax_query'] = _ww_languages_tax_query( $lang ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- de taalvoorwaarde, zoals de kern.
	}
	$pages    = array_filter(
		get_posts( $query ),
		static fn( WP_Post $page ): bool => current_user_can( 'edit_post', $page->ID )
	);
	$ids      = array_map( static fn( WP_Post $page ): int => $page->ID, $pages );
	$children = array();
	foreach ( $pages as $page ) {
		$parent                = in_array( $page->post_parent, $ids, true ) ? $page->post_parent : 0;
		$children[ $parent ][] = $page;
	}
	$list = array();
	$walk = static function ( int $parent, int $depth ) use ( &$walk, &$list, $children ): void {
		foreach ( $children[ $parent ] ?? array() as $page ) {
			$list[] = array(
				'id'        => $page->ID,
				'title'     => $page->post_title,
				'depth'     => $depth,
				'published' => _ww_editor_is_published( $page ),
				'url'       => _ww_editor_url( $page->ID ),
			);
			$walk( $page->ID, $depth + 1 );
		}
	};
	$walk( 0, 0 );
	return $list;
}

/**
 * URL van de pagina in het iframe: de voorbeeldlink, zodat ook een concept te zien is. De berichtenpagina krijgt haar
 * gewone link: met ?preview=true stuurt WordPress (redirect_canonical()) het overzicht door naar de homepage. Een
 * concept als berichtenpagina toont ook zonder voorbeeld het overzicht, want WordPress herkent haar aan haar ID.
 */
function _ww_editor_frame_url( WP_Post $post ): string {
	$url = (int) get_option( 'page_for_posts' ) === $post->ID ? get_permalink( $post ) : get_preview_post_link( $post );
	return add_query_arg( WW_EDITOR_PARAM, '1', (string) $url );
}

/**
 * Staat de pagina live (of ingepland, of privé)? Dan bestaat er geen concept meer naast.
 */
function _ww_editor_is_published( WP_Post $post ): bool {
	return in_array( $post->post_status, array( 'publish', 'future', 'private' ), true );
}

/**
 * Velden van de pagina voor het zijpaneel: label, type en waarde, plus titel en slug. Een foto krijgt een
 * voorbeeld-URL. Alleen de velden van zijn template (dezelfde als de abilities, ADR 0018).
 *
 * @return array<string,array<string,mixed>>
 */
function _ww_editor_fields( WP_Post $post ): array {
	$fields = array(
		'post_title' => array(
			'label'    => __( 'Titel', 'webwerckt-base' ),
			'type'     => 'text',
			'value'    => $post->post_title,
			'group'    => __( 'Algemeen', 'webwerckt-base' ),
			'groupKey' => 'general',
		),
		'post_name'  => array(
			'label'    => __( 'Slug (laatste deel van de URL)', 'webwerckt-base' ),
			'type'     => 'slug',
			'value'    => $post->post_name,
			'group'    => __( 'Algemeen', 'webwerckt-base' ),
			'groupKey' => 'general',
		),
	);
	foreach ( _ww_fields_for_post( $post ) as $name => $field ) {
		$item = _ww_editor_field( $name, $field, _ww_data_get_stored( $name, $post->ID ) );
		if ( 'pick' === $item['type'] ) {
			$item = _ww_editor_pick_field( $field, $item );
		}
		// Het paneel zet elk veld onder het label van zijn groep; groupKey is de naam van de groep.
		$fields[ $name ] = $item + array(
			'group'    => _ww_data_to_string( $field['group'] ?? '' ),
			'groupKey' => _ww_data_to_string( $field['group_name'] ?? '' ),
		);
	}
	return _ww_editor_add_sources( $post, $fields );
}

/**
 * Types waarvan het paneel in een vertaling de brontekst toont (Bron tonen).
 */
const WW_EDITOR_SOURCE_TYPES = array( 'text', 'paragraph', 'wysiwyg' );

/**
 * Platte tekst van een waarde, voor Bron tonen: zonder tags en met samengevoegde witruimte.
 *
 * @param mixed $value Opgeslagen waarde.
 */
function _ww_editor_plain_text( $value ): string {
	return trim( (string) preg_replace( '/\s+/u', ' ', wp_strip_all_tags( _ww_data_to_string( $value ) ) ) );
}

/**
 * Geeft in een vertaling elk tekst- en WYSIWYG-veld (en de titel) de sleutel source: de waarde van hetzelfde veld in
 * het bericht in de standaardtaal, als platte tekst. Ongewijzigd zonder Meertalig, zonder bron of voor een bericht dat
 * zelf de bron is.
 *
 * @param array<string,array<string,mixed>> $fields Velden van de pagina.
 * @return array<string,array<string,mixed>>
 */
function _ww_editor_add_sources( WP_Post $post, array $fields ): array {
	$source = '' !== _ww_editor_language( $post ) ? _ww_translation_source_id( $post->ID ) : 0;
	if ( $source <= 0 ) {
		return $fields;
	}
	foreach ( $fields as $name => $field ) {
		if ( 'post_title' === $name ) {
			$fields[ $name ]['source'] = _ww_editor_plain_text( get_post_field( 'post_title', $source ) );
		} elseif ( in_array( $field['type'] ?? '', WW_EDITOR_SOURCE_TYPES, true ) ) {
			$fields[ $name ]['source'] = _ww_editor_plain_text( _ww_data_get_stored( $name, $source ) );
		}
	}
	return $fields;
}

/**
 * Een veld voor het zijpaneel: label, type en waarde (_ww_fields_describe()); een foto krijgt een voorbeeld-URL.
 *
 * @param array<string,mixed> $field  Veld uit de configuratie.
 * @param mixed               $stored Opgeslagen waarde.
 * @return array<string,mixed>
 */
function _ww_editor_field( string $name, array $field, $stored ): array {
	$item = _ww_fields_describe( $field, $stored );
	// Zonder label toont het paneel de veldnaam.
	if ( ! isset( $field['label'] ) ) {
		$item['label'] = $name;
	}
	// Een sectie zonder opgeslagen schakelaar staat aan (ww_section_enabled()); het vinkje dus ook.
	if ( null === $stored && _ww_editor_is_toggle( $name ) ) {
		$item['value'] = true;
	}
	if ( 'file' === $item['type'] ) {
		$item['images']  = 'images' === ( $field['file_type'] ?? 'images' );
		$item['preview']  = is_int( $item['value'] ) ? (string) wp_get_attachment_image_url( $item['value'], 'medium' ) : '';
	}
	return $item;
}

/**
 * Velden van de Site-instellingen die de gebruiker in de editor mag bewerken, op naam: dezelfde als de abilities
 * (rechten, afgeschermde velden), zonder code (de scripts horen niet in een paneel voor tekst).
 *
 * @return array<string,array<string,mixed>>
 */
function _ww_editor_setting_fields(): array {
	return array_filter( _ww_fields_for_settings(), static fn( array $field ): bool => 'code' !== ( $field['type'] ?? '' ) );
}

/**
 * Mag de gebruiker in de editor Site-instellingen bewerken?
 */
function _ww_editor_can_edit_settings(): bool {
	return array() !== _ww_editor_setting_fields();
}

/**
 * Velden van de Site-instellingen voor het zijpaneel, zoals _ww_editor_fields(), met de naam van hun groep. Een
 * relatie zoekt via ww/v1/editor/settings/items; een nieuw bericht aanmaken kan hier niet.
 *
 * Met een extra taal (beslissing 0042) krijgt elk veld translatable. Een vertaalbaar veld toont in value de vertaling
 * (of '') en in fallback de waarde van de standaardtaal; een ander veld toont de waarde die voor alle talen geldt.
 *
 * @param string $lang Taalcode van een extra taal, of '' voor de standaardtaal.
 * @return array<string,array<string,mixed>>
 */
function _ww_editor_settings( string $lang = '' ): array {
	$lang     = _ww_settings_edit_language( $lang );
	$settings = array();
	foreach ( _ww_editor_setting_fields() as $name => $field ) {
		$translatable = '' !== $lang && _ww_setting_translatable( $field );
		$stored       = $translatable ? _ww_data_to_string( _ww_settings_translation( $lang )[ $name ] ?? '' ) : _ww_data_get_setting( $name, '' );
		if ( $translatable && '' === trim( $stored ) ) {
			$stored = '';
		}
		$item = _ww_editor_field( $name, $field, $stored );
		if ( 'pick' === $item['type'] ) {
			$item = array( 'create' => '' ) + _ww_editor_pick_field( $field, $item );
		}
		if ( '' !== $lang ) {
			$item['translatable'] = $translatable;
		}
		if ( $translatable ) {
			$item['fallback'] = _ww_data_to_string( _ww_data_get_setting( $name, '' ) );
		}
		$settings[ $name ] = $item + array(
			'group'    => _ww_data_to_string( $field['group'] ?? '' ),
			'groupKey' => _ww_data_to_string( $field['group_name'] ?? '' ),
		);
	}
	return $settings;
}

/**
 * Is dit veld de schakelaar van een sectie, child_{sectie}_enabled?
 */
function _ww_editor_is_toggle( string $name ): bool {
	return str_starts_with( $name, _ww_child_prefix() ) && str_ends_with( $name, '_enabled' );
}

/**
 * Een relatieveld voor het zijpaneel: de gekozen berichten in hun volgorde, met titel. Een bericht dat niet meer
 * bestaat of in de prullenbak ligt, valt weg; opslaan zou het weigeren (dezelfde controle als de abilities).
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @param array<string,mixed> $item  Label, type en waarde (ID of lijst met ID's).
 * @return array<string,mixed>
 */
function _ww_editor_pick_field( array $field, array $item ): array {
	$multiple = _ww_fields_is_multi( $field );
	$items    = array();
	foreach ( _ww_data_to_ids( $item['value'] ) as $id ) {
		$post = get_post( $id );
		if ( _ww_is_relatable_post( $post, _ww_data_to_string( $field['pick_val'] ?? '' ) ) ) {
			$items[] = _ww_editor_item( $post );
		}
	}
	$ids  = array_column( $items, 'id' );
	$type = _ww_editor_relation_type( $field );

	return array(
		'value'    => $multiple ? $ids : ( $ids[0] ?? 0 ),
		'multiple' => $multiple,
		// Alleen relaties met berichten zijn te bewerken, net als bij de abilities.
		'editable' => null !== $type,
		// Naam van één bericht van dat type, als de gebruiker er een mag aanmaken; anders ''.
		'create'   => null !== $type && current_user_can( $type->cap->create_posts ) ? (string) $type->labels->singular_name : '',
		'items'    => $items,
	) + $item;
}

/**
 * Het post type van een relatieveld met berichten, of null (geen relatie, of een relatie met iets anders).
 *
 * @param mixed $field Veld uit de configuratie.
 */
function _ww_editor_relation_type( $field ): ?WP_Post_Type {
	if ( ! is_array( $field ) || ! _ww_field_is_post_relation( $field ) ) {
		return null;
	}
	$type = get_post_type_object( _ww_data_to_string( $field['pick_val'] ?? '' ) );
	return $type instanceof WP_Post_Type ? $type : null;
}

/**
 * Een bericht in een relatie: ID, titel, of bezoekers het zien en, als de gebruiker het mag bewerken, de link
 * naar het bewerkscherm.
 *
 * @return array{id:int,title:string,published:bool,edit:string}
 */
function _ww_editor_item( WP_Post $post ): array {
	return array(
		'id'        => $post->ID,
		'title'     => $post->post_title,
		'published' => 'publish' === $post->post_status,
		'edit'      => current_user_can( 'edit_post', $post->ID ) ? (string) get_edit_post_link( $post->ID, 'raw' ) : '',
	);
}

/**
 * Teksten van het zijpaneel, vertaalbaar via het vertaalsjabloon van de parent.
 *
 * @return array<string,string>
 */
function _ww_editor_strings(): array {
	return array(
		'page'         => __( 'Deze pagina', 'webwerckt-base' ),
		'close'        => __( 'Sluiten', 'webwerckt-base' ),
		'draft'        => __( 'Concept', 'webwerckt-base' ),
		'published'    => __( 'Gepubliceerd', 'webwerckt-base' ),
		'saveDraft'    => __( 'Concept opslaan', 'webwerckt-base' ),
		'publish'      => __( 'Publiceren', 'webwerckt-base' ),
		'update'       => __( 'Bijwerken', 'webwerckt-base' ),
		'save'         => __( 'Opslaan', 'webwerckt-base' ),
		'saving'       => __( 'Bezig met opslaan…', 'webwerckt-base' ),
		'loading'      => __( 'Laden…', 'webwerckt-base' ),
		'saved'        => __( 'Opgeslagen.', 'webwerckt-base' ),
		'error'        => __( 'Opslaan is niet gelukt.', 'webwerckt-base' ),
		/* translators: %d: aantal wijzigingen; statusregel in de voet van het paneel. */
		'changesOne'   => _n( '%d wijziging nog niet opgeslagen', '%d wijzigingen nog niet opgeslagen', 1, 'webwerckt-base' ),
		/* translators: %d: aantal wijzigingen; statusregel in de voet van het paneel. */
		'changesMany'  => _n( '%d wijziging nog niet opgeslagen', '%d wijzigingen nog niet opgeslagen', 2, 'webwerckt-base' ),
		'noChanges'    => __( 'Geen wijzigingen', 'webwerckt-base' ),
		'viewLive'     => __( 'Bekijk live', 'webwerckt-base' ),
		'preview'      => __( 'Voorbeeld', 'webwerckt-base' ),
		'edit'         => __( 'Bewerken', 'webwerckt-base' ),
		'allPages'     => __( 'Alle pagina\'s', 'webwerckt-base' ),
		'collapse'     => __( 'Paneel inklappen', 'webwerckt-base' ),
		'expand'       => __( 'Paneel tonen', 'webwerckt-base' ),
		'onThisPage'   => __( 'Op deze pagina', 'webwerckt-base' ),
		'onThisPageHint' => __( 'Klik in de pagina op een tekst, knop of foto, of kies een sectie.', 'webwerckt-base' ),
		'noSections'   => __( 'Deze pagina heeft geen secties. Klik op een tekst of foto, of kies hieronder Deze pagina.', 'webwerckt-base' ),
		'siteLong'     => __( 'Hele site', 'webwerckt-base' ),
		'inPage'       => __( 'In de pagina', 'webwerckt-base' ),
		/* translators: %s: naam van de weergave waarnaar de terugknop gaat, bijvoorbeeld Op deze pagina. */
		'backTo'       => __( 'Terug naar %s', 'webwerckt-base' ),
		'fit'          => __( 'Passend', 'webwerckt-base' ),
		/* translators: %d: schaal van het voorbeeld in procenten; de zoomknop, bijvoorbeeld Passend · 62%. */
		'fitScale'     => __( 'Passend · %d%%', 'webwerckt-base' ),
		/* translators: zoomstand van het voorbeeld: ware grootte. */
		'fullSize'     => __( '100%', 'webwerckt-base' ),
		'zoom'         => __( 'Zoom', 'webwerckt-base' ),
		'live'         => __( 'Live', 'webwerckt-base' ),
		'generalGroup' => __( 'Titel en adres', 'webwerckt-base' ),
		'cantFind'     => __( 'Kun je iets niet vinden?', 'webwerckt-base' ),
		'searchAction' => __( 'Zoeken', 'webwerckt-base' ),
		/* translators: %d: breedte van het voorbeeld in pixels. */
		'desktopWidth' => __( 'Desktop · %dpx', 'webwerckt-base' ),
		/* translators: %d: breedte van het voorbeeld in pixels. */
		'tabletWidth'  => __( 'Tablet · %dpx', 'webwerckt-base' ),
		/* translators: %d: breedte van het voorbeeld in pixels. */
		'mobileWidth'  => __( 'Mobiel · %dpx', 'webwerckt-base' ),
		/* translators: %s: naam van de gebruiker. */
		'locked'       => __( '%s heeft deze pagina ook open. Wie het laatst opslaat, overschrijft de ander.', 'webwerckt-base' ),
		'chooseImage'  => __( 'Kies een foto', 'webwerckt-base' ),
		'useImage'     => __( 'Gebruik deze foto', 'webwerckt-base' ),
		'removeImage'  => __( 'Foto weghalen', 'webwerckt-base' ),
		'notYet'       => __( 'Dit veld kun je hier nog niet bewerken.', 'webwerckt-base' ),
		'searchLink'   => __( 'Zoek een pagina of typ een URL', 'webwerckt-base' ),
		'noLinkResults' => __( 'Niets gevonden. Typ een volledige URL, bijvoorbeeld https://…', 'webwerckt-base' ),
		/* translators: Opmaakkeuzes van de teksteditor, in het formaat van TinyMCE: label=element, gescheiden door ;. */
		'blockFormats' => __( 'Alinea=p;Kop 2=h2;Kop 3=h3;Kop 4=h4', 'webwerckt-base' ),
		'leave'        => __( 'Je hebt wijzigingen die nog niet zijn opgeslagen.', 'webwerckt-base' ),
		'hidden'       => __( 'verborgen', 'webwerckt-base' ),
		'inSettings'   => __( 'Staat in Site-instellingen', 'webwerckt-base' ),
		'site'         => __( 'Hele site', 'webwerckt-base' ),
		'siteShort'    => __( 'hele site', 'webwerckt-base' ),
		'siteNotice'   => __( 'Geldt voor de hele site, niet alleen voor deze pagina.', 'webwerckt-base' ),
		'addItem'      => __( 'Zoek om toe te voegen', 'webwerckt-base' ),
		'noItems'      => __( 'Nog niets gekozen.', 'webwerckt-base' ),
		'noMatches'    => __( 'Niets gevonden.', 'webwerckt-base' ),
		'untitled'     => __( '(geen titel)', 'webwerckt-base' ),
		'notPublished' => __( 'niet gepubliceerd', 'webwerckt-base' ),
		'moveUp'       => __( 'Omhoog', 'webwerckt-base' ),
		'moveDown'     => __( 'Omlaag', 'webwerckt-base' ),
		'removeItem'   => __( 'Weghalen', 'webwerckt-base' ),
		'editItem'     => __( 'Invullen (opent in een nieuw tabblad)', 'webwerckt-base' ),
		/* translators: 1: getypte titel, 2: naam van één bericht van het post type, bijvoorbeeld Dienst. */
		'createItem'   => __( '+ Nieuw aanmaken: „%1$s” (%2$s)', 'webwerckt-base' ),
		/* translators: %s: titel van het nieuwe bericht. */
		'created'      => __( '„%s” is aangemaakt als concept en gekoppeld. Vul het in en publiceer het (via het icoon in de lijst), dan verschijnt het na opslaan in de pagina.', 'webwerckt-base' ),
		'createError'  => __( 'Aanmaken is niet gelukt.', 'webwerckt-base' ),
		'afterSave'    => __( 'In de pagina zichtbaar na opslaan.', 'webwerckt-base' ),
		/* translators: %d: aantal gekozen berichten in een relatie. */
		'linked'       => __( '%d gekoppeld', 'webwerckt-base' ),
		'automatic'    => __( 'automatisch', 'webwerckt-base' ),
		/* translators: %s: naam van het post type, bijvoorbeeld Projecten. */
		'autoList'     => __( 'Deze lijst vult zich vanzelf met %s. Welke er staan en in welke volgorde, kies je hier niet: dat volgt uit de berichten zelf.', 'webwerckt-base' ),
		/* translators: %s: naam van het post type, bijvoorbeeld Projecten. */
		'manage'       => __( '%s beheren', 'webwerckt-base' ),
		'revert'       => __( 'Terugzetten', 'webwerckt-base' ),
		/* translators: %s: label van het veld. */
		'revertField'  => __( '%s terugzetten', 'webwerckt-base' ),
		'review'       => __( 'Wijzigingen bekijken', 'webwerckt-base' ),
		'changesTitle' => __( 'Wijzigingen', 'webwerckt-base' ),
		'discardAll'   => __( 'Alle wijzigingen weggooien', 'webwerckt-base' ),
		'discardConfirmOne' => __( 'De wijziging weggooien? Dit kan niet ongedaan worden gemaakt.', 'webwerckt-base' ),
		/* translators: %d: aantal wijzigingen dat wordt weggegooid. */
		'discardConfirmMany' => __( 'Alle %d wijzigingen weggooien? Dit kan niet ongedaan worden gemaakt.', 'webwerckt-base' ),
		'discarded'    => __( 'Wijzigingen weggegooid.', 'webwerckt-base' ),
		'versions'     => __( 'Versies', 'webwerckt-base' ),
		'currentVersion' => __( 'Huidige versie', 'webwerckt-base' ),
		'noVersions'   => __( 'Er zijn nog geen eerdere versies. Elke keer dat je opslaat, bewaart WordPress een versie.', 'webwerckt-base' ),
		'versionsNote' => __( 'Een versie zet tekst, foto\'s en de titel terug. Koppelingen (zoals diensten in een lijst) en Site-instellingen blijven zoals ze nu zijn.', 'webwerckt-base' ),
		'versionReplace' => __( 'Je niet-opgeslagen wijzigingen op deze pagina worden vervangen door deze versie. Doorgaan?', 'webwerckt-base' ),
		/* translators: %s: datum van de versie. */
		'versionLoaded' => __( 'Versie van %s staat in de pagina. Sla op om haar terug te zetten.', 'webwerckt-base' ),
		'versionSame'  => __( 'Deze versie is gelijk aan de huidige pagina.', 'webwerckt-base' ),
		'versionsError' => __( 'De versies konden niet worden geladen.', 'webwerckt-base' ),
		'otherPages'   => __( 'Pagina\'s', 'webwerckt-base' ),
		'general'      => __( 'Algemeen', 'webwerckt-base' ),
		'notOnPage'    => __( 'Niet zichtbaar op de pagina', 'webwerckt-base' ),
		'search'       => __( 'Zoeken (Ctrl+K)', 'webwerckt-base' ),
		'searchPlaceholder' => __( 'Zoek een veld, sectie of pagina', 'webwerckt-base' ),
		/* translators: %s: de zoekterm. */
		'noResults'    => __( 'Geen resultaten voor ‘%s’', 'webwerckt-base' ),
		'sections'     => __( 'Secties', 'webwerckt-base' ),
		'thisPage'     => __( 'Deze pagina', 'webwerckt-base' ),
		'groups'       => __( 'Groepen', 'webwerckt-base' ),
		'sectionKind'  => __( 'Sectie', 'webwerckt-base' ),
		'siteKind'     => __( 'Site', 'webwerckt-base' ),
		'switchLanguage' => __( 'Wissel van taal', 'webwerckt-base' ),
		'createTranslation' => __( 'Vertaling maken', 'webwerckt-base' ),
		/* translators: %s: datum waarop de bron is aangepast. */
		'sourceNewer'  => __( 'Bron aangepast op %s', 'webwerckt-base' ),
		'showSource'   => __( 'Bron tonen', 'webwerckt-base' ),
		'allLanguages' => __( 'Geldt voor alle talen', 'webwerckt-base' ),
		/* translators: %s: de waarde van het veld in de standaardtaal, als platte tekst. */
		'emptyFallback' => __( 'Leeg: %s', 'webwerckt-base' ),
		/* translators: %s: namen van de relaties die niet in de vertaling staan. */
		'notTranslated' => __( 'Niet overgenomen omdat ze nog niet vertaald zijn: %s', 'webwerckt-base' ),
		'duplicate'    => __( 'Deze pagina dupliceren', 'webwerckt-base' ),
		/* translators: %s: namen van de velden die niet meegingen bij het dupliceren. */
		'notCopied'    => __( 'Niet alles kon mee: %s', 'webwerckt-base' ),
		'duplicateUnsaved' => __( 'Je hebt wijzigingen die nog niet zijn opgeslagen. De kopie krijgt de opgeslagen versie en je wijzigingen gaan verloren. Toch dupliceren?', 'webwerckt-base' ),
		'viewHint'     => __( 'Klik in de pagina op een tekst om hem te bewerken. Deze teksten staan in de Site-instellingen.', 'webwerckt-base' ),
	);
}

/*
 * Opslaan.
 */

/**
 * Fout voor een pagina die niet (meer) bestaat.
 */
function _ww_editor_not_found(): WP_Error {
	return new WP_Error( 'ww_editor_post', __( 'Pagina niet gevonden.', 'webwerckt-base' ), array( 'status' => 404 ) );
}

// Argumenten die meer routes van de editor hebben: de pagina, het relatieveld en de zoekterm voor dat veld.
const WW_EDITOR_ID_ARG     = WW_REST_SCHEMA_ARG + array( 'type' => 'integer' );
const WW_EDITOR_FIELD_ARG  = WW_REST_SCHEMA_ARG + array(
	'type'     => 'string',
	'required' => true,
);
const WW_EDITOR_SEARCH_ARG = WW_REST_SCHEMA_ARG + array(
	'type'      => 'string',
	'maxLength' => 200,
	'default'   => '',
);

/**
 * Registreert de REST-routes van de editor.
 */
function _ww_editor_register_routes(): void {
	_ww_editor_register_save_route();
	_ww_editor_register_versions_routes();
	_ww_editor_register_settings_route();
	_ww_editor_register_items_routes();
	_ww_duplicate_register_route();
	if ( _ww_languages_active() ) {
		_ww_editor_register_translations_route();
	}
}
add_action( 'rest_api_init', '_ww_editor_register_routes' );

/**
 * POST ww/v1/editor/{id}: velden, titel en slug opslaan, en eventueel publiceren. Status '' bewaart de pagina zoals
 * hij is (concept of gepubliceerd), 'publish' publiceert een concept.
 */
function _ww_editor_register_save_route(): void {
	register_rest_route(
		WW_REST_NAMESPACE,
		'/editor/(?P<id>\d+)',
		array(
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => '_ww_editor_save',
			'permission_callback' => '_ww_editor_can_save',
			'args'                => array(
				'id'       => WW_EDITOR_ID_ARG,
				'fields'   => WW_REST_SCHEMA_ARG + array(
					'type'    => 'object',
					'default' => array(),
				),
				'settings' => WW_REST_SCHEMA_ARG + array(
					'type'    => 'object',
					'default' => array(),
				),
				'post'     => WW_REST_SCHEMA_ARG + array(
					'type'                 => 'object',
					'default'              => array(),
					'properties'           => array(
						'post_title' => array(
							'type'      => 'string',
							'maxLength' => 1000,
						),
						'post_name'  => array(
							'type'      => 'string',
							'maxLength' => 200,
						),
					),
					'additionalProperties' => false,
				),
				'status'   => WW_REST_SCHEMA_ARG + array(
					'type'    => 'string',
					'enum'    => array( '', 'publish' ),
					'default' => '',
				),
			),
		)
	);
}

/**
 * POST ww/v1/editor/settings: alleen Site-instellingen opslaan, vanuit de editor van de 404 of de zoekpagina.
 */
function _ww_editor_register_settings_route(): void {
	register_rest_route(
		WW_REST_NAMESPACE,
		'/editor/settings',
		array(
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => '_ww_editor_save_settings',
			'permission_callback' => '_ww_editor_can_edit_settings',
			'args'                => array(
				'settings' => WW_REST_SCHEMA_ARG + array(
					'type'    => 'object',
					'default' => array(),
				),
				'view'     => WW_REST_SCHEMA_ARG + array(
					'type'    => 'string',
					'enum'    => WW_EDITOR_VIEWS,
					'default' => '404',
				),
				// Met Meertalig: de extra taal waarin de vertaalbare velden bewaard worden (beslissing 0042).
				'lang'     => WW_REST_SCHEMA_ARG + array(
					'type'    => 'string',
					'default' => '',
				),
			),
		)
	);
}

/**
 * Berichten voor een relatieveld: GET ww/v1/editor/settings/items en GET ww/v1/editor/{id}/items zoeken, POST
 * ww/v1/editor/{id}/items maakt een concept.
 */
function _ww_editor_register_items_routes(): void {
	register_rest_route(
		WW_REST_NAMESPACE,
		'/editor/settings/items',
		array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => '_ww_editor_settings_items',
			'permission_callback' => '_ww_editor_can_edit_settings',
			'args'                => array(
				'field'  => WW_EDITOR_FIELD_ARG,
				'search' => WW_EDITOR_SEARCH_ARG,
			),
		)
	);
	register_rest_route(
		WW_REST_NAMESPACE,
		'/editor/(?P<id>\d+)/items',
		array(
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => '_ww_editor_items',
				'permission_callback' => '_ww_editor_can_save',
				'args'                => array(
					'id'     => WW_EDITOR_ID_ARG,
					'field'  => WW_EDITOR_FIELD_ARG,
					'search' => WW_EDITOR_SEARCH_ARG,
				),
			),
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => '_ww_editor_create_item',
				'permission_callback' => '_ww_editor_can_create_item',
				'args'                => array(
					'id'    => WW_EDITOR_ID_ARG,
					'field' => WW_EDITOR_FIELD_ARG,
					'title' => WW_REST_SCHEMA_ARG + array(
						'type'      => 'string',
						'required'  => true,
						'minLength' => 1,
						'maxLength' => 200,
					),
				),
			),
		)
	);
}

/**
 * POST ww/v1/editor/{id}/translations: maakt een vertaling van de pagina als concept (beslissing 0041). Alleen
 * geregistreerd als Meertalig aan staat.
 */
function _ww_editor_register_translations_route(): void {
	register_rest_route(
		WW_REST_NAMESPACE,
		'/editor/(?P<id>\d+)/translations',
		array(
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => '_ww_editor_create_translation',
			'permission_callback' => static fn( WP_REST_Request $request ): bool => _ww_translation_can_create( (int) $request->get_param( 'id' ) ),
			'args'                => array(
				'id'   => WW_EDITOR_ID_ARG,
				'lang' => WW_REST_SCHEMA_ARG + array(
					'type'     => 'string',
					'required' => true,
				),
			),
		)
	);
}

/**
 * POST ww/v1/editor/{id}/translations: de uitvoer van _ww_translation_create() (id, lang, source_id, status,
 * edit_url, dropped) plus editor_url, de URL van Visueel bewerken voor de vertaling. De status van een fout (400, een
 * bron die niet bestaat 404) komt uit _ww_translation_create().
 *
 * @return array<string,mixed>|WP_Error
 */
function _ww_editor_create_translation( WP_REST_Request $request ) {
	$result = _ww_translation_create( (int) $request->get_param( 'id' ), sanitize_key( (string) $request->get_param( 'lang' ) ) );
	if ( is_wp_error( $result ) ) {
		return $result;
	}
	return $result + array( 'editor_url' => _ww_editor_url( $result['id'] ) );
}

/**
 * Het post type van het relatieveld uit het verzoek (field), of een fout als het geen relatie van de pagina is.
 *
 * @return WP_Post_Type|WP_Error
 */
function _ww_editor_request_type( WP_REST_Request $request ) {
	$post = get_post( (int) $request->get_param( 'id' ) );
	if ( ! $post instanceof WP_Post ) {
		return _ww_editor_not_found();
	}
	$type = _ww_editor_relation_type( _ww_fields_for_post( $post )[ (string) $request->get_param( 'field' ) ] ?? null );
	return $type ?? new WP_Error( 'ww_editor_field', __( 'Dit veld is geen relatie van deze pagina.', 'webwerckt-base' ), array( 'status' => 400 ) );
}

/**
 * GET ww/v1/editor/{id}/items: berichten om aan een relatieveld van de pagina toe te voegen, van het post type van
 * dat veld. Zonder zoekterm de eerste op titel. Wie berichten van dat type niet mag bewerken, ziet alleen wat
 * gepubliceerd is. Een eigen route, omdat de zoekroute van WordPress alleen publieke post types kent.
 *
 * @return array<int,array<string,mixed>>|WP_Error
 */
function _ww_editor_items( WP_REST_Request $request ) {
	$type = _ww_editor_request_type( $request );
	if ( is_wp_error( $type ) ) {
		return $type;
	}
	$post = get_post( (int) $request->get_param( 'id' ) );
	return _ww_editor_find_items( $type, (string) $request->get_param( 'search' ), $post instanceof WP_Post ? _ww_editor_language( $post ) : '' );
}

/**
 * GET ww/v1/editor/settings/items: berichten om aan een relatieveld van de Site-instellingen toe te voegen, net als
 * _ww_editor_items().
 *
 * @return array<int,array<string,mixed>>|WP_Error
 */
function _ww_editor_settings_items( WP_REST_Request $request ) {
	$type = _ww_editor_relation_type( _ww_editor_setting_fields()[ (string) $request->get_param( 'field' ) ] ?? null );
	if ( null === $type ) {
		return new WP_Error( 'ww_editor_field', __( 'Dit veld is geen relatie van de Site-instellingen.', 'webwerckt-base' ), array( 'status' => 400 ) );
	}
	return _ww_editor_find_items( $type, (string) $request->get_param( 'search' ) );
}

/**
 * Hoeveel berichten het zoeken voor een relatieveld hoogstens geeft.
 */
const WW_EDITOR_ITEMS_LIMIT = 20;

/**
 * Berichten van een post type voor een relatieveld, op zoekterm. Zonder zoekterm de eerste op titel. Wie berichten
 * van dat type niet mag bewerken, ziet alleen wat gepubliceerd is. Wie alleen zijn eigen berichten mag bewerken
 * (geen edit_others_posts), ziet wat gepubliceerd is en zijn eigen concepten, niet de concepten van anderen:
 * perm readable houdt alleen privéberichten tegen. Met een taal en een vertaalbaar post type alleen berichten in die taal.
 *
 * @param string $lang Taalcode van de pagina, of ''.
 * @return array<int,array<string,mixed>>
 */
function _ww_editor_find_items( WP_Post_Type $type, string $search, string $lang = '' ): array {
	$search = sanitize_text_field( $search );
	$args   = array(
		'post_type'           => $type->name,
		'post_status'         => 'publish',
		'perm'                => 'readable',
		's'                   => $search,
		'orderby'             => '' === $search ? 'title' : 'relevance',
		'order'               => 'ASC',
		'posts_per_page'      => WW_EDITOR_ITEMS_LIMIT,
		'no_found_rows'       => true,
		'ignore_sticky_posts' => true,
	);
	if ( '' !== $lang && _ww_is_translatable( $type->name ) ) {
		// De kern filtert de REST API en de admin niet, dus de taal staat hier expliciet in de query. Een formulier kies
		// je in de standaardtaal; welke vertaling de pagina toont, kiest _ww_form_resolve() bij het tonen (0043).
		$args['tax_query'] = _ww_languages_tax_query( WW_FORM_POST_TYPE === $type->name ? _ww_default_language() : $lang ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- de taalvoorwaarde, zoals de kern.
	}

	$can_edit = current_user_can( $type->cap->edit_posts );
	if ( $can_edit && current_user_can( $type->cap->edit_others_posts ) ) {
		$posts = ( new WP_Query( array( 'post_status' => WW_EDITABLE_STATUSES ) + $args ) )->posts;
	} elseif ( $can_edit ) {
		$own   = ( new WP_Query(
			array(
				'post_status' => array_values( array_diff( WW_EDITABLE_STATUSES, array( 'publish' ) ) ),
				'author'      => get_current_user_id(),
				'perm'        => 'editable',
			) + $args
		) )->posts;
		$posts = array_slice( array_merge( ( new WP_Query( $args ) )->posts, $own ), 0, WW_EDITOR_ITEMS_LIMIT );
	} else {
		$posts = ( new WP_Query( $args ) )->posts;
	}
	return array_values( array_map( '_ww_editor_item', array_filter( $posts, static fn( $item ): bool => $item instanceof WP_Post ) ) );
}

/**
 * GET ww/v1/editor/{id}/versions en .../versions/{revision}: de eerdere versies van een pagina en de veldwaarden van
 * een versie. Alleen lezen; terugzetten gebeurt in de bewerker als niet-opgeslagen wijziging.
 */
function _ww_editor_register_versions_routes(): void {
	register_rest_route(
		WW_REST_NAMESPACE,
		'/editor/(?P<id>\d+)/versions',
		array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => '_ww_editor_versions_route',
			'permission_callback' => '_ww_editor_can_save',
			'args'                => array( 'id' => WW_EDITOR_ID_ARG ),
		)
	);
	register_rest_route(
		WW_REST_NAMESPACE,
		'/editor/(?P<id>\d+)/versions/(?P<revision>\d+)',
		array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => '_ww_editor_version_route',
			'permission_callback' => '_ww_editor_can_save',
			'args'                => array(
				'id'       => WW_EDITOR_ID_ARG,
				'revision' => WW_EDITOR_ID_ARG,
			),
		)
	);
}

// Aantal versies in de lijst van de bewerker.
const WW_EDITOR_VERSIONS_LIMIT = 30;

/**
 * Eerdere versies van een pagina, nieuwste eerst, zonder autosaves. De eerste is de huidige.
 *
 * Sorteert op ID: revisies van dezelfde seconde houden zo hun aanmaakvolgorde (de datum kan gelijk zijn).
 *
 * @return array<int,array{id:int,date:string,author:string,current:bool}>
 */
function _ww_editor_versions( WP_Post $post ): array {
	$revisions = wp_get_post_revisions(
		$post->ID,
		array(
			'orderby'        => 'ID',
			'order'          => 'DESC',
			'posts_per_page' => WW_EDITOR_VERSIONS_LIMIT + 1,
		)
	);
	$versions  = array();
	foreach ( $revisions as $revision ) {
		if ( wp_is_post_autosave( $revision ) ) {
			continue;
		}
		$versions[] = array(
			'id'      => $revision->ID,
			'date'    => wp_date( 'j F Y, H:i', get_post_timestamp( $revision ) ),
			'author'  => (string) get_the_author_meta( 'display_name', (int) $revision->post_author ),
			'current' => array() === $versions,
		);
		if ( count( $versions ) >= WW_EDITOR_VERSIONS_LIMIT ) {
			break;
		}
	}
	return $versions;
}

/**
 * De ID's in de waarde van een bestandsveld (één ID of een lijst).
 *
 * @param mixed $value Waarde zoals _ww_editor_field() die teruggeeft.
 * @return int[]
 */
function _ww_editor_version_ids( $value ): array {
	$ids = array();
	foreach ( is_array( $value ) ? $value : array( $value ) as $id ) {
		if ( is_numeric( $id ) && (int) $id > 0 ) {
			$ids[] = (int) $id;
		}
	}
	return $ids;
}

/**
 * De veldwaarden van een versie, voor de velden die de pagina nu heeft, die in revisies meegaan en een waarde in de
 * revisie hebben. Een relatie, de Site-instellingen en de slug horen er niet bij.
 *
 * @return array{fields: object, post_title: string}
 */
function _ww_editor_version( WP_Post $post, WP_Post $revision ): array {
	$allowed = _ww_revision_field_names( $post->post_type );
	$fields  = array();
	foreach ( _ww_fields_for_post( $post ) as $name => $field ) {
		if ( ! in_array( $name, $allowed, true ) || ! metadata_exists( 'post', $revision->ID, $name ) ) {
			continue;
		}
		$item = _ww_editor_field( $name, $field, _ww_data_empty_to_null( _ww_data_meta_value( get_post_meta( $revision->ID, $name, false ) ) ) );
		// Een bestand dat inmiddels weg is (of geen afbeelding meer), slaat Bijwerken af: het veld blijft dan buiten de versie.
		if ( 'file' === ( $field['type'] ?? '' ) && null !== _ww_fields_ids_error( _ww_editor_version_ids( $item['value'] ?? null ), 'attachment', 'images' === ( $field['file_type'] ?? 'images' ) ) ) {
			continue;
		}
		$result = array( 'value' => $item['value'] ?? null );
		if ( isset( $item['preview'] ) ) {
			$result['preview'] = (string) $item['preview'];
		}
		$fields[ $name ] = $result;
	}
	return array(
		// Een object, zodat een versie zonder velden in JSON {} wordt en geen [].
		'fields'     => (object) $fields,
		'post_title' => $revision->post_title,
	);
}

/**
 * Callback van GET ww/v1/editor/{id}/versions.
 *
 * @return WP_REST_Response|WP_Error
 */
function _ww_editor_versions_route( WP_REST_Request $request ) {
	$post = get_post( (int) $request->get_param( 'id' ) );
	if ( ! $post instanceof WP_Post ) {
		return _ww_editor_not_found();
	}
	return rest_ensure_response( array( 'versions' => _ww_editor_versions( $post ) ) );
}

/**
 * Callback van GET ww/v1/editor/{id}/versions/{revision}. Een bericht dat geen revisie is, een revisie van een
 * andere pagina en een autosave zijn geen versie: 404.
 *
 * @return WP_REST_Response|WP_Error
 */
function _ww_editor_version_route( WP_REST_Request $request ) {
	$post     = get_post( (int) $request->get_param( 'id' ) );
	$revision = get_post( (int) $request->get_param( 'revision' ) );
	if ( ! $post instanceof WP_Post || ! $revision instanceof WP_Post
		|| 'revision' !== $revision->post_type
		|| $revision->post_parent !== $post->ID
		|| wp_is_post_autosave( $revision ) ) {
		return _ww_editor_not_found();
	}
	return rest_ensure_response( _ww_editor_version( $post, $revision ) );
}

/**
 * Mag de gebruiker deze pagina visueel bewerken? De nonce van de REST API (X-WP-Nonce) logt hem in.
 */
function _ww_editor_can_save( WP_REST_Request $request ): bool {
	$post = get_post( (int) $request->get_param( 'id' ) );
	return $post instanceof WP_Post && _ww_editor_can_edit( $post );
}

/**
 * Mag de gebruiker deze pagina bewerken én een bericht maken van het post type van het relatieveld? Is het veld
 * geen relatie, dan meldt _ww_editor_create_item() dat.
 */
function _ww_editor_can_create_item( WP_REST_Request $request ): bool {
	$type = _ww_editor_request_type( $request );
	return _ww_editor_can_save( $request ) && ( is_wp_error( $type ) || current_user_can( $type->cap->create_posts ) );
}

/**
 * POST ww/v1/editor/{id}/items: maakt een concept met deze titel van het post type van het relatieveld, om meteen
 * te koppelen. Een concept, net als de ability create-post: een bericht met alleen een titel hoort niet live te
 * staan. De kaart verschijnt pas in de pagina als het bericht is ingevuld en gepubliceerd. Koppelen gebeurt pas bij
 * het opslaan van de pagina; wie dat niet doet, houdt een los concept over.
 *
 * @return array<string,mixed>|WP_Error
 */
function _ww_editor_create_item( WP_REST_Request $request ) {
	$type = _ww_editor_request_type( $request );
	if ( is_wp_error( $type ) ) {
		return $type;
	}
	$title = sanitize_text_field( (string) $request->get_param( 'title' ) );
	if ( '' === $title ) {
		return new WP_Error( 'ww_editor_title', __( 'Geef het bericht een titel.', 'webwerckt-base' ), array( 'status' => 400 ) );
	}
	$id = _ww_create_draft( $type->name, $title );
	if ( is_wp_error( $id ) ) {
		return $id;
	}
	// Een nieuw bericht krijgt de taal van de pagina, net als de relaties die er al staan.
	$page = get_post( (int) $request->get_param( 'id' ) );
	$lang = $page instanceof WP_Post ? _ww_editor_language( $page ) : '';
	if ( '' !== $lang && _ww_is_translatable( $type->name ) && WW_FORM_POST_TYPE !== $type->name ) {
		$set = _ww_set_post_language( $id, $lang );
		if ( is_wp_error( $set ) ) {
			wp_delete_post( $id, true );
			return $set;
		}
	}
	$item = get_post( $id );
	return $item instanceof WP_Post ? _ww_editor_item( $item ) : _ww_editor_not_found();
}

/**
 * Slaat de wijzigingen op zoals "Bijwerken" in de admin: velden via Pods (gecontroleerd zoals bij de abilities),
 * Site-instellingen via hun instellingen-pod, daarna titel, slug en status met wp_update_post(), dus één revisie, de kopie naar post_content en het legen van
 * de cache. Geeft de nieuwe gegevens van de pagina, of een fout.
 *
 * @return array<string,mixed>|WP_Error
 */
function _ww_editor_save( WP_REST_Request $request ) {
	$post = get_post( (int) $request->get_param( 'id' ) );
	if ( ! $post instanceof WP_Post ) {
		return _ww_editor_not_found();
	}
	$update = _ww_editor_post_update( $post, (array) $request->get_param( 'post' ), (string) $request->get_param( 'status' ) );
	if ( is_wp_error( $update ) ) {
		return $update;
	}
	$fields = _ww_fields_input( $request->get_param( 'fields' ), _ww_fields_for_post( $post ) );
	if ( is_wp_error( $fields ) ) {
		return $fields;
	}
	// Site-instellingen alleen die de gebruiker mag bewerken; een ander veld is een fout, nog vóór er iets is opgeslagen.
	$allowed  = _ww_editor_setting_fields();
	$settings = _ww_fields_input( $request->get_param( 'settings' ), $allowed );
	if ( is_wp_error( $settings ) ) {
		return $settings;
	}
	if ( array() !== $fields ) {
		$error = _ww_fields_pods_save( $post->post_type, $post->ID, $fields );
		if ( null !== $error ) {
			return $error;
		}
	}
	// De taal van de Site-instellingen is die van de pagina, nooit die uit de invoer.
	$error = _ww_editor_store_settings( $settings, $allowed, _ww_settings_edit_language( _ww_editor_language( $post ) ) );
	if ( null !== $error ) {
		return $error;
	}

	$result = _ww_update_post( $update );
	if ( is_wp_error( $result ) ) {
		return $result;
	}
	// De vergrendeling staat in de admin-include, die de REST API niet laadt.
	require_once ABSPATH . 'wp-admin/includes/post.php';
	wp_set_post_lock( $post->ID );
	$post = get_post( $post->ID );
	return $post instanceof WP_Post ? _ww_editor_data( $post ) : _ww_editor_not_found();
}

/**
 * POST ww/v1/editor/settings: slaat alleen Site-instellingen op, vanuit de editor van de 404 of de zoekpagina. Geeft
 * de nieuwe gegevens van het scherm, of een fout.
 *
 * @return array<string,mixed>|WP_Error
 */
function _ww_editor_save_settings( WP_REST_Request $request ) {
	// De taal komt hier uit de invoer, maar alleen een extra taal (of de standaardtaal) wordt aanvaard.
	$lang = _ww_settings_input_language( $request->get_param( 'lang' ) );
	if ( is_wp_error( $lang ) ) {
		return $lang;
	}
	$allowed  = _ww_editor_setting_fields();
	$settings = _ww_fields_input( $request->get_param( 'settings' ), $allowed );
	if ( is_wp_error( $settings ) ) {
		return $settings;
	}
	$error = _ww_editor_store_settings( $settings, $allowed, $lang );
	return null === $error ? _ww_editor_view_data( (string) $request->get_param( 'view' ), $lang ) : $error;
}

/**
 * Bewaart gecontroleerde Site-instellingen. Met een extra taal gaan de vertaalbare velden naar ww_settings_{lang} en de
 * rest (telefoon, foto's, relaties) naar Pods, zoals zonder taal. Alles is al gecontroleerd; eerst Pods, dat nog kan
 * falen, dan de vertalingen, die na de splitsing niet meer falen: een fout bewaart nooit half.
 *
 * @param array<string,mixed>               $settings Veldnaam => gecontroleerde waarde.
 * @param array<string,array<string,mixed>> $allowed  Toegestane velden op naam.
 * @param string                            $lang     Een extra taal (_ww_settings_edit_language()), of ''.
 */
function _ww_editor_store_settings( array $settings, array $allowed, string $lang ): ?WP_Error {
	if ( '' === $lang ) {
		return _ww_fields_save_settings( $settings, $allowed );
	}
	$own   = array_filter( $settings, static fn( $name ): bool => _ww_setting_translatable( $allowed[ $name ] ?? array() ), ARRAY_FILTER_USE_KEY );
	$error = _ww_fields_save_settings( array_diff_key( $settings, $own ), $allowed );
	if ( null !== $error || array() === $own ) {
		return $error;
	}
	return _ww_settings_save_translation( $own, $lang );
}

/**
 * Gegevens voor wp_update_post(): titel, slug en status, of een fout. Publiceren vraagt het recht daarvoor.
 *
 * Alles wat wp_update_post() zou weigeren, wordt hier al geweigerd: de velden zijn dan nog niet opgeslagen, zodat
 * een fout nooit half opslaat. Een lege titel is zo'n fout, want een pagina zonder titel en tekst slaat WordPress
 * niet op.
 *
 * @param array<string,mixed> $input  post_title en post_name.
 * @param string              $status '' of 'publish'.
 * @return array<string,mixed>|WP_Error
 */
function _ww_editor_post_update( WP_Post $post, array $input, string $status ) {
	$publish = 'publish' === $status && ! _ww_editor_is_published( $post );
	if ( $publish && ! _ww_editor_can_publish( $post ) ) {
		return new WP_Error( 'ww_editor_status', __( 'Je mag deze pagina niet publiceren.', 'webwerckt-base' ), array( 'status' => 403 ) );
	}

	$update = array( 'ID' => $post->ID );
	if ( isset( $input['post_title'] ) ) {
		$update['post_title'] = sanitize_text_field( _ww_data_to_string( $input['post_title'] ) );
		if ( '' === $update['post_title'] ) {
			return new WP_Error( 'ww_editor_title', __( 'Geef de pagina een titel.', 'webwerckt-base' ), array( 'status' => 400 ) );
		}
	}
	if ( isset( $input['post_name'] ) ) {
		$update['post_name'] = sanitize_title( _ww_data_to_string( $input['post_name'] ) );
	}
	if ( $publish ) {
		$update['post_status'] = 'publish';
	}
	return $update;
}
