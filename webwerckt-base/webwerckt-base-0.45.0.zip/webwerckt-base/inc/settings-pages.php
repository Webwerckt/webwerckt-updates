<?php
/**
 * De Site-instellingen als eigen scherm met een pagina per onderwerp (beslissing 0025). De opslag blijft één pod
 * `site_settings`: dezelfde opties, helpers en abilities. Pods dient alleen nog als opslag; het scherm is van het thema.
 *
 * - Elke groep in pods/settings.json noemt zijn pagina (`page`). Een groep zonder bekende pagina, zoals een groep
 *   van het child-thema zonder `page`, komt op Overige.
 * - Het scherm is een eigen hoofditem in het menu (admin.php?page=ww-site-settings) met &section={pagina}. Het item
 *   van Pods (pods-settings-site_settings) wordt weggehaald; een oude URL daarheen stuurt door met dezelfde section.
 * - Het scherm slaat per pagina op, alleen de velden van die pagina (zie settings-admin.php).
 * - Een pagina staat alleen in het scherm van wie er minstens één veld mag bewerken.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// De pod van de Site-instellingen, de slug van het eigen scherm en die van het scherm van Pods (dat verdwijnt).
const WW_SETTINGS_POD         = 'site_settings';
const WW_SETTINGS_SCREEN      = 'ww-site-settings';
const WW_SETTINGS_PODS_SCREEN = 'pods-settings-' . WW_SETTINGS_POD;
// De pagina voor groepen zonder bekende pagina.
const WW_SETTINGS_OTHER = 'other';

/**
 * De pagina's van de Site-instellingen, op slug, in de volgorde van het menu. Het child-thema voegt eigen pagina's
 * toe met het filter `ww_settings_pages` (slug => label); pagina's van de parent kan het niet vervangen. Overige
 * staat altijd als laatste.
 *
 * @return array<string,string>
 */
function _ww_settings_pages(): array {
	$pages = array(
		'contact'  => __( 'Contact & openingstijden', 'webwerckt-base' ),
		'social'   => __( 'Social media & footer', 'webwerckt-base' ),
		'notfound' => __( '404 & zoeken', 'webwerckt-base' ),
		'seo'      => __( 'SEO', 'webwerckt-base' ),
		'scripts'  => __( 'Scripts', 'webwerckt-base' ),
	);

	$extra = apply_filters( 'ww_settings_pages', array() );
	foreach ( is_array( $extra ) ? $extra : array() as $slug => $label ) {
		$slug  = sanitize_key( (string) $slug );
		$label = _ww_data_to_string( $label );
		if ( '' !== $slug && '' !== $label && ! isset( $pages[ $slug ] ) && WW_SETTINGS_OTHER !== $slug ) {
			$pages[ $slug ] = $label;
		}
	}

	$pages[ WW_SETTINGS_OTHER ] = __( 'Overige', 'webwerckt-base' );
	return $pages;
}

/**
 * De pod Site-instellingen uit de configuratie, of een lege lijst.
 *
 * @return array<string,mixed>
 */
function _ww_settings_pod(): array {
	foreach ( _ww_pods_config() as $pod ) {
		if ( 'settings' === ( $pod['type'] ?? '' ) && WW_SETTINGS_POD === ( $pod['name'] ?? '' ) ) {
			return $pod;
		}
	}
	return array();
}

/**
 * Groepen van de pod Site-instellingen uit de configuratie.
 *
 * @return array<int,array<string,mixed>>
 */
function _ww_settings_groups(): array {
	$pod = _ww_settings_pod();
	return is_array( $pod['groups'] ?? null ) ? array_values( array_filter( $pod['groups'], 'is_array' ) ) : array();
}

/**
 * De pagina van een groep: zijn `page` als die bestaat, anders Overige.
 *
 * @param array<string,mixed>  $group Groep uit de configuratie.
 * @param array<string,string> $pages Pagina's (_ww_settings_pages()).
 */
function _ww_settings_group_page( array $group, array $pages ): string {
	$page = sanitize_key( _ww_data_to_string( $group['page'] ?? '' ) );
	return '' !== $page && isset( $pages[ $page ] ) ? $page : WW_SETTINGS_OTHER;
}

/**
 * Pagina per groepnaam.
 *
 * @return array<string,string>
 */
function _ww_settings_group_pages(): array {
	$pages = _ww_settings_pages();
	$map   = array();
	foreach ( _ww_settings_groups() as $group ) {
		$map[ _ww_data_to_string( $group['name'] ?? '' ) ] = _ww_settings_group_page( $group, $pages );
	}
	return $map;
}

/**
 * Mag de huidige gebruiker dit veld van de Site-instellingen bewerken? Dezelfde regel als _ww_fields_for_settings():
 * beheerder of pods_edit_site_settings, en het veld niet afgeschermd met restrict_capability.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 */
function _ww_settings_field_editable( array $field ): bool {
	return ( current_user_can( 'edit_theme_options' ) || current_user_can( 'pods_edit_' . WW_SETTINGS_POD ) ) && ! _ww_field_restricted( $field );
}

/**
 * De pagina's waarop de huidige gebruiker minstens één veld mag bewerken, op slug, in de volgorde van het menu.
 *
 * @return array<string,string>
 */
function _ww_settings_visible_pages(): array {
	$pages   = _ww_settings_pages();
	$visible = array();
	foreach ( _ww_settings_groups() as $group ) {
		$fields = is_array( $group['fields'] ?? null ) ? array_filter( $group['fields'], 'is_array' ) : array();
		foreach ( $fields as $field ) {
			if ( _ww_settings_field_editable( $field ) ) {
				$visible[ _ww_settings_group_page( $group, $pages ) ] = true;
				break;
			}
		}
	}
	return array_intersect_key( $pages, $visible );
}

/**
 * Is dit verzoek het scherm van de Site-instellingen (ook het opslaan, dat naar dezelfde URL gaat)?
 */
function _ww_settings_is_screen(): bool {
	return is_admin() && WW_SETTINGS_SCREEN === _ww_query_key( 'page' );
}

/**
 * De gevraagde pagina: `section` uit de URL, of zonder `section` de eerste pagina die de gebruiker mag zien (zo
 * komt een oude bladwijzer naar het scherm daar uit). '' als de gebruiker geen enkele pagina mag zien.
 */
function _ww_settings_current_page(): string {
	$section = _ww_query_key( 'section' );
	if ( '' !== $section ) {
		return $section;
	}
	return (string) array_key_first( _ww_settings_visible_pages() );
}

/**
 * URL van het scherm. De eerste zichtbare pagina krijgt geen `section`: het scherm opent daar vanzelf.
 *
 * @param string               $section Slug van de pagina, of '' voor de eerste.
 * @param array<string,string> $args    Extra queryargumenten.
 */
function _ww_settings_url( string $section = '', array $args = array() ): string {
	$query = array( 'page' => WW_SETTINGS_SCREEN );
	if ( '' !== $section && $section !== (string) array_key_first( _ww_settings_visible_pages() ) ) {
		$query['section'] = $section;
	}
	return add_query_arg( $query + $args, admin_url( 'admin.php' ) );
}

/*
 * Het menu.
 */

/**
 * Haalt het item van Pods weg en zet het eigen scherm in het menu (op admin_menu 20, na Pods). Het item staat er
 * alleen voor wie minstens één pagina ziet; het recht is `read`, de controle gebeurt in de code.
 */
function _ww_settings_menu(): void {
	remove_menu_page( WW_SETTINGS_PODS_SCREEN );
	if ( array() === _ww_settings_visible_pages() ) {
		return;
	}
	$pod      = _ww_settings_pod();
	$label    = _ww_data_to_string( $pod['menu_name'] ?? '' );
	$icon     = _ww_data_to_string( $pod['menu_icon'] ?? '' );
	$position = $pod['menu_position'] ?? null;
	$hook     = add_menu_page(
		'' !== $label ? $label : __( 'Site-instellingen', 'webwerckt-base' ),
		'' !== $label ? $label : __( 'Site-instellingen', 'webwerckt-base' ),
		'read',
		WW_SETTINGS_SCREEN,
		'_ww_settings_render',
		'' !== $icon ? $icon : 'dashicons-admin-settings',
		is_numeric( $position ) ? (int) $position : 59
	);
	add_action( 'load-' . $hook, '_ww_settings_handle_save' );
}
add_action( 'admin_menu', '_ww_settings_menu', 20 );

/**
 * Stuurt een oude URL van het scherm van Pods door naar het eigen scherm (bladwijzers).
 *
 * @return string De doel-URL, of '' als dit niet de oude pagina is.
 */
function _ww_settings_pods_redirect_url(): string {
	if ( WW_SETTINGS_PODS_SCREEN !== _ww_query_key( 'page' ) ) {
		return '';
	}
	$section = _ww_query_key( 'section' );
	return admin_url( 'admin.php?page=' . WW_SETTINGS_SCREEN . ( '' !== $section ? '&section=' . $section : '' ) );
}

/**
 * Doet die doorverwijzing, voordat Pods zijn eigen scherm tekent.
 */
function _ww_settings_redirect_pods_screen(): void {
	$url = _ww_settings_pods_redirect_url();
	if ( '' !== $url ) {
		wp_safe_redirect( $url );
		exit;
	}
}
add_action( 'admin_init', '_ww_settings_redirect_pods_screen' );

/*
 * Het scherm.
 */

/**
 * Vóór de uitvoer van het scherm: een pagina die de gebruiker niet mag zien of die niet bestaat, geeft een melding
 * in plaats van een leeg formulier. De titel van het tabblad wordt die van de pagina.
 */
function _ww_settings_screen_load(): void {
	if ( ! _ww_settings_is_screen() ) {
		return;
	}
	$pages = _ww_settings_visible_pages();
	$page  = _ww_settings_current_page();
	if ( '' === $page ) {
		return; // Zonder pagina staat het scherm niet in het menu; WordPress weigert de toegang zelf.
	}
	if ( ! isset( $pages[ $page ] ) ) {
		wp_die( esc_html__( 'Deze pagina van de Site-instellingen bestaat niet of je mag hem niet bewerken.', 'webwerckt-base' ), 403 );
	}
	$GLOBALS['title'] = _ww_settings_page_title( $pages[ $page ] ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- de titel van admin-header.php.
}
add_action( 'current_screen', '_ww_settings_screen_load' );

/**
 * Titel van een pagina: "Site-instellingen › SEO".
 *
 * @param string $label Label van de pagina.
 */
function _ww_settings_page_title( string $label ): string {
	$menu = __( 'Site-instellingen', 'webwerckt-base' );
	/* translators: 1: Site-instellingen, 2: naam van de pagina, zoals SEO. */
	return sprintf( __( '%1$s › %2$s', 'webwerckt-base' ), $menu, $label );
}

/**
 * Haalt de eigen sleutel `page` uit de groepen voordat de pod naar Pods gaat; Pods kent hem niet.
 *
 * @param array<string,mixed> $pod Pod uit de configuratie.
 * @return array<string,mixed>
 */
function _ww_settings_strip_pages( array $pod ): array {
	if ( 'settings' !== ( $pod['type'] ?? '' ) || ! is_array( $pod['groups'] ?? null ) ) {
		return $pod;
	}
	$pod['groups'] = array_map(
		static function ( $group ) {
			if ( is_array( $group ) ) {
				unset( $group['page'], $group['ww_layout'] );
			}
			return $group;
		},
		$pod['groups']
	);
	return $pod;
}
