<?php
/**
 * Meertalig (beslissing 0040), onderdeel WP-CLI: wp ww languages list en set-default.
 *
 * De klasse bestaat altijd, zodat de tests hem direct kunnen aanroepen; WP-CLI kent het commando alleen als WP_CLI
 * gedefinieerd is. Zonder actieve module (Meertalig uit, of een vertaalplugin actief) weigert set-default. set-default
 * zet alles om, in vaste stappen (beslissing 0044).
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * De vertaalbare berichten zonder taalterm (ze horen bij de standaardtaal), per post type.
 *
 * @return array<string,int[]>
 */
function _ww_languages_untagged_posts(): array {
	$posts = array();
	foreach ( _ww_translatable_post_types() as $type ) {
		$ids = get_posts(
			array(
				'post_type'        => $type,
				'post_status'      => _ww_languages_counted_statuses(),
				'tax_query'        => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- alleen in WP-CLI.
					array(
						'taxonomy' => 'ww_language',
						'operator' => 'NOT EXISTS',
					),
				),
				'fields'           => 'ids',
				'posts_per_page'   => -1,
				'suppress_filters' => false,
			)
		);
		if ( array() !== $ids ) {
			$posts[ $type ] = array_map( 'intval', $ids );
		}
	}
	return $posts;
}

/**
 * Een waarde kort in de uitvoer van set-default: zonder HTML, hoogstens 50 tekens, tussen aanhalingstekens.
 *
 * @param string $value Tekst.
 */
function _ww_languages_switch_text( string $value ): string {
	return '"' . mb_strimwidth( trim( wp_strip_all_tags( $value ) ), 0, 50, '…' ) . '"';
}

/**
 * Stap berichten van set-default (kern): alle vertaalbare berichten zonder taalterm krijgen de oude standaardtaal, zodat
 * ze in hun taal blijven.
 *
 * @param string $old     De huidige standaardtaal.
 * @param string $new     De nieuwe standaardtaal.
 * @param bool   $dry_run Alleen tonen wat er verandert.
 * @return string[] Per post type een regel.
 */
function _ww_languages_switch_posts( string $old, string $new, bool $dry_run ): array {
	$untagged = _ww_languages_untagged_posts();
	$lines    = array();
	foreach ( $untagged as $type => $ids ) {
		$lines[] = sprintf( '%s: %d zonder taal %s %s.', $type, count( $ids ), $dry_run ? 'krijgen' : 'kregen', $old );
	}
	if ( $dry_run ) {
		return $lines;
	}

	_ww_languages_sync_terms();
	foreach ( $untagged as $ids ) {
		foreach ( $ids as $id ) {
			wp_set_object_terms( $id, $old, 'ww_language' );
		}
	}
	return $lines;
}

/**
 * Stap Site-instellingen van set-default (3a). Per vertaalbaar veld wordt de vertaling uit ww_settings_{nieuw} de
 * standaard (via Pods) en gaat de tekst van de standaardtaal naar ww_settings_{oud}. Een veld zonder vertaling houdt zijn
 * tekst en krijgt die ook in ww_settings_{oud}. Een vertaling gelijk aan de tekst van de standaardtaal gaat niet naar
 * ww_settings_{oud}: daar valt de taal toch op terug, en zo geeft heen en terug precies de beginstand. Daarna gaat
 * ww_settings_{nieuw} weg. Niet-vertaalbare velden blijven staan.
 *
 * Hervatten na een fout (zolang een taal de standaardtaal is, staat er niets onder zijn code):
 * - bestaat ww_settings_{nieuw} niet meer en ww_settings_{oud} wel, dan is de stap al gedaan;
 * - een veld dat al in ww_settings_{oud} staat, is bewaard; heeft ww_settings_{nieuw} er nog een andere vertaling voor,
 *   dan is alleen de Pods-save nog niet gelukt en gebeurt die alsnog.
 * Is ww_settings_{nieuw} er, dan krijgt ww_settings_{oud} na de stap altijd een waarde (ook een lege lijst), zodat een
 * volgende run weet dat de stap gedaan is.
 *
 * @param string $old     De huidige standaardtaal.
 * @param string $new     De nieuwe standaardtaal.
 * @param bool   $dry_run Alleen tonen wat er verandert.
 * @return string[]|WP_Error Per veld een regel; een fout als Pods niet kon opslaan.
 */
function _ww_languages_switch_settings( string $old, string $new, bool $dry_run ): array|WP_Error {
	$has_source = false !== get_option( 'ww_settings_' . $new );
	$has_stored = false !== get_option( 'ww_settings_' . $old );
	if ( ! $has_source && $has_stored ) {
		return array();
	}
	$source  = _ww_settings_translation( $new );
	$stored  = _ww_settings_translation( $old );
	$target  = $stored;
	$save    = array();
	$allowed = array();
	$lines   = array();
	$seen    = array();

	foreach ( _ww_pods_setting_fields() as $field ) {
		$name = _ww_data_to_string( $field['name'] ?? '' );
		if ( '' === $name || isset( $seen[ $name ] ) || ! _ww_setting_translatable( $field ) ) {
			continue;
		}
		$seen[ $name ] = true;
		$current       = _ww_data_to_string( get_option( _ww_settings_prefix() . $name, '' ) );
		$translation   = _ww_data_to_string( $source[ $name ] ?? '' );
		$translated    = '' !== trim( $translation );
		if ( ! $translated && '' === trim( $current ) ) {
			continue;
		}

		if ( array_key_exists( $name, $stored ) ) {
			// Al bewaard in een eerdere run; alleen de Pods-save kan nog ontbreken.
			if ( $translated && $translation !== $current ) {
				$save[ $name ]    = $translation;
				$allowed[ $name ] = $field;
				$lines[]          = sprintf( '%s: %s wordt de standaard (hervat).', $name, _ww_languages_switch_text( $translation ) );
			}
			continue;
		}
		if ( '' !== trim( $current ) && $translation !== $current ) {
			$target[ $name ] = $current;
		}
		if ( $translated && $translation !== $current ) {
			$save[ $name ]    = $translation;
			$allowed[ $name ] = $field;
			$lines[]          = sprintf( '%s: %s wordt de standaard; %s gaat naar ww_settings_%s.', $name, _ww_languages_switch_text( $translation ), _ww_languages_switch_text( $current ), $old );
		} elseif ( $translated ) {
			$lines[] = sprintf( '%s: %s is in beide talen gelijk en blijft de standaard.', $name, _ww_languages_switch_text( $current ) );
		} else {
			$lines[] = sprintf( '%s: geen vertaling in %s; %s blijft de standaard en staat ook in ww_settings_%s.', $name, $new, _ww_languages_switch_text( $current ), $old );
		}
	}
	$remove = $has_source;
	if ( $remove ) {
		$lines[] = sprintf( 'ww_settings_%s wordt verwijderd.', $new );
	}
	if ( $dry_run ) {
		return $lines;
	}

	// Eerst de tekst van de standaardtaal bewaren, dan pas overschrijven: zo gaat er bij een fout niets verloren.
	if ( $target !== $stored || ( $has_source && ! $has_stored ) ) {
		update_option( 'ww_settings_' . $old, $target, true );
	}
	if ( array() !== $save ) {
		$error = _ww_fields_save_settings( $save, $allowed );
		if ( null !== $error ) {
			return $error;
		}
	}
	if ( $remove ) {
		delete_option( 'ww_settings_' . $new );
	}
	return $lines;
}

/**
 * Stap termen van set-default (3b), voor één term. Naam, slug en beschrijving wisselen om met _ww_term_{nieuw}: per
 * veld wordt de vertaling de gewone term en gaat de oude waarde naar _ww_term_{oud} (met _ww_term_slug_{oud}). Een veld
 * zonder vertaling houdt zijn waarde en krijgt die ook in _ww_term_{oud}; een vertaling gelijk aan de gewone waarde gaat
 * daar niet heen (zoals bij de Site-instellingen).
 *
 * Verandert de slug, dan houden de andere extra talen (ook verborgen) hun adres, zoals bij de URL-basis: een taal zonder
 * eigen slug krijgt de oude gewone slug als slug (alleen de slug; de naam valt terug op de nieuwe standaardtaal), en een
 * eigen slug gelijk aan de nieuwe gewone slug vervalt. Dat gebeurt vóór _ww_term_{oud}: die meta is het teken dat de term
 * is omgezet (_ww_languages_switch_terms()), dus een volgende run doet het niet nog eens.
 *
 * @param WP_Term  $term    De term, met de gewone waarden.
 * @param string   $old     De huidige standaardtaal.
 * @param string   $new     De nieuwe standaardtaal.
 * @param bool     $dry_run Alleen tonen wat er verandert.
 * @param string[] $others  De andere extra talen (niet de oude en niet de nieuwe standaardtaal).
 * @return string[]|WP_Error Een regel als de term zelf verandert en per andere taal die een slug krijgt of verliest een
 *                           regel; leeg als alleen de vertaling wordt bewaard. Of de fout van wp_update_term().
 */
function _ww_languages_switch_term( WP_Term $term, string $old, string $new, bool $dry_run, array $others = array() ): array|WP_Error {
	$translation = _ww_term_translation( $term->term_id, $new );
	$plain       = array(
		'name'        => $term->name,
		'slug'        => $term->slug,
		'description' => $term->description,
	);
	$update      = array();
	$keep        = array();
	foreach ( $plain as $key => $value ) {
		if ( '' !== $translation[ $key ] && $translation[ $key ] !== $value ) {
			$update[ $key ] = $translation[ $key ];
		}
		if ( '' !== $value && $translation[ $key ] !== $value ) {
			$keep[ $key ] = $value;
		}
	}
	$lines = array() === $update ? array() : array( sprintf( '%s: %s wordt %s (de oude naam gaat naar %s).', $term->taxonomy, _ww_languages_switch_text( $term->name ), _ww_languages_switch_text( $update['name'] ?? $term->name ), $old ) );

	// De andere talen houden hun adres: taal => de nieuwe vertaling (zonder lege velden).
	$pins = array();
	if ( isset( $update['slug'] ) ) {
		foreach ( $others as $code ) {
			$values = array_filter( _ww_term_translation( $term->term_id, $code ), static fn( string $value ): bool => '' !== $value );
			$label  = $term->taxonomy . ' ' . _ww_languages_switch_text( $term->name ) . ' in ' . $code;
			if ( ! isset( $values['slug'] ) ) {
				$values['slug'] = $term->slug;
				$lines[]        = sprintf( '%s: houdt de slug "%s".', $label, $term->slug );
			} elseif ( $values['slug'] === $update['slug'] ) {
				unset( $values['slug'] );
				$lines[] = sprintf( '%s: de slug "%s" is nu de gewone slug en vervalt als vertaling.', $label, $update['slug'] );
			} else {
				continue;
			}
			$pins[ $code ] = $values;
		}
	}
	if ( $dry_run ) {
		return $lines;
	}

	// Eerst de term zelf: lukt dat niet, dan is er voor deze term niets veranderd en doet een volgende run hem opnieuw.
	if ( array() !== $update ) {
		// De beschrijving is al gesaneerd (wp_kses_post() bij het opslaan van de vertaling). Onder WP-CLI is er geen
		// gebruiker met unfiltered_html, en de strengere wp_filter_kses zou dan <p> en andere opmaak weghalen.
		$kses = has_filter( 'pre_term_description', 'wp_filter_kses' );
		if ( false !== $kses ) {
			remove_filter( 'pre_term_description', 'wp_filter_kses', $kses );
		}
		try {
			$updated = wp_update_term( $term->term_id, $term->taxonomy, wp_slash( $update ) );
		} finally {
			if ( false !== $kses ) {
				add_filter( 'pre_term_description', 'wp_filter_kses', $kses );
			}
		}
		if ( is_wp_error( $updated ) ) {
			return $updated;
		}
	}
	foreach ( $pins as $code => $values ) {
		if ( array() === $values ) {
			delete_term_meta( $term->term_id, '_ww_term_' . $code );
		} else {
			update_term_meta( $term->term_id, '_ww_term_' . $code, wp_slash( $values ) );
		}
		if ( isset( $values['slug'] ) ) {
			update_term_meta( $term->term_id, '_ww_term_slug_' . $code, $values['slug'] );
		} else {
			delete_term_meta( $term->term_id, '_ww_term_slug_' . $code );
		}
	}
	if ( array() !== $keep ) {
		update_term_meta( $term->term_id, '_ww_term_' . $old, wp_slash( $keep ) );
	}
	if ( isset( $keep['slug'] ) ) {
		update_term_meta( $term->term_id, '_ww_term_slug_' . $old, $keep['slug'] );
	}
	delete_term_meta( $term->term_id, '_ww_term_' . $new );
	delete_term_meta( $term->term_id, '_ww_term_slug_' . $new );
	clean_term_cache( $term->term_id, $term->taxonomy );
	return $lines;
}

/**
 * Stap termen van set-default (3b): elke term van een vertaalbare taxonomie, met de vlag van 3b zodat de termfilters
 * niet meelopen (_ww_languages_terms_raw()). Een term met al _ww_term_{oud} is in een eerdere (afgebroken) run omgezet.
 * De andere extra talen (ook verborgen) houden hun termadressen (_ww_languages_switch_term()).
 *
 * @param string $old     De huidige standaardtaal.
 * @param string $new     De nieuwe standaardtaal.
 * @param bool   $dry_run Alleen tonen wat er verandert.
 * @return string[]|WP_Error Per term die verandert een regel, per andere taal die een slug krijgt of verliest een regel,
 *                           plus het aantal termen dat alleen zijn waarden ook in de oude taal krijgt.
 */
function _ww_languages_switch_terms( string $old, string $new, bool $dry_run ): array|WP_Error {
	$others = array();
	foreach ( _ww_languages_config()['languages'] as $language ) {
		if ( $language['code'] !== $old && $language['code'] !== $new ) {
			$others[] = $language['code'];
		}
	}
	$previous = _ww_languages_terms_raw();
	_ww_languages_terms_raw( true );
	$lines = array();
	$kept  = 0;
	try {
		foreach ( _ww_translatable_taxonomies() as $taxonomy ) {
			if ( ! taxonomy_exists( $taxonomy ) ) {
				continue;
			}
			$terms = get_terms(
				array(
					'taxonomy'   => $taxonomy,
					'hide_empty' => false,
				)
			);
			foreach ( is_array( $terms ) ? $terms : array() as $term ) {
				if ( metadata_exists( 'term', $term->term_id, '_ww_term_' . $old ) ) {
					continue;
				}
				$term_lines = _ww_languages_switch_term( $term, $old, $new, $dry_run, $others );
				if ( $term_lines instanceof WP_Error ) {
					return $term_lines;
				}
				if ( array() === $term_lines ) {
					++$kept;
				} else {
					array_push( $lines, ...$term_lines );
				}
			}
		}
	} finally {
		_ww_languages_terms_raw( $previous );
	}
	if ( $kept > 0 ) {
		$lines[] = sprintf( '%d termen zonder andere naam in %s houden hun naam; die staat ook in %s.', $kept, $new, $old );
	}
	return $lines;
}

/**
 * Stap URL-basis van set-default (0044). Voor elk post type en elke taxonomie van de parent (_ww_post_type_parent_bases())
 * met een vertaalde basis in de nieuwe taal: die wordt de echte basis (default_bases, gelezen door
 * _ww_register_post_types()), en de oude echte basis wordt de vertaalde basis van de oude taal. Een basis gelijk aan die
 * van de parent valt uit default_bases: zo geeft heen en terug de beginstand. Een object van buiten de parent blijft
 * zoals het is (zie _ww_languages_switch_warnings()). Daarna worden de post types opnieuw geregistreerd, zodat de flush
 * aan het eind de nieuwe basis kent.
 *
 * De andere extra talen (ook verborgen) houden hun adressen: een taal zonder eigen basis voor zo'n object krijgt de oude
 * echte basis als basis, en een eigen basis gelijk aan de nieuwe echte basis vervalt (een basis gelijk aan de echte
 * basis wordt nooit bewaard). Botst een basis van een andere taal na het omzetten, dan komt er een waarschuwing.
 *
 * @param string            $old      De huidige standaardtaal.
 * @param string            $new      De nieuwe standaardtaal.
 * @param bool              $dry_run  Alleen tonen wat er verandert.
 * @param array<int,string> $warnings Krijgt de botsingen in de andere talen mee (niet in de dry-run).
 * @return string[]|WP_Error Per object een regel, en per andere taal die iets krijgt of verliest een regel.
 */
function _ww_languages_switch_bases( string $old, string $new, bool $dry_run, array &$warnings = array() ): array|WP_Error {
	$objects   = _ww_language_base_objects();
	$config    = _ww_languages_config();
	$new_bases = _ww_language_bases( $new );
	$old_bases = _ww_language_bases( $old );
	$default   = $config['default_bases'] ?? array();
	$lines     = array();
	$others    = array();
	foreach ( $config['languages'] as $language ) {
		if ( $language['code'] !== $old && $language['code'] !== $new ) {
			$others[ $language['code'] ] = $language['bases'] ?? array();
		}
	}

	foreach ( _ww_post_type_parent_bases() as $name => $parent ) {
		// Een basis die de oude taal al heeft, is in een eerdere (afgebroken) run omgezet.
		if ( ! isset( $objects[ $name ], $new_bases[ $name ] ) || isset( $old_bases[ $name ] ) ) {
			continue;
		}
		$real               = $objects[ $name ]['base'];
		$target             = $new_bases[ $name ];
		$old_bases[ $name ] = $real;
		unset( $new_bases[ $name ] );
		if ( $target === $parent ) {
			unset( $default[ $name ] );
		} else {
			$default[ $name ] = $target;
		}
		$lines[] = sprintf( '%s: /%s/ wordt de basis; %s krijgt /%s/.', $objects[ $name ]['label'], $target, $old, $real );

		// De andere talen houden hun adressen.
		foreach ( $others as $code => $bases ) {
			if ( ! isset( $bases[ $name ] ) ) {
				$others[ $code ][ $name ] = $real;
				$lines[]                  = sprintf( '%s in %s: houdt /%s/.', $objects[ $name ]['label'], $code, $real );
			} elseif ( $bases[ $name ] === $target ) {
				unset( $others[ $code ][ $name ] );
				$lines[] = sprintf( '%s in %s: /%s/ is nu de echte basis en vervalt als vertaling.', $objects[ $name ]['label'], $code, $target );
			}
		}
	}
	if ( $dry_run || array() === $lines ) {
		return $lines;
	}

	foreach ( $config['languages'] as $index => $language ) {
		if ( $language['code'] === $old ) {
			$config['languages'][ $index ]['bases'] = $old_bases;
		} elseif ( $language['code'] === $new ) {
			$config['languages'][ $index ]['bases'] = $new_bases;
		} else {
			$config['languages'][ $index ]['bases'] = $others[ $language['code'] ];
		}
	}
	$config['default_bases'] = $default;
	$clean                   = _ww_languages_sanitize( $config );
	if ( $clean instanceof WP_Error ) {
		return $clean;
	}
	update_option( 'ww_languages', $clean, true );
	_ww_reregister_post_types();

	// Na het omzetten (de objecten hebben hun nieuwe echte basis): botsingen in de andere talen.
	foreach ( $others as $code => $bases ) {
		foreach ( _ww_language_base_conflicts( $code, $bases ) as $name => $reason ) {
			/* translators: 1: taalcode, 2: de botsing, zoals 'Projecten: "projects" is al de URL-basis van Diensten.' */
			$warnings[] = sprintf( __( 'De URL-basis in %1$s botst na het wisselen. %2$s Pas hem aan op de pagina Talen.', 'webwerckt-base' ), $code, _ww_language_base_conflicts_label( array( $name => $reason ) ) );
		}
	}
	return $lines;
}

/**
 * Stap menu's van set-default (3a). Per menulocatie wordt het menu van {locatie}__{nieuw} het menu van {locatie}, en
 * krijgt {locatie}__{oud} het oude menu van {locatie}; {locatie}__{nieuw} vervalt. Zonder eigen menu in de nieuwe taal
 * blijft {locatie} zoals hij is (en krijgt {locatie}__{oud} hetzelfde menu); hetzelfde menu in beide gaat niet naar
 * {locatie}__{oud}. Een locatie met al een menu op {locatie}__{oud} is al omgezet.
 *
 * @param string $old     De huidige standaardtaal.
 * @param string $new     De nieuwe standaardtaal.
 * @param bool   $dry_run Alleen tonen wat er verandert.
 * @return string[] Per locatie een regel.
 */
function _ww_languages_switch_menus( string $old, string $new, bool $dry_run ): array {
	$locations = get_nav_menu_locations();
	$changed   = $locations;
	$lines     = array();
	$label     = static function ( int $menu_id ): string {
		$menu = $menu_id > 0 ? wp_get_nav_menu_object( $menu_id ) : false;
		return $menu instanceof WP_Term ? '"' . $menu->name . '"' : '(geen)';
	};

	foreach ( array_keys( get_registered_nav_menus() ) as $location ) {
		$location = (string) $location;
		if ( '' !== _ww_menu_location_language( $location )['lang'] || ! empty( $locations[ $location . '__' . $old ] ) ) {
			continue;
		}
		$plain      = absint( $locations[ $location ] ?? 0 );
		$translated = absint( $locations[ $location . '__' . $new ] ?? 0 );
		if ( 0 === $plain && 0 === $translated ) {
			continue;
		}
		if ( $translated > 0 ) {
			$changed[ $location ] = $translated;
		}
		if ( $plain > 0 && $translated !== $plain ) {
			$changed[ $location . '__' . $old ] = $plain;
		}
		unset( $changed[ $location . '__' . $new ] );
		$lines[] = sprintf( '%1$s: %2$s; %1$s__%3$s krijgt %4$s.', $location, $translated > 0 ? 'menu ' . $label( $translated ) : 'geen menu in ' . $new . ', het menu blijft', $old, $label( $translated !== $plain ? $plain : 0 ) );
	}
	if ( ! $dry_run && $changed !== $locations ) {
		set_theme_mod( 'nav_menu_locations', $changed );
	}
	return $lines;
}

/**
 * Stap ondertitel van set-default (0044): de ondertitel van de nieuwe taal wordt blogdescription, en de oude
 * blogdescription de ondertitel van de oude taal. Zonder ondertitel in de nieuwe taal blijft blogdescription staan en
 * krijgt de oude taal die tekst ook; dezelfde tekst in beide gaat niet naar de oude taal. Een oude taal met al een
 * ondertitel is al omgezet.
 *
 * @param string $old     De huidige standaardtaal.
 * @param string $new     De nieuwe standaardtaal.
 * @param bool   $dry_run Alleen tonen wat er verandert.
 * @return string[]|WP_Error Een regel, of geen.
 */
function _ww_languages_switch_tagline( string $old, string $new, bool $dry_run ): array|WP_Error {
	$language = _ww_language( $old );
	if ( null === $language || isset( $language['tagline'] ) ) {
		return array();
	}
	$current     = _ww_language_tagline( $old );
	$translation = _ww_language_tagline( $new );
	if ( '' === $translation && '' === $current ) {
		return array();
	}
	if ( '' !== $translation && $translation !== $current ) {
		$line = sprintf( '%s wordt de ondertitel; %s krijgt %s.', _ww_languages_switch_text( $translation ), $old, _ww_languages_switch_text( $current ) );
	} elseif ( '' !== $translation ) {
		$line = sprintf( 'De ondertitel %s is in beide talen gelijk en blijft staan.', _ww_languages_switch_text( $current ) );
	} else {
		$line = sprintf( 'Geen ondertitel in %s: %s blijft staan en is ook de ondertitel van %s.', $new, _ww_languages_switch_text( $current ), $old );
	}
	if ( $dry_run ) {
		return array( $line );
	}

	$config = _ww_languages_config();
	foreach ( $config['languages'] as $index => $row ) {
		if ( $row['code'] === $old ) {
			$config['languages'][ $index ]['tagline'] = $translation !== $current ? $current : '';
		} elseif ( $row['code'] === $new ) {
			unset( $config['languages'][ $index ]['tagline'] );
		}
	}
	$clean = _ww_languages_sanitize( $config );
	if ( $clean instanceof WP_Error ) {
		return $clean;
	}
	update_option( 'ww_languages', $clean, true );
	if ( '' !== $translation && $translation !== $current ) {
		update_option( 'blogdescription', $translation );
	}
	return array( $line );
}

/**
 * De waarschuwingen van set-default: een vertaalbaar post type of een vertaalbare taxonomie met een eigen rewrite.slug
 * die de parent niet registreert (niet in _ww_post_type_parent_objects(), dus van een child-thema of plugin). Die basis
 * zet set-default niet om; het child-thema moet hem zelf aanpassen. Een object van WordPress zelf (categorie, tag)
 * alleen als de nieuwe taal er een vertaalde basis voor heeft: die basis staat in Instellingen → Permalinks.
 *
 * @param string $new De nieuwe standaardtaal.
 * @return string[]
 */
function _ww_languages_switch_warnings( string $new ): array {
	$parent   = _ww_post_type_parent_objects();
	$bases    = _ww_language_bases( $new );
	$warnings = array();
	foreach ( _ww_language_base_objects() as $name => $object ) {
		$wp      = 'post_type' === $object['type'] ? get_post_type_object( $name ) : get_taxonomy( $name );
		$builtin = ( $wp instanceof WP_Post_Type || $wp instanceof WP_Taxonomy ) && $wp->_builtin;
		if ( ! isset( $parent[ $name ] ) && ( ! $builtin || isset( $bases[ $name ] ) ) ) {
			/* translators: 1: naam van een post type of taxonomie, zoals Boeken, 2: URL-basis, 3: taalcode */
			$warnings[] = sprintf( __( '%1$s heeft een eigen URL-basis "%2$s" van buiten het thema (rewrite.slug). Die wordt niet omgezet: pas hem zelf aan naar de basis voor %3$s.', 'webwerckt-base' ), $object['label'], $object['base'], $new );
		}
	}
	return $warnings;
}

/**
 * Wisselt de standaardtaal (WP-CLI) en zet alles om, in een vaste volgorde: berichten, Site-instellingen, termen,
 * URL-basis, menu's en ondertitel (elk een functie _ww_languages_switch_{stap}()), dan de optie ww_languages met de
 * nieuwe standaardtaal, de rewrite rules flushen en de paginacache legen. Met $dry_run verandert er niets en komt de
 * lijst van wat er zou veranderen terug.
 *
 * Lukt een stap niet, dan stopt het en komt de fout terug met in de data onder `done` de stappen die al gedaan zijn.
 * Een volgende run doet de rest: zolang een taal de standaardtaal is, staat er niets onder zijn code, dus wat al onder
 * de oude standaardtaal staat, is omgezet en wordt overgeslagen.
 *
 * @param string            $code     De nieuwe standaardtaal.
 * @param bool              $dry_run  Alleen tonen wat er verandert.
 * @param array<int,string> $warnings Krijgt de waarschuwingen mee (_ww_languages_switch_warnings()), ook in de dry-run,
 *                                    en bij het echt omzetten de botsingen van basissen in andere talen.
 * @return array<string,list<string>>|WP_Error Stap (posts, settings, terms, bases, menus, tagline) => regels; leeg als
 *                                             $code al de standaardtaal is. Fouten: ww_languages_inactive,
 *                                             ww_languages_unknown, ww_language_hidden, of de fout van een stap.
 */
function _ww_languages_set_default( string $code, bool $dry_run = false, array &$warnings = array() ): array|WP_Error {
	if ( ! _ww_languages_active() ) {
		return new WP_Error( 'ww_languages_inactive', __( 'Meertalig staat uit, of een vertaalplugin regelt de talen.', 'webwerckt-base' ) );
	}
	$language = _ww_language( $code );
	if ( null === $language ) {
		/* translators: %s: taalcode */
		return new WP_Error( 'ww_languages_unknown', sprintf( __( 'De taal "%s" bestaat niet.', 'webwerckt-base' ), $code ) );
	}
	$old = _ww_default_language();
	if ( $code === $old ) {
		return array();
	}
	if ( ! $language['visible'] ) {
		/* translators: %s: taalcode */
		return new WP_Error( 'ww_language_hidden', sprintf( __( 'De taal "%s" is verborgen. Maak hem eerst zichtbaar voor bezoekers.', 'webwerckt-base' ), $code ) );
	}

	foreach ( _ww_languages_switch_warnings( $code ) as $warning ) {
		$warnings[] = $warning;
	}

	$steps = array(
		'posts'    => '_ww_languages_switch_posts',
		'settings' => '_ww_languages_switch_settings',
		'terms'    => '_ww_languages_switch_terms',
		'bases'    => '_ww_languages_switch_bases',
		'menus'    => '_ww_languages_switch_menus',
		'tagline'  => '_ww_languages_switch_tagline',
	);
	$done  = array();
	foreach ( $steps as $step => $callback ) {
		$lines = 'bases' === $step ? _ww_languages_switch_bases( $old, $code, $dry_run, $warnings ) : $callback( $old, $code, $dry_run );
		if ( $lines instanceof WP_Error ) {
			return _ww_languages_switch_failed( $lines, $done );
		}
		$done[ $step ] = array_values( $lines );
	}
	if ( $dry_run ) {
		return $done;
	}

	$config            = _ww_languages_config();
	$config['default'] = $code;
	$clean             = _ww_languages_sanitize( $config );
	if ( $clean instanceof WP_Error ) {
		return _ww_languages_switch_failed( $clean, $done );
	}
	// De optie, termen bijwerken, flushen (de post types zijn met de nieuwe basis geregistreerd) en de cache legen.
	_ww_languages_store( $clean );
	return $done;
}

/**
 * Een fout van een stap van set-default, met de al gedane stappen in de data onder `done`.
 *
 * @param WP_Error                   $error De fout.
 * @param array<string,list<string>> $done  De gedane stappen.
 */
function _ww_languages_switch_failed( WP_Error $error, array $done ): WP_Error {
	$data = $error->get_error_data();
	$error->add_data( ( is_array( $data ) ? $data : array() ) + array( 'done' => $done ) );
	return $error;
}

/**
 * Commando's voor de talen van het thema (wp ww languages). De klasse bestaat altijd (de tests roepen hem direct aan);
 * WP-CLI kent hem alleen als WP_CLI gedefinieerd is.
 */
class WW_Languages_CLI_Command {

	/**
	 * Toont de talen met hun status en het aantal berichten per taal (zonder taalterm telt bij de standaardtaal).
	 *
	 * ## EXAMPLES
	 *
	 *     wp ww languages list
	 *
	 * @subcommand list
	 *
	 * @param string[]             $args       Positionele argumenten (geen).
	 * @param array<string,string> $assoc_args Opties.
	 */
	public function list_languages( $args, $assoc_args ): void {
		$config = _ww_languages_config();
		if ( array() === $config['languages'] ) {
			WP_CLI::log( 'Er zijn geen talen ingesteld. Zet Meertalig aan in Instellingen > Algemeen.' );
			return;
		}
		$tagged   = taxonomy_exists( 'ww_language' );
		$untagged = $tagged ? array_sum( array_map( 'count', _ww_languages_untagged_posts() ) ) : 0;

		WP_CLI::log( sprintf( '%-8s %-14s %-24s %-28s %s', 'code', 'locale', 'naam', 'status', 'berichten' ) );
		foreach ( $config['languages'] as $language ) {
			$count = $tagged ? array_sum( _ww_languages_post_counts( $language['code'] ) ) : 0;
			if ( $language['code'] === $config['default'] ) {
				$status = 'standaardtaal';
				$count += $untagged;
			} else {
				$status = $language['visible'] ? 'zichtbaar' : 'verborgen (alleen redacteuren)';
			}
			WP_CLI::log( sprintf( '%-8s %-14s %-24s %-28s %d', $language['code'], $language['locale'], $language['name'], $status, $count ) );
		}
	}

	/**
	 * Wisselt de standaardtaal en zet alles om: berichten zonder taal, Site-instellingen, termen, URL-basis, menu's en
	 * ondertitel; daarna de optie, de rewrite rules flushen en de paginacache legen. Toont eerst de lijst van wat er
	 * verandert en vraagt dan om bevestiging. Stopt een stap met een fout, dan toont het wat al is omgezet; een tweede
	 * run doet de rest.
	 *
	 * ## OPTIONS
	 *
	 * <code>
	 * : De code van de nieuwe standaardtaal (een zichtbare taal).
	 *
	 * [--dry-run]
	 * : Alleen tonen wat er verandert; er verandert niets.
	 *
	 * [--yes]
	 * : Niet om bevestiging vragen.
	 *
	 * ## EXAMPLES
	 *
	 *     wp ww languages set-default en --dry-run
	 *     wp ww languages set-default en --yes
	 *
	 * @subcommand set-default
	 *
	 * @param string[]             $args       De taalcode.
	 * @param array<string,mixed>  $assoc_args Opties.
	 */
	public function set_default( $args, $assoc_args ): void {
		$code    = isset( $args[0] ) ? (string) $args[0] : '';
		$dry_run = ! empty( $assoc_args['dry-run'] );
		$old     = _ww_default_language();
		$warn    = array();
		$plan    = _ww_languages_set_default( $code, true, $warn );
		if ( $plan instanceof WP_Error ) {
			WP_CLI::error( $plan->get_error_message() );
		}
		foreach ( $warn as $message ) {
			WP_CLI::warning( $message );
		}
		if ( $code === $old ) {
			WP_CLI::success( sprintf( '%s is al de standaardtaal.', $code ) );
			return;
		}

		WP_CLI::log( sprintf( 'Van %s naar %s:', $old, $code ) );
		self::log_steps( $plan );
		if ( $dry_run ) {
			WP_CLI::success( sprintf( 'Proefrun: daarna zou %s de standaardtaal zijn. Er is niets veranderd.', $code ) );
			return;
		}

		WP_CLI::confirm( sprintf( '%s de standaardtaal maken en dit omzetten?', $code ), $assoc_args );
		$after  = array();
		$result = _ww_languages_set_default( $code, false, $after );
		// Alleen de waarschuwingen die de proefrun nog niet gaf: de botsingen na het omzetten van de URL-basis.
		foreach ( array_diff( $after, $warn ) as $message ) {
			WP_CLI::warning( $message );
		}
		if ( $result instanceof WP_Error ) {
			$data = $result->get_error_data();
			$done = is_array( $data ) && is_array( $data['done'] ?? null ) ? $data['done'] : array();
			if ( array() !== $done ) {
				WP_CLI::log( 'Al omgezet:' );
				self::log_steps( $done );
			}
			$message = $result->get_error_message() . sprintf( ' Het wisselen is niet af: %s is nog de standaardtaal.', $old );
			if ( ! empty( $done['bases'] ) ) {
				$message .= ' De URL-basis is al omgezet, dus tot dan kloppen de adressen niet.';
			}
			WP_CLI::error( $message . ' Los de fout op en draai het commando opnieuw om het af te maken: het doet dan de rest.' );
		}
		WP_CLI::success( sprintf( '%s is nu de standaardtaal.', $code ) );
	}

	/**
	 * Toont de stappen van set-default met hun regels.
	 *
	 * @param array<mixed> $steps Stap => regels, uit _ww_languages_set_default().
	 */
	private static function log_steps( array $steps ): void {
		$labels = array(
			'posts'    => 'Berichten',
			'settings' => 'Site-instellingen',
			'terms'    => 'Termen',
			'bases'    => 'URL-basis',
			'menus'    => "Menu's",
			'tagline'  => 'Ondertitel',
		);
		foreach ( $steps as $step => $lines ) {
			WP_CLI::log( ( $labels[ $step ] ?? (string) $step ) . ':' );
			$lines = is_array( $lines ) ? $lines : array();
			if ( array() === $lines ) {
				WP_CLI::log( '  niets' );
			}
			foreach ( $lines as $line ) {
				WP_CLI::log( '  ' . (string) $line );
			}
		}
	}
}

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	WP_CLI::add_command( 'ww languages', 'WW_Languages_CLI_Command' );
}
