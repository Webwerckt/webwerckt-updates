// Statistieken: één hit per paginaweergave, zonder cookie en zonder opslag in de browser.
// Het adres van het meetpunt staat in data-ww-stats op de scripttag. currentScript is er alleen tijdens het uitvoeren.

(function () {
	const script = document.currentScript;
	const url = script && script.dataset.wwStats;
	if (!url || !navigator.sendBeacon) {
		return;
	}

	function host(link) {
		try {
			return new URL(link).host;
		} catch (e) {
			return '';
		}
	}

	function send() {
		const body = { p: location.pathname, w: screen.width };
		try {
			const referrer = document.referrer;
			body.r = referrer && host(referrer) !== location.host ? referrer : '';
			const query = new URLSearchParams(location.search);
			body.us = query.get('utm_source') || '';
			body.um = query.get('utm_medium') || '';
			body.uc = query.get('utm_campaign') || '';
			body.tz = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
		} catch (e) {
			// Een rare verwijzer of een oude browser mag de hit niet tegenhouden.
		}
		navigator.sendBeacon(url, JSON.stringify(body));
	}

	function sendEvent(body) {
		try {
			navigator.sendBeacon(url, JSON.stringify(body));
		} catch (e) {
			// Een mislukte meting mag de pagina nooit storen.
		}
	}

	// Kliks: tel, mailto, download, extern, intern of knop. Alleen soort, tekst en doel, nooit formulierinhoud.
	const downloads = /\.(pdf|zip|docx?|xlsx?|pptx?|csv|txt|rtf|odt|ods|dwg|mp3|mp4)$/i;

	function clean(text, max) {
		return (text || '').replace(/\s+/g, ' ').trim().slice(0, max);
	}

	function label(el) {
		const img = el.querySelector('img[alt]');
		const isInput = el.tagName === 'INPUT';
		return (
			clean(el.getAttribute('aria-label'), 80) ||
			clean(isInput ? el.value : el.textContent, 80) ||
			clean(el.getAttribute('title'), 80) ||
			clean(img && img.getAttribute('alt'), 80)
		);
	}

	function onClick(event) {
		const el = event.target.closest && event.target.closest('a[href], button, [role="button"], input[type="submit"], input[type="button"]');
		if (!el) {
			return;
		}
		// Een verzendknop van een themaformulier komt via de formuliermeting.
		if (el.matches('button[type=submit], button:not([type]), input[type=submit]') && el.form && el.form.querySelector('input[name="ww_form"]')) {
			return;
		}
		let kind = 'knop';
		let target = '';
		const href = el.matches('a[href]') ? el.getAttribute('href').trim() : '';
		if (href) {
			const lower = href.toLowerCase();
			let parsed = null;
			try {
				parsed = new URL(href, location.href);
			} catch (e) {
				// Een onleesbaar adres telt als interne link zonder doel.
			}
			if (lower.indexOf('tel:') === 0 || lower.indexOf('mailto:') === 0) {
				kind = lower.charAt(0) === 't' ? 'tel' : 'mailto';
				target = href.slice(kind.length + 1).split('?')[0];
			} else {
				const web = parsed && /^https?:$/.test(parsed.protocol);
				if (el.hasAttribute('download') || (parsed && downloads.test(parsed.pathname))) {
					kind = 'download';
				} else if (web && parsed.host !== location.host) {
					kind = 'extern';
				} else {
					kind = 'intern';
				}
				// Alleen een http(s)-adres krijgt een doel; sms:, javascript:, data:, whatsapp: en dergelijke niet.
				if (web) {
					target = kind === 'intern' ? parsed.pathname : parsed.host + parsed.pathname;
				}
			}
		}
		sendEvent({ e: 'c', p: location.pathname, k: kind, t: target, l: label(el) });
	}

	document.addEventListener('click', onClick, true);

	// Formulieren: alleen die van het thema (met een veld ww_form), view, start, step en sent.
	const viewed = new WeakSet();
	const started = new WeakSet();

	function formId(form) {
		const input = form && form.querySelector && form.querySelector('input[name="ww_form"]');
		const id = input ? parseInt(input.value, 10) : 0;
		return id > 0 ? id : 0;
	}

	function sendForm(form, status, step) {
		const id = formId(form);
		if (id) {
			sendEvent({ e: 'f', p: location.pathname, f: id, s: status, n: step || 0 });
		}
	}

	function view(form) {
		if (!viewed.has(form)) {
			viewed.add(form);
			sendForm(form, 'view');
		}
	}

	const forms = Array.prototype.filter.call(document.querySelectorAll('form'), formId);
	if ('IntersectionObserver' in window) {
		const observer = new IntersectionObserver(
			function (entries) {
				entries.forEach(function (entry) {
					if (entry.isIntersecting) {
						observer.unobserve(entry.target);
						view(entry.target);
					}
				});
			},
			{ threshold: 0.5 }
		);
		forms.forEach(function (form) {
			observer.observe(form);
		});
	} else {
		forms.forEach(view);
	}

	document.addEventListener('focusin', function (event) {
		const field = event.target;
		const form = field && field.form;
		if (form && !started.has(form) && field.matches('input, select, textarea') && formId(form)) {
			started.add(form);
			view(form);
			sendForm(form, 'start');
		}
	});

	document.addEventListener('ww-form-step', function (event) {
		const index = event.detail && Number(event.detail.index);
		sendForm(event.target, 'step', index >= 0 ? index + 1 : 0);
	});

	document.addEventListener('ww-form-submitted', function (event) {
		sendForm(event.target, 'sent');
	});

	if (document.prerendering) {
		document.addEventListener('prerenderingchange', send, { once: true });
	} else {
		send();
	}
})();
