// Statistieken: "Nu op de site" elke 30 seconden verversen zolang het tabblad zichtbaar is.
// Het adres en de nonce staan in data-url en data-nonce op [data-ww-realtime]. De server tekent de eerste waarde al mee.
// Er kunnen meer plekken op één scherm staan (het zijpaneel en de compacte regel voor mobiel): één verzoek per ronde,
// en elke plek krijgt het antwoord. Een compacte plek heeft alleen de teller.

(function () {
	const roots = Array.prototype.slice.call(document.querySelectorAll('[data-ww-realtime]'));
	const first = roots[0];
	const url = first && first.dataset.url;
	const nonce = first && first.dataset.nonce;
	if (!url || !nonce || !window.fetch) {
		return;
	}

	let busy = false;

	function renderRoot(root, data) {
		const count = Number(data.count) || 0;
		const counter = root.querySelector('[data-ww-realtime-count]');
		const empty = root.querySelector('[data-ww-realtime-empty]');
		const list = root.querySelector('[data-ww-realtime-list]');
		if (counter) {
			counter.textContent = String(count);
		}
		if (empty) {
			empty.hidden = count > 0;
		}
		if (!list) {
			return;
		}
		list.replaceChildren();
		(data.pages || []).forEach(function (page) {
			const item = document.createElement('li');
			const name = page.title || page.path;
			if (page.url) {
				const link = document.createElement('a');
				link.href = page.url;
				link.textContent = name;
				item.appendChild(link);
			} else {
				item.appendChild(document.createTextNode(name));
			}
			const visitors = document.createElement('span');
			visitors.className = 'ww-realtime__visitors';
			visitors.textContent = String(page.visitors);
			item.appendChild(document.createTextNode(' '));
			item.appendChild(visitors);
			list.appendChild(item);
		});
	}

	function render(data) {
		roots.forEach(function (root) {
			renderRoot(root, data);
		});
	}

	function refresh() {
		if (busy) {
			return;
		}
		busy = true;
		fetch(url, {
			method: 'POST',
			credentials: 'same-origin',
			body: new URLSearchParams({ action: 'ww_stats_realtime', _ajax_nonce: nonce }),
		})
			.then(function (response) {
				return response.ok ? response.json() : null;
			})
			.then(function (json) {
				if (json && json.success && json.data) {
					render(json.data);
				}
			})
			.catch(function () {
				// Een mislukte vraag laat de oude waarde staan; de volgende ronde probeert het opnieuw.
			})
			.then(function () {
				busy = false;
			});
	}

	setInterval(function () {
		if (document.visibilityState === 'visible') {
			refresh();
		}
	}, 30000);

	document.addEventListener('visibilitychange', function () {
		if (document.visibilityState === 'visible') {
			refresh();
		}
	});
})();
