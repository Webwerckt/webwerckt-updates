// De builder in het bewerkscherm van een formulier (inc/forms-builder.php, ADR 0032).
// Eén toestand: de configuratie, gelezen uit het verborgen tekstvak ww_form_config. Na elke wijziging gaat hij als
// JSON terug in dat tekstvak; opslaan doet de gewone knop Bijwerken, en de server schoont alles op met
// ww_form_sanitize(). Wat hier gebeurt (sleutels maken, toegestane tags in de bevestiging) volgt dezelfde regels als
// de server, maar de server is leidend.
// render() bouwt het tabblad dat open is opnieuw op na een verandering in de opbouw (een veld erbij, weg of
// verplaatst, een vinkje, een keuze). Typen in een tekstvak werkt alleen de toestand bij, zonder opnieuw te tekenen,
// zodat de cursor blijft staan. Alles wordt met createElement en textContent gemaakt, nooit met innerHTML: labels
// en teksten zijn invoer.
// Een veld bewerk je in een venster (<dialog>, showModal) dat één keer gemaakt wordt en bij elke render alleen gevuld
// wordt; de lijst toont per veld een rij die het venster opent. Wat je in het venster typt, staat meteen in die rij.
// De onderdelen (Velden, Mail, Na versturen, Opslag) staan als tabbladen in het zijpaneel en in de kiezer op mobiel
// (inc/forms-panel.php); zonder paneel staan ze boven in de metabox. Na een wijziging meldt het paneel "Niet
// opgeslagen wijzigingen".
// Ook de kopieerknoppen op het bewerkscherm ([data-ww-copy] in de kaart Plaatsen, [data-ww-copy-text] in de kiezer)
// werken via dit script.

(() => {
	const data = window.wwFormBuilder;
	if (!data) {
		return;
	}
	const t = data.texts;

	/*
	 * Kleine hulpmiddelen.
	 */

	// Vult %s, %d, %1$s enzovoort in, zoals sprintf in PHP.
	const format = (text, ...values) => {
		let next = 0;
		return text.replace(/%(?:(\d)\$)?[sd]/g, (match, position) =>
			String(values[position ? position - 1 : next++] ?? ''),
		);
	};

	// Voegt kinderen toe en slaat null, undefined en false over: Element.append(null) zou de tekst "null" plaatsen.
	const add = (node, ...children) => {
		for (const child of children.flat(Infinity)) {
			if (child !== null && child !== undefined && child !== false) {
				node.append(child);
			}
		}
		return node;
	};

	// Maakt een element. Eigenschappen die met on beginnen worden luisteraars; value, checked, selected, disabled en
	// hidden worden als eigenschap gezet, de rest als attribuut. Kinderen mogen tekst, elementen of lijsten zijn.
	const PROPERTIES = new Set(['value', 'checked', 'selected', 'disabled', 'hidden']);
	const el = (tag, props = {}, ...children) => {
		const node = document.createElement(tag);
		for (const [name, value] of Object.entries(props)) {
			if (value === undefined || value === null) {
				continue;
			}
			if (name === 'class') {
				node.className = value;
			} else if (name.startsWith('on')) {
				node.addEventListener(name.slice(2), value);
			} else if (PROPERTIES.has(name)) {
				node[name] = value;
			} else if (value !== false) {
				node.setAttribute(name, value === true ? '' : String(value));
			}
		}
		return add(node, ...children);
	};

	// Een meldingsgebied voor schermlezers: verplaatsen, verwijderen, kopiëren en invoegen worden voorgelezen. Het
	// venster van een veld (showModal) maakt de rest van de pagina inert, en dan leest een schermlezer dat gebied niet
	// voor; daarom heeft het venster een eigen meldingsgebied, dat announce() gebruikt zolang het venster open is.
	const liveRegion = () => el('div', { class: 'screen-reader-text', 'aria-live': 'polite', 'aria-atomic': 'true' });
	const live = liveRegion();
	const modalLive = liveRegion();
	document.body.append(live);
	const announce = (text) => {
		const region = modalLive.closest('dialog')?.open ? modalLive : live;
		region.textContent = '';
		window.setTimeout(() => {
			region.textContent = text;
		}, 50);
	};

	const focusFirst = (...ids) => {
		for (const id of ids) {
			const target = document.getElementById(id);
			if (target && !target.disabled) {
				target.focus();
				return;
			}
		}
	};

	// Kopiëren naar het klembord. navigator.clipboard bestaat alleen op https (of localhost); anders execCommand.
	const copyText = async (text) => {
		if (navigator.clipboard && window.isSecureContext) {
			try {
				await navigator.clipboard.writeText(text);
				return true;
			} catch {
				// Val terug op execCommand hieronder.
			}
		}
		const area = el('textarea', { readonly: true, class: 'ww-fb-copy-area' });
		area.value = text;
		document.body.append(area);
		area.select();
		let done = false;
		try {
			done = document.execCommand('copy');
		} catch {
			done = false;
		}
		area.remove();
		return done;
	};

	// Een knop met data-ww-copy="#selector" kopieert de waarde van dat veld; data-ww-copy-text kopieert die tekst.
	document.addEventListener('click', async (event) => {
		const button = event.target.closest('[data-ww-copy], [data-ww-copy-text]');
		if (!button) {
			return;
		}
		let text = button.dataset.wwCopyText;
		if (text === undefined) {
			const source = document.querySelector(button.dataset.wwCopy);
			if (!source) {
				return;
			}
			text = source.value;
			source.select();
		}
		if (await copyText(text)) {
			const original = button.dataset.wwCopyLabel ?? button.textContent;
			button.dataset.wwCopyLabel = original;
			button.textContent = t.copied;
			announce(`${t.copied}: ${text}`);
			window.setTimeout(() => {
				button.textContent = original;
			}, 2000);
		}
	});

	const root = document.getElementById('ww-form-builder-app');
	const store = document.getElementById('ww-form-config');
	if (!root || !store) {
		return;
	}

	/*
	 * De toestand.
	 */

	let state;
	try {
		state = JSON.parse(store.value);
	} catch {
		state = null;
	}
	if (!state || typeof state !== 'object' || !Array.isArray(state.fields)) {
		state = structuredClone(data.config);
	}

	// Wat alleen het scherm betreft en niet in de configuratie hoort: het open tabblad, de opengeklapte stappen (open),
	// het menu Veld toevoegen, het venster van een veld (dialog: { field, isNew, asking } of null) en de volgorde-stand
	// op mobiel (reorder). Velden en opties hebben geen vaste id voordat ze een sleutel hebben; daarom een nummer per
	// object.
	// ui.list is de lijst van het tabblad Velden: de veldobjecten uit state.fields met daartussen stappen
	// ({ step: true, key, title }). Hij wordt alleen ter plekke gewijzigd (de sleepfunctie houdt een verwijzing vast);
	// syncList() zet daarna state.fields gelijk en commit() schrijft er state.steps uit.
	const ui = { tab: 'fields', open: new Set(), menu: false, list: [], dialog: null, reorder: false };
	const ids = new WeakMap();
	let lastId = 0;
	const uid = (object) => {
		if (!ids.has(object)) {
			ids.set(object, ++lastId);
		}
		return ids.get(object);
	};

	/*
	 * Stappen: scheidingen in dezelfde lijst als de velden.
	 */

	const isStep = (item) => item.step === true;
	const newStep = () => ({ step: true, key: '', title: '' });
	const stepCount = () => ui.list.filter(isStep).length;
	const stepNumber = (step) => ui.list.filter(isStep).indexOf(step) + 1;
	const stepName = (step) => {
		const number = format(t.stepN, stepNumber(step));
		return step.title.trim() ? `${number}: ${step.title.trim()}` : number;
	};

	// De stap waar een item onder staat, of null.
	const stepOf = (item) => {
		for (let index = ui.list.indexOf(item); index >= 0; index--) {
			if (isStep(ui.list[index])) {
				return ui.list[index];
			}
		}
		return null;
	};

	// Na elke wijziging aan de lijst: de bovenste stap staat bovenaan, één stap alleen is geen stappenformulier, en
	// state.fields bevat de velden in de volgorde van de lijst.
	const syncList = () => {
		const first = ui.list.findIndex(isStep);
		if (first > 0) {
			ui.list.unshift(...ui.list.splice(first, 1));
		}
		const steps = ui.list.filter(isStep);
		if (steps.length === 1) {
			ui.list.splice(ui.list.indexOf(steps[0]), 1);
		}
		state.fields = ui.list.filter((item) => !isStep(item));
	};

	// Laden: een from als getal is een plaats in state.fields, als tekst een veldsleutel. Wat niets vindt, valt weg.
	const loadList = () => {
		const starts = new Map();
		for (const step of Array.isArray(state.steps) ? state.steps : []) {
			if (!step || typeof step !== 'object') {
				continue;
			}
			const index =
				typeof step.from === 'number'
					? step.from
					: state.fields.findIndex((field) => field.key && field.key === step.from);
			if (!state.fields[index]) {
				continue;
			}
			starts.set(index, [
				...(starts.get(index) ?? []),
				{ step: true, key: String(step.key ?? ''), title: String(step.title ?? '') },
			]);
		}
		state.fields.forEach((field, index) => {
			ui.list.push(...(starts.get(index) ?? []), field);
		});
		syncList();
	};
	loadList();

	// Na een wijziging: "Niet opgeslagen wijzigingen" in het paneel en in de balk op mobiel, en body.is-dirty. Na
	// Bijwerken laadt de pagina opnieuw en is de melding weg. De titel van WordPress (#title) telt ook mee.
	const markDirty = () => {
		// Alleen de eerste keer schrijven: het is een aria-live-regio, en elke toetsaanslag zou hem opnieuw voorlezen.
		for (const status of document.querySelectorAll('.ww-forms-panel__dirty')) {
			if (status.textContent !== t.unsaved) {
				status.textContent = t.unsaved;
			}
		}
		document.body.classList.add('is-dirty');
	};
	document.getElementById('title')?.addEventListener('input', markDirty);

	// Een eigen waarschuwing bij weggaan: die van WordPress (post.js) kijkt alleen naar titel, inhoud en samenvatting
	// (autosave postChanged()) en TinyMCE, niet naar ww_form_config. De browser toont zijn eigen tekst. Versturen van
	// #post (Bijwerken, ook via de knoppen in het paneel en de balk) zet de waarschuwing uit; de melding blijft staan.
	let submitting = false;
	document.getElementById('post')?.addEventListener('submit', () => {
		submitting = true;
	});
	window.addEventListener('beforeunload', (event) => {
		if (submitting || !document.body.classList.contains('is-dirty')) {
			return;
		}
		event.preventDefault();
		event.returnValue = '';
	});

	// Het aantal velden achter het onderdeel Velden, ook als er niet opnieuw getekend wordt.
	const updateCounts = () => {
		for (const count of document.querySelectorAll('.ww-fb-tab-count')) {
			count.textContent = String(state.fields.length);
		}
	};

	// Schrijft de toestand terug in het tekstvak dat met Bijwerken meegaat. De stappen komen uit ui.list: elke stap met
	// minstens één veld vóór de volgende stap, met from als plaats van dat eerste veld in state.fields. Lege stappen
	// gaan niet mee.
	const commit = () => {
		const steps = [];
		let pending = null;
		for (const item of ui.list) {
			if (isStep(item)) {
				pending = item;
			} else if (pending) {
				steps.push({ ...(pending.key ? { key: pending.key } : {}), title: pending.title, from: state.fields.indexOf(item) });
				pending = null;
			}
		}
		state.steps = steps;
		store.value = JSON.stringify(state);
		markDirty();
		updateCounts();
	};

	/*
	 * Regels zoals op de server (inc/forms.php).
	 */

	// Zoals _ww_form_key(): kleine letters, a-z0-9_, beginnend met een letter, nooit ww_, hoogstens 40 tekens, bezet
	// of gereserveerd krijgt _2, _3. Leeg wordt "veld".
	const makeKey = (label, taken) => {
		let base = String(label)
			.normalize('NFD')
			.replace(/[̀-ͯ]/g, '')
			.toLowerCase()
			.replace(/[^a-z0-9]+/g, '_')
			.replace(/^_+|_+$/g, '');
		let before;
		do {
			before = base;
			base = base.replace(/^[^a-z]+/, '').replace(/^ww(_|$)/, '');
		} while (before !== base);
		base = base.slice(0, 40).replace(/_+$/, '');
		if (base === '') {
			base = 'veld';
		}
		let key = base;
		for (let n = 2; taken.includes(key) || data.builtinTags.includes(key); n++) {
			const suffix = `_${n}`;
			key = base.slice(0, 40 - suffix.length).replace(/_+$/, '') + suffix;
		}
		return key;
	};

	// Platte tekst van een label; het label van een vinkje mag HTML bevatten. DOMParser voert niets uit.
	const plain = (html) =>
		new DOMParser().parseFromString(String(html ?? ''), 'text/html').body.textContent.trim();

	const fieldName = (field) => plain(field.label) || t.noLabel;

	// Een veld krijgt zijn sleutel één keer, zodra het een label heeft; daarna verandert hij nooit meer.
	const assignKey = (field) => {
		if (field.key || plain(field.label) === '') {
			return false;
		}
		const taken = state.fields.filter((other) => other !== field && other.key).map((other) => other.key);
		field.key = makeKey(plain(field.label), taken);
		return true;
	};

	const assignValue = (field, option) => {
		if (option.value || option.label.trim() === '') {
			return false;
		}
		const taken = field.options.filter((other) => other !== option && other.value).map((other) => other.value);
		option.value = makeKey(option.label, taken);
		return true;
	};

	// Regels met invoer e-mailadres (en een sleutel); voor de bevestiging alleen verplichte.
	const emailFields = (requiredOnly) =>
		state.fields.filter(
			(field) =>
				field.key && field.type === 'line' && field.input === 'email' && (!requiredOnly || field.required),
		);

	// Een antwoord- of ontvangerveld dat niet meer bestaat of geen (verplicht) e-mailveld meer is, valt weg.
	const cleanReferences = () => {
		const { notify, confirm } = state.mail;
		if (notify.reply_to_field && !emailFields(false).some((field) => field.key === notify.reply_to_field)) {
			notify.reply_to_field = '';
		}
		if (confirm.to_field && !emailFields(true).some((field) => field.key === confirm.to_field)) {
			confirm.to_field = '';
		}
	};

	const BUILTIN_LABELS = {
		alle_velden: t.tagAll,
		formulier: t.tagForm,
		site: t.tagSite,
		datum: t.tagDate,
		pagina: t.tagPage,
	};

	const fieldTags = (fields) => fields.filter((field) => field.key).map((field) => ({ tag: field.key, label: fieldName(field) }));

	// De tags voor de melding: alles.
	const notifyTags = () => [
		...data.builtinTags.map((tag) => ({ tag, label: BUILTIN_LABELS[tag] ?? tag })),
		...fieldTags(state.fields),
	];

	// Of reCAPTCHA voor dit formulier actief is, zoals _ww_form_recaptcha_active(): sleutels ingesteld en niet uitgezet.
	const recaptchaActive = () => Boolean(data.recaptchaConfigured) && state.recaptcha !== false;

	const hasFileField = () => state.fields.some((field) => field.type === 'file');

	// De tags voor de bevestiging zonder actieve reCAPTCHA, zoals _ww_form_confirm_allowed(): formulier, site, datum;
	// keuzevelden en vinkjes; een regel tekst (ingekort). Nooit alle_velden, pagina, tekstvakken, e-mail- of
	// telefoonregels.
	const confirmTagsRestricted = () => [
		...data.confirmBuiltin.map((tag) => ({ tag, label: BUILTIN_LABELS[tag] ?? tag })),
		...state.fields
			.filter((field) => field.key)
			.flatMap((field) => {
				if (['select', 'choice', 'checkbox'].includes(field.type)) {
					return [{ tag: field.key, label: fieldName(field) }];
				}
				if (field.type === 'line' && field.input === 'text') {
					return [{ tag: field.key, label: `${fieldName(field)} (${t.tagShort})` }];
				}
				return [];
			}),
	];

	// Met actieve reCAPTCHA alle tags, ook die van bestandsvelden: na een geslaagde controle is de bevestiging
	// onbeperkt, anders blijven de tags die de kern niet toestaat leeg.
	const confirmTags = () => (recaptchaActive() ? notifyTags() : confirmTagsRestricted());

	const NEW_FIELD = {
		line: { input: 'text', placeholder: '' },
		text: { placeholder: '', max_length: 5000 },
		checkbox: {},
		select: { empty_option: t.emptyOptionText, options: [] },
		choice: { multiple: false, options: [] },
		file: { accept: ['documents'], max_size_mb: Math.min(5, data.fileMaxMb ?? 5), max_files: 1 },
	};

	/*
	 * Bouwstenen voor het formulier van de builder.
	 */

	// Een regel met label, invoerelement en eventueel een uitleg (aria-describedby).
	const row = (id, labelText, control, help) => {
		const helpId = help ? `${id}-help` : null;
		if (helpId) {
			control.setAttribute('aria-describedby', helpId);
		}
		return el(
			'div',
			{ class: 'ww-fb-row' },
			el('label', { for: id, class: 'ww-fb-row__label' }, labelText),
			control,
			help ? el('p', { class: 'description', id: helpId }, help) : null,
		);
	};

	// Een tekstveld (of tekstvak) dat bij typen alleen de toestand bijwerkt.
	const textInput = (id, value, onInput, options = {}) => {
		const tag = options.rows ? 'textarea' : 'input';
		return el(tag, {
			id,
			class: options.rows ? 'large-text' : 'regular-text',
			type: options.rows ? null : options.type ?? 'text',
			rows: options.rows,
			maxlength: options.max,
			value: value ?? '',
			oninput: (event) => {
				onInput(event.target.value);
				commit();
			},
			onchange: options.onChange,
			onfocus: (event) => {
				event.target.dataset.wwTouched = '1';
			},
		});
	};

	// Een vinkje met zijn label erachter. Na een klik tekent de builder opnieuw: dat kan veel tonen of verbergen.
	// help mag tekst of een lijst met tekst en elementen zijn (bijvoorbeeld een link).
	const checkbox = (id, labelText, checked, onChange, help, disabled = false) => {
		const helpId = help ? `${id}-help` : null;
		return el(
			'div',
			{ class: 'ww-fb-row ww-fb-row--check' },
			el(
				'label',
				{ for: id },
				el('input', {
					type: 'checkbox',
					id,
					checked: Boolean(checked),
					disabled,
					'aria-describedby': helpId,
					onchange: (event) => {
						onChange(event.target.checked);
						commit();
						render();
					},
				}),
				' ',
				labelText,
			),
			help ? el('p', { class: 'description', id: helpId }, help) : null,
		);
	};

	// Een keuzelijst; options is een lijst [waarde, tekst].
	const select = (id, value, options, onChange) =>
		el(
			'select',
			{
				id,
				onchange: (event) => {
					onChange(event.target.value);
					commit();
				},
			},
			options.map(([optionValue, text]) =>
				el('option', { value: String(optionValue), selected: String(optionValue) === String(value) }, text),
			),
		);

	const iconButton = (id, icon, label, onClick, disabled = false) =>
		el(
			'button',
			{ type: 'button', id, class: 'button button-small ww-fb-icon', 'aria-label': label, title: label, disabled, onclick: onClick },
			el('span', { class: `dashicons ${icon}`, 'aria-hidden': 'true' }),
		);

	/*
	 * Verplaatsen: slepen met de muis (HTML5 drag-and-drop) en knoppen omhoog en omlaag.
	 */

	const moveItem = (list, from, to) => {
		const [item] = list.splice(from, 1);
		list.splice(Math.max(0, Math.min(list.length, to > from ? to - 1 : to)), 0, item);
		return list.indexOf(item);
	};

	let dragging = null; // { list, index }

	// Maakt een rij versleepbaar binnen zijn eigen lijst. Alleen de greep start het slepen: een versleepbare rij zou
	// tekst selecteren in de invoervelden erin onmogelijk maken.
	const draggable = (item, list, index, onMoved) => {
		const clear = () => item.classList.remove('is-drop-before', 'is-drop-after');
		const after = (event) => {
			const box = item.getBoundingClientRect();
			return event.clientY > box.top + box.height / 2;
		};
		item.addEventListener('dragstart', (event) => {
			if (!item.draggable) {
				return;
			}
			event.stopPropagation();
			dragging = { list, index };
			event.dataTransfer.effectAllowed = 'move';
			event.dataTransfer.setData('text/plain', String(index));
			item.classList.add('is-dragging');
		});
		item.addEventListener('dragover', (event) => {
			if (!dragging || dragging.list !== list) {
				return;
			}
			event.preventDefault();
			event.stopPropagation();
			event.dataTransfer.dropEffect = 'move';
			const below = after(event);
			item.classList.toggle('is-drop-after', below);
			item.classList.toggle('is-drop-before', !below);
		});
		item.addEventListener('dragleave', clear);
		item.addEventListener('drop', (event) => {
			if (!dragging || dragging.list !== list) {
				return;
			}
			event.preventDefault();
			event.stopPropagation();
			const from = dragging.index;
			dragging = null;
			clear();
			const to = index + (after(event) ? 1 : 0);
			if (to !== from && to !== from + 1) {
				onMoved(moveItem(list, from, to));
			}
		});
		item.addEventListener('dragend', () => {
			item.draggable = false;
			item.classList.remove('is-dragging');
			dragging = null;
			clear();
		});
		return el('span', {
			class: 'ww-fb-handle dashicons dashicons-move',
			title: t.drag,
			'aria-hidden': 'true',
			onmousedown: () => {
				item.draggable = true;
			},
			onmouseup: () => {
				item.draggable = false;
			},
		});
	};

	/*
	 * Tabblad Velden.
	 */

	const itemId = (item) => `ww-fb-${isStep(item) ? 's' : 'f'}${uid(item)}`;

	// De knop van een item in de lijst: bij een veld de knop die het venster opent, bij een stap de knop die openklapt.
	const itemButtonId = (item) => `${itemId(item)}-${isStep(item) ? 'toggle' : 'open'}`;

	// Verplaatst een veld of een stap in ui.list.
	const moveField = (item, delta) => {
		const from = ui.list.indexOf(item);
		const to = from + delta;
		if (to < 0 || to >= ui.list.length) {
			return;
		}
		ui.list.splice(from, 1);
		ui.list.splice(to, 0, item);
		afterFieldMove(item, delta < 0 ? 'up' : 'down');
	};

	const afterFieldMove = (item, direction) => {
		syncList();
		commit();
		render();
		const id = itemId(item);
		focusFirst(`${id}-${direction}`, `${id}-${direction === 'up' ? 'down' : 'up'}`, itemButtonId(item));
		if (isStep(item)) {
			announce(format(t.moved, stepName(item), stepNumber(item), stepCount()));
			return;
		}
		// Met stappen zegt de melding ook in welke stap het veld nu staat.
		const step = stepOf(item);
		const text = format(t.moved, fieldName(item), state.fields.indexOf(item) + 1, state.fields.length);
		announce(step ? `${text} ${stepName(step)}` : text);
	};

	// Na verwijderen krijgt het volgende (of vorige) item dat nog in de lijst staat de focus.
	const focusAfterRemove = (candidates) => {
		const next = candidates.find((item) => item && ui.list.includes(item));
		focusFirst(next ? itemButtonId(next) : '', 'ww-fb-add');
	};

	// Verwijdert een veld, na de vraag in het venster (Verwijderen in renderDialog()). Eerst gaat het venster dicht,
	// zodat de pagina niet meer inert is en de melding in het gewone meldingsgebied voorgelezen wordt.
	const removeField = (field) => {
		ui.dialog = null;
		if (dialog.open) {
			dialog.close();
		}
		const index = ui.list.indexOf(field);
		const candidates = [ui.list[index + 1], ui.list[index - 1]];
		ui.list.splice(index, 1);
		syncList();
		cleanReferences();
		commit();
		render();
		focusAfterRemove(candidates);
		announce(format(t.removed, fieldName(field)));
	};

	// Een stap verwijderen voegt zijn velden bij de stap erboven; er gaat niets verloren, dus geen bevestiging.
	const removeStep = (step) => {
		const name = stepName(step);
		const index = ui.list.indexOf(step);
		const candidates = [ui.list[index + 1], ui.list[index - 1], ui.list[index - 2]];
		ui.list.splice(index, 1);
		ui.open.delete(uid(step));
		syncList();
		commit();
		render();
		focusAfterRemove(candidates);
		announce(format(stepCount() ? t.stepRemoved : t.stepsRemoved, name));
	};

	// Een stap komt onderaan; is het de eerste, dan komt er ook een bovenaan: één stap alleen bestaat niet (syncList()
	// zou hem weghalen).
	const addStep = () => {
		if (!ui.list.some(isStep)) {
			ui.list.unshift(newStep());
		}
		const step = newStep();
		ui.list.push(step);
		ui.open.add(uid(step));
		ui.menu = false;
		syncList();
		commit();
		render();
		focusFirst(`${itemId(step)}-title`);
		announce(format(t.stepAdded, stepName(step), stepCount()));
	};

	const addField = (type) => {
		const field = {
			key: '',
			type,
			label: '',
			required: false,
			help: '',
			...structuredClone(NEW_FIELD[type]),
		};
		ui.list.push(field);
		syncList();
		if (type === 'file') {
			// Zoals ww_form_sanitize(): een formulier met een uploadveld slaat inzendingen altijd op.
			state.storage.store = true;
		}
		ui.menu = false;
		commit();
		render();
		openField(field, true);
	};

	// De tag van een veld, alleen-lezen met een kopieerknop; of een uitleg zolang het veld nog geen sleutel heeft.
	const fillTag = (box, field, id) => {
		if (!field.key) {
			box.replaceChildren(el('p', { class: 'description' }, t.tagPending));
			return;
		}
		const tag = `{${field.key}}`;
		box.replaceChildren(
			el(
				'div',
				{ class: 'ww-fb-tag' },
				el('span', { class: 'ww-fb-tag__label', id: `${id}-tag-label` }, `${t.tag}:`),
				' ',
				el('code', { 'aria-labelledby': `${id}-tag-label` }, tag),
				' ',
				el('button', { type: 'button', class: 'button button-small', 'data-ww-copy-text': tag, 'aria-label': format(t.copyTag, tag) }, t.copy),
			),
			el('p', { class: 'description' }, t.tagHelp),
		);
	};

	const renderOption = (field, option, index, fid) => {
		const id = `ww-fb-o${uid(option)}`;
		const name = option.label.trim() || format(t.optionLabel, index + 1);
		const last = field.options.length - 1;
		const value = el('code', { class: 'ww-fb-option__value', title: t.optionValue, hidden: !option.value }, option.value || '');
		const item = el('li', { class: 'ww-fb-option' });
		const moved = (newIndex) => {
			commit();
			render();
			focusFirst(`${id}-label`);
			announce(format(t.moved, name, newIndex + 1, field.options.length));
		};
		const step = (delta, direction) => () => {
			moveItem(field.options, index, delta > 0 ? index + 2 : index - 1);
			commit();
			render();
			focusFirst(`${id}-${direction}`, `${id}-${direction === 'up' ? 'down' : 'up'}`);
			announce(format(t.moved, name, field.options.indexOf(option) + 1, field.options.length));
		};
		add(
			item,
			draggable(item, field.options, index, moved),
			el('label', { for: `${id}-label`, class: 'screen-reader-text' }, format(t.optionLabel, index + 1)),
			textInput(
				`${id}-label`,
				option.label,
				(text) => {
					option.label = text;
				},
				{
					max: 200,
					onChange: () => {
						if (assignValue(field, option)) {
							value.textContent = option.value;
							value.hidden = false;
							commit();
						}
					},
				},
			),
			value,
			el(
				'span',
				{ class: 'ww-fb-actions' },
				iconButton(`${id}-up`, 'dashicons-arrow-up-alt2', format(t.moveUp, name), step(-1, 'up'), index === 0),
				iconButton(`${id}-down`, 'dashicons-arrow-down-alt2', format(t.moveDown, name), step(1, 'down'), index === last),
				iconButton(`${id}-remove`, 'dashicons-trash', format(t.remove, name), () => {
					field.options.splice(index, 1);
					commit();
					render();
					const next = field.options[index] ?? field.options[index - 1];
					focusFirst(next ? `ww-fb-o${uid(next)}-label` : '', `${fid}-addoption`);
					announce(format(t.removed, name));
				}),
			),
		);
		return item;
	};

	const renderOptions = (field, fid) => {
		const full = field.options.length >= 100;
		return el(
			'fieldset',
			{ class: 'ww-fb-options' },
			el('legend', { class: 'ww-fb-row__label' }, t.options),
			field.options.length
				? el('ol', { class: 'ww-fb-options__list' }, field.options.map((option, index) => renderOption(field, option, index, fid)))
				: el('p', { class: 'description' }, t.noOptions),
			el(
				'button',
				{
					type: 'button',
					class: 'button',
					id: `${fid}-addoption`,
					disabled: full,
					onclick: () => {
						const option = { value: '', label: '' };
						field.options.push(option);
						commit();
						render();
						focusFirst(`ww-fb-o${uid(option)}-label`);
					},
				},
				t.addOption,
			),
			full ? el('p', { class: 'description' }, t.maxOptions) : null,
		);
	};

	// Een getalveld dat bij het verlaten de waarde tussen min en max zet; leeg of onzin wordt fallback.
	const numberInput = (id, value, min, max, fallback, onValue) => {
		const input = textInput(id, String(value ?? fallback), () => {}, {
			type: 'number',
			onChange: (event) => {
				const number = Number.parseInt(event.target.value, 10);
				const clean = Number.isNaN(number) ? fallback : Math.max(min, Math.min(max, number));
				onValue(clean);
				event.target.value = String(clean);
				commit();
			},
		});
		input.min = String(min);
		input.max = String(max);
		input.className = 'small-text';
		return input;
	};

	// De nieuwe lijst accept na een vinkje, in de volgorde van _ww_form_file_groups(). De laatste groep kan niet uit
	// (de server zou er documents van maken); een onbekende groep valt weg, zoals op de server.
	const toggleGroup = (accept, group, on) => {
		const next = Object.keys(data.fileGroups ?? {}).filter((key) => (key === group ? on : accept.includes(key)));
		return next.length ? next : accept;
	};

	// De instellingen van een bestandsveld: vinkjes voor de groepen, de grootte per bestand en het aantal. Geen
	// placeholder.
	const renderFileSettings = (field, id) => {
		const groups = Object.entries(data.fileGroups ?? {});
		const maxMb = Math.max(1, Math.min(20, data.fileMaxMb ?? 20));
		if (!Array.isArray(field.accept)) {
			field.accept = ['documents'];
		}
		const checkedCount = groups.filter(([key]) => field.accept.includes(key)).length;
		return [
			el(
				'fieldset',
				{ class: 'ww-fb-row ww-fb-groups' },
				el('legend', { class: 'ww-fb-row__label' }, t.fileAccept),
				groups.map(([key, group]) => {
					const on = field.accept.includes(key);
					return checkbox(
						`${id}-accept-${key}`,
						`${group.label} (${group.ext.join(', ')})`,
						on,
						(value) => {
							field.accept = toggleGroup(field.accept, key, value);
						},
						null,
						on && checkedCount === 1,
					);
				}),
			),
			row(
				`${id}-maxsize`,
				t.fileMaxSize,
				numberInput(`${id}-maxsize`, field.max_size_mb, 1, maxMb, Math.min(5, maxMb), (value) => {
					field.max_size_mb = value;
				}),
				format(t.fileServerMax, data.fileMaxMb),
			),
			row(
				`${id}-maxfiles`,
				t.fileMaxFiles,
				numberInput(`${id}-maxfiles`, field.max_files, 1, 5, 1, (value) => {
					field.max_files = value;
				}),
				t.fileMaxFilesHelp,
			),
		];
	};

	// De instellingen van een veld, in het venster; refresh werkt de titel van het venster en de rij in de lijst bij als
	// het label of de soort invoer verandert.
	const renderFieldBody = (field, id, refresh) => {
		const tagBox = el('div', { class: 'ww-fb-tagbox' });
		fillTag(tagBox, field, id);
		const isCheckbox = field.type === 'checkbox';
		const parts = [
			row(
				`${id}-label`,
				isCheckbox ? t.labelCheckbox : t.label,
				textInput(
					`${id}-label`,
					field.label,
					(text) => {
						field.label = text;
						refresh();
					},
					{
						max: 200,
						onChange: () => {
							if (assignKey(field)) {
								fillTag(tagBox, field, id);
								commit();
							}
						},
					},
				),
				isCheckbox ? t.labelCheckboxHelp : null,
			),
			tagBox,
			checkbox(`${id}-required`, t.required, field.required, (checked) => {
				field.required = checked;
				cleanReferences();
			}),
		];

		if (field.type === 'line') {
			parts.push(
				row(
					`${id}-input`,
					t.input,
					select(
						`${id}-input`,
						field.input,
						[
							['text', t.inputText],
							['email', t.inputEmail],
							['tel', t.inputTel],
						],
						(value) => {
							field.input = value;
							cleanReferences();
							refresh();
						},
					),
				),
			);
		}
		if (field.type === 'line' || field.type === 'text') {
			parts.push(
				row(
					`${id}-placeholder`,
					t.placeholder,
					textInput(`${id}-placeholder`, field.placeholder, (text) => {
						field.placeholder = text;
					}, { max: 200 }),
				),
			);
		}
		if (field.type === 'text') {
			const max = textInput(`${id}-max`, String(field.max_length ?? 5000), () => {}, {
				type: 'number',
				onChange: (event) => {
					const number = Number.parseInt(event.target.value, 10);
					field.max_length = Number.isNaN(number) ? 5000 : Math.max(1, Math.min(20000, number));
					event.target.value = String(field.max_length);
					commit();
				},
			});
			max.min = '1';
			max.max = '20000';
			max.className = 'small-text';
			parts.push(row(`${id}-max`, t.maxLength, max));
		}
		if (field.type === 'select') {
			parts.push(
				row(
					`${id}-empty`,
					t.emptyOption,
					textInput(`${id}-empty`, field.empty_option, (text) => {
						field.empty_option = text;
					}, { max: 200 }),
					t.emptyOptionHelp,
				),
			);
		}
		if (field.type === 'choice') {
			parts.push(
				checkbox(`${id}-multiple`, t.multiple, field.multiple, (checked) => {
					field.multiple = checked;
				}),
			);
		}
		if (field.type === 'select' || field.type === 'choice') {
			parts.push(renderOptions(field, id));
		}
		if (field.type === 'file') {
			parts.push(...renderFileSettings(field, id));
		}
		parts.push(
			row(
				`${id}-help`,
				t.help,
				textInput(`${id}-help`, field.help, (text) => {
					field.help = text;
				}, { max: 500 }),
			),
		);
		return el('div', { class: 'ww-fb-field__body', id: `${id}-body` }, parts);
	};

	const typeOf = (field) => data.types[field.type] ?? { name: field.type, icon: 'dashicons-forms', desc: '' };

	// De soort onder het label in de lijst: de naam van het type, bij een regel met e-mail of telefoon de soort invoer,
	// bij een keuzeveld het aantal opties.
	const fieldSummary = (field) => {
		const name = typeOf(field).name;
		if (field.type === 'line' && field.input === 'email') {
			return `${name} · ${t.inputEmail}`;
		}
		if (field.type === 'line' && field.input === 'tel') {
			return `${name} · ${t.inputTel}`;
		}
		if (field.type === 'select' || field.type === 'choice') {
			const count = Array.isArray(field.options) ? field.options.length : 0;
			return `${name} · ${count === 1 ? t.optionOne : format(t.optionsCount, count)}`;
		}
		return name;
	};

	// Per veld een functie die zijn rij bijwerkt zonder opnieuw te tekenen (bij typen in het venster). render() maakt de
	// rijen opnieuw en zet dan ook nieuwe functies.
	const rowRefreshers = new WeakMap();

	// Een veld in de lijst: greep, type-icoon, een knop met label en soort die het venster opent, de tag, en Bewerken,
	// omhoog en omlaag. Verwijderen gebeurt in het venster.
	const renderField = (field, index) => {
		const id = itemId(field);
		const type = typeOf(field);
		const last = ui.list.length - 1;
		const item = el('li', { class: 'ww-fb-field' });

		const title = el('span', { class: 'ww-fb-field__name', id: `${id}-name` });
		const summary = el('span', { class: 'ww-fb-chip' });
		// Boven de bovenste stap kan geen veld staan.
		const top = index === 0 || (index === 1 && isStep(ui.list[0]));
		const edit = iconButton(`${id}-edit`, 'dashicons-edit', '', () => openField(field));
		edit.classList.add('ww-fb-field__edit');
		edit.setAttribute('aria-haspopup', 'dialog');
		const up = iconButton(`${id}-up`, 'dashicons-arrow-up-alt2', '', () => moveField(field, -1), top);
		const down = iconButton(`${id}-down`, 'dashicons-arrow-down-alt2', '', () => moveField(field, 1), index === last);
		// De naam, de soort en de namen van de knoppen; ook bij typen in het label in het venster.
		const refresh = () => {
			const name = fieldName(field);
			title.textContent = name;
			title.classList.toggle('is-empty', plain(field.label) === '');
			summary.textContent = fieldSummary(field);
			for (const [button, text] of [
				[edit, t.editField],
				[up, t.moveUp],
				[down, t.moveDown],
			]) {
				button.setAttribute('aria-label', format(text, name));
				button.title = format(text, name);
			}
			edit.title = t.edit;
		};
		refresh();
		rowRefreshers.set(field, refresh);

		add(
			item,
			el(
				'div',
				{ class: 'ww-fb-field__head ww-fb-field__row' },
				draggable(item, ui.list, index, (newIndex) => afterFieldMove(ui.list[newIndex], 'up')),
				el('span', { class: 'ww-fb-field__icon', title: type.name }, el('span', { class: `dashicons ${type.icon}`, 'aria-hidden': 'true' })),
				el(
					'button',
					{
						type: 'button',
						class: 'ww-fb-field__open',
						id: `${id}-open`,
						'aria-haspopup': 'dialog',
						onclick: () => openField(field),
					},
					el(
						'span',
						{ class: 'ww-fb-field__text' },
						title,
						el('span', { class: 'ww-fb-field__meta' }, summary, field.required ? el('span', { class: 'ww-fb-chip ww-fb-chip--required' }, t.requiredMark) : null),
					),
					el('span', { class: 'ww-fb-field__go dashicons dashicons-arrow-right-alt2', 'aria-hidden': 'true' }),
				),
				field.key ? el('code', { class: 'ww-fb-field__key' }, `{${field.key}}`) : null,
				el('span', { class: 'ww-fb-actions' }, edit, up, down),
			),
		);
		return item;
	};

	/*
	 * Het venster van een veld: één <dialog> ná de builder in de metabox, zodat render() hem niet vervangt. Kop, inhoud
	 * en voet zijn vaste vakken die renderDialog() vult; zo blijft de inhoud op zijn plek staan als de builder opnieuw
	 * tekent. Knoppen zijn type="button" en er is geen <form method="dialog">: het venster staat binnen #post.
	 */

	const dialogHead = el('div', { class: 'ww-fb-dialog__head' });
	const dialogBody = el('div', { class: 'ww-fb-dialog__body' });
	const dialogFoot = el('div', { class: 'ww-fb-dialog__foot' });
	const dialog = el(
		'dialog',
		{
			class: 'ww-fb-dialog',
			'aria-labelledby': 'ww-fb-dialog-title',
			// Esc: de standaard cancel van <dialog>. Zelf sluiten, zodat de focus teruggaat naar de lijst.
			oncancel: (event) => {
				event.preventDefault();
				closeField();
			},
			// Sluit de browser het venster toch zelf (Chrome doet dat bij een herhaalde Esc), dan dezelfde afronding.
			onclose: () => {
				if (ui.dialog) {
					closeField();
				}
			},
		},
		dialogHead,
		dialogBody,
		dialogFoot,
		modalLive,
	);
	root.after(dialog);

	// Een veld dat nog focus heeft, verliest die eerst: dan vuurt change en krijgt een nieuw label zijn sleutel (en een
	// nieuwe optie zijn waarde), ook als het venster met Esc sluit of naar een ander veld gaat.
	const settleDialog = () => {
		const active = document.activeElement;
		if (active && dialog.contains(active) && active.matches('input, textarea, select')) {
			active.blur();
		}
	};

	// Vult kop, inhoud en voet van het venster (Ontwerp 8). Alle teksten via el() en textContent.
	const renderDialog = () => {
		if (!ui.dialog) {
			dialogHead.replaceChildren();
			dialogBody.replaceChildren();
			dialogFoot.replaceChildren();
			return;
		}
		const { field, isNew, asking } = ui.dialog;
		const id = itemId(field);
		const type = typeOf(field);
		const position = state.fields.indexOf(field);
		const total = state.fields.length;

		const titleText = () => (isNew ? format(t.newField, type.name) : fieldName(field));
		const title = el('span', { class: 'ww-fb-dialog__title' }, titleText());
		const refresh = () => {
			title.textContent = titleText();
			rowRefreshers.get(field)?.();
		};

		dialogHead.replaceChildren(
			el(
				'h2',
				{ class: 'ww-fb-dialog__heading', id: 'ww-fb-dialog-title' },
				el('span', { class: 'ww-fb-field__icon' }, el('span', { class: `dashicons ${type.icon}`, 'aria-hidden': 'true' })),
				title,
			),
			el(
				'button',
				{ type: 'button', class: 'ww-fb-dialog__close', id: 'ww-fb-dialog-close', 'aria-label': t.close, title: t.close, onclick: closeField },
				el('span', { class: 'dashicons dashicons-no-alt', 'aria-hidden': 'true' }),
			),
		);

		// De lijst met opties schuift zelf; die plek blijft staan als de inhoud opnieuw getekend wordt.
		const optionsScroll = dialogBody.querySelector('.ww-fb-options__list')?.scrollTop ?? 0;
		dialogBody.replaceChildren(renderFieldBody(field, id, refresh));
		const options = dialogBody.querySelector('.ww-fb-options__list');
		if (options) {
			options.scrollTop = optionsScroll;
		}

		const left = asking
			? el(
					'div',
					{ class: 'ww-fb-dialog__group ww-fb-dialog__ask', role: 'group', 'aria-labelledby': 'ww-fb-dialog-ask' },
					el('span', { id: 'ww-fb-dialog-ask' }, t.removeAsk),
					el(
						'button',
						{ type: 'button', class: 'button ww-fb-dialog__danger', id: 'ww-fb-dialog-remove-yes', onclick: () => removeField(field) },
						t.removeYes,
					),
					el(
						'button',
						{
							type: 'button',
							class: 'button',
							id: 'ww-fb-dialog-remove-no',
							onclick: () => {
								ui.dialog.asking = false;
								renderDialog();
								focusFirst('ww-fb-dialog-remove');
							},
						},
						t.cancel,
					),
				)
			: el(
					'div',
					{ class: 'ww-fb-dialog__group' },
					el(
						'button',
						{
							type: 'button',
							class: 'button-link button-link-delete ww-fb-dialog__remove',
							id: 'ww-fb-dialog-remove',
							onclick: () => {
								settleDialog();
								ui.dialog.asking = true;
								renderDialog();
								focusFirst('ww-fb-dialog-remove-no');
							},
						},
						isNew ? t.discard : t.removeField,
					),
				);
		const go = (delta) => () => {
			const next = state.fields[position + delta];
			if (next) {
				openField(next);
				announce(`${fieldName(next)}. ${format(t.fieldNofM, position + delta + 1, total)}`);
			}
		};
		const right = asking
			? null
			: el(
					'div',
					{ class: 'ww-fb-dialog__group' },
					isNew
						? null
						: [
								el(
									'button',
									{ type: 'button', class: 'button ww-fb-dialog__nav', id: 'ww-fb-dialog-prev', 'aria-label': t.prevField, title: t.prevField, disabled: position <= 0, onclick: go(-1) },
									'‹',
								),
								el('span', { class: 'ww-fb-dialog__position' }, format(t.fieldNofM, position + 1, total)),
								el(
									'button',
									{ type: 'button', class: 'button ww-fb-dialog__nav', id: 'ww-fb-dialog-next', 'aria-label': t.nextField, title: t.nextField, disabled: position >= total - 1, onclick: go(1) },
									'›',
								),
							],
					el('button', { type: 'button', class: 'button button-primary', id: 'ww-fb-dialog-done', onclick: closeField }, isNew ? t.addThis : t.done),
				);
		dialogFoot.replaceChildren(left, ...(right ? [right] : []));
	};

	// Opent het venster voor een veld (of wisselt van veld als het al open is) en zet de focus op het label.
	const openField = (field, isNew = false) => {
		settleDialog();
		const other = !ui.dialog || ui.dialog.field !== field;
		ui.dialog = { field, isNew, asking: false };
		ui.menu = false;
		if (other) {
			// Een ander veld: de oude opties horen er niet bij, en de inhoud begint bovenaan.
			dialogBody.replaceChildren();
		}
		renderDialog();
		if (!dialog.open) {
			dialog.showModal();
		}
		if (other) {
			dialogBody.scrollTop = 0;
		}
		focusFirst(`${itemId(field)}-label`);
	};

	// Sluit het venster. Een nieuw veld zonder label blijft staan, met "(nog geen label)". De lijst wordt opnieuw
	// getekend (een nieuwe sleutel, opties, verplicht) en de focus gaat terug naar de knop van het veld.
	const closeField = () => {
		if (!ui.dialog) {
			return;
		}
		settleDialog();
		const { field } = ui.dialog;
		ui.dialog = null;
		if (dialog.open) {
			dialog.close();
		}
		render();
		focusFirst(`${itemId(field)}-open`, 'ww-fb-add');
	};

	// Een stap: een balk met Stap n en de titel; openklappen geeft het veld Titel. De bovenste stap staat vast zolang er
	// andere stappen zijn (en een stap alleen bestaat niet): niet te verslepen, verplaatsen of verwijderen. Hij blijft
	// wel een plek om iets op te laten vallen; syncList() zet hem daarna weer bovenaan.
	const renderStep = (step, index) => {
		const id = itemId(step);
		const open = ui.open.has(uid(step));
		const fixed = index === 0;
		const next = ui.list[index + 1];
		const empty = !next || isStep(next);
		const item = el('li', { class: `ww-fb-field ww-fb-step${open ? ' is-open' : ''}` });
		const handle = draggable(item, ui.list, index, (newIndex) => {
			const moved = ui.list[newIndex];
			// Boven de bovenste stap kan niets komen: wat erboven valt (veld of stap), komt eronder.
			if (newIndex === 0 && ui.list.length > 1) {
				ui.list.splice(0, 1);
				ui.list.splice(1, 0, moved);
			}
			afterFieldMove(moved, 'up');
		});

		const title = el('span', { class: 'ww-fb-field__name' }, step.title.trim());
		const up = iconButton(`${id}-up`, 'dashicons-arrow-up-alt2', format(t.moveUp, stepName(step)), () => moveField(step, -1), fixed || index === 1);
		const down = iconButton(`${id}-down`, 'dashicons-arrow-down-alt2', format(t.moveDown, stepName(step)), () => moveField(step, 1), fixed || index === ui.list.length - 1);
		const remove = iconButton(`${id}-remove`, 'dashicons-trash', format(t.remove, stepName(step)), () => removeStep(step), fixed);
		// Bij typen in de titel: de balk en de namen van de knoppen bijwerken, zonder opnieuw te tekenen.
		const refresh = () => {
			const name = stepName(step);
			title.textContent = step.title.trim();
			for (const [button, text] of [
				[up, t.moveUp],
				[down, t.moveDown],
				[remove, t.remove],
			]) {
				button.setAttribute('aria-label', format(text, name));
				button.title = format(text, name);
			}
		};

		add(
			item,
			el(
				'div',
				{ class: 'ww-fb-field__head' },
				fixed ? el('span', { class: 'ww-fb-handle ww-fb-handle--off dashicons', 'aria-hidden': 'true' }) : handle,
				el(
					'button',
					{
						type: 'button',
						class: 'ww-fb-field__toggle',
						id: `${id}-toggle`,
						'aria-expanded': String(open),
						'aria-controls': open ? `${id}-body` : null,
						onclick: () => {
							if (open) {
								ui.open.delete(uid(step));
							} else {
								ui.open.add(uid(step));
							}
							render();
						},
					},
					el('span', { class: 'dashicons dashicons-editor-ol', 'aria-hidden': 'true' }),
					el('span', { class: 'ww-fb-step__number' }, format(t.stepN, stepNumber(step))),
					title,
					el('span', { class: `ww-fb-field__chevron dashicons dashicons-arrow-${open ? 'up' : 'down'}`, 'aria-hidden': 'true' }),
				),
				el('span', { class: 'ww-fb-actions' }, up, down, remove),
			),
			empty ? el('p', { class: 'ww-fb-step__empty' }, t.stepEmpty) : null,
			open
				? el(
						'div',
						{ class: 'ww-fb-field__body', id: `${id}-body` },
						row(
							`${id}-title`,
							t.stepTitle,
							textInput(`${id}-title`, step.title, (text) => {
								step.title = text;
								refresh();
							}, { max: 200 }),
						),
					)
				: null,
		);
		return item;
	};

	// De knop Veld toevoegen met het menu van de veldtypen en, na een scheiding, Stap. Pijltjes lopen door het menu,
	// Escape sluit het. De 50 velden tellen alleen echte velden; bij maxSteps stappen staat Stap uit.
	const renderAdd = () => {
		const full = state.fields.length >= 50;
		const stepsFull = stepCount() >= (data.maxSteps ?? 10);
		const menu = el(
			'ul',
			{ class: 'ww-fb-menu', id: 'ww-fb-add-menu', hidden: !ui.menu },
			Object.entries(data.types).map(([type, info]) =>
				el(
					'li',
					{},
					el(
						'button',
						{ type: 'button', class: 'ww-fb-menu__item ww-fb-menu__item--type', disabled: full, onclick: () => addField(type) },
						el('span', { class: 'ww-fb-field__icon' }, el('span', { class: `dashicons ${info.icon}`, 'aria-hidden': 'true' })),
						el('span', { class: 'ww-fb-menu__text' }, el('b', {}, info.name), info.desc ? el('small', {}, info.desc) : null),
					),
				),
			),
			el('li', { class: 'ww-fb-menu__separator', role: 'separator' }),
			el(
				'li',
				{},
				el(
					'button',
					{ type: 'button', class: 'ww-fb-menu__item', disabled: stepsFull, onclick: addStep },
					el('span', { class: 'dashicons dashicons-editor-ol', 'aria-hidden': 'true' }),
					t.step,
				),
			),
		);
		const toggle = el(
			'button',
			{
				type: 'button',
				class: 'button button-primary',
				id: 'ww-fb-add',
				'aria-expanded': String(ui.menu),
				'aria-controls': 'ww-fb-add-menu',
				disabled: full && stepsFull,
				onclick: () => {
					ui.menu = !ui.menu;
					render();
					if (ui.menu) {
						root.querySelector('.ww-fb-menu__item:not(:disabled)')?.focus();
					}
				},
			},
			el('span', { class: 'dashicons dashicons-plus-alt2', 'aria-hidden': 'true' }),
			' ',
			t.addField,
		);
		const close = () => {
			ui.menu = false;
			menu.hidden = true;
			toggle.setAttribute('aria-expanded', 'false');
		};
		const wrap = el(
			'div',
			{
				class: 'ww-fb-add',
				onkeydown: (event) => {
					const items = [...menu.querySelectorAll('button:not(:disabled)')];
					const current = items.indexOf(document.activeElement);
					if (event.key === 'Escape' && ui.menu) {
						event.preventDefault();
						close();
						toggle.focus();
					} else if (current >= 0 && (event.key === 'ArrowDown' || event.key === 'ArrowUp')) {
						event.preventDefault();
						const next = (current + (event.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length;
						items[next].focus();
					}
				},
				// Met Tab buiten het menu sluit het, zonder opnieuw te tekenen (dat zou een klik elders opeten). Klikken
				// buiten het menu: zie pointerdown onderaan.
				onfocusout: (event) => {
					if (ui.menu && event.relatedTarget && !wrap.contains(event.relatedTarget)) {
						close();
					}
				},
			},
			toggle,
			menu,
			full ? el('p', { class: 'description' }, t.maxFields) : null,
		);
		return wrap;
	};

	// De knop Volgorde, alleen zichtbaar op mobiel: daar zijn ↑ en ↓ verborgen tot je hem aanzet.
	const renderReorder = () =>
		el(
			'button',
			{
				type: 'button',
				class: 'button ww-fb-reorder',
				id: 'ww-fb-reorder',
				'aria-pressed': String(ui.reorder),
				onclick: () => {
					ui.reorder = !ui.reorder;
					render();
				},
			},
			el('span', { class: 'dashicons dashicons-sort', 'aria-hidden': 'true' }),
			' ',
			ui.reorder ? t.orderDone : t.order,
		);

	const renderFieldsTab = () => [
		ui.list.length
			? el(
					'ol',
					{ class: `ww-fb-fields${ui.reorder ? ' is-reorder' : ''}` },
					ui.list.map((item, index) => (isStep(item) ? renderStep(item, index) : renderField(item, index))),
				)
			: el('p', { class: 'ww-fb-empty' }, t.noFields),
		el('div', { class: 'ww-fb-fields-foot' }, renderAdd(), ui.list.length > 1 ? renderReorder() : null),
		el(
			'div',
			{ class: 'ww-fb-submit' },
			row(
				'ww-fb-submit-label',
				t.submitLabel,
				textInput('ww-fb-submit-label', state.submit_label, (text) => {
					state.submit_label = text;
				}, { max: 200 }),
			),
		),
	];

	/*
	 * Tabblad Mail.
	 */

	// De keuzelijst Veld invoegen bij een onderwerp of bericht: zet {tag} op de plek van de cursor. Een veld waar de
	// cursor nog niet stond, krijgt de tag aan het eind.
	const insertSelect = (target, tags, name, describedBy = null) =>
		el(
			'select',
			{
				class: 'ww-fb-insert',
				'aria-label': format(t.insertIn, name),
				'aria-describedby': describedBy,
				onchange: (event) => {
					const value = event.target.value;
					event.target.value = '';
					if (!value) {
						return;
					}
					const tag = `{${value}}`;
					const touched = target.dataset.wwTouched === '1';
					const start = touched ? target.selectionStart : target.value.length;
					const end = touched ? target.selectionEnd : target.value.length;
					target.setRangeText(tag, start, end, 'end');
					target.dispatchEvent(new Event('input', { bubbles: true }));
					target.focus();
					announce(format(t.inserted, tag));
				},
			},
			el('option', { value: '' }, `${t.insert}…`),
			tags.map(({ tag, label }) => el('option', { value: tag }, `${label} {${tag}}`)),
		);

	// Onderwerp en bericht van een mail, elk met Veld invoegen. note: een uitleg die onder de eerste knop Veld
	// invoegen komt en bij beide knoppen hoort (aria-describedby).
	const mailTexts = (mail, prefix, tags, note = null) => {
		const noteId = note ? `${prefix}-insert-note` : null;
		const subject = textInput(`${prefix}-subject`, mail.subject, (text) => {
			mail.subject = text;
		}, { max: 200 });
		const body = textInput(`${prefix}-body`, mail.body, (text) => {
			mail.body = text;
		}, { max: 10000, rows: 8 });
		return [
			el('div', { class: 'ww-fb-row' }, el('label', { for: subject.id, class: 'ww-fb-row__label' }, t.subject), el('div', { class: 'ww-fb-with-insert' }, subject, insertSelect(subject, tags, t.subject, noteId)), note ? el('p', { class: 'description', id: noteId }, note) : null),
			el('div', { class: 'ww-fb-row' }, el('label', { for: body.id, class: 'ww-fb-row__label' }, t.body), insertSelect(body, tags, t.body, noteId), body),
		];
	};

	const renderMailTab = () => {
		const { notify, confirm } = state.mail;
		const replyOptions = [['', t.replyToNone], ...emailFields(false).map((field) => [field.key, fieldName(field)])];
		const required = emailFields(true);
		const toOptions = [['', t.confirmToNone], ...required.map((field) => [field.key, fieldName(field)])];
		return [
			el(
				'fieldset',
				{ class: 'ww-fb-section' },
				el('legend', {}, t.notify),
				checkbox('ww-fb-notify-enabled', t.notifyEnabled, notify.enabled, (checked) => {
					notify.enabled = checked;
				}),
				row(
					'ww-fb-notify-to',
					t.notifyTo,
					textInput('ww-fb-notify-to', notify.to, (text) => {
						notify.to = text;
					}, { max: 1000 }),
					t.notifyToHelp,
				),
				mailTexts(notify, 'ww-fb-notify', notifyTags()),
				row('ww-fb-notify-reply', t.replyTo, select('ww-fb-notify-reply', notify.reply_to_field, replyOptions, (value) => {
					notify.reply_to_field = value;
				})),
			),
			el(
				'fieldset',
				{ class: 'ww-fb-section' },
				el('legend', {}, t.confirm),
				checkbox('ww-fb-confirm-enabled', t.confirmEnabled, confirm.enabled, (checked) => {
					confirm.enabled = checked;
				}),
				row(
					'ww-fb-confirm-to',
					t.confirmTo,
					select('ww-fb-confirm-to', confirm.to_field, toOptions, (value) => {
						confirm.to_field = value;
					}),
					required.length ? null : t.confirmNoEmail,
				),
				// Met actieve reCAPTCHA geldt de beperking alleen nog zonder geslaagde controle; dat zegt de zin onder Veld
				// invoegen.
				recaptchaActive() ? null : el('p', { class: 'description ww-fb-note' }, t.confirmLimit),
				mailTexts(confirm, 'ww-fb-confirm', confirmTags(), recaptchaActive() ? t.confirmRecaptcha : null),
			),
		];
	};

	/*
	 * Tabblad Na versturen.
	 */

	const renderAfterTab = () => {
		const after = state.after;
		const radio = (value, text) =>
			el(
				'label',
				{ class: 'ww-fb-radio' },
				el('input', {
					type: 'radio',
					name: 'ww-fb-after-type',
					id: `ww-fb-after-${value}`,
					value,
					checked: after.type === value,
					onchange: () => {
						after.type = value;
						commit();
						render();
					},
				}),
				' ',
				text,
			);
		// Een gekozen pagina die niet meer gepubliceerd is, blijft in de lijst; anders valt de keuze stil weg.
		const pages = data.pages.map((page) => [page.id, page.title]);
		if (after.page_id && !data.pages.some((page) => page.id === Number(after.page_id))) {
			pages.unshift([after.page_id, format(t.pageUnpublished, after.page_id)]);
		}
		return [
			el('fieldset', { class: 'ww-fb-section' }, el('legend', {}, t.afterType), radio('message', t.afterMessage), radio('redirect', t.afterRedirect)),
			after.type === 'redirect'
				? el(
						'div',
						{ class: 'ww-fb-section' },
						row('ww-fb-after-page', t.page, select('ww-fb-after-page', after.page_id, [[0, t.pageNone], ...pages], (value) => {
							after.page_id = Number(value);
						})),
						row(
							'ww-fb-after-url',
							t.url,
							textInput('ww-fb-after-url', after.url, (text) => {
								after.url = text;
							}, { max: 2048 }),
							t.urlHelp,
						),
					)
				: el(
						'div',
						{ class: 'ww-fb-section' },
						row(
							'ww-fb-after-message',
							t.message,
							textInput('ww-fb-after-message', after.message, (text) => {
								after.message = text;
							}, { max: 2000, rows: 4 }),
							t.messageHelp,
						),
					),
		];
	};

	/*
	 * Tabblad Opslag.
	 */

	const renderStorageTab = () => {
		const storage = state.storage;
		const months = textInput('ww-fb-retention', String(storage.retention_months ?? 12), () => {}, {
			type: 'number',
			onChange: (event) => {
				const number = Number.parseInt(event.target.value, 10);
				storage.retention_months = Number.isNaN(number) ? 12 : Math.max(1, Math.min(120, number));
				event.target.value = String(storage.retention_months);
				commit();
			},
		});
		months.min = '1';
		months.max = '120';
		months.className = 'small-text';
		// Zonder sleutels is de schakelaar uit en vergrendeld; de keuze van het formulier blijft in de configuratie
		// staan, zodat hij weer geldt zodra er sleutels zijn. Een beheerder krijgt de link naar Instellingen.
		const configured = Boolean(data.recaptchaConfigured);
		const missing = configured
			? null
			: [t.recaptchaMissing, data.settingsUrl ? [' ', el('a', { href: data.settingsUrl }, t.recaptchaSettings)] : null];
		// Met een bestandsveld staat opslaan vast aan, zoals ww_form_sanitize() het ook afdwingt.
		const locked = hasFileField();
		if (locked && !storage.store) {
			storage.store = true;
			commit();
		}
		return [
			checkbox(
				'ww-fb-recaptcha',
				t.recaptcha,
				configured && state.recaptcha !== false,
				(checked) => {
					state.recaptcha = checked;
				},
				missing,
				!configured,
			),
			checkbox(
				'ww-fb-store',
				t.store,
				storage.store,
				(checked) => {
					storage.store = checked;
				},
				locked ? t.storeFile : t.storeHelp,
				locked,
			),
			row('ww-fb-retention', t.retention, months, t.retentionHelp),
		];
	};

	/*
	 * Tabbladen en render().
	 */

	const TABS = [
		['fields', t.tabFields, renderFieldsTab, 'dashicons-feedback'],
		['mail', t.tabMail, renderMailTab, 'dashicons-email'],
		['after', t.tabAfter, renderAfterTab, 'dashicons-yes-alt'],
		['storage', t.tabStorage, renderStorageTab, 'dashicons-database'],
	];

	// De onderdelen staan in het zijpaneel en in de kiezer op mobiel (inc/forms-panel.php). Ontbreekt het paneel, dan
	// tekent render() de tabbladen zoals vroeger boven in de metabox.
	const panelTabs = document.getElementById('ww-forms-panel-tabs');
	const pickerTabs = document.getElementById('ww-forms-picker-tabs');
	const picker = document.getElementById('ww-forms-picker-edit');

	// De id van een tabblad: die in het paneel (of in de metabox) labelt het tabpaneel; die in de kiezer is apart.
	const tabId = (id, kind = 'panel') => (kind === 'picker' ? `ww-fb-picker-tab-${id}` : `ww-fb-tab-${id}`);

	const selectTab = (id, kind = 'panel') => {
		ui.tab = id;
		ui.menu = false;
		render();
		focusFirst(tabId(id, kind));
	};

	// Pijltjes en Home/End lopen door de onderdelen; keys geeft per toets de stap of de plaats.
	const tabKeys = (keys, kind) => (event) => {
		// Met Alt, Ctrl of Meta is het een sneltoets van de browser of het systeem (bijvoorbeeld Alt+← terug).
		if (event.altKey || event.ctrlKey || event.metaKey) {
			return;
		}
		const index = TABS.findIndex(([id]) => id === ui.tab);
		if (event.key in keys) {
			event.preventDefault();
			const next = keys[event.key](index);
			selectTab(TABS[(next + TABS.length) % TABS.length][0], kind);
		}
	};

	const renderTabs = () =>
		el(
			'div',
			{
				class: 'nav-tab-wrapper ww-fb-tabs',
				role: 'tablist',
				'aria-label': t.tabs,
				onkeydown: tabKeys(
					{ ArrowRight: (i) => i + 1, ArrowLeft: (i) => i - 1, Home: () => 0, End: () => TABS.length - 1 },
					'panel',
				),
			},
			TABS.map(([id, label]) =>
				el(
					'button',
					{
						type: 'button',
						role: 'tab',
						id: tabId(id),
						class: `nav-tab${id === ui.tab ? ' nav-tab-active' : ''}`,
						'aria-selected': String(id === ui.tab),
						'aria-controls': `ww-fb-panel-${id}`,
						tabindex: id === ui.tab ? '0' : '-1',
						onclick: () => selectTab(id),
					},
					label,
				),
			),
		);

	// Het aantal velden achter Velden; commit() werkt het bij zonder de onderdelen opnieuw te tekenen.
	const fieldCount = () => el('span', { class: 'ww-forms-count ww-fb-tab-count' }, String(state.fields.length));

	// Vult de lijst in het paneel (kind 'panel') of in de kiezer (kind 'picker') met de onderdelen als tabbladen. In de
	// kiezer sluit een keuze het uitklapmenu en staat het gekozen onderdeel in de summary.
	const renderPanelTabs = (container, kind) => {
		container.setAttribute('role', 'tablist');
		container.setAttribute('aria-orientation', 'vertical');
		container.setAttribute('aria-label', t.sections);
		container.onkeydown = tabKeys(
			{ ArrowDown: (i) => i + 1, ArrowUp: (i) => i - 1, Home: () => 0, End: () => TABS.length - 1 },
			kind,
		);
		container.replaceChildren(
			...TABS.map(([id, label, , icon]) =>
				el(
					'li',
					{ role: 'presentation' },
					el(
						'button',
						{
							type: 'button',
							role: 'tab',
							id: tabId(id, kind),
							class: 'ww-forms-panel__tab',
							'aria-selected': String(id === ui.tab),
							'aria-controls': `ww-fb-panel-${id}`,
							tabindex: id === ui.tab ? '0' : '-1',
							onclick: () => {
								selectTab(id, kind);
								if (kind === 'picker' && picker) {
									picker.open = false;
									picker.querySelector('summary')?.focus();
								}
							},
						},
						el('span', { class: `dashicons ${icon}`, 'aria-hidden': 'true' }),
						el('span', { class: 'ww-forms-nav__label' }, label),
						id === 'fields' ? fieldCount() : null,
					),
				),
			),
		);
		if (kind === 'picker' && picker) {
			const value = picker.querySelector('summary b');
			if (value) {
				value.textContent = TABS.find(([id]) => id === ui.tab)?.[1] ?? '';
			}
		}
	};

	// Bouwt de builder (en een open venster) opnieuw op en zet de focus terug op het element met dezelfde id.
	const render = () => {
		const active = document.activeElement;
		const owners = [root, panelTabs, pickerTabs, dialog].filter(Boolean);
		const focusId = active && owners.some((owner) => owner.contains(active)) ? active.id : '';
		if (panelTabs) {
			renderPanelTabs(panelTabs, 'panel');
			if (pickerTabs) {
				renderPanelTabs(pickerTabs, 'picker');
			}
		}
		// Via add(): replaceChildren(null) zou de tekst "null" plaatsen.
		root.replaceChildren();
		add(
			root,
			panelTabs ? null : renderTabs(),
			TABS.map(([id, , build]) =>
				el(
					'div',
					{
						class: 'ww-fb-panel',
						role: 'tabpanel',
						id: `ww-fb-panel-${id}`,
						'aria-labelledby': tabId(id),
						hidden: id !== ui.tab,
					},
					id === ui.tab ? build() : null,
				),
			),
		);
		renderDialog();
		if (focusId) {
			focusFirst(focusId);
		}
	};

	// Enter in een invoerveld zou het hele bewerkscherm versturen (Bijwerken); in de builder en in het venster (dat
	// binnen #post staat) doet Enter niets.
	const blockEnter = (event) => {
		if (event.key === 'Enter' && event.target.matches('input:not([type="checkbox"]):not([type="radio"]), select')) {
			event.preventDefault();
		}
	};
	root.addEventListener('keydown', blockEnter);
	dialog.addEventListener('keydown', blockEnter);

	// Klikken buiten Veld toevoegen sluit het menu, ook in browsers die een knop bij klikken geen focus geven.
	document.addEventListener('pointerdown', (event) => {
		if (ui.menu && !event.target.closest('.ww-fb-add')) {
			ui.menu = false;
			const menu = document.getElementById('ww-fb-add-menu');
			if (menu) {
				menu.hidden = true;
			}
			document.getElementById('ww-fb-add')?.setAttribute('aria-expanded', 'false');
		}
	});

	render();
})();
