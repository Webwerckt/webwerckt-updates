/**
 * De invoer van velden die de tekenlaag tekent (inc/settings-fields-render.php): lijsten met pagina's, één afbeelding,
 * meerdere afbeeldingen, en wijzigingen in een wysiwyg melden. Zonder kennis van het scherm: de Site-instellingen en
 * het bewerkscherm roepen window.wwFieldInputs.init( root, { texts, onChange } ) aan. Dit bestand doet zelf niets
 * bij het laden.
 */
( function () {
	'use strict';

	// Vult %s, %d, %1$s enzovoort in, zoals sprintf in PHP.
	function format( text ) {
		var values = Array.prototype.slice.call( arguments, 1 );
		var next = 0;
		return String( text || '' ).replace( /%(?:(\d)\$)?[sd]/g, function ( match, position ) {
			var value = values[ position ? position - 1 : next++ ];
			return undefined === value || null === value ? '' : String( value );
		} );
	}

	function dashicon( name ) {
		var span = document.createElement( 'span' );
		span.className = 'dashicons dashicons-' + name;
		span.setAttribute( 'aria-hidden', 'true' );
		return span;
	}

	/*
	 * De twee soorten lijsten met omhoog, omlaag en weghalen: pagina's (relatie met berichten) en afbeeldingen.
	 * field is het blok om de lijst heen, list de ul, prefix het begin van de klassen van items en knoppen.
	 */
	var PICKS = { field: 'ww-settings-pickfield', list: 'ww-settings-picks', prefix: 'ww-settings-picks' };
	var IMAGES = { field: 'ww-field-images', list: 'ww-field-images__list', prefix: 'ww-field-images' };

	/**
	 * Koppelt de invoer binnen root. Geeft { refresh } terug: na het terugzetten van de HTML (ongedaan maken) zet
	 * refresh de knoppen van de lijsten goed en laadt de editors opnieuw uit hun tekstvak.
	 *
	 * @param {Element} root    Element met de velden, zoals het formulier.
	 * @param {Object}  options texts (vertaalde teksten) en onChange (bij elke wijziging die het script zelf doet).
	 * @return {{refresh: Function}}
	 */
	function init( root, options ) {
		options = options || {};
		var texts = options.texts || window.wwFieldInputsTexts || {};
		var onChange = 'function' === typeof options.onChange ? options.onChange : function () {};

		/* Lijsten: volgorde, knoppen, verplaatsen en weghalen. */

		function listItems( list, kind ) {
			return Array.prototype.slice.call( list.querySelectorAll( '.' + kind.prefix + '__item' ) );
		}

		function updateList( list, kind ) {
			var items = listItems( list, kind );
			items.forEach( function ( item, index ) {
				item.querySelector( '.' + kind.prefix + '__up' ).disabled = 0 === index;
				item.querySelector( '.' + kind.prefix + '__down' ).disabled = items.length - 1 === index;
			} );
		}

		function updateAllLists() {
			[ PICKS, IMAGES ].forEach( function ( kind ) {
				Array.prototype.forEach.call( root.querySelectorAll( '.' + kind.list ), function ( list ) {
					updateList( list, kind );
				} );
			} );
		}

		function listButton( kind, action, icon, label, extra ) {
			var button = document.createElement( 'button' );
			button.type = 'button';
			button.className = 'button-link ' + ( extra || '' ) + ' ' + kind.prefix + '__' + action;
			button.setAttribute( 'aria-label', label );
			button.appendChild( dashicon( icon ) );
			return button;
		}

		// Een nieuw item met verborgen ID, eventueel een voorbeeld, de titel en de drie knoppen. Geeft de knop weghalen.
		function addItem( field, kind, id, title, image ) {
			var list = field.querySelector( '.' + kind.list );
			var marker = field.querySelector( 'input[type="hidden"][value=""]' );
			var item = document.createElement( 'li' );
			item.className = kind.prefix + '__item';
			var hidden = document.createElement( 'input' );
			hidden.type = 'hidden';
			hidden.name = marker ? marker.name : '';
			hidden.value = id;
			var label = document.createElement( 'span' );
			label.className = kind.prefix + '__title';
			label.textContent = title;
			item.appendChild( hidden );
			if ( image ) {
				item.appendChild( image );
			}
			item.appendChild( label );
			item.appendChild( listButton( kind, 'up', 'arrow-up-alt2', format( texts.up, title ) ) );
			item.appendChild( listButton( kind, 'down', 'arrow-down-alt2', format( texts.down, title ) ) );
			item.appendChild( listButton( kind, 'remove', 'no-alt', format( texts.remove, title ), 'button-link-delete' ) );
			list.appendChild( item );
			updateList( list, kind );
			return item.querySelector( '.' + kind.prefix + '__remove' );
		}

		// Omhoog, omlaag of weghalen. Geeft false als de knop daar niet bij hoort.
		function moveOrRemove( button, kind ) {
			var field = button.closest( '.' + kind.field );
			var list = field.querySelector( '.' + kind.list );
			var item = button.closest( '.' + kind.prefix + '__item' );
			if ( ! item ) {
				return false;
			}

			if ( button.classList.contains( kind.prefix + '__remove' ) ) {
				var neighbour = item.nextElementSibling || item.previousElementSibling;
				item.remove();
				updateList( list, kind );
				var focus = neighbour ? neighbour.querySelector( '.' + kind.prefix + '__remove' ) : field.querySelector( '.' + kind.prefix + '__add' );
				if ( focus ) {
					focus.focus();
				}
				onChange();
				return true;
			}

			var up = button.classList.contains( kind.prefix + '__up' );
			var target = up ? item.previousElementSibling : item.nextElementSibling;
			if ( ! target ) {
				return true;
			}
			list.insertBefore( item, up ? target : target.nextElementSibling );
			updateList( list, kind );
			// Een uitgeschakelde knop houdt de focus niet: aan de rand gaat de focus naar de andere richting.
			var kept = button.disabled ? item.querySelector( '.' + kind.prefix + ( up ? '__down' : '__up' ) ) : button;
			if ( kept ) {
				kept.focus();
			}
			onChange();
			return true;
		}

		/* Lijsten met pagina's. */

		function hidePicker( field ) {
			var select = field.querySelector( '.ww-settings-picks__select' );
			if ( select ) {
				select.value = '';
				select.hidden = true;
			}
		}

		function handlePickClick( button ) {
			var field = button.closest( '.ww-settings-pickfield' );
			var list = field.querySelector( '.ww-settings-picks' );

			if ( button.classList.contains( 'ww-settings-picks__add' ) ) {
				var select = field.querySelector( '.ww-settings-picks__select' );
				var chosen = listItems( list, PICKS ).map( function ( li ) {
					return li.querySelector( 'input' ).value;
				} );
				Array.prototype.forEach.call( select.options, function ( option ) {
					option.disabled = '' !== option.value && -1 !== chosen.indexOf( option.value );
				} );
				select.hidden = false;
				select.focus();
				return;
			}
			moveOrRemove( button, PICKS );
		}

		root.addEventListener( 'change', function ( event ) {
			var select = event.target;
			if ( ! select.classList || ! select.classList.contains( 'ww-settings-picks__select' ) || '' === select.value ) {
				return;
			}
			var field = select.closest( '.ww-settings-pickfield' );
			var option = select.options[ select.selectedIndex ];
			var remove = addItem( field, PICKS, select.value, option.textContent );
			hidePicker( field );
			remove.focus();
			onChange();
		} );

		root.addEventListener( 'keydown', function ( event ) {
			if ( 'Escape' === event.key && event.target.classList && event.target.classList.contains( 'ww-settings-picks__select' ) ) {
				var field = event.target.closest( '.ww-settings-pickfield' );
				hidePicker( field );
				field.querySelector( '.ww-settings-picks__add' ).focus();
			}
		} );

		/* Eén afbeelding kiezen. */

		var frames = new WeakMap();

		function renderImage( box, attachment ) {
			var field = box.getAttribute( 'data-field' );
			var hidden = box.querySelector( 'input[type="hidden"]' );
			while ( box.lastChild !== hidden ) {
				box.removeChild( box.lastChild );
			}
			hidden.value = attachment ? attachment.id : '';

			if ( attachment ) {
				var preview = document.createElement( 'div' );
				preview.className = 'ww-settings-image__preview';
				var img = document.createElement( 'img' );
				img.src = attachment.sizes && attachment.sizes.medium ? attachment.sizes.medium.url : attachment.url;
				img.alt = '';
				var note = document.createElement( 'p' );
				note.className = 'description';
				note.textContent = ( attachment.filename || '' ) + ( attachment.width && attachment.height ? ' · ' + attachment.width + ' × ' + attachment.height : '' );
				preview.appendChild( img );
				preview.appendChild( note );
				box.appendChild( preview );
			} else {
				var empty = document.createElement( 'p' );
				empty.className = 'description ww-settings-image__empty';
				empty.textContent = texts.noImage;
				box.appendChild( empty );
			}

			var row = document.createElement( 'p' );
			var choose = document.createElement( 'button' );
			choose.type = 'button';
			choose.className = 'button ww-settings-image__choose';
			choose.id = 'ww-field-' + field;
			choose.textContent = attachment ? texts.other : texts.choose;
			row.appendChild( choose );
			if ( attachment ) {
				var remove = document.createElement( 'button' );
				remove.type = 'button';
				remove.className = 'button-link button-link-delete ww-settings-image__remove';
				remove.textContent = texts.delete;
				row.appendChild( document.createTextNode( ' ' ) );
				row.appendChild( remove );
			}
			box.appendChild( row );
			return choose;
		}

		function chooseImage( box ) {
			if ( ! window.wp || ! window.wp.media ) {
				return;
			}
			var frame = frames.get( box );
			if ( ! frame ) {
				frame = window.wp.media( { library: { type: 'image' }, multiple: false } );
				frame.on( 'select', function () {
					var attachment = frame.state().get( 'selection' ).first().toJSON();
					var choose = renderImage( box, attachment );
					choose.focus();
					onChange();
				} );
				frames.set( box, frame );
			}
			frame.open();
		}

		/* Meerdere afbeeldingen. */

		function thumbnail( attachment ) {
			var img = document.createElement( 'img' );
			img.src = attachment.sizes && attachment.sizes.thumbnail ? attachment.sizes.thumbnail.url : attachment.url;
			img.alt = '';
			return img;
		}

		function chooseImages( box ) {
			if ( ! window.wp || ! window.wp.media ) {
				return;
			}
			var frame = frames.get( box );
			if ( ! frame ) {
				frame = window.wp.media( { library: { type: 'image' }, multiple: 'add' } );
				// Elke keer een lege keuze: wat eerder gekozen en daarna weggehaald is, komt niet vanzelf terug.
				frame.on( 'open', function () {
					frame.state().get( 'selection' ).reset();
				} );
				frame.on( 'select', function () {
					var list = box.querySelector( '.ww-field-images__list' );
					var chosen = listItems( list, IMAGES ).map( function ( li ) {
						return li.querySelector( 'input' ).value;
					} );
					var last = null;
					frame.state().get( 'selection' ).each( function ( model ) {
						var attachment = model.toJSON();
						if ( -1 !== chosen.indexOf( String( attachment.id ) ) ) {
							return;
						}
						chosen.push( String( attachment.id ) );
						last = addItem( box, IMAGES, attachment.id, attachment.filename || attachment.title || String( attachment.id ), thumbnail( attachment ) );
					} );
					if ( last ) {
						last.focus();
						onChange();
					}
				} );
				frames.set( box, frame );
			}
			frame.open();
		}

		/* Klikken. */

		root.addEventListener( 'click', function ( event ) {
			var button = event.target.closest( 'button' );
			if ( ! button || ! root.contains( button ) ) {
				return;
			}
			if ( button.closest( '.ww-settings-pickfield' ) ) {
				handlePickClick( button );
				return;
			}
			var images = button.closest( '.ww-field-images' );
			if ( images ) {
				if ( button.classList.contains( 'ww-field-images__add' ) ) {
					chooseImages( images );
				} else {
					moveOrRemove( button, IMAGES );
				}
				return;
			}
			var box = button.closest( '.ww-settings-image' );
			if ( box && button.classList.contains( 'ww-settings-image__choose' ) ) {
				chooseImage( box );
			} else if ( box && button.classList.contains( 'ww-settings-image__remove' ) ) {
				renderImage( box, null ).focus();
				onChange();
			}
		} );

		/* Opgemaakte tekst: TinyMCE meldt geen input of change aan het formulier. Het tabblad Tekst wel. */

		var editors = [];

		function watchEditor( editor ) {
			if ( ! editor || 0 !== String( editor.id ).indexOf( 'ww_field_' ) || -1 !== editors.indexOf( editor ) ) {
				return;
			}
			var textarea = document.getElementById( editor.id );
			if ( ! textarea || ! root.contains( textarea ) ) {
				return;
			}
			editors.push( editor );
			editor.on( 'input change undo redo', function () {
				onChange();
			} );
		}

		if ( window.jQuery ) {
			// WordPress meldt elke editor die klaar is met dit jQuery-event (de editors starten na dit script).
			window.jQuery( document ).on( 'tinymce-editor-init', function ( event, editor ) {
				watchEditor( editor );
			} );
		}
		if ( window.tinymce && window.tinymce.editors ) {
			Array.prototype.forEach.call( window.tinymce.editors, watchEditor );
		}

		function reloadEditors() {
			editors.forEach( function ( editor ) {
				// load() leest het tekstvak opnieuw, met de alinea's zoals WordPress ze bij het openen maakt.
				if ( 'function' === typeof editor.load ) {
					editor.load();
				} else {
					editor.setContent( document.getElementById( editor.id ).value );
				}
			} );
		}

		updateAllLists();

		return {
			refresh: function () {
				updateAllLists();
				reloadEditors();
			}
		};
	}

	window.wwFieldInputs = { init: init };
}() );
