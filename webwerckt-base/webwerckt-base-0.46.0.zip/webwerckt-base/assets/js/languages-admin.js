/**
 * Het scherm Talen (inc/languages-admin-screen.php): Snel bewerken, volgorde en verwijderen zonder herladen, het venster
 * Taal toevoegen, de balk en de teksten bij niet-opgeslagen wijzigingen, het venster bij wisselen van onderdeel en
 * Kopiëren. Alleen gemak: zonder dit script werkt alles met de knoppen van de formulieren.
 */
( function () {
	'use strict';

	var root = document.querySelector( '.ww-languages' );
	if ( ! root ) {
		return;
	}
	// Teksten en gegevens uit PHP (_ww_languages_admin_assets()), al vertaald.
	var settings = window.wwLanguages || {};
	var texts = settings.texts || {};

	var overview = null; // Het formulier van het Overzicht (met de lijst Talen op de site).
	var tbody = null;
	var tracked = []; // { form, kind, initial, forced, dirty, note, next, nextValue }
	var savebar = null;
	var submitting = false;
	var addModal = null;
	var addOpener = null;
	var leave = null;
	var leaveOpener = null;
	var leaveLink = null;
	var snapshots = new WeakMap();

	/* Hulpjes. */

	// Vult %s, %d, %1$s enzovoort in, zoals sprintf in PHP.
	function format( text ) {
		var values = Array.prototype.slice.call( arguments, 1 );
		var next = 0;
		return String( text || '' ).replace( /%(?:(\d)\$)?[sd]/g, function ( match, position ) {
			var value = values[ position ? position - 1 : next++ ];
			return undefined === value || null === value ? '' : String( value );
		} );
	}

	function each( list, callback ) {
		Array.prototype.forEach.call( list, callback );
	}

	function element( tag, className, text ) {
		var node = document.createElement( tag );
		if ( className ) {
			node.className = className;
		}
		if ( undefined !== text ) {
			node.textContent = text;
		}
		return node;
	}

	function button( className, text, type ) {
		var node = element( 'button', className, text );
		node.type = type || 'button';
		return node;
	}

	function normalCode( value ) {
		return String( value || '' ).trim().toLowerCase();
	}

	// De velden die met Tab bereikbaar en zichtbaar zijn; velden in een dichte uitklapper tellen niet mee.
	function focusables( container ) {
		return Array.prototype.filter.call(
			container.querySelectorAll( 'a[href], button:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), summary' ),
			function ( node ) {
				return node.getClientRects().length > 0;
			}
		);
	}

	function trapTab( event, container ) {
		var items = focusables( container );
		if ( ! items.length ) {
			return;
		}
		var first = items[ 0 ];
		var last = items[ items.length - 1 ];
		if ( ! container.contains( document.activeElement ) ) {
			event.preventDefault();
			first.focus();
		} else if ( event.shiftKey && document.activeElement === first ) {
			event.preventDefault();
			last.focus();
		} else if ( ! event.shiftKey && document.activeElement === last ) {
			event.preventDefault();
			first.focus();
		}
	}

	/* Fouten bij een veld: aria-invalid, een tekst eronder en aria-describedby ernaartoe. */

	function setError( input, message, errorId ) {
		clearError( input );
		input.setAttribute( 'aria-invalid', 'true' );
		var id = errorId;
		if ( ! id ) {
			id = input.id + '-error';
			var error = element( 'p', 'ww-languages-error', message );
			error.id = id;
			input.insertAdjacentElement( 'afterend', error );
		}
		var described = input.getAttribute( 'aria-describedby' ) || '';
		input.setAttribute( 'data-ww-describedby', described );
		input.setAttribute( 'aria-describedby', ( described + ' ' + id ).trim() );
	}

	function clearError( input ) {
		if ( ! input.hasAttribute( 'aria-invalid' ) ) {
			return;
		}
		input.removeAttribute( 'aria-invalid' );
		var own = document.getElementById( input.id + '-error' );
		if ( own ) {
			own.remove();
		}
		var described = input.getAttribute( 'data-ww-describedby' ) || '';
		input.removeAttribute( 'data-ww-describedby' );
		if ( described ) {
			input.setAttribute( 'aria-describedby', described );
		} else {
			input.removeAttribute( 'aria-describedby' );
		}
	}

	/* Wijzigingen bewaken: een formulier is gewijzigd als zijn velden anders zijn dan bij het laden. */

	function serialize( form ) {
		var list = [];
		new FormData( form ).forEach( function ( value, key ) {
			if ( 'ww_next' !== key && '_wp_http_referer' !== key ) {
				list.push( key + '=' + value );
			}
		} );
		return list.sort().join( '&' );
	}

	function anyDirty() {
		return tracked.some( function ( entry ) {
			return entry.dirty;
		} );
	}

	function guard( event ) {
		if ( submitting || ! anyDirty() ) {
			return;
		}
		event.preventDefault();
		event.returnValue = '';
	}

	function check() {
		tracked.forEach( function ( entry ) {
			entry.dirty = entry.forced || serialize( entry.form ) !== entry.initial;
			if ( entry.note ) {
				entry.note.hidden = ! entry.dirty;
			}
			if ( 'overview' === entry.kind && savebar ) {
				savebar.hidden = ! entry.dirty;
			}
		} );
		if ( anyDirty() ) {
			window.addEventListener( 'beforeunload', guard );
		} else {
			window.removeEventListener( 'beforeunload', guard );
		}
	}

	function track( form, kind ) {
		var next = form.querySelector( 'input[name="ww_next"]' );
		var entry = {
			form: form,
			kind: kind,
			initial: serialize( form ),
			forced: '1' === form.getAttribute( 'data-ww-dirty' ),
			dirty: false,
			note: null,
			next: next,
			nextValue: next ? next.value : '',
		};
		form.addEventListener( 'input', check );
		form.addEventListener( 'change', check );
		form.addEventListener( 'submit', function ( event ) {
			// Een tweede klik terwijl het formulier al verstuurd wordt, doet niets.
			if ( submitting ) {
				event.preventDefault();
				return;
			}
			// Een open rij van Snel bewerken gaat eerst door Bijwerken; met een fout blijft de rij open en wordt er niets
			// verstuurd.
			var open = 'overview' === kind ? editing() : null;
			if ( open && ! applyEdit( open ) ) {
				event.preventDefault();
				if ( next ) {
					next.value = entry.nextValue;
				}
				return;
			}
			submitting = true;
			window.removeEventListener( 'beforeunload', guard );
		} );
		tracked.push( entry );
		return entry;
	}

	/* Overzicht: rijen. */

	function rows() {
		return tbody ? Array.prototype.slice.call( tbody.querySelectorAll( 'tr.ww-languages-row' ) ) : [];
	}

	function field( tr, name ) {
		return tr.querySelector( '.ww-languages-qe input[name$="[' + name + ']"]' );
	}

	function prefixOf( tr ) {
		var order = tr.querySelector( 'input[name$="[order]"]' );
		return order ? order.name.slice( 0, -'[order]'.length ) : '';
	}

	// Een rij die weggaat (Verwijderen, of doorgestreept na een geweigerde opslag) telt niet mee: de server laat hem
	// weg voor de controle.
	function isRemoved( tr ) {
		return tr.classList.contains( 'is-removing' ) || tr.classList.contains( 'is-removed' );
	}

	function rowName( tr ) {
		var name = field( tr, 'name' );
		var code = field( tr, 'code' );
		return ( name && name.value.trim() ) || ( code ? code.value.trim() : '' );
	}

	// De volgorde opnieuw als 1..n en de pijltjes aan de randen uit.
	function renumber() {
		var list = rows();
		list.forEach( function ( tr, index ) {
			var order = tr.querySelector( 'input[name$="[order]"]' );
			if ( order ) {
				order.value = String( index + 1 );
			}
			var moves = tr.querySelectorAll( 'button[name="ww_move"]' );
			if ( 2 === moves.length ) {
				moves[ 0 ].disabled = 0 === index;
				moves[ 1 ].disabled = list.length - 1 === index;
			}
		} );
	}

	// Naam, code, locale en adres van een rij, en de labels die de naam noemen.
	function showRow( tr, name, code, locale ) {
		var label = name || code;
		var strong = tr.querySelector( '.ww-languages-title strong' );
		if ( strong ) {
			( strong.querySelector( 'a' ) || strong ).textContent = label;
		}
		var badge = tr.querySelector( '.ww-languages-title .ww-languages-code' );
		if ( badge ) {
			badge.textContent = code;
		}
		var localeLine = tr.querySelector( '.ww-languages-locale' );
		if ( localeLine ) {
			localeLine.textContent = locale;
		}
		var address = tr.querySelector( '.ww-languages-col-address code' );
		if ( address ) {
			address.textContent = '1' === tr.getAttribute( 'data-default' ) ? '/' : '/' + code + '/';
		}
		var moves = tr.querySelectorAll( 'button[name="ww_move"]' );
		if ( 2 === moves.length ) {
			moves[ 0 ].setAttribute( 'aria-label', format( texts.up, label ) );
			moves[ 1 ].setAttribute( 'aria-label', format( texts.down, label ) );
		}
		each( tr.querySelectorAll( '.ww-languages-remove .screen-reader-text, .ww-languages-keep .screen-reader-text' ), function ( text ) {
			text.textContent = ' ' + label;
		} );
	}

	/* Snel bewerken. */

	function editing() {
		return tbody ? tbody.querySelector( 'tr.is-editing' ) : null;
	}

	function qeFields( tr ) {
		return [ field( tr, 'name' ), field( tr, 'code' ), field( tr, 'locale' ) ].filter( Boolean );
	}

	function closeEdit( tr, focus ) {
		tr.classList.remove( 'is-editing' );
		qeFields( tr ).forEach( clearError );
		var edit = tr.querySelector( '.ww-languages-edit' );
		if ( edit ) {
			edit.setAttribute( 'aria-expanded', 'false' );
			if ( focus ) {
				edit.focus();
			}
		}
		snapshots.delete( tr );
	}

	function openEdit( tr ) {
		var open = editing();
		if ( open && open !== tr ) {
			cancelEdit( open, false );
		}
		if ( tr.classList.contains( 'is-editing' ) ) {
			return;
		}
		snapshots.set( tr, qeFields( tr ).map( function ( input ) {
			return input.value;
		} ) );
		tr.classList.add( 'is-editing' );
		var edit = tr.querySelector( '.ww-languages-edit' );
		if ( edit ) {
			edit.setAttribute( 'aria-expanded', 'true' );
		}
		var name = field( tr, 'name' );
		if ( name ) {
			name.focus();
		}
	}

	// Annuleren of Escape: de waarden van bij het openen terug.
	function cancelEdit( tr, focus ) {
		var values = snapshots.get( tr );
		if ( values ) {
			qeFields( tr ).forEach( function ( input, index ) {
				input.value = values[ index ];
			} );
		}
		closeEdit( tr, focus );
		check();
	}

	function applyEdit( tr ) {
		var name = field( tr, 'name' );
		var code = field( tr, 'code' );
		var locale = field( tr, 'locale' );
		var invalid = [];
		[ name, code, locale ].forEach( function ( input ) {
			clearError( input );
			if ( '' === input.value.trim() ) {
				setError( input, texts.required );
				invalid.push( input );
			}
		} );
		if ( ! invalid.length ) {
			var wanted = normalCode( code.value );
			rows().some( function ( other ) {
				var otherCode = other !== tr && ! isRemoved( other ) ? field( other, 'code' ) : null;
				if ( otherCode && normalCode( otherCode.value ) === wanted ) {
					setError( code, format( texts.codeTaken, wanted, rowName( other ) ) );
					invalid.push( code );
					return true;
				}
				return false;
			} );
		}
		if ( invalid.length ) {
			invalid[ 0 ].focus();
			return false;
		}

		var before = snapshots.get( tr );
		var oldCode = before ? normalCode( before[ 1 ] ) : '';
		var newCode = normalCode( code.value );
		code.value = newCode;
		// De keuzelijst Standaardtaal stuurt de code: die gaat mee met de nieuwe code en naam.
		var select = overview.querySelector( 'select[name="ww_default"]' );
		if ( select && oldCode ) {
			each( select.options, function ( option ) {
				if ( option.value === oldCode ) {
					option.value = newCode;
					option.textContent = name.value.trim() || newCode;
				}
			} );
		}
		showRow( tr, name.value.trim(), newCode, locale.value.trim() );
		closeEdit( tr, true );
		check();
		return true;
	}

	/* Volgorde. */

	function move( trigger ) {
		var tr = trigger.closest( 'tr.ww-languages-row' );
		var up = /:-1$/.test( trigger.value );
		var target = up ? tr.previousElementSibling : tr.nextElementSibling;
		if ( ! target || ! target.classList.contains( 'ww-languages-row' ) ) {
			return;
		}
		tbody.insertBefore( tr, up ? target : target.nextElementSibling );
		renumber();
		// Een uitgeschakelde knop houdt de focus niet: aan de rand gaat de focus naar de andere richting.
		var moves = tr.querySelectorAll( 'button[name="ww_move"]' );
		var kept = trigger.disabled ? moves[ up ? 1 : 0 ] : trigger;
		if ( kept ) {
			kept.focus();
		}
		check();
	}

	/* Verwijderen en Toch houden. */

	function markRemoving( tr, trigger ) {
		var open = editing();
		if ( open === tr ) {
			cancelEdit( tr, false );
		}
		tr.classList.add( 'is-removing' );
		var input = document.createElement( 'input' );
		input.type = 'hidden';
		input.name = prefixOf( tr ) + '[remove]';
		input.value = '1';
		input.className = 'ww-languages-remove-input';
		tr.querySelector( 'td' ).appendChild( input );

		var title = tr.querySelector( '.ww-languages-title' );
		if ( title ) {
			title.appendChild( element( 'span', 'ww-languages-badge is-removed ww-languages-removing', texts.removing ) );
		}
		var keep = button( 'button-link ww-languages-keep', texts.keep );
		keep.appendChild( element( 'span', 'screen-reader-text', ' ' + rowName( tr ) ) );
		trigger.hidden = true;
		trigger.insertAdjacentElement( 'afterend', keep );
		keep.focus();
		// Een nieuwe rij van na een geweigerde opslag die weggaat, maakt Taal toevoegen weer vrij.
		setAddEnabled( ! hasNewRow() );
		check();
	}

	function keepRow( keep ) {
		var tr = keep.closest( 'tr.ww-languages-row' );
		tr.classList.remove( 'is-removing' );
		each( tr.querySelectorAll( '.ww-languages-remove-input, .ww-languages-removing' ), function ( node ) {
			node.remove();
		} );
		var remove = tr.querySelector( 'button[name="ww_remove"]' );
		keep.remove();
		if ( remove ) {
			remove.hidden = false;
			remove.focus();
		}
		setAddEnabled( ! hasNewRow() );
		check();
	}

	/* Taal toevoegen: het venster en de nieuwe rij. */

	function addLinks() {
		return root.querySelectorAll( 'a.ww-languages-add, .ww-languages-panel a[href*="language=new"], .ww-languages-menu a[href*="language=new"]' );
	}

	function hasNewRow() {
		return !! ( tbody && tbody.querySelector( 'tr.is-new:not(.is-removing):not(.is-removed)' ) );
	}

	// Er kan maar één nieuwe rij tegelijk zijn: tot het opslaan staat de knop uit.
	function setAddEnabled( enabled ) {
		each( addLinks(), function ( link ) {
			if ( enabled ) {
				link.removeAttribute( 'aria-disabled' );
				link.classList.remove( 'is-disabled' );
			} else {
				link.setAttribute( 'aria-disabled', 'true' );
				link.classList.add( 'is-disabled' );
			}
		} );
	}

	function modalField( name ) {
		return addModal ? addModal.querySelector( '#ww-languages-dialog-' + name ) : null;
	}

	function updateAddress() {
		var code = modalField( 'code' );
		var note = addModal ? addModal.querySelector( '#ww-languages-dialog-code-note' ) : null;
		if ( code && note ) {
			note.textContent = format( texts.address, normalCode( code.value ) || '…' );
		}
	}

	function clearModalErrors() {
		[ 'name', 'code', 'locale' ].forEach( function ( name ) {
			clearError( modalField( name ) );
		} );
		var error = addModal.querySelector( '.ww-languages-modal__error' );
		error.hidden = true;
		error.textContent = '';
	}

	function closeAdd( focus ) {
		if ( ! addModal ) {
			return;
		}
		addModal.remove();
		addModal = null;
		if ( focus && addOpener ) {
			addOpener.focus();
		}
		addOpener = null;
	}

	function openAdd( opener ) {
		var template = document.getElementById( 'ww-languages-add-template' );
		if ( ! template || addModal ) {
			return;
		}
		// De mobiele kiezer Onderdeel zou open achter het venster blijven staan.
		each( root.querySelectorAll( 'details.ww-languages-menu[open]' ), function ( menu ) {
			menu.open = false;
		} );
		addOpener = opener.closest( 'details.ww-languages-menu' ) ? opener.closest( 'details.ww-languages-menu' ).querySelector( 'summary' ) : opener;
		addModal = document.importNode( template.content, true ).firstElementChild;
		root.appendChild( addModal );

		var preset = addModal.querySelector( '.ww-languages-modal-preset' );
		var details = addModal.querySelector( 'details' );
		preset.addEventListener( 'change', function () {
			var option = preset.options[ preset.selectedIndex ];
			if ( 'other' === preset.value ) {
				details.open = true;
				modalField( 'name' ).focus();
				return;
			}
			if ( '' === preset.value ) {
				return;
			}
			modalField( 'name' ).value = option.getAttribute( 'data-name' ) || '';
			modalField( 'code' ).value = option.getAttribute( 'data-code' ) || '';
			modalField( 'locale' ).value = option.getAttribute( 'data-locale' ) || '';
			clearModalErrors();
			updateAddress();
		} );
		modalField( 'code' ).addEventListener( 'input', updateAddress );
		addModal.addEventListener( 'click', function ( event ) {
			var action = event.target.closest( 'button[data-ww-action]' );
			if ( action && 'cancel' === action.getAttribute( 'data-ww-action' ) ) {
				closeAdd( true );
			} else if ( action && 'add' === action.getAttribute( 'data-ww-action' ) ) {
				submitAdd();
			}
		} );
		addModal.addEventListener( 'keydown', function ( event ) {
			if ( 'Enter' === event.key && 'INPUT' === event.target.tagName ) {
				event.preventDefault();
				submitAdd();
			}
		} );
		updateAddress();
		preset.focus();
	}

	function submitAdd() {
		var details = addModal.querySelector( 'details' );
		var inputs = [ modalField( 'name' ), modalField( 'code' ), modalField( 'locale' ) ];
		clearModalErrors();

		var empty = inputs.filter( function ( input ) {
			return '' === input.value.trim();
		} );
		if ( empty.length ) {
			var error = addModal.querySelector( '.ww-languages-modal__error' );
			error.textContent = texts.fillAll;
			error.hidden = false;
			empty.forEach( function ( input ) {
				setError( input, texts.fillAll, error.id );
			} );
			details.open = true;
			empty[ 0 ].focus();
			return;
		}

		var code = normalCode( inputs[ 1 ].value );
		var taken = null;
		rows().some( function ( tr ) {
			var other = isRemoved( tr ) ? null : field( tr, 'code' );
			if ( other && normalCode( other.value ) === code ) {
				taken = tr;
				return true;
			}
			return false;
		} );
		if ( taken ) {
			setError( inputs[ 1 ], format( texts.codeTaken, code, rowName( taken ) ) );
			details.open = true;
			inputs[ 1 ].focus();
			return;
		}

		var template = document.getElementById( 'ww-languages-row-template' );
		var tr = document.importNode( template.content, true ).firstElementChild;
		var name = inputs[ 0 ].value.trim();
		var locale = inputs[ 2 ].value.trim();
		field( tr, 'name' ).value = name;
		field( tr, 'code' ).value = code;
		field( tr, 'locale' ).value = locale;
		enhanceRow( tr );
		showRow( tr, name, code, locale );
		tbody.appendChild( tr );
		renumber();
		setAddEnabled( false );
		var emptyState = overview.querySelector( '.ww-languages-empty' );
		if ( emptyState ) {
			emptyState.hidden = true;
		}
		closeAdd( false );
		var edit = tr.querySelector( '.ww-languages-edit' );
		if ( edit ) {
			edit.focus();
		}
		check();
	}

	// Een nieuwe rij weghalen: er is niets opgeslagen, dus de rij gaat er gewoon uit.
	function removeNewRow( tr ) {
		tr.remove();
		renumber();
		setAddEnabled( ! hasNewRow() );
		var emptyState = overview.querySelector( '.ww-languages-empty' );
		if ( emptyState && rows().length <= 1 ) {
			emptyState.hidden = false;
		}
		var add = root.querySelector( 'a.ww-languages-add' );
		if ( add ) {
			add.focus();
		}
		check();
	}

	function enhanceRow( tr ) {
		each( tr.querySelectorAll( '.ww-languages-edit, .ww-languages-qe__actions' ), function ( node ) {
			node.hidden = false;
		} );
	}

	/* De balk onderin. */

	function buildSavebar( form ) {
		var bar = element( 'div', 'ww-languages-savebar' );
		bar.hidden = true;
		var text = element( 'p', 'ww-languages-savebar__text' );
		var dot = element( 'span', 'ww-languages-dot' );
		dot.setAttribute( 'aria-hidden', 'true' );
		text.appendChild( dot );
		text.appendChild( document.createTextNode( texts.unsaved ) );
		var actions = element( 'p', 'ww-languages-savebar__actions' );
		var undo = button( 'button', texts.undo );
		var save = button( 'button button-primary', texts.save, 'submit' );
		actions.appendChild( undo );
		actions.appendChild( save );
		bar.appendChild( text );
		bar.appendChild( actions );
		form.appendChild( bar );

		// Ongedaan maken laadt de pagina opnieuw. Een gewone navigatie in plaats van reload(): na een geweigerde opslag is
		// de pagina een POST-antwoord (reload zou opnieuw versturen) en Firefox zet bij reload de ingevulde velden terug.
		undo.addEventListener( 'click', function () {
			submitting = true;
			window.removeEventListener( 'beforeunload', guard );
			window.location.assign( window.location.href.split( '#' )[ 0 ] );
		} );
		return bar;
	}

	/* Het venster bij wisselen van onderdeel. */

	function isSectionLink( link ) {
		var href = link.getAttribute( 'href' ) || '';
		return '#' !== href.charAt( 0 ) && /[?&]page=ww-languages(&|$)/.test( href );
	}

	function targetOf( link ) {
		try {
			return new URL( link.href, window.location.href ).searchParams.get( 'language' ) || '';
		} catch ( error ) {
			return '';
		}
	}

	function buildLeave() {
		var dialog = element( 'div', 'ww-languages-leave' );
		dialog.setAttribute( 'role', 'alertdialog' );
		dialog.setAttribute( 'aria-modal', 'true' );
		dialog.setAttribute( 'aria-labelledby', 'ww-languages-leave-title' );
		dialog.setAttribute( 'aria-describedby', 'ww-languages-leave-text' );
		dialog.hidden = true;
		var box = element( 'div', 'ww-languages-leave__box' );
		var title = element( 'h2', '', texts.leaveTitle );
		title.id = 'ww-languages-leave-title';
		// Eén formulier (Overzicht, Taal toevoegen) of meer vakken die elk apart opslaan (pagina van een taal).
		var text = element( 'p', '', tracked.length > 1 ? texts.leaveText : texts.leaveTextOverview );
		text.id = 'ww-languages-leave-text';
		var actions = element( 'p', 'ww-languages-leave__actions' );
		var stay = button( 'button', texts.stay );
		stay.setAttribute( 'data-ww-action', 'stay' );
		var discard = button( 'button', texts.discard );
		discard.setAttribute( 'data-ww-action', 'discard' );
		var saveGo = button( 'button button-primary', texts.saveGo );
		saveGo.setAttribute( 'data-ww-action', 'save-next' );
		actions.appendChild( stay );
		actions.appendChild( discard );
		actions.appendChild( saveGo );
		box.appendChild( title );
		box.appendChild( text );
		box.appendChild( actions );
		dialog.appendChild( box );
		root.appendChild( dialog );

		dialog.addEventListener( 'click', function ( event ) {
			var action = event.target.closest( 'button[data-ww-action]' );
			if ( ! action ) {
				return;
			}
			var name = action.getAttribute( 'data-ww-action' );
			if ( 'stay' === name ) {
				closeLeave();
			} else if ( 'discard' === name ) {
				var href = leaveLink.href;
				submitting = true;
				window.removeEventListener( 'beforeunload', guard );
				window.location.href = href;
			} else if ( 'save-next' === name ) {
				saveNext();
			}
		} );
		return dialog;
	}

	function openLeave( link ) {
		leave = leave || buildLeave();
		leaveLink = link;
		each( root.querySelectorAll( 'details.ww-languages-menu[open]' ), function ( menu ) {
			menu.open = false;
		} );
		leaveOpener = link.closest( 'details.ww-languages-menu' ) ? link.closest( 'details.ww-languages-menu' ).querySelector( 'summary' ) : link;
		leave.hidden = false;
		leave.querySelector( '[data-ww-action="save-next"]' ).focus();
	}

	function closeLeave() {
		leave.hidden = true;
		leaveLink = null;
		if ( leaveOpener ) {
			leaveOpener.focus();
		}
	}

	// Verstuurt het eerste gewijzigde formulier met het gekozen onderdeel als ww_next.
	function saveNext() {
		var entry = null;
		tracked.some( function ( item ) {
			if ( item.dirty ) {
				entry = item;
				return true;
			}
			return false;
		} );
		if ( ! entry ) {
			return;
		}
		if ( ! entry.form.checkValidity() ) {
			closeLeave();
			entry.form.reportValidity();
			return;
		}
		if ( entry.next ) {
			entry.next.value = targetOf( leaveLink );
		}
		leave.hidden = true;
		// requestSubmit gaat door de submit-handler van track(): die past een open rij van Snel bewerken toe en zet
		// submitting. form.submit() slaat die handler over.
		if ( entry.form.requestSubmit ) {
			entry.form.requestSubmit();
		} else {
			submitting = true;
			window.removeEventListener( 'beforeunload', guard );
			entry.form.submit();
		}
	}

	/* Kopiëren. */

	function copy( trigger ) {
		var text = trigger.getAttribute( 'data-copy' ) || '';
		var code = trigger.parentNode.querySelector( 'code' );
		function selectCode() {
			if ( ! code ) {
				return;
			}
			var range = document.createRange();
			range.selectNodeContents( code );
			var selection = window.getSelection();
			selection.removeAllRanges();
			selection.addRange( range );
		}
		function done() {
			trigger.textContent = texts.copied;
			window.setTimeout( function () {
				trigger.textContent = texts.copy;
			}, 1500 );
		}
		// Zonder HTTPS (een lokale .test-site) is er geen klembord-API: dan staat de tekst geselecteerd.
		if ( navigator.clipboard && navigator.clipboard.writeText ) {
			navigator.clipboard.writeText( text ).then( done, selectCode );
		} else {
			selectCode();
		}
	}

	/* Taal toevoegen zonder venster (&language=new): de keuzelijst vult de velden. */

	function enhanceAddPage( form ) {
		var wrap = form.querySelector( '.ww-languages-preset' );
		var preset = form.querySelector( '#ww-languages-preset' );
		if ( ! wrap || ! preset ) {
			return;
		}
		preset.addEventListener( 'change', function () {
			var option = preset.options[ preset.selectedIndex ];
			var name = form.querySelector( '#ww-languages-new-name' );
			if ( 'other' === preset.value ) {
				if ( name ) {
					name.focus();
				}
				return;
			}
			if ( '' === preset.value ) {
				return;
			}
			[ 'name', 'code', 'locale' ].forEach( function ( key ) {
				var input = form.querySelector( '#ww-languages-new-' + key );
				if ( input ) {
					input.value = option.getAttribute( 'data-' + key ) || '';
				}
			} );
			check();
		} );
		wrap.hidden = false;
	}

	/* Start. */

	each( root.querySelectorAll( 'form.ww-languages-form' ), function ( form ) {
		if ( form.querySelector( '.ww-languages-list' ) ) {
			overview = form;
			tbody = form.querySelector( '.ww-languages-list tbody' );
			track( form, 'overview' );
		} else if ( form.querySelector( '.ww-languages-add-box' ) ) {
			track( form, 'add' );
			enhanceAddPage( form );
		} else if ( form.hasAttribute( 'data-ww-box' ) ) {
			var entry = track( form, 'box' );
			var submit = form.querySelector( '.submit' );
			if ( submit ) {
				entry.note = element( 'span', 'ww-languages-unsaved', texts.unsavedBox );
				entry.note.hidden = true;
				submit.appendChild( entry.note );
			}
		}
	} );

	savebar = overview ? buildSavebar( overview ) : null;
	var canAdd = !! ( overview && 'content' in document.createElement( 'template' ) && document.getElementById( 'ww-languages-add-template' ) );

	if ( overview ) {
		overview.addEventListener( 'click', function ( event ) {
			var target = event.target.closest( 'button, a' );
			if ( ! target || ! overview.contains( target ) ) {
				return;
			}
			var tr = target.closest( 'tr.ww-languages-row' );
			if ( 'ww_move' === target.name && tr ) {
				event.preventDefault();
				move( target );
			} else if ( 'ww_remove' === target.name && tr ) {
				event.preventDefault();
				if ( 'new' === tr.getAttribute( 'data-index' ) ) {
					removeNewRow( tr );
				} else {
					markRemoving( tr, target );
				}
			} else if ( target.classList.contains( 'ww-languages-keep' ) ) {
				keepRow( target );
			} else if ( target.classList.contains( 'ww-languages-edit' ) && tr ) {
				if ( tr.classList.contains( 'is-editing' ) ) {
					cancelEdit( tr, true );
				} else {
					openEdit( tr );
				}
			} else if ( target.classList.contains( 'ww-languages-qe-cancel' ) && tr ) {
				cancelEdit( tr, true );
			} else if ( target.classList.contains( 'ww-languages-qe-apply' ) && tr ) {
				applyEdit( tr );
			} else if ( 'A' === target.tagName && tr && 0 === ( target.getAttribute( 'href' ) || '' ).indexOf( '#ww-languages-qe-' ) ) {
				// De naam van de standaardtaal linkt naar Snel bewerken.
				event.preventDefault();
				openEdit( tr );
			}
		} );

		// Na een geweigerde opslag: het vinkje Verwijderen uit is Toch houden, de doorhaling gaat mee.
		overview.addEventListener( 'change', function ( event ) {
			var box = event.target.closest( '.ww-languages-remove-check input[type="checkbox"]' );
			var tr = box ? box.closest( 'tr.ww-languages-row' ) : null;
			if ( tr ) {
				tr.classList.toggle( 'is-removed', box.checked );
				// De badge Wordt verwijderd van de server gaat mee; die van het script (is-removing) niet.
				each( tr.querySelectorAll( '.ww-languages-badge.is-removed:not(.ww-languages-removing)' ), function ( badge ) {
					badge.hidden = ! box.checked;
				} );
				setAddEnabled( ! hasNewRow() );
			}
		} );

		// Enter in Snel bewerken is Bijwerken, niet het hele formulier opslaan.
		overview.addEventListener( 'keydown', function ( event ) {
			if ( 'Enter' !== event.key || 'INPUT' !== event.target.tagName ) {
				return;
			}
			var tr = event.target.closest( 'tr.is-editing' );
			if ( tr && event.target.closest( '.ww-languages-qe' ) ) {
				event.preventDefault();
				applyEdit( tr );
			}
		} );

		if ( hasNewRow() ) {
			setAddEnabled( false );
		}
	}

	document.addEventListener( 'click', function ( event ) {
		var link = event.target.closest ? event.target.closest( 'a[href]' ) : null;
		if ( ! link || ! root.contains( link ) || event.defaultPrevented || 0 !== event.button || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey ) {
			return;
		}
		if ( canAdd && -1 !== Array.prototype.indexOf.call( addLinks(), link ) ) {
			event.preventDefault();
			if ( 'true' !== link.getAttribute( 'aria-disabled' ) ) {
				openAdd( link );
			}
			return;
		}
		if ( anyDirty() && isSectionLink( link ) ) {
			event.preventDefault();
			openLeave( link );
		}
	} );

	// Escape en Tab: eerst het venster bij wisselen, dan het venster Taal toevoegen, dan de rij van Snel bewerken.
	document.addEventListener( 'keydown', function ( event ) {
		if ( 'Escape' !== event.key && 'Tab' !== event.key ) {
			return;
		}
		var dialog = leave && ! leave.hidden ? leave : addModal;
		if ( dialog ) {
			if ( 'Escape' === event.key ) {
				event.preventDefault();
				event.stopPropagation();
				if ( dialog === leave ) {
					closeLeave();
				} else {
					closeAdd( true );
				}
			} else {
				trapTab( event, dialog );
			}
			return;
		}
		if ( 'Escape' === event.key && event.target.closest ) {
			var tr = event.target.closest( 'tr.is-editing' );
			if ( tr ) {
				event.preventDefault();
				cancelEdit( tr, true );
			}
		}
	}, true );

	each( root.querySelectorAll( '.ww-languages-copy' ), function ( trigger ) {
		trigger.addEventListener( 'click', function () {
			copy( trigger );
		} );
		trigger.hidden = false;
	} );

	// Terug uit de cache van de browser (bfcache): het versturen is niet gebeurd of voorbij. Een oud doel van Opslaan en
	// verder mag de volgende opslag niet sturen.
	window.addEventListener( 'pageshow', function ( event ) {
		if ( ! event.persisted ) {
			return;
		}
		submitting = false;
		tracked.forEach( function ( entry ) {
			if ( entry.next ) {
				entry.next.value = entry.nextValue;
			}
		} );
		check();
	} );

	// Pas aan het eind: gaat er eerder iets mis, dan blijven de velden van Snel bewerken open en werkt alles zonder script.
	each( rows(), enhanceRow );
	check();
	root.classList.add( 'ww-languages-js' );
}() );
