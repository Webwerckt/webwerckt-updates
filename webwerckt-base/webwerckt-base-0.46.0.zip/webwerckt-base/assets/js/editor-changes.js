// Wijzigingen van de visuele bewerker, voor het terugdraaien: welke velden zijn aangepast, in de volgorde van het
// paneel en met hun label en groep. Puur rekenwerk; bij het importeren raakt dit bestand de DOM niet aan.

/**
 * @param {Map<string, unknown>} changes Aangepaste velden, op veldnaam.
 * @param {Record<string, {label: string, group?: string, site?: boolean}>} fields Alle velden, in paneelvolgorde.
 * @returns {Array<{name: string, label: string, group: string, site: boolean}>}
 */
export function changedFields(changes, fields) {
	return Object.keys(fields)
		.filter((name) => changes.has(name))
		.map((name) => ({
			name,
			label: fields[name].label,
			group: fields[name].group || '',
			site: !!fields[name].site,
		}));
}

/**
 * Welke velden een versie anders maakt dan de bewerker nu heeft. Gelijkheid zoals same() in editor.js.
 *
 * @param {Record<string, {label: string, type: string, value: unknown, preview?: string}>} fields De velden van de bewerker.
 * @param {{fields: Record<string, {value: unknown, preview?: string}>, post_title: string}} version De versie van de REST-route.
 * @returns {Map<string, {value: unknown, preview?: string}>} Alleen de velden die verschillen, met hun waarde (en preview).
 */
export function versionChanges(fields, version) {
	const changes = new Map();
	const add = (name, value, preview) => {
		const current = fields[name];
		if (!current || current.type === 'pick' || sameValue(current.value, value)) {
			return;
		}
		changes.set(name, preview === undefined ? { value } : { value, preview });
	};

	Object.entries(version.fields || {}).forEach(([name, entry]) => add(name, entry.value, entry.preview));
	add('post_title', version.post_title);

	return changes;
}

// Zelfde vergelijking als same() in editor.js; daar kan dit bestand niet uit importeren (die raakt de DOM aan).
function sameValue(a, b) {
	return a === b || JSON.stringify(a) === JSON.stringify(b);
}
