// Menu's in de kop van het zijpaneel van de visuele bewerker: de pagina's onder de paginatitel en de talen naast de
// titel. Een menu-knop volgens het
// WAI-ARIA-patroon: role="menu" met menuitems, ↑↓ en Home/End verplaatsen de focus, Enter of spatie kiest, Escape
// sluit en zet de focus terug op de knop. Een klik erbuiten, in de pagina (het iframe) of een tweede klik op de knop
// sluit het ook. aria-expanded op de knop volgt het menu, niet het paneel.

// Afstand tot de rand van het venster en tot de knop, in pixels.
const MARGIN = 8;
const GAP = 4;

let count = 0;
// Er staat maar één menu tegelijk open.
const menus = new Set();

/**
 * @param {HTMLButtonElement} button
 * @param {HTMLElement} container  het [data-ww-editor-menu] na de knop
 * Een item kan een toelichting hebben (detail, bijvoorbeeld Concept), een grijze regel eronder (note) en een diepte
 * (depth, ingesprongen). Met align
 * 'start' staat het menu links uitgelijnd op de knop, anders rechts.
 *
 * @param {{ items: () => Array<{ id: string, label: string, detail?: string, note?: string, depth?: number, current?: boolean, separator?: boolean }>, onPick: (id: string) => void, align?: 'start' | 'end' }} options
 * @returns {{ open(): void, close(): void, isOpen(): boolean }}
 */
export function menuButton(button, container, options) {
	count += 1;
	button.id ||= `ww-editor-menu-button-${count}`;
	container.id ||= `ww-editor-menu-${count}`;
	container.classList.add('ww-editor__menu');
	container.setAttribute('role', 'menu');
	container.setAttribute('aria-labelledby', button.id);
	button.setAttribute('aria-controls', container.id);
	button.setAttribute('aria-expanded', 'false');

	const entries = () => [...container.querySelectorAll('[role="menuitem"]')];
	const isOpen = () => !container.hidden;

	const focusAt = (index) => {
		const all = entries();
		if (all.length > 0) {
			all[(index + all.length) % all.length].focus();
		}
	};

	// Rechts (of bij align 'start' links) uitgelijnd op de knop, en verschoven als het menu buiten het venster valt.
	const place = () => {
		const rect = button.getBoundingClientRect();
		const width = container.offsetWidth;
		const wanted = options.align === 'start' ? rect.left : rect.right - width;
		const left = Math.max(MARGIN, Math.min(wanted, window.innerWidth - width - MARGIN));
		container.style.left = `${left}px`;
		container.style.top = `${rect.bottom + GAP}px`;
		container.style.maxHeight = `${Math.max(120, window.innerHeight - rect.bottom - GAP - MARGIN)}px`;
	};

	const render = () => {
		container.replaceChildren(
			...options.items().flatMap((item) => {
				const entry = document.createElement('button');
				entry.type = 'button';
				entry.className = 'ww-editor__menu-item';
				entry.setAttribute('role', 'menuitem');
				entry.tabIndex = -1;
				entry.textContent = item.label;
				if (item.depth) {
					entry.style.setProperty('--ww-depth', String(item.depth));
					entry.dataset.wwDepth = '';
				}
				if (item.detail) {
					const detail = document.createElement('span');
					detail.className = 'ww-editor__menu-detail';
					detail.textContent = item.detail;
					entry.append(' ', detail);
				}
				if (item.note) {
					const note = document.createElement('span');
					note.className = 'ww-editor__menu-note';
					note.textContent = item.note;
					entry.append(note);
				}
				if (item.current) {
					entry.setAttribute('aria-current', 'true');
				}
				entry.addEventListener('click', () => pick(item.id));
				if (!item.separator) {
					return [entry];
				}
				const line = document.createElement('div');
				line.className = 'ww-editor__menu-separator';
				line.setAttribute('role', 'separator');
				return [line, entry];
			})
		);
	};

	// Een klik buiten het menu en de knop; de knop zelf wisselt via zijn eigen klik.
	const onOutside = (event) => {
		if (!container.contains(event.target) && !button.contains(event.target)) {
			close();
		}
	};
	// Een klik in de pagina komt niet bij dit document aan, maar haalt de focus uit dit venster.
	const onBlur = () => close();
	const onResize = () => place();

	function open(focusLast = false) {
		menus.forEach((menu) => menu !== api && menu.close());
		render();
		container.hidden = false;
		button.setAttribute('aria-expanded', 'true');
		place();
		document.addEventListener('pointerdown', onOutside, true);
		window.addEventListener('blur', onBlur);
		window.addEventListener('resize', onResize);
		const all = entries();
		const current = all.findIndex((entry) => entry.hasAttribute('aria-current'));
		focusAt(focusLast ? all.length - 1 : Math.max(0, current));
	}

	function close(restoreFocus = false) {
		if (!isOpen()) {
			return;
		}
		container.hidden = true;
		button.setAttribute('aria-expanded', 'false');
		document.removeEventListener('pointerdown', onOutside, true);
		window.removeEventListener('blur', onBlur);
		window.removeEventListener('resize', onResize);
		if (restoreFocus) {
			button.focus();
		}
	}

	// Eerst sluiten zonder de focus naar de knop te halen: wat het menu opent, zet de focus zelf.
	function pick(id) {
		close();
		options.onPick(id);
	}

	button.addEventListener('click', () => (isOpen() ? close() : open()));
	button.addEventListener('keydown', (event) => {
		if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
			event.preventDefault();
			open(event.key === 'ArrowUp');
		} else if (event.key === 'Escape' && isOpen()) {
			event.preventDefault();
			event.stopPropagation();
			close(true);
		}
	});

	container.addEventListener('keydown', (event) => {
		const all = entries();
		const index = all.indexOf(document.activeElement);
		const moves = { ArrowDown: index + 1, ArrowUp: index - 1, Home: 0, End: all.length - 1 };
		if (Object.hasOwn(moves, event.key)) {
			event.preventDefault();
			focusAt(moves[event.key]);
		} else if (event.key === 'Escape') {
			// Alleen het menu sluit, niet het paneel eronder (de keydown-listener van editor.js).
			event.preventDefault();
			event.stopPropagation();
			close(true);
		} else if (event.key === 'Tab') {
			close();
		}
	});

	const api = { open: () => open(), close: (restoreFocus = false) => close(restoreFocus), isOpen };
	menus.add(api);
	return api;
}
