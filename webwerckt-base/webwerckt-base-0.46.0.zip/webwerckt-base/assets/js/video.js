/**
 * Video-placeholder (beslissing 0037): een klik op de link van een placeholder uit inc/embeds.php laadt de speler
 * van YouTube (youtube-nocookie.com) of Vimeo (dnt=1). De klik geldt als toestemming voor die ene video; er wordt
 * niets onthouden. Zonder JavaScript blijft het een gewone link naar de video bij de dienst.
 */
( function () {
	'use strict';

	/**
	 * De speler-URL uit data-ww-video, alleen als hij via https van www.youtube-nocookie.com (/embed/) of
	 * player.vimeo.com (/video/) komt. Anders null: een tekstveld kan zelf een figure met data-ww-video bevatten.
	 */
	function playerUrl( src ) {
		var url;
		try {
			url = new URL( src, location.href );
		} catch ( e ) {
			return null;
		}
		if ( url.protocol !== 'https:' ) {
			return null;
		}
		if (
			( url.hostname === 'www.youtube-nocookie.com' && url.pathname.indexOf( '/embed/' ) === 0 ) ||
			( url.hostname === 'player.vimeo.com' && url.pathname.indexOf( '/video/' ) === 0 )
		) {
			return url.href;
		}
		return null;
	}

	document.addEventListener( 'click', function ( event ) {
		if ( event.defaultPrevented || event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey ) {
			return; // Nieuw tabblad of venster: laat de link gewoon openen.
		}
		var link = event.target instanceof Element ? event.target.closest( '.ww-video__link' ) : null;
		var figure = link ? link.closest( '.ww-video' ) : null;
		var src = figure ? figure.getAttribute( 'data-ww-video' ) : '';
		var url = src ? playerUrl( src ) : null;
		if ( ! url ) {
			return; // Geen of een onbekende speler-URL: de link opent gewoon.
		}
		event.preventDefault();

		var title = link.querySelector( '.ww-video__title' );
		var iframe = document.createElement( 'iframe' );
		iframe.src = url;
		iframe.title = title ? title.textContent.trim() : link.getAttribute( 'aria-label' ) || '';
		iframe.setAttribute( 'allow', 'autoplay; fullscreen; picture-in-picture' );
		iframe.setAttribute( 'allowfullscreen', '' );
		iframe.style.width = '100%';
		iframe.style.height = '100%';
		iframe.style.border = '0';
		figure.replaceChildren( iframe );
		iframe.focus();
	} );
}() );
