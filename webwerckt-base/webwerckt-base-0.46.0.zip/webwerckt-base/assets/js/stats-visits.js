// Statistieken, Paden: een bezoek openen in een venster in plaats van op zijn eigen pagina.
// Elke regel van Bezoeken heeft een link a.ww-stats-visit-link[data-ww-visit] naar het bezoek; het detail staat al in
// <template id="ww-stats-visit-{i}" data-title>. Zonder dit script (of zonder <dialog>) opent de link gewoon de pagina.

(function () {
	'use strict';

	const dialog = document.getElementById('ww-stats-visit-dialog');
	if (!dialog || typeof dialog.showModal !== 'function') {
		return;
	}

	const title = dialog.querySelector('#ww-stats-visit-dialog-title');
	const body = dialog.querySelector('[data-ww-body]');
	const pos = dialog.querySelector('[data-ww-pos]');
	const prev = dialog.querySelector('[data-ww-prev]');
	const next = dialog.querySelector('[data-ww-next]');
	const links = Array.prototype.slice.call(document.querySelectorAll('a.ww-stats-visit-link[data-ww-visit]'));
	const format = dialog.dataset.posFormat || '%1$s / %2$s';
	let current = -1;
	if (pos) {
		pos.setAttribute('aria-live', 'polite'); // "2 van 50" wordt voorgelezen bij Vorig en Volgend.
	}
	let opener = null;

	function linkFor(index) {
		return links.find(function (link) {
			return Number(link.dataset.wwVisit) === index;
		});
	}

	function open(index) {
		const template = document.getElementById('ww-stats-visit-' + index);
		if (!template) {
			return;
		}
		current = index;
		title.textContent = template.dataset.title || '';
		body.replaceChildren(template.content.cloneNode(true));
		body.scrollTop = 0;
		if (pos) {
			pos.textContent = format.replace('%1$s', String(index + 1)).replace('%2$s', String(links.length));
		}
		const focused = document.activeElement;
		if (prev) {
			prev.disabled = !document.getElementById('ww-stats-visit-' + (index - 1));
		}
		if (next) {
			next.disabled = !document.getElementById('ww-stats-visit-' + (index + 1));
		}
		// Wordt de knop met de focus uitgeschakeld (Volgend bij het laatste bezoek), dan zou de focus naar <body>
		// vallen: zet hem op de andere knop, of op Sluiten.
		if (focused && focused.disabled && (focused === prev || focused === next)) {
			const other = focused === next ? prev : next;
			(other && !other.disabled ? other : dialog.querySelector('[data-ww-close]')).focus();
		}
		if (!dialog.open) {
			opener = linkFor(index) || null;
			dialog.showModal();
		}
	}

	document.addEventListener('click', function (event) {
		if (event.defaultPrevented || event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) {
			return; // Middelklik of met een toets: de link opent zoals altijd (nieuw tabblad of venster).
		}
		const target = event.target instanceof Element ? event.target : null;
		if (!target) {
			return;
		}
		let link = target.closest('a.ww-stats-visit-link[data-ww-visit]');
		if (!link) {
			const row = target.closest('tr.is-clickable');
			// Een andere link in de regel (zoals een pictogram met een link) doet zijn eigen werk.
			if (!row || target.closest('a, button, input, select, textarea, summary')) {
				return;
			}
			link = row.querySelector('a.ww-stats-visit-link[data-ww-visit]');
		}
		if (!link) {
			return;
		}
		event.preventDefault();
		open(Number(link.dataset.wwVisit));
	});

	if (prev) {
		prev.addEventListener('click', function () {
			open(current - 1);
		});
	}
	if (next) {
		next.addEventListener('click', function () {
			open(current + 1);
		});
	}
	dialog.querySelectorAll('[data-ww-close]').forEach(function (button) {
		button.addEventListener('click', function () {
			dialog.close();
		});
	});

	// Een klik op de achtergrond: het doel is dan de dialog zelf, niet iets erin. Esc regelt de browser.
	dialog.addEventListener('click', function (event) {
		if (event.target === dialog) {
			dialog.close();
		}
	});

	dialog.addEventListener('close', function () {
		body.replaceChildren();
		// De focus terug naar de regel van het laatst getoonde bezoek (na Vorig/Volgend is dat een andere regel).
		const back = linkFor(current) || opener;
		current = -1;
		if (back && document.contains(back)) {
			back.focus();
		}
	});

	// Alleen met dit script is de hele regel klikbaar.
	links.forEach(function (link) {
		const row = link.closest('tr');
		if (row) {
			row.classList.add('is-clickable');
		}
	});
})();
