/**
 * Het scherm Site-instellingen (inc/settings-admin.php): wijzigingen bewaken, het venster bij wisselen van onderdeel,
 * openingstijden controleren, tellers en zoekvoorbeeld, de code-editor en ongedaan maken. De invoer van lijsten,
 * afbeeldingen en opgemaakte tekst staat in assets/js/field-inputs.js (wwFieldInputs), gedeeld met het bewerkscherm.
 * Alleen gemak: zonder dit script slaat het formulier ook op.
 */
( function () {
	'use strict';

	var form = document.getElementById( 'ww-settings-form' );
	if ( ! form ) {
		return;
	}
	// Teksten en instellingen uit PHP (_ww_settings_admin_assets()), al vertaald.
	var settings = window.wwSettings || {};
	var texts = settings.texts || {};

	// Vult %s, %d, %1$s enzovoort in, zoals sprintf in PHP.
	function format( text ) {
		var values = Array.prototype.slice.call( arguments, 1 );
		var next = 0;
		return String( text || '' ).replace( /%(?:(\d)\$)?[sd]/g, function ( match, position ) {
			var value = values[ position ? position - 1 : next++ ];
			return undefined === value || null === value ? '' : String( value );
		} );
	}

	var savebar = form.querySelector( '.ww-settings-savebar' );
	var dialog = form.querySelector( '.ww-settings-dialog' );
	var next = form.querySelector( 'input[name="ww_next"]' );
	var dirty = false;
	var submitting = false;
	var resetting = false;
	var editors = [];
	var pending = null;

	/* Wijzigingen. */

	function guard( event ) {
		if ( ! dirty || submitting ) {
			return;
		}
		event.preventDefault();
		event.returnValue = '';
	}

	function setDirty( value ) {
		dirty = value;
		if ( savebar ) {
			savebar.hidden = ! value;
		}
		if ( value ) {
			window.addEventListener( 'beforeunload', guard );
		} else {
			window.removeEventListener( 'beforeunload', guard );
		}
	}

	function markDirty() {
		if ( ! resetting && ! dirty ) {
			setDirty( true );
		}
	}

	function onFieldEvent( event ) {
		if ( event.target.closest && event.target.closest( '.ww-settings-picks__select, .ww-settings-dialog' ) ) {
			return;
		}
		markDirty();
	}
	form.addEventListener( 'input', onFieldEvent );
	form.addEventListener( 'change', onFieldEvent );

	form.addEventListener( 'submit', function () {
		submitting = true;
		window.removeEventListener( 'beforeunload', guard );
	} );

	/* Openingstijden, gelijk aan _ww_hours_parse(). */

	var timePattern = /^\s*(\d{1,2})[:.](\d{2})\s*[-–—]\s*(\d{1,2})[:.](\d{2})\s*$/;

	function pad( number ) {
		return ( number < 10 ? '0' : '' ) + number;
	}

	function clock( minutes ) {
		return pad( Math.floor( minutes / 60 ) ) + ':' + pad( minutes % 60 );
	}

	function parseHours( value ) {
		value = value.trim();
		if ( '' === value || -1 !== [ 'gesloten', 'closed', '-' ].indexOf( value.toLowerCase() ) ) {
			return [];
		}
		var ranges = [];
		var parts = value.split( ',' );
		for ( var i = 0; i < parts.length; i++ ) {
			var match = timePattern.exec( parts[ i ] );
			if ( ! match ) {
				return null;
			}
			var from = parseInt( match[ 1 ], 10 ) * 60 + parseInt( match[ 2 ], 10 );
			var to = parseInt( match[ 3 ], 10 ) * 60 + parseInt( match[ 4 ], 10 );
			to = 0 === to ? 24 * 60 : to;
			var last = ranges.length ? ranges[ ranges.length - 1 ] : null;
			if ( parseInt( match[ 2 ], 10 ) > 59 || parseInt( match[ 4 ], 10 ) > 59 || to > 24 * 60 || to <= from || ( last && from < last.to ) ) {
				return null;
			}
			ranges.push( { from: from, to: to } );
		}
		return ranges;
	}

	function updateHours( input ) {
		var status = input.closest( 'tr' ).querySelector( '.ww-settings-hours-status' );
		if ( ! status ) {
			return;
		}
		var ranges = parseHours( input.value );
		var text;
		var state = '';
		if ( null === ranges ) {
			text = texts.hoursBad;
			state = ' bad';
			input.setAttribute( 'aria-invalid', 'true' );
		} else {
			input.removeAttribute( 'aria-invalid' );
			if ( ranges.length ) {
				text = format(
					texts.hoursOpen,
					ranges.map( function ( range ) {
						return clock( range.from ) + '–' + clock( range.to );
					} ).join( ' ' + texts.and + ' ' )
				);
				state = ' ok';
			} else {
				text = texts.closed;
			}
		}
		status.className = 'ww-settings-hours-status' + state;
		status.textContent = text;
	}

	function updateAllHours() {
		Array.prototype.forEach.call( form.querySelectorAll( '.ww-settings-hours' ), updateHours );
	}

	form.addEventListener( 'input', function ( event ) {
		if ( event.target.classList && event.target.classList.contains( 'ww-settings-hours' ) ) {
			updateHours( event.target );
		}
	} );

	Array.prototype.forEach.call( form.querySelectorAll( '.ww-settings-hours-copy' ), function ( button ) {
		button.hidden = false;
		button.addEventListener( 'click', function () {
			var box = button.closest( '.ww-settings-box' );
			var inputs = box ? box.querySelectorAll( '.ww-settings-hours' ) : [];
			for ( var i = 1; i <= 4 && i < inputs.length; i++ ) {
				inputs[ i ].value = inputs[ 0 ].value;
				inputs[ i ].dispatchEvent( new Event( 'input', { bubbles: true } ) );
			}
		} );
	} );

	/* Tellers en zoekvoorbeeld. */

	var limits = { title: 60, description: 155 };

	function length( text ) {
		return Array.from( text ).length;
	}

	function updateCounters() {
		Array.prototype.forEach.call( form.querySelectorAll( '.ww-settings-counter' ), function ( counter ) {
			var input = document.getElementById( counter.getAttribute( 'data-for' ) );
			var max = limits[ counter.getAttribute( 'data-kind' ) ];
			if ( ! input || ! max ) {
				return;
			}
			var count = length( input.value );
			var text = format( texts.counter, count, max );
			if ( count > max ) {
				text += texts.tooLong;
			}
			counter.textContent = text;
			counter.style.color = count > max ? '#b32d2e' : '';
		} );
	}

	function updateSerp() {
		var serp = form.querySelector( '.ww-settings-serp' );
		var title = document.getElementById( 'ww-field-seo_home_title' );
		var desc = document.getElementById( 'ww-field-seo_home_description' );
		if ( ! serp ) {
			return;
		}
		var titleText = title ? title.value.trim() : '';
		var descText = desc ? desc.value.trim() : '';
		if ( length( descText ) > limits.description ) {
			descText = Array.from( descText ).slice( 0, limits.description ).join( '' ).trim() + ' …';
		}
		var titleEl = serp.querySelector( '.ww-settings-serp__title' );
		var descEl = serp.querySelector( '.ww-settings-serp__desc' );
		if ( titleEl ) {
			titleEl.textContent = '' !== titleText ? titleText : serp.getAttribute( 'data-fallback' ) || '';
		}
		if ( descEl ) {
			descEl.textContent = descText;
		}
	}

	form.addEventListener( 'input', function ( event ) {
		if ( event.target.id === 'ww-field-seo_home_title' || event.target.id === 'ww-field-seo_home_description' ) {
			updateCounters();
			updateSerp();
		}
	} );

	/* Lijsten met pagina's, afbeeldingen en opgemaakte tekst: assets/js/field-inputs.js. */

	var fieldInputs = window.wwFieldInputs ? window.wwFieldInputs.init( form, { texts: window.wwFieldInputsTexts || {}, onChange: markDirty } ) : null;

	/* Code-editor. */

	var codeSettings = settings.code;
	if ( window.wp && window.wp.codeEditor && codeSettings ) {
		Array.prototype.forEach.call( form.querySelectorAll( '.ww-settings-code' ), function ( textarea ) {
			var editor = window.wp.codeEditor.initialize( textarea, codeSettings );
			if ( ! editor || ! editor.codemirror ) {
				return;
			}
			editor.codemirror.on( 'change', function ( cm ) {
				cm.save();
				markDirty();
			} );
			editors.push( { codemirror: editor.codemirror, textarea: textarea, initial: textarea.defaultValue } );
		} );
	}

	/* Ongedaan maken. */

	var snapshots = [];
	Array.prototype.forEach.call( form.querySelectorAll( '.ww-settings-pickfield, .ww-settings-image, .ww-field-images' ), function ( node ) {
		snapshots.push( { node: node, html: node.innerHTML } );
	} );

	function undo() {
		resetting = true;
		form.reset();
		snapshots.forEach( function ( snapshot ) {
			snapshot.node.innerHTML = snapshot.html;
		} );
		editors.forEach( function ( editor ) {
			editor.codemirror.setValue( editor.initial );
			editor.codemirror.save();
		} );
		if ( fieldInputs ) {
			fieldInputs.refresh();
		}
		resetting = false;
		updateAllHours();
		updateCounters();
		updateSerp();
		setDirty( false );
		// De balk met de knop Ongedaan maken verdwijnt: de focus gaat naar de opslaanknop onder het formulier.
		var submit = form.querySelector( '.submit button[type="submit"]' );
		if ( submit ) {
			submit.focus();
		}
	}

	/* Venster bij wisselen van onderdeel. */

	var opener = null;

	function dialogButtons() {
		return Array.prototype.slice.call( dialog.querySelectorAll( 'button' ) );
	}

	function openDialog( link ) {
		opener = link;
		pending = link;
		// De mobiele uitklapper Onderdeel staat buiten het formulier en zou open achter het venster blijven staan.
		Array.prototype.forEach.call( document.querySelectorAll( 'details.ww-settings-menu[open]' ), function ( menu ) {
			menu.open = false;
		} );
		if ( opener.closest && opener.closest( 'details.ww-settings-menu' ) ) {
			opener = opener.closest( 'details.ww-settings-menu' ).querySelector( 'summary' );
		}
		dialog.hidden = false;
		dialog.querySelector( '[data-ww-action="save-next"]' ).focus();
	}

	function closeDialog() {
		dialog.hidden = true;
		pending = null;
		next.value = '';
		if ( opener ) {
			opener.focus();
		}
	}

	function saveNext() {
		if ( ! form.checkValidity() ) {
			closeDialog();
			form.reportValidity();
			return;
		}
		next.value = pending.getAttribute( 'data-ww-section' );
		submitting = true;
		window.removeEventListener( 'beforeunload', guard );
		dialog.hidden = true;
		if ( form.requestSubmit ) {
			form.requestSubmit();
		} else {
			form.submit();
		}
	}

	document.addEventListener( 'click', function ( event ) {
		var link = event.target.closest ? event.target.closest( 'a[data-ww-section]' ) : null;
		if ( ! link || ! dirty || ! dialog || event.defaultPrevented || event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey ) {
			return;
		}
		event.preventDefault();
		openDialog( link );
	} );

	if ( dialog ) {
		dialog.addEventListener( 'click', function ( event ) {
			var button = event.target.closest( 'button[data-ww-action]' );
			if ( ! button ) {
				return;
			}
			var action = button.getAttribute( 'data-ww-action' );
			if ( 'stay' === action ) {
				closeDialog();
			} else if ( 'discard' === action ) {
				var href = pending.href;
				setDirty( false );
				window.location.href = href;
			} else if ( 'save-next' === action ) {
				saveNext();
			}
		} );

		document.addEventListener( 'keydown', function ( event ) {
			if ( dialog.hidden ) {
				return;
			}
			if ( 'Escape' === event.key ) {
				event.preventDefault();
				event.stopPropagation();
				closeDialog();
			} else if ( 'Tab' === event.key ) {
				var buttons = dialogButtons();
				var first = buttons[ 0 ];
				var last = buttons[ buttons.length - 1 ];
				if ( ! dialog.contains( document.activeElement ) ) {
					event.preventDefault();
					first.focus();
				} else if ( event.shiftKey && document.activeElement === first ) {
					event.preventDefault();
					last.focus();
				} else if ( ! event.shiftKey && document.activeElement === last ) {
					event.preventDefault();
					first.focus();
				}
			}
		}, true );
	}

	if ( savebar ) {
		var undoButton = savebar.querySelector( '[data-ww-action="undo"]' );
		if ( undoButton ) {
			undoButton.addEventListener( 'click', undo );
		}
	}

	/* Sprongadres: #ww-field-{veld}. */

	function jump() {
		var hash = window.location.hash;
		if ( 0 !== hash.indexOf( '#ww-field-' ) ) {
			return;
		}
		var id;
		try {
			id = decodeURIComponent( hash.slice( 1 ) );
		} catch ( error ) {
			return; // Een kapot adres, zoals #ww-field-%E0: niets om naartoe te springen.
		}
		var target = document.getElementById( id );
		if ( target ) {
			target.scrollIntoView( { block: 'center' } );
			target.focus();
		}
	}
	window.addEventListener( 'hashchange', jump );

	// Terug naar deze pagina uit de cache van de browser (bfcache): het versturen is niet gebeurd of voorbij. De bewaking
	// komt terug als er nog wijzigingen zijn, en een oud doel van Opslaan en verder mag de volgende opslag niet sturen.
	window.addEventListener( 'pageshow', function ( event ) {
		if ( ! event.persisted ) {
			return;
		}
		submitting = false;
		if ( next ) {
			next.value = '';
		}
		setDirty( dirty );
	} );

	updateAllHours();
	updateCounters();
	updateSerp();
	// Na een fout bij opslaan staan de ingezonden, niet-opgeslagen waarden in het formulier.
	if ( '1' === form.getAttribute( 'data-ww-dirty' ) ) {
		setDirty( true );
	}
	jump();
}() );
