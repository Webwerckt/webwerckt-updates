/**
 * Mail › Instellingen: alleen gemak. Zonder dit script werkt het formulier ook (alle velden staan er, sla op om te
 * wisselen). Geen gegevens in het script; het leest alleen de HTML.
 */
( function () {
	'use strict';

	// Toont de velden van de gekozen aansluiting.
	var radios = document.querySelectorAll( 'input[name="ww_mail_transport"]' );
	var groups = document.querySelectorAll( '[data-ww-mail-transport]' );
	function showTransport() {
		var chosen = null;
		for ( var i = 0; i < radios.length; i++ ) {
			if ( radios[ i ].checked ) {
				chosen = radios[ i ].value;
			}
		}
		if ( null === chosen ) {
			return;
		}
		for ( var j = 0; j < groups.length; j++ ) {
			groups[ j ].hidden = groups[ j ].getAttribute( 'data-ww-mail-transport' ) !== chosen;
		}
	}
	for ( var r = 0; r < radios.length; r++ ) {
		radios[ r ].addEventListener( 'change', showTransport );
	}
	showTransport();

	// Een ingesteld geheim: veld en vinkje pas na Vervangen.
	var secrets = document.querySelectorAll( '[data-ww-mail-secret]' );
	Array.prototype.forEach.call( secrets, function ( box ) {
		var button = box.querySelector( '.ww-mail-secret__replace' );
		var input = box.querySelector( '.ww-mail-secret__input' );
		var remove = box.querySelector( '.ww-mail-secret__remove' );
		if ( ! button || ! input ) {
			return;
		}
		input.hidden = true;
		if ( remove ) {
			remove.hidden = true;
		}
		button.hidden = false;
		button.addEventListener( 'click', function () {
			input.hidden = false;
			if ( remove ) {
				remove.hidden = false;
			}
			button.hidden = true;
			input.focus();
		} );
	} );

	// Het voorbeeld van de afzender volgt de velden.
	var name = document.getElementById( 'ww_mail_from_name' );
	var address = document.getElementById( 'ww_mail_from' );
	var previewName = document.getElementById( 'ww-mail-preview-name' );
	var previewAddress = document.getElementById( 'ww-mail-preview-address' );
	var preview = previewAddress ? previewAddress.parentNode : null;
	function updatePreview() {
		if ( name && previewName ) {
			previewName.textContent = name.value.trim() || name.placeholder;
		}
		if ( address && previewAddress && preview ) {
			var value = address.value.trim();
			previewAddress.textContent = value ? '<' + value + '>' : preview.getAttribute( 'data-default' ) || '';
		}
	}
	if ( name ) {
		name.addEventListener( 'input', updatePreview );
	}
	if ( address ) {
		address.addEventListener( 'input', updatePreview );
	}
}() );
