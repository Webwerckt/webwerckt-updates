/**
 * De knoppen om op te slaan in het zijpaneel en de balk van het bewerkscherm (inc/forms-panel.php). Ze staan buiten
 * #submitpost, dus post.js van WordPress kent ze niet. Een klik gaat daarom naar de verborgen knop van WordPress die
 * data-ww-submit noemt (Bijwerken → #publish met name="save"; Concept opslaan → #save-post; Publiceren → #publish).
 * Zo doet de afhandeling van post.js mee: geen "pagina verlaten?", de bewerkingsvergrendeling blijft, autosave pauzeert
 * en de knoppen gaan uit tegen dubbel versturen. Zonder dit script, of zonder die knop, versturen de knoppen #post zelf
 * via form="post".
 */
( function () {
	'use strict';

	var selector = 'button[data-ww-submit]';

	document.addEventListener( 'click', function ( event ) {
		var button = event.target.closest( selector );
		if ( ! button ) {
			return;
		}
		var target = document.querySelector( button.getAttribute( 'data-ww-submit' ) );
		if ( ! target ) {
			return; // Geen knop van WordPress (bijvoorbeeld ter beoordeling zonder publicatierecht): gewoon versturen.
		}
		event.preventDefault();
		if ( target.disabled || target.classList.contains( 'disabled' ) ) {
			return; // WordPress houdt opslaan tegen, bijvoorbeeld tijdens een autosave.
		}
		target.click();
		// post.js zet 'disabled' op zijn knoppen zodra #post echt verstuurd wordt; dan gaan deze knoppen ook uit.
		if ( target.classList.contains( 'disabled' ) ) {
			document.querySelectorAll( selector ).forEach( function ( other ) {
				other.disabled = true;
			} );
		}
	} );
}() );
