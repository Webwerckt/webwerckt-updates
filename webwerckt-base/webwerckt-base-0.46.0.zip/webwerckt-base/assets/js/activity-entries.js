// Activiteitenlog: de gewijzigde velden van een regel openen in een venster in plaats van op een eigen pagina.
// Elke regel heeft een link a.ww-activity-entry-link[data-ww-entry] naar het detail (&entry={id}); het detail staat al
// in <template id="ww-activity-entry-{i}" data-title>. Zonder dit script (of zonder <dialog>) opent de link gewoon de
// pagina met het detail.

(function () {
	'use strict';

	const dialog = document.getElementById('ww-activity-entry-dialog');
	if (!dialog || typeof dialog.showModal !== 'function') {
		return;
	}

	const title = dialog.querySelector('#ww-activity-entry-dialog-title');
	const body = dialog.querySelector('[data-ww-body]');
	const pos = dialog.querySelector('[data-ww-pos]');
	const prev = dialog.querySelector('[data-ww-prev]');
	const next = dialog.querySelector('[data-ww-next]');
	const links = Array.prototype.slice.call(document.querySelectorAll('a.ww-activity-entry-link[data-ww-entry]'));
	const format = dialog.dataset.posFormat || '%1$s / %2$s';
	let current = -1;
	if (pos) {
		pos.setAttribute('aria-live', 'polite'); // "2 van 50" wordt voorgelezen bij Nieuwer en Ouder.
	}
	let opener = null;

	// Elke regel heeft twee links: de samenvatting in Gewijzigde velden (desktop) en de regel onder de titel (mobiel).
	// De zichtbare gaat voor.
	const total = document.querySelectorAll('tr[data-ww-entry]').length || links.length;

	function linkFor(index) {
		const own = links.filter(function (link) {
			return Number(link.dataset.wwEntry) === index;
		});
		return own.find(function (link) {
			return link.getClientRects().length > 0;
		}) || own[0];
	}

	function rowFor(index) {
		return document.querySelector('tr[data-ww-entry="' + index + '"]');
	}

	// Het zoekvak boven de velden (bij meer dan 8): verbergt de velden die niet passen, en daarna de lege groepen.
	function bindFieldFilter() {
		const input = body.querySelector('input[data-ww-field-filter]');
		if (!input) {
			return;
		}
		input.hidden = false;
		input.addEventListener('input', function () {
			const query = input.value.trim().toLowerCase();
			body.querySelectorAll('li[data-field]').forEach(function (item) {
				item.hidden = query !== '' && (item.dataset.field || '').indexOf(query) === -1;
			});
			body.querySelectorAll('.ww-activity-field-group').forEach(function (group) {
				group.hidden = !group.querySelector('li[data-field]:not([hidden])');
			});
		});
	}

	function markOpen(index) {
		document.querySelectorAll('tr.is-open[data-ww-entry]').forEach(function (row) {
			row.classList.remove('is-open');
		});
		const row = index >= 0 ? rowFor(index) : null;
		if (row) {
			row.classList.add('is-open');
		}
	}

	function open(index) {
		const template = document.getElementById('ww-activity-entry-' + index);
		if (!template) {
			return;
		}
		current = index;
		title.textContent = template.dataset.title || '';
		body.replaceChildren(template.content.cloneNode(true));
		body.scrollTop = 0;
		bindFieldFilter();
		markOpen(index);
		if (pos) {
			pos.textContent = format.replace('%1$s', String(index + 1)).replace('%2$s', String(total));
		}
		const focused = document.activeElement;
		if (prev) {
			prev.disabled = !document.getElementById('ww-activity-entry-' + (index - 1));
		}
		if (next) {
			next.disabled = !document.getElementById('ww-activity-entry-' + (index + 1));
		}
		// Wordt de knop met de focus uitgeschakeld (Ouder bij de laatste regel), dan zou de focus naar <body> vallen:
		// zet hem op de andere knop, of op Sluiten.
		if (focused && focused.disabled && (focused === prev || focused === next)) {
			const other = focused === next ? prev : next;
			(other && !other.disabled ? other : dialog.querySelector('[data-ww-close]')).focus();
		}
		if (!dialog.open) {
			opener = linkFor(index) || rowFor(index);
			dialog.showModal();
		}
	}

	// Zet de focus terug op de link van de regel, of op de regel zelf als de link niet zichtbaar is (op mobiel staat
	// alleen de kolom Wat).
	function focusBack(index) {
		const link = linkFor(index);
		if (link && document.contains(link) && link.getClientRects().length > 0) {
			link.focus();
			return;
		}
		const row = rowFor(index);
		if (row) {
			if (!row.hasAttribute('tabindex')) {
				row.setAttribute('tabindex', '-1');
			}
			row.focus();
			return;
		}
		if (opener && document.contains(opener)) {
			opener.focus();
		}
	}

	document.addEventListener('click', function (event) {
		if (event.defaultPrevented || event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) {
			return; // Middelklik of met een toets: de link opent zoals altijd (nieuw tabblad of venster).
		}
		const target = event.target instanceof Element ? event.target : null;
		if (!target) {
			return;
		}
		let index = -1;
		const link = target.closest('a.ww-activity-entry-link[data-ww-entry]');
		if (link) {
			index = Number(link.dataset.wwEntry);
		} else {
			const row = target.closest('tr[data-ww-entry]');
			// Een andere link in de regel (de titel, de naam) doet zijn eigen werk.
			if (!row || target.closest('a, button, input, select, textarea, summary, label')) {
				return;
			}
			index = Number(row.dataset.wwEntry);
		}
		if (!document.getElementById('ww-activity-entry-' + index)) {
			return;
		}
		event.preventDefault();
		open(index);
	});

	if (prev) {
		prev.addEventListener('click', function () {
			open(current - 1);
		});
	}
	if (next) {
		next.addEventListener('click', function () {
			open(current + 1);
		});
	}
	dialog.querySelectorAll('[data-ww-close]').forEach(function (button) {
		button.addEventListener('click', function () {
			dialog.close();
		});
	});

	// Een klik op de achtergrond: het doel is dan de dialog zelf, niet iets erin. Esc regelt de browser.
	dialog.addEventListener('click', function (event) {
		if (event.target === dialog) {
			dialog.close();
		}
	});

	dialog.addEventListener('close', function () {
		body.replaceChildren();
		markOpen(-1);
		// De focus terug naar de regel die het laatst open was (na Nieuwer/Ouder is dat een andere regel).
		const index = current;
		current = -1;
		focusBack(index);
	});

	// Alleen met dit script is de hele regel klikbaar.
	document.querySelectorAll('tr[data-ww-entry]').forEach(function (row) {
		row.classList.add('is-clickable');
	});
})();
