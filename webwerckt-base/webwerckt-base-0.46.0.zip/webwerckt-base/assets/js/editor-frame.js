// Visueel bewerken, in de pagina in het iframe (ADR 0019): maakt de elementen met data-ww-edit aanklikbaar, meldt
// een klik aan het zijpaneel (editor.js) en toont wijzigingen direct. Het zijpaneel stuurt eerst de velden van de
// pagina; een markering voor een onbekend veld blijft gewoon tekst. Secties van ww_section() staan tussen twee
// HTML-commentaren; bij hover krijgt een sectie een knop die zijn schakelaar en overige velden opent. Het gekozen
// element houdt zijn label, met dezelfde titel en kleur als de kop van het zijpaneel. Kaarten van een relatie of
// automatische lijst (ww_card()) staan ook tussen commentaren, met het nummer van hun lijst; bij hover krijgt de
// hele lijst een amber kader, en een klik opent de lijst in het zijpaneel. Een veld uit de Site-instellingen
// (ww_setting_attrs()) en een sectie daaruit zijn groen. Ctrl+K in de pagina opent het zoekvenster van de bewerker
// (SEARCH); een resultaat daaruit komt terug als REVEAL.

import { MESSAGE } from 'ww-editor-protocol';

const config = JSON.parse(document.getElementById('ww-editor-frame-data').textContent);
const EMPTY_IMAGE = 'data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%2F%3E';
// Gewone links: http(s), mailto, tel, een pad, een anker of leeg. Geen javascript: of data:.
const SAFE_URL = /^(https?:|mailto:|tel:|\/|#|$)/i;
// Wat de WYSIWYG-editor maakt, met de attributen per element. Elk element mag class en style hebben.
const ALLOWED_HTML = {
	p: [],
	h2: [],
	h3: [],
	h4: [],
	strong: [],
	b: [],
	em: [],
	i: [],
	del: [],
	span: [],
	br: [],
	blockquote: [],
	ul: [],
	ol: [],
	li: [],
	a: ['href', 'target', 'rel'],
	img: ['src', 'alt', 'width', 'height'],
};
const URL_ATTRS = ['href', 'src'];
// Deze elementen vallen met hun inhoud weg; een ander onbekend element laat zijn inhoud staan.
const DROPPED = ['script', 'style', 'template', 'iframe', 'object', 'embed', 'noscript'];
// <!--ww-section:{naam}:{bron}--> ... <!--/ww-section:{naam}-->, uit ww_section().
const SECTION_START = /^ww-section:([a-z0-9_-]+):(page|settings)$/;
// <!--ww-card:{nummer}--> ... <!--/ww-card:{nummer}-->, uit ww_card(); het nummer verwijst naar config.lists.
const CARD_START = /^ww-card:(\d+)$/;
// Eén id per geladen document, in elke READY: zo herkent het zijpaneel een herhaling van dezelfde pagina, en een
// nieuwe pagina (ook na opslaan) aan een andere id, ook als de markeringen gelijk zijn.
const LOAD_ID = globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random()}`;

let fields = {};
// Sectienaam => wat het zijpaneel erover meldt: label, of hij te bewerken is, of hij uit staat, of hij in de
// Site-instellingen staat. Een sectie die het paneel niet noemt, krijgt geen knop.
let sectionInfo = {};
let strings = {};
// Nummer van een lijst => wat het zijpaneel erover meldt: label en tekst ('3 gekoppeld', 'automatisch'). Een lijst
// die het paneel niet noemt, is niet aan te klikken.
let listInfo = {};
// De schaal van het voorbeeld (setScale()); labels groeien in de pagina met 1 / schaal.
let scale = 1;
// Waar FIELDS de pagina heen scrolde terwijl die nog laadde; bij load nog een keer, want een foto zonder afmetingen kan
// de pagina tot dan te kort maken. Vervalt zodra de gebruiker zelf scrolt.
let pendingScroll = null;
const badge = document.createElement('ww-edit-badge');
badge.hidden = true;
const selectedBadge = document.createElement('ww-edit-badge');
selectedBadge.hidden = true;
const sectionBadge = document.createElement('ww-section-badge');
sectionBadge.hidden = true;
const selectFrame = document.createElement('ww-select-frame');
selectFrame.hidden = true;
const hoverFrame = document.createElement('ww-hover-frame');
hoverFrame.hidden = true;
let hoveredNode = null;
const listHover = overlay();
const listSelected = overlay();
listSelected.box.dataset.wwCurrent = '';
document.body.append(hoverFrame, selectFrame, badge, selectedBadge, sectionBadge, listHover.box, listHover.label, listSelected.box, listSelected.label);
let selectedNode = null;
let selectedList = null;

// Sectienaam => bron en de elementen tussen de commentaren. Die elementen krijgen data-ww-section, zodat een
// element in de pagina zijn sectie vindt met closest().
const sections = findSections();
// Nummer van een lijst => de elementen van zijn kaarten, met data-ww-list.
const lists = findLists();

function send(payload) {
	window.parent.postMessage(payload, config.origin);
}

function findSections() {
	const found = new Map();
	const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_COMMENT);
	for (let comment = walker.nextNode(); comment; comment = walker.nextNode()) {
		const match = SECTION_START.exec(comment.data);
		if (!match) {
			continue;
		}
		const [, name, source] = match;
		const section = found.get(name) || { source, nodes: [] };
		for (let node = comment.nextSibling; node && !(node.nodeType === Node.COMMENT_NODE && node.data === `/ww-section:${name}`); node = node.nextSibling) {
			if (node.nodeType === Node.ELEMENT_NODE) {
				node.dataset.wwSection = name;
				section.nodes.push(node);
			}
		}
		found.set(name, section);
	}
	return found;
}

function findLists() {
	const found = new Map();
	const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_COMMENT);
	for (let comment = walker.nextNode(); comment; comment = walker.nextNode()) {
		const match = CARD_START.exec(comment.data);
		if (!match || !config.lists?.[match[1]]) {
			continue;
		}
		const index = match[1];
		const nodes = found.get(index) || [];
		for (let node = comment.nextSibling; node && !(node.nodeType === Node.COMMENT_NODE && node.data === `/ww-card:${index}`); node = node.nextSibling) {
			if (node.nodeType === Node.ELEMENT_NODE) {
				node.dataset.wwList = index;
				nodes.push(node);
			}
		}
		found.set(index, nodes);
	}
	return found;
}

// Een kader met label om een lijst; een lijst heeft geen eigen element, dus het kader ligt over zijn kaarten heen.
function overlay() {
	const box = document.createElement('ww-list-frame');
	const label = document.createElement('ww-list-badge');
	box.hidden = true;
	label.hidden = true;
	return { box, label };
}

function placeOverlay({ box, label }, index) {
	const info = listInfo[index];
	const rects = (lists.get(index) || []).map((node) => node.getBoundingClientRect()).filter((rect) => rect.width > 0);
	box.hidden = label.hidden = !info || rects.length === 0;
	if (box.hidden) {
		return;
	}
	const top = Math.min(...rects.map((rect) => rect.top)) + window.scrollY - 6;
	const left = Math.min(...rects.map((rect) => rect.left)) + window.scrollX - 6;
	box.style.top = `${top}px`;
	box.style.left = `${left}px`;
	box.style.width = `${Math.max(...rects.map((rect) => rect.right)) + window.scrollX + 6 - left}px`;
	box.style.height = `${Math.max(...rects.map((rect) => rect.bottom)) + window.scrollY + 6 - top}px`;
	label.textContent = `▦ ${info.label} · ${info.text}`;
	const above = top - label.offsetHeight - 4;
	label.style.top = `${above < 0 ? top + 4 : above}px`;
	label.style.left = `${Math.max(0, left)}px`;
}

// De lijst onder de muis, als het paneel hem kent.
function listOf(event) {
	const index = event.target.closest?.('[data-ww-list]')?.dataset.wwList;
	return index !== undefined && listInfo[index] ? index : null;
}

// Alle veldnamen van een element, in volgorde: de eerste is de inhoud, de rest attributen.
function namesOf(node) {
	return (node.dataset.wwEdit || '').split(' ').filter(Boolean);
}

// De veldnamen van een element die het zijpaneel kent.
function knownNamesOf(node) {
	return namesOf(node).filter((name) => Object.hasOwn(fields, name));
}

function decorate() {
	document.querySelectorAll('[data-ww-edit]').forEach((node) => {
		const known = knownNamesOf(node);
		if (known.length > 0) {
			node.dataset.wwEditable = '';
			node.dataset.wwLabel = known.map((name) => fields[name].label).join(' + ');
			node.toggleAttribute('data-ww-site', known.some((name) => fields[name].site));
		} else {
			delete node.dataset.wwEditable;
			delete node.dataset.wwSite;
		}
	});
}

// Een uitgezette sectie staat er in de editor toch, gedimd.
function decorateSections() {
	sections.forEach(({ nodes }, name) => nodes.forEach((node) => node.toggleAttribute('data-ww-section-off', Boolean(sectionInfo[name]?.off))));
}

// Kiest een element, een sectie of een lijst; de rest is dan niet meer gekozen.
function select(node, section = null, list = null) {
	selectedList = list;
	document.querySelectorAll('[data-ww-selected]').forEach((other) => delete other.dataset.wwSelected);
	document.querySelectorAll('[data-ww-section-selected]').forEach((other) => delete other.dataset.wwSectionSelected);
	if (node) {
		node.dataset.wwSelected = '';
	}
	selectedNode = node;
	hover(null);
	placeSelected();
	sections.get(section)?.nodes.forEach((other) => (other.dataset.wwSectionSelected = ''));
}

// Een label linksboven, boven het kader (placeFrame()), of erin als er boven het element geen ruimte is. Het label
// schaalt vanaf zijn onderrand (transform-origin), dus de rekensom gaat over die onderrand en de zichtbare hoogte.
function place(label, node) {
	const rect = node.getBoundingClientRect();
	label.textContent = `✎ ${node.dataset.wwLabel}`;
	label.toggleAttribute('data-ww-site', node.hasAttribute('data-ww-site'));
	const top = rect.top + window.scrollY;
	const visible = label.offsetHeight / scale;
	// Boven het kader: 6px ruimte van het kader, dan zijn witte rand en die van het label (elk 2px op het scherm).
	const above = top - 6 - 4 / scale;
	const bottom = above - visible < 0 ? top + 4 + visible : above;
	label.style.top = `${bottom - label.offsetHeight}px`;
	label.style.left = `${Math.max(0, rect.left + window.scrollX)}px`;
}

// Een kader om een element, 6px ruimer aan elke kant, in paginacoördinaten (ook bij een geschaald voorbeeld).
function placeFrame(frame, node) {
	frame.hidden = !node;
	if (!node) {
		return;
	}
	const rect = node.getBoundingClientRect();
	frame.toggleAttribute('data-ww-site', node.hasAttribute('data-ww-site'));
	frame.style.top = `${rect.top + window.scrollY - 6}px`;
	frame.style.left = `${rect.left + window.scrollX - 6}px`;
	frame.style.width = `${rect.width + 12}px`;
	frame.style.height = `${rect.height + 12}px`;
}

// Het label van het gekozen element; opnieuw geplaatst als de pagina verschuift (een langere tekst, een foto die
// laadt, een ander schermformaat).
function placeSelected() {
	selectedBadge.hidden = !selectedNode;
	placeFrame(selectFrame, selectedNode);
	if (hoveredNode && hoveredNode !== selectedNode) {
		placeFrame(hoverFrame, hoveredNode);
	}
	if (selectedNode) {
		place(selectedBadge, selectedNode);
	}
	placeOverlay(listSelected, selectedList);
}

// Het kader van de lijst onder de muis; de gekozen lijst heeft zijn kader al.
function hoverList(index) {
	placeOverlay(listHover, index === selectedList ? null : index);
}

// HTML uit de WYSIWYG-editor, opnieuw opgebouwd met alleen de elementen en attributen van ALLOWED_HTML. Het is de
// eigen tekst van de gebruiker en PHP filtert hem bij het tonen toch, maar dit frame heeft dezelfde herkomst als de
// admin: een voorbeeld hoort niets uit te voeren of te laden. Een allowlist, omdat een lijst met verboden dingen
// nooit compleet is.
function cleanHtml(html) {
	return cleanChildren(new DOMParser().parseFromString(html, 'text/html').body);
}

function cleanChildren(parent) {
	return Array.from(parent.childNodes).flatMap((node) => {
		if (node.nodeType === Node.TEXT_NODE) {
			return [document.createTextNode(node.data)];
		}
		if (node.nodeType !== Node.ELEMENT_NODE || DROPPED.includes(node.localName)) {
			return [];
		}
		const children = cleanChildren(node);
		if (!Object.hasOwn(ALLOWED_HTML, node.localName)) {
			return children;
		}
		const copy = document.createElement(node.localName);
		[...ALLOWED_HTML[node.localName], 'class', 'style'].forEach((name) => {
			const value = node.getAttribute(name);
			if (value !== null && (!URL_ATTRS.includes(name) || SAFE_URL.test(value))) {
				copy.setAttribute(name, value);
			}
		});
		copy.append(...children);
		return [copy];
	});
}

// Toont een wijziging direct. Na het opslaan laadt het zijpaneel de pagina opnieuw; dan rendert PHP het echt.
function apply(name, value) {
	document.querySelectorAll('[data-ww-edit]').forEach((node) => {
		const index = namesOf(node).indexOf(name);
		if (index === -1) {
			return;
		}
		if (node instanceof HTMLImageElement) {
			node.removeAttribute('srcset');
			node.removeAttribute('sizes');
			node.src = value?.url || EMPTY_IMAGE;
			node.toggleAttribute('data-ww-empty', !value?.url);
		} else if (index > 0) {
			// Een link op het element zelf of eromheen (een tegel met het label erin). Alleen gewone links; bij
			// opslaan escapet PHP de URL toch zelf.
			const link = node.closest('[href]');
			if (link && SAFE_URL.test(String(value ?? ''))) {
				link.setAttribute('href', String(value ?? ''));
			}
		} else if (typeof value?.html === 'string') {
			node.replaceChildren(...cleanHtml(value.html));
		} else if (typeof value === 'string') {
			node.innerText = value;
		}
	});
}

// Het gemarkeerde element onder de muis. Een foto onder een overlay telt ook: een pseudo-element van de sectie
// (dan bevat het aangeklikte element de foto) of een lege overlay zonder tekst. Een tekst die zelf niet gemarkeerd
// is, laat de foto eronder met rust; anders zou een klik op een titel de foto kiezen.
function targetOf(event) {
	const direct = event.target.closest('[data-ww-editable]');
	if (direct) {
		return direct;
	}
	const below = document.elementsFromPoint(event.clientX, event.clientY).find((node) => node.matches('[data-ww-editable]'));
	return below && (event.target.contains(below) || event.target.textContent.trim() === '') ? below : null;
}

function hover(node) {
	document.querySelectorAll('[data-ww-hover]').forEach((other) => other !== node && delete other.dataset.wwHover);
	// Het gekozen element heeft zijn label al.
	badge.hidden = !node || node === selectedNode;
	hoveredNode = node;
	if (!node) {
		hoverFrame.hidden = true;
		return;
	}
	node.dataset.wwHover = '';
	if (!badge.hidden) {
		place(badge, node);
	}
	placeFrame(hoverFrame, node === selectedNode ? null : node);
}

// De knop van een sectie, rechtsboven in de sectie: de naam, en of hij verborgen is of in de Site-instellingen staat.
function hoverSection(name) {
	const info = sectionInfo[name];
	sectionBadge.hidden = !info;
	document.querySelectorAll('[data-ww-section-hover]').forEach((other) => other.dataset.wwSection !== name && delete other.dataset.wwSectionHover);
	sections.get(name)?.nodes.forEach((node) => info && (node.dataset.wwSectionHover = ''));
	if (!info) {
		delete sectionBadge.dataset.wwSectionName;
		return;
	}
	const rects = (sections.get(name)?.nodes || []).map((node) => node.getBoundingClientRect()).filter((rect) => rect.width > 0);
	if (rects.length === 0) {
		sectionBadge.hidden = true;
		return;
	}
	const top = Math.min(...rects.map((rect) => rect.top));
	const right = Math.max(...rects.map((rect) => rect.right));
	sectionBadge.dataset.wwSectionName = name;
	sectionBadge.toggleAttribute('data-ww-clickable', Boolean(info.editable));
	sectionBadge.toggleAttribute('data-ww-site', Boolean(info.site));
	sectionBadge.textContent = info.settings ? strings.inSettings : `⚙ ${info.label}${info.site ? ` · ${strings.siteShort}` : ''}${info.off ? ` · ${strings.hidden}` : ''}`;
	sectionBadge.style.top = `${Math.max(0, top + window.scrollY + 8)}px`;
	sectionBadge.style.left = `${Math.max(0, right - 8 - sectionBadge.offsetWidth) + window.scrollX}px`;
}

document.addEventListener(
	'click',
	(event) => {
		if (event.target === sectionBadge) {
			event.preventDefault();
			event.stopPropagation();
			const name = sectionBadge.dataset.wwSectionName;
			if (sectionInfo[name]?.editable) {
				select(null, name);
				send({ type: MESSAGE.SECTION, name });
			}
			return;
		}
		// Een kaart gaat voor een foto eronder: de kaarten zelf zijn van een ander bericht en niet gemarkeerd.
		const list = listOf(event);
		if (list !== null) {
			event.preventDefault();
			event.stopPropagation();
			select(null, null, list);
			hoverList(null);
			send({ type: MESSAGE.LIST, index: Number(list) });
			return;
		}
		const node = targetOf(event);
		// Geen links volgen of formulieren versturen: de pagina staat hier alleen om te bewerken.
		if (node || event.target.closest('a[href]')) {
			event.preventDefault();
		}
		if (!node) {
			return;
		}
		event.stopPropagation();
		select(node);
		send({ type: MESSAGE.SELECT, fields: namesOf(node) });
	},
	true
);

document.addEventListener('submit', (event) => event.preventDefault(), true);

document.addEventListener('mousemove', (event) => {
	const list = listOf(event);
	hoverList(list);
	hover(list === null ? targetOf(event) : null);
	// Op de knop zelf blijft de sectie gekozen; de knop staat buiten de sectie in de body.
	if (event.target !== sectionBadge) {
		hoverSection(event.target.closest('[data-ww-section]')?.dataset.wwSection);
	}
});
document.addEventListener('mouseleave', () => {
	hover(null);
	hoverList(null);
	hoverSection(null);
});

new ResizeObserver(placeSelected).observe(document.body);
window.addEventListener('resize', placeSelected);

// Wie zelf scrolt, krijgt bij load niet alsnog de plek van voor het opslaan.
['wheel', 'touchstart', 'keydown', 'mousedown'].forEach((type) => window.addEventListener(type, () => (pendingScroll = null), { capture: true, passive: true }));
window.addEventListener('load', () => {
	if (pendingScroll !== null) {
		window.scrollTo(0, pendingScroll);
		pendingScroll = null;
	}
});

let scrollQueued = false;
window.addEventListener('scroll', () => {
	if (scrollQueued) {
		return;
	}
	scrollQueued = true;
	requestAnimationFrame(() => {
		scrollQueued = false;
		send({ type: MESSAGE.SCROLL, y: window.scrollY });
	});
});

window.addEventListener('message', (event) => {
	if (event.source !== window.parent || event.origin !== config.origin) {
		return;
	}
	const { type } = event.data || {};
	if (type === MESSAGE.FIELDS) {
		fields = event.data.fields || {};
		strings = event.data.strings || {};
		sectionInfo = event.data.sections || {};
		listInfo = event.data.lists || {};
		decorate();
		decorateSections();
		// Na het opslaan laadt de pagina opnieuw: dezelfde plek en hetzelfde element, dezelfde sectie of dezelfde lijst
		// als daarvoor.
		const y = Number(event.data.scroll) || 0;
		window.scrollTo(0, y);
		pendingScroll = document.readyState === 'complete' ? null : y;
		// Het element met precies deze velden, anders het element met het eerste veld (één veld van een element met meer).
		const wanted = Array.isArray(event.data.selected) ? event.data.selected : [];
		const nodes = Array.from(document.querySelectorAll('[data-ww-edit]'));
		const node = wanted.length > 0 ? (nodes.find((other) => other.dataset.wwEdit === wanted.join(' ')) ?? nodes.find((other) => namesOf(other).includes(wanted[0])) ?? null) : null;
		const list = Number.isInteger(event.data.list) ? String(event.data.list) : null;
		select(node, event.data.section, list);
	} else if (type === MESSAGE.SECTIONS) {
		sectionInfo = event.data.sections || {};
		decorateSections();
	} else if (type === MESSAGE.LISTS) {
		listInfo = event.data.lists || {};
		placeSelected();
	} else if (type === MESSAGE.VALUE) {
		apply(event.data.name, event.data.value);
		placeSelected();
	} else if (type === MESSAGE.DESELECT) {
		select(null);
	} else if (type === MESSAGE.HELLO) {
		setAccent(event.data.accent);
		setScale(event.data.scale);
		placeSelected();
		ready();
	} else if (type === MESSAGE.SCALE) {
		setScale(event.data.scale);
		placeSelected();
	} else if (type === MESSAGE.REVEAL) {
		reveal(event.data);
	}
});

// Uit het zoekvenster: een veld of sectie in beeld en gekozen. Het zijpaneel opent zelf; er gaat geen SELECT of
// SECTION terug.
function reveal({ field, section }) {
	const behavior = window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth';
	if (typeof field === 'string') {
		const node = Array.from(document.querySelectorAll('[data-ww-edit]')).find((other) => namesOf(other).includes(field));
		if (node) {
			node.scrollIntoView({ block: 'center', behavior });
			select(node);
		}
	} else if (typeof section === 'string' && sections.has(section)) {
		sections.get(section).nodes[0]?.scrollIntoView({ block: 'center', behavior });
		select(null, section);
	}
}

// Ctrl+K of ⌘K in de pagina opent het zoekvenster van de bewerker, niet de zoekbalk van de browser.
window.addEventListener(
	'keydown',
	(event) => {
		if ((event.ctrlKey || event.metaKey) && !event.shiftKey && !event.altKey && event.key?.toLowerCase() === 'k') {
			event.preventDefault();
			send({ type: MESSAGE.SEARCH });
		}
	},
	true
);

// De accentkleur van de admin van de gebruiker; alleen een gewone kleurwaarde, nooit zomaar een string in de CSS.
function setAccent(accent) {
	if (typeof accent === 'string' && /^(#[0-9a-f]{3,8}|rgba?\([\d\s,.%]+\)|hsla?\([\d\s,.%deg]+\))$/i.test(accent.trim())) {
		document.documentElement.style.setProperty('--ww-edit-accent', accent.trim());
	}
}

// De schaal van het voorbeeld, zodat kaders en labels visueel even dik en groot blijven.
function setScale(next) {
	const value = Number(next);
	if (value > 0 && value <= 4) {
		scale = value;
		document.documentElement.style.setProperty('--ww-edit-scale', String(value));
	}
}

// Het zijpaneel bepaalt welke velden nergens gemarkeerd zijn; die horen bij hun sectie of bij de pagina. Meldt zich bij
// het laden en bij elke HELLO, steeds met dezelfde LOAD_ID: het zijpaneel verwerkt een herhaling niet opnieuw.
function ready() {
	send({
		type: MESSAGE.READY,
		load: LOAD_ID,
		marks: [...new Set(Array.from(document.querySelectorAll('[data-ww-edit]')).flatMap(namesOf))],
		sections: Array.from(sections, ([name, { source }]) => ({ name, source })),
		lists: Array.from(lists.keys(), (index) => ({ index: Number(index), ...config.lists[index] })),
	});
}

ready();
