/**
 * Het formulier van Redirects (inc/redirects-admin-sections.php): de nieuwe URL uit bij Pagina is weg (410), en een
 * samenvatting in gewone taal. Alleen gemak: zonder dit script werkt het formulier ook.
 */
( function () {
	'use strict';

	var form = document.querySelector( '.ww-redirects-form' );
	var summary = document.getElementById( 'ww-redirect-summary' );
	var l10n = window.wwRedirectsL10n;
	if ( ! form || ! summary || ! l10n ) {
		return;
	}
	var source = form.querySelector( '#ww-source' );
	var target = form.querySelector( '#ww-target' );
	var prefix = form.querySelector( 'input[name="ww_match_type"]' );

	function status() {
		var checked = form.querySelector( 'input[name="ww_status"]:checked' );
		return checked ? checked.value : '301';
	}

	function code( text ) {
		var el = document.createElement( 'code' );
		el.textContent = text;
		return el;
	}

	// Vult een tekst met %1$s en %2$s met elementen, zonder HTML uit de invoer te lezen.
	function fill( template, parts ) {
		summary.textContent = '';
		template.split( /(%[12]\$s)/ ).forEach( function ( piece ) {
			if ( '%1$s' === piece ) {
				summary.appendChild( parts[ 0 ] );
			} else if ( '%2$s' === piece ) {
				summary.appendChild( parts[ 1 ] );
			} else if ( piece ) {
				summary.appendChild( document.createTextNode( piece ) );
			}
		} );
	}

	function update() {
		var code410 = '410' === status();
		if ( target ) {
			target.disabled = code410;
		}
		var from = source ? source.value.trim() : '';
		if ( '' === from ) {
			summary.hidden = true;
			return;
		}
		var below = prefix && prefix.checked ? l10n.below : '';
		var to = target ? target.value.trim() : '';
		var fromNode = document.createDocumentFragment();
		fromNode.appendChild( code( l10n.host + from ) );
		if ( below ) {
			fromNode.appendChild( document.createTextNode( below ) );
		}
		fill( l10n[ 's' + status() ] || l10n.s301, [ fromNode, code( to || '…' ) ] );
		summary.hidden = false;
	}

	form.addEventListener( 'input', update );
	form.addEventListener( 'change', update );
	update();
}() );
