/**
 * Toestemmingslaag in de browser (beslissing 0037): leest en schrijft de cookie ww_consent, toont de banner uit
 * inc/consent.php en activeert de <template>-elementen van de gekozen categorieën.
 *
 * De server geeft elke bezoeker dezelfde HTML (paginacache); dit script beslist wat er draait. Zonder banner op de
 * pagina doet het niets. Geen localStorage: de keuze staat alleen in de cookie.
 */
( function () {
	'use strict';

	var COOKIE = 'ww_consent';
	var MAX_AGE = 31536000; // 12 maanden, in seconden.
	// Cookies van statistieken en marketing (Google Analytics, Google Ads, Meta) die bij intrekken weg moeten.
	var TRACKING_COOKIE = /^(_ga|_gid|_gat|_fbp|_gcl_)/;
	// MIME-types waarmee de browser een script als JavaScript uitvoert.
	var JS_TYPE = /^(?:(?:text|application)\/(?:x-)?(?:java|ecma)script|text\/javascript1\.[0-5]|text\/(?:jscript|livescript))$/;

	var banner = document.querySelector( '[data-ww-consent-banner]' );
	if ( ! banner ) {
		return;
	}

	var version = banner.getAttribute( 'data-ww-consent-version' ) || '';
	var choices = banner.querySelector( '[data-ww-consent-choices]' );
	var settingsButton = banner.querySelector( '[data-ww-consent-action="settings"]' );
	var saveButton = banner.querySelector( '[data-ww-consent-action="save"]' );
	// De actieve categorieën: alleen die hebben een schakelaar in de banner.
	var boxes = Array.prototype.slice.call( banner.querySelectorAll( 'input[type="checkbox"][name]' ) );
	var available = boxes.map( function ( box ) {
		return box.name;
	} );

	// De huidige keuze, of null als er (nog) geen geldige keuze is.
	var current = readChoice();
	// Element dat de focus had voordat de banner hem kreeg; daar gaat de focus na een keuze of Escape naartoe.
	var returnTo = null;
	// Geopend via open() of [data-ww-consent-open]: dan sluit Escape de banner, ook zonder eerdere keuze.
	var openedOnRequest = false;
	// Scripts komen in volgorde in de pagina: een extern script zonder async of defer houdt de rest op tot het geladen is.
	var queue = Promise.resolve();

	/**
	 * Leest de cookie. Geeft de gekozen categorieën terug (alleen die met een schakelaar), of null als er geen cookie
	 * is, hij niet te lezen is, de versie niet klopt of hij ouder is dan 12 maanden.
	 */
	function readChoice() {
		var parts = document.cookie ? document.cookie.split( ';' ) : [];
		for ( var i = 0; i < parts.length; i++ ) {
			var part = parts[ i ].replace( /^\s+/, '' );
			if ( part.indexOf( COOKIE + '=' ) !== 0 ) {
				continue;
			}
			try {
				var data = JSON.parse( decodeURIComponent( part.slice( COOKIE.length + 1 ) ) );
				if ( ! data || data.v !== version || ! Array.isArray( data.c ) || typeof data.t !== 'number' ) {
					return null;
				}
				if ( ! ( Math.floor( Date.now() / 1000 ) - data.t < MAX_AGE ) ) {
					return null;
				}
				return available.filter( function ( category ) {
					return data.c.indexOf( category ) !== -1;
				} );
			} catch ( e ) {
				return null;
			}
		}
		return null;
	}

	/**
	 * Schrijft de keuze in de cookie: URL-gecodeerde JSON met versie, categorieën en tijd.
	 */
	function writeChoice( categories ) {
		var value = encodeURIComponent(
			JSON.stringify( { v: version, c: categories, t: Math.floor( Date.now() / 1000 ) } )
		);
		document.cookie =
			COOKIE + '=' + value + '; Path=/; Max-Age=' + MAX_AGE + '; SameSite=Lax' +
			( location.protocol === 'https:' ? '; Secure' : '' );
	}

	/**
	 * Wist de trackingcookies op het eigen domein en op het hoofddomein (de laatste twee labels van de hostnaam).
	 */
	function clearTrackingCookies() {
		var root = location.hostname.split( '.' ).slice( -2 ).join( '.' );
		var parts = document.cookie ? document.cookie.split( ';' ) : [];
		parts.forEach( function ( part ) {
			var name = part.split( '=' )[ 0 ].replace( /^\s+|\s+$/g, '' );
			if ( TRACKING_COOKIE.test( name ) ) {
				document.cookie = name + '=; Max-Age=0; Path=/';
				document.cookie = name + '=; Max-Age=0; Path=/; Domain=' + root;
			}
		} );
	}

	/**
	 * Een nieuw <script> met dezelfde attributen en tekst: een gekloond script uit een <template> draait niet.
	 */
	function recreateScript( old ) {
		var script = document.createElement( 'script' );
		for ( var i = 0; i < old.attributes.length; i++ ) {
			script.setAttribute( old.attributes[ i ].name, old.attributes[ i ].value );
		}
		script.textContent = old.textContent;
		if ( script.hasAttribute( 'src' ) && ! script.hasAttribute( 'async' ) && ! script.hasAttribute( 'defer' ) ) {
			script.async = false;
		}
		return script;
	}

	/**
	 * Moet de rest wachten tot dit script geladen is? Ja bij een extern script zonder async of defer dat de browser
	 * echt uitvoert: type leeg, een JavaScript-MIME-type of module, en geen nomodule. Een script met bijvoorbeeld
	 * type="text/plain" vuurt nooit load of error en zou alle volgende templates ophouden.
	 */
	function blocks( script ) {
		if ( ! script.hasAttribute( 'src' ) || script.hasAttribute( 'async' ) || script.hasAttribute( 'defer' ) ) {
			return false;
		}
		if ( script.hasAttribute( 'nomodule' ) ) {
			return false;
		}
		var type = ( script.getAttribute( 'type' ) || '' ).split( ';' )[ 0 ].trim().toLowerCase();
		return type === '' || type === 'module' || JS_TYPE.test( type );
	}

	/**
	 * Zet één knoop op zijn plek. Een blokkerend script geeft een Promise die klaar is bij load of error.
	 */
	function insert( node, place ) {
		place( node );
		if ( node.nodeName === 'SCRIPT' && blocks( node ) ) {
			return new Promise( function ( resolve ) {
				node.addEventListener( 'load', resolve );
				node.addEventListener( 'error', resolve );
			} );
		}
		return null;
	}

	/**
	 * Activeert één template: kloont de inhoud, maakt de scripts opnieuw, laat <noscript> weg en zet de knopen in
	 * de <head> of direct na de template. Elke template hoogstens één keer (data-ww-done).
	 */
	function activate( template ) {
		if ( template.hasAttribute( 'data-ww-done' ) ) {
			return;
		}
		template.setAttribute( 'data-ww-done', '' );

		var nodes = Array.prototype.slice.call( template.content.cloneNode( true ).childNodes );
		var anchor = template;
		var place = template.getAttribute( 'data-ww-place' ) === 'head'
			? function ( node ) {
				document.head.appendChild( node );
			}
			: function ( node ) {
				anchor.after( node );
				anchor = node;
			};

		nodes.forEach( function ( node ) {
			if ( node.nodeName === 'NOSCRIPT' ) {
				return;
			}
			if ( node.nodeName === 'SCRIPT' ) {
				node = recreateScript( node );
			} else if ( node.nodeType === 1 ) {
				// Scripts en noscript dieper in een element: zelfde behandeling, maar zonder op het laden te wachten.
				Array.prototype.forEach.call( node.querySelectorAll( 'noscript' ), function ( child ) {
					child.remove();
				} );
				Array.prototype.forEach.call( node.querySelectorAll( 'script' ), function ( child ) {
					child.replaceWith( recreateScript( child ) );
				} );
			}
			queue = queue.then( function () {
				return insert( node, place );
			} );
		} );
	}

	/**
	 * Activeert de templates van de toegestane categorieën die nog niet actief zijn, in de volgorde van de pagina.
	 */
	function activateAllowed( categories ) {
		Array.prototype.forEach.call( document.querySelectorAll( 'template[data-ww-consent]' ), function ( template ) {
			if ( categories.indexOf( template.getAttribute( 'data-ww-consent' ) ) !== -1 ) {
				activate( template );
			}
		} );
	}

	/**
	 * Toont of verbergt de schakelaars en Keuze opslaan.
	 */
	function setExpanded( expanded ) {
		if ( choices ) {
			choices.hidden = ! expanded;
		}
		if ( saveButton ) {
			saveButton.hidden = ! expanded;
		}
		if ( settingsButton ) {
			settingsButton.setAttribute( 'aria-expanded', expanded ? 'true' : 'false' );
		}
	}

	/**
	 * Verbergt de banner. Geeft het element terug dat de focus had voordat de banner hem kreeg, of null.
	 */
	function hide() {
		var target = returnTo;
		banner.hidden = true;
		openedOnRequest = false;
		returnTo = null;
		return target;
	}

	/**
	 * Zet de focus terug waar hij was, als dat element er nog is.
	 */
	function restoreFocus( target ) {
		if ( target && target !== document.body && document.contains( target ) && typeof target.focus === 'function' ) {
			target.focus();
		}
	}

	/**
	 * Opent de banner met de schakelaars uitgeklapt en de huidige keuze aangevinkt, en geeft de focus aan de eerste knop.
	 */
	function open() {
		var active = document.activeElement;
		if ( active && ! banner.contains( active ) ) {
			returnTo = active;
		}
		boxes.forEach( function ( box ) {
			box.checked = current !== null && current.indexOf( box.name ) !== -1;
		} );
		setExpanded( true );
		openedOnRequest = true;
		banner.hidden = false;
		var first = banner.querySelector( 'button:not([hidden])' );
		if ( first ) {
			first.focus();
		}
	}

	/**
	 * Verwerkt een keuze: cookie, banner dicht, activeren, event, focus terug. Valt er een categorie weg, dan wissen
	 * we de trackingcookies en herladen we, omdat code die al draait niet te stoppen is. Zonder geldige vorige keuze
	 * (eerste bezoek, nieuwe versie of verlopen) draait er op deze pagina nog niets: een keuze zonder statistieken of
	 * marketing wist dan alleen de trackingcookies, bijvoorbeeld van voor een versiewissel, zonder te herladen.
	 */
	function choose( categories ) {
		var previous = current;
		var revoked = previous !== null && previous.some( function ( category ) {
			return categories.indexOf( category ) === -1;
		} );
		writeChoice( categories );
		current = categories;
		var target = hide();
		if ( previous === null && available.some( function ( category ) {
			return categories.indexOf( category ) === -1;
		} ) ) {
			clearTrackingCookies();
		}
		if ( ! revoked ) {
			activateAllowed( categories );
		}
		document.dispatchEvent(
			new CustomEvent( 'ww-consent-change', { detail: { categories: categories.slice() } } )
		);
		if ( revoked ) {
			clearTrackingCookies();
			location.reload();
			return;
		}
		restoreFocus( target );
	}

	// Knoppen in de banner.
	banner.addEventListener( 'click', function ( event ) {
		var button = event.target.closest ? event.target.closest( '[data-ww-consent-action]' ) : null;
		if ( ! button || ! banner.contains( button ) ) {
			return;
		}
		switch ( button.getAttribute( 'data-ww-consent-action' ) ) {
			case 'accept':
				choose( available.slice() );
				break;
			case 'reject':
				choose( [] );
				break;
			case 'settings':
				setExpanded( settingsButton.getAttribute( 'aria-expanded' ) !== 'true' );
				break;
			case 'save':
				choose(
					boxes
						.filter( function ( box ) {
							return box.checked;
						} )
						.map( function ( box ) {
							return box.name;
						} )
				);
				break;
		}
	} );

	// Escape sluit zonder wijziging, maar niet bij een eerste bezoek: dan moet er eerst een keuze komen.
	banner.addEventListener( 'keydown', function ( event ) {
		if ( event.key === 'Escape' && ! banner.hidden && ( openedOnRequest || current !== null ) ) {
			event.preventDefault();
			restoreFocus( hide() );
		}
	} );

	// Waar kwam de focus vandaan toen hij de banner in ging (ook bij een eerste bezoek, via Tab)?
	banner.addEventListener( 'focusin', function ( event ) {
		if ( event.relatedTarget && ! banner.contains( event.relatedTarget ) ) {
			returnTo = event.relatedTarget;
		}
	} );

	// Elk element met data-ww-consent-open opent de banner, ook als het later in de pagina komt.
	document.addEventListener( 'click', function ( event ) {
		var opener = event.target.closest ? event.target.closest( '[data-ww-consent-open]' ) : null;
		if ( opener ) {
			event.preventDefault();
			open();
		}
	} );

	window.wwConsent = {
		has: function ( category ) {
			return current !== null && current.indexOf( category ) !== -1;
		},
		open: open,
		get categories() {
			return current ? current.slice() : [];
		},
	};

	if ( current !== null ) {
		activateAllowed( current );
	} else {
		// Eerste bezoek: tonen, maar de focus niet overnemen.
		banner.hidden = false;
	}
} )();
