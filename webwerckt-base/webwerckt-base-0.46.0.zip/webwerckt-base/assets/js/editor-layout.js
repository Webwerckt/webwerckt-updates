// Visueel bewerken: rekenregels voor de weergaven in het midden van het zijpaneel (editor.js), zonder DOM. Dit
// bestand importeert niets, zodat de regels ook los in node te controleren zijn.

// Tot zoveel groepen staan de velden van de Pagina-instellingen direct onder elkaar; bij meer is het een lijst.
export const INLINE_GROUPS = 3;

// Een label zonder "{prefix}: " aan het begin (de conventie uit 0019, 'Hero: titel'), met een hoofdletter: 'Titel'.
// Begint het label niet zo, of is er geen prefix, dan blijft het zoals het is.
export function withoutPrefix(label, prefix) {
	const head = `${prefix}: `;
	if (!prefix || !label.startsWith(head)) {
		return label;
	}
	const rest = label.slice(head.length).trimStart();
	return rest === '' ? label : rest.charAt(0).toUpperCase() + rest.slice(1);
}

// De sectie waar een veldgroep bij hoort: haar sleutel eindigt op _{sectie} (child_template_{template}_{sectie}), de
// langste naam als er meer passen (hero en hero_extra). Anders null.
export function sectionOfGroup(key, sectionNames) {
	return sectionNames.filter((name) => key.endsWith(`_${name}`)).reduce((best, name) => (!best || name.length > best.length ? name : best), null);
}

// De groepen van de Pagina-instellingen: alle groepen, in hun volgorde, behalve die van een sectie op de pagina; die
// staan al in de weergave Sectie. Algemeen (titel en slug) blijft altijd.
export function pageSettingsGroups(groups, sectionNames) {
	return groups.filter((group) => group.key === 'general' || sectionOfGroup(group.key, sectionNames) === null);
}

// De marge om het voorbeeld, in pixels, als het geschaald of als scherm in het midden staat.
export const PREVIEW_MARGIN = 20;

// De schaal waarmee een pagina van `viewport` pixels breed in `available` pixels past (met marge aan beide kanten):
// nooit groter dan 1, nooit kleiner dan 0,1.
export function previewScale({ viewport, available, margin = PREVIEW_MARGIN }) {
	return Math.max(0.1, Math.min(1, (available - 2 * margin) / viewport));
}

// De tekst rechts naast het schermformaat. Met een keuze (choice, alleen op Desktop als er iets te schalen valt) de
// zoomknop: "Passend · 62%" of "100%"; zonder keuze de breedte, en de schaal als het voorbeeld kleiner staat:
// "768px · 85%". strings.fitScale heeft %d voor de schaal en %% voor het procentteken (gettext-formaat).
export function zoomLabel({ choice, zoom, scale, viewport, strings }) {
	const percent = Math.round(scale * 100);
	if (choice) {
		return zoom === '100' ? strings.fullSize : strings.fitScale.replace('%d', String(percent)).replace('%%', '%');
	}
	return scale < 1 ? `${viewport}px · ${percent}%` : `${viewport}px`;
}

// De grijze regel onder Deze pagina en Hele site: de namen van de groepen erachter, hooguit `max`, met "…" als er meer
// zijn. Lege namen tellen niet mee; zonder namen een lege tekst.
export function groupSummary(labels, max = 3) {
	const names = labels.filter((label) => typeof label === 'string' && label.trim() !== '');
	return names.length > max ? `${names.slice(0, max).join(', ')}, …` : names.join(', ');
}
