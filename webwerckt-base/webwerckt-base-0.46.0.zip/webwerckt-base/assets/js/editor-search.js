// Zoekvenster van de visuele bewerker, te openen met het vergrootglas of Ctrl+K / ⌘K: zoekt in secties, velden van
// de pagina, velden van de Site-instellingen, veldgroepen en andere pagina's (goto). Een combobox met listbox volgens het WAI-ARIA-patroon:
// de focus blijft in het zoekveld, ↑↓ verplaatsen de selectie (aria-activedescendant), Enter kiest, Escape of een
// klik op de overlay sluit en zet de focus terug waar hij was. Wat er te vinden is en wat kiezen doet, bepaalt
// editor.js (entries en onPick); dit bestand doet alleen het venster. Bij het importeren raakt het de DOM niet aan.

/** @typedef {{ kind: 'section' | 'page' | 'site' | 'group' | 'goto', id: string, label: string, detail: string }} Entry */

// Woorden in een label: 'Hero: titel', 'Contact · telefoon', 'Over-ons'.
const WORDS = /[\s:·\-–]+/;
// Het icoon per soort resultaat, dezelfde als in de kop van het paneel.
const ICONS = { section: 'admin-generic', page: 'edit', site: 'admin-site-alt3', group: 'admin-page', goto: 'media-document' };

let count = 0;

// Kleine letters, zonder accenten ('Café' => 'cafe') en zonder spaties eromheen.
export function normalize(text) {
	return String(text ?? '')
		.normalize('NFD')
		.replace(/\p{M}/gu, '')
		.toLowerCase()
		.trim();
}

// 0: het label begint met de term; 1: een woord in het label begint ermee; 2: label of toelichting bevat hem; 3: de
// term heeft meer woorden en die staan elk ergens in label of toelichting ('diensten titel' vindt 'Diensten: titel').
function score(entry, q) {
	const label = normalize(entry.label);
	if (label.startsWith(q)) {
		return 0;
	}
	if (label.split(WORDS).some((word) => word.startsWith(q))) {
		return 1;
	}
	const text = normalize(`${entry.label} ${entry.detail}`);
	if (text.includes(q)) {
		return 2;
	}
	const words = q.split(WORDS).filter(Boolean);
	return words.length > 1 && words.every((word) => text.includes(word)) ? 3 : null;
}

/**
 * De treffers voor een zoekterm, de beste eerst; bij een gelijke stand in de volgorde van entries. Zonder zoekterm de
 * secties en groepen, als snelle sprong (andere pagina's staan in het menu onder de paginatitel).
 *
 * @param {Entry[]} entries
 * @param {string} query
 * @returns {Entry[]}
 */
export function rank(entries, query) {
	const q = normalize(query);
	if (q === '') {
		return entries.filter((entry) => entry.kind === 'section' || entry.kind === 'group');
	}
	return entries
		.map((entry, index) => ({ entry, index, score: score(entry, q) }))
		.filter((item) => item.score !== null)
		.sort((a, b) => a.score - b.score || a.index - b.index)
		.map((item) => item.entry);
}

// Ctrl+K, of ⌘K op macOS.
export function isSearchShortcut(event) {
	return Boolean(event.ctrlKey || event.metaKey) && !event.shiftKey && !event.altKey && typeof event.key === 'string' && event.key.toLowerCase() === 'k';
}

// Een resultaat uit de Site-instellingen: een siteveld of een groep van de site.
function isSiteEntry(entry) {
	return entry.kind === 'site' || (entry.kind === 'group' && entry.id.startsWith('site:'));
}

function element(tag, props = {}, children = []) {
	const node = Object.assign(document.createElement(tag), props);
	node.append(...children);
	return node;
}

/**
 * @param {HTMLElement} container  het lege [data-ww-editor-search-dialog]
 * @param {{ strings: Record<string, string>, entries: () => Entry[], onPick: (entry: Entry) => void }} options
 * @returns {{ open(): void, close(): void, isOpen(): boolean }}
 */
export function searchDialog(container, { strings, entries, onPick }) {
	count += 1;
	const id = `ww-editor-search-${count}`;
	const listbox = element('div', { id: `${id}-list`, className: 'ww-editor__search-list', role: 'listbox' });
	listbox.setAttribute('aria-label', strings.search);
	const input = element('input', {
		id: `${id}-input`,
		type: 'text',
		className: 'ww-editor__search-input',
		placeholder: strings.searchPlaceholder,
		autocomplete: 'off',
		spellcheck: false,
		role: 'combobox',
	});
	input.setAttribute('aria-label', strings.searchPlaceholder);
	input.setAttribute('aria-controls', listbox.id);
	input.setAttribute('aria-autocomplete', 'list');
	input.setAttribute('aria-expanded', 'true');
	const empty = element('p', { className: 'ww-editor__search-empty', role: 'status' });
	const dialog = element('div', { className: 'ww-editor__search-dialog', role: 'dialog' }, [
		element('div', { className: 'ww-editor__search-field' }, [element('span', { className: 'dashicons dashicons-search', ariaHidden: 'true' }), input]),
		listbox,
		empty,
	]);
	dialog.setAttribute('aria-modal', 'true');
	dialog.setAttribute('aria-label', strings.search);
	const backdrop = element('div', { className: 'ww-editor__search-overlay' });
	container.classList.add('ww-editor__search');
	container.replaceChildren(backdrop, dialog);

	// De resultaten zoals ze nu in de lijst staan, in de volgorde van de lijst, en welke gekozen is.
	let shown = [];
	let active = -1;
	// Wat de focus had voor het venster openging.
	let returnFocus = null;

	const isOpen = () => !container.hidden;

	const optionId = (index) => `${id}-option-${index}`;

	function setActive(index) {
		const options = listbox.querySelectorAll('[role="option"]');
		active = shown.length === 0 ? -1 : (index + shown.length) % shown.length;
		options.forEach((option, other) => option.setAttribute('aria-selected', String(other === active)));
		if (active === -1) {
			input.removeAttribute('aria-activedescendant');
			return;
		}
		input.setAttribute('aria-activedescendant', optionId(active));
		options[active].scrollIntoView({ block: 'nearest' });
	}

	function option(entry, index) {
		const node = element('div', { id: optionId(index), className: 'ww-editor__search-option', role: 'option' }, [
			element('span', { className: `dashicons dashicons-${ICONS[entry.kind]}`, ariaHidden: 'true' }),
			element('span', { className: 'ww-editor__search-label', textContent: entry.label }),
			element('span', { className: 'ww-editor__search-detail', textContent: entry.detail }),
		]);
		node.setAttribute('aria-selected', 'false');
		if (isSiteEntry(entry)) {
			node.dataset.wwSite = '';
			node.append(element('span', { className: 'ww-editor__search-site', textContent: strings.siteKind }));
		}
		node.addEventListener('mousemove', () => active !== index && setActive(index));
		node.addEventListener('click', () => pick(index));
		return node;
	}

	// Blokken met een kopje: Secties, Deze pagina, Site, Pagina's, en zonder zoekterm de groepen.
	function render() {
		const query = input.value;
		const found = rank(entries(), query);
		const blocks = [
			['section', strings.sections],
			['page', strings.thisPage],
			['site', strings.siteKind],
			['goto', strings.otherPages],
			...(normalize(query) === '' ? [['group', strings.groups]] : []),
		];
		shown = [];
		const groups = blocks.flatMap(([kind, title]) => {
			const items = found.filter((entry) => entry.kind === kind);
			if (items.length === 0) {
				return [];
			}
			const headingId = `${id}-${kind}`;
			const options = items.map((entry) => {
				shown.push(entry);
				return option(entry, shown.length - 1);
			});
			const group = element('div', { className: 'ww-editor__search-group', role: 'group' }, [
				element('div', { id: headingId, className: 'ww-editor__search-heading', role: 'presentation', textContent: title }),
				...options,
			]);
			group.setAttribute('aria-labelledby', headingId);
			return [group];
		});
		listbox.replaceChildren(...groups);
		listbox.hidden = shown.length === 0;
		empty.hidden = shown.length > 0 || normalize(query) === '';
		empty.textContent = empty.hidden ? '' : strings.noResults.replace('%s', () => query.trim());
		setActive(0);
	}

	function open() {
		// Al open: alleen de focus terug naar het zoekveld, geen tweede venster.
		if (isOpen()) {
			input.focus();
			input.select();
			return;
		}
		returnFocus = document.activeElement;
		input.value = '';
		container.hidden = false;
		render();
		input.focus();
	}

	function close() {
		if (!isOpen()) {
			return;
		}
		container.hidden = true;
		const target = returnFocus;
		returnFocus = null;
		if (target?.isConnected && typeof target.focus === 'function') {
			target.focus();
		}
	}

	// Eerst sluiten, met de focus terug: wat het resultaat opent, zet de focus daarna zelf.
	function pick(index) {
		const entry = shown[index];
		if (!entry) {
			return;
		}
		close();
		onPick(entry);
	}

	input.addEventListener('input', render);
	dialog.addEventListener('keydown', (event) => {
		if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
			event.preventDefault();
			setActive(active + (event.key === 'ArrowDown' ? 1 : -1));
		} else if (event.key === 'Enter') {
			event.preventDefault();
			pick(active);
		} else if (event.key === 'Escape') {
			// Alleen het venster sluit, niet een menu of het paneel eronder (editor.js).
			event.preventDefault();
			event.stopPropagation();
			close();
		} else if (event.key === 'Tab') {
			// Het zoekveld is het enige wat de focus kan krijgen; die blijft in het venster.
			event.preventDefault();
		}
	});
	backdrop.addEventListener('click', () => close());
	// Een klik in het venster (een resultaat, een kopje, de rand) haalt de focus niet uit het zoekveld; anders werken
	// Escape, ↑↓ en Enter niet meer.
	dialog.addEventListener('mousedown', (event) => event.target !== input && event.preventDefault());

	return { open, close, isOpen };
}
