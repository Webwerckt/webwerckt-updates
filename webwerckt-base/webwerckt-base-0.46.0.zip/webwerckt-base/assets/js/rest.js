// Gedeeld door load-more.js en filter.js: het kaarten-endpoint aanroepen en wijzigingen melden.

const ROUTE = '/ww/v1/cards';

// Het endpoint komt van PHP (_ww_rest_module_data()) in <script type="application/json">. Een tekstveld in de pagina
// kan wel data-attributen of een element met hetzelfde id maken (wp_kses_post laat data-* en id door), maar geen
// script-element; daarom alleen dat element, en geen data-attribuut meer.
export function cardsEndpoint() {
	const element = document.querySelector('script[type="application/json"]#wp-script-module-data-ww-rest');
	let data;
	try {
		data = JSON.parse(element?.textContent || '{}');
	} catch (error) {
		return null;
	}
	return endpointUrl(typeof data?.endpoint === 'string' ? data.endpoint : '');
}

// Alleen ons eigen endpoint op dit domein: geen HTML van een vreemde server of van een ander bestand op het domein.
// Met mooie permalinks /wp-json/ww/v1/cards zonder rest_route (die wint in WordPress van het pad), anders de
// homepage (of index.php) met rest_route precies onze route.
export function endpointUrl(value) {
	let url;
	try {
		url = new URL(value, window.location.href);
	} catch (error) {
		return null;
	}
	if (url.origin !== window.location.origin || url.username || url.password) {
		return null;
	}
	const route = url.searchParams.get('rest_route');
	const pretty = url.pathname.endsWith(`/wp-json${ROUTE}`) && route === null;
	const plain = route === ROUTE && /\/(index\.php)?$/.test(url.pathname);
	return pretty || plain ? url : null;
}

// Een URL waar het script naartoe mag: alleen http(s) op dit domein, als string, of null. Voor next_url uit het
// endpoint en de href van een knop of link, die beide in window.location kunnen komen (geen javascript:).
export function sameOriginUrl(value) {
	if (typeof value !== 'string' || value.trim() === '') {
		return null;
	}
	let url;
	try {
		url = new URL(value, window.location.href);
	} catch (error) {
		return null;
	}
	const isHttp = url.protocol === 'https:' || url.protocol === 'http:';
	return isHttp && url.origin === window.location.origin ? url.href : null;
}

// Naar een andere pagina, alleen als sameOriginUrl() hem goedkeurt.
export function navigate(value) {
	const url = sameOriginUrl(value);
	if (url) {
		window.location.href = url;
	}
}

// Lijst met kaarten van een post type: het element met data-ww-list.
export function listFor(postType) {
	return document.querySelector(`[data-ww-list="${CSS.escape(postType)}"]`);
}

// Taxonomie => term-slug uit een JSON-data-attribuut; bij onzin een leeg filter.
export function parseTax(value) {
	try {
		const tax = JSON.parse(value || '{}');
		return tax && typeof tax === 'object' && !Array.isArray(tax) ? tax : {};
	} catch (error) {
		return {};
	}
}

// Haalt één pagina kaarten op: { html, has_more, next_url, total }.
// Het endpoint komt van de pagina met de taal erin (?lang=en of /en/wp-json/...); die blijft staan,
// zodat de kaarten in de taal van de pagina komen.
export async function fetchCards(endpoint, postType, page, tax, signal) {
	const url = new URL(endpoint);
	url.searchParams.set('post_type', postType);
	url.searchParams.set('page', String(page));
	for (const [name, value] of Object.entries(tax)) {
		url.searchParams.set(`tax[${name}]`, String(value));
	}

	const response = await fetch(url, { headers: { Accept: 'application/json' }, signal });
	if (!response.ok) {
		throw new Error(`HTTP ${response.status}`);
	}
	return response.json();
}

// Kaart-HTML als losse elementen, zonder scripts uit te voeren.
export function parseCards(html) {
	const template = document.createElement('template');
	template.innerHTML = typeof html === 'string' ? html : '';
	return template.content;
}

// Meldt een wijziging aan schermlezers via één verborgen aria-live-regio.
export function announce(message) {
	let region = document.querySelector('[data-ww-live]');
	if (!region) {
		region = document.createElement('div');
		region.dataset.wwLive = '';
		region.setAttribute('aria-live', 'polite');
		region.setAttribute('role', 'status');
		region.style.cssText =
			'position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap';
		document.body.append(region);
	}
	region.textContent = message;
}
