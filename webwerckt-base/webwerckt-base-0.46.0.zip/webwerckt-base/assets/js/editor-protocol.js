// De berichten tussen het adminscherm (editor.js) en de pagina in het iframe (editor-frame.js). Beide kanten nemen de
// namen hier vandaan, zodat ze niet uit elkaar kunnen lopen.

export const MESSAGE = Object.freeze({
	// Van de pagina naar het paneel.
	READY: 'ready',
	SELECT: 'select',
	SECTION: 'section',
	LIST: 'list',
	SCROLL: 'scroll',
	// Ctrl+K of ⌘K in de pagina: open het zoekvenster.
	SEARCH: 'search',
	// Van het paneel naar de pagina.
	FIELDS: 'fields',
	VALUE: 'value',
	SECTIONS: 'sections',
	LISTS: 'lists',
	DESELECT: 'deselect',
	// De accentkleur en de schaal van het voorbeeld ({ accent, scale }); de pagina antwoordt met READY.
	HELLO: 'hello',
	// De schaal van het voorbeeld is veranderd ({ scale }).
	SCALE: 'scale',
	// Zet een veld ({ field }) of sectie ({ section }) in beeld en markeer het, zonder SELECT of SECTION terug.
	REVEAL: 'reveal',
});
