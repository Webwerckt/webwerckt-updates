/**
 * Lightbox (inc/lightbox.php, ADR 0052): een klik op een a[data-ww-lightbox] opent de foto groot in de <dialog> uit
 * de footer, met bladeren door de foto's van dezelfde groep. De grote foto komt uit de <template> in de link, zodat de
 * browser zelf het passende formaat en type (AVIF/WebP) kiest. Zonder JavaScript, zonder dialoog, zonder template of
 * bij een link die niet veilig is, opent de link gewoon zijn href.
 */
( function () {
	'use strict';

	if ( typeof HTMLDialogElement === 'undefined' ) {
		return;
	}

	var root = document.documentElement;
	var state = null; // { dialog, items, index, opener, current }
	var lastSwipe = 0;

	/**
	 * Heeft deze URL dezelfde origin als de pagina? Een lege of ontbrekende URL telt niet: die zou anders naar de
	 * pagina zelf verwijzen.
	 */
	function sameOrigin( value ) {
		if ( typeof value !== 'string' || value.trim() === '' ) {
			return false;
		}
		try {
			return new URL( value.trim(), location.href ).origin === location.origin;
		} catch ( e ) {
			return false;
		}
	}

	/**
	 * De URL's uit een srcset: per kandidaat (gescheiden door komma's) het eerste woord.
	 */
	function srcsetUrls( srcset ) {
		var urls = [];
		srcset.split( ',' ).forEach( function ( candidate ) {
			var url = candidate.trim().split( /\s+/ )[ 0 ];
			if ( url ) {
				urls.push( url );
			}
		} );
		return urls;
	}

	/**
	 * De template met de grote foto, of null.
	 */
	function template( link ) {
		var tpl = link.querySelector( 'template.ww-lightbox-src' );
		return tpl && tpl.content && tpl.content.querySelector( 'img' ) ? tpl : null;
	}

	/**
	 * Een link telt alleen mee als hij een template met een foto heeft (inc/lightbox.php drukt die altijd af) en elke
	 * URL daarin (src en srcset van img en source) van deze site komt. Een zelfgeschreven link zonder template, of met
	 * een foto van elders, blijft een gewone link.
	 */
	function isSafe( link ) {
		var tpl = template( link );
		var urls = [];
		if ( ! tpl ) {
			return false;
		}
		Array.prototype.forEach.call( tpl.content.querySelectorAll( 'img, source' ), function ( node ) {
			if ( node.hasAttribute( 'src' ) ) {
				urls.push( node.getAttribute( 'src' ) );
			}
			if ( node.hasAttribute( 'srcset' ) ) {
				urls = urls.concat( srcsetUrls( node.getAttribute( 'srcset' ) ) );
			}
		} );
		return urls.length > 0 && urls.every( sameOrigin );
	}

	/**
	 * Een kopie van de grote foto voor in de dialoog: de <picture> (of <img>) uit de template. Alleen aan te roepen
	 * voor een link waarvoor isSafe() klopt.
	 *
	 * Met sizes="100vw" en w-descriptors krijgt de foto de breedte van het scherm, ook als het bestand kleiner is. De
	 * width uit de template begrenst daarom de breedte; de hoogte volgt de verhouding.
	 */
	function content( link ) {
		var source = template( link ).content.querySelector( 'img' );
		var node = document.importNode( source.closest( 'picture' ) || source, true );
		var img = node.tagName === 'IMG' ? node : node.querySelector( 'img' );
		var width = img ? img.getAttribute( 'width' ) : null;
		if ( width && /^[1-9][0-9]*$/.test( width.trim() ) ) {
			img.style.maxWidth = 'min(100%, ' + parseInt( width, 10 ) + 'px)';
		}
		return node;
	}

	function part( dialog, name ) {
		return dialog.querySelector( '.ww-lightbox__' + name );
	}

	/**
	 * Toont foto nummer index (rondgaand) uit de reeks.
	 */
	function show( index ) {
		var dialog = state.dialog;
		var count = state.items.length;
		var single = count < 2;
		var media = part( dialog, 'media' );
		var caption = part( dialog, 'caption' );
		var counter = part( dialog, 'counter' );
		var preload = part( dialog, 'preload' );
		var link, node, img, text, format, live;

		state.index = ( ( index % count ) + count ) % count;
		link = state.items[ state.index ];

		node = content( link );
		img = node.tagName === 'IMG' ? node : node.querySelector( 'img' );
		state.current = img;
		dialog.classList.add( 'is-loading' );
		if ( img ) {
			img.addEventListener( 'load', loaded );
			img.addEventListener( 'error', loaded );
		} else {
			dialog.classList.remove( 'is-loading' );
		}
		media.textContent = '';
		media.appendChild( node );

		text = link.getAttribute( 'data-ww-lightbox-caption' ) || '';
		caption.textContent = text;
		caption.hidden = text === '';

		// Eerst de teller tonen, dan pas de live-tekst zetten: in een verborgen deel wordt niets voorgelezen.
		counter.hidden = single;
		part( dialog, 'prev' ).hidden = single;
		part( dialog, 'next' ).hidden = single;
		if ( ! single ) {
			counter.firstElementChild.textContent = ( state.index + 1 ) + ' / ' + count;
			format = dialog.getAttribute( 'data-ww-counter' ) || '%1$d / %2$d';
			live = counter.querySelector( '.ww-lightbox__sr' );
			if ( live ) {
				live.textContent = format.split( '%1$d' ).join( String( state.index + 1 ) ).split( '%2$d' ).join( String( count ) );
			}
		}

		// De vorige en de volgende foto vast laden.
		preload.textContent = '';
		if ( ! single ) {
			preload.appendChild( content( state.items[ ( state.index + 1 ) % count ] ) );
			if ( count > 2 ) {
				preload.appendChild( content( state.items[ ( state.index - 1 + count ) % count ] ) );
			}
		}
	}

	function loaded( event ) {
		if ( state && event.target === state.current ) {
			state.dialog.classList.remove( 'is-loading' );
		}
	}

	function step( delta ) {
		if ( state && state.items.length > 1 ) {
			show( state.index + delta );
		}
	}

	/**
	 * Koppelt de bediening eenmalig aan de dialoog.
	 */
	function setup( dialog ) {
		var start = null;

		if ( dialog.wwLightbox ) {
			return;
		}
		dialog.wwLightbox = true;

		dialog.addEventListener( 'click', function ( event ) {
			var target = event.target;
			if ( ! state || ! ( target instanceof Element ) ) {
				return;
			}
			if ( Date.now() - lastSwipe < 400 ) {
				return; // De klik na een veegbeweging.
			}
			if ( target.closest( '.ww-lightbox__close' ) ) {
				dialog.close();
			} else if ( target.closest( '.ww-lightbox__prev' ) ) {
				step( -1 );
			} else if ( target.closest( '.ww-lightbox__next' ) ) {
				step( 1 );
			} else if ( target === dialog || target.matches( '.ww-lightbox__figure, .ww-lightbox__media' ) ) {
				dialog.close();
			}
		} );

		dialog.addEventListener( 'keydown', function ( event ) {
			if ( ! state || event.ctrlKey || event.metaKey || event.altKey || event.shiftKey ) {
				return;
			}
			if ( event.key === 'ArrowLeft' || event.key === 'ArrowRight' ) {
				if ( state.items.length > 1 ) {
					event.preventDefault();
					step( event.key === 'ArrowLeft' ? -1 : 1 );
				}
			}
		} );

		dialog.addEventListener( 'pointerdown', function ( event ) {
			start = event.pointerType === 'touch' && event.isPrimary ? { id: event.pointerId, x: event.clientX, y: event.clientY } : null;
		} );
		dialog.addEventListener( 'pointercancel', function () {
			start = null;
		} );
		dialog.addEventListener( 'pointerup', function ( event ) {
			var dx, dy;
			if ( ! start || event.pointerId !== start.id ) {
				return;
			}
			dx = event.clientX - start.x;
			dy = event.clientY - start.y;
			start = null;
			if ( Math.abs( dx ) > 50 && Math.abs( dx ) > Math.abs( dy ) && state && state.items.length > 1 ) {
				lastSwipe = Date.now();
				step( dx < 0 ? 1 : -1 );
			}
		} );

		// Escape geeft cancel en sluit de dialoog vanzelf; alle manieren van sluiten komen hier uit.
		dialog.addEventListener( 'close', function () {
			var opener;
			var live;
			if ( dialog.open ) {
				return; // Al opnieuw geopend voordat dit close-event kwam: niets wegpoetsen.
			}
			opener = state ? state.opener : null;
			live = dialog.querySelector( '.ww-lightbox__counter .ww-lightbox__sr' );
			root.classList.remove( 'ww-lightbox-open' );
			dialog.classList.remove( 'is-loading' );
			part( dialog, 'media' ).textContent = '';
			part( dialog, 'preload' ).textContent = '';
			part( dialog, 'caption' ).textContent = '';
			if ( live ) {
				live.textContent = '';
			}
			state = null;
			if ( opener && opener.isConnected ) {
				opener.focus();
			}
		} );
	}

	document.addEventListener( 'click', function ( event ) {
		if ( event.defaultPrevented || event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey ) {
			return; // Nieuw tabblad of venster: laat de link gewoon openen.
		}
		var link = event.target instanceof Element ? event.target.closest( 'a[data-ww-lightbox]' ) : null;
		var dialog = document.querySelector( 'dialog.ww-lightbox' );
		var group, items;
		if ( ! link || ! dialog || ! dialog.isConnected || typeof dialog.showModal !== 'function' || dialog.open || ! isSafe( link ) ) {
			return;
		}
		if ( ! part( dialog, 'media' ) || ! part( dialog, 'caption' ) || ! part( dialog, 'counter' ) || ! part( dialog, 'preload' ) ||
			! part( dialog, 'prev' ) || ! part( dialog, 'next' ) ) {
			return;
		}

		group = link.getAttribute( 'data-ww-lightbox' ) || '';
		items = group === '' ? [ link ] : Array.prototype.filter.call( document.querySelectorAll( 'a[data-ww-lightbox]' ), function ( a ) {
			return a.getAttribute( 'data-ww-lightbox' ) === group && isSafe( a );
		} );

		event.preventDefault();
		setup( dialog );
		state = { dialog: dialog, items: items, index: 0, opener: link, current: null };
		try {
			dialog.showModal();
		} catch ( e ) {
			state = null;
			location.href = link.href; // De dialoog kan niet open: dan alsnog het bestand.
			return;
		}
		root.classList.add( 'ww-lightbox-open' );
		show( items.indexOf( link ) );
	} );
}() );
