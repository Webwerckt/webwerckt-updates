<?php
/**
 * Vangnet: verplicht voor elk thema. Het uiterlijk staat in het child-thema.
 *
 * Heeft het child-thema geen 404.php, search.php of eigen index.php, dan toont dit bestand voor de 404 en de
 * zoekresultaten een kale, bruikbare versie: de teksten uit de Site-instellingen (in Visueel bewerken aan te klikken),
 * de suggesties of de resultaten als lijst met links. Zonder CSS van de parent: het mag lelijk zijn, niet kapot.
 * Een eigen index.php van het child-thema gaat voor (de templatevolgorde van WordPress); dat child-thema maakt zijn
 * 404.php en search.php zelf (regel 126).
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<main>
<?php if ( is_404() ) : ?>
	<h1 <?php echo ww_setting_attrs( 'notfound_title' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- ge-escaped attribuut. ?>><?php echo ww_setting( 'notfound_title' ) ?: esc_html__( 'Pagina niet gevonden', 'webwerckt-base' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- ww_setting() is veilige HTML. ?></h1>
	<div <?php echo ww_setting_attrs( 'notfound_text' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- ge-escaped attribuut. ?>><?php echo wpautop( ww_setting( 'notfound_text' ) ?: esc_html__( 'Deze pagina bestaat niet (meer). Misschien zoek je een van deze pagina\'s.', 'webwerckt-base' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- ww_setting() is veilige HTML. ?></div>
	<?php $ww_suggestions = ww_404_suggestions(); ?>
	<?php if ( array() !== $ww_suggestions ) : ?>
		<ul <?php echo ww_setting_attrs( 'notfound_pages' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- ge-escaped attribuut. ?>>
			<?php foreach ( $ww_suggestions as $ww_id ) : ?>
				<li><a href="<?php echo esc_url( (string) get_permalink( $ww_id ) ); ?>"><?php echo esc_html( get_the_title( $ww_id ) ); ?></a></li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>
	<?php get_search_form(); ?>
<?php elseif ( is_search() ) : ?>
	<h1>
		<?php
		/* translators: %s: de zoekopdracht. */
		printf( esc_html__( 'Zoekresultaten voor „%s”', 'webwerckt-base' ), esc_html( get_search_query( false ) ) );
		?>
	</h1>
	<?php get_search_form(); ?>
	<?php $ww_counts = ww_search_counts(); ?>
	<?php if ( count( $ww_counts ) > 1 ) : ?>
		<ul>
			<?php foreach ( $ww_counts as $ww_group ) : ?>
				<li><a href="<?php echo $ww_group['url']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- ge-escaped door ww_search_counts(). ?>"<?php echo $ww_group['current'] ? ' aria-current="page"' : ''; ?>><?php echo $ww_group['label']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- ge-escaped door ww_search_counts(). ?> (<?php echo (int) $ww_group['count']; ?>)</a></li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>
	<?php if ( have_posts() ) : ?>
		<ul>
			<?php while ( have_posts() ) : ?>
				<?php the_post(); ?>
				<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
			<?php endwhile; ?>
		</ul>
		<?php the_posts_pagination(); ?>
	<?php else : ?>
		<div <?php echo ww_setting_attrs( 'search_empty_text' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- ge-escaped attribuut. ?>><?php echo wpautop( ww_setting( 'search_empty_text' ) ?: esc_html__( 'Niets gevonden. Probeer een ander woord.', 'webwerckt-base' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- ww_setting() is veilige HTML. ?></div>
	<?php endif; ?>
<?php else : ?>
	<h1><?php echo esc_html( get_the_title() ); ?></h1>
<?php endif; ?>
</main>
<?php wp_footer(); ?>
</body>
</html>
