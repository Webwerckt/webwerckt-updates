<?php
/**
 * Plugin Name: Webwerckt Base: paginacache
 * Description: Stuurt bezoekers zonder login een bewaarde pagina van het thema webwerckt-base, vóór de plugins en het thema laden. Het thema installeert en ververst dit bestand zelf; aanpassen heeft geen zin.
 *
 * Het thema bewaart de pagina's (inc/page-cache.php); dit bestand laadt alleen inc/page-cache-serve.php uit het
 * thema en serveert daarmee (beslissing 0028). Uitzetten: define( 'WW_PAGE_CACHE', false ); in wp-config.php.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( 'webwerckt-base' === get_template() ) {
	// Hetzelfde pad als functions.php (WW_BASE_DIR), zodat require_once het bestand maar één keer laadt.
	$ww_page_cache_serve = get_template_directory() . '/inc/page-cache-serve.php';
	if ( is_readable( $ww_page_cache_serve ) ) {
		require_once $ww_page_cache_serve;
		_ww_page_cache_serve();
	}
	unset( $ww_page_cache_serve );
}
