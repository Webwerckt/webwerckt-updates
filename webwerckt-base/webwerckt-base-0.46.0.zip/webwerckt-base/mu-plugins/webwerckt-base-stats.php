<?php
/**
 * Plugin Name: Webwerckt Base: statistieken
 * Description: Neemt de paginatreffers van het thema webwerckt-base aan, vóór de plugins en het thema laden. Het thema installeert en ververst dit bestand zelf; aanpassen heeft geen zin.
 *
 * Alleen bij een verzoek met ?ww_hit laadt dit bestand inc/stats-collect.php uit het thema; dat verwerkt de treffer
 * als het verzoek op de voorkant (index.php) binnenkomt (beslissing 0038). Alle andere verzoeken gaan ongemoeid door.
 * Het thema laadt het beacon alleen als dit bestand er staat.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- anoniem meetpunt; het beveiligt zichzelf met een Origin-controle.
if ( isset( $_GET['ww_hit'] ) && 'webwerckt-base' === get_template() ) {
	// Hetzelfde pad als functions.php (WW_BASE_DIR), zodat require_once het bestand maar één keer laadt.
	$ww_stats_collect = get_template_directory() . '/inc/stats-collect.php';
	if ( is_readable( $ww_stats_collect ) ) {
		require_once $ww_stats_collect;
		_ww_stats_collect();
	}
	unset( $ww_stats_collect );
}
