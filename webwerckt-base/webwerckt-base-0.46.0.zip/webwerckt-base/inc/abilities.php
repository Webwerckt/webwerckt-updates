<?php
/**
 * Abilities (WordPress 6.9+) waarmee een AI-agent via de MCP Adapter of de REST API een site inricht:
 * berichten zoeken en als concept aanmaken, het paginatemplate kiezen, de velden van een bericht en de
 * Site-instellingen lezen en schrijven, menu's lezen en vullen, en afbeeldingen zoeken, uploaden en bijwerken (beslissing 0018).
 *
 * - De velden komen uit de veldconfiguratie (pods/*.json) van parent en child-thema. Een bericht krijgt alleen de velden die
 *   ook in de admin bij zijn paginatemplate staan; onbekende velden en verkeerde waarden worden geweigerd.
 * - Schrijven loopt via de opslaglaag van het thema (inc/field-store.php) en daarna wp_update_post(), net als
 *   "Bijwerken" in de admin:
 *   revisie, de kopie naar post_content en het legen van de cache gaan zo vanzelf mee.
 * - Elke ability controleert de rechten die de admin ook vraagt. Schrijven kan alleen als WW_ABILITIES_WRITE_HOST
 *   in wp-config.php gelijk is aan de host van de site (het staging-slot). Na een verhuizing naar het live
 *   domein klopt de host niet meer en staat schrijven vanzelf uit; lezen blijft werken.
 * - Nieuwe berichten zijn altijd een concept: publiceren gebeurt in de admin.
 * - Uploaden neemt alleen afbeeldingen aan en loopt via media_handle_sideload(), net als de uploader in de admin.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Categorie van de abilities.
 */
function _ww_abilities_register_category(): void {
	wp_register_ability_category(
		'webwerckt',
		array(
			'label'       => __( 'Webwerckt-site', 'webwerckt-base' ),
			'description' => __( 'Content, velden, Site-instellingen en menu\'s van een site met webwerckt-base.', 'webwerckt-base' ),
		)
	);
}
add_action( 'wp_abilities_api_categories_init', '_ww_abilities_register_category' );

/**
 * Registreert één ability in de categorie webwerckt, beschikbaar voor de REST API en de MCP Adapter.
 *
 * @param array<string,mixed> $input_schema JSON Schema van de invoer.
 * @param callable            $execute      Voert de ability uit.
 * @param callable            $permission   Mag de huidige gebruiker dit (bool of WP_Error)?
 * @param bool                $readonly     Leest alleen.
 * @param bool                $destructive  Kan bestaande gegevens vervangen of verwijderen.
 * @param bool                $idempotent   Twee keer dezelfde aanroep geeft hetzelfde resultaat.
 */
function _ww_register_ability( string $name, string $label, string $description, array $input_schema, callable $execute, callable $permission, bool $readonly, bool $destructive = false, bool $idempotent = true ): void {
	wp_register_ability(
		'webwerckt/' . $name,
		array(
			'label'               => $label,
			'description'         => $description,
			'category'            => 'webwerckt',
			'input_schema'        => $input_schema,
			// Het staging-slot hier en niet in de permissiecheck: WordPress geeft de melding van een geweigerde
			// permissie niet door aan de aanroeper, en dan weet de agent niet waarom schrijven niet lukt.
			'execute_callback'    => $readonly ? $execute : static fn( $input = array() ) => _ww_abilities_write_lock( $name, (array) $input ) ?? $execute( $input ),
			'permission_callback' => $permission,
			'meta'                => array(
				'public'      => true,
				// MCP Adapter 0.6+ leidt dit af van public; oudere versies lezen alleen mcp.public.
				'mcp'         => array( 'public' => true ),
				'annotations' => array(
					'readonly'    => $readonly,
					'destructive' => $destructive,
					'idempotent'  => $idempotent,
				),
			),
		)
	);
}

/**
 * JSON Schema van een object met deze eigenschappen.
 *
 * @param array<string,array<string,mixed>> $properties Eigenschappen.
 * @param string[]                          $required   Verplichte eigenschappen.
 * @return array<string,mixed>
 */
function _ww_abilities_schema( array $properties, array $required = array() ): array {
	return array(
		'type'                 => 'object',
		'properties'           => $properties,
		'required'             => $required,
		'additionalProperties' => false,
		'default'              => array(),
	);
}

/**
 * Registreert de abilities.
 */
function _ww_abilities_register(): void {
	$post_id = array(
		'type'        => 'integer',
		'minimum'     => 1,
		'description' => 'ID van het bericht of de pagina.',
	);
	$fields  = array(
		'type'                 => 'object',
		'minProperties'        => 1,
		'additionalProperties' => true,
		'description'          => 'Veldnaam => waarde. Tekst als string, ja/nee als boolean, een foto als attachment-ID, meerdere foto\'s als lijst met attachment-ID\'s, een relatie als lijst met post-ID\'s (een relatie met termen, met taxonomy bij het veld, als lijst met term-ID\'s). Een meerkeuze krijgt een van de waarden uit choices (value, niet het label), met multiple een lijst met waarden. Een datum als JJJJ-MM-DD, een tijd als UU:MM of UU:MM:SS, een datum met tijd als JJJJ-MM-DD UU:MM:SS (ook JJJJ-MM-DDTUU:MM); het formaat staat bij het veld als format. null of een lege string maakt het veld leeg.',
	);

	// Met Meertalig actief: een taalfilter op list-posts en get-seo, en create-translation. Zonder blijft alles zoals het was.
	$lang_filter = _ww_languages_active()
		? array(
			'lang' => array(
				'type'        => 'string',
				'description' => 'Alleen berichten in deze taal (taalcode). Zonder lang alle talen.',
			),
		)
		: array();

	_ww_register_ability(
		'list-posts',
		__( 'Berichten zoeken', 'webwerckt-base' ),
		__( 'Geeft berichten van een post type (page, post, service, …) met ID, titel, status, paginatemplate en link. Ook concepten. Gebruik de ID bij webwerckt/get-fields en webwerckt/update-fields.', 'webwerckt-base' ),
		_ww_abilities_schema(
			array(
				'post_type' => array( 'type' => 'string' ),
				'search'    => array( 'type' => 'string' ),
				'per_page'  => array(
					'type'    => 'integer',
					'minimum' => 1,
					'maximum' => 100,
					'default' => 20,
				),
			) + $lang_filter,
			array( 'post_type' )
		),
		'_ww_ability_list_posts',
		'_ww_ability_can_list_posts',
		true
	);

	_ww_register_ability(
		'create-post',
		__( 'Concept aanmaken', 'webwerckt-base' ),
		__( 'Maakt een nieuw bericht als concept, eventueel met een paginatemplate (alleen voor beheerders). Publiceren gebeurt in de admin.', 'webwerckt-base' ),
		_ww_abilities_schema(
			array(
				'post_type' => array( 'type' => 'string' ),
				'title'     => array(
					'type'      => 'string',
					'minLength' => 1,
				),
				'template'  => array(
					'type'        => 'string',
					'description' => 'Bestandsnaam van het paginatemplate, bijvoorbeeld page-home.php.',
				),
			),
			array( 'post_type', 'title' )
		),
		'_ww_ability_create_post',
		'_ww_ability_can_create_post',
		false
	);

	_ww_register_ability(
		'set-template',
		__( 'Paginatemplate kiezen', 'webwerckt-base' ),
		__( 'Zet het paginatemplate van een pagina (bijvoorbeeld page-home.php, of default voor de tekstpagina). Het template bepaalt welke velden de pagina heeft. Alleen voor beheerders.', 'webwerckt-base' ),
		_ww_abilities_schema(
			array(
				'post_id'  => $post_id,
				'template' => array( 'type' => 'string' ),
			),
			array( 'post_id', 'template' )
		),
		'_ww_ability_set_template',
		'_ww_ability_can_set_template',
		false
	);

	_ww_register_ability(
		'get-fields',
		__( 'Velden lezen', 'webwerckt-base' ),
		__( 'Geeft de velden van een bericht zoals de admin ze toont bij zijn paginatemplate: naam, label, type en huidige waarde; bij een relatie, meerkeuze of foto ook multiple, bij een meerkeuze de keuzes (choices: value en label) en bij een datum of tijd het formaat (format). Lees dit vóór webwerckt/update-fields.', 'webwerckt-base' ),
		_ww_abilities_schema( array( 'post_id' => $post_id ), array( 'post_id' ) ),
		'_ww_ability_get_fields',
		'_ww_ability_can_edit_post',
		true
	);

	_ww_register_ability(
		'update-fields',
		__( 'Velden opslaan', 'webwerckt-base' ),
		__( 'Slaat velden van een bericht op, alleen velden die webwerckt/get-fields voor dat bericht noemt. Werkt als Bijwerken in de admin (revisie, zoekindex, cache). Geeft de velden daarna terug.', 'webwerckt-base' ),
		_ww_abilities_schema(
			array(
				'post_id' => $post_id,
				'fields'  => $fields,
			),
			array( 'post_id', 'fields' )
		),
		'_ww_ability_update_fields',
		'_ww_ability_can_edit_post',
		false
	);

	if ( _ww_languages_active() ) {
		_ww_register_ability(
			'create-translation',
			__( 'Vertaling maken', 'webwerckt-base' ),
			__( 'Maakt een vertaling van een bericht in een extra taal, altijd als concept (publiceren doet de klant). Werkwijze: lees de bron met webwerckt/get-fields, maak de vertaling hier (met een vertaalde title en slug als je die al hebt), vertaal de teksten en schrijf ze met webwerckt/update-fields op de ID van de vertaling. Template, foto\'s, sectieschakelaars, SEO-velden en relaties zijn al overgenomen; wat nog niet vertaald is, staat in dropped. webwerckt/list-posts geeft per vertaling source_newer: de bron is later gewijzigd dan de vertaling; vergelijk dan de bron met de vertaling en beslis zelf of er iets moet worden aangepast.', 'webwerckt-base' ),
			_ww_abilities_schema(
				array(
					'post_id' => $post_id,
					'lang'    => array(
						'type'        => 'string',
						'minLength'   => 1,
						'description' => 'Taalcode van een extra taal, bijvoorbeeld en.',
					),
					'title'   => array( 'type' => 'string' ),
					'slug'    => array( 'type' => 'string' ),
				),
				array( 'post_id', 'lang' )
			),
			'_ww_ability_create_translation',
			'_ww_ability_can_create_translation',
			false,
			false,
			false
		);
	}

	_ww_register_ability(
		'duplicate-post',
		__( 'Bericht dupliceren', 'webwerckt-base' ),
		__( 'Dupliceert een pagina of bericht als nieuw concept (publiceren doet de klant), met de titel Kopie van … tenzij je een title meegeeft. De kopie krijgt dezelfde template, velden, relaties, termen, bovenliggende pagina, volgorde, uitgelichte afbeelding, samenvatting en SEO-titel, -beschrijving en -afbeelding, en bij Meertalig dezelfde taal (zonder vertaalgroep). De slug blijft leeg, de auteur is de huidige gebruiker; canonical, noindex, wachtwoord, revisies en menu-items gaan niet mee. Wat niet mee kon (een verwijderde foto, bestand, term of gebruiker, een verwijderde of weggegooide relatie of bovenliggende pagina, een opgeslagen waarde die niet meer klopt, een veld dat je niet mag bewerken) staat in dropped en dropped_labels.', 'webwerckt-base' ),
		_ww_abilities_schema(
			array(
				'post_id' => $post_id,
				'title'   => array( 'type' => 'string' ),
			),
			array( 'post_id' )
		),
		'_ww_ability_duplicate_post',
		'_ww_ability_can_duplicate_post',
		false,
		false,
		false
	);

	_ww_register_ability(
		'list-terms',
		__( 'Termen zoeken', 'webwerckt-base' ),
		__( 'Geeft de termen van een taxonomie (projectcategorie, tag, …) met ID, naam, slug, beschrijving en aantal. Met Meertalig actief ook translations: per extra taal naam, slug en beschrijving, of null zonder vertaling. De gewone waarden zijn die van de standaardtaal.', 'webwerckt-base' ),
		_ww_abilities_schema(
			array(
				'taxonomy' => array( 'type' => 'string' ),
				'search'   => array( 'type' => 'string' ),
				'per_page' => array(
					'type'    => 'integer',
					'minimum' => 1,
					'maximum' => 100,
					'default' => 20,
				),
			),
			array( 'taxonomy' )
		),
		'_ww_ability_list_terms',
		'_ww_ability_can_list_terms',
		true
	);

	if ( _ww_languages_active() ) {
		_ww_register_ability(
			'update-term-translation',
			__( 'Termvertaling opslaan', 'webwerckt-base' ),
			__( 'Slaat de naam, slug en beschrijving van een term in een extra taal op (de gewone term blijft de standaardtaal). Alleen de meegegeven velden veranderen; een lege waarde wist dat veld. Geeft de term zoals webwerckt/list-terms. Zoek de term-ID met webwerckt/list-terms.', 'webwerckt-base' ),
			_ww_abilities_schema(
				array(
					'term_id'     => array(
						'type'    => 'integer',
						'minimum' => 1,
					),
					'lang'        => array(
						'type'        => 'string',
						'minLength'   => 1,
						'description' => 'Taalcode van een extra taal, bijvoorbeeld en.',
					),
					'name'        => array( 'type' => 'string' ),
					'slug'        => array( 'type' => 'string' ),
					'description' => array( 'type' => 'string' ),
				),
				array( 'term_id', 'lang' )
			),
			'_ww_ability_update_term_translation',
			'_ww_ability_can_update_term_translation',
			false
		);
	}

	if ( _ww_languages_active() ) {
		_ww_register_ability(
			'get-languages',
			__( 'Talen lezen', 'webwerckt-base' ),
			__( 'Geeft de standaardtaal (default) en per taal code, locale, naam, default, visible, de ondertitel (tagline), de vertaalde URL-basissen (bases: post type- of taxonomienaam => basis) en de objecten met een vertaalbare basis (objects: naam => type, base (de basis van de standaardtaal) en label). De standaardtaal heeft geen bases en geen objects. Alleen voor beheerders.', 'webwerckt-base' ),
			_ww_abilities_schema( array() ),
			'_ww_ability_get_languages',
			'_ww_ability_can_manage_languages',
			true
		);

		_ww_register_ability(
			'set-url-bases',
			__( 'URL-basis per taal opslaan', 'webwerckt-base' ),
			__( 'Zet de vertaalde URL-basis van archieven en termarchieven in een extra taal (/en/projects/ in plaats van /en/projecten/). Alleen de meegegeven namen veranderen; een lege waarde zet de basis van de standaardtaal terug. Een basis mag niet gelijk zijn aan een andere basis in die taal, een taalcode, een vast adres van WordPress of de slug van een pagina op het hoogste niveau in die taal (fout ww_language_base_taken). Zie webwerckt/get-languages voor de namen. Alleen voor beheerders, en niet op productie: een basis wijzigen verandert adressen die zoekmachines kennen.', 'webwerckt-base' ),
			_ww_abilities_schema(
				array(
					'lang'  => array(
						'type'        => 'string',
						'minLength'   => 1,
						'description' => 'Taalcode van een extra taal, bijvoorbeeld en.',
					),
					'bases' => array(
						'type'                 => 'object',
						'additionalProperties' => array( 'type' => 'string' ),
						'description'          => 'Post type- of taxonomienaam => vertaalde basis, bijvoorbeeld { "project": "projects" }.',
					),
				),
				array( 'lang', 'bases' )
			),
			'_ww_ability_set_url_bases',
			'_ww_ability_can_manage_languages',
			false
		);

		_ww_register_ability(
			'set-language-tagline',
			__( 'Ondertitel per taal opslaan', 'webwerckt-base' ),
			__( 'Zet de ondertitel van een extra taal; die verschijnt op de frontend in die taal (titel van de homepage, schema, get_bloginfo met description). Een lege tekst wist hem: dan geldt de ondertitel van de standaardtaal. De ondertitel van de standaardtaal is de blogdescription (Instellingen → Algemeen): fout ww_language_default. Alleen voor beheerders; mag ook op productie, het is tekst in een extra taal.', 'webwerckt-base' ),
			_ww_abilities_schema(
				array(
					'lang'    => array(
						'type'        => 'string',
						'minLength'   => 1,
						'description' => 'Taalcode van een extra taal, bijvoorbeeld en.',
					),
					'tagline' => array(
						'type'        => 'string',
						'description' => 'De ondertitel; leeg wist hem.',
					),
				),
				array( 'lang', 'tagline' )
			),
			'_ww_ability_set_language_tagline',
			'_ww_ability_can_manage_languages',
			false
		);
	}

	// Met Meertalig actief: de taal waarin de vertaalbare Site-instellingen gelezen en bewaard worden (beslissing 0042).
	$settings_lang = _ww_languages_active()
		? array(
			'lang' => array(
				'type'        => 'string',
				'description' => 'Taalcode van een extra taal, bijvoorbeeld en. Per veld value (de waarde in die taal, of null), fallback (de waarde van de standaardtaal) en translatable. Bij update-settings alleen vertaalbare velden; een lege waarde wist de vertaling. Zonder lang of met de standaardtaal gelden de waarden van de standaardtaal.',
			),
		)
		: array();

	_ww_register_ability(
		'get-settings',
		__( 'Site-instellingen lezen', 'webwerckt-base' ),
		__( 'Geeft de velden van de Site-instellingen (contactgegevens, social media, velden van het child-thema) met label, type en huidige waarde, en multiple, choices en format zoals bij webwerckt/get-fields.', 'webwerckt-base' ),
		_ww_abilities_schema( $settings_lang ),
		'_ww_ability_get_settings',
		'_ww_ability_can_edit_settings',
		true
	);

	_ww_register_ability(
		'get-schema',
		__( 'Structured data bekijken', 'webwerckt-base' ),
		__( 'Geeft de JSON-LD-graph die het thema in de head zet: van de homepage, of van een gepubliceerd bericht of pagina (post_id). Met enabled (levert het thema het schema), plugin (een andere SEO-plugin die het overneemt) en missing (wat er in de Site-instellingen nog ontbreekt voor een volledige organisatie).', 'webwerckt-base' ),
		_ww_abilities_schema(
			array(
				'post_id' => array(
					'type'        => 'integer',
					'minimum'     => 0,
					'default'     => 0,
					'description' => 'ID van een gepubliceerd bericht of pagina; 0 is de homepage.',
				),
			)
		),
		'_ww_ability_get_schema',
		'_ww_ability_can_list_schema',
		true
	);

	_ww_register_ability(
		'get-seo',
		__( 'SEO van berichten bekijken', 'webwerckt-base' ),
		__( 'Geeft per gepubliceerd bericht van een post type de SEO-velden (ww_seo_title, ww_seo_description, ww_seo_image, ww_seo_schema_type, ww_seo_canonical, ww_seo_noindex) en het oordeel van het thema: missing, short, long of good voor titel en beschrijving, missing of good voor de afbeelding. Met limits (goede lengte in tekens) en plugin (een SEO-plugin die het overneemt). Schrijven gaat met webwerckt/update-fields.', 'webwerckt-base' ),
		_ww_abilities_schema(
			array(
				'post_type' => array( 'type' => 'string' ),
				'only_issues' => array(
					'type'        => 'boolean',
					'default'     => false,
					'description' => 'Alleen berichten zonder noindex waar titel, beschrijving of afbeelding niet goed is.',
				),
			) + $lang_filter,
			array( 'post_type' )
		),
		'_ww_ability_get_seo',
		'_ww_ability_can_list_posts',
		true
	);

	_ww_register_ability(
		'update-settings',
		__( 'Site-instellingen opslaan', 'webwerckt-base' ),
		__( 'Slaat velden van de Site-instellingen op, alleen velden die webwerckt/get-settings noemt. Leegt daarna de cache van de site.', 'webwerckt-base' ),
		_ww_abilities_schema( array( 'fields' => $fields ) + $settings_lang, array( 'fields' ) ),
		'_ww_ability_update_settings',
		'_ww_ability_can_edit_settings',
		false
	);

	_ww_register_ability(
		'get-menus',
		__( 'Menu\'s lezen', 'webwerckt-base' ),
		__( 'Geeft alle menulocaties van het thema met het menu dat erop staat en zijn items als boom.', 'webwerckt-base' ),
		_ww_abilities_schema( array() ),
		'_ww_ability_get_menus',
		'_ww_ability_can_edit_menus',
		true
	);

	_ww_register_ability(
		'set-menu',
		__( 'Menu vullen', 'webwerckt-base' ),
		__( 'Vervangt de items van het menu op een menulocatie (maakt het menu aan als er nog geen is). Elk item heeft een post_id (een pagina of bericht) of een url, een optionele title en optioneel children. Alleen voor beheerders.', 'webwerckt-base' ),
		_ww_abilities_schema(
			array(
				'location' => array( 'type' => 'string' ),
				'items'    => array(
					'type'  => 'array',
					'items' => array( 'type' => 'object' ),
				),
			),
			array( 'location', 'items' )
		),
		'_ww_ability_set_menu',
		'_ww_ability_can_edit_menus',
		false,
		true
	);

	_ww_register_ability(
		'upload-media',
		__( 'Afbeelding uploaden', 'webwerckt-base' ),
		__( 'Zet een afbeelding (jpg, png, gif, webp of avif) in de mediabibliotheek, uit base64-data of van een openbare URL, met een alt-tekst. Geeft de attachment-ID voor een fotoveld in webwerckt/update-fields. Elke aanroep maakt een nieuwe bijlage.', 'webwerckt-base' ),
		_ww_abilities_schema(
			array(
				'filename' => array(
					'type'        => 'string',
					'minLength'   => 1,
					'description' => 'Bestandsnaam met extensie, bijvoorbeeld hero-bestelbussen.jpg.',
				),
				'data'     => array(
					'type'        => 'string',
					'description' => 'Inhoud van het bestand als base64, eventueel als data-URL. Gebruik data of url.',
				),
				'url'      => array(
					'type'        => 'string',
					'description' => 'Openbare https-URL van de afbeelding. Gebruik data of url.',
				),
				'alt'      => array(
					'type'        => 'string',
					'description' => 'Alt-tekst: wat er op de foto staat. Leeg voor een decoratieve afbeelding.',
				),
				'title'    => array(
					'type'        => 'string',
					'description' => 'Titel in de mediabibliotheek; standaard de bestandsnaam.',
				),
			),
			array( 'filename' )
		),
		'_ww_ability_upload_media',
		'_ww_ability_can_upload_media',
		false,
		false,
		false
	);

	_ww_register_ability(
		'list-media',
		__( 'Afbeeldingen zoeken', 'webwerckt-base' ),
		__( 'Zoekt afbeeldingen in de mediabibliotheek op titel of bestandsnaam, nieuwste eerst, met ID, URL, alt-tekst, afmetingen en de beschikbare formaten. Gebruik de ID in een fotoveld bij webwerckt/update-fields; zoek eerst hier voordat je een foto opnieuw uploadt.', 'webwerckt-base' ),
		_ww_abilities_schema(
			array(
				'search'   => array(
					'type'        => 'string',
					'description' => 'Woord uit de titel of de bestandsnaam; leeg voor de nieuwste afbeeldingen.',
				),
				'per_page' => array(
					'type'    => 'integer',
					'minimum' => 1,
					'maximum' => 100,
					'default' => 20,
				),
			)
		),
		'_ww_ability_list_media',
		'_ww_ability_can_upload_media',
		true
	);

	_ww_register_ability(
		'update-media',
		__( 'Afbeelding bijwerken', 'webwerckt-base' ),
		__( 'Past de alt-tekst en/of de titel van een afbeelding in de mediabibliotheek aan, net als in de admin. Velden die je weglaat blijven zoals ze zijn; een lege alt-tekst maakt de afbeelding decoratief. Zoek de ID met webwerckt/list-media.', 'webwerckt-base' ),
		_ww_abilities_schema(
			array(
				'id'    => array(
					'type'        => 'integer',
					'minimum'     => 1,
					'description' => 'ID van de afbeelding.',
				),
				'alt'   => array(
					'type'        => 'string',
					'description' => 'Alt-tekst: wat er op de foto staat. Leeg voor een decoratieve afbeelding.',
				),
				'title' => array(
					'type'      => 'string',
					'minLength' => 1,
				),
			),
			array( 'id' )
		),
		'_ww_ability_update_media',
		'_ww_ability_can_edit_media',
		false
	);

	$redirect_page = array(
		'type'    => 'integer',
		'minimum' => 1,
		'default' => 1,
	);
	$redirect_per  = array(
		'type'    => 'integer',
		'minimum' => 1,
		'maximum' => 500,
		'default' => 100,
	);

	_ww_register_ability(
		'import-redirects',
		__( 'Redirects importeren', 'webwerckt-base' ),
		__( 'Voegt redirects toe of werkt ze bij (bijvoorbeeld de lijst voor een relaunch), hoogstens 5000 per aanroep. Per regel is het resultaat new, update, unchanged of error (met reden). Standaard staat dry_run aan: dan wordt er niets opgeslagen en zie je alleen het voorbeeld; stuur dry_run false om echt te importeren. Een kring binnen de lijst ziet alleen de echte import. Status is 301 (standaard), 302 of 410 (dan is een doel niet nodig); type is exact (standaard) of prefix (ook alles eronder).', 'webwerckt-base' ),
		_ww_abilities_schema(
			array(
				'rules'   => array(
					'type'     => 'array',
					'maxItems' => 5000,
					'items'    => _ww_abilities_schema(
						array(
							'source' => array(
								'type'        => 'string',
								'description' => 'Oud pad of oude URL op deze site, bijvoorbeeld /oude-pagina/.',
							),
							'target' => array(
								'type'        => 'string',
								'description' => 'Nieuw pad (begint met /) of volledige URL; leeg bij 410.',
							),
							'status' => array(
								'type' => 'integer',
								'enum' => array( 301, 302, 410 ),
							),
							'type'   => array(
								'type' => 'string',
								'enum' => array( 'exact', 'prefix' ),
							),
						),
						array( 'source' )
					),
				),
				'dry_run' => array(
					'type'        => 'boolean',
					'default'     => true,
					'description' => 'Standaard true: alleen een voorbeeld, er wordt niets opgeslagen.',
				),
			),
			array( 'rules' )
		),
		'_ww_ability_import_redirects',
		'_ww_ability_can_manage_redirects',
		false,
		false,
		true
	);

	_ww_register_ability(
		'list-redirects',
		__( 'Redirects bekijken', 'webwerckt-base' ),
		__( 'Geeft de redirects met bron, doel, status, type, herkomst (manual, import of slug) en het aantal keer gebruikt, plus het totaal. Zoek in bron en doel met search; hoogstens 500 per pagina (standaard 100).', 'webwerckt-base' ),
		_ww_abilities_schema(
			array(
				'search'   => array( 'type' => 'string' ),
				'origin'   => array(
					'type' => 'string',
					'enum' => array( 'manual', 'import', 'slug' ),
				),
				'page'     => $redirect_page,
				'per_page' => $redirect_per,
			)
		),
		'_ww_ability_list_redirects',
		'_ww_ability_can_manage_redirects',
		true
	);

	_ww_register_ability(
		'list-404-log',
		__( '404-logboek bekijken', 'webwerckt-base' ),
		__( 'Geeft de paden die bezoekers vroegen maar niet bestonden, meest gevraagd eerst, met aantal, eerste en laatste keer en de verwijzer, plus het totaal. Gebruik min_hits om incidenten weg te laten; hoogstens 500 per pagina (standaard 100). Maak er een redirect voor met webwerckt/import-redirects.', 'webwerckt-base' ),
		_ww_abilities_schema(
			array(
				'min_hits' => array(
					'type'    => 'integer',
					'minimum' => 1,
				),
				'page'     => $redirect_page,
				'per_page' => $redirect_per,
			)
		),
		'_ww_ability_list_404_log',
		'_ww_ability_can_manage_redirects',
		true
	);

	_ww_register_ability(
		'save-form',
		__( 'Formulier opslaan', 'webwerckt-base' ),
		__( 'Maakt een formulier (zonder id) of werkt er een bij (met id). De configuratie gaat door dezelfde opschoning als de builder in de admin; het antwoord geeft de opgeslagen configuratie en de waarschuwingen terug. Zonder status wordt een nieuw formulier een concept. Op productie (met Meertalig, een formulier in een extra taal) mogen alleen teksten veranderen: mail.notify.to en enabled, storage en after.type, page_id en url blijven zoals ze zijn en een concept publiceren kan niet; een andere waarde geeft ww_abilities_locked, weglaten of ongewijzigd meesturen mag. Alleen voor beheerders.', 'webwerckt-base' ),
		_ww_abilities_schema(
			array(
				'id'     => array(
					'type'    => 'integer',
					'minimum' => 1,
				),
				'title'  => array( 'type' => 'string' ),
				'slug'   => array( 'type' => 'string' ),
				'status' => array(
					'type' => 'string',
					'enum' => array( 'publish', 'draft' ),
				),
				'config' => array(
					'type'                 => 'object',
					'additionalProperties' => true,
					'description'          => 'De configuratie van het formulier met de sleutels fields, submit_label, steps (optioneel: een lijst { key, title, from }; from is de sleutel of de positie (vanaf 0) van het eerste veld van de stap; hoogstens 10; één stap wordt een gewoon formulier), mail (mail.notify en mail.confirm), after, storage en recaptcha (true of false: reCAPTCHA gebruiken als de sleutels zijn ingesteld); andere sleutels worden weggelaten met een waarschuwing. Een veld van het type file heeft accept (een lijst groepsleutels: documents, images, spreadsheets; standaard documents, onbekende waarden vallen daarop terug), max_size_mb (1 tot 20, nooit boven de serverlimiet) en max_files (1 tot 5); een formulier met een bestandsveld slaat inzendingen altijd op. Zie webwerckt/list-forms voor een voorbeeld.',
				),
			)
		),
		'_ww_ability_save_form',
		'_ww_ability_can_manage_forms',
		false,
		false,
		false
	);

	_ww_register_ability(
		'list-forms',
		__( 'Formulieren bekijken', 'webwerckt-base' ),
		__( 'Geeft alle formulieren met ID, titel, slug, status, taal (als er een vertaalplugin is) en configuratie. Alleen voor beheerders.', 'webwerckt-base' ),
		_ww_abilities_schema( array() ),
		'_ww_ability_list_forms',
		'_ww_ability_can_manage_forms',
		true
	);

	_ww_register_ability(
		'list-form-entries',
		__( 'Inzendingen bekijken', 'webwerckt-base' ),
		__( 'Geeft inzendingen van formulieren, nieuwste eerst, met velden, pagina, status, controle door reCAPTCHA en mailstatus, plus het totaal; hoogstens 500 per pagina (standaard 100). Spam staat er alleen bij met status spam. Bestandsvelden geven alleen naam, grootte en type, nooit een pad of de inhoud. Markeert niets als gelezen. Alleen voor beheerders.', 'webwerckt-base' ),
		_ww_abilities_schema(
			array(
				'form_id'  => array(
					'type'    => 'integer',
					'minimum' => 1,
				),
				'status'   => array(
					'type' => 'string',
					'enum' => array( 'new', 'read', 'spam' ),
				),
				'page'     => $redirect_page,
				'per_page' => $redirect_per,
			)
		),
		'_ww_ability_list_form_entries',
		'_ww_ability_can_manage_forms',
		true
	);
}
add_action( 'wp_abilities_api_init', '_ww_abilities_register' );

/*
 * Staging-slot en rechten. De permissiechecks vragen dezelfde rechten als de admin.
 */

/**
 * Fout als schrijven niet mag, anders null. Schrijven mag alleen als de verwachte host is ingesteld en
 * gelijk is aan de host van de site.
 *
 * @param string $expected Host uit WW_ABILITIES_WRITE_HOST ('' als hij niet is ingesteld).
 * @param string $host     Host van home_url().
 */
function _ww_abilities_write_error( string $expected, string $host ): ?WP_Error {
	if ( '' === $expected ) {
		return new WP_Error( 'ww_abilities_locked', __( 'Schrijven via abilities staat uit. Zet op een staging-site define( \'WW_ABILITIES_WRITE_HOST\', \'<host van de site>\' ); in wp-config.php.', 'webwerckt-base' ), array( 'status' => 403 ) );
	}
	if ( strtolower( $expected ) !== strtolower( $host ) ) {
		/* translators: 1: host van de site, 2: host uit WW_ABILITIES_WRITE_HOST. */
		return new WP_Error( 'ww_abilities_wrong_host', sprintf( __( 'Schrijven via abilities staat uit: deze site is %1$s, maar WW_ABILITIES_WRITE_HOST is %2$s.', 'webwerckt-base' ), $host, $expected ), array( 'status' => 403 ) );
	}
	return null;
}

/**
 * Het staging-slot voor deze site: fout als schrijven niet mag, anders null.
 *
 * Met Meertalig actief laat het slot op een andere host alleen vertalingen en per taal ingestelde teksten en menu's door
 * (_ww_abilities_translation_allowed()); de foutmelding noemt dan ook wat wel kan. Zonder Meertalig is het slot zoals in 0018.
 *
 * @param string              $name  Naam van de ability, zonder webwerckt/.
 * @param array<string,mixed> $input Invoer van de ability.
 */
function _ww_abilities_write_lock( string $name = '', array $input = array() ): ?WP_Error {
	$expected = defined( 'WW_ABILITIES_WRITE_HOST' ) ? _ww_data_to_string( constant( 'WW_ABILITIES_WRITE_HOST' ) ) : '';
	$error    = _ww_abilities_write_error( $expected, (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
	if ( null === $error || _ww_abilities_translation_allowed( $name, $input ) ) {
		return null;
	}
	if ( _ww_languages_active() ) {
		return new WP_Error( 'ww_abilities_locked', __( 'Op deze site kunnen abilities alleen vertalingen maken en bijwerken.', 'webwerckt-base' ), array( 'status' => 403 ) );
	}
	return $error;
}

/**
 * Mag deze ability ook op een andere host (productie) schrijven? Alleen met Meertalig actief, en alleen
 * create-translation (altijd een concept), update-term-translation (alleen een extra taal op een term van een vertaalbare taxonomie), update-fields op een bericht in een extra taal, save-form op een bestaand formulier in een extra taal (0043), set-language-tagline voor een extra taal, update-settings met een
 * extra taal als lang (die schrijft dan alleen vertalingen) en set-menu op een geregistreerde locatie van een extra taal
 * waarvan het menu niet ook op een andere locatie staat (_ww_abilities_menu_lock_allows()). De taal van een bericht komt uit het bericht zelf: een bericht zonder taalterm, of met een taal die niet meer in de optie staat, is de standaardtaal.
 *
 * @param string              $name  Naam van de ability, zonder webwerckt/.
 * @param array<string,mixed> $input Invoer van de ability.
 */
function _ww_abilities_translation_allowed( string $name, array $input ): bool {
	if ( ! _ww_languages_active() ) {
		return false;
	}
	if ( 'create-translation' === $name ) {
		return true;
	}
	if ( 'update-term-translation' === $name ) {
		// Alleen een extra taal op een term van een vertaalbare taxonomie; de standaardtaal en een onbekende taal blijven op slot.
		$term = get_term( absint( $input['term_id'] ?? 0 ) );
		return in_array( sanitize_key( is_string( $input['lang'] ?? null ) ? $input['lang'] : '' ), _ww_extra_language_codes(), true )
			&& $term instanceof WP_Term && _ww_is_translatable_taxonomy( $term->taxonomy );
	}
	if ( 'update-settings' === $name ) {
		// Alleen met een extra taal; zonder lang, met de standaardtaal of een onbekende taal blijft het op slot.
		return '' !== _ww_settings_edit_language( is_string( $input['lang'] ?? null ) ? $input['lang'] : '' );
	}
	if ( 'set-menu' === $name ) {
		// Alleen een locatie van een extra taal; een gewone locatie, de standaardtaal of een onbekende taal blijft op slot.
		$location = is_string( $input['location'] ?? null ) ? sanitize_key( $input['location'] ) : '';
		return _ww_abilities_menu_lock_allows( $location );
	}
	if ( 'set-language-tagline' === $name ) {
		// Alleen een extra taal; de standaardtaal en een onbekende taal blijven op slot.
		return in_array( sanitize_key( is_string( $input['lang'] ?? null ) ? $input['lang'] : '' ), _ww_extra_language_codes(), true );
	}
	if ( 'save-form' === $name ) {
		// Alleen een bestaand formulier in een extra taal; een nieuw formulier en de standaardtaal blijven op slot.
		$form_id = absint( $input['id'] ?? 0 );
		return $form_id > 0 && WW_FORM_POST_TYPE === get_post_type( $form_id ) && in_array( _ww_post_language( $form_id ), _ww_extra_language_codes(), true );
	}
	$post = 'update-fields' === $name ? _ww_abilities_post( $input ) : null;
	return null !== $post && in_array( _ww_post_language( $post->ID ), _ww_extra_language_codes(), true );
}

/**
 * Mag set-menu op een andere host (productie) deze locatie vullen? Alleen een geregistreerde locatie van een extra taal,
 * en alleen als het menu waarin set-menu dan schrijft (zelfde keuze als _ww_abilities_menu_for(): het menu op de
 * locatie, anders het menu met de naam van het label, anders een nieuw menu) niet ook op een locatie zonder extra taal
 * staat. Anders zou een gedeeld menu het menu van de standaardtaal herschrijven.
 *
 * @param string $location Locatie uit de invoer, door sanitize_key().
 */
function _ww_abilities_menu_lock_allows( string $location ): bool {
	$registered = get_registered_nav_menus();
	if ( ! isset( $registered[ $location ] ) || '' === _ww_menu_location_language( $location )['lang'] ) {
		return false;
	}
	$assigned = get_nav_menu_locations();
	$menu     = wp_get_nav_menu_object( absint( $assigned[ $location ] ?? 0 ) ) ?: wp_get_nav_menu_object( $registered[ $location ] );
	if ( ! $menu instanceof WP_Term ) {
		return true;
	}
	foreach ( $assigned as $other => $menu_id ) {
		if ( (int) $menu_id === $menu->term_id && '' === _ww_menu_location_language( (string) $other )['lang'] ) {
			return false;
		}
	}
	return true;
}

/**
 * Het bericht uit de invoer, of null. Alleen van een post type dat de abilities kennen (_ww_abilities_type_object()):
 * interne post types zoals user_request (privacyverzoeken, de titel is een e-mailadres) hebben vaak de rechten
 * van gewone berichten, zodat een Redacteur ze anders kon lezen.
 *
 * @param mixed  $input   Invoer van de ability.
 * @param string $ability Naam van de ability, zie _ww_abilities_type_object().
 */
function _ww_abilities_post( $input, string $ability = '' ): ?WP_Post {
	$post = get_post( is_array( $input ) ? absint( $input['post_id'] ?? 0 ) : 0 );
	return $post instanceof WP_Post && null !== _ww_abilities_type_object( $post->post_type, $ability ) ? $post : null;
}

/**
 * Het post type uit de invoer, als de abilities het kennen (_ww_abilities_type_object()), of null.
 *
 * @param mixed $input Invoer van de ability.
 */
function _ww_abilities_post_type( $input ): ?WP_Post_Type {
	return _ww_abilities_type_object( is_array( $input ) ? sanitize_key( _ww_data_to_string( $input['post_type'] ?? '' ) ) : '' );
}

/**
 * Een post type met content dat in de admin te bewerken is (show_ui), of null. Bijlagen, menu-items en de
 * interne post types van WordPress (wp_block, wp_template, …) niet. Formulieren alleen voor create-translation (0043);
 * de andere abilities van berichten kennen ze niet.
 *
 * @param string $name    Post type.
 * @param string $ability Naam van de ability ('' voor de gewone abilities van berichten).
 */
function _ww_abilities_type_object( string $name, string $ability = '' ): ?WP_Post_Type {
	$object = get_post_type_object( $name );
	$intern = in_array( $name, array( 'attachment', 'nav_menu_item', WW_FORM_POST_TYPE ), true ) || str_starts_with( $name, 'wp_' );
	if ( WW_FORM_POST_TYPE === $name && 'create-translation' === $ability ) {
		$intern = false;
	}
	return $object instanceof WP_Post_Type && $object->show_ui && ! $intern ? $object : null;
}

/**
 * Mag de gebruiker berichten van dit post type bekijken in de admin?
 *
 * @param mixed $input Invoer van de ability.
 */
function _ww_ability_can_list_posts( $input ): bool {
	$type = _ww_abilities_post_type( $input );
	return null !== $type && current_user_can( $type->cap->edit_posts );
}

/**
 * Mag de gebruiker een concept van dit post type maken (en zo nodig het template kiezen)?
 *
 * @param mixed $input Invoer van de ability.
 */
function _ww_ability_can_create_post( $input ): bool {
	$type     = _ww_abilities_post_type( $input );
	$template = _ww_data_to_string( is_array( $input ) ? ( $input['template'] ?? '' ) : '' );
	return null !== $type && current_user_can( $type->cap->create_posts ) && ( '' === $template || current_user_can( 'edit_theme_options' ) );
}

/**
 * Mag de gebruiker dit bericht bewerken (en dus zijn velden lezen en opslaan)?
 *
 * @param mixed $input Invoer van de ability.
 */
function _ww_ability_can_edit_post( $input ): bool {
	$post = _ww_abilities_post( $input );
	return null !== $post && current_user_can( 'edit_post', $post->ID );
}

/**
 * Mag de gebruiker het template van dit bericht kiezen? Net als in de admin alleen een beheerder.
 *
 * @param mixed $input Invoer van de ability.
 */
function _ww_ability_can_set_template( $input ): bool {
	return current_user_can( 'edit_theme_options' ) && _ww_ability_can_edit_post( $input );
}

/**
 * Mag de gebruiker de Site-instellingen bewerken? De beheerder, of wie het recht ww_edit_settings heeft (de
 * Redacteur, _ww_settings_grant_cap()).
 */
function _ww_ability_can_edit_settings(): bool {
	return array() !== _ww_fields_for_settings();
}

/**
 * Mag de gebruiker menu's bekijken? Alleen de beheerder: de klant krijgt edit_theme_options alleen op het menuscherm.
 */
function _ww_ability_can_edit_menus(): bool {
	return current_user_can( 'edit_theme_options' );
}

/**
 * Mag de gebruiker bestanden uploaden (en dus de mediabibliotheek bekijken)? Net als "Media" in de admin.
 */
function _ww_ability_can_upload_media(): bool {
	return current_user_can( 'upload_files' );
}

/**
 * De afbeelding uit de invoer, of null. Alleen afbeeldingen, net als bij list-media en upload-media.
 *
 * @param mixed $input Invoer van de ability.
 */
function _ww_abilities_image( $input ): ?WP_Post {
	$post = get_post( is_array( $input ) ? absint( $input['id'] ?? 0 ) : 0 );
	return $post instanceof WP_Post && 'attachment' === $post->post_type && wp_attachment_is_image( $post ) ? $post : null;
}

/**
 * Mag de gebruiker deze afbeelding bewerken? Hetzelfde recht als "Bijlage bewerken" in de admin.
 *
 * @param mixed $input Invoer van de ability.
 */
function _ww_ability_can_edit_media( $input ): bool {
	$image = _ww_abilities_image( $input );
	return null !== $image && current_user_can( 'edit_post', $image->ID );
}

/*
 * Berichten en templates.
 */

/**
 * Een bericht als array voor de antwoorden.
 *
 * @return array<string,mixed>
 */
function _ww_abilities_post_summary( WP_Post $post ): array {
	$summary = array(
		'id'        => $post->ID,
		'post_type' => $post->post_type,
		'title'     => get_the_title( $post ),
		'status'    => $post->post_status,
		'template'  => (string) get_page_template_slug( $post ) ?: 'default',
		'link'      => (string) get_permalink( $post ),
		'edit_link' => (string) get_edit_post_link( $post, 'raw' ),
	);
	if ( _ww_languages_active() && _ww_is_translatable( $post->post_type ) ) {
		$summary['lang']         = _ww_post_language( $post->ID );
		$summary['translations'] = _ww_translation_overview( $post->ID );
	}
	return $summary;
}

/**
 * De taalvoorwaarde voor een query uit de invoer lang: een lege lijst zonder Meertalig, anders een tax_query. Een
 * onbekende taal is een fout. Zonder lang staat er een voorwaarde die alle talen doorlaat: een query zonder
 * taalvoorwaarde krijgt die van de kern (de standaardtaal) zodra de abilities buiten REST draaien, bijvoorbeeld in WP-CLI.
 *
 * @param array<string,mixed> $input Invoer met eventueel lang.
 * @return array<string,mixed>|WP_Error
 */
function _ww_abilities_lang_query( array $input ) {
	$lang = _ww_data_to_string( $input['lang'] ?? '' );
	if ( ! _ww_languages_active() ) {
		return array();
	}
	if ( '' === $lang ) {
		$any = array(
			'relation' => 'OR',
			array(
				'taxonomy' => 'ww_language',
				'operator' => 'EXISTS',
			),
			array(
				'taxonomy' => 'ww_language',
				'operator' => 'NOT EXISTS',
			),
		);
		return array( 'tax_query' => array( $any ) ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- alleen met Meertalig.
	}
	if ( ! in_array( $lang, _ww_language_codes(), true ) ) {
		return new WP_Error( 'ww_translation_lang', __( 'Onbekende taal.', 'webwerckt-base' ), array( 'status' => 400 ) );
	}
	return array( 'tax_query' => array( _ww_languages_tax_query( $lang ) ) ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- alleen met Meertalig.
}

/**
 * Fout voor een bericht dat niet bestaat of dat de gebruiker niet mag zien.
 */
function _ww_abilities_not_found(): WP_Error {
	return new WP_Error( 'ww_abilities_post', __( 'Bericht niet gevonden.', 'webwerckt-base' ), array( 'status' => 404 ) );
}

/**
 * Aantal resultaten van een lijst-ability: per_page uit de invoer, standaard 20, hooguit 100.
 *
 * @param array<string,mixed> $input Invoer van de ability.
 */
function _ww_abilities_per_page( array $input ): int {
	return min( 100, max( 1, absint( $input['per_page'] ?? 20 ) ) );
}

/**
 * Berichten van een post type, nieuwste eerst.
 *
 * @param array<string,mixed> $input post_type, search, per_page, lang.
 * @return array<string,mixed>|WP_Error
 */
function _ww_ability_list_posts( array $input ) {
	$lang = _ww_abilities_lang_query( $input );
	if ( is_wp_error( $lang ) ) {
		return $lang;
	}
	$query = new WP_Query(
		$lang + array(
			'post_type'      => sanitize_key( _ww_data_to_string( $input['post_type'] ?? '' ) ),
			'post_status'    => WW_EDITABLE_STATUSES,
			'perm'           => 'editable',
			's'              => sanitize_text_field( _ww_data_to_string( $input['search'] ?? '' ) ),
			'posts_per_page' => _ww_abilities_per_page( $input ),
			'orderby'        => 'date',
			'order'          => 'DESC',
			'no_found_rows'  => true,
		)
	);
	return array( 'posts' => array_map( '_ww_abilities_post_summary', array_filter( $query->posts, static fn( $post ): bool => $post instanceof WP_Post ) ) );
}

/**
 * Fout als het template niet bij dit bericht past, anders null. 'default' is de tekstpagina.
 */
function _ww_abilities_template_error( WP_Post $post, string $template ): ?WP_Error {
	$templates = array_keys( wp_get_theme()->get_page_templates( $post, $post->post_type ) );
	if ( 'default' === $template || in_array( $template, $templates, true ) ) {
		return null;
	}
	/* translators: 1: template, 2: beschikbare templates. */
	return new WP_Error( 'ww_abilities_template', sprintf( __( 'Template %1$s bestaat niet voor dit bericht. Kies uit: default, %2$s.', 'webwerckt-base' ), $template, implode( ', ', $templates ) ), array( 'status' => 400 ) );
}

/**
 * Maakt een concept, eventueel met template.
 *
 * @param array<string,mixed> $input post_type, title, template.
 * @return array<string,mixed>|WP_Error
 */
function _ww_ability_create_post( array $input ) {
	$template = _ww_data_to_string( $input['template'] ?? '' );
	$post_id  = _ww_create_draft(
		sanitize_key( _ww_data_to_string( $input['post_type'] ?? '' ) ),
		sanitize_text_field( _ww_data_to_string( $input['title'] ?? '' ) )
	);
	if ( is_wp_error( $post_id ) ) {
		return $post_id;
	}
	if ( '' !== $template ) {
		$result = _ww_ability_set_template(
			array(
				'post_id'  => $post_id,
				'template' => $template,
			)
		);
		if ( is_wp_error( $result ) ) {
			return $result;
		}
	}
	$post = get_post( $post_id );
	return $post instanceof WP_Post ? _ww_abilities_post_summary( $post ) : new WP_Error( 'ww_abilities_post', __( 'Het concept is niet aangemaakt.', 'webwerckt-base' ) );
}

/**
 * Zet het paginatemplate.
 *
 * @param array<string,mixed> $input post_id, template.
 * @return array<string,mixed>|WP_Error
 */
function _ww_ability_set_template( array $input ) {
	$post     = _ww_abilities_post( $input );
	$template = _ww_data_to_string( $input['template'] ?? '' );
	if ( null === $post ) {
		return _ww_abilities_not_found();
	}
	$error = _ww_abilities_template_error( $post, $template );
	if ( null !== $error ) {
		return $error;
	}

	$result = _ww_update_post(
		array(
			'ID'            => $post->ID,
			'page_template' => $template,
		)
	);
	if ( is_wp_error( $result ) ) {
		return $result;
	}
	$post = get_post( $post->ID );
	return $post instanceof WP_Post ? _ww_abilities_post_summary( $post ) : _ww_abilities_not_found();
}

/*
 * Velden en Site-instellingen.
 */

/**
 * Velden met naam, label, type en waarde voor het antwoord (_ww_fields_describe(): ook multiple, choices, format en
 * bij een relatie met termen taxonomy); een pick noemt ook post_type (bij een meerkeuze en een relatie met termen
 * leeg).
 *
 * @param array<string,array<string,mixed>> $fields Velden op naam.
 * @param callable                          $read   Geeft de opgeslagen waarde van een veldnaam.
 * @return array<int,array<string,mixed>>
 */
function _ww_abilities_describe( array $fields, callable $read ): array {
	$out = array();
	foreach ( $fields as $name => $field ) {
		$item = array( 'name' => $name ) + _ww_fields_describe( $field, $read( $name ) );
		if ( 'pick' === $item['type'] ) {
			$item['post_type'] = _ww_field_is_term_relation( $field ) ? '' : _ww_data_to_string( $field['pick_val'] ?? '' );
		}
		$out[] = $item;
	}
	return $out;
}

/**
 * Velden van een bericht met hun waarden.
 *
 * @param array<string,mixed> $input post_id.
 * @return array<string,mixed>|WP_Error
 */
function _ww_ability_get_fields( array $input ) {
	$post = _ww_abilities_post( $input );
	if ( null === $post ) {
		return _ww_abilities_not_found();
	}
	$result = array(
		'post'   => _ww_abilities_post_summary( $post ),
		'fields' => _ww_abilities_describe( _ww_fields_for_post( $post ), static fn( string $name ) => _ww_data_get_stored( $name, $post->ID ) ),
	);
	if ( _ww_languages_active() && _ww_is_translatable( $post->post_type ) ) {
		$result['lang']      = _ww_post_language( $post->ID );
		$result['source_id'] = _ww_translation_source_id( $post->ID ) ?: null;
	}
	return $result;
}

/**
 * Mag de gebruiker van dit bericht een vertaling maken? Zie _ww_translation_can_create().
 *
 * @param mixed $input Invoer van de ability.
 */
function _ww_ability_can_create_translation( $input ): bool {
	$post = _ww_abilities_post( $input, 'create-translation' );
	return null !== $post && _ww_translation_can_create( $post->ID );
}

/**
 * Maakt een vertaling als concept (inc/languages-translate.php). Titel en slug worden hier schoongemaakt.
 *
 * @param array<string,mixed> $input post_id, lang, title, slug.
 * @return array<string,mixed>|WP_Error
 */
function _ww_ability_create_translation( array $input ) {
	$post = _ww_abilities_post( $input, 'create-translation' );
	if ( null === $post ) {
		return _ww_abilities_not_found();
	}
	return _ww_translation_create(
		$post->ID,
		sanitize_key( _ww_data_to_string( $input['lang'] ?? '' ) ),
		array(
			'title' => sanitize_text_field( _ww_data_to_string( $input['title'] ?? '' ) ),
			'slug'  => sanitize_title( _ww_data_to_string( $input['slug'] ?? '' ) ),
		)
	);
}

/**
 * Mag de gebruiker dit bericht dupliceren? Zie _ww_post_can_duplicate().
 *
 * @param mixed $input Invoer van de ability.
 */
function _ww_ability_can_duplicate_post( $input ): bool {
	$post = _ww_abilities_post( $input );
	return null !== $post && _ww_post_can_duplicate( $post->ID );
}

/**
 * Dupliceert een bericht als concept (inc/duplicate.php). De titel wordt hier schoongemaakt.
 *
 * @param array<string,mixed> $input post_id, title.
 * @return array<string,mixed>|WP_Error
 */
function _ww_ability_duplicate_post( array $input ) {
	$post = _ww_abilities_post( $input );
	if ( null === $post ) {
		return _ww_abilities_not_found();
	}
	return _ww_post_duplicate( $post->ID, array( 'title' => sanitize_text_field( _ww_data_to_string( $input['title'] ?? '' ) ) ) );
}

/**
 * De taxonomie uit de invoer, als de abilities haar kennen (met show_ui), of null.
 *
 * @param mixed $input Invoer van de ability.
 */
function _ww_abilities_taxonomy( $input ): ?WP_Taxonomy {
	$taxonomy = get_taxonomy( is_array( $input ) ? sanitize_key( _ww_data_to_string( $input['taxonomy'] ?? '' ) ) : '' );
	return $taxonomy instanceof WP_Taxonomy && $taxonomy->show_ui ? $taxonomy : null;
}

/**
 * Mag de gebruiker de termen van deze taxonomie beheren (manage_terms)?
 *
 * @param mixed $input Invoer van de ability.
 */
function _ww_ability_can_list_terms( $input ): bool {
	$taxonomy = _ww_abilities_taxonomy( $input );
	return null !== $taxonomy && current_user_can( $taxonomy->cap->manage_terms );
}

/**
 * Een term voor de abilities: id, name, slug, description, count en, met Meertalig actief, translations (per extra taal de
 * vertaling of null). Altijd de gewone waarden: de aanroeper zet de termfilters uit.
 *
 * @return array<string,mixed>
 */
function _ww_abilities_term_summary( WP_Term $term ): array {
	$summary = array(
		'id'          => $term->term_id,
		'name'        => $term->name,
		'slug'        => $term->slug,
		'description' => $term->description,
		'count'       => $term->count,
	);
	if ( _ww_languages_active() && _ww_is_translatable_taxonomy( $term->taxonomy ) ) {
		$translations = array();
		foreach ( _ww_extra_language_codes() as $code ) {
			$translation          = _ww_term_translation( $term->term_id, $code );
			$translations[ $code ] = array() !== array_filter( $translation ) ? $translation : null;
		}
		$summary['translations'] = $translations;
	}
	return $summary;
}

/**
 * Termen van een taxonomie, op naam. De termfilters staan uit: altijd de gewone waarden, ook op een verzoek in een extra taal.
 *
 * @param array<string,mixed> $input taxonomy, search, per_page.
 * @return array<string,mixed>
 */
function _ww_ability_list_terms( array $input ): array {
	$previous = _ww_languages_terms_raw();
	_ww_languages_terms_raw( true );
	try {
		$terms = get_terms(
			array(
				'taxonomy'   => sanitize_key( _ww_data_to_string( $input['taxonomy'] ?? '' ) ),
				'hide_empty' => false,
				'search'     => sanitize_text_field( _ww_data_to_string( $input['search'] ?? '' ) ),
				'number'     => _ww_abilities_per_page( $input ),
			)
		);
	} finally {
		_ww_languages_terms_raw( $previous );
	}
	return array( 'terms' => array_map( '_ww_abilities_term_summary', is_array( $terms ) ? array_values( $terms ) : array() ) );
}

/**
 * Mag de gebruiker deze term bewerken (edit_term)?
 *
 * @param mixed $input Invoer van de ability.
 */
function _ww_ability_can_update_term_translation( $input ): bool {
	$term_id = is_array( $input ) ? absint( $input['term_id'] ?? 0 ) : 0;
	return $term_id > 0 && current_user_can( 'edit_term', $term_id );
}

/**
 * Bewaart de vertaling van een term in een extra taal en geeft de term terug zoals list-terms.
 *
 * @param array<string,mixed> $input term_id, lang, name, slug, description.
 * @return array<string,mixed>|WP_Error
 */
function _ww_ability_update_term_translation( array $input ) {
	$term_id = absint( $input['term_id'] ?? 0 );
	$data    = array();
	foreach ( array( 'name', 'slug', 'description' ) as $field ) {
		if ( isset( $input[ $field ] ) && is_string( $input[ $field ] ) ) {
			$data[ $field ] = $input[ $field ];
		}
	}
	$result = _ww_term_save_translation( $term_id, sanitize_key( _ww_data_to_string( $input['lang'] ?? '' ) ), $data );
	if ( is_wp_error( $result ) ) {
		$result->add_data( array( 'status' => 400 ) );
		return $result;
	}

	$previous = _ww_languages_terms_raw();
	_ww_languages_terms_raw( true );
	try {
		$term = get_term( $term_id );
	} finally {
		_ww_languages_terms_raw( $previous );
	}
	return $term instanceof WP_Term ? _ww_abilities_term_summary( $term ) : new WP_Error( 'invalid_term', __( 'Term niet gevonden.', 'webwerckt-base' ), array( 'status' => 404 ) );
}

/**
 * Mag de gebruiker de talen beheren? Alleen de beheerder, net als de pagina Talen.
 */
function _ww_ability_can_manage_languages(): bool {
	return current_user_can( 'manage_options' );
}

/**
 * De talen met per taal de status, de ondertitel en de vertaalde URL-basis, plus de objecten met een vertaalbare basis.
 *
 * @return array<string,mixed>
 */
function _ww_ability_get_languages(): array {
	$config    = _ww_languages_config();
	$objects   = _ww_language_base_objects();
	$languages = array();
	foreach ( $config['languages'] as $language ) {
		$is_default  = $language['code'] === $config['default'];
		$languages[] = array(
			'code'    => $language['code'],
			'locale'  => $language['locale'],
			'name'    => $language['name'],
			'default' => $is_default,
			'visible' => $language['visible'],
			'tagline' => _ww_language_tagline( $language['code'] ),
			'bases'   => $is_default ? array() : _ww_language_bases( $language['code'] ),
			'objects' => $is_default ? array() : $objects,
		);
	}
	return array(
		'default'   => $config['default'],
		'languages' => $languages,
	);
}

/**
 * Zet de vertaalde URL-basis van een extra taal (_ww_language_save_bases()) en geeft de basissen van die taal terug.
 *
 * @param array<string,mixed> $input lang, bases.
 * @return array<string,mixed>|WP_Error
 */
function _ww_ability_set_url_bases( array $input ) {
	$lang   = sanitize_key( _ww_data_to_string( $input['lang'] ?? '' ) );
	$bases  = isset( $input['bases'] ) && is_array( $input['bases'] ) ? $input['bases'] : array();
	$result = _ww_language_save_bases( $lang, $bases );
	if ( $result instanceof WP_Error ) {
		$result->add_data( array_merge( (array) $result->get_error_data(), array( 'status' => 400 ) ) );
		return $result;
	}
	return array(
		'lang'  => $lang,
		'bases' => _ww_language_bases( $lang ),
	);
}

/**
 * Zet de ondertitel van een extra taal (_ww_language_save_tagline()) en geeft hem terug.
 *
 * @param array<string,mixed> $input lang, tagline.
 * @return array<string,mixed>|WP_Error
 */
function _ww_ability_set_language_tagline( array $input ) {
	$lang   = sanitize_key( _ww_data_to_string( $input['lang'] ?? '' ) );
	$result = _ww_language_save_tagline( $lang, _ww_data_to_string( $input['tagline'] ?? '' ) );
	if ( $result instanceof WP_Error ) {
		$result->add_data( array_merge( (array) $result->get_error_data(), array( 'status' => 400 ) ) );
		return $result;
	}
	return array(
		'lang'    => $lang,
		'tagline' => _ww_language_tagline( $lang ),
	);
}

/**
 * Slaat velden van een bericht op en werkt het bericht bij zoals "Bijwerken" in de admin.
 *
 * @param array<string,mixed> $input post_id, fields.
 * @return array<string,mixed>|WP_Error
 */
function _ww_ability_update_fields( array $input ) {
	$post = _ww_abilities_post( $input );
	if ( null === $post ) {
		return _ww_abilities_not_found();
	}
	$data = _ww_fields_input( $input['fields'] ?? array(), _ww_fields_for_post( $post ) );
	if ( is_wp_error( $data ) ) {
		return $data;
	}
	$error = _ww_fields_save( $post->post_type, $post->ID, $data );
	if ( null !== $error ) {
		return $error;
	}

	$result = _ww_update_post( array( 'ID' => $post->ID ) );
	return is_wp_error( $result ) ? $result : _ww_ability_get_fields( array( 'post_id' => $post->ID ) );
}

/**
 * Site-instellingen met hun waarden. Met een extra taal (lang) per veld ook translatable en fallback (de waarde van de
 * standaardtaal); value is dan de waarde in die taal, of null als er geen vertaling is. Een veld dat voor alle talen
 * geldt, heeft translatable false en toont zijn waarde in value.
 *
 * @param array<string,mixed> $input lang.
 * @return array<string,mixed>|WP_Error
 */
function _ww_ability_get_settings( array $input = array() ) {
	$lang = _ww_settings_input_language( $input['lang'] ?? '' );
	if ( is_wp_error( $lang ) ) {
		return $lang;
	}
	$fields = _ww_fields_for_settings();
	if ( '' === $lang ) {
		return array( 'fields' => _ww_abilities_describe( $fields, '_ww_data_get_setting' ) );
	}
	$stored    = _ww_settings_translation( $lang );
	$described = _ww_abilities_describe( $fields, static fn( string $name ) => _ww_data_get_setting( $name, $lang ) );
	foreach ( $described as $index => $item ) {
		$name         = (string) $item['name'];
		$field        = $fields[ $name ];
		$translatable = _ww_setting_translatable( $field );
		$own          = _ww_data_to_string( $stored[ $name ] ?? '' );

		$described[ $index ]['translatable'] = $translatable;
		$described[ $index ]['fallback']     = _ww_fields_value( $field, _ww_data_get_setting( $name, '' ) );
		if ( $translatable ) {
			$described[ $index ]['value'] = '' !== trim( $own ) ? $own : null;
		}
	}
	return array( 'fields' => $described );
}

/**
 * Slaat Site-instellingen op, per instellingen-pod. De cache leegt zich bij het opslaan van de opties (inc/cache.php).
 *
 * Met een extra taal (lang) gaan de waarden naar ww_settings_{lang} (beslissing 0042) en mogen alleen vertaalbare
 * velden: een ander veld geeft ww_settings_not_translatable en er wordt niets bewaard. Een lege waarde wist de
 * vertaling. Dit is het enige wat het staging-slot op een andere host doorlaat (_ww_abilities_translation_allowed()):
 * met een extra taal schrijft deze functie nooit naar de opties van de standaardtaal.
 *
 * @param array<string,mixed> $input fields en lang.
 * @return array<string,mixed>|WP_Error
 */
function _ww_ability_update_settings( array $input ) {
	$lang = _ww_settings_input_language( $input['lang'] ?? '' );
	if ( is_wp_error( $lang ) ) {
		return $lang;
	}
	$allowed = _ww_fields_for_settings();
	$data    = _ww_fields_input( $input['fields'] ?? array(), $allowed );
	if ( is_wp_error( $data ) ) {
		return $data;
	}

	$error = '' === $lang ? _ww_fields_save_settings( $data, $allowed ) : _ww_settings_save_translation( $data, $lang );
	return null === $error ? _ww_ability_get_settings( array( 'lang' => $lang ) ) : $error;
}

/**
 * Mag de huidige gebruiker het schema bekijken? Wie berichten bewerkt; het schema zelf is openbaar.
 */
function _ww_ability_can_list_schema(): bool {
	return current_user_can( 'edit_posts' );
}

/**
 * De graph van de homepage of van een gepubliceerd bericht, met de stand van het schema.
 *
 * @param array<string,mixed> $input post_id.
 * @return array<string,mixed>|WP_Error
 */
function _ww_ability_get_schema( array $input ) {
	$post_id = absint( $input['post_id'] ?? 0 );
	if ( $post_id > 0 && 'publish' !== get_post_status( $post_id ) ) {
		return new WP_Error( 'ww_abilities_post', __( 'Bericht niet gevonden of niet gepubliceerd.', 'webwerckt-base' ), array( 'status' => 404 ) );
	}
	return array(
		'enabled' => _ww_schema_enabled(),
		'plugin'  => _ww_schema_plugin(),
		'missing' => _ww_schema_missing(),
		'graph'   => _ww_schema_enabled() ? _ww_schema_graph_for( $post_id ) : array(),
	);
}

/**
 * SEO-velden en het oordeel per gepubliceerd bericht van een post type (inc/seo-admin.php).
 *
 * @param array<string,mixed> $input post_type, only_issues, lang.
 * @return array<string,mixed>|WP_Error
 */
function _ww_ability_get_seo( array $input ) {
	$type = _ww_data_to_string( $input['post_type'] ?? '' );
	if ( '' !== _ww_seo_plugin() || ! in_array( $type, _ww_seo_admin_post_types(), true ) ) {
		return array(
			'enabled' => false,
			'plugin'  => _ww_seo_plugin(),
			'items'   => array(),
		);
	}
	$lang = _ww_abilities_lang_query( $input );
	if ( is_wp_error( $lang ) ) {
		return $lang;
	}
	$ids = get_posts(
		$lang + array(
			'post_type'      => $type,
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'orderby'        => 'title',
			'order'          => 'ASC',
		)
	);
	update_meta_cache( 'post', $ids );
	$items = array();
	foreach ( $ids as $id ) {
		$id     = (int) $id;
		$report = _ww_seo_post_report( $id );
		$issue  = ! $report['noindex'] && array() !== array_diff( array( $report['title'], $report['description'], $report['image'] ), array( 'good' ) );
		if ( ! empty( $input['only_issues'] ) && ! $issue ) {
			continue;
		}
		$items[] = array(
			'id'                 => $id,
			'title'              => _ww_plain_text( get_the_title( $id ) ),
			'link'               => (string) get_permalink( $id ),
			'ww_seo_title'       => _ww_data_to_string( _ww_data_get_stored( 'ww_seo_title', $id ) ),
			'ww_seo_description' => _ww_data_to_string( _ww_data_get_stored( 'ww_seo_description', $id ) ),
			'ww_seo_image'       => _ww_data_to_attachment_id( _ww_data_get_stored( 'ww_seo_image', $id ) ),
			'ww_seo_schema_type' => _ww_seo_schema_type( $id ),
			'ww_seo_canonical'   => _ww_seo_post_canonical( $id ),
			'report'             => $report,
		);
	}
	return array(
		'enabled' => true,
		'plugin'  => '',
		'limits'  => _ww_seo_length_limits(),
		'items'   => $items,
	);
}

/*
 * Menu's.
 */

/**
 * Een menu-item als array voor het antwoord, nog zonder kinderen.
 *
 * @param object{ID:int,title:string,url:string,object:string,object_id:int|string} $item Menu-item uit wp_get_nav_menu_items().
 * @return array<string,mixed>
 */
function _ww_abilities_menu_item( object $item ): array {
	return array(
		'id'        => (int) $item->ID,
		'title'     => $item->title,
		'url'       => $item->url,
		'object'    => $item->object,
		'object_id' => (int) $item->object_id,
		'children'  => array(),
	);
}

/**
 * De items van een menu als boom.
 *
 * @return array<int,array<string,mixed>>
 */
function _ww_abilities_menu_tree( int $menu_id ): array {
	$items    = $menu_id > 0 ? wp_get_nav_menu_items( $menu_id, array( 'update_post_term_cache' => false ) ) : false;
	$items    = is_array( $items ) ? $items : array();
	$ids      = wp_list_pluck( $items, 'ID' );
	$branches = array();
	foreach ( $items as $item ) {
		$parent = (int) $item->menu_item_parent;
		$branches[ in_array( $parent, $ids, true ) ? $parent : 0 ][] = _ww_abilities_menu_item( $item );
	}
	return _ww_menu_branch( $branches, 0 );
}

/**
 * Alle menulocaties met hun menu en items.
 *
 * @return array<string,mixed>
 */
function _ww_ability_get_menus(): array {
	$assigned  = get_nav_menu_locations();
	$locations = array();
	foreach ( get_registered_nav_menus() as $location => $label ) {
		$menu_id     = absint( $assigned[ $location ] ?? 0 );
		$locations[] = array(
			'location' => $location,
			'label'    => $label,
			'lang'     => _ww_menu_location_language( (string) $location )['lang'],
			'menu_id'  => $menu_id,
			'items'    => _ww_abilities_menu_tree( $menu_id ),
		);
	}
	return array( 'locations' => $locations );
}

/**
 * Menu-items uit de invoer, gecontroleerd en klaar voor wp_update_nav_menu_item(), of een fout. Hooguit drie niveaus.
 *
 * @param mixed $items Invoer.
 * @return array<int,array<string,mixed>>|WP_Error
 */
function _ww_abilities_menu_input( $items, int $depth = 1 ) {
	if ( ! is_array( $items ) || $depth > 3 ) {
		return new WP_Error( 'ww_abilities_menu', __( 'Menu-items zijn een lijst, hooguit drie niveaus diep.', 'webwerckt-base' ), array( 'status' => 400 ) );
	}
	$out = array();
	foreach ( $items as $item ) {
		$item  = is_array( $item ) ? $item : array();
		$title = sanitize_text_field( _ww_data_to_string( $item['title'] ?? '' ) );
		$id    = absint( $item['post_id'] ?? 0 );
		$url   = _ww_data_to_string( $item['url'] ?? '' );
		$post  = $id > 0 ? get_post( $id ) : null;

		if ( $post instanceof WP_Post && ! in_array( $post->post_type, array( 'revision', 'nav_menu_item', 'attachment' ), true ) && 'trash' !== $post->post_status ) {
			$args = array(
				'menu-item-type'      => 'post_type',
				'menu-item-object'    => $post->post_type,
				'menu-item-object-id' => $post->ID,
				'menu-item-title'     => $title,
			);
		} elseif ( 0 === $id && '' !== $title && ( str_starts_with( $url, '/' ) || wp_http_validate_url( $url ) ) ) {
			$args = array(
				'menu-item-type'  => 'custom',
				'menu-item-url'   => esc_url_raw( str_starts_with( $url, '/' ) ? home_url( $url ) : $url ),
				'menu-item-title' => $title,
			);
		} else {
			return new WP_Error( 'ww_abilities_menu', __( 'Elk menu-item heeft een bestaand post_id, of een title met een url (https://… of /pad/).', 'webwerckt-base' ), array( 'status' => 400 ) );
		}

		$children = _ww_abilities_menu_input( $item['children'] ?? array(), $depth + 1 );
		if ( is_wp_error( $children ) ) {
			return $children;
		}
		$out[] = array(
			'args'     => $args + array( 'menu-item-status' => 'publish' ),
			'children' => $children,
		);
	}
	return $out;
}

/**
 * Voegt gecontroleerde items toe aan een menu, met hun kinderen.
 *
 * @param array<int,array<string,mixed>> $items Uit _ww_abilities_menu_input().
 */
function _ww_abilities_menu_add( int $menu_id, array $items, int $parent = 0 ): ?WP_Error {
	foreach ( $items as $item ) {
		$args    = (array) $item['args'];
		$item_id = wp_update_nav_menu_item( $menu_id, 0, $args + array( 'menu-item-parent-id' => $parent ) );
		if ( is_wp_error( $item_id ) ) {
			return $item_id;
		}
		$error = _ww_abilities_menu_add( $menu_id, (array) $item['children'], (int) $item_id );
		if ( null !== $error ) {
			return $error;
		}
	}
	return null;
}

/**
 * Het menu op een locatie, of een nieuw menu met de naam van de locatie dat er meteen op komt.
 *
 * @return int|WP_Error
 */
function _ww_abilities_menu_for( string $location, string $label ) {
	$assigned = get_nav_menu_locations();
	$menu     = wp_get_nav_menu_object( absint( $assigned[ $location ] ?? 0 ) ) ?: wp_get_nav_menu_object( $label );
	$menu_id  = $menu instanceof WP_Term ? $menu->term_id : wp_create_nav_menu( $label );
	if ( is_wp_error( $menu_id ) ) {
		return $menu_id;
	}
	$assigned[ $location ] = (int) $menu_id;
	set_theme_mod( 'nav_menu_locations', $assigned );
	return (int) $menu_id;
}

/**
 * Vervangt de items van het menu op een locatie. Alles wordt eerst gecontroleerd, zodat een fout het menu niet leeg achterlaat.
 *
 * @param array<string,mixed> $input location, items.
 * @return array<string,mixed>|WP_Error
 */
function _ww_ability_set_menu( array $input ) {
	$location   = sanitize_key( _ww_data_to_string( $input['location'] ?? '' ) );
	$registered = get_registered_nav_menus();
	if ( ! isset( $registered[ $location ] ) ) {
		/* translators: 1: menulocatie, 2: bestaande locaties. */
		return new WP_Error( 'ww_abilities_menu', sprintf( __( 'Menulocatie %1$s bestaat niet. Locaties: %2$s.', 'webwerckt-base' ), $location, implode( ', ', array_keys( $registered ) ) ), array( 'status' => 400 ) );
	}
	$items = _ww_abilities_menu_input( $input['items'] ?? null );
	if ( is_wp_error( $items ) ) {
		return $items;
	}

	$menu_id = _ww_abilities_menu_for( $location, $registered[ $location ] );
	if ( is_wp_error( $menu_id ) ) {
		return $menu_id;
	}
	foreach ( wp_get_nav_menu_items( $menu_id, array( 'post_status' => 'any' ) ) ?: array() as $old ) {
		wp_delete_post( $old->ID, true );
	}
	$error = _ww_abilities_menu_add( $menu_id, $items );
	if ( null !== $error ) {
		return $error;
	}

	return array(
		'location' => $location,
		'menu_id'  => $menu_id,
		'items'    => _ww_abilities_menu_tree( $menu_id ),
	);
}

/*
 * Media.
 */

/**
 * Afbeeldingstypen die de ability aanneemt, als extensies => MIME-type voor wp_check_filetype_and_ext(). Geen SVG:
 * dat is code, en WordPress staat het zelf ook niet toe.
 *
 * @return array<string,string>
 */
function _ww_abilities_image_mimes(): array {
	return array_intersect( get_allowed_mime_types(), array( 'image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/avif' ) );
}

/**
 * Fout voor een bestand boven de uploadlimiet van de site.
 */
function _ww_abilities_media_too_large(): WP_Error {
	/* translators: %s: uploadlimiet, bijvoorbeeld 64 MB. */
	return new WP_Error( 'ww_abilities_media', sprintf( __( 'Het bestand is groter dan de uploadlimiet van de site (%s).', 'webwerckt-base' ), size_format( wp_max_upload_size() ) ), array( 'status' => 413 ) );
}

/**
 * Zet de invoer in een tijdelijk bestand: base64-data, of een download van een https-URL. Geeft het pad of een fout.
 *
 * @param array<string,mixed> $input data of url.
 * @return string|WP_Error
 */
function _ww_abilities_media_tmp( array $input ) {
	$data = _ww_data_to_string( $input['data'] ?? '' );
	$url  = _ww_data_to_string( $input['url'] ?? '' );
	if ( ( '' === $data ) === ( '' === $url ) ) {
		return new WP_Error( 'ww_abilities_media', __( 'Geef data (base64) of url, niet allebei.', 'webwerckt-base' ), array( 'status' => 400 ) );
	}

	if ( '' !== $url ) {
		if ( 'https' !== wp_parse_url( $url, PHP_URL_SCHEME ) || ! wp_http_validate_url( $url ) ) {
			return new WP_Error( 'ww_abilities_media', __( 'De url moet een openbare https-URL zijn.', 'webwerckt-base' ), array( 'status' => 400 ) );
		}
		// download_url() gebruikt wp_safe_remote_get(): geen adressen op het eigen netwerk.
		$tmp = download_url( $url, 30 );
		if ( is_wp_error( $tmp ) ) {
			return $tmp;
		}
		// Dezelfde grens als bij base64: download_url() zelf kent er geen.
		if ( (int) filesize( $tmp ) > wp_max_upload_size() ) {
			wp_delete_file( $tmp );
			return _ww_abilities_media_too_large();
		}
		return $tmp;
	}

	$binary = base64_decode( (string) preg_replace( '/^data:[^,]*;base64,|\s+/', '', $data ), true );
	if ( false === $binary || '' === $binary ) {
		return new WP_Error( 'ww_abilities_media', __( 'De data is geen geldige base64.', 'webwerckt-base' ), array( 'status' => 400 ) );
	}
	if ( strlen( $binary ) > wp_max_upload_size() ) {
		return _ww_abilities_media_too_large();
	}
	$tmp = wp_tempnam( 'ww-upload' );
	if ( false === file_put_contents( $tmp, $binary ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- tijdelijk bestand, net als download_url().
		return new WP_Error( 'ww_abilities_media', __( 'Het tijdelijke bestand kon niet worden geschreven.', 'webwerckt-base' ), array( 'status' => 500 ) );
	}
	return $tmp;
}

/**
 * Een bijlage als array voor het antwoord.
 *
 * @return array<string,mixed>
 */
function _ww_abilities_media_summary( int $id ): array {
	$meta  = wp_get_attachment_metadata( $id );
	$meta  = is_array( $meta ) ? $meta : array();
	$sizes = array();
	foreach ( array_keys( (array) ( $meta['sizes'] ?? array() ) ) as $size ) {
		$src = wp_get_attachment_image_src( $id, (string) $size );
		if ( is_array( $src ) ) {
			$sizes[ (string) $size ] = array(
				'url'    => $src[0],
				'width'  => $src[1],
				'height' => $src[2],
			);
		}
	}
	return array(
		'id'       => $id,
		'title'    => get_the_title( $id ),
		'url'      => (string) wp_get_attachment_url( $id ),
		'filename' => wp_basename( (string) get_attached_file( $id ) ),
		'mime'     => (string) get_post_mime_type( $id ),
		'width'    => absint( $meta['width'] ?? 0 ),
		'height'   => absint( $meta['height'] ?? 0 ),
		'alt'      => _ww_data_to_string( get_post_meta( $id, '_wp_attachment_image_alt', true ) ),
		'sizes'    => (object) $sizes,
	);
}

/**
 * Afbeeldingen uit de mediabibliotheek, nieuwste eerst, gezocht op titel of bestandsnaam.
 *
 * @param array<string,mixed> $input search, per_page.
 * @return array<string,mixed>
 */
function _ww_ability_list_media( array $input = array() ): array {
	// Zoeken op bestandsnaam doet WordPress alleen in de mediabibliotheek van de admin; hier zetten we het aan.
	// WP_Query haalt het filter na gebruik zelf weer weg, dus het geldt alleen voor deze query.
	add_filter( 'wp_allow_query_attachment_by_filename', '__return_true' );
	$query = new WP_Query(
		array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'post_mime_type' => 'image',
			's'              => sanitize_text_field( _ww_data_to_string( $input['search'] ?? '' ) ),
			'posts_per_page' => _ww_abilities_per_page( $input ),
			'orderby'        => 'date',
			'order'          => 'DESC',
			'fields'         => 'ids',
			'no_found_rows'  => true,
		)
	);
	return array( 'media' => array_map( static fn( $id ): array => _ww_abilities_media_summary( (int) $id ), $query->posts ) );
}

/**
 * Past de alt-tekst en/of de titel van een afbeelding aan. Een veld dat ontbreekt blijft staan.
 *
 * @param array<string,mixed> $input id, alt, title.
 * @return array<string,mixed>|WP_Error
 */
function _ww_ability_update_media( array $input ) {
	$image = _ww_abilities_image( $input );
	if ( null === $image ) {
		return new WP_Error( 'ww_abilities_media', __( 'Afbeelding niet gevonden.', 'webwerckt-base' ), array( 'status' => 404 ) );
	}
	if ( ! array_key_exists( 'alt', $input ) && ! array_key_exists( 'title', $input ) ) {
		return new WP_Error( 'ww_abilities_media', __( 'Geef alt, title of allebei.', 'webwerckt-base' ), array( 'status' => 400 ) );
	}

	$title = sanitize_text_field( _ww_data_to_string( $input['title'] ?? '' ) );
	if ( '' !== $title ) {
		$result = _ww_update_post(
			array(
				'ID'         => $image->ID,
				'post_title' => $title,
			)
		);
		if ( is_wp_error( $result ) ) {
			return $result;
		}
	}
	if ( array_key_exists( 'alt', $input ) ) {
		update_post_meta( $image->ID, '_wp_attachment_image_alt', wp_slash( sanitize_text_field( _ww_data_to_string( $input['alt'] ) ) ) );
	}
	return _ww_abilities_media_summary( $image->ID );
}

/**
 * Zet een afbeelding in de mediabibliotheek zoals de uploader van de admin: met de formaten van het thema en de
 * metadata. Alleen afbeeldingen; het echte type van het bestand telt, niet alleen de extensie.
 *
 * @param array<string,mixed> $input filename, data of url, alt, title.
 * @return array<string,mixed>|WP_Error
 */
function _ww_ability_upload_media( array $input ) {
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';

	$tmp = _ww_abilities_media_tmp( $input );
	if ( is_wp_error( $tmp ) ) {
		return $tmp;
	}

	$filename = sanitize_file_name( _ww_data_to_string( $input['filename'] ?? '' ) );
	$check    = wp_check_filetype_and_ext( $tmp, $filename, _ww_abilities_image_mimes() );
	if ( empty( $check['type'] ) ) {
		wp_delete_file( $tmp );
		return new WP_Error( 'ww_abilities_media', __( 'Alleen afbeeldingen (jpg, png, gif, webp, avif), en de extensie moet bij de inhoud passen.', 'webwerckt-base' ), array( 'status' => 400 ) );
	}

	$title = sanitize_text_field( _ww_data_to_string( $input['title'] ?? '' ) );
	$id    = media_handle_sideload(
		array(
			'name'     => $check['proper_filename'] ?: $filename,
			'tmp_name' => $tmp,
		),
		0,
		null,
		'' !== $title ? wp_slash( array( 'post_title' => $title ) ) : array()
	);
	if ( is_wp_error( $id ) ) {
		wp_delete_file( $tmp );
		return $id;
	}

	$alt = sanitize_text_field( _ww_data_to_string( $input['alt'] ?? '' ) );
	if ( '' !== $alt ) {
		update_post_meta( $id, '_wp_attachment_image_alt', wp_slash( $alt ) );
	}
	return _ww_abilities_media_summary( $id );
}

/*
 * Redirects en het 404-logboek: alleen voor de beheerder, net als het beheerscherm.
 */

/**
 * Mag de gebruiker de redirects en het 404-logboek beheren? Net als het scherm Redirects.
 */
function _ww_ability_can_manage_redirects(): bool {
	return current_user_can( 'manage_options' );
}

/**
 * Pagina en aantal per pagina uit de invoer: hoogstens 500 per pagina.
 *
 * @param array<string,mixed> $input page en per_page.
 * @return array{0:int,1:int} Pagina en aantal per pagina.
 */
function _ww_abilities_redirect_paging( array $input ): array {
	$per_page = min( 500, max( 1, absint( $input['per_page'] ?? 100 ) ) );
	$page     = max( 1, absint( $input['page'] ?? 1 ) );
	return array( $page, $per_page );
}

/**
 * Importeert redirects, of toont standaard alleen het voorbeeld (dry_run staat standaard aan).
 *
 * @param array<string,mixed> $input rules en dry_run.
 * @return array<string,mixed>
 */
function _ww_ability_import_redirects( array $input ): array {
	$rules = array();
	foreach ( (array) ( $input['rules'] ?? array() ) as $rule ) {
		if ( ! is_array( $rule ) ) {
			continue;
		}
		$rules[] = array(
			'source'     => _ww_data_to_string( $rule['source'] ?? '' ),
			'target'     => _ww_data_to_string( $rule['target'] ?? '' ),
			'status'     => $rule['status'] ?? 301,
			'match_type' => $rule['type'] ?? 'exact',
		);
	}

	$dry_run = (bool) ( $input['dry_run'] ?? true );
	_ww_redirects_ensure_ready();
	return array( 'dry_run' => $dry_run ) + _ww_redirects_import( $rules, $dry_run );
}

/**
 * De redirects, met zoeken, filter op herkomst en paginering.
 *
 * @param array<string,mixed> $input search, origin, page, per_page.
 * @return array<string,mixed>
 */
function _ww_ability_list_redirects( array $input = array() ): array {
	global $wpdb;
	list( $page, $per_page ) = _ww_abilities_redirect_paging( $input );
	if ( ! _ww_redirects_ensure_ready() ) {
		return array(
			'redirects' => array(),
			'total'     => 0,
			'page'      => $page,
			'per_page'  => $per_page,
		);
	}

	$where  = array( '1=1' );
	$params = array();
	$search = sanitize_text_field( _ww_data_to_string( $input['search'] ?? '' ) );
	if ( '' !== $search ) {
		$like     = '%' . $wpdb->esc_like( $search ) . '%';
		$where[]  = '(source LIKE %s OR target LIKE %s)';
		$params[] = $like;
		$params[] = $like;
	}
	$origin = _ww_data_to_string( $input['origin'] ?? '' );
	if ( in_array( $origin, array( 'manual', 'import', 'slug' ), true ) ) {
		$where[]  = 'origin = %s';
		$params[] = $origin;
	}
	$clause = implode( ' AND ', $where );
	$table  = _ww_redirects_table();

	$count = "SELECT COUNT(*) FROM $table WHERE $clause";
	$total = (int) $wpdb->get_var( array() === $params ? $count : $wpdb->prepare( $count, $params ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- tabelnaam en voorwaarden zijn eigen waarden; zonder parameters is er niets te prepareren.
	$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT id, source, target, status, match_type, origin, post_id, hits, last_hit, created FROM $table WHERE $clause ORDER BY id ASC LIMIT %d OFFSET %d", array_merge( $params, array( $per_page, ( $page - 1 ) * $per_page ) ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- tabelnaam en voorwaarden zijn eigen waarden.

	return array(
		'redirects' => array_map(
			static fn( $row ): array => array(
				'id'       => (int) $row->id,
				'source'   => (string) $row->source,
				'target'   => (string) $row->target,
				'status'   => (int) $row->status,
				'type'     => (string) $row->match_type,
				'origin'   => (string) $row->origin,
				'post_id'  => (int) $row->post_id,
				'hits'     => (int) $row->hits,
				'last_hit' => null === $row->last_hit ? null : (string) $row->last_hit,
				'created'  => (string) $row->created,
			),
			(array) $rows
		),
		'total'     => $total,
		'page'      => $page,
		'per_page'  => $per_page,
	);
}

/**
 * Het 404-logboek, meest gevraagd eerst.
 *
 * @param array<string,mixed> $input min_hits, page, per_page.
 * @return array<string,mixed>
 */
function _ww_ability_list_404_log( array $input = array() ): array {
	global $wpdb;
	list( $page, $per_page ) = _ww_abilities_redirect_paging( $input );
	$min_hits                = max( 1, absint( $input['min_hits'] ?? 1 ) );
	$table                   = _ww_404_log_table();
	if ( ! _ww_redirects_ensure_ready() ) {
		return array(
			'log'      => array(),
			'total'    => 0,
			'page'     => $page,
			'per_page' => $per_page,
		);
	}

	$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE hits >= %d", $min_hits ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_404_log_table().
	$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT path, hits, first_seen, last_seen, referrer FROM $table WHERE hits >= %d ORDER BY hits DESC, last_seen DESC, path ASC LIMIT %d OFFSET %d", $min_hits, $per_page, ( $page - 1 ) * $per_page ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_404_log_table().

	return array(
		'log'      => array_map(
			static fn( $row ): array => array(
				'path'       => (string) $row->path,
				'hits'       => (int) $row->hits,
				'first_seen' => (string) $row->first_seen,
				'last_seen'  => (string) $row->last_seen,
				'referrer'   => (string) $row->referrer,
			),
			(array) $rows
		),
		'total'    => $total,
		'page'     => $page,
		'per_page' => $per_page,
	);
}

/*
 * Formulieren (beslissing 0032).
 */

/**
 * Mag de gebruiker formulieren en inzendingen via abilities beheren? Alleen de beheerder.
 */
function _ww_ability_can_manage_forms(): bool {
	return current_user_can( 'manage_options' );
}

/**
 * De taal van een formulier: met Meertalig actief die van de module (0043), anders null.
 */
function _ww_abilities_form_language( int $id ): ?string {
	if ( ! _ww_languages_active() ) {
		return null;
	}
	$lang = _ww_post_language( $id );
	return '' !== $lang ? $lang : null;
}

/**
 * Op productie (een andere host dan WW_ABILITIES_WRITE_HOST, met Meertalig, een formulier in een extra taal) mag save-form
 * alleen teksten veranderen (labels, meldingen, mailteksten). Wat bepaalt waar een inzending heen gaat, blijft zoals het is:
 * de ontvangers van de melding (mail.notify.to, en enabled: uit betekent geen ontvangers), de opslag (storage, helemaal) en
 * de doorverwijzing na versturen (after.type, after.page_id, after.url; after.message blijft vrij). reply_to_field blijft
 * vrij: het zet alleen de Reply-To op het adres van de inzender, de ontvangers veranderen niet. Ook mail.confirm blijft
 * vrij (die gaat naar de inzender). Een concept publiceren kan er niet. Ontbrekende sleutels krijgen in $input de
 * opgeslagen waarden, zodat een vertaling die ze weglaat of ongewijzigd terugstuurt gewoon opslaat. Vergeleken wordt na de
 * opschoning. Fout ww_abilities_locked als de invoer een vergrendelde sleutel verandert of een concept publiceert, anders
 * null (vóór elke wijziging).
 *
 * @param int                 $id     Bestaand formulier.
 * @param string|null         $status Gevraagde status.
 * @param array<string,mixed> $input  Invoer van de ability; config wordt aangevuld.
 */
function _ww_abilities_form_production_guard( int $id, ?string $status, array &$input ): ?WP_Error {
	$expected = defined( 'WW_ABILITIES_WRITE_HOST' ) ? _ww_data_to_string( constant( 'WW_ABILITIES_WRITE_HOST' ) ) : '';
	if ( ! _ww_languages_active() || null === _ww_abilities_write_error( $expected, (string) wp_parse_url( home_url(), PHP_URL_HOST ) )
		|| WW_FORM_POST_TYPE !== get_post_type( $id ) || ! in_array( _ww_post_language( $id ), _ww_extra_language_codes(), true ) ) {
		return null;
	}
	if ( 'publish' === $status && 'publish' !== get_post_status( $id ) ) {
		return new WP_Error( 'ww_abilities_locked', __( 'Op deze site kan save-form geen concept publiceren. Publiceer het formulier op de staging-site of in de formulierbouwer.', 'webwerckt-base' ), array( 'status' => 403 ) );
	}
	$stored = _ww_form_config( $id );
	if ( ! isset( $input['config'] ) || ! is_array( $input['config'] ) || null === $stored ) {
		return null;
	}

	$config         = $input['config'];
	$mail           = _ww_form_array( $config['mail'] ?? array() );
	$mail['notify'] = _ww_form_array( $mail['notify'] ?? array() ) + $stored['mail']['notify'];
	$config['mail'] = $mail;
	foreach ( array( 'after', 'storage' ) as $key ) {
		$config[ $key ] = _ww_form_array( $config[ $key ] ?? array() ) + $stored[ $key ];
	}
	$clean = ww_form_sanitize( $config )['config'];
	$routing = static fn( array $form ): array => array(
		$form['mail']['notify']['to'],
		$form['mail']['notify']['enabled'],
		$form['storage'],
		$form['after']['type'],
		$form['after']['page_id'],
		$form['after']['url'],
	);
	if ( $routing( $clean ) !== $routing( $stored ) ) {
		return new WP_Error( 'ww_abilities_locked', __( 'Op deze site kan save-form de ontvangers van de melding (mail.notify.to en enabled), de opslag (storage) en de doorverwijzing na versturen (after.type, page_id en url) niet veranderen. Dat kan op de staging-site of in de formulierbouwer. Teksten vertalen mag wel.', 'webwerckt-base' ), array( 'status' => 403 ) );
	}
	$input['config'] = $config;
	return null;
}

/**
 * Maakt een formulier of werkt er een bij.
 *
 * @param array<string,mixed> $input id, title, slug, status en config.
 * @return array<string,mixed>|WP_Error
 */
function _ww_ability_save_form( array $input = array() ) {
	$id       = absint( $input['id'] ?? 0 );
	$creating = 0 === $id;
	$title    = isset( $input['title'] ) ? trim( _ww_data_to_string( $input['title'] ) ) : null;
	$status   = isset( $input['status'] ) ? _ww_data_to_string( $input['status'] ) : null;
	if ( null !== $status && ! in_array( $status, array( 'publish', 'draft' ), true ) ) {
		return new WP_Error( 'ww_abilities_form', __( 'De status moet publish of draft zijn.', 'webwerckt-base' ), array( 'status' => 400 ) );
	}
	if ( isset( $input['config'] ) && ! is_array( $input['config'] ) ) {
		return new WP_Error( 'ww_abilities_form', __( 'De configuratie moet een object zijn.', 'webwerckt-base' ), array( 'status' => 400 ) );
	}
	$locked = $creating ? null : _ww_abilities_form_production_guard( $id, $status, $input );
	if ( null !== $locked ) {
		return $locked;
	}

	if ( $creating ) {
		if ( null === $title || '' === $title ) {
			return new WP_Error( 'ww_abilities_form', __( 'Een nieuw formulier heeft een titel nodig.', 'webwerckt-base' ), array( 'status' => 400 ) );
		}
	} elseif ( WW_FORM_POST_TYPE !== get_post_type( $id ) ) {
		return new WP_Error( 'ww_abilities_form', __( 'Formulier niet gevonden.', 'webwerckt-base' ), array( 'status' => 404 ) );
	}

	$post = array( 'post_type' => WW_FORM_POST_TYPE );
	if ( ! $creating ) {
		$post['ID'] = $id;
	}
	if ( null !== $title && '' !== $title ) {
		$post['post_title'] = $title;
	}
	if ( isset( $input['slug'] ) && '' !== _ww_data_to_string( $input['slug'] ) ) {
		$post['post_name'] = sanitize_title( _ww_data_to_string( $input['slug'] ) );
	}
	if ( null !== $status || $creating ) {
		$post['post_status'] = $status ?? 'draft';
	}
	$saved = $creating ? wp_insert_post( wp_slash( $post ), true ) : wp_update_post( wp_slash( $post ), true );
	if ( is_wp_error( $saved ) ) {
		return $saved;
	}
	$id = (int) $saved;

	$warnings = array();
	if ( isset( $input['config'] ) ) {
		$warnings = _ww_form_save_config( $id, $input['config'] );
	} elseif ( $creating ) {
		$warnings = _ww_form_save_config( $id, _ww_form_default_config() );
	}

	return array(
		'id'       => $id,
		'status'   => get_post_status( $id ),
		'config'   => _ww_form_config( $id ),
		'warnings' => $warnings,
	);
}

/**
 * Alle formulieren (elke status behalve de prullenbak) met hun configuratie.
 *
 * @return array{forms: list<array<string,mixed>>}
 */
function _ww_ability_list_forms(): array {
	$posts = get_posts(
		array(
			'post_type'        => WW_FORM_POST_TYPE,
			'post_status'      => array( 'publish', 'draft', 'pending', 'private', 'future' ),
			'posts_per_page'   => -1,
			'orderby'          => 'ID',
			'order'            => 'ASC',
			'suppress_filters' => true,
			'lang'             => '', // Met Meertalig: alle talen (_ww_languages_query_language()).
		)
	);
	$forms = array();
	foreach ( $posts as $post ) {
		$form = array(
			'id'       => $post->ID,
			'title'    => get_the_title( $post ),
			'slug'     => $post->post_name,
			'status'   => $post->post_status,
			'language' => _ww_abilities_form_language( $post->ID ),
			'config'   => _ww_form_config( $post->ID ),
		);
		if ( _ww_languages_active() ) {
			// Zoals list-posts (0043).
			$form['lang']         = _ww_post_language( $post->ID );
			$form['translations'] = _ww_translation_overview( $post->ID );
		}
		$forms[] = $form;
	}
	return array( 'forms' => $forms );
}

/**
 * De velden van een inzending voor een ability: bij een bestandsveld alleen name, size en mime. De naam op
 * schijf (en dus het pad) gaat nooit mee.
 *
 * @param mixed $fields De velden van de inzending.
 * @return array<string,mixed>
 */
function _ww_abilities_entry_fields( $fields ): array {
	$fields = is_array( $fields ) ? $fields : array();
	foreach ( $fields as $key => $field ) {
		if ( ! is_array( $field ) || 'file' !== ( $field['type'] ?? '' ) ) {
			continue;
		}
		$files = array();
		foreach ( is_array( $field['value'] ?? null ) ? $field['value'] : array() as $file ) {
			if ( is_array( $file ) ) {
				$files[] = array(
					'name' => (string) ( $file['name'] ?? '' ),
					'size' => (int) ( $file['size'] ?? 0 ),
					'mime' => (string) ( $file['mime'] ?? '' ),
				);
			}
		}
		$fields[ $key ]['value'] = $files;
	}
	return $fields;
}

/**
 * Inzendingen, met filters en paginering. Zet niets op gelezen.
 *
 * @param array<string,mixed> $input form_id, status, page en per_page.
 * @return array<string,mixed>
 */
function _ww_ability_list_form_entries( array $input = array() ): array {
	list( $page, $per_page ) = _ww_abilities_redirect_paging( $input );
	$status                  = _ww_data_to_string( $input['status'] ?? '' );
	$form_id                 = absint( $input['form_id'] ?? 0 );
	$languages               = _ww_languages_active();
	// Met Meertalig de vertaalgroep van het formulier, zoals de lijst in het beheer (0043).
	$filter                  = $languages && $form_id > 0 ? array( 'form_ids' => _ww_form_group_ids( $form_id ) ) : array( 'form_id' => $form_id );
	$result                  = _ww_form_entries_query(
		$filter + array(
			'status'   => in_array( $status, array( 'new', 'read', 'spam' ), true ) ? $status : '',
			'page'     => $page,
			'per_page' => $per_page,
		)
	);
	$items                   = array();
	foreach ( $result['items'] as $entry ) {
		$item = array(
			'id'          => (int) $entry->id,
			'form_id'     => (int) $entry->form_id,
			'created'     => (string) $entry->created,
			'fields'      => _ww_abilities_entry_fields( $entry->fields ),
			'page_url'    => (string) $entry->page_url,
			'status'      => (string) $entry->status,
			'recaptcha'   => (string) $entry->recaptcha,
			'mail_status' => (string) $entry->mail_status,
		);
		if ( $languages ) {
			$item['lang'] = _ww_post_language( (int) $entry->form_id );
		}
		$items[] = $item;
	}
	return array(
		'items'    => $items,
		'total'    => $result['total'],
		'page'     => $page,
		'per_page' => $per_page,
	);
}
