<?php
/**
 * Verwerking van een inzending (beslissing 0032): honeypot, limiet, validatie, opslaan, mails en het antwoord.
 *
 * Een formulier verstuurt naar zijn eigen pagina. _ww_form_handle_post() vangt die POST op template_redirect op en
 * antwoordt met JSON (form.js stuurt de header X-WW-Form: 1), met een 303 na succes, of laat WordPress de pagina
 * gewoon opbouwen met de foutentoestand (via het filter _ww_form_state, dat ww_form() leest). Geen nonce: een nonce
 * veroudert in de paginacache en beschermt een open formulier niet. Het IP-adres wordt nergens opgeslagen, alleen een
 * hash ervan in de naam van een transient.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bewaart de uitkomst van de verwerking in deze aanvraag, voor de weergave zonder JavaScript.
 *
 * @param array<string,mixed>|null $set Nieuwe toestand (form_id, values, errors, general); array() wist hem.
 * @return array<string,mixed>
 */
function _ww_form_posted( ?array $set = null ): array {
	static $posted = array();
	if ( null !== $set ) {
		$posted = $set;
	}
	return $posted;
}

/**
 * Geeft de bewaarde toestand door aan de weergave, alleen voor het formulier dat verstuurd is.
 *
 * Na een te grote POST is niet bekend welk formulier het was: dan krijgt elk formulier met een bestandsveld de
 * algemene melding.
 *
 * @param array<string,mixed> $state   Toestand.
 * @param int                 $form_id Formulier dat wordt weergegeven.
 * @return array<string,mixed>
 */
function _ww_form_posted_state( $state, $form_id ) {
	$posted = _ww_form_posted();
	if ( ! $posted ) {
		return $state;
	}
	if ( ! empty( $posted['too_large'] ) ) {
		$config = _ww_form_config( (int) $form_id );
		if ( ! $config || ! _ww_form_has_file_field( $config ) ) {
			return $state;
		}
		$state            = _ww_form_array( $state );
		$state['general'] = $posted['general'];
		return $state;
	}
	if ( (int) $form_id !== (int) $posted['form_id'] ) {
		return $state;
	}
	$state             = _ww_form_array( $state );
	$state['values']   = $posted['values'];
	$state['errors']   = $posted['errors'];
	$state['general']  = $posted['general'];
	$state['reselect'] = ! empty( $posted['reselect'] );
	return $state;
}
add_filter( '_ww_form_state', '_ww_form_posted_state', 10, 2 );

/**
 * Het IP-adres van de bezoeker, voor de limiet. Achter een proxy of CDN past het filter ww_form_client_ip het aan.
 */
function _ww_form_client_ip(): string {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated -- isset hierboven.
	return _ww_form_string( apply_filters( 'ww_form_client_ip', $ip ) );
}

/**
 * De limiet: hoogstens max geldige inzendingen per window seconden (filter ww_form_rate_limit).
 *
 * @return array{max: int, window: int}
 */
function _ww_form_rate_settings(): array {
	$limit = _ww_form_array(
		apply_filters(
			'ww_form_rate_limit',
			array(
				'max'    => 5,
				'window' => 600,
			)
		)
	);
	return array(
		'max'    => max( 1, (int) ( $limit['max'] ?? 5 ) ),
		'window' => max( 1, (int) ( $limit['window'] ?? 600 ) ),
	);
}

/**
 * De naam van de transient voor deze bezoeker: een hash van het IP-adres, nooit het adres zelf.
 */
function _ww_form_rate_key(): string {
	return 'ww_form_rl_' . substr( hash_hmac( 'sha256', _ww_form_client_ip(), wp_salt( 'nonce' ) ), 0, 32 );
}

/**
 * De telling van deze bezoeker in het lopende venster, of null als er geen is.
 *
 * @return array{count: int, start: int}|null
 */
function _ww_form_rate_current(): ?array {
	$rate = get_transient( _ww_form_rate_key() );
	if ( ! is_array( $rate ) || ! isset( $rate['count'], $rate['start'] ) ) {
		return null;
	}
	$rate = array(
		'count' => (int) $rate['count'],
		'start' => (int) $rate['start'],
	);
	return time() - $rate['start'] < _ww_form_rate_settings()['window'] ? $rate : null;
}

/**
 * Heeft deze bezoeker de limiet bereikt?
 */
function _ww_form_rate_limited(): bool {
	$rate = _ww_form_rate_current();
	return null !== $rate && $rate['count'] >= _ww_form_rate_settings()['max'];
}

/**
 * Telt een geldige inzending. Het venster is vast: het begint bij de eerste inzending en schuift niet op.
 */
function _ww_form_rate_hit(): void {
	$window = _ww_form_rate_settings()['window'];
	$rate   = _ww_form_rate_current() ?? array(
		'count' => 0,
		'start' => time(),
	);
	++$rate['count'];
	set_transient( _ww_form_rate_key(), $rate, max( 1, $window - ( time() - $rate['start'] ) ) );
}

/**
 * Een tekst uit de invoer; een array of object is geen tekst en telt als ongeldig.
 *
 * @param mixed $value Invoer.
 * @return string|null Null bij geen tekst.
 */
function _ww_form_input_string( $value ): ?string {
	if ( null === $value ) {
		return '';
	}
	return is_scalar( $value ) ? (string) $value : null;
}

/**
 * Schoont ingevulde tekst op zoals WordPress dat doet, maar laat een losse < staan. De opschoning van WordPress maakt
 * daar &lt; van, en dat is geen veilige HTML maar gewoon verkeerde tekst in de mail en de CSV. Alles wat de waarde
 * toont, escapet hem zelf.
 *
 * @param string $value     Ingevulde tekst.
 * @param bool   $multiline Regeleindes bewaren.
 */
function _ww_form_clean_input( string $value, bool $multiline = false ): string {
	$clean = $multiline ? sanitize_textarea_field( $value ) : sanitize_text_field( $value );
	return false !== strpos( $value, '<' ) ? wp_specialchars_decode( $clean, ENT_QUOTES ) : $clean;
}

/**
 * Controleert de invoer tegen de velden van de configuratie. Velden die niet in de configuratie staan, gaan eruit.
 *
 * Waarden: veldsleutel => tekst; bij een vinkje '1' of ''; bij een keuzeveld met meerdere keuzes een lijst zonder
 * dubbelen. Een array waar een tekst hoort (ww_fields[naam][]=x) geldt als lege of ongeldige waarde, met een gewone
 * foutmelding.
 *
 * @param array<string,mixed> $config Opgeschoonde configuratie.
 * @param mixed               $input  ww_fields uit de POST, na wp_unslash; geen array geldt als lege invoer.
 * @return array{values: array<string,mixed>, errors: array<string,string>}
 */
function _ww_form_validate( array $config, $input ): array {
	$input    = _ww_form_array( $input );
	$values   = array();
	$errors   = array();
	$required = __( 'Dit veld is verplicht.', 'webwerckt-base' );
	$option   = __( 'Kies een van de opties', 'webwerckt-base' );
	/* translators: %d: het grootste aantal tekens. */
	$too_long = __( 'Maximaal %d tekens.', 'webwerckt-base' );

	foreach ( _ww_form_array( $config['fields'] ?? array() ) as $field ) {
		$key   = (string) $field['key'];
		$raw   = $input[ $key ] ?? null;
		$error = '';

		switch ( $field['type'] ) {
			case 'line':
				$value = _ww_form_clean_input( (string) _ww_form_input_string( $raw ) );
				$input_type = (string) ( $field['input'] ?? 'text' );
				$max        = 'tel' === $input_type ? 30 : 255;
				if ( '' === $value ) {
					break;
				}
				if ( mb_strlen( $value ) > $max ) {
					$error = sprintf( $too_long, $max );
				} elseif ( 'email' === $input_type && ! is_email( $value ) ) {
					$error = __( 'Vul een geldig e-mailadres in.', 'webwerckt-base' );
				} elseif ( 'tel' === $input_type && ! preg_match( '/^[0-9 +\-()]+$/', $value ) ) {
					$error = __( 'Vul een geldig telefoonnummer in.', 'webwerckt-base' );
				}
				break;

			case 'text':
				// Eén regeleinde is één teken, net als voor maxlength in de browser.
				$value = _ww_form_clean_input( str_replace( array( "\r\n", "\r" ), "\n", (string) _ww_form_input_string( $raw ) ), true );
				$max   = (int) $field['max_length'];
				if ( mb_strlen( $value ) > $max ) {
					$error = sprintf( $too_long, $max );
				}
				break;

			case 'checkbox':
				$value = '1' === _ww_form_input_string( $raw ) ? '1' : '';
				break;

			case 'select':
			case 'choice':
				$allowed = array_column( _ww_form_array( $field['options'] ?? array() ), 'value' );
				if ( 'choice' === $field['type'] && ! empty( $field['multiple'] ) ) {
					$value = array();
					foreach ( is_array( $raw ) ? $raw : ( null === $raw || '' === $raw ? array() : array( $raw ) ) as $one ) {
						$one = _ww_form_input_string( $one );
						if ( null === $one || ! in_array( $one, $allowed, true ) ) {
							$error = $option;
						} elseif ( ! in_array( $one, $value, true ) ) {
							$value[] = $one;
						}
					}
					break;
				}
				$one = _ww_form_input_string( $raw );
				if ( null === $one || ( '' !== $one && ! in_array( $one, $allowed, true ) ) ) {
					$error = $option;
					$one   = '';
				}
				$value = $one;
				break;

			default:
				continue 2;
		}

		if ( '' === $error && ! empty( $field['required'] ) && ( '' === $value || array() === $value ) ) {
			$error = $required;
		}
		$values[ $key ] = $value;
		if ( '' !== $error ) {
			$errors[ $key ] = $error;
		}
	}

	return array(
		'values' => $values,
		'errors' => $errors,
	);
}

/**
 * Zet $_FILES['ww_files'] om van de geneste vorm van PHP (name[sleutel][n], type[sleutel][n], …) naar een lijst
 * bestanden per veldsleutel. Een losse waarde (ww_files[cv] zonder []) wordt een lijst van één. Geen array: array().
 *
 * @param mixed $raw $_FILES['ww_files'].
 * @return array<string, list<array{name: string, type: string, tmp_name: string, error: int, size: int}>>
 */
function _ww_form_files_input( $raw ): array {
	if ( ! is_array( $raw ) || ! is_array( $raw['name'] ?? null ) ) {
		return array();
	}
	$files = array();
	foreach ( $raw['name'] as $key => $names ) {
		$key   = (string) $key;
		$names = is_array( $names ) ? $names : array( $names );
		$list  = array();
		foreach ( $names as $n => $name ) {
			$part = static function ( string $prop ) use ( $raw, $key, $n ) {
				$value = $raw[ $prop ][ $key ] ?? null;
				return is_array( $value ) ? ( $value[ $n ] ?? null ) : $value;
			};
			$tmp   = $part( 'tmp_name' );
			$type  = $part( 'type' );
			$error = $part( 'error' );
			$size  = $part( 'size' );
			if ( ! is_scalar( $name ) ) {
				continue;
			}
			$list[] = array(
				'name'     => (string) $name,
				'type'     => is_scalar( $type ) ? (string) $type : '',
				'tmp_name' => is_scalar( $tmp ) ? (string) $tmp : '',
				'error'    => is_numeric( $error ) ? (int) $error : UPLOAD_ERR_NO_FILE,
				'size'     => is_numeric( $size ) ? (int) $size : 0,
			);
		}
		if ( $list ) {
			$files[ $key ] = $list;
		}
	}
	return $files;
}

/**
 * Is er bij een bestandsveld van dit formulier een bestand gekozen (ook een bestand dat daarna geweigerd wordt)?
 *
 * @param array<string,mixed>                     $config Opgeschoonde configuratie.
 * @param array<string, list<array<string,mixed>>> $files  Uitvoer van _ww_form_files_input().
 */
function _ww_form_files_chosen( array $config, array $files ): bool {
	foreach ( _ww_form_array( $config['fields'] ?? array() ) as $field ) {
		if ( 'file' !== $field['type'] ) {
			continue;
		}
		foreach ( _ww_form_array( $files[ $field['key'] ] ?? array() ) as $file ) {
			if ( UPLOAD_ERR_NO_FILE !== (int) ( $file['error'] ?? UPLOAD_ERR_NO_FILE ) ) {
				return true;
			}
		}
	}
	return false;
}

/**
 * De naam van een bestand om te tonen: opgeschoond met sanitize_file_name() en hoogstens 150 tekens, met behoud van
 * de extensie. Op schijf krijgt het bestand altijd een willekeurige naam.
 *
 * @param string $name Naam zoals de bezoeker hem stuurde.
 */
function _ww_form_file_name( string $name ): string {
	$name = sanitize_file_name( wp_check_invalid_utf8( $name, true ) );
	if ( mb_strlen( $name ) <= 150 ) {
		return $name;
	}
	$dot = mb_strrpos( $name, '.' );
	$ext = false !== $dot && mb_strlen( $name ) - $dot <= 10 ? mb_substr( $name, $dot ) : '';
	return mb_substr( $name, 0, 150 - mb_strlen( $ext ) ) . $ext;
}

/**
 * Controleert de bestanden per bestandsveld (spec "Verwerking › 3"). Per veld de eerste fout; bij een fout in een veld
 * gaan de bestanden van dat veld niet door.
 *
 * Het type komt uit de inhoud (wp_check_filetype_and_ext() met de mimes van de gekozen groepen), niet uit de naam: een
 * php-bestand met de naam cv.pdf wordt geweigerd, net als cv.pdf.php.
 *
 * @param array<string,mixed>                     $config Opgeschoonde configuratie.
 * @param array<string, list<array<string,mixed>>> $files  Uitvoer van _ww_form_files_input().
 * @return array{files: array<string, list<array{name: string, tmp: string, ext: string, mime: string, size: int}>>, errors: array<string,string>}
 */
function _ww_form_validate_files( array $config, array $files ): array {
	$messages = _ww_form_file_messages();
	$valid    = array();
	$errors   = array();

	foreach ( _ww_form_array( $config['fields'] ?? array() ) as $field ) {
		if ( 'file' !== $field['type'] ) {
			continue;
		}
		$key           = (string) $field['key'];
		$limit         = _ww_form_file_limit_mb( $field );
		$valid[ $key ] = array();
		$chosen        = array();
		$error         = '';

		foreach ( _ww_form_array( $files[ $key ] ?? array() ) as $file ) {
			$code = (int) ( $file['error'] ?? UPLOAD_ERR_NO_FILE );
			if ( UPLOAD_ERR_NO_FILE === $code ) {
				continue;
			}
			if ( UPLOAD_ERR_INI_SIZE === $code || UPLOAD_ERR_FORM_SIZE === $code ) {
				$error = sprintf( $messages['file_too_big'], $limit );
				break;
			}
			if ( UPLOAD_ERR_OK !== $code ) {
				error_log( sprintf( 'webwerckt-base: uploadfout %d bij veld %s van formulier.', $code, $key ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- bedoelde melding in het PHP-logboek.
				$error = $messages['upload_failed'];
				break;
			}
			$chosen[] = $file;
		}

		if ( '' === $error && ! $chosen && ! empty( $field['required'] ) ) {
			$error = __( 'Dit veld is verplicht.', 'webwerckt-base' );
		}
		if ( '' === $error && count( $chosen ) > (int) ( $field['max_files'] ?? 1 ) ) {
			$error = sprintf( $messages['too_many'], (int) ( $field['max_files'] ?? 1 ) );
		}

		$checked = array();
		if ( '' === $error ) {
			$mimes = _ww_form_file_mimes( $field );
			$exts  = _ww_form_file_extensions( $field );
			foreach ( $chosen as $file ) {
				$name = _ww_form_file_name( (string) ( $file['name'] ?? '' ) );
				$tmp  = (string) ( $file['tmp_name'] ?? '' );
				$size = (int) ( $file['size'] ?? 0 );
				if ( $size > $limit * MB_IN_BYTES ) {
					$error = sprintf( $messages['too_big'], $name, $limit );
					break;
				}
				if ( '' === $tmp || ! _ww_form_is_uploaded( $tmp ) ) {
					error_log( sprintf( 'webwerckt-base: bestand bij veld %s is geen ontvangen upload.', $key ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- bedoelde melding in het PHP-logboek.
					$error = $messages['upload_failed'];
					break;
				}
				$type = wp_check_filetype_and_ext( $tmp, $name, $mimes );
				$ext  = strtolower( (string) $type['ext'] );
				$mime = (string) $type['type'];
				if ( '' === $ext || '' === $mime || ! in_array( $ext, $exts, true ) ) {
					$error = sprintf( $messages['bad_type'], $name, implode( ', ', $exts ) );
					break;
				}
				$checked[] = array(
					'name' => $name,
					'tmp'  => $tmp,
					'ext'  => $ext,
					'mime' => $mime,
					'size' => $size,
				);
			}
		}

		if ( '' !== $error ) {
			$errors[ $key ] = $error;
		} else {
			$valid[ $key ] = $checked;
		}
	}

	return array(
		'files'  => $valid,
		'errors' => $errors,
	);
}

/**
 * De velden van een inzending zoals ze in de tabel komen: label, type, waarde en de tekst om te tonen.
 *
 * @param array<string,mixed> $config Opgeschoonde configuratie.
 * @param array<string,mixed> $values Waarden per sleutel.
 * @return array<string,array{label:string,type:string,value:mixed,display:string}>
 */
function _ww_form_entry_fields( array $config, array $values ): array {
	$fields = array();
	foreach ( $config['fields'] as $field ) {
		$value                   = $values[ $field['key'] ] ?? '';
		$fields[ $field['key'] ] = array(
			'label'   => _ww_form_mail_plain( (string) $field['label'] ),
			'type'    => (string) $field['type'],
			'value'   => $value,
			'display' => _ww_form_display_value( $field, $value ),
		);
	}
	return $fields;
}

/**
 * De uitkomst "Versturen is niet gelukt" (500) met de ingevulde waarden, voor als er niets bewaard of verstuurd is.
 *
 * @param array<string,mixed> $values   Gecontroleerde invoer.
 * @param bool                $reselect Er was een bestand gekozen.
 * @return array<string,mixed>
 */
function _ww_form_send_failed( array $values, bool $reselect ): array {
	$email = trim( _ww_setting_string( 'email' ) );
	if ( ! is_email( $email ) ) {
		$email = (string) get_option( 'admin_email' );
	}
	/* translators: %s: e-mailadres van de site. */
	$result             = _ww_form_failure( 500, sprintf( __( 'Versturen is niet gelukt. Probeer het later opnieuw of mail ons op %s.', 'webwerckt-base' ), $email ) );
	$result['values']   = $values;
	$result['reselect'] = $reselect;
	return $result;
}

/**
 * De grootte van post_max_size in bytes (0 is onbeperkt).
 */
function _ww_form_post_max_bytes(): int {
	return (int) wp_convert_hr_to_bytes( (string) ini_get( 'post_max_size' ) );
}

/**
 * Was deze POST groter dan post_max_size? Dan heeft PHP $_POST en $_FILES geleegd en zou de inzending verdwijnen.
 */
function _ww_form_post_too_large(): bool {
	// phpcs:disable WordPress.Security.NonceVerification -- alleen kijken of de POST leeg is.
	$method = isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated -- isset hierboven.
	if ( 'POST' !== strtoupper( $method ) || ! empty( $_POST ) || ! empty( $_FILES ) ) {
		return false;
	}
	// phpcs:enable WordPress.Security.NonceVerification
	$length = isset( $_SERVER['CONTENT_LENGTH'] ) ? (int) $_SERVER['CONTENT_LENGTH'] : 0;
	$max    = _ww_form_post_max_bytes();
	return $max > 0 && $length > $max;
}

/**
 * De melding bij een te grote POST: "Je bestanden zijn samen te groot. Het maximum is {n} MB."
 */
function _ww_form_post_too_large_message(): string {
	return sprintf( _ww_form_file_messages()['post_too_big'], max( 1, (int) floor( _ww_form_post_max_bytes() / MB_IN_BYTES ) ) );
}

/**
 * De URL na versturen met het bericht: de pagina met precies één ww_form_sent.
 *
 * @param string $page_url Pagina, eventueel met query-string.
 * @param int    $form_id  Formulier.
 */
function _ww_form_sent_url( string $page_url, int $form_id ): string {
	return add_query_arg( 'ww_form_sent', $form_id, remove_query_arg( 'ww_form_sent', $page_url ) );
}

/**
 * Waar een geslaagde inzending heen gaat: een gepubliceerde bedankpagina, anders after.url, anders het bericht op de
 * pagina zelf. De pagina wordt nu gecontroleerd, want hij kan na het opslaan van het formulier zijn verwijderd.
 *
 * @param int                 $form_id  Formulier.
 * @param array<string,mixed> $config   Opgeschoonde configuratie.
 * @param string              $page_url Pagina van de POST, met query-string.
 * @return array<string,mixed>
 */
function _ww_form_success( int $form_id, array $config, string $page_url ): array {
	$after  = _ww_form_array( $config['after'] ?? array() );
	$result = array(
		'status'   => 200,
		'ok'       => true,
		'errors'   => array(),
		'labels'   => array(),
		'values'   => array(),
		'message'  => '',
		'type'     => 'message',
		'url'      => '',
		'reselect' => false,
	);

	if ( 'redirect' === ( $after['type'] ?? '' ) ) {
		$page_id = (int) ( $after['page_id'] ?? 0 );
		$target  = '';
		if ( $page_id > 0 && 'page' === get_post_type( $page_id ) && 'publish' === get_post_status( $page_id ) ) {
			$target = (string) get_permalink( $page_id );
		}
		if ( '' === $target ) {
			$target = _ww_form_string( $after['url'] ?? '' );
		}
		if ( '' !== $target ) {
			$result['type'] = 'redirect';
			$result['url']  = $target;
			return $result;
		}
	}

	$result['message'] = wp_kses_post( _ww_form_after_message( $config ) );
	$result['url']     = _ww_form_sent_url( $page_url, $form_id );
	return $result;
}

/**
 * Een uitkomst met een algemene fout.
 *
 * @param int    $status  HTTP-status.
 * @param string $message Melding.
 * @return array<string,mixed>
 */
function _ww_form_failure( int $status, string $message ): array {
	return array(
		'status'   => $status,
		'ok'       => false,
		'errors'   => array(),
		'labels'   => array(),
		'values'   => array(),
		'message'  => $message,
		'type'     => 'message',
		'url'      => '',
		'reselect' => false,
	);
}

/**
 * Verwerkt een inzending zonder headers te sturen of te stoppen.
 *
 * Volgorde: formulier, honeypot, limiet, valideren (velden en bestanden), reCAPTCHA, dan spam of opslaan. Opslaan:
 * de inzending (bestandsvelden nog leeg), de bestanden in de afgeschermde map, de metadata in de inzending, mails, de
 * regel "niets bewaard" (500), tellen voor de limiet, de actie ww_form_submitted. Het formulier-ID wordt gebruikt zoals
 * het is verstuurd: een inzending hoort bij de taalversie waarop is ingezonden. Een formulier dat niet beschikbaar is,
 * geeft status 400.
 *
 * Spam (reCAPTCHA): opslaan met status spam en zonder bestanden als opslaan aan staat, geen mails en geen
 * ww_form_submitted, wel ww_form_spam; de limiet telt mee en de bezoeker krijgt het gewone succesantwoord.
 *
 * De uitkomst heeft naast de velden uit de brief ook values (de gecontroleerde invoer), voor het opnieuw tonen
 * zonder JavaScript, ook na een 429 of 500: de bezoeker moet het later kunnen proberen zonder alles opnieuw te typen.
 * labels is sleutel => label (platte tekst) voor elke fout van een veld; een fout van een sleutel
 * die geen veld is (uit het filter ww_form_validate), krijgt geen label en toont alleen de melding, net als zonder
 * JavaScript. reselect is true als er een bestand gekozen was en de inzending niet gelukt is: zonder JavaScript moet
 * de bezoeker het opnieuw kiezen.
 *
 * @param int                                       $form_id  Verstuurd formulier.
 * @param array<string,mixed>                       $post     De POST, na wp_unslash.
 * @param string                                    $page_url Pagina van de POST; de query-string gaat er voor opslaan en mails af.
 * @param array<string, list<array<string,mixed>>> $files    Uitvoer van _ww_form_files_input().
 * @return array{status: int, ok: bool, errors: array<string,string>, labels: array<string,string>, values: array<string,mixed>, message: string, type: string, url: string, reselect: bool}
 */
function _ww_form_process( int $form_id, array $post, string $page_url, array $files = array() ): array {
	_ww_form_recaptcha_result( '' );

	$config = null;
	if ( $form_id > 0 && WW_FORM_POST_TYPE === get_post_type( $form_id ) && 'publish' === get_post_status( $form_id ) ) {
		$config = _ww_form_config( $form_id );
	}
	if ( ! $config || ! $config['fields'] ) {
		return _ww_form_failure( 400, __( 'Dit formulier is niet beschikbaar.', 'webwerckt-base' ) );
	}

	if ( '' !== _ww_form_string( $post['ww_hp'] ?? '' ) ) {
		do_action( 'ww_form_spam', $form_id, 'honeypot' );
		return _ww_form_success( $form_id, $config, $page_url );
	}

	$chosen = _ww_form_files_chosen( $config, $files );

	if ( _ww_form_rate_limited() ) {
		$result             = _ww_form_failure( 429, __( 'Je hebt net al een paar keer iets verstuurd. Probeer het over een paar minuten opnieuw.', 'webwerckt-base' ) );
		$result['values']   = _ww_form_validate( $config, $post['ww_fields'] ?? array() )['values'];
		$result['reselect'] = $chosen;
		return $result;
	}

	$checked = _ww_form_validate( $config, $post['ww_fields'] ?? array() );
	$uploads = _ww_form_validate_files( $config, $files );
	$values  = $checked['values'];
	foreach ( $uploads['files'] as $key => $list ) {
		$values[ $key ] = array();
		foreach ( $list as $file ) {
			$values[ $key ][] = array(
				'name' => $file['name'],
				'size' => $file['size'],
				'mime' => $file['mime'],
			);
		}
	}
	// Fouten van velden en bestanden samen, in de volgorde van het formulier.
	$found = array();
	foreach ( $config['fields'] as $field ) {
		$message = $checked['errors'][ $field['key'] ] ?? $uploads['errors'][ $field['key'] ] ?? null;
		if ( null !== $message ) {
			$found[ $field['key'] ] = $message;
		}
	}
	$errors = array();
	foreach ( _ww_form_array( apply_filters( 'ww_form_validate', $found, $values, $form_id ) ) as $key => $message ) {
		$message = _ww_form_string( $message );
		if ( '' !== $message ) {
			$errors[ (string) $key ] = $message;
		}
	}

	if ( $errors ) {
		$labels = array();
		foreach ( $config['fields'] as $field ) {
			$labels[ $field['key'] ] = _ww_form_mail_plain( (string) $field['label'] );
		}
		$result             = _ww_form_failure( 422, __( 'Controleer de gemarkeerde velden.', 'webwerckt-base' ) );
		$result['errors']   = $errors;
		$result['values']   = $values;
		$result['reselect'] = $chosen;
		foreach ( array_keys( $errors ) as $key ) {
			if ( isset( $labels[ $key ] ) ) {
				$result['labels'][ $key ] = $labels[ $key ];
			}
		}
		return $result;
	}

	$token     = _ww_form_input_string( $post['ww_recaptcha'] ?? '' );
	$recaptcha = _ww_form_recaptcha_result( _ww_form_recaptcha_active( $config ) ? _ww_form_recaptcha_verify( (string) $token ) : 'off' );

	// De bestandsvelden gaan leeg de tabel in; de metadata komt pas na het verplaatsen.
	$has_files = _ww_form_has_file_field( $config );
	$empty     = $values;
	foreach ( array_keys( $uploads['files'] ) as $key ) {
		$empty[ $key ] = array();
	}
	$clean_url = esc_url_raw( (string) strtok( $page_url, '?' ) );
	$store     = ! empty( $config['storage']['store'] ) || $has_files;

	if ( 'spam' === $recaptcha ) {
		if ( $store && _ww_forms_ready() ) {
			_ww_form_entry_insert( $form_id, _ww_form_entry_fields( $config, $empty ), $clean_url, 'spam', 'spam' );
		}
		_ww_form_rate_hit();
		do_action( 'ww_form_spam', $form_id, 'recaptcha' );
		return _ww_form_success( $form_id, $config, $page_url );
	}

	// Zonder tabel kunnen de bestanden nergens bewaard worden.
	if ( $has_files && ! _ww_forms_ready() ) {
		error_log( sprintf( 'webwerckt-base: inzending van formulier %d met een bestandsveld niet opgeslagen: de tabel ontbreekt.', $form_id ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- bedoelde melding in het PHP-logboek.
		return _ww_form_send_failed( $values, $chosen );
	}

	$entry_id = 0;
	if ( $store ) {
		$fields   = _ww_form_entry_fields( $config, $empty );
		$entry_id = _ww_form_entry_insert( $form_id, $fields, $clean_url, 'new', $recaptcha );

		$to_store = array_filter( $uploads['files'] );
		if ( $has_files && ( 0 === $entry_id || ( $to_store && ! _ww_form_entry_store_files( $form_id, $entry_id, $config, $fields, $to_store, $values ) ) ) ) {
			error_log( sprintf( 'webwerckt-base: de bestanden van formulier %d konden niet worden bewaard; de inzending is niet opgeslagen.', $form_id ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- bedoelde melding in het PHP-logboek.
			return _ww_form_send_failed( $values, $chosen );
		}
	}

	$mails = _ww_form_send_mails( $form_id, $config, $values, $clean_url, $entry_id );
	if ( $entry_id > 0 ) {
		_ww_form_entry_set_mail_status( $entry_id, $mails );
	}

	if ( 0 === $entry_id && 'sent' !== $mails['notify'] ) {
		error_log( sprintf( 'webwerckt-base: inzending van formulier %d niet opgeslagen en de melding is niet verstuurd (%s).', $form_id, $mails['notify'] ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- bedoelde melding in het PHP-logboek.
		return _ww_form_send_failed( $values, $chosen );
	}

	_ww_form_rate_hit();
	do_action( 'ww_form_submitted', $entry_id, $values, $form_id );

	return _ww_form_success( $form_id, $config, $page_url );
}

/**
 * Zet de bestanden van een net opgeslagen inzending in de afgeschermde map en schrijft de metadata (value en display)
 * in de inzending. Lukt een stap niet, dan zijn de verplaatste bestanden en de inzending zelf weer weg.
 *
 * @param int                                                                                   $form_id  Formulier.
 * @param int                                                                                   $entry_id Net opgeslagen inzending.
 * @param array<string,mixed>                                                                   $config   Opgeschoonde configuratie.
 * @param array<string,array{label:string,type:string,value:mixed,display:string}>              $fields   Velden zoals ze zijn opgeslagen.
 * @param array<string,list<array{name:string,tmp:string,ext:string,mime:string,size:int}>> $files    Gecontroleerde bestanden.
 * @param array<string,mixed>                                                                   $values   Waarden; krijgt per bestandsveld de metadata.
 */
function _ww_form_entry_store_files( int $form_id, int $entry_id, array $config, array $fields, array $files, array &$values ): bool {
	$stored = _ww_form_store_files( $form_id, $entry_id, $files );
	if ( null !== $stored ) {
		foreach ( $config['fields'] as $field ) {
			if ( isset( $stored[ $field['key'] ] ) ) {
				$fields[ $field['key'] ]['value']   = $stored[ $field['key'] ];
				$fields[ $field['key'] ]['display'] = _ww_form_display_value( $field, $stored[ $field['key'] ] );
			}
		}
		if ( _ww_form_entry_update_fields( $entry_id, $fields ) ) {
			foreach ( $stored as $key => $list ) {
				$values[ $key ] = $list;
			}
			return true;
		}
		_ww_form_delete_dir( _ww_form_entry_dir( $form_id, $entry_id ) );
	}
	_ww_form_entries_delete( array( $entry_id ) );
	return false;
}

/**
 * Het JSON-antwoord voor form.js.
 *
 * @param array<string,mixed> $result Uitkomst van _ww_form_process().
 * @return array<string,mixed>
 */
function _ww_form_json( array $result ): array {
	if ( $result['ok'] ) {
		if ( 'redirect' === $result['type'] ) {
			return array(
				'ok'   => true,
				'type' => 'redirect',
				'url'  => $result['url'],
			);
		}
		return array(
			'ok'      => true,
			'type'    => 'message',
			'message' => $result['message'],
		);
	}
	if ( $result['errors'] ) {
		return array(
			'ok'      => false,
			'errors'  => $result['errors'],
			'labels'  => $result['labels'],
			'message' => $result['message'],
		);
	}
	return array(
		'ok'      => false,
		'message' => $result['message'],
	);
}

/**
 * Stuurt door met 303 en stopt: naar de eigen host met wp_safe_redirect, een after.url op een andere host met
 * wp_redirect.
 *
 * @param string $url Doel.
 */
function _ww_form_redirect( string $url ): never {
	$host = wp_parse_url( $url, PHP_URL_HOST );
	$home = wp_parse_url( home_url(), PHP_URL_HOST );
	if ( is_string( $host ) && '' !== $host && strtolower( $host ) !== strtolower( (string) $home ) ) {
		wp_redirect( $url, 303, 'webwerckt-base' ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- het doel is door de redacteur ingevoerd en mag een andere host zijn.
	} else {
		wp_safe_redirect( $url, 303, 'webwerckt-base' );
	}
	exit;
}

/**
 * De URL van deze aanvraag, met query-string: schema, host en poort van de site plus REQUEST_URI. Niet home_url(
 * REQUEST_URI ), want op een site in een submap staat de submap al in REQUEST_URI. Precies één / vooraan, zodat
 * //andere-host nooit een host wordt. Leeg of onbruikbaar: de homepage.
 */
function _ww_form_request_url(): string {
	$uri  = isset( $_SERVER['REQUEST_URI'] ) ? _ww_form_string( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- wordt hieronder met esc_url_raw een URL.
	$home = wp_parse_url( home_url() );
	$url  = '';
	if ( is_array( $home ) && isset( $home['scheme'], $home['host'] ) ) {
		$url = esc_url_raw( $home['scheme'] . '://' . $home['host'] . ( isset( $home['port'] ) ? ':' . $home['port'] : '' ) . '/' . ltrim( $uri, '/' ) );
	}
	return '' !== $url ? $url : home_url( '/' );
}

/**
 * Vangt de POST van een formulier op (template_redirect, prioriteit 0) en maakt een pagina met ?ww_form_sent
 * niet-cachebaar.
 *
 * Eerst een te grote POST (PHP heeft $_POST en $_FILES geleegd): status 413, met JSON of met de melding bij elk
 * formulier met een bestandsveld op de pagina. Verder alleen bij POST met een numerieke ww_form; anders gaat
 * WordPress gewoon verder. Met de header X-WW-Form: 1 komt er JSON, na succes zonder JavaScript een 303, en bij een
 * fout bouwt WordPress de pagina op met de foutentoestand.
 */
function _ww_form_handle_post(): void {
	$header = isset( $_SERVER['HTTP_X_WW_FORM'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_WW_FORM'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated -- isset hierboven.

	if ( _ww_form_post_too_large() ) {
		do_action( 'ww_cacheable', false, 'ww form' );
		nocache_headers();
		$message = _ww_form_post_too_large_message();
		error_log( sprintf( 'webwerckt-base: formulier-POST van %d bytes is groter dan post_max_size (%d bytes).', isset( $_SERVER['CONTENT_LENGTH'] ) ? (int) $_SERVER['CONTENT_LENGTH'] : 0, _ww_form_post_max_bytes() ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- bedoelde melding in het PHP-logboek.
		status_header( 413 );
		if ( '1' === $header ) {
			wp_send_json(
				array(
					'ok'      => false,
					'errors'  => new stdClass(),
					'message' => $message,
				),
				413
			);
		}
		_ww_form_posted(
			array(
				'form_id'   => 0,
				'too_large' => true,
				'values'    => array(),
				'errors'    => array(),
				'general'   => $message,
				'reselect'  => false,
			)
		);
		return;
	}

	// phpcs:disable WordPress.Security.NonceVerification -- Geen nonce bij een open formulier (beslissing 0032).
	$method  = isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated -- isset hierboven.
	$raw_id  = $_POST['ww_form'] ?? null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- alleen een reeks cijfers gaat verder.
	$is_form = 'POST' === strtoupper( $method ) && is_string( $raw_id ) && ctype_digit( $raw_id );

	if ( $is_form || isset( $_GET['ww_form_sent'] ) ) {
		do_action( 'ww_cacheable', false, 'ww form' );
	}
	if ( ! $is_form ) {
		return;
	}
	$form_id = (int) $raw_id;
	nocache_headers();

	$post  = _ww_form_array( wp_unslash( $_POST ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- _ww_form_validate() schoont elk veld op.
	$files = _ww_form_files_input( $_FILES['ww_files'] ?? null ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- _ww_form_validate_files() controleert elk bestand.
	// phpcs:enable WordPress.Security.NonceVerification

	$result = _ww_form_process( $form_id, $post, _ww_form_request_url(), $files );

	if ( '1' === $header ) {
		wp_send_json( _ww_form_json( $result ), $result['status'] );
	}

	if ( $result['ok'] ) {
		_ww_form_redirect( $result['url'] );
	}

	_ww_form_posted(
		array(
			'form_id'  => $form_id,
			'values'   => $result['values'],
			'errors'   => $result['errors'],
			'general'  => $result['errors'] ? '' : $result['message'],
			'reselect' => $result['reselect'],
		)
	);
}
add_action( 'template_redirect', '_ww_form_handle_post', 0 );
