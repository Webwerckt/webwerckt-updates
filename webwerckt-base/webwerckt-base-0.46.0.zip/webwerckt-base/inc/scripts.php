<?php
/**
 * Scripts uit de Site-instellingen (head_scripts en body_scripts), bijvoorbeeld van een tag manager: ongewijzigd in
 * de <head> en direct na <body>. Alleen de beheerder (manage_options) ziet en bewerkt de velden, ook al heeft een
 * Redacteur op een gewone site unfiltered_html (pods/settings.json, _ww_pods_lock_code_fields(), beslissing 0025).
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * De code uit een scriptveld, of '' als hij er niet hoort: in de admin en in Visueel bewerken, zodat een
 * tag manager de bewerker niet als bezoeker telt.
 *
 * @param string $field head_scripts of body_scripts.
 */
function _ww_setting_scripts( string $field ): string {
	if ( is_admin() || 0 !== _ww_editor_post_id() ) {
		return '';
	}
	return trim( _ww_setting_string( $field ) );
}

/**
 * Scripts in de <head>, vroeg, zoals een tag manager vraagt.
 */
function _ww_print_head_scripts(): void {
	$code = _ww_setting_scripts( 'head_scripts' );
	if ( '' !== $code ) {
		echo $code . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- code van een beheerder (manage_options), bewust ongewijzigd.
	}
}
add_action( 'wp_head', '_ww_print_head_scripts', 1 );

/**
 * Scripts direct na <body>. Het child-thema roept wp_body_open() aan in header.php.
 */
function _ww_print_body_scripts(): void {
	$code = _ww_setting_scripts( 'body_scripts' );
	if ( '' !== $code ) {
		echo $code . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- code van een beheerder (manage_options), bewust ongewijzigd.
	}
}
add_action( 'wp_body_open', '_ww_print_body_scripts', 1 );
