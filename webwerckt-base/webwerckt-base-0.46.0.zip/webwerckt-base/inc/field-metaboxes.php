<?php
/**
 * De velden op het bewerkscherm, zonder Pods: per post type met velden een vak per groep (de templategroepen alleen
 * bij het gekozen template), getekend door de tekenlaag van de Site-instellingen (inc/settings-fields-render.php) en
 * opgeslagen via de opslaglaag van het thema (_ww_fields_save()).
 *
 * - Opslaan alleen vanuit het formulier van het bewerkscherm: met de nonce ww_fields_{post_id}, het recht edit_post,
 *   niet bij autosave of een revisie. Snel bewerken, bulkbewerken, REST, wp_update_post(), dupliceren en terugzetten
 *   sturen die nonce niet mee en raken de velden dus niet.
 * - Alleen de velden die op het scherm stonden (ww_fields_shown[]), zoals Pods: wie het template wijzigt, slaat eerst
 *   op en vult daarna de nieuwe velden. Een afgeschermd veld of een soort zonder invoer staat er nooit bij.
 * - Een veld dat de gebruiker niet wijzigde, blijft ongemoeid: opslaan zonder wijziging laat de meta byte voor byte
 *   gelijk (ook _pods_-rijen, lege rijen en de volgorde van keuzes), ook waar een browser de waarde anders terugstuurt
 *   (regeleinden, &amp;, keuzes in de volgorde van de opties). Een veld zonder meta dat niemand aanraakte, krijgt dus
 *   geen lege rij; alleen bij de eerste opslag van een nieuw bericht gaat een getoonde default_value de database in.
 * - Een relatie met een bericht dat in de prullenbak ligt of weg is (of een term die weg is), verliest dat ID zonder
 *   fout (_ww_fields_drop_gone()).
 * - Een leeg verplicht veld: het bericht en de andere velden worden opgeslagen, dat veld niet, en de volgende keer
 *   staat er een melding.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * Welke vakken.
 */

/**
 * De groepen van dit bericht als vakken, in de volgorde van de bestanden: van de templategroepen alleen die van het
 * gekozen template, zonder velden die de gebruiker niet mag zien. Een groep zonder velden valt weg.
 *
 * @return array<int,array{name:string,label:string,fields:array<string,array<string,mixed>>}>
 */
function _ww_field_boxes( WP_Post $post ): array {
	$boxes = array();
	foreach ( _ww_pods_config() as $pod ) {
		if ( 'post_type' !== ( $pod['type'] ?? '' ) || $post->post_type !== ( $pod['name'] ?? '' ) || ! is_array( $pod['groups'] ?? null ) ) {
			continue;
		}
		foreach ( _ww_pods_template_groups( $pod['groups'], 'post_type', $post->post_type, $post->ID ) as $group ) {
			$fields = array();
			foreach ( (array) ( $group['fields'] ?? array() ) as $field ) {
				$name = _ww_data_to_string( $field['name'] ?? '' );
				if ( '' !== $name && ! _ww_field_restricted( $field ) ) {
					$fields[ $name ] = $field;
				}
			}
			if ( array() === $fields ) {
				continue;
			}
			$name    = _ww_data_to_string( $group['name'] ?? '' );
			$label   = _ww_data_to_string( $group['label'] ?? '' );
			$boxes[] = array(
				'name'   => $name,
				'label'  => '' !== $label ? $label : $name,
				'fields' => $fields,
			);
		}
	}
	return $boxes;
}

/**
 * De waarde van een veld zoals het scherm hem toont: de opgeslagen meta (bij meerdere waarden de lijst met rijen).
 * Zonder meta: bij een nieuw bericht (concept automatisch, Nieuwe pagina) of een nieuwe term default_value, bij een
 * bestaand bericht leeg, zodat wat de gebruiker intypt ook wordt opgeslagen. Een bewust leeg gelaten "" blijft leeg.
 *
 * @param int                 $object_id Bericht of term.
 * @param array<string,mixed> $field     Veld uit de configuratie.
 * @param bool                $new       Een nieuw bericht of een nieuwe term, nog niet opgeslagen.
 * @param string              $meta_type post (het bewerkscherm) of term (inc/field-terms.php).
 * @return mixed
 */
function _ww_field_box_value( int $object_id, array $field, bool $new = false, string $meta_type = 'post' ) {
	$name = _ww_data_to_string( $field['name'] ?? '' );
	if ( ! metadata_exists( $meta_type, $object_id, $name ) ) {
		return $new ? ( $field['default_value'] ?? null ) : null;
	}
	$rows = get_metadata( $meta_type, $object_id, $name, false );
	return _ww_fields_is_multi( $field ) ? $rows : ( $rows[0] ?? null );
}

/*
 * Tekenen.
 */

/**
 * Registreert een vak per groep (add_meta_boxes), met id ww-fields-{groep} en het label van de groep als titel.
 *
 * @param string $post_type Post type van het scherm.
 * @param mixed  $post      Het bericht (bij reacties een WP_Comment).
 */
function _ww_field_boxes_add( $post_type, $post = null ): void {
	if ( ! $post instanceof WP_Post ) {
		return;
	}
	foreach ( _ww_field_boxes( $post ) as $box ) {
		add_meta_box( 'ww-fields-' . $box['name'], $box['label'], '_ww_field_box_render', (string) $post_type, 'normal', 'default', array( 'box' => $box ) );
	}
}
add_action( 'add_meta_boxes', '_ww_field_boxes_add', 10, 2 );

/**
 * Tekent één vak: de nonce, een form-table met een rij per veld, en per veld met invoer een verborgen
 * ww_fields_shown[]. Een rij die de tekenlaag overslaat (een verouderd veld zonder waarde) of een soort zonder invoer
 * staat niet in ww_fields_shown en blijft bij opslaan ongemoeid.
 *
 * @param mixed $post     Het bericht.
 * @param mixed $meta_box Het vak van add_meta_box(), met args.box uit _ww_field_boxes().
 */
function _ww_field_box_render( $post, $meta_box ): void {
	$box = is_array( $meta_box ) && is_array( $meta_box['args']['box'] ?? null ) ? $meta_box['args']['box'] : array();
	if ( ! $post instanceof WP_Post || ! is_array( $box['fields'] ?? null ) ) {
		return;
	}

	// In elk vak dezelfde nonce, zonder id: een vak kan verborgen of verplaatst zijn, en ids moeten uniek blijven.
	$html  = '<input type="hidden" name="ww_fields_nonce" value="' . esc_attr( wp_create_nonce( 'ww_fields_' . $post->ID ) ) . '">';
	$rows  = '';
	$shown = '';
	foreach ( $box['fields'] as $name => $field ) {
		$name = (string) $name;
		$row  = _ww_settings_render_row( $field, _ww_field_box_value( $post->ID, $field, 'auto-draft' === $post->post_status ), array() );
		if ( '' === $row ) {
			continue;
		}
		$rows .= $row;
		if ( _ww_settings_field_supported( $field ) ) {
			$shown .= '<input type="hidden" name="ww_fields_shown[]" value="' . esc_attr( $name ) . '">';
		}
	}
	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- de tekenlaag escapet elke rij zelf.
	echo $html . '<table class="form-table" role="presentation"><tbody>' . $rows . '</tbody></table>' . $shown;
}

/**
 * Laadt het script en de stijl van de invoer op het bewerkscherm van een post type met velden, en start het script
 * op het formulier #post.
 *
 * @param string $hook Het scherm (post.php, post-new.php, ...).
 */
function _ww_field_boxes_assets( $hook ): void {
	if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
		return;
	}
	$post = get_post();
	if ( ! $post instanceof WP_Post ) {
		return;
	}
	$fields = array();
	foreach ( _ww_field_boxes( $post ) as $box ) {
		$fields += $box['fields'];
	}
	if ( array() === $fields ) {
		return;
	}
	_ww_field_inputs_enqueue( $fields );
	wp_add_inline_script( 'ww-field-inputs', "window.wwFieldInputs && document.getElementById( 'post' ) && window.wwFieldInputs.init( document.getElementById( 'post' ), { texts: window.wwFieldInputsTexts || {} } );" );
}
add_action( 'admin_enqueue_scripts', '_ww_field_boxes_assets' );

/*
 * Opslaan.
 */

/**
 * De sleutel van de melding na het opslaan, per bericht en gebruiker: ww_fields_{soort}_{post_id}_{user_id}.
 *
 * @param string $kind required (lege verplichte velden) of invalid (geweigerde waarden).
 */
function _ww_field_boxes_notice_key( string $kind, int $post_id ): string {
	return 'ww_fields_' . $kind . '_' . $post_id . '_' . get_current_user_id();
}

/**
 * De velden die bij opslaan mogen: de velden van het post type uit alle templates (het template kan in dezelfde
 * opslag zijn gewijzigd), zonder afgeschermde velden en soorten zonder invoer, en alleen de namen die op het scherm
 * stonden.
 *
 * @param string[] $shown Namen uit ww_fields_shown[].
 * @return array<string,array<string,mixed>>
 */
function _ww_field_boxes_allowed( string $post_type, array $shown ): array {
	$allowed = array();
	foreach ( _ww_pods_fields( $post_type ) as $field ) {
		$name = _ww_data_to_string( $field['name'] ?? '' );
		if ( in_array( $name, $shown, true ) && ! _ww_field_restricted( $field ) && _ww_settings_field_supported( $field ) ) {
			$allowed[ $name ] = $field;
		}
	}
	return $allowed;
}

/**
 * Wijzigde de gebruiker dit veld niet? Vergelijkt de ingezonden waarde met de waarde die het scherm tekende, zoals
 * een browser haar terugstuurt:
 *
 * - tekstvak, code en opgemaakte tekst: regeleinden als CRLF, en één regeleinde aan het begin weg;
 * - tekst, telefoon, e-mail en website: zonder regeleinden; e-mail en website ook zonder witruimte eromheen;
 * - een entiteit (&amp;, &eacute;) in een invoer komt terug als teken (esc_attr() escapet niet dubbel): beide tellen;
 * - getal, datum en tijd: een waarde die het invoerelement niet kent, komt leeg terug;
 * - ja/nee als aan of uit ("" is uit);
 * - meerkeuze met meerdere: dezelfde keuzes, in welke volgorde ook (de vinkjes staan in de volgorde van de opties);
 * - relatie (met berichten of termen) en foto's: dezelfde ID's in dezelfde volgorde (de ingezonden lijst al zonder
 *   verdwenen ID's).
 *
 * @param array<string,mixed> $field  Veld uit de configuratie.
 * @param mixed               $shown  Waarde op het scherm (_ww_field_box_value()).
 * @param mixed               $posted Ingezonden waarde, zonder slashes (_ww_settings_post_values()).
 */
function _ww_field_box_unchanged( array $field, $shown, $posted ): bool {
	$type = _ww_data_to_string( $field['type'] ?? '' );

	if ( _ww_field_is_choice( $field ) && _ww_fields_is_multi( $field ) ) {
		$options = array_map( 'strval', array_keys( _ww_field_choices( $field ) ) );
		$before  = array_values( array_intersect( _ww_settings_value_choices( $shown ), $options ) );
		$after   = _ww_settings_value_choices( $posted );
		sort( $before );
		sort( $after );
		return $before === $after;
	}
	if ( _ww_field_is_relation( $field ) || 'file' === $type ) {
		return _ww_settings_value_ids( $shown ) === _ww_settings_value_ids( $posted );
	}
	if ( 'boolean' === $type ) {
		return ! empty( $shown ) === _ww_data_to_bool( $posted );
	}
	if ( is_array( $posted ) || is_array( $shown ) ) {
		return false;
	}

	$before = _ww_data_to_string( $shown );
	$after  = _ww_data_to_string( $posted );
	if ( in_array( $type, array( 'paragraph', 'code', 'wysiwyg' ), true ) ) {
		$lines = static fn( string $text ): string => (string) preg_replace( '/^\n/', '', str_replace( array( "\r\n", "\r" ), "\n", $text ) );
		return $lines( $before ) === $lines( $after );
	}

	$patterns = array(
		'number'   => '/^-?(\d+|\d*\.\d+)([eE][-+]?\d+)?$/',
		'date'     => '/^\d{4}-\d{2}-\d{2}$/',
		'time'     => '/^\d{2}:\d{2}(:\d{2})?$/',
		'datetime' => '/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2})?$/',
	);
	if ( isset( $patterns[ $type ] ) ) {
		$before = 'number' === $type ? $before : _ww_settings_date_value( $type, $before );
		return $before === $after || ( '' === $after && 1 !== preg_match( $patterns[ $type ], $before ) );
	}

	$before = str_replace( array( "\r", "\n" ), '', $before );
	if ( in_array( $type, array( 'email', 'website' ), true ) ) {
		$before = trim( $before, " \t\n\f\r" );
	}
	return $before === $after || html_entity_decode( $before, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) === $after;
}

/**
 * Slaat de velden van het bewerkscherm op (save_post, prioriteit 9: vóór de kopie naar post_content, de taal-metabox
 * en de cache). Alleen met de nonce ww_fields_{post_id} van dit bericht uit het formulier, het recht edit_post, en
 * niet bij autosave of een revisie.
 *
 * Per veld dat op het scherm stond, in deze volgorde: ongewijzigd blijft ongemoeid; leeg en verplicht wordt overgeslagen en gemeld;
 * een waarde die de controle weigert ook (de browser houdt die meestal al tegen); de rest gaat in één keer naar
 * _ww_fields_save().
 *
 * @param int|string $post_id Bericht.
 * @param mixed      $post    Het bericht.
 */
function _ww_field_boxes_save( $post_id, $post = null ): void {
	static $saving = array();

	$post_id = (int) $post_id;
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) || isset( $saving[ $post_id ] ) ) {
		return;
	}
	// phpcs:disable WordPress.Security.NonceVerification.Missing -- de nonce wordt hier gecontroleerd.
	$nonce   = isset( $_POST['ww_fields_nonce'] ) && is_string( $_POST['ww_fields_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['ww_fields_nonce'] ) ) : '';
	$form_id = isset( $_POST['post_ID'] ) ? absint( _ww_data_to_string( wp_unslash( $_POST['post_ID'] ) ) ) : 0;
	if ( '' === $nonce || $form_id !== $post_id || ! wp_verify_nonce( $nonce, 'ww_fields_' . $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$post = get_post( $post_id );
	if ( ! $post instanceof WP_Post ) {
		return;
	}

	$shown   = isset( $_POST['ww_fields_shown'] ) && is_array( $_POST['ww_fields_shown'] ) ? array_map( 'sanitize_text_field', array_map( '_ww_data_to_string', wp_unslash( $_POST['ww_fields_shown'] ) ) ) : array();
	$allowed = _ww_field_boxes_allowed( $post->post_type, $shown );
	// Elke waarde gaat hieronder door _ww_settings_post_values() (wp_unslash) en _ww_fields_input_value() (controle).
	$posted = isset( $_POST['ww_fields'] ) && is_array( $_POST['ww_fields'] ) ? $_POST['ww_fields'] : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
	// De eerste opslag vanaf Nieuwe pagina: post.php stuurt dan original_post_status auto-draft mee.
	$first = isset( $_POST['original_post_status'] ) && 'auto-draft' === $_POST['original_post_status'];
	// phpcs:enable WordPress.Security.NonceVerification.Missing
	$values = _ww_settings_post_values( $allowed, array_intersect_key( $posted, $allowed ) );

	$data     = array();
	$required = array();
	$invalid  = array();
	foreach ( $allowed as $name => $field ) {
		if ( ! array_key_exists( $name, $values ) ) {
			continue;
		}
		$label = _ww_data_to_string( $field['label'] ?? $name );
		$value = _ww_fields_drop_gone( $field, $values[ $name ] );
		// Eerst: ongewijzigd blijft ongemoeid, ook een veld zonder meta (dan komt er geen lege rij bij) en een verplicht
		// veld dat al leeg was (geen melding bij elke opslag). Alleen bij de eerste opslag van een nieuw bericht gaat een
		// getoonde default_value wel de database in, zoals bij Pods. Een relatie waarvan ID's wegvielen, is gewijzigd.
		$stored = metadata_exists( 'post', $post_id, $name );
		if ( ( $stored || ! $first || ! isset( $field['default_value'] ) ) && _ww_field_box_unchanged( $field, _ww_field_box_value( $post_id, $field, $first ), $value ) ) {
			continue;
		}
		// Daarna: leeg en verplicht wordt niet opgeslagen maar gemeld.
		$clean = _ww_fields_input_value( $field, $value );
		if ( ! is_wp_error( $clean ) && _ww_field_is_required( $field ) && in_array( $clean, array( '', null, array() ), true ) ) {
			$required[] = $label;
			continue;
		}
		if ( is_wp_error( $clean ) ) {
			$invalid[] = $label . ': ' . $clean->get_error_message();
			continue;
		}
		$data[ $name ] = $clean;
	}

	if ( array() !== $data ) {
		$saving[ $post_id ] = true;
		$error              = _ww_fields_save( $post->post_type, $post_id, $data );
		unset( $saving[ $post_id ] );
		if ( $error instanceof WP_Error ) {
			$invalid[] = $error->get_error_message();
		}
	}

	foreach ( array(
		'required' => $required,
		'invalid'  => $invalid,
	) as $kind => $list ) {
		$key = _ww_field_boxes_notice_key( $kind, $post_id );
		if ( array() !== $list ) {
			set_transient( $key, $list, 10 * MINUTE_IN_SECONDS );
		} else {
			delete_transient( $key );
		}
	}
}
add_action( 'save_post', '_ww_field_boxes_save', 9, 2 );

/**
 * Toont na het opslaan (na de doorverwijzing) één keer de lege verplichte velden en de geweigerde waarden, op het
 * bewerkscherm van dat bericht.
 */
function _ww_field_boxes_notice(): void {
	$screen = get_current_screen();
	$post   = get_post();
	if ( ! $screen instanceof WP_Screen || 'post' !== $screen->base || ! $post instanceof WP_Post ) {
		return;
	}
	$messages = array(
		/* translators: %s: labels van de lege verplichte velden, gescheiden door komma's. */
		'required' => __( 'Deze verplichte velden zijn leeg en niet opgeslagen: %s. De rest is opgeslagen.', 'webwerckt-base' ),
		/* translators: %s: de velden met hun foutmelding. */
		'invalid'  => __( 'Deze velden zijn niet opgeslagen: %s', 'webwerckt-base' ),
	);
	foreach ( $messages as $kind => $message ) {
		$key  = _ww_field_boxes_notice_key( $kind, $post->ID );
		$list = get_transient( $key );
		if ( ! is_array( $list ) ) {
			continue;
		}
		delete_transient( $key );
		$list = array_filter( array_map( '_ww_data_to_string', $list ) );
		if ( array() !== $list ) {
			echo '<div class="notice notice-warning is-dismissible"><p>' . esc_html( sprintf( $message, implode( 'required' === $kind ? ', ' : ' ', $list ) ) ) . '</p></div>';
		}
	}
}
add_action( 'admin_notices', '_ww_field_boxes_notice' );
