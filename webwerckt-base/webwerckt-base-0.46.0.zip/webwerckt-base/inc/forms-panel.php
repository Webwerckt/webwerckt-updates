<?php
/**
 * Het zijpaneel van Formulieren: naast het WordPress-menu op de lijst, Inzendingen, Instellingen en het bewerkscherm.
 *
 * Die schermen zijn core-schermen (edit.php, post.php) of submenupagina's onder Formulieren; het thema bepaalt hun
 * opbouw niet. Daarom komt het paneel via in_admin_header in #wpcontent, vóór #wpbody, en maakt de bodyklasse
 * ww-forms-has-panel van #wpcontent een flexrij. Op mobiel (≤ 782 px) verdwijnt het paneel en staat er een kiezer
 * bovenaan de inhoud. De submenu's Nieuw formulier, Inzendingen en Instellingen gaan uit het menu; hun pagina's
 * blijven geregistreerd en bereikbaar, en het bolletje met nieuwe inzendingen staat achter Formulieren.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Welk formulierenscherm open is: list, entries, settings, edit, of leeg op een ander scherm.
 */
function _ww_forms_panel_screen(): string {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen instanceof WP_Screen ) {
		return '';
	}
	if ( str_ends_with( $screen->id, WW_FORM_ENTRIES_SCREEN ) ) {
		return 'entries';
	}
	if ( str_ends_with( $screen->id, WW_FORMS_SETTINGS_SCREEN ) ) {
		return 'settings';
	}
	if ( WW_FORM_POST_TYPE !== $screen->post_type ) {
		return '';
	}
	if ( 'edit' === $screen->base ) {
		return 'list';
	}
	return 'post' === $screen->base ? 'edit' : '';
}

/**
 * De onderdelen van de overzichtsschermen die de gebruiker mag openen.
 *
 * @return array<string,array{label:string,icon:string,url:string}>
 */
function _ww_forms_panel_sections(): array {
	$sections = array(
		'list' => array(
			'label' => __( 'Formulieren', 'webwerckt-base' ),
			'icon'  => 'dashicons-list-view',
			'url'   => admin_url( 'edit.php?post_type=' . WW_FORM_POST_TYPE ),
		),
	);
	if ( current_user_can( 'edit_others_pages' ) ) {
		$sections['entries'] = array(
			'label' => __( 'Inzendingen', 'webwerckt-base' ),
			'icon'  => 'dashicons-email-alt',
			'url'   => _ww_forms_entries_url(),
		);
	}
	if ( current_user_can( 'manage_options' ) ) {
		$sections['settings'] = array(
			'label' => __( 'Instellingen', 'webwerckt-base' ),
			'icon'  => 'dashicons-admin-generic',
			'url'   => _ww_forms_settings_url(),
		);
	}
	return $sections;
}

/**
 * Het aantal gepubliceerde formulieren.
 */
function _ww_forms_panel_published(): int {
	$counts = wp_count_posts( WW_FORM_POST_TYPE );
	return (int) ( $counts->publish ?? 0 );
}

/**
 * Wat achter een onderdeel staat: het aantal formulieren in grijs, of het bolletje met nieuwe inzendingen.
 *
 * @param string $slug Onderdeel.
 * @return string Geëscapete HTML.
 */
function _ww_forms_panel_count( string $slug ): string {
	if ( 'list' === $slug ) {
		return '<span class="ww-forms-count">' . esc_html( number_format_i18n( _ww_forms_panel_published() ) ) . '</span>';
	}
	if ( 'entries' === $slug ) {
		$new = _ww_form_entries_count_new();
		return $new > 0 ? '<span class="awaiting-mod">' . esc_html( number_format_i18n( $new ) ) . '</span>' : '';
	}
	return '';
}

/**
 * De onderdelen als lijstitems; het actieve krijgt aria-current.
 *
 * @param string $active Actief onderdeel.
 * @param bool   $icons  Met Dashicon (in het paneel) of zonder (in de kiezer).
 * @return string Geëscapete HTML.
 */
function _ww_forms_panel_items( string $active, bool $icons ): string {
	$items = '';
	foreach ( _ww_forms_panel_sections() as $slug => $section ) {
		$icon   = $icons ? '<span class="dashicons ' . esc_attr( $section['icon'] ) . '" aria-hidden="true"></span>' : '';
		$items .= '<li><a href="' . esc_url( $section['url'] ) . '"' . ( $slug === $active ? ' aria-current="page"' : '' ) . '>' . $icon
			. '<span class="ww-forms-nav__label">' . esc_html( $section['label'] ) . '</span>' . _ww_forms_panel_count( $slug ) . '</a></li>';
	}
	return $items;
}

/**
 * Het paneel op de lijst, Inzendingen en Instellingen.
 *
 * @param string $active Actief onderdeel (list, entries of settings).
 * @return string Geëscapete HTML.
 */
function _ww_forms_render_overview_panel( string $active ): string {
	$published = _ww_forms_panel_published();
	/* translators: %s: aantal gepubliceerde formulieren. */
	$forms     = sprintf( _n( '%s formulier', '%s formulieren', $published, 'webwerckt-base' ), number_format_i18n( $published ) );
	$recaptcha = _ww_form_recaptcha_configured() ? __( 'reCAPTCHA aan', 'webwerckt-base' ) : __( 'reCAPTCHA uit', 'webwerckt-base' );

	return '<nav class="ww-forms-panel" aria-label="' . esc_attr__( 'Formulieren', 'webwerckt-base' ) . '">'
		. '<p class="ww-forms-panel__title">' . esc_html__( 'Formulieren', 'webwerckt-base' ) . '</p>'
		. '<p class="ww-forms-panel__sub">' . esc_html( $forms . ' · ' . $recaptcha ) . '</p>'
		. '<ul class="ww-forms-panel__nav">' . _ww_forms_panel_items( $active, true ) . '</ul>'
		. '<p class="ww-forms-panel__foot"><span class="dashicons dashicons-info-outline" aria-hidden="true"></span><span>'
		. esc_html__( 'Zet een formulier op een pagina met de code bij Plaatsen. Inzendingen worden bewaard zolang de bewaartermijn van het formulier zegt.', 'webwerckt-base' )
		. '</span></p></nav>';
}

/**
 * De kiezer voor mobiel op de lijst, Inzendingen en Instellingen.
 *
 * @param string $active Actief onderdeel (list, entries of settings).
 * @return string Geëscapete HTML.
 */
function _ww_forms_render_picker( string $active ): string {
	$sections = _ww_forms_panel_sections();
	return '<div class="ww-forms-mobile"><details class="ww-forms-picker"><summary><span>' . esc_html__( 'Formulieren', 'webwerckt-base' ) . '</span> <b>'
		. esc_html( $sections[ $active ]['label'] ?? '' ) . '</b></summary><ul>' . _ww_forms_panel_items( $active, false ) . '</ul></details></div>';
}

/**
 * Of een formulier als gepubliceerd geldt voor de knoppen: dezelfde keuze als het vak Publiceren van WordPress.
 *
 * @param WP_Post $post Het formulier.
 */
function _ww_forms_edit_is_published( WP_Post $post ): bool {
	return in_array( $post->post_status, array( 'publish', 'future', 'private' ), true );
}

/**
 * De titel van het formulier, of "(zonder titel)". Op post.php staat $post in de context edit en is de titel al
 * ge-escapet; esc_html() escapet niet dubbel. Op post-new.php is de titel van de auto-draft leeg.
 *
 * @param WP_Post $post Het formulier.
 */
function _ww_forms_edit_title( WP_Post $post ): string {
	return '' !== $post->post_title ? $post->post_title : __( '(zonder titel)', 'webwerckt-base' );
}

/**
 * De status onder de titel: Gepubliceerd (met de datum van de laatste wijziging), Concept, of het label van WordPress.
 *
 * @param WP_Post $post Het formulier.
 * @return string Geëscapete HTML.
 */
function _ww_forms_edit_status( WP_Post $post ): string {
	if ( 'publish' === $post->post_status ) {
		$date = date_i18n( 'j M', (int) get_post_modified_time( 'U', false, $post ) );
		/* translators: %s: datum van de laatste wijziging, bijvoorbeeld 14 nov. */
		$updated = sprintf( __( 'bijgewerkt %s', 'webwerckt-base' ), $date );
		return '<span class="ww-forms-panel__status is-published">' . esc_html__( 'Gepubliceerd', 'webwerckt-base' ) . '</span> · ' . esc_html( $updated );
	}
	if ( in_array( $post->post_status, array( 'draft', 'auto-draft' ), true ) ) {
		return '<span class="ww-forms-panel__status">' . esc_html__( 'Concept', 'webwerckt-base' ) . '</span>';
	}
	$object = get_post_status_object( $post->post_status );
	$label  = $object instanceof stdClass && is_string( $object->label ) ? $object->label : $post->post_status;
	return '<span class="ww-forms-panel__status">' . esc_html( $label ) . '</span>';
}

/**
 * De knoppen om op te slaan, buiten het formulier #post en er via form="post" bij. name en value zijn die van de knop
 * van WordPress, zodat post.php hetzelfde doet; de velden van het verborgen vak Publiceren gaan gewoon mee.
 *
 * data-ww-submit noemt de verborgen knop van WordPress waar assets/js/forms-panel.js de klik naartoe stuurt, zodat de
 * afhandeling van post.js meedoet (geen "pagina verlaten?", geen vrijgeven van de bewerkingsvergrendeling, autosave
 * gepauzeerd, niet twee keer versturen). Gepubliceerd: Bijwerken naar #publish (name="save"). Concept of nieuw:
 * opslaan naar #save-post, Publiceren naar #publish. Zonder script versturen de knoppen #post zelf.
 *
 * @param WP_Post $post    Het formulier.
 * @param string  $context panel (het zijpaneel) of bar (de balk op mobiel); bepaalt de id's.
 * @return string Geëscapete HTML.
 */
function _ww_forms_render_save_buttons( WP_Post $post, string $context = 'panel' ): string {
	$context = 'bar' === $context ? 'bar' : 'panel';
	// De value is bewust de core-tekst zonder tekstdomein: post.php krijgt dezelfde waarde als van de knop van WordPress.
	if ( _ww_forms_edit_is_published( $post ) ) {
		return '<button type="submit" form="post" class="button button-primary" id="ww-forms-update-' . $context . '" name="save" value="' . esc_attr( __( 'Update' ) ) . '" data-ww-submit="#publish">' // phpcs:ignore WordPress.WP.I18n.MissingArgDomain -- zie hierboven.
			. esc_html__( 'Bijwerken', 'webwerckt-base' ) . '</button>';
	}
	$pending = 'pending' === $post->post_status;
	return '<button type="submit" form="post" class="button" id="ww-forms-draft-' . $context . '" name="save" value="' . esc_attr( $pending ? __( 'Save as Pending' ) : __( 'Save Draft' ) ) . '" data-ww-submit="#save-post">' // phpcs:ignore WordPress.WP.I18n.MissingArgDomain -- zie hierboven.
		. ( $pending ? esc_html__( 'Opslaan', 'webwerckt-base' ) : esc_html__( 'Concept opslaan', 'webwerckt-base' ) ) . '</button>'
		. '<button type="submit" form="post" class="button button-primary" id="ww-forms-publish-' . $context . '" name="publish" value="' . esc_attr( __( 'Publish' ) ) . '" data-ww-submit="#publish">' // phpcs:ignore WordPress.WP.I18n.MissingArgDomain -- zie hierboven.
		. esc_html__( 'Publiceren', 'webwerckt-base' ) . '</button>';
}

/**
 * De kaart Plaatsen: de shortcode met een kopieerknop, de slug voor ww_form() in een template en de pagina's waar het
 * formulier op staat. Een nieuw formulier heeft nog geen ID om te tonen.
 *
 * @param WP_Post $post Het formulier.
 * @return string Geëscapete HTML.
 */
function _ww_forms_render_place_card( WP_Post $post ): string {
	$html = '<div class="ww-forms-panel__card"><p class="ww-forms-panel__card-title">' . esc_html__( 'Plaatsen', 'webwerckt-base' ) . '</p>';
	if ( 'auto-draft' === $post->post_status ) {
		return $html . '<p>' . esc_html__( 'De code om dit formulier op een pagina te zetten verschijnt hier na het opslaan.', 'webwerckt-base' ) . '</p></div>';
	}
	$html .= '<p><label for="ww-form-shortcode">' . esc_html__( 'Zet deze code op een pagina, bijvoorbeeld in een tekstveld:', 'webwerckt-base' ) . '</label></p>'
		. '<p class="ww-fb-place"><input type="text" id="ww-form-shortcode" class="code" value="' . esc_attr( sprintf( '[ww_form id="%d"]', $post->ID ) ) . '" readonly>'
		. '<button type="button" class="button button-small" data-ww-copy="#ww-form-shortcode">' . esc_html__( 'Kopiëren', 'webwerckt-base' ) . '</button></p>';
	if ( '' !== $post->post_name ) {
		$html .= '<p class="description">' . esc_html__( 'In een template:', 'webwerckt-base' ) . ' <code>' . esc_html( sprintf( "ww_form( '%s' );", $post->post_name ) ) . '</code></p>';
	} else {
		$html .= '<p class="description">' . esc_html__( 'De slug voor een template verschijnt na het publiceren.', 'webwerckt-base' ) . '</p>';
	}
	$links = _ww_forms_placement_links( $post->ID );
	$html .= '' !== $links
		? '<p class="ww-forms-panel__placed">' . esc_html__( 'Staat op:', 'webwerckt-base' ) . ' ' . $links . '</p>'
		: '<p class="ww-forms-panel__placed description">' . esc_html__( 'Nog nergens geplaatst', 'webwerckt-base' ) . '</p>';
	return $html . '</div>';
}

/**
 * De link naar de inzendingen van dit formulier, met het bolletje voor nieuwe (over de vertaalgroep, net als de lijst
 * die de link toont). Niet bij een nieuw formulier of zonder het recht om Inzendingen te openen.
 *
 * @param WP_Post $post Het formulier.
 * @param bool    $icon Met Dashicon en bolletje (paneel) of alleen de tekst (kiezer).
 * @return string Geëscapete HTML, of leeg.
 */
function _ww_forms_edit_entries_link( WP_Post $post, bool $icon ): string {
	if ( 'auto-draft' === $post->post_status || ! current_user_can( 'edit_others_pages' ) ) {
		return '';
	}
	$new    = _ww_forms_group_entry_counts( (int) $post->ID )['new'];
	$bubble = $new > 0 ? '<span class="awaiting-mod">' . esc_html( number_format_i18n( $new ) ) . '</span>' : '';
	return '<a href="' . esc_url( _ww_forms_entries_url( array( 'form_id' => (string) $post->ID ) ) ) . '">'
		. ( $icon ? '<span class="dashicons dashicons-email-alt" aria-hidden="true"></span>' : '' )
		. '<span class="ww-forms-nav__label">' . esc_html__( 'Inzendingen', 'webwerckt-base' ) . '</span>' . $bubble . '</a>';
}

/**
 * De link onder de knoppen: Naar prullenbak, of zonder prullenbak (EMPTY_TRASH_DAYS 0, _ww_forms_trash_is_permanent())
 * Definitief verwijderen met een vraag, want dan gaan ook de inzendingen en hun bestanden weg. De vraag noemt het
 * aantal inzendingen, net als de rij-actie in de lijst (_ww_forms_delete_entries_message()). Niet bij een nieuw
 * formulier.
 *
 * @param WP_Post $post Het formulier.
 * @return string Geëscapete HTML, of leeg.
 */
function _ww_forms_render_trash_link( WP_Post $post ): string {
	if ( 'auto-draft' === $post->post_status ) {
		return '';
	}
	$permanent = _ww_forms_trash_is_permanent();
	$url       = get_delete_post_link( $post, '', $permanent );
	if ( ! $url ) {
		return '';
	}
	if ( ! $permanent ) {
		return '<a class="ww-forms-panel__trash" href="' . esc_url( $url ) . '">' . esc_html_x( 'Naar prullenbak', 'actie: formulier naar de prullenbak', 'webwerckt-base' ) . '</a>';
	}
	$message = _ww_forms_delete_entries_message( $post->ID );
	$message = '' !== $message ? $message : __( 'Dit formulier definitief verwijderen? Dit kan niet ongedaan worden.', 'webwerckt-base' );
	return '<a class="ww-forms-panel__trash" href="' . esc_url( $url ) . '"' . _ww_forms_confirm_attr( $message ) . '>' . esc_html__( 'Definitief verwijderen', 'webwerckt-base' ) . '</a>';
}

/**
 * Het paneel op het bewerkscherm (variant A): terug naar de lijst, titel en status, opslaan, de onderdelen die de
 * builder vult, de inzendingen en de kaart Plaatsen.
 *
 * @param WP_Post $post Het formulier (ook een auto-draft op post-new.php).
 * @return string Geëscapete HTML.
 */
function _ww_forms_render_edit_panel( WP_Post $post ): string {
	$title   = _ww_forms_edit_title( $post );
	$entries = _ww_forms_edit_entries_link( $post, true );

	return '<nav class="ww-forms-panel ww-forms-panel--edit" aria-label="' . esc_attr( $title ) . '">'
		. '<a class="ww-forms-panel__back" href="' . esc_url( admin_url( 'edit.php?post_type=' . WW_FORM_POST_TYPE ) ) . '">'
		. '<span class="dashicons dashicons-arrow-left-alt2" aria-hidden="true"></span>' . esc_html__( 'Alle formulieren', 'webwerckt-base' ) . '</a>'
		. '<p class="ww-forms-panel__title">' . esc_html( $title ) . '</p>'
		. '<p class="ww-forms-panel__sub">' . _ww_forms_edit_status( $post ) . '</p>'
		. '<div class="ww-forms-panel__save"><p class="ww-forms-panel__dirty" aria-live="polite"></p>'
		. '<div class="ww-forms-panel__buttons">' . _ww_forms_render_save_buttons( $post, 'panel' ) . '</div>'
		. _ww_forms_render_trash_link( $post )
		. '</div>'
		. '<p class="ww-forms-panel__label">' . esc_html__( 'Onderdelen', 'webwerckt-base' ) . '</p>'
		. '<ul id="ww-forms-panel-tabs" class="ww-forms-panel__nav ww-forms-panel__tabs"></ul>'
		. ( '' !== $entries ? '<ul class="ww-forms-panel__nav ww-forms-panel__entries"><li>' . $entries . '</li></ul>' : '' )
		. _ww_forms_render_place_card( $post )
		. '<p class="ww-forms-panel__foot"><span class="dashicons dashicons-info-outline" aria-hidden="true"></span><span>'
		. esc_html__( 'Wijzigingen gelden pas na Bijwerken.', 'webwerckt-base' ) . '</span></p></nav>';
}

/**
 * Bovenaan het formulier #post, alleen zichtbaar op mobiel: de link terug naar de lijst en de kiezer voor de
 * onderdelen. De builder vult ul#ww-forms-picker-tabs; Inzendingen en Code kopiëren staan eronder. Dit staat binnen
 * #post, dus elke knop heeft type="button".
 */
function _ww_forms_mobile_edit_output(): void {
	$post = get_post();
	if ( 'edit' !== _ww_forms_panel_screen() || ! $post instanceof WP_Post ) {
		return;
	}
	$extra   = '';
	$entries = _ww_forms_edit_entries_link( $post, false );
	if ( '' !== $entries ) {
		$extra .= '<li>' . $entries . '</li>';
	}
	if ( 'auto-draft' !== $post->post_status ) {
		$extra .= '<li><button type="button" class="ww-forms-picker__copy" data-ww-copy-text="' . esc_attr( sprintf( '[ww_form id="%d"]', $post->ID ) ) . '">'
			. esc_html__( 'Code kopiëren', 'webwerckt-base' ) . '</button></li>';
	}
	echo '<div class="ww-forms-mobile ww-forms-mobile--edit">' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- alles hieronder is geëscapet.
		. '<a class="ww-forms-mobile__back" href="' . esc_url( admin_url( 'edit.php?post_type=' . WW_FORM_POST_TYPE ) ) . '">'
		. '<span class="dashicons dashicons-arrow-left-alt2" aria-hidden="true"></span>' . esc_html__( 'Formulieren', 'webwerckt-base' ) . '</a>'
		. '<details class="ww-forms-picker" id="ww-forms-picker-edit"><summary><span>' . esc_html__( 'Onderdeel', 'webwerckt-base' ) . '</span> <b></b></summary>'
		. '<div class="ww-forms-picker__menu"><ul id="ww-forms-picker-tabs"></ul>'
		. ( '' !== $extra ? '<ul class="ww-forms-picker__extra">' . $extra . '</ul>' : '' )
		. '</div></details></div>';
}
add_action( 'edit_form_top', '_ww_forms_mobile_edit_output' );

/**
 * De balk onderaan het bewerkscherm op mobiel: de statusregel en dezelfde knoppen als in het paneel.
 */
function _ww_forms_mobile_bar_output(): void {
	$post = get_post();
	if ( 'edit' !== _ww_forms_panel_screen() || ! $post instanceof WP_Post ) {
		return;
	}
	echo '<div class="ww-forms-mobilebar"><p class="ww-forms-panel__dirty" aria-live="polite"></p>' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_forms_render_save_buttons() escapet.
		. '<div class="ww-forms-mobilebar__buttons">' . _ww_forms_render_save_buttons( $post, 'bar' ) . '</div></div>';
}
add_action( 'admin_footer', '_ww_forms_mobile_bar_output' );

/**
 * Het paneel neemt de zijkolom over en die is verborgen; vakken die daar zouden staan (Taal, Laatste activiteit, die
 * van plug-ins) komen onder de builder, in normal met prioriteit low. Alleen Publiceren (submitdiv) blijft in de
 * verborgen zijkolom, want de velden ervan gaan mee met form="post". Draait laat, na add_meta_boxes.
 */
function _ww_forms_move_side_boxes(): void {
	global $wp_meta_boxes;
	$side = $wp_meta_boxes[ WW_FORM_POST_TYPE ]['side'] ?? null;
	if ( ! is_array( $side ) ) {
		return;
	}
	foreach ( $side as $priority => $boxes ) {
		foreach ( (array) $boxes as $id => $box ) {
			if ( 'submitdiv' === $id ) {
				continue;
			}
			$wp_meta_boxes[ WW_FORM_POST_TYPE ]['normal']['low'][ $id ] = $box; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- de vakken van WordPress zelf.
			unset( $wp_meta_boxes[ WW_FORM_POST_TYPE ]['side'][ $priority ][ $id ] );
		}
	}
}
add_action( 'add_meta_boxes_' . WW_FORM_POST_TYPE, '_ww_forms_move_side_boxes', PHP_INT_MAX );

/**
 * Een opgeslagen volgorde van de vakken (slepen) zet een vak terug in de kolom waar het stond. Haal alles behalve
 * submitdiv uit side en zet het achter normal, anders verdwijnt het in de verborgen zijkolom.
 *
 * @param mixed $order Opgeslagen volgorde per kolom, met komma's gescheiden ID's.
 * @return mixed
 */
function _ww_forms_box_order( $order ) {
	if ( ! is_array( $order ) || ! isset( $order['side'] ) || ! is_string( $order['side'] ) ) {
		return $order;
	}
	$side  = array_filter( explode( ',', $order['side'] ) );
	$moved = array_values( array_diff( $side, array( 'submitdiv' ) ) );
	if ( array() === $moved ) {
		return $order;
	}
	$normal          = array_filter( explode( ',', is_string( $order['normal'] ?? null ) ? $order['normal'] : '' ) );
	$order['side']   = in_array( 'submitdiv', $side, true ) ? 'submitdiv' : '';
	$order['normal'] = implode( ',', array_merge( $normal, array_diff( $moved, $normal ) ) );
	return $order;
}
add_filter( 'get_user_option_meta-box-order_' . WW_FORM_POST_TYPE, '_ww_forms_box_order' );

/**
 * Print het paneel van het open scherm, vóór #wpbody. Het bewerkscherm krijgt het paneel van dat formulier.
 */
function _ww_forms_panel_output(): void {
	$screen = _ww_forms_panel_screen();
	if ( '' === $screen ) {
		return;
	}
	if ( 'edit' === $screen ) {
		$post = get_post();
		if ( $post instanceof WP_Post ) {
			echo _ww_forms_render_edit_panel( $post ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_forms_render_edit_panel() escapet.
		}
		return;
	}
	echo _ww_forms_render_overview_panel( $screen ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_forms_render_overview_panel() escapet.
}
add_action( 'in_admin_header', '_ww_forms_panel_output' );

/**
 * De kiezer bovenaan de lijst Formulieren. Inzendingen en Instellingen tekenen hem zelf.
 */
function _ww_forms_panel_picker_output(): void {
	if ( 'list' !== _ww_forms_panel_screen() ) {
		return;
	}
	echo _ww_forms_render_picker( 'list' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_forms_render_picker() escapet.
}
add_action( 'all_admin_notices', '_ww_forms_panel_picker_output' );

/**
 * De bodyklasse waarmee de stijl ruimte maakt voor het paneel.
 *
 * @param string $classes Bodyklassen.
 */
function _ww_forms_panel_body_class( string $classes ): string {
	return '' === _ww_forms_panel_screen() ? $classes : $classes . ' ww-forms-has-panel';
}
add_filter( 'admin_body_class', '_ww_forms_panel_body_class' );

/**
 * Laadt de stijl van het paneel, alleen op de formulierenschermen.
 *
 * @param string $hook Hook van het scherm.
 */
function _ww_forms_panel_assets( string $hook ): void {
	unset( $hook );
	if ( '' === _ww_forms_panel_screen() ) {
		return;
	}
	wp_enqueue_style( 'ww-forms-admin', _ww_asset_url( 'css/forms-admin.css' ), array(), WW_BASE_VERSION );
	if ( 'edit' === _ww_forms_panel_screen() ) {
		wp_enqueue_script( 'ww-forms-panel', _ww_asset_url( 'js/forms-panel.js' ), array(), WW_BASE_VERSION, array( 'in_footer' => true ) );
	}
}
add_action( 'admin_enqueue_scripts', '_ww_forms_panel_assets' );

/**
 * Haalt Nieuw formulier, Inzendingen en Instellingen uit het submenu; het paneel neemt ze over. Dat gebeurt pas op
 * admin_head. Op admin_menu zou alleen Alle formulieren overblijven, en wp-admin/includes/menu.php (na admin_menu, vóór
 * de toegangscontrole) vouwt een submenu met één item op. get_admin_page_parent() vindt Inzendingen en Instellingen
 * dan in geen enkel submenu en geeft '', de hooknaam wordt admin_page_… in plaats van de geregistreerde
 * ww_form_page_…, en user_can_access_admin_page() geeft "geen toestemming". admin_head komt na die controle en vóór
 * het menu getekend wordt; Formulieren blijft het actieve menu ($parent_file is dan al gezet). Blijft alleen Alle
 * formulieren over, dan gaat het submenu hier weg, zoals WordPress zelf doet bij één item.
 */
function _ww_forms_panel_hide_submenus(): void {
	global $submenu;
	$parent = 'edit.php?post_type=' . WW_FORM_POST_TYPE;
	remove_submenu_page( $parent, 'post-new.php?post_type=' . WW_FORM_POST_TYPE );
	remove_submenu_page( $parent, WW_FORM_ENTRIES_SCREEN );
	remove_submenu_page( $parent, WW_FORMS_SETTINGS_SCREEN );
	$left = (array) ( $submenu[ $parent ] ?? array() );
	if ( 1 === count( $left ) && $parent === ( reset( $left )[2] ?? '' ) ) {
		unset( $submenu[ $parent ] );
	}
}
add_action( 'admin_head', '_ww_forms_panel_hide_submenus' );

/**
 * Zet het bolletje met nieuwe inzendingen achter Formulieren.
 */
function _ww_forms_panel_menu(): void {
	global $menu;
	$parent = 'edit.php?post_type=' . WW_FORM_POST_TYPE;

	if ( ! current_user_can( 'edit_others_pages' ) || ! is_array( $menu ) ) {
		return;
	}
	$count = _ww_form_entries_count_new();
	if ( $count < 1 ) {
		return;
	}
	foreach ( $menu as $index => $item ) {
		if ( $parent !== ( $item[2] ?? '' ) || str_contains( _ww_data_to_string( $item[0] ?? '' ), 'awaiting-mod' ) ) {
			continue;
		}
		$menu[ $index ][0] = _ww_data_to_string( $item[0] ?? '' ) . ' <span class="awaiting-mod">' . esc_html( number_format_i18n( $count ) ) . '</span>'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- het menu van WordPress zelf.
	}
}
add_action( 'admin_menu', '_ww_forms_panel_menu', 99 );
