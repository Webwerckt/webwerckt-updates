<?php
/**
 * SEO-plugins (ADR 0023, 0024). Het thema doet de SEO zelf (inc/seo.php) en het schema (inc/schema.php). Is er toch
 * een SEO-plugin actief, dan meldt dit bestand hem via ww_seo_plugin en doet het thema geen titels, beschrijvingen,
 * canonical, Open Graph of sitemap. The SEO Framework (TSF) zet daarbij geen structured data: dat blijft van het thema.
 * Een andere SEO-plugin met eigen schema gaat ook daarvoor; dan zet het thema niets.
 *
 * De 404 en de zoekresultaten krijgen altijd noindex, via TSF als die actief is (TSF zet zelf een robots-tag en haalt
 * die van WordPress weg), anders via wp_robots (_ww_seo_robots() in inc/seo.php). Zo staat er nooit een tweede robots-tag.
 *
 * Zonder plugin gebeurt er niets en breekt er niets (regel 55).
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Filter ww_schema_plugin: de naam van een actieve SEO-plugin die zelf structured data zet (Yoast, Rank Math,
 * SEOPress, All in One SEO). TSF telt niet mee: daarvan zet het thema het schema uit. Een naam die al is ingevuld
 * (door een child-thema of andere plugin), blijft staan.
 *
 * @param mixed $plugin Naam tot nu toe, of ''.
 */
function _ww_seo_plugin_with_schema( $plugin ): string {
	$plugin = _ww_data_to_string( $plugin );
	if ( '' !== $plugin ) {
		return $plugin;
	}
	$plugins = array(
		'WPSEO_VERSION'     => 'Yoast SEO',
		'RANK_MATH_VERSION' => 'Rank Math',
		'SEOPRESS_VERSION'  => 'SEOPress',
		'AIOSEO_VERSION'    => 'All in One SEO',
	);
	foreach ( $plugins as $constant => $name ) {
		if ( defined( $constant ) ) {
			return $name;
		}
	}
	return '';
}
add_filter( 'ww_schema_plugin', '_ww_seo_plugin_with_schema' );

/**
 * Filter ww_seo_plugin: de naam van een actieve SEO-plugin, ook The SEO Framework. Een naam die al is ingevuld (door
 * een child-thema of andere plugin), blijft staan.
 *
 * @param mixed $plugin Naam tot nu toe, of ''.
 */
function _ww_seo_plugin_name( $plugin ): string {
	$plugin = _ww_seo_plugin_with_schema( $plugin );
	return '' === $plugin && _ww_tsf_active() ? 'The SEO Framework' : $plugin;
}
add_filter( 'ww_seo_plugin', '_ww_seo_plugin_name' );

/**
 * Is The SEO Framework actief?
 */
function _ww_tsf_active(): bool {
	return defined( 'THE_SEO_FRAMEWORK_VERSION' );
}

/**
 * TSF bouwt geen graph zolang het thema het schema levert. Een filter in plaats van de instelling "Gestructureerde
 * data uitvoeren?": die kan iemand weer aanzetten, en TSF onthoudt zijn instellingen al vóór het thema laadt.
 *
 * @param mixed $graph Nodes van TSF.
 * @return mixed
 */
function _ww_tsf_schema_graph( $graph ) {
	return _ww_schema_enabled() ? array() : $graph;
}
add_filter( 'the_seo_framework_schema_graph_data', '_ww_tsf_schema_graph' );

/**
 * Robots van TSF: noindex op een 404 en op zoekresultaten, ook als die instelling in TSF uit staat. Alleen voor de
 * pagina van het verzoek zelf ($args null) op de frontend: TSF vraagt de robots ook op voor andere berichten (de
 * SEO-balk in de admin, de sitemap), en in de admin is een gezochte berichtenlijst ook is_search().
 *
 * @param mixed $meta Robots van TSF, zoals [ 'noindex' => 'noindex' ].
 * @param mixed $args Bericht, term of archief waarvoor TSF de robots bepaalt; null is de huidige pagina.
 * @return mixed
 */
function _ww_tsf_robots( $meta, $args = null ) {
	if ( is_array( $meta ) && null === $args && ! is_admin() && _ww_is_noindex_page() ) {
		$meta['noindex'] = 'noindex';
	}
	return $meta;
}
add_filter( 'the_seo_framework_robots_meta_array', '_ww_tsf_robots', 10, 2 );

/**
 * Melding op het instellingenscherm van TSF dat de schema-instellingen daar geen effect hebben.
 */
function _ww_tsf_schema_notice(): void {
	$page = _ww_query_key( 'page' );
	if ( 'theseoframework-settings' !== $page || ! _ww_tsf_active() || ! _ww_schema_enabled() ) {
		return;
	}
	printf(
		'<div class="notice notice-info"><p>%s</p></div>',
		esc_html__( 'Structured data komt van het thema webwerckt-base. De instellingen onder "Schema.org Instellingen" hebben geen effect.', 'webwerckt-base' )
	);
}
add_action( 'admin_notices', '_ww_tsf_schema_notice' );
