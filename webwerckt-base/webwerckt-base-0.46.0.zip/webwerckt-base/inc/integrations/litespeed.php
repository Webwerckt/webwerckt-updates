<?php
/**
 * LiteSpeed Cache: tags en purges. Alles zijn hooks; zonder actieve plugin gebeurt er niets.
 *
 * De rest van de parent kent LiteSpeed niet, maar meldt met eigen acties wat er gebeurt: ww_shows_post_type (deze
 * pagina toont items van een post type), ww_cacheable (dit antwoord mag wel of niet in een paginacache) en
 * ww_cache_ttl (hoogstens zo lang). Wat er leeg moet, bepaalt inc/cache.php en meldt het met _ww_purge_post_type
 * en _ww_purge_all. Dit bestand vertaalt al die acties naar LiteSpeed.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Cache-tag van een post type, bijvoorbeeld 'ww_service'.
 */
function _ww_cache_tag_name( string $post_type ): string {
	return 'ww_' . sanitize_key( $post_type );
}

/**
 * Voegt de pagina die nu wordt opgebouwd toe aan de tag van een post type.
 *
 * @param mixed $post_type Post type; een publieke actie kan van alles doorgeven, dus pas na controle een string.
 */
function _ww_cache_tag( $post_type = '' ): void {
	$post_type = _ww_data_to_string( $post_type );
	if ( '' === $post_type ) {
		return;
	}
	do_action( 'litespeed_tag_add', _ww_cache_tag_name( $post_type ) );
}
add_action( 'ww_shows_post_type', '_ww_cache_tag' );

/**
 * Antwoord wel of niet in de cache. Wel: ook als "Cache REST API" in LiteSpeed uit staat, want de parent meldt alleen
 * publieke antwoorden die de tags van hun post type dragen.
 *
 * @param mixed $cacheable Of het antwoord in de cache mag.
 * @param mixed $reason    Waarom, zichtbaar in de debuglog van LiteSpeed.
 */
function _ww_cache_control( $cacheable, $reason = '' ): void {
	do_action( $cacheable ? 'litespeed_control_set_cacheable' : 'litespeed_control_set_nocache', _ww_data_to_string( $reason ) );
}
add_action( 'ww_cacheable', '_ww_cache_control', 10, 2 );

/**
 * Hoogstens zo lang in de cache, voor een pagina met iets dat maar even waar is ("nu open").
 *
 * @param mixed $seconds Seconden.
 */
function _ww_cache_ttl( $seconds ): void {
	$seconds = absint( $seconds );
	if ( $seconds > 0 ) {
		do_action( 'litespeed_control_set_ttl', $seconds );
	}
}
add_action( 'ww_cache_ttl', '_ww_cache_ttl' );

/**
 * Leegt bij LiteSpeed de pagina's met de tag van een post type.
 *
 * @param mixed $post_type Post type, van _ww_purge_post_type.
 */
function _ww_litespeed_purge_post_type( $post_type ): void {
	do_action( 'litespeed_purge', _ww_cache_tag_name( _ww_data_to_string( $post_type ) ) );
}
add_action( '_ww_purge_post_type', '_ww_litespeed_purge_post_type' );

/**
 * Leegt bij LiteSpeed de hele cache.
 */
function _ww_litespeed_purge_all(): void {
	do_action( 'litespeed_purge_all' );
}
add_action( '_ww_purge_all', '_ww_litespeed_purge_all' );
