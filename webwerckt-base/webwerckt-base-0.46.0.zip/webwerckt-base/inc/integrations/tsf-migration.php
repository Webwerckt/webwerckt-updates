<?php
/**
 * Eenmalige overstap van The SEO Framework (TSF) naar de SEO van het thema (ADR 0024). Kopieert de waarden van TSF
 * naar de velden van het thema, alleen waar het veld van het thema nog leeg is. Twee abilities:
 *
 * - webwerckt/plan-tsf-migration (lezen): wat er gekopieerd zou worden, wat niet en waarom, en hoeveel rijen er per
 *   sleutel van TSF zijn, zodat de sleutels hieronder op de echte database na te kijken zijn.
 * - webwerckt/migrate-tsf (schrijven, alleen op het staging-slot van ADR 0018): voert het plan uit.
 *
 * De sleutels van TSF staan alleen in de constanten hieronder. Dit bestand gaat eruit zodra de sites over zijn.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Post meta van TSF per bericht.
 */
const WW_TSF_POST_KEYS = array(
	'title'          => '_genesis_title',
	'description'    => '_genesis_description',
	'canonical'      => '_genesis_canonical_uri',
	'noindex'        => '_genesis_noindex',
	'image_id'       => '_social_image_id',
	'image_url'      => '_social_image_url',
	'no_blogname'    => '_tsf_title_no_blogname',
	'redirect'       => 'redirect',
	'exclude_search' => 'exclude_local_search',
);

/**
 * De optie met de site-instellingen van TSF, en de sleutels daarin.
 */
const WW_TSF_SITE_OPTION = 'autodescription-site-settings';
const WW_TSF_SITE_KEYS   = array(
	'separator'        => 'title_separator',
	'home_title'       => 'homepage_title',
	'home_description' => 'homepage_description',
	'image_id'         => 'social_image_fb_id',
	'image_url'        => 'social_image_fb_url',
	'remove_additions' => 'title_rem_additions',
);

/**
 * Term meta van TSF (één array per term). Termen hebben geen SEO-velden in het thema: alleen geteld.
 */
const WW_TSF_TERM_KEY = 'autodescription-term-settings';

/**
 * Scheidingstekens van TSF naar die van het thema (WW_SEO_SEPARATORS); onbekend wordt ndash.
 */
const WW_TSF_SEPARATORS = array(
	'hyphen' => 'hyphen',
	'dash'   => 'hyphen',
	'ndash'  => 'ndash',
	'mdash'  => 'ndash',
	'pipe'   => 'pipe',
	'middot' => 'middot',
	'bull'   => 'bullet',
	'bullet' => 'bullet',
);

/**
 * Een URL om te vergelijken: zonder schema, www, slash aan het eind en hoofdletters.
 */
function _ww_tsf_comparable_url( string $url ): string {
	$url = strtolower( trim( $url ) );
	$url = (string) preg_replace( '#^https?://(www\.)?#', '', $url );
	return untrailingslashit( $url );
}

/**
 * De site-instellingen van TSF als array.
 *
 * @return array<string,mixed>
 */
function _ww_tsf_site_settings(): array {
	$settings = get_option( WW_TSF_SITE_OPTION, array() );
	return is_array( $settings ) ? $settings : array();
}

/**
 * Het scheidingsteken van het thema dat bij dat van TSF hoort.
 */
function _ww_tsf_separator_key(): string {
	$tsf = _ww_data_to_string( _ww_tsf_site_settings()[ WW_TSF_SITE_KEYS['separator'] ] ?? '' );
	return WW_TSF_SEPARATORS[ $tsf ] ?? 'ndash';
}

/**
 * Een afbeelding van TSF als attachment-ID: de ID, anders de URL opgezocht in de mediabibliotheek. 0 als er geen is.
 */
function _ww_tsf_image_id( int $id, string $url ): int {
	if ( $id > 0 && 'attachment' === get_post_type( $id ) ) {
		return $id;
	}
	return '' === $url ? 0 : attachment_url_to_postid( $url );
}

/**
 * Het plan voor één bericht: per veld van het thema de nieuwe waarde (changes) of waarom niet (skipped).
 *
 * @return array{changes:array<string,string>,skipped:array<string,string>}
 */
function _ww_tsf_post_plan( int $post_id ): array {
	$meta    = static fn( string $key ): string => trim( _ww_data_to_string( get_post_meta( $post_id, WW_TSF_POST_KEYS[ $key ], true ) ) );
	$empty   = static fn( string $field ): bool => '' === _ww_data_to_string( get_post_meta( $post_id, $field, true ) );
	$values  = array();
	$skipped = array();

	$title = $meta( 'title' );
	if ( '' !== $title ) {
		// TSF zet de sitenaam achter een eigen titel, tenzij dat per bericht of voor de hele site uit staat. Het veld
		// van het thema vervangt de hele titel, dus de sitenaam gaat mee in de waarde.
		$additions = '1' !== $meta( 'no_blogname' ) && empty( _ww_tsf_site_settings()[ WW_TSF_SITE_KEYS['remove_additions'] ] );
		$values['ww_seo_title'] = $additions ? $title . ' ' . WW_SEO_SEPARATORS[ _ww_tsf_separator_key() ] . ' ' . _ww_plain_text( get_bloginfo( 'name' ) ) : $title;
	}

	$description = $meta( 'description' );
	if ( '' !== $description ) {
		$values['ww_seo_description'] = $description;
	}

	$canonical = $meta( 'canonical' );
	$own       = get_permalink( $post_id );
	if ( '' !== $canonical && is_string( $own ) && _ww_tsf_comparable_url( $canonical ) === _ww_tsf_comparable_url( $own ) ) {
		$skipped['ww_seo_canonical'] = __( 'gelijk aan het eigen adres', 'webwerckt-base' );
	} elseif ( '' !== $canonical ) {
		$values['ww_seo_canonical'] = esc_url_raw( $canonical );
	}

	// TSF bewaart 1 (noindex), 0 (standaard) of -1 (altijd indexeren): alleen 1 is noindex.
	$noindex = $meta( 'noindex' );
	if ( '1' === $noindex ) {
		$values['ww_seo_noindex'] = '1';
	} elseif ( '' !== $noindex && '0' !== $noindex ) {
		/* translators: %s: waarde van TSF. */
		$skipped['ww_seo_noindex'] = sprintf( __( 'TSF-waarde %s is geen noindex', 'webwerckt-base' ), $noindex );
	}

	$image_url = $meta( 'image_url' );
	$image     = _ww_tsf_image_id( (int) $meta( 'image_id' ), $image_url );
	if ( $image > 0 ) {
		$values['ww_seo_image'] = (string) $image;
	} elseif ( '' !== $image_url ) {
		/* translators: %s: URL van de afbeelding. */
		$skipped['ww_seo_image'] = sprintf( __( 'niet in de mediabibliotheek: %s', 'webwerckt-base' ), $image_url );
	}

	$changes = array();
	foreach ( $values as $field => $value ) {
		if ( $empty( $field ) ) {
			$changes[ $field ] = $value;
		} else {
			$skipped[ $field ] = __( 'veld van het thema is al ingevuld', 'webwerckt-base' );
		}
	}
	if ( '' !== $meta( 'redirect' ) ) {
		/* translators: %s: doel van de doorverwijzing. */
		$skipped['redirect'] = sprintf( __( 'doorverwijzing naar %s: zet die in de redirect-plugin', 'webwerckt-base' ), $meta( 'redirect' ) );
	}
	if ( '1' === $meta( 'exclude_search' ) ) {
		$skipped['exclude_search'] = __( 'uitgesloten van de zoekfunctie: het thema kent dat niet per pagina', 'webwerckt-base' );
	}
	return array(
		'changes' => $changes,
		'skipped' => $skipped,
	);
}

/**
 * Het plan voor de Site-instellingen: per optie de nieuwe waarde, alleen waar de optie nog leeg is.
 *
 * @return array<string,string> Veld van de Site-instellingen => waarde.
 */
function _ww_tsf_settings_plan(): array {
	$tsf    = _ww_tsf_site_settings();
	$values = array(
		'seo_separator'        => array() === $tsf ? '' : _ww_tsf_separator_key(),
		'seo_home_title'       => trim( _ww_data_to_string( $tsf[ WW_TSF_SITE_KEYS['home_title'] ] ?? '' ) ),
		'seo_home_description' => trim( _ww_data_to_string( $tsf[ WW_TSF_SITE_KEYS['home_description'] ] ?? '' ) ),
	);
	$image  = _ww_tsf_image_id( (int) ( $tsf[ WW_TSF_SITE_KEYS['image_id'] ] ?? 0 ), _ww_data_to_string( $tsf[ WW_TSF_SITE_KEYS['image_url'] ] ?? '' ) );
	if ( $image > 0 ) {
		$values['seo_image'] = (string) $image;
	}
	return array_filter(
		$values,
		static fn( string $value, string $field ): bool => '' !== $value && '' === _ww_setting_string( $field ),
		ARRAY_FILTER_USE_BOTH
	);
}

/**
 * Hoeveel rijen er per sleutel van TSF zijn: zo is te zien of de sleutels kloppen voor deze site.
 *
 * @return array<string,int>
 */
function _ww_tsf_key_counts(): array {
	global $wpdb;
	$counts = array();
	foreach ( array_merge( array_values( WW_TSF_POST_KEYS ), array( WW_TSF_TERM_KEY ) ) as $key ) {
		$table            = WW_TSF_TERM_KEY === $key ? $wpdb->termmeta : $wpdb->postmeta;
		$counts[ $key ] = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE meta_key = %s AND meta_value <> %s', $table, $key, '' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}
	$counts[ WW_TSF_SITE_OPTION ] = array() === _ww_tsf_site_settings() ? 0 : 1;
	return $counts;
}

/**
 * Het hele plan: berichten met iets om te kopiëren of over te slaan, de Site-instellingen, termen met eigen waarden
 * van TSF (die het thema niet overneemt) en de rijen per sleutel.
 *
 * @return array<string,mixed>
 */
function _ww_tsf_migration_plan(): array {
	$ids   = get_posts(
		array(
			'post_type'      => _ww_seo_post_types(),
			'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future' ),
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'orderby'        => 'ID',
			'order'          => 'ASC',
		)
	);
	$posts = array();
	update_meta_cache( 'post', $ids );
	foreach ( $ids as $id ) {
		$plan = _ww_tsf_post_plan( (int) $id );
		if ( array() !== $plan['changes'] || array() !== $plan['skipped'] ) {
			$posts[] = array(
				'id'    => (int) $id,
				'title' => _ww_plain_text( get_the_title( (int) $id ) ),
			) + $plan;
		}
	}
	$keys = _ww_tsf_key_counts();
	return array(
		'posts'    => $posts,
		'settings' => _ww_tsf_settings_plan(),
		'terms'    => $keys[ WW_TSF_TERM_KEY ],
		'keys'     => $keys,
	);
}

/**
 * Voert het plan uit en geeft terug wat er geschreven is.
 *
 * @return array<string,mixed>
 */
function _ww_tsf_migration_apply(): array {
	$plan = _ww_tsf_migration_plan();
	foreach ( $plan['posts'] as $post ) {
		foreach ( $post['changes'] as $field => $value ) {
			update_post_meta( $post['id'], $field, $value );
		}
		// Een canonical gelijk aan het eigen adres valt weg, net als bij opslaan in de admin.
		_ww_seo_clean_canonical( $post['id'] );
	}
	foreach ( $plan['settings'] as $field => $value ) {
		update_option( _ww_settings_prefix() . $field, $value );
	}
	return array( 'written' => true ) + $plan;
}

/**
 * Meldt de twee abilities aan.
 */
function _ww_tsf_migration_register(): void {
	$description = __( 'Overstap van The SEO Framework naar de SEO van het thema (ADR 0024). Kopieert per bericht titel (met de sitenaam die TSF erachter zette), beschrijving, canonical (niet als die gelijk is aan het eigen adres), noindex (alleen een expliciete) en afbeelding, en in de Site-instellingen scheidingsteken, homepage en afbeelding bij delen. Alleen waar het veld van het thema nog leeg is. keys geeft het aantal rijen per sleutel van TSF: staat daar 0 bij een sleutel die de site wel gebruikt, dan klopt de sleutel niet.', 'webwerckt-base' );
	_ww_register_ability(
		'plan-tsf-migration',
		__( 'Overstap van The SEO Framework bekijken', 'webwerckt-base' ),
		$description . ' ' . __( 'Schrijft niets.', 'webwerckt-base' ),
		_ww_abilities_schema( array() ),
		static fn(): array => _ww_tsf_migration_plan(),
		static fn(): bool => current_user_can( 'manage_options' ),
		true
	);
	_ww_register_ability(
		'migrate-tsf',
		__( 'Overstappen van The SEO Framework', 'webwerckt-base' ),
		$description . ' ' . __( 'Bekijk eerst webwerckt/plan-tsf-migration. Zet daarna The SEO Framework uit.', 'webwerckt-base' ),
		_ww_abilities_schema( array() ),
		static fn(): array => _ww_tsf_migration_apply(),
		static fn(): bool => current_user_can( 'manage_options' ),
		false
	);
}
add_action( 'wp_abilities_api_init', '_ww_tsf_migration_register' );
