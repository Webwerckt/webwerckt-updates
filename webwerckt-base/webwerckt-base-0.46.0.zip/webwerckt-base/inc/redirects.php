<?php
/**
 * Redirects en 404-logboek: tabellen, schemaversie en het normaliseren van paden (beslissing 0031).
 *
 * Twee eigen tabellen: {prefix}ww_redirects (de regels) en {prefix}ww_404_log (welke paden niet bestaan). Het schema
 * wordt bij admin_init en na een themawissel aangelegd; aan de voorkant controleert het thema alleen de optie
 * ww_redirects_db_version, nooit de database zelf.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const WW_REDIRECTS_DB_VERSION = 1;

/**
 * Naam van de tabel met redirectregels.
 */
function _ww_redirects_table(): string {
	global $wpdb;
	return $wpdb->prefix . 'ww_redirects';
}

/**
 * Naam van de tabel met het 404-logboek.
 */
function _ww_404_log_table(): string {
	global $wpdb;
	return $wpdb->prefix . 'ww_404_log';
}

/**
 * Legt beide tabellen aan (of werkt ze bij) en bewaart de schemaversie.
 */
function _ww_redirects_install(): void {
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';

	$charset = $wpdb->get_charset_collate();

	dbDelta(
		'CREATE TABLE ' . _ww_redirects_table() . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  source varchar(255) NOT NULL,
  match_type varchar(10) NOT NULL DEFAULT 'exact',
  target varchar(2048) NOT NULL DEFAULT '',
  status smallint(6) NOT NULL DEFAULT 301,
  origin varchar(10) NOT NULL DEFAULT 'manual',
  post_id bigint(20) unsigned NOT NULL DEFAULT 0,
  hits bigint(20) unsigned NOT NULL DEFAULT 0,
  last_hit datetime DEFAULT NULL,
  created datetime NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY source (source)
) $charset;"
	);

	dbDelta(
		'CREATE TABLE ' . _ww_404_log_table() . " (
  path varchar(255) NOT NULL,
  hits bigint(20) unsigned NOT NULL DEFAULT 0,
  first_seen datetime NOT NULL,
  last_seen datetime NOT NULL,
  referrer varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY  (path),
  KEY last_seen (last_seen)
) $charset;"
	);

	// Alleen als beide tabellen er echt zijn is het schema klaar; anders probeert admin_init het bij het volgende bezoek opnieuw.
	// Een SELECT in plaats van SHOW TABLES: die laat tijdelijke tabellen (de testsuite) niet zien.
	$suppressed = $wpdb->suppress_errors( true );
	$complete   = true;
	foreach ( array( _ww_redirects_table(), _ww_404_log_table() ) as $table ) {
		if ( false === $wpdb->query( "SELECT 1 FROM $table LIMIT 1" ) ) { // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_redirects_table() en _ww_404_log_table().
			$complete = false;
		}
	}
	$wpdb->suppress_errors( $suppressed );
	if ( ! $complete ) {
		return;
	}

	// De schemaversie wordt bij elk verzoek gelezen: autoload, anders kost dat een query extra (ook voor bestaande installaties).
	update_option( 'ww_redirects_db_version', WW_REDIRECTS_DB_VERSION, true );
	wp_set_option_autoload( 'ww_redirects_db_version', true );
}

/**
 * Zijn de tabellen aangelegd voor deze schemaversie? Aan de voorkant de enige controle.
 */
function _ww_redirects_ready(): bool {
	return (int) get_option( 'ww_redirects_db_version' ) === WW_REDIRECTS_DB_VERSION;
}

/**
 * Zorgt dat de tabellen er zijn voor wie ze buiten het scherm gebruikt (REST-abilities, export): legt ze zo nodig aan.
 * Geeft terug of ze er daarna zijn.
 */
function _ww_redirects_ensure_ready(): bool {
	if ( ! _ww_redirects_ready() ) {
		_ww_redirects_install();
	}
	return _ww_redirects_ready();
}

add_action(
	'admin_init',
	static function (): void {
		if ( ! _ww_redirects_ready() ) {
			_ww_redirects_install();
		}
	}
);
add_action( 'after_switch_theme', '_ww_redirects_install' );

/**
 * Verwijdert beide tabellen, de schemaversie en de geplande opruiming van het logboek: voor wie het thema voorgoed van een site haalt. Aan de voorkant geeft
 * het thema daarna geen redirects meer, zonder databasefout (_ww_redirects_ready() is dan false).
 */
function _ww_redirects_drop_tables(): void {
	global $wpdb;
	$wpdb->query( 'DROP TABLE IF EXISTS ' . _ww_redirects_table() ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.SchemaChange -- tabelnaam uit _ww_redirects_table().
	$wpdb->query( 'DROP TABLE IF EXISTS ' . _ww_404_log_table() ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.SchemaChange -- tabelnaam uit _ww_404_log_table().
	delete_option( 'ww_redirects_db_version' );
	wp_clear_scheduled_hook( WW_404_LOG_CLEANUP_HOOK );
}

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	/**
	 * Commando's voor de redirects en het 404-logboek van het thema.
	 */
	class WW_Redirects_CLI_Command {

		/**
		 * Verwijdert de tabellen ww_redirects en ww_404_log, de schemaversie en de geplande opruiming. Alle redirects en het logboek gaan verloren.
		 * Werkt alleen zolang dit thema actief is: voer het uit vóór je naar een ander thema overstapt.
		 *
		 * ## OPTIONS
		 *
		 * [--yes]
		 * : Niet om bevestiging vragen.
		 *
		 * ## EXAMPLES
		 *
		 *     wp ww redirects drop-tables --yes
		 *
		 * @subcommand drop-tables
		 *
		 * @param string[]             $args       Positionele argumenten (geen).
		 * @param array<string,string> $assoc_args Opties.
		 */
		public function drop_tables( $args, $assoc_args ): void {
			WP_CLI::confirm( 'Alle redirects en het 404-logboek van deze site verwijderen? Dit kan niet ongedaan worden gemaakt.', $assoc_args );
			_ww_redirects_drop_tables();
			WP_CLI::success( 'De tabellen ww_redirects en ww_404_log zijn verwijderd.' );
		}
	}
	WP_CLI::add_command( 'ww redirects', 'WW_Redirects_CLI_Command' );
}

/**
 * Maakt van een URL of pad een genormaliseerd pad, of null als het geen geldige bron is.
 *
 * Alleen het pad (zonder query-string), zonder het pad van de site-URL bij een submap-installatie, in kleine
 * letters (ook de hexadecimale tekens van %-codes), met enkele slashes, beginnend met een slash en eindigend
 * met een slash tenzij het laatste deel een punt heeft. Hoogstens 255 tekens.
 *
 * @param string $url       Volledige URL, pad of relatief pad.
 * @param bool   $lowercase Naar kleine letters (voor bronnen en vergelijken); false laat de hoofdletters staan (voor een opgeslagen doel).
 * @param bool   $limit     Weiger paden van meer dan 255 tekens; false voor een verzoekpad, dat langer mag zijn dan elke bron.
 */
function _ww_redirect_normalize( string $url, bool $lowercase = true, bool $limit = true ): ?string {
	$url = trim( $url );
	if ( '' === $url ) {
		return null;
	}

	if ( preg_match( '#^[a-z][a-z0-9+.-]*://#i', $url ) ) {
		$parts = wp_parse_url( $url );
		if ( ! is_array( $parts ) || empty( $parts['host'] ) ) {
			return null;
		}
		$home_host = wp_parse_url( home_url(), PHP_URL_HOST );
		if ( ! is_string( $home_host ) || 0 !== strcasecmp( $parts['host'], $home_host ) ) {
			return null;
		}
		$path = $parts['path'] ?? '';
	} else {
		// Geen wp_parse_url: "//a/b" zou daar als host "a" gelden.
		$path = (string) strtok( $url, '?#' );
	}

	if ( $lowercase ) {
		$path = strtolower( $path );
	}
	$path = (string) preg_replace( '#/{2,}#', '/', '/' . $path );

	$home_path = wp_parse_url( home_url(), PHP_URL_PATH );
	if ( is_string( $home_path ) ) {
		$home_path = strtolower( (string) preg_replace( '#/{2,}#', '/', '/' . trim( $home_path, '/' ) ) );
		if ( '/' !== $home_path ) {
			$lower = strtolower( $path );
			if ( $lower === $home_path ) {
				$path = '/';
			} elseif ( str_starts_with( $lower, $home_path . '/' ) ) {
				$path = substr( $path, strlen( $home_path ) );
			}
		}
	}

	$last = substr( $path, (int) strrpos( $path, '/' ) + 1 );
	if ( '' !== $last && ! str_contains( $last, '.' ) ) {
		$path .= '/';
	}

	if ( $limit && strlen( $path ) > 255 ) {
		return null;
	}
	return $path;
}

/**
 * Een regel uit de tabel voor precies deze (genormaliseerde) bron.
 *
 * @param string $source Genormaliseerde bron.
 */
function _ww_redirect_get_by_source( string $source ): ?object {
	global $wpdb;
	$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . _ww_redirects_table() . ' WHERE source = %s', $source ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_redirects_table().
	return is_object( $row ) ? $row : null;
}

/**
 * De regel die voor een genormaliseerd pad geldt: een exacte regel voor het pad zelf, of anders het langste
 * voorvoegsel boven het pad. Eén query over het pad en al zijn ouders.
 *
 * @param string $path        Genormaliseerd pad.
 * @param bool   $prefix_only Alleen voorvoegselregels meetellen (voor een nieuwe voorvoegselregel).
 */
function _ww_redirect_match( string $path, bool $prefix_only = false ): ?object {
	global $wpdb;
	if ( ! _ww_redirects_ready() ) {
		return null;
	}

	$candidates = array( $path );
	$parent     = $path;
	while ( '/' !== $parent ) {
		$parent       = rtrim( $parent, '/' );
		$parent       = substr( $parent, 0, (int) strrpos( $parent, '/' ) + 1 );
		$parent       = '' === $parent ? '/' : $parent;
		$candidates[] = $parent;
	}
	// Een bron is hoogstens 255 tekens: een langer kandidaat-pad kan niet bestaan, de ouders ervan wel.
	$candidates = array_values(
		array_filter(
			array_unique( $candidates ),
			static fn( string $candidate ): bool => strlen( $candidate ) <= 255
		)
	);

	$placeholders = implode( ',', array_fill( 0, count( $candidates ), '%s' ) );
	$rows         = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . _ww_redirects_table() . " WHERE source IN ($placeholders)", $candidates ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- tabelnaam en placeholders zijn eigen waarden.

	$best = null;
	foreach ( (array) $rows as $row ) {
		if ( 'prefix' !== $row->match_type && ( $prefix_only || $row->source !== $path ) ) {
			continue;
		}
		if ( null === $best || strlen( $row->source ) > strlen( $best->source ) ) {
			$best = $row;
		}
	}
	return $best;
}

/**
 * Is dit doel een pad op deze site (begint met een slash, of een volledige URL op de host van home_url())? Geeft het
 * genormaliseerde pad, of null voor een extern doel.
 *
 * @param string $target Doel van een regel.
 */
function _ww_redirect_internal_path( string $target ): ?string {
	$target = trim( $target );
	if ( str_starts_with( $target, '/' ) || preg_match( '#^https?://#i', $target ) ) {
		return _ww_redirect_normalize( $target );
	}
	return null;
}

/**
 * Het doel van een regel voor een pad. Bij een voorvoegselregel gaat het deel van het pad na de bron achter het doel:
 * /oud/blog/ naar /blog/ maakt van /oud/blog/artikel-x/ het doel /blog/artikel-x/.
 *
 * @param object $rule Regel uit de tabel.
 * @param string $path Genormaliseerd pad dat onder de regel valt.
 */
function _ww_redirect_target_with_rest( object $rule, string $path ): string {
	$target = (string) $rule->target;
	if ( 'prefix' === $rule->match_type && strlen( $path ) > strlen( (string) $rule->source ) ) {
		// De rest hoort bij het pad van het doel, vóór een query-string of fragment.
		$cut  = strcspn( $target, '?#' );
		$tail = substr( $target, $cut );
		$base = substr( $target, 0, $cut );

		$target = rtrim( $base, '/' ) . '/' . substr( $path, strlen( (string) $rule->source ) ) . $tail;
	}
	return $target;
}

/**
 * Volgt een doel door de bestaande regels naar het einddoel (hoogstens 10 stappen).
 *
 * Valt het doel onder een voorvoegselregel, dan wordt de rest na dat voorvoegsel achter het doel van die regel gezet.
 * Een 410 als einde geeft status 410 met een leeg doel. Met $source (de bron van een nieuwe regel) is het een kring
 * zodra de keten weer bij die bron uitkomt (bij een voorvoegsel ook eronder), of als er meer dan 10 stappen nodig zijn.
 * Een nieuwe voorvoegselregel volgt alleen voorvoegselregels: een exacte regel op het doel dekt de paden eronder niet.
 *
 * @param string $target     Doel zoals opgegeven.
 * @param string $source     Genormaliseerde bron van de regel die wordt opgeslagen, of '' om geen kring te zoeken.
 * @param string $match_type Type van die regel (exact of prefix).
 * @return array{target:string,status:int,loop:bool} Status is die van de laatst gevolgde regel, anders 301.
 */
function _ww_redirect_final( string $target, string $source = '', string $match_type = 'exact' ): array {
	$status = 301;
	$path   = _ww_redirect_internal_path( $target );

	for ( $step = 0; $step <= 10; $step++ ) {
		if ( null === $path ) {
			return array(
				'target' => $target,
				'status' => $status,
				'loop'   => false,
			);
		}
		if ( '' !== $source && ( $path === $source || ( 'prefix' === $match_type && str_starts_with( $path, $source ) ) ) ) {
			return array(
				'target' => $target,
				'status' => $status,
				'loop'   => true,
			);
		}
		$rule = _ww_redirect_match( $path, 'prefix' === $match_type );
		if ( null === $rule ) {
			return array(
				'target' => $target,
				'status' => $status,
				'loop'   => false,
			);
		}
		if ( 410 === (int) $rule->status ) {
			return array(
				'target' => '',
				'status' => 410,
				'loop'   => false,
			);
		}
		$status = (int) $rule->status;
		$target = _ww_redirect_target_with_rest( $rule, $path );
		$path   = _ww_redirect_internal_path( $target );
	}

	return array(
		'target' => $target,
		'status' => $status,
		'loop'   => true,
	);
}

/**
 * Zou een nieuwe voorvoegselregel een kring geven via een regel die al onder het doel staat? Voorbeeld: /y/z/ naar
 * /x/z/ bestaat, en nu komt /x/ naar /y/: dan stuurt /x/z/ naar /y/z/ en dat weer terug. Alleen als de nieuwe regel het
 * doel van zo'n regel terug naar zijn bron stuurt: een exacte /b/ naar /a/sub/ met /a/ naar /b/ is geen kring. _ww_redirect_final() ziet dit niet,
 * omdat het alleen voorvoegselregels op het doel volgt.
 *
 * @param string $source Genormaliseerde bron van de nieuwe voorvoegselregel.
 * @param string $target Doel zoals opgegeven.
 * @param int    $own_id Id van de regel die wordt bijgewerkt (telt niet mee), of 0.
 */
function _ww_redirect_prefix_loop_below_target( string $source, string $target, int $own_id = 0 ): bool {
	global $wpdb;
	$path = _ww_redirect_internal_path( $target );
	if ( null === $path ) {
		return false;
	}

	$rules = $wpdb->get_results( $wpdb->prepare( 'SELECT id, source, match_type, target, status FROM ' . _ww_redirects_table() . ' WHERE source LIKE %s AND id <> %d', $wpdb->esc_like( $path ) . '%', $own_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_redirects_table().
	$new   = (object) array(
		'source'     => $source,
		'match_type' => 'prefix',
		'target'     => $target,
	);
	foreach ( (array) $rules as $rule ) {
		if ( 410 === (int) $rule->status ) {
			continue;
		}
		$goes_to = _ww_redirect_internal_path( (string) $rule->target );
		if ( null === $goes_to || ! str_starts_with( $goes_to, $source ) ) {
			continue;
		}
		// Waar stuurt de nieuwe regel dat doel heen? Komt dat weer bij de bron van de regel uit, dan is het een kring.
		$back = _ww_redirect_internal_path( _ww_redirect_target_with_rest( $new, $goes_to ) );
		if ( null !== $back && ( $back === $rule->source || ( 'prefix' === $rule->match_type && str_starts_with( $back, (string) $rule->source ) ) ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Valideert een regel en vult de standaardwaarden in, zonder iets te lezen of te schrijven. Gedeeld door
 * ww_redirect_save() en het voorbeeld van de import. Een kring of keten blijft buiten beeld: die hangt van de
 * bestaande regels af en wordt pas bij het opslaan gecontroleerd.
 *
 * @param array<string,mixed> $rule source, target, status (301), match_type (exact), origin (manual) en post_id (0).
 * @return array{source:string,match_type:string,target:string,status:int,origin:string,post_id:int}|WP_Error
 */
function _ww_redirect_validate( array $rule ) {
	$source = _ww_redirect_normalize( (string) ( $rule['source'] ?? '' ) );
	if ( null === $source ) {
		return new WP_Error( 'ww_redirect_invalid_source', __( 'Ongeldige bron: gebruik een pad op deze site van hoogstens 255 tekens.', 'webwerckt-base' ) );
	}

	$status = (int) ( $rule['status'] ?? 301 );
	if ( ! in_array( $status, array( 301, 302, 410 ), true ) ) {
		return new WP_Error( 'ww_redirect_invalid_status', __( 'Ongeldige status: kies 301, 302 of 410.', 'webwerckt-base' ) );
	}

	$match_type = 'prefix' === ( $rule['match_type'] ?? 'exact' ) ? 'prefix' : 'exact';
	$origin     = in_array( $rule['origin'] ?? 'manual', array( 'manual', 'import', 'slug' ), true ) ? (string) ( $rule['origin'] ?? 'manual' ) : 'manual';
	$post_id    = absint( $rule['post_id'] ?? 0 );

	$target = '';
	if ( 410 !== $status ) {
		$target = trim( (string) ( $rule['target'] ?? '' ) );
		$valid  = ( str_starts_with( $target, '/' ) && ! str_starts_with( $target, '//' ) ) || 1 === preg_match( '#^https?://[^\s/]#i', $target );
		if ( ! $valid || strlen( $target ) > 2048 ) {
			return new WP_Error( 'ww_redirect_invalid_target', __( 'Ongeldig doel: gebruik een pad dat met / begint of een URL met http(s)://.', 'webwerckt-base' ) );
		}

		// Een doel dat alleen een pad is (geen query of fragment) krijgt de vaste vorm (slashes, eindslash), maar behoudt zijn hoofdletters.
		if ( str_starts_with( $target, '/' ) && ! str_contains( $target, '?' ) && ! str_contains( $target, '#' ) ) {
			$target = _ww_redirect_normalize( $target, false ) ?? $target;
		}

		$internal = _ww_redirect_internal_path( $target );
		if ( null !== $internal && ( $internal === $source || ( 'prefix' === $match_type && str_starts_with( $internal, $source ) ) ) ) {
			return new WP_Error( 'ww_redirect_self', __( 'Het doel is gelijk aan de bron of valt erbinnen: dat stuurt eindeloos door.', 'webwerckt-base' ) );
		}
	}

	return array(
		'source'     => $source,
		'match_type' => $match_type,
		'target'     => $target,
		'status'     => $status,
		'origin'     => $origin,
		'post_id'    => $post_id,
	);
}

/**
 * Staan de cache-acties per opgeslagen regel uit? Een import zet dat uit en leegt de cache één keer na afloop, want elke
 * _ww_purge_path doorzoekt de hele paginacache.
 *
 * @param bool|null $set Met een waarde: onthoud die.
 */
function _ww_redirect_purge_suspend( ?bool $set = null ): bool {
	static $suspended = false;
	if ( null !== $set ) {
		$suspended = $set;
	}
	return $suspended;
}

/**
 * Slaat een redirectregel op: de enige schrijfweg, ook voor het scherm, de import, de ability en een gewijzigde slug.
 *
 * Valideert, weigert een regel naar zichzelf of in een kring, kort ketens in (het doel van de nieuwe regel en de
 * regels die naar de nieuwe bron wijzen), werkt een bestaande regel met dezelfde bron bij, haalt het pad uit het
 * 404-logboek en leegt de paginacache voor de bron (_ww_purge_path).
 *
 * @param array<string,mixed> $rule source, target, status (301), match_type (exact), origin (manual) en post_id (0).
 * @return int|WP_Error Id van de regel.
 */
function ww_redirect_save( array $rule ) {
	global $wpdb;

	if ( ! _ww_redirects_ready() ) {
		return new WP_Error( 'ww_redirect_not_ready', __( 'De redirecttabellen zijn nog niet aangelegd.', 'webwerckt-base' ) );
	}

	$valid = _ww_redirect_validate( $rule );
	if ( $valid instanceof WP_Error ) {
		return $valid;
	}
	$source     = $valid['source'];
	$match_type = $valid['match_type'];
	$target     = $valid['target'];
	$status     = $valid['status'];
	$origin     = $valid['origin'];
	$post_id    = $valid['post_id'];

	$existing = _ww_redirect_get_by_source( $source );
	if ( null !== $existing && 'slug' === $origin && 'slug' !== $existing->origin ) {
		error_log( sprintf( 'webwerckt-base: slug-redirect voor %s overgeslagen, er staat al een handmatige regel.', $source ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- bedoelde melding in het PHP-logboek.
		return new WP_Error( 'ww_redirect_slug_skipped', __( 'Een bestaande handmatige of geïmporteerde regel gaat voor een slug-regel.', 'webwerckt-base' ) );
	}
	// Zonder manage_options overschrijft een slug-regel geen slug-regel van een ander bericht (B2 van de audit).
	if ( null !== $existing && 'slug' === $origin && (int) $existing->post_id !== $post_id && ! _ww_redirect_may_override() ) {
		error_log( sprintf( 'webwerckt-base: slug-redirect voor %s overgeslagen, er staat al een regel van een ander bericht.', $source ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- bedoelde melding in het PHP-logboek.
		return new WP_Error( 'ww_redirect_slug_skipped', __( 'Een bestaande handmatige of geïmporteerde regel gaat voor een slug-regel.', 'webwerckt-base' ) );
	}

	if ( 410 !== $status ) {
		$final = _ww_redirect_final( $target, $source, $match_type );
		if ( $final['loop'] ) {
			return new WP_Error( 'ww_redirect_loop', __( 'Deze regel geeft een kring: het doel stuurt uiteindelijk terug naar de bron.', 'webwerckt-base' ) );
		}
		if ( 'prefix' === $match_type && _ww_redirect_prefix_loop_below_target( $source, $target, null === $existing ? 0 : (int) $existing->id ) ) {
			return new WP_Error( 'ww_redirect_loop', __( 'Deze regel geeft een kring: het doel stuurt uiteindelijk terug naar de bron.', 'webwerckt-base' ) );
		}
		if ( 410 === $final['status'] ) {
			$status = 410;
			$target = '';
		} else {
			$target = $final['target'];
		}
	}

	$data = array(
		'source'     => $source,
		'match_type' => $match_type,
		'target'     => $target,
		'status'     => $status,
		'origin'     => $origin,
		'post_id'    => $post_id,
	);
	$is_new  = null === $existing;
	$changed = $is_new || (string) $existing->target !== $target || (int) $existing->status !== $status || (string) $existing->match_type !== $match_type || (string) $existing->origin !== $origin || (int) $existing->post_id !== $post_id;
	if ( null !== $existing ) {
		$saved = $wpdb->update( _ww_redirects_table(), $data, array( 'id' => (int) $existing->id ) );
		$id    = (int) $existing->id;
	} else {
		$saved = $wpdb->insert( _ww_redirects_table(), $data + array( 'created' => gmdate( 'Y-m-d H:i:s' ) ) );
		$id    = (int) $wpdb->insert_id;
	}
	if ( false === $saved ) {
		return new WP_Error( 'ww_redirect_db', __( 'De regel kon niet worden opgeslagen.', 'webwerckt-base' ) );
	}

	// Regels die naar de nieuwe bron wijzen, gaan direct naar het nieuwe doel (alleen een gelijke bron, geen voorvoegsel).
	// Een exacte nieuwe regel dekt alleen exacte regels: een voorvoegselregel stuurt ook paden eronder door.
	$only_exact = 'exact' === $match_type ? " AND match_type = 'exact'" : '';
	// Een slug-regel van iemand zonder manage_options herschrijft alleen slug-regels: een handmatige of geïmporteerde
	// regel naar de oude URL blijft staan en loopt via de nieuwe regel door (B2 van de audit, beslissing 0031).
	if ( 'slug' === $origin && ! _ww_redirect_may_override() ) {
		$only_exact .= " AND origin = 'slug'";
	}
	$pointing = array_values( array_unique( array( $source, strtolower( home_url( $source ) ) ) ) );
	$in       = implode( ',', array_fill( 0, count( $pointing ), '%s' ) );
	if ( 410 === $status ) {
		$wpdb->query( $wpdb->prepare( 'UPDATE ' . _ww_redirects_table() . " SET target = '', status = 410 WHERE id <> %d$only_exact AND LOWER(target) IN ($in)", array_merge( array( $id ), $pointing ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- tabelnaam en placeholders zijn eigen waarden.
	} else {
		$wpdb->query( $wpdb->prepare( 'UPDATE ' . _ww_redirects_table() . " SET target = %s WHERE id <> %d$only_exact AND LOWER(target) IN ($in)", array_merge( array( $target, $id ), $pointing ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- tabelnaam en placeholders zijn eigen waarden.
	}

	// Het pad (bij een voorvoegsel alles eronder) hoort niet meer in het 404-logboek. Een voorvoegsel op / maakt het
	// hele logboek leeg: zo'n regel stuurt elke pagina door.
	_ww_404_log_forget( $source, $match_type );

	// De paginacache bewaart het pad zoals de bezoeker het vroeg, dus bij een submap-installatie met het pad van home_url().
	$home_path = untrailingslashit( strtolower( (string) wp_parse_url( home_url(), PHP_URL_PATH ) ) );
	if ( ! _ww_redirect_purge_suspend() ) {
		do_action( '_ww_purge_path', $home_path . $source, 'prefix' === $match_type );
	}

	// Een update die niets veranderde is geen gebeurtenis, ook al geeft de functie dan het id terug.
	if ( $changed ) {
		/**
		 * Een redirectregel is opgeslagen (aangemaakt of echt gewijzigd), ook door de import en de slug-redirect.
		 *
		 * Komt niet na een validatiefout, een overgeslagen slug-regel of een update zonder wijziging.
		 *
		 * @param int                 $id     Id van de regel.
		 * @param array<string,mixed> $rule   De opgeslagen regel: source, target, status (en match_type, origin, post_id).
		 * @param bool                $is_new True bij een nieuwe regel, false bij een bijgewerkte.
		 */
		do_action(
			'ww_redirect_saved',
			$id,
			array(
				'source'     => $source,
				'target'     => $target,
				'status'     => $status,
				'match_type' => $match_type,
				'origin'     => $origin,
				'post_id'    => $post_id,
			),
			$is_new
		);
	}

	return $id;
}

/**
 * Verwijdert een regel en zijn waarschuwingen. Een cache-actie is niet nodig: het pad gaf al geen pagina uit de cache.
 *
 * @param int $id Id van de regel.
 */
function ww_redirect_delete( int $id ): bool {
	global $wpdb;
	$source   = (string) $wpdb->get_var( $wpdb->prepare( 'SELECT source FROM ' . _ww_redirects_table() . ' WHERE id = %d', $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_redirects_table().
	$deleted  = (int) $wpdb->delete( _ww_redirects_table(), array( 'id' => $id ) ) > 0;
	// De waarschuwingen van het scherm horen bij de regel; elke verwijderweg ruimt ze op.
	delete_transient( 'ww_redirect_warn_' . $id );
	delete_transient( 'ww_redirect_warn_posts_' . $id );
	if ( $deleted ) {
		/**
		 * Een redirectregel is echt verwijderd.
		 *
		 * @param int    $id     Id van de regel.
		 * @param string $source De bron van de verwijderde regel.
		 */
		do_action( 'ww_redirect_deleted', $id, $source );
	}
	return $deleted;
}

/**
 * Wat er met een verzoek moet gebeuren: de status, de volledige bestemming en het id van de regel, of null als er
 * geen regel geldt. Puur: geen headers en geen tellers.
 *
 * Het pad van het verzoek wordt genormaliseerd (kleine letters, zonder query). Een pad als doel krijgt home_url()
 * ervoor, een volledige URL blijft zoals hij is, en heeft het doel geen query-string dan gaat die van het verzoek mee.
 * Het filter ww_redirect krijgt array( 'rule' => object, 'target' => string ) en de REQUEST_URI; het mag beide
 * wijzigen of null teruggeven om niet door te sturen. Bij een 410 is het doel leeg.
 *
 * @param string $request_uri REQUEST_URI, met eventuele query-string.
 * @return array{status:int,location:string,id:int}|null
 */
function _ww_redirect_resolve( string $request_uri ): ?array {
	if ( ! _ww_redirects_ready() ) {
		return null;
	}

	$path = _ww_redirect_normalize( $request_uri, true, false );
	if ( null === $path ) {
		return null;
	}
	$rule = _ww_redirect_match( $path );
	if ( null === $rule ) {
		return null;
	}

	$location = '';
	if ( 410 !== (int) $rule->status ) {
		$location = _ww_redirect_target_with_rest( $rule, $path );
		if ( str_starts_with( $location, '/' ) ) {
			// home_url() zonder pad: het doel is een pad op de site zoals het is ingevuld, zonder het voorvoegsel van
			// de huidige taal dat home_url( $pad ) op de voorkant krijgt (inc/languages-links.php).
			$location = untrailingslashit( home_url() ) . $location;
		}
		$query = (string) wp_parse_url( $request_uri, PHP_URL_QUERY );
		if ( '' !== $query ) {
			$hash     = strpos( $location, '#' );
			$fragment = false === $hash ? '' : substr( $location, $hash );
			$before   = false === $hash ? $location : substr( $location, 0, $hash );
			if ( ! str_contains( $before, '?' ) ) {
				$location = $before . '?' . $query . $fragment;
			}
		}
	}

	$filtered = apply_filters(
		'ww_redirect',
		array(
			'rule'   => $rule,
			'target' => $location,
		),
		$request_uri
	);
	if ( ! is_array( $filtered ) || ! isset( $filtered['rule'] ) || ! is_object( $filtered['rule'] ) ) {
		return null;
	}

	return array(
		'status'   => (int) $filtered['rule']->status,
		'location' => (string) ( $filtered['target'] ?? '' ),
		'id'       => (int) $filtered['rule']->id,
	);
}

/**
 * Was dit verzoek een 410 van een redirectregel? Het 404-logboek logt zo'n verzoek niet.
 *
 * @param bool|null $set Met een waarde: onthoud die (alleen voor _ww_redirect_maybe).
 */
function _ww_redirect_was_410( ?bool $set = null ): bool {
	static $was = false;
	if ( null !== $set ) {
		$was = $set;
	}
	return $was;
}

/**
 * Is dit een gewoon GET- of HEAD-verzoek aan de voorkant? Niet voor beheer, REST, cron, feeds, voorbeelden,
 * embeds en de visuele editor. Gedeeld door de redirects en het 404-logboek.
 */
function _ww_redirect_is_frontend_request(): bool {
	$method = isset( $_SERVER['REQUEST_METHOD'] ) ? _ww_data_to_string( $_SERVER['REQUEST_METHOD'] ) : '';
	if ( ! in_array( $method, array( 'GET', 'HEAD' ), true ) ) {
		return false;
	}
	if ( is_admin() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || wp_doing_cron() || is_feed() || is_preview() || is_embed() ) {
		return false;
	}
	return 0 === _ww_editor_post_id() && '' === _ww_editor_view();
}

/**
 * Stuurt het verzoek door of geeft een 410, als er een regel voor het pad is (template_redirect, prioriteit 1).
 *
 * Alleen GET en HEAD aan de voorkant. Een 410 gebruikt de gewone 404-pagina, en redirect_canonical gaat uit zodat de
 * 404-gok van WordPress een bewust verwijderde URL niet alsnog doorstuurt.
 */
function _ww_redirect_maybe(): void {
	_ww_redirect_was_410( false );

	if ( ! _ww_redirect_is_frontend_request() ) {
		return;
	}

	$uri = isset( $_SERVER['REQUEST_URI'] ) ? _ww_data_to_string( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- het pad wordt genormaliseerd en alleen vergeleken met opgeslagen bronnen; %-codes moeten blijven.
	$hit = '' === $uri ? null : _ww_redirect_resolve( $uri );
	if ( null === $hit ) {
		return;
	}

	do_action( 'ww_cacheable', false, 'ww redirect' );

	global $wpdb;
	$now = gmdate( 'Y-m-d H:i:s' );
	$wpdb->query( $wpdb->prepare( 'UPDATE ' . _ww_redirects_table() . ' SET hits = hits + 1, last_hit = IF(last_hit IS NULL OR last_hit < %s, %s, last_hit) WHERE id = %d', gmdate( 'Y-m-d H:i:s', time() - 60 ), $now, $hit['id'] ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_redirects_table().

	if ( 410 === $hit['status'] ) {
		global $wp_query;
		_ww_redirect_was_410( true );
		remove_action( 'template_redirect', 'redirect_canonical' );
		remove_action( 'template_redirect', 'wp_old_slug_redirect' );
		$wp_query->set_404();
		status_header( 410 );
		nocache_headers();
		return;
	}

	if ( wp_redirect( $hit['location'], $hit['status'], 'webwerckt-base' ) ) { // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- het doel is door de beheerder ingevoerd en mag een andere host zijn.
		exit;
	}
}
add_action( 'template_redirect', '_ww_redirect_maybe', 1 );

/**
 * Bewaart of geeft de permalink van een bericht van vóór de wijziging.
 *
 * @param int         $post_id Bericht.
 * @param string|null $set     Met een waarde: bewaar die permalink.
 * @param bool        $take    Geef de bewaarde permalink en vergeet hem.
 */
function _ww_redirect_old_permalinks( int $post_id, ?string $set = null, bool $take = false ): ?string {
	static $list = array();
	if ( null !== $set ) {
		$list[ $post_id ] = $set;
		return null;
	}
	$old = $list[ $post_id ] ?? null;
	if ( $take ) {
		unset( $list[ $post_id ] );
	}
	return $old;
}

/**
 * Onthoudt de permalink van een gepubliceerd bericht vóór het bijwerken (pre_post_update).
 *
 * @param int $post_id Bericht.
 */
function _ww_redirect_remember_permalink( int $post_id ): void {
	$post = get_post( $post_id );
	if ( ! $post instanceof WP_Post || 'publish' !== $post->post_status || ! is_post_type_viewable( $post->post_type ) ) {
		return;
	}
	$url = get_permalink( $post );
	_ww_redirect_old_permalinks( $post_id, $url );
}
add_action( 'pre_post_update', '_ww_redirect_remember_permalink' );

/**
 * Meldt een mislukte slug-regel in het PHP-logboek (een overgeslagen regel meldt zichzelf al).
 *
 * @param int|WP_Error $result Uitkomst van ww_redirect_save().
 */
function _ww_redirect_log_slug_error( $result ): void {
	if ( $result instanceof WP_Error && 'ww_redirect_slug_skipped' !== $result->get_error_code() ) {
		error_log( 'webwerckt-base: slug-redirect niet opgeslagen: ' . $result->get_error_message() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- bedoelde melding in het PHP-logboek.
	}
}

/**
 * Maakt een redirect van de oude naar de nieuwe URL als de permalink van een gepubliceerd bericht is veranderd
 * (post_updated en wp_after_insert_post: de eerste die de bewaarde permalink vindt, doet het werk).
 *
 * @param int $post_id Bericht.
 */
function _ww_redirect_on_post_change( int $post_id ): void {
	$old_url = _ww_redirect_old_permalinks( $post_id, null, true );
	if ( null === $old_url || ! _ww_redirects_ready() ) {
		return;
	}

	$post = get_post( $post_id );
	if ( ! $post instanceof WP_Post || 'publish' !== $post->post_status || ! is_post_type_viewable( $post->post_type ) ) {
		return;
	}
	if ( 'page' === $post->post_type && in_array( $post_id, array( (int) get_option( 'page_on_front' ), (int) get_option( 'page_for_posts' ) ), true ) ) {
		return;
	}

	$new_url = get_permalink( $post );
	$old     = _ww_redirect_normalize( $old_url );
	$new     = _ww_redirect_normalize( $new_url );
	if ( null === $old || null === $new || $old === $new ) {
		return;
	}

	// Een echte pagina gaat voor, ook als het filter het aanmaken van een redirect uitzet.
	_ww_redirect_release_source( $post_id );
	_ww_redirect_warn_if_covered( $post_id );

	/**
	 * Zet het automatisch aanmaken van een redirect bij een gewijzigde URL uit.
	 *
	 * @param bool    $enabled Standaard true.
	 * @param WP_Post $post    Het bericht.
	 * @param string  $old_url De oude URL.
	 * @param string  $new_url De nieuwe URL.
	 */
	if ( ! apply_filters( 'ww_redirect_on_slug_change', true, $post, $old_url, $new_url ) ) {
		return;
	}

	// Leidt de oude URL nog naar iets anders (een pagina met dezelfde slug, een archief, de berichtenpagina), dan was
	// hij niet van dit bericht: een regel zou die pagina kapen (B2 van de audit).
	if ( _ww_redirect_url_taken( $old_url, $post_id ) ) {
		return;
	}

	if ( is_post_type_hierarchical( $post->post_type ) ) {
		// Een exacte regel van /nieuw/… naar /oud/… zou met de voorvoegselregel een kring geven: die gaat weg, de pagina's staan er nu echt.
		_ww_redirect_release_below( $new, $old );
	}

	_ww_redirect_log_slug_error(
		ww_redirect_save(
			array(
				'source'     => $old,
				'target'     => $new,
				'status'     => 301,
				'match_type' => is_post_type_hierarchical( $post->post_type ) ? 'prefix' : 'exact',
				'origin'     => 'slug',
				'post_id'    => $post_id,
			)
		)
	);
}
add_action( 'post_updated', '_ww_redirect_on_post_change' );
add_action( 'wp_after_insert_post', '_ww_redirect_on_post_change' );

/**
 * Verwijdert de exacte regels waarvan de bron onder $new valt en het doel onder $old (als pad of volledige URL). Wie
 * geen manage_options heeft, verwijdert alleen slug-regels.
 *
 * @param string $new Genormaliseerd nieuw pad van een hiërarchisch bericht.
 * @param string $old Genormaliseerd oud pad.
 */
function _ww_redirect_release_below( string $new, string $old ): void {
	global $wpdb;
	$targets = array_values( array_unique( array( $old, strtolower( home_url( $old ) ) ) ) );
	$likes   = array_map( static fn( string $t ): string => $wpdb->esc_like( $t ) . '%', $targets );
	$or      = implode( ' OR ', array_fill( 0, count( $likes ), 'LOWER(target) LIKE %s' ) );
	// Zonder manage_options alleen slug-regels: handmatige en geïmporteerde regels zijn van de beheerder (B12 van de audit).
	$origin = _ww_redirect_may_override() ? '' : " AND origin = 'slug'";
	$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . _ww_redirects_table() . " WHERE match_type = 'exact'$origin AND source LIKE %s AND ($or)", array_merge( array( $wpdb->esc_like( $new ) . '%' ), $likes ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- tabelnaam en placeholders zijn eigen waarden.
}

/**
 * Een echte pagina gaat voor: verwijdert de exacte regel op de permalink van het bericht, en een slug-regel van het
 * bericht zelf (exact of voorvoegsel, zodat terughernoemen werkt). Een voorvoegselregel van een ander blijft staan.
 *
 * Een handmatige of geïmporteerde exacte regel verwijdert alleen wie manage_options heeft: het scherm Redirects is
 * van de beheerder. Bij een ander (een Auteur die op die URL publiceert) blijft de regel staan en krijgt hij een
 * waarschuwing in het scherm (B12 van de audit, beslissing 0031).
 *
 * @param int $post_id Bericht.
 */
function _ww_redirect_release_source( int $post_id ): void {
	if ( ! _ww_redirects_ready() ) {
		return;
	}
	$post = get_post( $post_id );
	if ( ! $post instanceof WP_Post || ! is_post_type_viewable( $post->post_type ) ) {
		return;
	}
	$url    = get_permalink( $post );
	$source = _ww_redirect_normalize( $url );
	if ( null === $source ) {
		return;
	}
	$rule = _ww_redirect_get_by_source( $source );
	if ( null === $rule ) {
		return;
	}
	$own_slug = 'slug' === $rule->origin && (int) $rule->post_id === $post_id;
	if ( $own_slug || ( 'exact' === $rule->match_type && ( 'slug' === $rule->origin || _ww_redirect_may_override() ) ) ) {
		ww_redirect_delete( (int) $rule->id );
	} elseif ( 'exact' === $rule->match_type ) {
		set_transient( 'ww_redirect_warn_posts_' . (int) $rule->id, '1', WEEK_IN_SECONDS );
	}
}

/**
 * Mag de huidige gebruiker via een bericht handmatige en geïmporteerde regels verwijderen of herschrijven? Alleen met
 * manage_options, het recht van het scherm Redirects. Een geplande publicatie (cron, geen gebruiker) mag het ook niet.
 */
function _ww_redirect_may_override(): bool {
	return current_user_can( 'manage_options' );
}

/**
 * Leidt deze URL naar een ander object dan het bericht: een ander bericht of een pagina (ook de berichtenpagina), of
 * het archief van een post type? Dan hoort de URL niet bij het bericht, ook al gaf get_permalink() hem: WordPress
 * laat een bericht dezelfde slug hebben als een pagina, en de pagina wint de routering.
 *
 * @param string $url     Volledige URL.
 * @param int    $post_id Het bericht.
 */
function _ww_redirect_url_taken( string $url, int $post_id ): bool {
	$other = url_to_postid( $url );
	if ( $other > 0 && $other !== $post_id ) {
		return true;
	}
	$path = _ww_redirect_normalize( $url );
	// De berichtenpagina is voor url_to_postid() geen los bericht (geen is_singular), dus apart.
	$posts_page = (int) get_option( 'page_for_posts' );
	if ( null !== $path && $posts_page > 0 && $posts_page !== $post_id && _ww_redirect_normalize( (string) get_permalink( $posts_page ) ) === $path ) {
		return true;
	}
	foreach ( get_post_types( array( 'has_archive' => true ) ) as $post_type ) {
		$archive = get_post_type_archive_link( $post_type );
		if ( null !== $path && is_string( $archive ) && _ww_redirect_normalize( $archive ) === $path ) {
			return true;
		}
	}
	return false;
}

/**
 * Waarschuwt (voor het scherm Redirects) als een voorvoegselregel de permalink van een bericht dekt: de pagina is dan
 * niet te bereiken. Zet dezelfde transient als _ww_redirects_check_prefix(), een week.
 *
 * @param int $post_id Bericht.
 */
function _ww_redirect_warn_if_covered( int $post_id ): void {
	$post = get_post( $post_id );
	if ( ! $post instanceof WP_Post || 'publish' !== $post->post_status || ! is_post_type_viewable( $post->post_type ) ) {
		return;
	}
	$path = _ww_redirect_normalize( (string) get_permalink( $post ) );
	if ( null === $path ) {
		return;
	}
	$rule = _ww_redirect_match( $path, true );
	if ( null !== $rule && '/' !== $rule->source ) {
		set_transient( 'ww_redirect_warn_posts_' . (int) $rule->id, '1', WEEK_IN_SECONDS );
	}
}

/**
 * Bij het publiceren van een bericht gaat het voor op een regel op zijn URL (transition_post_status).
 *
 * @param string  $new_status Nieuwe status.
 * @param string  $old_status Oude status.
 * @param WP_Post $post       Het bericht.
 */
function _ww_redirect_on_publish( string $new_status, string $old_status, WP_Post $post ): void {
	if ( 'publish' === $new_status && 'publish' !== $old_status ) {
		_ww_redirect_release_source( $post->ID );
		_ww_redirect_warn_if_covered( $post->ID );
	}
}
add_action( 'transition_post_status', '_ww_redirect_on_publish', 10, 3 );
