<?php
/**
 * Meertalig afronding (beslissing 0044), onderdeel sitemap: een sitemap per zichtbare taal, de regels in robots.txt en
 * de taalvoorwaarde in de query's van de sitemap.
 *
 * De sitemap van WordPress draait per taal via de routing van de kern: /en/wp-sitemap.xml en alles daaronder verliest
 * zijn voorvoegsel bij het parsen, de query's filteren op de taal van het verzoek en de links krijgen het voorvoegsel.
 * /wp-sitemap.xml blijft de standaardtaal. Een verborgen taal heeft voor een bezoeker geen voorvoegsel, dus
 * /en/wp-sitemap.xml geeft dan een 404. De stylesheet blijft die van de standaardtaal (/wp-sitemap.xsl): die is in elke
 * taal gelijk.
 *
 * Met een SEO-plugin (_ww_seo_enabled() false) doet dit onderdeel niets; de plugin regelt dan de sitemap.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * De adressen van de sitemap-index per taal: taalcode => URL, de standaardtaal eerst, daarna de zichtbare extra talen.
 * Uit het ruwe adres van de site (_ww_languages_home()), nooit uit het gefilterde home_url(). Zonder module, naast een
 * SEO-plugin of met de sitemap van WordPress uit array().
 *
 * @return array<string,string>
 */
function _ww_languages_sitemap_urls(): array {
	if ( ! _ww_languages_active() || ! _ww_seo_enabled() || ! wp_sitemaps_get_server()->sitemaps_enabled() ) {
		return array();
	}
	$urls = array();
	foreach ( array_merge( array( _ww_default_language() ), _ww_visible_language_codes() ) as $code ) {
		$urls[ $code ] = _ww_languages_home( $code ) . 'wp-sitemap.xml';
	}
	return $urls;
}

/**
 * Filter robots_txt: per zichtbare extra taal een regel Sitemap, onder die van WordPress (prioriteit 0). Niet in de
 * index van de standaardtaal: een sitemap-index mag geen andere index bevatten.
 *
 * Geen tekst (een ander filter gaf iets anders terug): dan blijft de waarde ongewijzigd.
 *
 * @param mixed $output Inhoud van robots.txt.
 * @param mixed $public Of de site zichtbaar is voor zoekmachines (blog_public; WordPress geeft '1' of '0').
 * @return mixed
 */
function _ww_languages_robots_txt( mixed $output, mixed $public ): mixed {
	if ( ! is_string( $output ) || ! $public ) {
		return $output;
	}
	$urls = _ww_languages_sitemap_urls();
	unset( $urls[ _ww_default_language() ] );
	if ( array() === $urls ) {
		return $output;
	}
	$lines = '';
	foreach ( $urls as $url ) {
		$lines .= 'Sitemap: ' . esc_url( $url ) . "\n";
	}
	// Een regeleinde ervoor alleen als de uitvoer (van WordPress of een ander filter) er niet al mee eindigt.
	return ( '' === $output || str_ends_with( $output, "\n" ) ? $output : $output . "\n" ) . $lines;
}

/**
 * Filter wp_sitemaps_posts_query_args: de taalvoorwaarde van de taal van het verzoek, ook waar het query-filter van de
 * kern niet draait. Het opwarmen (inc/page-cache-preload.php) leest de sitemap vanuit cron en de admin, en daar slaat
 * _ww_languages_pre_get_posts() over; zonder deze voorwaarde stonden er berichten van elke taal in, ook van een
 * verborgen taal. Op de voorkant doet hij hetzelfde als het query-filter, dat een bestaande taalvoorwaarde respecteert.
 *
 * @param mixed $args      Argumenten van de WP_Query.
 * @param mixed $post_type Post type van deze sitemap.
 * @return mixed
 */
function _ww_languages_sitemap_query_args( mixed $args, mixed $post_type = '' ): mixed {
	if ( ! is_array( $args ) || ! is_string( $post_type ) || ! _ww_seo_enabled() || ! _ww_is_translatable( $post_type ) ) {
		return $args;
	}
	$tax_query = $args['tax_query'] ?? array();
	if ( _ww_languages_has_language_clause( $tax_query ) ) {
		return $args;
	}
	$clauses = array( 'relation' => 'AND' );
	if ( is_array( $tax_query ) && array() !== $tax_query ) {
		$clauses[] = $tax_query;
	}
	$clauses[]         = _ww_languages_tax_query( _ww_languages_request_language() );
	$args['tax_query'] = $clauses; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- de taal hoort bij de sitemap.
	return $args;
}

/**
 * Filter wp_sitemaps_index_entry: de subsitemaps in de index van een extra taal met het voorvoegsel. WordPress bouwt ze
 * met home_url( '/wp-sitemap-….xml' ), en het filter home_url van de kern laat een pad met een bestand zonder voorvoegsel.
 *
 * @param mixed $entry Regel van de index (loc, eventueel lastmod).
 * @return mixed
 */
function _ww_languages_sitemap_index_entry( mixed $entry ): mixed {
	if ( ! is_array( $entry ) || ! isset( $entry['loc'] ) || ! is_string( $entry['loc'] ) || ! _ww_seo_enabled() ) {
		return $entry;
	}
	$entry['loc'] = _ww_languages_relink( $entry['loc'], _ww_languages_request_language() );
	return $entry;
}

/**
 * Hangt de hooks van dit onderdeel op. Draait ook na init (zie _ww_languages_boot()). Met alleen de standaardtaal is er
 * geen tweede sitemap.
 */
function _ww_languages_boot_sitemap(): void {
	if ( array() === _ww_extra_language_codes() ) {
		return;
	}
	add_filter( 'robots_txt', '_ww_languages_robots_txt', 10, 2 );
	add_filter( 'wp_sitemaps_posts_query_args', '_ww_languages_sitemap_query_args', 10, 2 );
	add_filter( 'wp_sitemaps_index_entry', '_ww_languages_sitemap_index_entry' );
}
