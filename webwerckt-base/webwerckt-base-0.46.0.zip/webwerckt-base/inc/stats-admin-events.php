<?php
/**
 * Statistieken: de tabbladen Kliks en Formulieren.
 *
 * Leest de lijsten click en form uit _ww_stats_query() en toont ze als tabel; op smalle schermen worden de rijen kaarten.
 *
 * @package webwerckt-base
 */

defined( 'ABSPATH' ) || exit;

/**
 * Het gekozen klikfilter uit de URL: leeg (alle) of tel, mailto, download, extern, intern, knop. Alles anders is leeg.
 *
 * @param array<string,mixed> $query Uit _ww_stats_admin_query().
 */
function _ww_stats_click_kind( array $query ): string {
	$kind = $query['kind'] ?? '';
	return is_string( $kind ) && in_array( $kind, array( 'tel', 'mailto', 'download', 'extern', 'intern', 'knop' ), true ) ? $kind : '';
}

/**
 * De naam van een klikSoort, in de tabel (enkelvoud) of op de filterknop (meervoud).
 *
 * @param string $kind   Leeg of een soort.
 * @param bool   $plural Meervoud voor de filterknoppen (Downloads, Knoppen).
 */
function _ww_stats_click_kind_label( string $kind, bool $plural = false ): string {
	switch ( $kind ) {
		case 'tel':
			return __( 'Bellen', 'webwerckt-base' );
		case 'mailto':
			return __( 'Mail', 'webwerckt-base' );
		case 'download':
			return $plural ? __( 'Downloads', 'webwerckt-base' ) : __( 'Download', 'webwerckt-base' );
		case 'extern':
			return __( 'Extern', 'webwerckt-base' );
		case 'intern':
			return __( 'Intern', 'webwerckt-base' );
		case 'knop':
			return $plural ? __( 'Knoppen', 'webwerckt-base' ) : __( 'Knop', 'webwerckt-base' );
	}
	return '';
}

/**
 * Het tabblad Kliks: filterknoppen en een tabel met Tekst, Doel, Soort, Kliks en Bezoekers.
 * De eerste 25 regels staan open, regel 26 tot 100 achter "Meer tonen". (overige) staat alleen onder Alle.
 *
 * @param array<string,string> $period Uit _ww_stats_period().
 * @param array<string,mixed>  $query  Uit _ww_stats_admin_query().
 */
function _ww_stats_render_clicks( array $period, array $query ): void {
	$kind  = _ww_stats_click_kind( $query );
	$lists = _ww_stats_query( $period['from'], $period['to'] )['lists'];

	$intro   = '<p class="ww-stats-filters" role="group" aria-label="' . esc_attr__( 'Soort klik', 'webwerckt-base' ) . '">';
	$filters = array(
		''         => __( 'Alle', 'webwerckt-base' ),
		'tel'      => _ww_stats_click_kind_label( 'tel', true ),
		'mailto'   => _ww_stats_click_kind_label( 'mailto', true ),
		'download' => _ww_stats_click_kind_label( 'download', true ),
		'extern'   => _ww_stats_click_kind_label( 'extern', true ),
		'intern'   => _ww_stats_click_kind_label( 'intern', true ),
		'knop'     => _ww_stats_click_kind_label( 'knop', true ),
	);
	foreach ( $filters as $key => $label ) {
		$key     = (string) $key;
		$current = $key === $kind;
		$url     = _ww_stats_tab_url( $period, 'clicks', '' !== $key ? array( 'kind' => $key ) : array() );
		$intro  .= '<a href="' . esc_url( $url ) . '" class="button' . ( $current ? ' button-primary' : '' ) . '"' . ( $current ? ' aria-current="page"' : '' ) . '>' . esc_html( $label ) . '</a> ';
	}
	$intro .= '</p>';

	$rows = array();
	foreach ( $lists['click'] ?? array() as $entry ) {
		$parts = _ww_stats_click_parts( $entry['item'] );
		if ( '' !== $kind && $parts['kind'] !== $kind ) {
			continue;
		}
		if ( '(overige)' === $entry['item'] ) {
			$text = __( 'Overige', 'webwerckt-base' );
		} else {
			$text = '' !== trim( $parts['label'] ) ? $parts['label'] : __( '(zonder tekst)', 'webwerckt-base' );
		}
		$rows[] = array(
			esc_html( $text ),
			esc_html( $parts['target'] ),
			esc_html( _ww_stats_click_kind_label( $parts['kind'] ) ),
			esc_html( number_format_i18n( $entry['views'] ) ),
			esc_html( number_format_i18n( $entry['visitors'] ) ),
		);
	}

	$headers = array(
		__( 'Tekst', 'webwerckt-base' ),
		__( 'Doel', 'webwerckt-base' ),
		__( 'Soort', 'webwerckt-base' ),
		__( 'Kliks', 'webwerckt-base' ),
		__( 'Bezoekers', 'webwerckt-base' ),
	);
	echo _ww_stats_block( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_stats_block() en de cellen zijn geëscapet.
		__( 'Kliks', 'webwerckt-base' ),
		$headers,
		$rows,
		array(
			'open'     => 25,
			'cards'    => true,
			'num_from' => 3,
			'intro'    => $intro,
			'empty'    => __( 'Nog geen kliks gemeten in deze periode.', 'webwerckt-base' ),
		)
	);
}

/**
 * De titel van een formulier, anders "Formulier #ID". Alleen de titel van een echt formulier (WW_FORM_POST_TYPE): het
 * ID komt uit de browser en kan van elk bericht zijn.
 *
 * @param int $id Formulier-ID.
 */
function _ww_stats_form_title( int $id ): string {
	$title = WW_FORM_POST_TYPE === get_post_type( $id ) ? trim( get_the_title( $id ) ) : '';
	if ( '' === $title ) {
		/* translators: %d: ID van het formulier. */
		$title = sprintf( __( 'Formulier #%d', 'webwerckt-base' ), $id );
	}
	return $title;
}

/**
 * Zet de lijst form (sleutels formId|view, formId|start, formId|sent, formId|step|n) om naar een trechter per formulier.
 * Gezien, begonnen en verstuurd zijn het aantal gebeurtenissen (views); per stap het aantal bezoekers dat die stap
 * bereikte, en start_visitors het aantal bezoekers dat begon: de basis van de stapbalken, zodat die in één eenheid
 * (bezoekers) rekenen. Gesorteerd op verstuurd, aflopend; bij gelijke stand het formulier met de meeste weergaven eerst.
 *
 * @param array<int,array{item:string,views:int,visitors:int}> $form_list Lijst form uit _ww_stats_query().
 * @return array<int,array{view:int,start:int,sent:int,steps:array<int,int>,start_visitors:int}> Per formulier-ID.
 */
function _ww_stats_form_funnel( array $form_list ): array {
	$forms = array();
	foreach ( $form_list as $entry ) {
		$bits = explode( '|', $entry['item'] );
		$valid = ctype_digit( $bits[0] ) && (int) $bits[0] > 0 && isset( $bits[1] ) && (
			( 2 === count( $bits ) && in_array( $bits[1], array( 'view', 'start', 'sent' ), true ) )
			|| ( 3 === count( $bits ) && 'step' === $bits[1] && ctype_digit( $bits[2] ) )
		);
		if ( ! $valid ) {
			continue; // (overige) en onbekende of onvolledige sleutels.
		}
		$id = (int) $bits[0];
		if ( ! isset( $forms[ $id ] ) ) {
			$forms[ $id ] = array(
				'view'           => 0,
				'start'          => 0,
				'sent'           => 0,
				'steps'          => array(),
				'start_visitors' => 0,
			);
		}
		if ( 'step' === $bits[1] ) {
			$forms[ $id ]['steps'][ (int) $bits[2] ] = $entry['visitors'];
		} else {
			$forms[ $id ][ $bits[1] ] = $entry['views'];
			if ( 'start' === $bits[1] ) {
				$forms[ $id ]['start_visitors'] = $entry['visitors'];
			}
		}
	}
	foreach ( $forms as $id => $form ) {
		ksort( $form['steps'] );
		$forms[ $id ] = $form;
	}
	uasort(
		$forms,
		static function ( array $a, array $b ): int {
			return array( $b['sent'], $b['view'] ) <=> array( $a['sent'], $a['view'] );
		}
	);
	return $forms;
}

/**
 * Het tabblad Formulieren: per formulier gezien, begonnen, verstuurd en conversie, met bij stappen een trechter.
 *
 * @param array<string,string> $period Uit _ww_stats_period().
 * @param array<string,mixed>  $query  Uit _ww_stats_admin_query(); dit tabblad gebruikt het niet.
 */
function _ww_stats_render_forms( array $period, array $query ): void { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed -- zelfde aanroep als _ww_stats_render_clicks().
	$lists   = _ww_stats_query( $period['from'], $period['to'] )['lists'];
	$funnels = _ww_stats_form_funnel( $lists['form'] ?? array() );

	$rows = array();
	foreach ( $funnels as $id => $form ) {
		$name = esc_html( _ww_stats_form_title( (int) $id ) );
		if ( array() !== $form['steps'] ) {
			$bars = '';
			foreach ( $form['steps'] as $step => $visitors ) {
				$share = $form['start_visitors'] > 0 ? min( 100, (int) round( $visitors / $form['start_visitors'] * 100 ) ) : 0;
				/* translators: %d: nummer van de stap. */
				$label = sprintf( __( 'Stap %d', 'webwerckt-base' ), $step );
				$bars .= '<li><span class="ww-stats-step__label">' . esc_html( $label ) . '</span>'
					. '<span class="ww-stats-step__bar" aria-hidden="true"><span style="width:' . $share . '%"></span></span>'
					. '<span class="ww-stats-step__value">' . esc_html( number_format_i18n( $visitors ) . ' (' . _ww_stats_format_share( $visitors, $form['start_visitors'] ) . ')' ) . '</span></li>';
			}
			$name .= '<details class="ww-stats-steps"><summary>' . esc_html__( 'Stappen', 'webwerckt-base' ) . '</summary><ol>' . $bars . '</ol></details>';
		}
		$rows[] = array(
			$name,
			esc_html( number_format_i18n( $form['view'] ) ),
			esc_html( number_format_i18n( $form['start'] ) ),
			esc_html( number_format_i18n( $form['sent'] ) ),
			esc_html( $form['view'] > 0 ? _ww_stats_format_share( $form['sent'], $form['view'] ) : '–' ),
		);
	}

	$headers = array(
		__( 'Formulier', 'webwerckt-base' ),
		__( 'Gezien', 'webwerckt-base' ),
		__( 'Begonnen', 'webwerckt-base' ),
		__( 'Verstuurd', 'webwerckt-base' ),
		__( 'Conversie', 'webwerckt-base' ),
	);
	echo _ww_stats_block( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_stats_block() en de cellen zijn geëscapet.
		__( 'Formulieren', 'webwerckt-base' ),
		$headers,
		$rows,
		array(
			'open'  => 25,
			'cards' => true,
			'outro' => '<p class="description">' . esc_html__( 'Gemeten in de browser, dus een ondergrens. Het echte aantal inzendingen staat bij Formulieren.', 'webwerckt-base' ) . '</p>',
			'empty' => __( 'Nog geen formulieren gezien in deze periode.', 'webwerckt-base' ),
		)
	);
}
