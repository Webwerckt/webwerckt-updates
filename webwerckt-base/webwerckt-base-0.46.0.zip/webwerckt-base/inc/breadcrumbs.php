<?php
/**
 * Breadcrumbs: het pad van de homepage naar de huidige pagina, als data. Het child-thema maakt de HTML; het schema
 * (inc/schema.php) maakt er een BreadcrumbList van. Beide gebruiken _ww_breadcrumb_trail(), dus ze lopen nooit uiteen.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Een stap in het pad, met platte tekst en een URL die nog niet ge-escaped zijn.
 *
 * @return array{label:string,url:string}
 */
function _ww_breadcrumb( string $label, string $url ): array {
	return array(
		'label' => _ww_plain_text( $label ),
		'url'   => $url,
	);
}

/**
 * Een bericht als stap.
 *
 * @return array{label:string,url:string}
 */
function _ww_breadcrumb_post( int $post_id ): array {
	return _ww_breadcrumb( get_the_title( $post_id ), (string) get_permalink( $post_id ) );
}

/**
 * De bovenliggende berichten van een bericht, de bovenste eerst.
 *
 * @return array<int,array{label:string,url:string}>
 */
function _ww_breadcrumb_ancestors( int $post_id ): array {
	return array_map( '_ww_breadcrumb_post', array_reverse( array_map( 'intval', get_post_ancestors( $post_id ) ) ) );
}

/**
 * De berichtenpagina als stap, als die bestaat en niet ook de homepage is.
 *
 * @return array<int,array{label:string,url:string}>
 */
function _ww_breadcrumb_posts_page(): array {
	$page = _ww_posts_page_id();
	return 0 === $page ? array() : array( _ww_breadcrumb_post( $page ) );
}

/**
 * Het overzicht van een post type als stap: de berichtenpagina voor berichten, het archief voor een post type met
 * een archief. Anders geen stap.
 *
 * @return array<int,array{label:string,url:string}>
 */
function _ww_breadcrumb_post_type( string $post_type ): array {
	if ( 'post' === $post_type ) {
		return _ww_breadcrumb_posts_page();
	}
	$type = get_post_type_object( $post_type );
	$url  = $type instanceof WP_Post_Type && $type->has_archive ? get_post_type_archive_link( $post_type ) : false;
	if ( ! $type instanceof WP_Post_Type || ! is_string( $url ) ) {
		return array();
	}
	return array( _ww_breadcrumb( (string) apply_filters( 'post_type_archive_title', $type->labels->name, $post_type ), $url ) );
}

/**
 * Een term met zijn bovenliggende termen, na het overzicht van het post type waar de taxonomie bij hoort.
 *
 * @return array<int,array{label:string,url:string}>
 */
function _ww_breadcrumb_term( WP_Term $term ): array {
	$taxonomy = get_taxonomy( $term->taxonomy );
	$trail    = $taxonomy instanceof WP_Taxonomy && isset( $taxonomy->object_type[0] ) ? _ww_breadcrumb_post_type( $taxonomy->object_type[0] ) : array();
	$terms    = array_reverse( array_map( 'intval', get_ancestors( $term->term_id, $term->taxonomy, 'taxonomy' ) ) );
	$terms[]  = $term->term_id;
	foreach ( $terms as $term_id ) {
		$item = get_term( $term_id, $term->taxonomy );
		$link = $item instanceof WP_Term ? get_term_link( $item ) : '';
		if ( $item instanceof WP_Term && is_string( $link ) ) {
			$trail[] = _ww_breadcrumb( $item->name, $link );
		}
	}
	return $trail;
}

/**
 * De stappen na Home voor de huidige pagina.
 *
 * @return array<int,array{label:string,url:string}>
 */
function _ww_breadcrumb_steps(): array {
	$object = get_queried_object();

	if ( is_404() ) {
		return array( _ww_breadcrumb( __( 'Pagina niet gevonden', 'webwerckt-base' ), '' ) );
	}
	if ( is_search() ) {
		/* translators: %s: de zoekopdracht. */
		return array( _ww_breadcrumb( sprintf( __( 'Zoekresultaten voor „%s”', 'webwerckt-base' ), get_search_query( false ) ), '' ) );
	}
	if ( is_home() ) {
		return _ww_breadcrumb_posts_page();
	}
	if ( is_singular() && $object instanceof WP_Post ) {
		$trail = array_merge( _ww_breadcrumb_post_type( $object->post_type ), _ww_breadcrumb_ancestors( $object->ID ) );
		return array_merge( $trail, array( _ww_breadcrumb_post( $object->ID ) ) );
	}
	if ( ( is_category() || is_tag() || is_tax() ) && $object instanceof WP_Term ) {
		return _ww_breadcrumb_term( $object );
	}
	if ( is_post_type_archive() && $object instanceof WP_Post_Type ) {
		return _ww_breadcrumb_post_type( $object->name );
	}
	// Auteur, datum en andere archieven: de titel van het archief.
	return array( _ww_breadcrumb( get_the_archive_title(), '' ) );
}

/**
 * Het pad naar de huidige pagina als platte tekst en URL's, nog niet ge-escaped: Home eerst, de huidige pagina
 * laatst. Op de homepage leeg. Gaat door het filter ww_breadcrumbs, waarmee een child-thema een stap toevoegt of
 * het label van Home wijzigt; ook het schema gebruikt deze lijst.
 *
 * @return array<int,array{label:string,url:string}>
 */
function _ww_breadcrumb_trail(): array {
	if ( is_front_page() ) {
		return array();
	}
	$trail = array_merge( array( _ww_breadcrumb( __( 'Home', 'webwerckt-base' ), home_url( '/' ) ) ), _ww_breadcrumb_steps() );
	$trail = apply_filters( 'ww_breadcrumbs', $trail );

	$clean = array();
	foreach ( is_array( $trail ) ? $trail : array() as $item ) {
		$label = is_array( $item ) ? _ww_plain_text( _ww_data_to_string( $item['label'] ?? '' ) ) : '';
		if ( '' !== $label ) {
			$clean[] = array(
				'label' => $label,
				'url'   => _ww_data_to_string( $item['url'] ?? '' ),
			);
		}
	}
	return count( $clean ) > 1 ? $clean : array();
}

/**
 * Het pad naar de huidige pagina, Home eerst. Op de homepage array().
 *
 * Elk item is een array met label (ge-escaped), url (ge-escaped; '' bij de huidige pagina), current (bool) en attrs
 * (`aria-current="page"` bij de huidige pagina):
 *
 *     <?php foreach ( ww_breadcrumbs() as $crumb ) : ?>
 *         <li><?php if ( $crumb['url'] ) : ?><a href="<?php echo $crumb['url']; ?>"><?php echo $crumb['label']; ?></a>
 *         <?php else : ?><span <?php echo $crumb['attrs']; ?>><?php echo $crumb['label']; ?></span><?php endif; ?></li>
 *     <?php endforeach; ?>
 *
 * @return array<int,array{label:string,url:string,current:bool,attrs:string}>
 */
function ww_breadcrumbs(): array {
	$trail = _ww_breadcrumb_trail();
	$last  = count( $trail ) - 1;
	$out   = array();
	foreach ( $trail as $index => $item ) {
		$current = $index === $last;
		$out[]   = array(
			'label'   => esc_html( $item['label'] ),
			'url'     => $current ? '' : esc_url( $item['url'] ),
			'current' => $current,
			'attrs'   => $current ? 'aria-current="page"' : '',
		);
	}
	return $out;
}
