<?php
/**
 * Paginacache: de techniek in Site-gezondheid, en de gewone taal voor het scherm Pagina cache. Het scherm zegt wat
 * een klant moet weten; de reden, het schrijven van de .htaccess en de opwarmfouten staan hier, voor wie ze zoekt.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Uitleg bij de reden waarom de cache uit staat (_ww_page_cache_status()), of '' als hij aan staat.
 */
function _ww_page_cache_reason_text( string $reason ): string {
	switch ( $reason ) {
		case '':
			return '';
		case 'constant':
			return __( 'De paginacache staat uit met WW_PAGE_CACHE in wp-config.php.', 'webwerckt-base' );
		case 'environment':
			return sprintf(
				/* translators: %s: omgeving, zoals local of staging. */
				__( 'De paginacache staat alleen aan op productie, en deze site is %s. Zet define( \'WW_PAGE_CACHE\', true ); in wp-config.php om hem hier toch te gebruiken.', 'webwerckt-base' ),
				wp_get_environment_type()
			);
		case 'wordpress':
			return __( 'De paginacache vraagt WordPress 6.9 of nieuwer.', 'webwerckt-base' );
		case 'plugin':
			return sprintf(
				/* translators: %s: pad van de plugin, zoals litespeed-cache/litespeed-cache.php. */
				__( 'Een andere cacheplugin is actief (%s) en verzorgt de paginacache. Zet die uit om de cache van het thema te gebruiken.', 'webwerckt-base' ),
				_ww_page_cache_other_plugin()
			);
		case 'advanced-cache':
			return __( 'Een andere cacheplugin heeft een advanced-cache.php neergezet en WP_CACHE staat aan. Die verzorgt de paginacache.', 'webwerckt-base' );
		case 'filter':
			return __( 'De paginacache staat uit met het filter ww_page_cache.', 'webwerckt-base' );
		case 'mu-plugin':
			return __( 'De mu-plugin webwerckt-base-page-cache.php staat niet in wp-content/mu-plugins. Het thema zet hem daar zelf neer, maar dat lukte niet: geen schrijfrechten, of bestandswijzigingen staan uit (DISALLOW_FILE_MODS).', 'webwerckt-base' );
		default:
			return $reason;
	}
}

/**
 * Waarom de laatste ronde opwarmen stopte, of '' als hij gewoon klaar was.
 *
 * @param array<string,mixed> $status De laatste ronde (_ww_page_cache_preload_run()).
 */
function _ww_page_cache_preload_stop_text( array $status ): string {
	$url = is_string( $status['url'] ?? null ) ? $status['url'] : '';
	switch ( $status['stop'] ?? '' ) {
		case 'error':
			return sprintf(
				/* translators: 1: URL, 2: foutmelding. */
				__( 'Gestopt: de site kon %1$s niet bij zichzelf opvragen (%2$s). Blokkeert een firewall verzoeken van de server naar zichzelf?', 'webwerckt-base' ),
				$url,
				is_string( $status['error'] ?? null ) ? $status['error'] : ''
			);
		case 'http':
			$code = (int) ( $status['code'] ?? 0 );
			$text = sprintf(
				/* translators: 1: HTTP-statuscode, 2: URL. */
				__( 'Gestopt: de server gaf %1$d op %2$s. De volgende ronde probeert het opnieuw.', 'webwerckt-base' ),
				$code,
				$url
			);
			return 401 === $code ? $text . ' ' . __( 'Staat de site achter een wachtwoord?', 'webwerckt-base' ) : $text;
		case 'time':
			return __( 'Overgeslagen: de cron had niet genoeg tijd over binnen de tijdslimiet van PHP (max_execution_time). De volgende ronde probeert het opnieuw.', 'webwerckt-base' );
		case 'slow':
			return sprintf(
				/* translators: 1: URL, 2: seconden. */
				__( 'Gestopt: %1$s duurde %2$s seconden. Bij een trage server wacht het opwarmen tot de volgende ronde.', 'webwerckt-base' ),
				$url,
				number_format_i18n( (float) ( $status['seconds'] ?? 0 ), 1 )
			);
		default:
			return '';
	}
}

/**
 * Klanttekst voor een uitgezette cache, zonder techniek.
 */
function _ww_page_cache_client_reason( string $reason ): string {
	switch ( $reason ) {
		case 'plugin':
		case 'advanced-cache':
			$name = '';
			if ( 'plugin' === $reason ) {
				$path = _ww_page_cache_other_plugin();
				if ( ! function_exists( 'get_plugins' ) ) {
					require_once ABSPATH . 'wp-admin/includes/plugin.php';
				}
				$plugins = get_plugins();
				$name    = isset( $plugins[ $path ]['Name'] ) && is_string( $plugins[ $path ]['Name'] ) && '' !== $plugins[ $path ]['Name'] ? $plugins[ $path ]['Name'] : $path;
			}
			if ( '' === $name ) {
				return __( 'Een andere cacheplugin zorgt al voor snelle pagina\'s. Zolang die aan staat, doet het thema niets.', 'webwerckt-base' );
			}
			return sprintf(
				/* translators: %s: naam van de andere cacheplugin. */
				__( 'Een andere cacheplugin (%s) zorgt al voor snelle pagina\'s. Zolang die aan staat, doet het thema niets.', 'webwerckt-base' ),
				$name
			);
		case 'constant':
		case 'environment':
		case 'filter':
			return __( 'De pagina cache staat voor deze site uit.', 'webwerckt-base' );
		case 'wordpress':
			return __( 'De pagina cache vraagt een nieuwere versie van WordPress.', 'webwerckt-base' );
		default:
			return __( 'De pagina cache kon niet worden ingesteld. Neem contact op met Webwerckt.', 'webwerckt-base' );
	}
}

/**
 * Klanttekst voor een gestopte opwarmronde, of '' als hij niet stopte.
 *
 * @param array<string,mixed> $status De laatste ronde (_ww_page_cache_preload_run()).
 */
function _ww_page_cache_client_stop( array $status ): string {
	$url  = is_string( $status['url'] ?? null ) ? $status['url'] : '';
	$page = '' !== $url ? _ww_page_cache_title( $url ) : '';
	switch ( $status['stop'] ?? '' ) {
		case 'slow':
			$first = sprintf(
				/* translators: 1: paginatitel, 2: seconden. */
				__( 'De site reageerde traag op de pagina %1$s (%2$s seconden).', 'webwerckt-base' ),
				$page,
				number_format_i18n( (float) ( $status['seconds'] ?? 0 ), 1 )
			);
			break;
		case 'http':
			$first = sprintf(
				/* translators: %s: paginatitel. */
				__( 'De site gaf een foutmelding op de pagina %s.', 'webwerckt-base' ),
				$page
			);
			break;
		case 'error':
			$first = __( 'De site kon zichzelf niet bereiken.', 'webwerckt-base' );
			break;
		case 'time':
			$first = __( 'De server had even geen tijd.', 'webwerckt-base' );
			break;
		default:
			return '';
	}
	return __( 'Opwarmen is even gestopt.', 'webwerckt-base' ) . ' ' . $first . ' ' . __( 'Het thema probeert het over een paar minuten opnieuw. Gebeurt dit vaak, neem dan contact op met Webwerckt.', 'webwerckt-base' );
}

/**
 * Hoe de cache ervoor staat, voor het scherm en voor Site-gezondheid.
 *
 * @return array{level:string,label:string,notice:string}
 */
function _ww_page_cache_admin_state(): array {
	$reason = _ww_page_cache_status();
	if ( '' !== $reason ) {
		return array(
			'level'  => 'off',
			'label'  => __( 'Staat uit', 'webwerckt-base' ),
			'notice' => _ww_page_cache_client_reason( $reason ),
		);
	}
	if ( _ww_page_cache_preload_enabled() ) {
		$status = get_option( WW_PAGE_CACHE_PRELOAD_STATUS );
		if ( is_array( $status ) && in_array( $status['stop'] ?? '', array( 'error', 'http', 'slow', 'time' ), true ) ) {
			return array(
				'level'  => 'warning',
				'label'  => __( 'Staat aan, opwarmen gestopt', 'webwerckt-base' ),
				'notice' => _ww_page_cache_client_stop( $status ),
			);
		}
	}
	if ( 'unwritable' === _ww_page_cache_static_state() ) {
		return array(
			'level'  => 'warning',
			'label'  => __( 'Staat aan', 'webwerckt-base' ),
			'notice' => __( 'Je site is iets minder snel dan kan. Neem contact op met Webwerckt.', 'webwerckt-base' ),
		);
	}
	return array(
		'level'  => 'ok',
		'label'  => __( 'Staat aan', 'webwerckt-base' ),
		'notice' => '',
	);
}

/**
 * Uitkomst van de test Pagina cache in Site-gezondheid, met de techniek erbij.
 *
 * @return array<string,mixed>
 */
function _ww_page_cache_health(): array {
	$state  = _ww_page_cache_admin_state();
	$status = get_option( WW_PAGE_CACHE_PRELOAD_STATUS );
	$parts  = array(
		_ww_page_cache_reason_text( _ww_page_cache_status() ),
		_ww_page_cache_static_text( _ww_page_cache_static_state() ),
		is_array( $status ) ? _ww_page_cache_preload_stop_text( $status ) : '',
	);
	$html   = '';
	foreach ( $parts as $part ) {
		if ( '' !== $part ) {
			$html .= '<p>' . esc_html( $part ) . '</p>';
		}
	}
	$html .= '<p><a href="' . esc_url( _ww_page_cache_admin_url() ) . '">' . esc_html__( 'Naar het scherm Pagina cache', 'webwerckt-base' ) . '</a></p>';

	if ( 'ok' === $state['level'] ) {
		$label = __( 'De pagina cache staat aan', 'webwerckt-base' );
	} elseif ( 'off' === $state['level'] ) {
		$label = __( 'De pagina cache staat uit', 'webwerckt-base' );
	} else {
		$label = __( 'De pagina cache vraagt aandacht', 'webwerckt-base' );
	}
	return _ww_health_result( 'ww_page_cache', $label, 'ok' === $state['level'] ? 'good' : 'recommended', $html );
}

/**
 * Hangt de test Pagina cache in Site-gezondheid.
 *
 * @param array<string,mixed> $tests Tests van WordPress.
 * @return array<string,mixed>
 */
function _ww_page_cache_health_test( array $tests ): array {
	$tests['direct']['ww_page_cache'] = array(
		'label' => __( 'Pagina cache', 'webwerckt-base' ),
		'test'  => '_ww_page_cache_health',
	);
	return $tests;
}
add_filter( 'site_status_tests', '_ww_page_cache_health_test' );
