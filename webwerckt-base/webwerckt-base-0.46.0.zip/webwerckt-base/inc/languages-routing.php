<?php
/**
 * Meertalig (beslissing 0040), onderdeel routing: het voorvoegsel uit het pad, de URI terugzetten, de locale, de 301's,
 * de voorpagina per taal, een pagina opzoeken per taal en de 404 bij een bericht in de verkeerde taal.
 *
 * Een extra taal die de bezoeker kan bereiken (_ww_routable_language_codes()) staat als /{code}/ voor het pad. Alleen het
 * parsen van WordPress ziet het pad zonder voorvoegsel: op do_parse_request gaat het eraf, op parse_request komt het
 * oorspronkelijke REQUEST_URI direct terug. Alle rewrite rules werken zo ongewijzigd, en alles daarna (paginacache,
 * redirects, het 404-logboek, formulieren, redirect_canonical) leest weer het echte pad.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Eerste padsegmenten die nooit als taal worden gelezen.
const WW_LANGUAGES_RESERVED_PATHS = array( 'wp-admin', 'wp-login.php', 'wp-json', 'xmlrpc.php' );

/**
 * Het pad van de site zonder slash erachter ('' op de hoofdmap, '/site' in een submap). Uit de ruwe optie home, nooit
 * uit het gefilterde home_url().
 */
function _ww_languages_home_path(): string {
	$path = wp_parse_url( (string) get_option( 'home' ), PHP_URL_PATH );
	return is_string( $path ) ? untrailingslashit( $path ) : '';
}

/**
 * De taal van dit verzoek, ook in de uit-stand (dan altijd de standaardtaal). Anders dan ww_current_language() geeft
 * dit nooit ''.
 */
function _ww_languages_request_language(): string {
	$current = _ww_languages_state()['current'];
	return '' !== $current ? $current : _ww_default_language();
}

/**
 * Haalt het voorvoegsel van een bereikbare extra taal van een REQUEST_URI af.
 *
 * '/en/about-us/?x=1' wordt [ 'en', '/about-us/?x=1' ] en '/en' wordt [ 'en', '/' ]. Zonder voorvoegsel, met een
 * verborgen taal (voor een bezoeker) of met een gereserveerd pad blijft de URI staan: [ '', $uri ].
 *
 * @return array{0:string,1:string}
 */
function _ww_languages_split_path( string $uri ): array {
	$home = _ww_languages_home_path();
	$rest = $uri;
	if ( '' !== $home ) {
		if ( ! str_starts_with( $uri, $home . '/' ) && ! str_starts_with( $uri, $home . '?' ) && $uri !== $home ) {
			return array( '', $uri );
		}
		$rest = substr( $uri, strlen( $home ) );
	}

	if ( 1 !== preg_match( '#^/([^/?\#]+)(/|\?|$)(.*)$#s', $rest, $match ) ) {
		return array( '', $uri );
	}
	$code = $match[1];
	if ( in_array( $code, WW_LANGUAGES_RESERVED_PATHS, true ) || ! in_array( $code, _ww_extra_language_codes(), true ) ) {
		return array( '', $uri );
	}
	// Pas nu de zichtbaarheid: die kijkt naar de rechten van de gebruiker.
	if ( ! in_array( $code, _ww_routable_language_codes(), true ) ) {
		return array( '', $uri );
	}

	$after = '?' === $match[2] ? '/?' . $match[3] : '/' . $match[3];
	return array( $code, $home . $after );
}

/**
 * Draait in de boot (after_setup_theme, prioriteit 1): zet de huidige taal uit het ruwe REQUEST_URI en hangt het filter
 * locale op, vóór de textdomains van de thema's laden. In een extra taal laadt hij de strings van WordPress en
 * $wp_locale opnieuw, want die bestaan al. Laadde een textdomain van het thema toch al eerder (een string buiten een
 * hook in het child-thema), dan gaat het eruit, zodat het opnieuw laadt in de taal van het verzoek.
 */
function _ww_languages_detect_early(): void {
	$uri   = isset( $_SERVER['REQUEST_URI'] ) && is_string( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- alleen vergeleken met de ingestelde taalcodes.
	$code  = _ww_languages_split_path( $uri )[0];
	$state = &_ww_languages_state();

	$state['current'] = '' !== $code ? $code : _ww_default_language();
	// Prioriteit 1: switch_to_locale() (prioriteit 10) gaat voor, bijvoorbeeld voor een mail in de taal van de ontvanger.
	add_filter( 'locale', '_ww_languages_locale', 1 );

	if ( '' === $code ) {
		return;
	}
	_ww_languages_reload_locale();
}

/**
 * Laadt de strings opnieuw in de locale die het filter locale nu geeft. De strings van WordPress zelf en de maand- en
 * dagnamen laadt wp-settings.php al vóór het thema: opnieuw, in de locale van deze taal. Een al geladen textdomain van
 * het thema gaat eruit, zodat het bij de eerste string opnieuw laadt in de taal van het verzoek.
 */
function _ww_languages_reload_locale(): void {
	unload_textdomain( 'default', true );
	load_default_textdomain();
	$GLOBALS['wp_locale'] = new WP_Locale(); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- de datums volgen de taal van het verzoek.

	foreach ( array_unique( array( 'webwerckt-base', (string) wp_get_theme()->get( 'TextDomain' ) ) ) as $domain ) {
		if ( '' !== $domain && is_textdomain_loaded( $domain ) ) {
			unload_textdomain( $domain, true );
		}
	}
}

/**
 * Zet de huidige taal en de locale buiten de routing om: voor REST (het kaarten-endpoint met ?lang=), waar het pad geen
 * voorvoegsel heeft. Laadt de strings alleen opnieuw als de taal echt wisselt. $lang moet al gecontroleerd zijn (zie
 * _ww_languages_valid_language()).
 *
 * @param string $lang Taalcode.
 */
function _ww_languages_set_current( string $lang ): void {
	$state    = &_ww_languages_state();
	$previous = _ww_languages_request_language();

	$state['current'] = $lang;
	add_filter( 'locale', '_ww_languages_locale', 1 );
	if ( $previous !== _ww_languages_request_language() ) {
		_ww_languages_reload_locale();
	}
}

/**
 * Filter do_parse_request (als laatste): haalt het voorvoegsel van REQUEST_URI af en zet de huidige taal. Elke keer,
 * ook zonder voorvoegsel, zodat een volgend verzoek in hetzelfde proces (tests) niet de oude taal houdt.
 *
 * @param bool $do Of WordPress het verzoek parst.
 * @param WP   $wp Het WP-object.
 */
function _ww_languages_parse_request( bool $do, WP $wp ): bool {
	unset( $wp );
	if ( ! $do ) {
		return $do;
	}

	$uri   = isset( $_SERVER['REQUEST_URI'] ) && is_string( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- komt ongewijzigd terug in _ww_languages_restore_uri().
	$split = _ww_languages_split_path( $uri );
	$state = &_ww_languages_state();

	$state['current']      = '' !== $split[0] ? $split[0] : _ww_default_language();
	$state['original_uri'] = $uri;
	if ( '' !== $split[0] ) {
		// Een vertaalde basis (/en/projects/) wordt voor het parsen de echte basis (inc/languages-bases.php).
		$home                   = _ww_languages_home_path();
		$_SERVER['REQUEST_URI'] = $home . _ww_language_base_unswap( substr( $split[1], strlen( $home ) ), $split[0] );
	}
	return $do;
}

/**
 * Actie parse_request (als eerste): zet het oorspronkelijke REQUEST_URI terug. Alleen het parsen zag het pad zonder
 * voorvoegsel.
 */
function _ww_languages_restore_uri(): void {
	$original = _ww_languages_state()['original_uri'];
	if ( '' !== $original ) {
		$_SERVER['REQUEST_URI'] = $original;
	}
}

/**
 * Filter locale: de locale van de huidige taal als dat een extra taal is. Voor de standaardtaal en in de admin blijft
 * de locale van de site staan.
 *
 * @param string $locale Locale.
 */
function _ww_languages_locale( string $locale ): string {
	$current = _ww_languages_state()['current'];
	if ( '' === $current || _ww_default_language() === $current ) {
		return $locale;
	}
	$language = _ww_language( $current );
	return null !== $language ? $language['locale'] : $locale;
}

/**
 * Filter option_page_on_front en option_page_for_posts: in een extra taal de vertaling in die taal, of 0 als die er
 * niet is (dan geeft /en/ een 404, zie _ww_languages_wrong_language()). In de standaardtaal de oorspronkelijke ID.
 *
 * @param mixed $id Waarde van de optie.
 * @return mixed
 */
function _ww_languages_front_page_option( mixed $id ): mixed {
	$current = _ww_languages_state()['current'];
	if ( '' === $current || _ww_default_language() === $current || ! is_numeric( $id ) || (int) $id <= 0 ) {
		return $id;
	}
	return _ww_translations( (int) $id )[ $current ] ?? 0;
}

/**
 * De optie page_on_front of page_for_posts zonder het filter van de taal.
 */
function _ww_languages_raw_page_option( string $name ): int {
	$hooked = has_filter( 'option_' . $name, '_ww_languages_front_page_option' );
	if ( false === $hooked ) {
		return (int) get_option( $name );
	}
	remove_filter( 'option_' . $name, '_ww_languages_front_page_option', $hooked );
	$value = (int) get_option( $name );
	add_filter( 'option_' . $name, '_ww_languages_front_page_option', $hooked );
	return $value;
}

/**
 * Zoekt een bericht op in de gegeven taal: bij een hiërarchisch post type langs zijn pad, per segment met de ouder
 * erbij; anders alleen op de slug. get_page_by_path() en een query op name kunnen dat niet: de eerste doet een eigen
 * SQL-query zonder taal, en bij de tweede is de query singulier, waardoor WP_Query de tax_query overslaat.
 *
 * @return int Post-ID, of 0.
 */
function _ww_languages_find_by_path( string $post_type, string $path, string $lang ): int {
	$hierarchical = is_post_type_hierarchical( $post_type );
	// Dezelfde normalisatie als get_page_by_path().
	$path     = str_replace( array( '%2F', '%20' ), array( '/', ' ' ), rawurlencode( urldecode( $path ) ) );
	$segments = array_map( 'sanitize_title_for_query', explode( '/', trim( $path, '/' ) ) );
	if ( ! $hierarchical && count( $segments ) > 1 ) {
		return 0;
	}
	$parent = 0;
	$last   = count( $segments ) - 1;
	$editor = current_user_can( 'edit_posts' );

	foreach ( $segments as $index => $segment ) {
		// Gepubliceerd gaat voor: een nieuwer concept met dezelfde slug mag de live pagina niet verdringen. Een bezoeker
		// krijgt als laatste segment alleen gepubliceerd. Een ouder mag, net als in get_page_by_path(), elke status
		// hebben, en wie mag bewerken vindt daarna ook een concept.
		$statuses = $index < $last || $editor ? array( 'publish', 'any' ) : array( 'publish' );
		$found    = 0;
		foreach ( $statuses as $status ) {
			// post_name__in en niet name: met name is de query singulier, en dan slaat WP_Query de tax_query over.
			$args = array(
				'post_type'        => $post_type,
				'post_name__in'    => array( $segment ),
				'post_status'      => $status,
				'fields'           => 'ids',
				'tax_query'        => _ww_languages_tax_query( $lang ), // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- de taal hoort bij de zoekopdracht.
				'suppress_filters' => true,
				'numberposts'      => 1,
			);
			if ( $hierarchical ) {
				$args['post_parent'] = $parent;
			}
			$ids = get_posts( $args );
			if ( array() !== $ids ) {
				$found = (int) $ids[0];
				break;
			}
		}
		if ( 0 === $found ) {
			return 0;
		}
		$parent = $found;
	}
	return $parent;
}

/**
 * Welk bericht een singulier verzoek op naam vraagt: [ post type, pad of slug, query vars die weg moeten ], of null.
 * Een pagina via pagename, een ander vertaalbaar post type via zijn query var, en een bericht via name (met post_type,
 * of zonder: dan is het een post). Alleen vertaalbare post types.
 *
 * @param array<string,mixed> $vars Query vars.
 * @return array{0:string,1:string,2:string[]}|null
 */
function _ww_languages_request_target( array $vars ): ?array {
	if ( isset( $vars['pagename'] ) && is_string( $vars['pagename'] ) && '' !== $vars['pagename'] ) {
		return _ww_is_translatable( 'page' ) ? array( 'page', $vars['pagename'], array( 'pagename' ) ) : null;
	}

	foreach ( _ww_translatable_post_types() as $type ) {
		$object = get_post_type_object( $type );
		if ( in_array( $type, array( 'page', 'post' ), true ) || null === $object || ! is_string( $object->query_var ) || '' === $object->query_var ) {
			continue;
		}
		$path = $vars[ $object->query_var ] ?? '';
		if ( is_string( $path ) && '' !== $path ) {
			return array( $type, $path, array( $object->query_var, 'name' ) );
		}
	}

	$name = $vars['name'] ?? '';
	$type = $vars['post_type'] ?? 'post';
	if ( is_string( $name ) && '' !== $name && is_string( $type ) && _ww_is_translatable( $type ) ) {
		return array( $type, $name, array( 'name' ) );
	}
	return null;
}

/**
 * Filter request: zoekt het bericht van een singulier verzoek op naam op in de taal van het verzoek (zie
 * _ww_languages_request_target()), en zet daarna page_id, of p met post_type. Niet gevonden: een 404. Alleen met
 * minstens een extra taal in de optie, ook een verborgen (berichten in een verborgen taal delen hun slug ook), en in
 * de uit-stand (dan in de standaardtaal).
 *
 * @param array<string,mixed> $vars Query vars.
 * @return array<string,mixed>
 */
function _ww_languages_request( array $vars ): array {
	if ( array() === _ww_extra_language_codes() ) {
		return $vars;
	}
	$state             = &_ww_languages_state();
	$state['old_slug'] = null;
	$target            = _ww_languages_request_target( $vars );
	if ( null === $target ) {
		return $vars;
	}

	list( $type, $path, $remove ) = $target;
	$id                           = _ww_languages_find_by_path( $type, $path, _ww_languages_request_language() );
	if ( 0 === $id && 'page' === $type ) {
		// Een bijlage onder een pagina (/pagina/bijlage/) heeft geen taal: dan zoekt WordPress hem zelf op.
		$found = get_page_by_path( $path );
		if ( $found instanceof WP_Post && 'attachment' === $found->post_type ) {
			return $vars;
		}
		// De paginaregels zetten pagename zodra er een pagina met dit pad is, in welke taal ook. Een pagina `team` in
		// een andere taal mag een bericht `team` in deze taal niet verbergen: zoek een enkel segment dan op als post.
		if ( ! str_contains( trim( $path, '/' ), '/' ) && _ww_is_translatable( 'post' ) ) {
			$post_id = _ww_languages_find_by_path( 'post', $path, _ww_languages_request_language() );
			if ( 0 !== $post_id ) {
				unset( $vars['pagename'] );
				$vars['p']         = $post_id;
				$vars['post_type'] = 'post';
				return $vars;
			}
		}
	}

	foreach ( $remove as $key ) {
		unset( $vars[ $key ] );
	}
	if ( 0 === $id ) {
		// Bewaar de naam voor de oude-slug-redirect van WordPress, die alleen niet-hiërarchische types volgt. Een enkel
		// segment op een paginaregel kan de oude slug van een bericht zijn (zie hierboven).
		if ( ! is_post_type_hierarchical( $type ) ) {
			$state['old_slug'] = array( $type, $path );
		} elseif ( 'page' === $type && ! str_contains( trim( $path, '/' ), '/' ) && _ww_is_translatable( 'post' ) ) {
			$state['old_slug'] = array( 'post', trim( $path, '/' ) );
		}
		return _ww_languages_request_404( $vars );
	}
	if ( 'page' === $type ) {
		$vars['page_id'] = $id;
	} else {
		$vars['p']         = $id;
		$vars['post_type'] = $type;
	}
	return $vars;
}

/**
 * Een 404 vanuit het filter request, zonder dat WordPress een bericht in een andere taal gaat raden.
 *
 * @param array<string,mixed> $vars Query vars.
 * @return array<string,mixed>
 */
function _ww_languages_request_404( array $vars ): array {
	$vars['error'] = '404';
	add_filter( 'do_redirect_guess_404_permalink', '__return_false' );
	return $vars;
}

/**
 * Waar een verzoek met een 301 heen moet, of '' voor geen redirect. Een pure functie, zodat hij zonder exit te testen is.
 *
 * - /{extra taal} zonder slash gaat naar /{extra taal}/.
 * - /{standaardtaal}/pad gaat naar /pad.
 * - /{extra taal}/{echte basis}/… gaat naar /{extra taal}/{vertaalde basis}/… als die taal een vertaalde basis heeft
 *   (inc/languages-bases.php), alleen met $bases.
 *
 * Alleen voor GET en HEAD: een POST zou met een 301 zijn inhoud verliezen. De querystring blijft.
 *
 * @param string $uri    REQUEST_URI (met het pad van de site, en eventueel een querystring).
 * @param string $method REQUEST_METHOD.
 * @param bool   $bases  Ook de 301 naar de vertaalde basis.
 * @return string Het nieuwe REQUEST_URI, of ''.
 */
function _ww_languages_redirect_target( string $uri, string $method = 'GET', bool $bases = true ): string {
	if ( ! in_array( strtoupper( $method ), array( 'GET', 'HEAD' ), true ) ) {
		return '';
	}
	$home  = _ww_languages_home_path();
	$parts = explode( '?', $uri, 2 );
	$path  = $parts[0];
	$query = isset( $parts[1] ) ? '?' . $parts[1] : '';

	if ( '' !== $home ) {
		if ( $path !== $home && ! str_starts_with( $path, $home . '/' ) ) {
			return '';
		}
		$path = substr( $path, strlen( $home ) );
	}
	if ( 1 !== preg_match( '#^/([^/]+)(/.*)?$#s', $path, $match ) ) {
		return '';
	}

	$code = $match[1];
	$rest = $match[2] ?? '';
	if ( '' === $rest && in_array( $code, _ww_routable_language_codes(), true ) ) {
		return $home . '/' . $code . '/' . $query;
	}
	if ( _ww_default_language() === $code ) {
		return $home . ( '' === $rest ? '/' : $rest ) . $query;
	}
	if ( $bases && '' !== $rest && in_array( $code, _ww_routable_language_codes(), true ) ) {
		$swapped = _ww_language_base_replace( $rest, $code, true );
		if ( $swapped !== $rest ) {
			return $home . '/' . $code . $swapped . $query;
		}
	}
	return '';
}

/**
 * Actie template_redirect (prioriteit 0): de 301's van _ww_languages_redirect_target(). De 301 naar de vertaalde basis
 * alleen als geen redirectregel het pad al doorstuurt.
 */
function _ww_languages_redirects(): void {
	$uri    = isset( $_SERVER['REQUEST_URI'] ) && is_string( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- alleen een bekend voorvoegsel gaat eraf; wp_safe_redirect() controleert de host.
	$method = isset( $_SERVER['REQUEST_METHOD'] ) && is_string( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : 'GET'; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- alleen vergeleken met GET en HEAD.
	$target = _ww_languages_redirect_target( $uri, $method, false );
	if ( '' === $target ) {
		// De 301 naar de vertaalde basis. Een redirectregel voor dit pad (template_redirect, prioriteit 1) gaat voor.
		$target = _ww_languages_redirect_target( $uri, $method );
		if ( '' === $target || _ww_language_base_rule_exists( $uri ) ) {
			return;
		}
	}

	$home   = wp_parse_url( (string) get_option( 'home' ) );
	$origin = ( $home['scheme'] ?? 'https' ) . '://' . ( $home['host'] ?? '' ) . ( isset( $home['port'] ) ? ':' . $home['port'] : '' );
	if ( wp_safe_redirect( $origin . $target, 301, 'Webwerckt' ) ) {
		exit;
	}
}

/**
 * Of /en/ een voorpagina vraagt die in deze taal niet bestaat: het filter gaf 0, dus WordPress viel terug op de
 * berichtenlijst. Een feed en de berichtenpagina zelf tellen niet.
 */
function _ww_languages_front_page_missing( WP_Query $query ): bool {
	if ( ! $query->is_home() || $query->is_posts_page || $query->is_feed() || 'page' !== get_option( 'show_on_front' ) ) {
		return false;
	}
	return 0 === (int) get_option( 'page_on_front' ) && _ww_languages_raw_page_option( 'page_on_front' ) > 0;
}

/**
 * Actie wp: een 404 als het object van een singulier verzoek vertaalbaar is en in een andere taal dan het verzoek, of
 * als de voorpagina in deze taal geen vertaling heeft.
 */
function _ww_languages_wrong_language(): void {
	global $wp_query;
	if ( ! $wp_query instanceof WP_Query || $wp_query->is_404() ) {
		return;
	}

	if ( $wp_query->is_singular() ) {
		$post = $wp_query->get_queried_object();
		if ( ! $post instanceof WP_Post || ! _ww_is_translatable( $post->post_type ) || _ww_post_language( $post->ID ) === _ww_languages_request_language() ) {
			return;
		}
	} elseif ( ! _ww_languages_front_page_missing( $wp_query ) ) {
		return;
	}

	// set_404() zet alleen de vlaggen terug. Het bericht in de verkeerde of verborgen taal moet ook uit de query en uit
	// $post, zodat een 404-template of _ww_current_id() het niet alsnog toont.
	$wp_query->set_404();
	$wp_query->posts             = array();
	$wp_query->post              = null;
	$wp_query->post_count        = 0;
	$wp_query->found_posts       = 0;
	$wp_query->max_num_pages     = 0;
	$wp_query->current_post      = -1;
	$wp_query->queried_object    = null;
	$wp_query->queried_object_id = null;
	$GLOBALS['post']           = null; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- het bericht mag niet zichtbaar blijven.
	status_header( 404 );
	nocache_headers();
	add_filter( 'do_redirect_guess_404_permalink', '__return_false' );
}

/**
 * Filter old_slug_redirect_post_id: de redirect bij een oude slug alleen naar een bericht in de taal van het verzoek.
 * WordPress geeft één bericht met deze oude slug, in welke taal ook; hoort dat bij een andere taal, dan wordt het bericht
 * met dezelfde oude slug in de taal van het verzoek opgezocht. Is er geen, dan geen redirect (de 404 blijft).
 *
 * @param mixed $id Post-ID.
 * @return mixed
 */
function _ww_languages_old_slug_post_id( mixed $id ): mixed {
	if ( ! is_numeric( $id ) || (int) $id <= 0 ) {
		return $id;
	}
	$type = get_post_type( (int) $id );
	$lang = _ww_languages_request_language();
	if ( false === $type || ! _ww_is_translatable( $type ) || _ww_post_language( (int) $id ) === $lang ) {
		return $id;
	}

	$name = get_query_var( 'name' );
	if ( ! is_string( $name ) || '' === $name ) {
		return 0;
	}
	global $wpdb;
	$ids = $wpdb->get_col( $wpdb->prepare( "SELECT pm.post_id FROM $wpdb->postmeta pm INNER JOIN $wpdb->posts p ON p.ID = pm.post_id WHERE p.post_type = %s AND pm.meta_key = '_wp_old_slug' AND pm.meta_value = %s ORDER BY pm.post_id", $type, $name ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- dezelfde zoekvraag als _find_post_by_old_slug() van WordPress, alleen op een 404.
	foreach ( $ids as $candidate ) {
		if ( _ww_post_language( (int) $candidate ) === $lang ) {
			return (int) $candidate;
		}
	}
	return 0;
}

/**
 * Actie wp: zet bij een 404 uit _ww_languages_request() de naam en het post type terug op de hoofdquery. Het filter
 * request haalt de naam weg om WordPress geen bericht in een andere taal te laten laden; zonder naam draait
 * wp_old_slug_redirect() niet. Een slug die nergens een oude slug is, blijft een 404.
 */
function _ww_languages_old_slug_restore(): void {
	global $wp_query;
	$old = _ww_languages_state()['old_slug'];
	if ( null === $old || ! $wp_query instanceof WP_Query || ! $wp_query->is_404() ) {
		return;
	}
	$wp_query->set( 'name', $old[1] );
	$wp_query->set( 'post_type', $old[0] );
}

/**
 * Hangt de 404 bij de verkeerde taal en de oude-slug-redirect per taal op. Ook in de uit-stand: dan is de taal van elk
 * verzoek de standaardtaal.
 */
function _ww_languages_hook_wrong_language(): void {
	add_action( 'wp', '_ww_languages_wrong_language' );
	add_action( 'wp', '_ww_languages_old_slug_restore', 20 );
	add_filter( 'old_slug_redirect_post_id', '_ww_languages_old_slug_post_id' );
}

/**
 * Hangt de hooks van dit onderdeel op. Draait ook na init (zie _ww_languages_boot()). Met alleen de standaardtaal is er
 * geen voorvoegsel en niets te routeren.
 */
function _ww_languages_boot_routing(): void {
	if ( array() === _ww_extra_language_codes() ) {
		return;
	}
	_ww_languages_detect_early();
	add_filter( 'do_parse_request', '_ww_languages_parse_request', PHP_INT_MAX, 2 );
	add_action( 'parse_request', '_ww_languages_restore_uri', PHP_INT_MIN );
	add_filter( 'request', '_ww_languages_request' );
	add_filter( 'option_page_on_front', '_ww_languages_front_page_option' );
	add_filter( 'option_page_for_posts', '_ww_languages_front_page_option' );
	add_action( 'template_redirect', '_ww_languages_redirects', 0 );
	_ww_languages_hook_wrong_language();
}
