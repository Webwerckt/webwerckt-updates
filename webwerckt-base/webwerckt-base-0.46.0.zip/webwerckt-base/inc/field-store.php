<?php
/**
 * De opslaglaag van de velden: schoont gecontroleerde waarden op en schrijft ze naar wp_postmeta, wp_termmeta en
 * wp_options, byte voor byte zoals Pods 3.3.9.2 (spec eigen-velden, deel 1). tests/test-field-store.php vergelijkt
 * elke soort met Pods zelf.
 *
 * - _ww_field_clean() doet wat pre_save van Pods per soort doet, voor de opties die de veldconfiguratie gebruikt en
 *   met de standaardwaarden van Pods voor de rest.
 * - _ww_field_store_post(), _ww_field_store_term() en _ww_field_store_setting() schrijven de rijen in dezelfde
 *   volgorde als Pods, met delete_metadata/add_metadata/update_metadata, zodat het activiteitenlog en de revisies
 *   dezelfde haken zien. Bericht en term delen _ww_field_store_meta(): Pods slaat een taxonomie-pod op zoals een
 *   post type, alleen in de term meta.
 * - wp_podsrel schrijft het thema niet. Pods leest daar de volgorde van relaties uit; Pods en de eigen velden horen
 *   daarom niet tegelijk te bewerken.
 *
 * Controle (bestaat het bericht, is de keuze toegestaan) is niet hier maar in _ww_fields_input() (inc/fields.php).
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * Soorten.
 */

/**
 * Hoe Pods een veld opslaat: 'relation' (relatie met berichten, termen of bestanden: rijen en _pods_-lijst),
 * 'choice' (custom-simple: rijen, en bij meerdere een _pods_-lijst) of 'plain' (één rij).
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 */
function _ww_field_store_kind( array $field ): string {
	$type = _ww_data_to_string( $field['type'] ?? '' );
	if ( 'file' === $type ) {
		return 'relation';
	}
	if ( 'pick' === $type ) {
		return 'custom-simple' === ( $field['pick_object'] ?? '' ) ? 'choice' : 'relation';
	}
	return 'plain';
}

/**
 * Een optie van een veld, of de terugvalwaarde die Pods gebruikt als de optie ontbreekt.
 *
 * Let op: Pods vult de standaardwaarden uit zijn eigen instellingenscherm (options() per soort) niet aan voor velden
 * die in code zijn geregistreerd, zoals die van het thema. Wat telt, is de terugvalwaarde in de code van pre_save
 * (pods_v( $optie, $veld, $terugval )), en die verschilt soms van het scherm: zo staat "witruimte weghalen" in het
 * scherm standaard aan, maar zonder de optie doet Pods het niet. De vergelijkingstest legt dat vast.
 *
 * @param array<string,mixed> $field   Veld uit de configuratie.
 * @param mixed               $default Terugvalwaarde van Pods.
 * @return mixed
 */
function _ww_field_option( array $field, string $option, $default ) {
	return $field[ $option ] ?? $default;
}

/*
 * Opschonen.
 */

/**
 * Eén gecontroleerde waarde opgeschoond zoals pre_save van Pods: tekst, een lijst met ID's (relatie en foto's), een
 * lijst met keuzes (meerkeuze met meerdere), 0 of 1 (ja/nee), of null.
 *
 * Gelijk aan Pods, ook waar dat van de spec-tabel afwijkt:
 * - Een leeg getal wordt null: Pods slaat het niet op als "" maar haalt de rij weg.
 * - Een lege datum wordt 0000-00-00, een lege datum met tijd 0000-00-00 00:00:00; een lege tijd blijft "".
 * - Een meerkeuze met meerdere geeft altijd een lijst, ook leeg; hoe Pods die opslaat (een lege lijst als één lege
 *   rij) doen _ww_field_store_post() en _ww_field_store_setting().
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @param mixed               $value Gecontroleerde waarde (_ww_fields_input_value()).
 * @return mixed
 */
function _ww_field_clean( array $field, $value ) {
	$type = _ww_data_to_string( $field['type'] ?? '' );
	$kind = _ww_field_store_kind( $field );

	if ( 'relation' === $kind ) {
		$ids = array();
		foreach ( is_array( $value ) ? $value : array( $value ) as $id ) {
			$ids[] = is_numeric( $id ) ? (int) $id : 0;
		}
		$ids = array_values( array_unique( array_filter( $ids ) ) );
		return _ww_fields_is_multi( $field ) ? $ids : array_slice( $ids, 0, 1 );
	}

	if ( 'choice' === $kind ) {
		$options = _ww_fields_custom_options( $field );
		$values  = array();
		foreach ( is_array( $value ) ? $value : ( '' === $value || null === $value ? array() : explode( ',', (string) $value ) ) as $choice ) {
			$choice = (string) $choice;
			if ( isset( $options[ $choice ] ) ) {
				$values[] = $choice;
			}
		}
		if ( ! _ww_fields_is_multi( $field ) ) {
			return $values[0] ?? '';
		}
		return $values;
	}

	switch ( $type ) {
		case 'boolean':
			return _ww_field_clean_boolean( $field, $value );
		case 'number':
			return _ww_field_clean_number( $field, _ww_data_to_string( $value ) );
		case 'date':
		case 'time':
		case 'datetime':
			$empty = array(
				'date'     => '0000-00-00',
				'time'     => '',
				'datetime' => '0000-00-00 00:00:00',
			);
			$value = _ww_data_to_string( $value );
			return '' === trim( $value ) ? $empty[ $type ] : $value;
		case 'email':
			$value = _ww_data_to_string( $value );
			return _ww_field_max_length( is_email( $value ) ? $value : '', (int) _ww_field_option( $field, 'email_max_length', 255 ) );
		case 'phone':
			return _ww_field_clean_phone( $field, _ww_data_to_string( $value ) );
		case 'website':
			$value = _ww_field_clean_url( $field, _ww_data_to_string( $value ) );
			return _ww_field_max_length( $value, (int) _ww_field_option( $field, 'website_max_length', 255 ) );
		case 'code':
			$value = _ww_field_trim( $field, 'code', _ww_data_to_string( $value ) );
			return _ww_field_max_length( $value, (int) _ww_field_option( $field, 'code_max_length', 0 ) );
		case 'wysiwyg':
		case 'paragraph':
		case 'text':
		default:
			return _ww_field_clean_text( $field, $type, _ww_data_to_string( $value ) );
	}
}

/**
 * Tekst, tekstvak en opgemaakte tekst: HTML, shortcodes en witruimte zoals Pods (PodsField::strip_html(),
 * strip_shortcodes() en trim_whitespace()), en hoogstens zoveel tekens als de soort toestaat.
 *
 * Zonder opties (zoals in de configuratie van het thema): tekst en tekstvak zonder HTML (wp_strip_all_tags(), dat
 * ook de witruimte aan begin en eind weghaalt), tekst hoogstens 255 tekens; opgemaakte tekst altijd met HTML, door
 * wp_kses_post(). Shortcodes gaan eruit, tenzij {soort}_allow_shortcode aan staat. Witruimte blijft verder staan.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @param string              $type  text, paragraph of wysiwyg (een onbekende soort als text).
 */
function _ww_field_clean_text( array $field, string $type, string $value ): string {
	if ( ! in_array( $type, array( 'paragraph', 'wysiwyg' ), true ) ) {
		$type = 'text';
	}
	$value = _ww_field_strip_html( $field, $type, $value );
	if ( '' !== $value && '0' !== $value && 1 !== (int) _ww_field_option( $field, $type . '_allow_shortcode', 0 ) ) {
		$value = strip_shortcodes( $value );
	}
	$value = _ww_field_trim( $field, $type, $value );
	return _ww_field_max_length( $value, (int) _ww_field_option( $field, $type . '_max_length', 'text' === $type ? 255 : 0 ) );
}

/**
 * HTML eruit of opgeschoond, zoals PodsField::strip_html() (en PodsField_WYSIWYG::strip_html(), dat HTML altijd
 * toestaat).
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 */
function _ww_field_strip_html( array $field, string $type, string $value ): string {
	// Pods slaat een lege waarde (ook "0") over.
	if ( '' === $value || '0' === $value ) {
		return $value;
	}
	$allow_html = 'wysiwyg' === $type ? 1 : (int) _ww_field_option( $field, $type . '_allow_html', 0 );
	if ( 1 !== $allow_html ) {
		return wp_strip_all_tags( $value );
	}
	$tags = _ww_data_to_string( _ww_field_option( $field, $type . '_allowed_html_tags', '' ) );
	$tags = array_unique( array_filter( explode( ' ', trim( str_replace( array( '<', '>', ',' ), ' ', $tags ) ) ) ) );
	if ( array() !== $tags ) {
		$value = strip_tags( $value, '<' . implode( '><', $tags ) . '>' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.strip_tags_strip_tags -- zoals Pods, met de toegestane tags.
	}
	return 1 === (int) _ww_field_option( $field, $type . '_sanitize_html', 1 ) ? wp_kses_post( $value ) : $value;
}

/**
 * Witruimte zoals PodsField::trim_whitespace(): alleen met de opties {soort}_trim, _trim_lines of _trim_p_brs.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 */
function _ww_field_trim( array $field, string $type, string $value ): string {
	if ( 1 === (int) _ww_field_option( $field, $type . '_trim_p_brs', 0 ) ) {
		$value = (string) preg_replace( '/(<p[^>]*>\s*(\s|&nbsp;|<br\s*?\/?>)*\s*<\/?p>)/Umi', '', $value );
		$value = (string) preg_replace( '/([\n\r]\s*[\n\r]\s*[\n\r])+/', "\n", $value );
	}
	if ( 1 === (int) _ww_field_option( $field, $type . '_trim_lines', 0 ) ) {
		$value = (string) preg_replace( '/\h+$/m', '', $value );
		$value = (string) preg_replace( '/([\n\r]\s*[\n\r]\s*[\n\r])+/', "\n", $value );
	}
	return 1 === (int) _ww_field_option( $field, $type . '_trim', 0 ) ? trim( $value ) : $value;
}

/**
 * Hoogstens $length tekens (multibyte), zoals Pods; 0 of minder is geen grens.
 */
function _ww_field_max_length( string $value, int $length ): string {
	return 0 < $length && $length < mb_strlen( $value ) ? mb_substr( $value, 0, $length ) : $value;
}

/**
 * Ja/nee als 0 of 1, zoals PodsField_Boolean::pre_save(): het label van ja, of 1, true, on en yes, is 1.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @param mixed               $value Waarde.
 */
function _ww_field_clean_boolean( array $field, $value ): int {
	$yes = strtolower( _ww_data_to_string( $field['boolean_yes_label'] ?? '' ) );
	$yes = '' === $yes ? strtolower( __( 'Yes', 'pods' ) ) : $yes; // phpcs:ignore WordPress.WP.I18n.TextDomainMismatch -- het label van Pods, zoals Pods het vergelijkt.
	if ( is_string( $value ) ) {
		$value = strtolower( $value );
	}
	return $yes === $value ? 1 : (int) filter_var( $value, FILTER_VALIDATE_BOOLEAN );
}

/**
 * Getal zoals PodsField_Number::pre_save(): scheidingstekens van de site weg, afgerond op number_decimals.
 * Leeg geeft null (Pods slaat dan niets op).
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 */
function _ww_field_clean_number( array $field, string $value ): ?string {
	global $wp_locale;
	$formats = array(
		'9.999,99'  => array( '.', ',' ),
		'9,999.99'  => array( ',', '.' ),
		'9\'999.99' => array( '\'', '.' ),
		'9 999,99'  => array( ' ', ',' ),
		'9999.99'   => array( '', '.' ),
		'9999,99'   => array( '', ',' ),
	);
	$format  = wp_unslash( _ww_data_to_string( $field['number_format'] ?? '' ) );
	$default = array( (string) ( $wp_locale->number_format['thousands_sep'] ?? ',' ), (string) ( $wp_locale->number_format['decimal_point'] ?? '.' ) );
	list( $thousands, $dot ) = $formats[ $format ] ?? $default;

	if ( 'slider' !== ( $field['number_format_type'] ?? '' ) ) {
		$value = str_replace( array( $thousands, html_entity_decode( $thousands, ENT_COMPAT ), $dot, html_entity_decode( $dot, ENT_COMPAT ) ), array( '', '', '.', '.' ), $value );
		if ( 1 === (int) ( $field['number_html5'] ?? 0 ) ) {
			$value = str_replace( ',', '.', $value );
		}
	}
	$value = (string) preg_replace( '/[^0-9\.\-]/', '', trim( $value ) );
	// Pods: leeg en niet het getal 0. Na het filter hierboven is dat alleen "" ("0" blijft 0).
	if ( '' === $value ) {
		return null;
	}

	$length = (int) ( $field['number_max_length'] ?? 12 );
	$length = $length < 1 || 64 < $length ? 64 : $length;
	$places = min( max( 0, (int) ( $field['number_decimals'] ?? 0 ) ), 30, $length );
	$value  = number_format( (float) $value, $places, '.', '' );
	if ( ! empty( $field['number_format_soft'] ) && str_contains( $value, '.' ) ) {
		$value = rtrim( rtrim( $value, '0' ), '.' );
	}
	return $value;
}

/**
 * Telefoon zoals PodsField_Phone::pre_save(). Internationaal (zoals de configuratie het gebruikt) blijft de invoer
 * staan; de andere formaten maken er cijfergroepen van. Hoogstens 25 tekens.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 */
function _ww_field_clean_phone( array $field, string $value ): string {
	$format = _ww_data_to_string( $field['phone_format'] ?? '' );
	$format = '' === $format ? '999-999-9999 x999' : $format;
	if ( 'international' !== $format ) {
		$number    = (string) preg_replace( '/([^0-9ext])/', '', (string) preg_replace( '/(\+\d+)/', '', $value ) );
		$number    = str_replace( array( 'ext', 'x', 't', 'e' ), array( '|', '|', '', '' ), $number );
		$parts     = explode( '|', $number );
		$number    = $parts[0];
		$extension = $parts[1] ?? '';
		$numbers   = str_split( $number, 3 );
		if ( isset( $numbers[3] ) ) {
			$numbers = array( $numbers[0], $numbers[1], $numbers[2] . implode( '', array_slice( $numbers, 3, 1 ) ) );
		} elseif ( isset( $numbers[1] ) ) {
			$numbers = array( $numbers[0], $numbers[1] );
		}
		if ( '(999) 999-9999 x999' === $format ) {
			$count = count( $numbers );
			$value = 1 === $count ? '' : ( 2 === $count ? implode( '-', $numbers ) : '(' . $numbers[0] . ') ' . $numbers[1] . '-' . $numbers[2] );
		} else {
			$value = implode( '999.999.9999 x999' === $format ? '.' : '-', $numbers );
		}
		if ( 1 === (int) ( $field['phone_enable_phone_extension'] ?? 0 ) && '' !== $extension ) {
			$value .= ' x' . $extension;
		}
	}
	return _ww_field_max_length( $value, (int) _ww_field_option( $field, 'phone_max_length', 25 ) );
}

/**
 * Website zoals PodsField_Website::validate_url(): http:// ervoor als er geen schema is, en leeg als het geen URL
 * is. Zonder website_format (zoals in de configuratie van het thema) blijft de rest staan zoals hij is; Pods doet dan
 * ook niets met website_allow_port. Alleen met website_format normal bouwt Pods de URL opnieuw op uit de delen
 * (zonder poort, tenzij website_allow_port). De andere formaten van Pods (no-www, force-www enzovoort) gebruikt de
 * configuratie niet; ze werken hier als zonder formaat.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 */
function _ww_field_clean_url( array $field, string $value ): string {
	if ( '' === $value || '0' === $value ) {
		return $value;
	}
	if ( ! str_contains( $value, '://' ) && ! str_starts_with( $value, '//' ) ) {
		$value = 'http://' . $value;
	}
	$url = wp_parse_url( $value );
	if ( ! is_array( $url ) || count( $url ) < 2 ) {
		return '';
	}
	if ( 'normal' !== ( $field['website_format'] ?? '' ) ) {
		return $value;
	}
	$url = array_merge(
		array(
			'scheme'   => 'http',
			'host'     => '',
			'port'     => '',
			'path'     => '/',
			'query'    => '',
			'fragment' => '',
		),
		$url
	);
	if ( 1 !== (int) ( $field['website_allow_port'] ?? 0 ) ) {
		$url['port'] = '';
	}
	$built = trim( $url['scheme'] . '://', ':' ) . $url['host'];
	if ( ! empty( $url['port'] ) ) {
		$built .= ':' . $url['port'];
	}
	$built   .= '/' . ltrim( (string) $url['path'], '/' );
	$query    = ltrim( (string) $url['query'], '?' );
	$fragment = ltrim( (string) $url['fragment'], '#' );
	$built   .= '' !== $query && '0' !== $query ? '?' . $query : '';
	$built   .= '' !== $fragment && '0' !== $fragment ? '#' . $fragment : '';
	return $built;
}

/*
 * Opslaan.
 */

/**
 * Slaat opgeschoonde waarden van een bericht op, zoals Pods (PodsAPI::save_meta() en save_relationships()). Zie
 * _ww_field_store_meta().
 *
 * @param array<string,array<string,mixed>> $fields Velden op naam.
 * @param array<string,mixed>               $data   Veldnaam => opgeschoonde waarde (_ww_field_clean()).
 */
function _ww_field_store_post( int $post_id, array $fields, array $data ): void {
	_ww_field_store_meta( 'post', $post_id, $fields, $data );
}

/**
 * Slaat opgeschoonde waarden van een term (een taxonomie-pod) op in de term meta, zoals Pods
 * (PodsAPI::save_term_meta() en save_relationships()). Zie _ww_field_store_meta(); een foto krijgt geen ouder.
 *
 * @param array<string,array<string,mixed>> $fields Velden op naam.
 * @param array<string,mixed>               $data   Veldnaam => opgeschoonde waarde (_ww_field_clean()).
 */
function _ww_field_store_term( int $term_id, array $fields, array $data ): void {
	_ww_field_store_meta( 'term', $term_id, $fields, $data );
}

/**
 * Slaat opgeschoonde waarden op als meta van een bericht ('post') of term ('term'), zoals Pods.
 *
 * - Eén rij met de waarde, ook "" en "0". null (een leeg getal) haalt de rij weg.
 * - Relatie en foto's: alle rijen weg; daarna _pods_{veld} met de lijst van ID's (ook bij één) en een rij per ID,
 *   in volgorde. Leeg: rijen en _pods_{veld} weg.
 * - Meerkeuze met één: alle rijen weg, _pods_{veld} weg, één rij met de waarde (ook leeg: een lege rij).
 * - Meerkeuze met meerdere: alle rijen weg, _pods_{veld} met de lijst en een rij per waarde. Leeg wordt het, zoals
 *   bij Pods, een lijst met één lege waarde en één lege rij.
 * - Foto's bij een bericht: daarna krijgt een foto zonder ouder het bericht als ouder
 *   (_ww_field_store_attachment_parents()). Bij een term niet, zoals bij Pods.
 * - Volgorde zoals Pods: eerst de gewone velden, dan de meerkeuzes, dan relaties en foto's.
 *
 * @param string                            $meta_type post of term.
 * @param array<string,array<string,mixed>> $fields    Velden op naam.
 * @param array<string,mixed>               $data      Veldnaam => opgeschoonde waarde (_ww_field_clean()).
 */
function _ww_field_store_meta( string $meta_type, int $object_id, array $fields, array $data ): void {
	$order = array(
		'plain'    => array(),
		'choice'   => array(),
		'relation' => array(),
	);
	foreach ( $data as $name => $value ) {
		$order[ _ww_field_store_kind( $fields[ $name ] ?? array() ) ][ (string) $name ] = $value;
	}

	foreach ( $order['plain'] as $name => $value ) {
		if ( null === $value ) {
			delete_metadata( $meta_type, $object_id, $name );
			continue;
		}
		update_metadata( $meta_type, $object_id, $name, wp_slash( is_bool( $value ) ? (int) $value : $value ) );
	}

	foreach ( $order['choice'] as $name => $value ) {
		$values = array_values( (array) ( is_array( $value ) && array() === $value ? '' : $value ) );
		delete_metadata( $meta_type, $object_id, $name );
		if ( _ww_fields_is_multi( $fields[ $name ] ) ) {
			update_metadata( $meta_type, $object_id, '_pods_' . $name, wp_slash( $values ) );
		} else {
			delete_metadata( $meta_type, $object_id, '_pods_' . $name );
		}
		foreach ( $values as $choice ) {
			add_metadata( $meta_type, $object_id, $name, wp_slash( $choice ) );
		}
	}

	foreach ( $order['relation'] as $name => $ids ) {
		$ids = array_map( 'intval', (array) $ids );
		delete_metadata( $meta_type, $object_id, $name );
		if ( array() === $ids ) {
			delete_metadata( $meta_type, $object_id, '_pods_' . $name );
			continue;
		}
		update_metadata( $meta_type, $object_id, '_pods_' . $name, $ids );
		foreach ( $ids as $id ) {
			add_metadata( $meta_type, $object_id, $name, $id );
		}
		if ( 'post' === $meta_type && 'file' === ( $fields[ $name ]['type'] ?? '' ) ) {
			_ww_field_store_attachment_parents( $object_id, $ids );
		}
	}
}

/**
 * Zet de ouder van foto's zonder ouder op het bericht, zoals PodsField_File::save(): alleen als de gebruiker de foto
 * zelf uploadde, hem mag bewerken, of hij van niemand is. Een foto met een ouder houdt die. Pods doet dit alleen voor
 * berichten; bij de Site-instellingen gebeurt niets. (Pods kijkt ook naar PODS_DISABLE_FILE_UPLOAD en verwante
 * constanten; die zet het thema niet.)
 *
 * @param int[] $ids ID's van foto's, in volgorde.
 */
function _ww_field_store_attachment_parents( int $post_id, array $ids ): void {
	$user = get_current_user_id();
	foreach ( $ids as $id ) {
		$attachment = get_post( $id );
		if ( ! $attachment instanceof WP_Post || 0 !== (int) $attachment->post_parent ) {
			continue;
		}
		$author = (int) $attachment->post_author;
		if ( 0 !== $author && ! ( $user && $author === $user ) && ! current_user_can( 'edit_post', $id ) ) {
			continue;
		}
		wp_update_post(
			array(
				'ID'          => $id,
				'post_parent' => $post_id,
				'post_type'   => $attachment->post_type,
			)
		);
	}
}

/**
 * Slaat één opgeschoonde waarde van de Site-instellingen op als optie {pod}_{veld}, zoals Pods
 * (PodsAPI::save_setting() en save_relationships()).
 *
 * - Relatie en foto's: de lijst van ID's; leeg haalt de optie weg.
 * - Meerkeuze met meerdere: de lijst, maar één keuze als tekst en leeg als "" (zoals Pods).
 * - De rest: de waarde, ook "" en "0"; ja/nee als 0 of 1.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @param mixed               $value Opgeschoonde waarde (_ww_field_clean()).
 */
function _ww_field_store_setting( string $pod, array $field, $value ): void {
	$option = $pod . '_' . _ww_data_to_string( $field['name'] ?? '' );
	$kind   = _ww_field_store_kind( $field );

	if ( 'relation' === $kind ) {
		$ids = array_map( 'intval', (array) $value );
		if ( array() === $ids ) {
			delete_option( $option );
			return;
		}
		update_option( $option, $ids );
		return;
	}

	if ( 'choice' === $kind && is_array( $value ) ) {
		$value = array_values( $value );
		if ( count( $value ) < 2 ) {
			$value = implode( '', $value );
		}
	}
	update_option( $option, is_bool( $value ) ? (int) $value : $value );
}
