<?php
/**
 * Iconen en de SVG-sprite: ww_icon().
 *
 * Elk bestand assets/icons/{naam}.svg van het child-thema (en van de parent, als die map er is) wordt een <symbol> in
 * één sprite in uploads/ww-assets/{hash}.svg. Schrijven, bijhouden en opruimen gaan zoals bij de samengevoegde CSS
 * (inc/assets.php); de bestandsnaam past op WW_SPRITE_PATTERN.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Namespaces die in een symbool mogen blijven; de sprite declareert ze op zijn root.
const WW_ICON_SVG_NS   = 'http://www.w3.org/2000/svg';
const WW_ICON_XLINK_NS = 'http://www.w3.org/1999/xlink';

/**
 * De iconen: naam => pad, uit assets/icons/ van de parent en daarna het child-thema (child wint bij dezelfde naam).
 * Alleen namen met a-z, 0-9 en -; gesorteerd op naam.
 *
 * @return array<string,string>
 */
function _ww_icon_files(): array {
	$files = array();
	foreach ( array_unique( array( get_template_directory(), get_stylesheet_directory() ) ) as $dir ) {
		$dir = $dir . '/assets/icons/';
		foreach ( glob( $dir . '*.svg' ) ?: array() as $file ) {
			$name = basename( $file, '.svg' );
			if ( preg_match( '/^[a-z0-9-]+$/', $name ) && is_file( $dir . $name . '.svg' ) ) {
				$files[ $name ] = $dir . $name . '.svg';
			}
		}
	}
	ksort( $files, SORT_STRING );
	return $files;
}

/**
 * Zet een SVG-bestand om naar één <symbol id="{naam}">, verkleind en opgeschoond. Geeft '' als het icoon overgeslagen
 * wordt: ongeldige XML, geen root <svg>, geen maat, of een <style>-element of class-attribuut binnen de root (die
 * klassen zouden in de sprite botsen). Bij WP_DEBUG volgt dan een melding.
 *
 * Opgeschoond: XML-declaratie, doctype, commentaar, <title>, <desc>, <metadata>, <script>, <foreignObject>, on*-
 * attributen, href/xlink:href die niet met # beginnen, entiteitsverwijzingen (die worden nooit uitgevouwen) en
 * elementen en attributen uit andere namespaces dan SVG en xlink (van tekenprogramma's; met een niet-gedeclareerd
 * voorvoegsel zou de sprite geen geldige XML meer zijn). Elke id krijgt het voorvoegsel {naam}-, met de verwijzingen
 * erheen.
 *
 * @param string $name Naam van het icoon (a-z, 0-9 en -).
 * @param string $svg  Inhoud van het SVG-bestand.
 */
function _ww_icon_symbol( string $name, string $svg ): string {
	if ( '' === trim( $svg ) ) {
		return _ww_icon_skip( $name, 'het bestand is leeg' );
	}
	$internal = libxml_use_internal_errors( true );
	$document = new DOMDocument();
	// Zonder LIBXML_NOENT en LIBXML_DTDLOAD: geen entiteiten uitvouwen en geen externe DTD; LIBXML_NONET: geen netwerk.
	$loaded = $document->loadXML( $svg, LIBXML_NONET );
	libxml_clear_errors();
	libxml_use_internal_errors( $internal );

	$root = $document->documentElement;
	if ( ! $loaded || ! $root || 'svg' !== $root->localName ) {
		return _ww_icon_skip( $name, 'het is geen geldige SVG' );
	}

	$view_box = trim( $root->getAttribute( 'viewBox' ) );
	if ( '' === $view_box ) {
		$size = '/^\s*(\d+(?:\.\d+)?)\s*(?:px)?\s*$/';
		if ( ! preg_match( $size, $root->getAttribute( 'width' ), $width ) || ! preg_match( $size, $root->getAttribute( 'height' ), $height ) ) {
			return _ww_icon_skip( $name, 'het heeft geen viewBox en geen width en height' );
		}
		$view_box = '0 0 ' . $width[1] . ' ' . $height[1];
	}

	$symbol = '<symbol id="' . esc_attr( $name ) . '" viewBox="' . _ww_icon_escape( $view_box ) . '"';
	$keep   = array( 'fill', 'stroke', 'stroke-width', 'stroke-linecap', 'stroke-linejoin', 'stroke-miterlimit', 'fill-rule', 'clip-rule', 'color', 'opacity' );
	foreach ( $root->attributes ?? array() as $attribute ) {
		if ( null === $attribute->namespaceURI && in_array( $attribute->localName, $keep, true ) ) {
			$symbol .= ' ' . $attribute->localName . '="' . _ww_icon_escape( _ww_icon_references( $name, $attribute->value ) ) . '"';
		}
	}

	$inner = '';
	foreach ( $root->childNodes as $child ) {
		$part = _ww_icon_node( $name, $child );
		if ( null === $part ) {
			return _ww_icon_skip( $name, 'het heeft een <style>-element of class-attributen; exporteer het met presentatie-attributen' );
		}
		$inner .= $part;
	}
	return $symbol . '>' . $inner . '</symbol>';
}

/**
 * Een knoop binnen de root als verkleinde, opgeschoonde XML; '' voor wat weg moet, null als het hele icoon
 * overgeslagen moet worden (een <style>-element of class-attribuut).
 *
 * @param string  $name Naam van het icoon, voorvoegsel voor de id's.
 * @param DOMNode $node Knoop.
 */
function _ww_icon_node( string $name, DOMNode $node ): ?string {
	if ( $node instanceof DOMText ) {
		// DOMCdataSection is ook een DOMText. Witruimte tussen tags valt weg.
		return '' === trim( $node->data ) ? '' : _ww_icon_escape( $node->data );
	}
	if ( ! $node instanceof DOMElement ) {
		// Commentaar, verwerkingsinstructies en entiteitsverwijzingen.
		return '';
	}
	if ( null !== $node->namespaceURI && WW_ICON_SVG_NS !== $node->namespaceURI ) {
		return '';
	}
	$tag = $node->localName;
	if ( 'style' === $tag ) {
		return null;
	}
	if ( in_array( $tag, array( 'title', 'desc', 'metadata', 'script', 'foreignObject' ), true ) ) {
		return '';
	}

	$xml = '<' . $tag;
	foreach ( $node->attributes ?? array() as $attribute ) {
		$attribute_name = $attribute->localName;
		if ( WW_ICON_XLINK_NS === $attribute->namespaceURI ) {
			$prefix = 'xlink:';
		} elseif ( null === $attribute->namespaceURI ) {
			$prefix = '';
		} else {
			continue;
		}
		if ( '' === $prefix && 'class' === $attribute_name ) {
			return null;
		}
		if ( str_starts_with( strtolower( $attribute_name ), 'on' ) ) {
			continue;
		}
		$value = $attribute->value;
		if ( 'href' === $attribute_name ) {
			if ( ! str_starts_with( $value, '#' ) ) {
				continue;
			}
			$value = '#' . $name . '-' . substr( $value, 1 );
		} elseif ( '' === $prefix && 'id' === $attribute_name ) {
			$value = $name . '-' . $value;
		} else {
			$value = _ww_icon_references( $name, $value );
		}
		$xml .= ' ' . $prefix . $attribute_name . '="' . _ww_icon_escape( $value ) . '"';
	}

	$inner = '';
	foreach ( $node->childNodes as $child ) {
		$part = _ww_icon_node( $name, $child );
		if ( null === $part ) {
			return null;
		}
		$inner .= $part;
	}
	return '' === $inner ? $xml . '/>' : $xml . '>' . $inner . '</' . $tag . '>';
}

/**
 * Laat url(#id) in een attribuutwaarde naar de id met voorvoegsel wijzen: url(#a) wordt url(#{naam}-a).
 *
 * @param string $name  Naam van het icoon.
 * @param string $value Attribuutwaarde.
 */
function _ww_icon_references( string $name, string $value ): string {
	return (string) preg_replace( '/url\(\s*(["\']?)#([^\s"\')]+)\1\s*\)/', 'url($1#' . $name . '-$2$1)', $value );
}

/**
 * Escapet tekst voor XML, ook binnen een attribuut tussen dubbele aanhalingstekens.
 *
 * @param string $text Tekst.
 */
function _ww_icon_escape( string $text ): string {
	return htmlspecialchars( $text, ENT_XML1 | ENT_QUOTES, 'UTF-8' );
}

/**
 * Slaat een icoon over, met een melding bij WP_DEBUG.
 *
 * @param string $name   Naam van het icoon.
 * @param string $reason Waarom.
 * @return string Altijd ''.
 */
function _ww_icon_skip( string $name, string $reason ): string {
	if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		_doing_it_wrong( '_ww_icon_symbol', esc_html( 'Icoon "' . $name . '" is overgeslagen: ' . $reason . '.' ), '0.20.0' );
	}
	return '';
}

/**
 * URL van de sprite met alle iconen, of '' als er geen (bruikbare) iconen zijn of schrijven niet lukt. De naam is een
 * hash van de paden, wijzigingsdatums en groottes van de bronbestanden en de parent-versie; een nieuwe sprite leegt
 * de paginacache en de vorige wordt na WW_STYLES_KEEP opgeruimd (_ww_styles_track()).
 *
 * De uitkomst blijft per verzoek onthouden. Met $fresh = true wordt hij opnieuw bepaald, met dezelfde bijwerkingen
 * (schrijven en bijhouden); zonder bijwerkingen vergeten kan met _ww_icon_sprite_url_reset().
 *
 * @param bool $fresh Opnieuw bepalen in plaats van de onthouden uitkomst te geven.
 */
function _ww_icon_sprite_url( bool $fresh = false ): string {
	if ( isset( $GLOBALS['ww_icon_sprite_url'] ) && ! $fresh ) {
		return $GLOBALS['ww_icon_sprite_url'];
	}
	$GLOBALS['ww_icon_sprite_url'] = '';
	$files                         = _ww_icon_files();
	if ( array() === $files ) {
		return '';
	}

	$parts = array( WW_BASE_VERSION );
	foreach ( $files as $file ) {
		$parts[] = array( $file, filemtime( $file ), filesize( $file ) );
	}
	$name    = substr( md5( (string) wp_json_encode( $parts ) ), 0, WW_STYLES_HASH_LENGTH ) . '.svg';
	$uploads = wp_get_upload_dir();
	$path    = $uploads['basedir'] . '/' . WW_STYLES_DIR . '/' . $name;

	if ( ! is_file( $path ) ) {
		$symbols = '';
		foreach ( $files as $icon => $file ) {
			$svg      = file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- lokaal themabestand.
			$symbols .= false === $svg ? '' : _ww_icon_symbol( $icon, $svg );
		}
		if ( '' === $symbols || ! _ww_write_asset( $path, '<svg xmlns="' . WW_ICON_SVG_NS . '" xmlns:xlink="' . WW_ICON_XLINK_NS . '">' . $symbols . '</svg>' ) ) {
			return '';
		}
	}
	_ww_styles_track( 'icons', $name );
	$GLOBALS['ww_icon_sprite_url'] = $uploads['baseurl'] . '/' . WW_STYLES_DIR . '/' . $name;
	return $GLOBALS['ww_icon_sprite_url'];
}

/**
 * Vergeet wat deze verzoek over iconen onthouden is: de sprite-URL, de symbolen en de wachtrij voor de footer. Zonder
 * bijwerkingen; de volgende aanroep bepaalt alles opnieuw. Voor tests.
 */
function _ww_icon_sprite_url_reset(): void {
	unset( $GLOBALS['ww_icon_sprite_url'], $GLOBALS['ww_icon_symbols'], $GLOBALS['ww_inline_icons'] );
}

/**
 * Het <symbol> van een icoon, of '' als het icoon niet bestaat of is overgeslagen. Per verzoek onthouden, dus een
 * melding voor een overgeslagen icoon komt één keer.
 *
 * @param string $name Naam van het icoon.
 */
function _ww_icon_symbol_for( string $name ): string {
	if ( ! isset( $GLOBALS['ww_icon_symbols'][ $name ] ) ) {
		$file = _ww_icon_files()[ $name ] ?? '';
		$svg  = '' === $file ? false : file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- lokaal themabestand.
		$GLOBALS['ww_icon_symbols'][ $name ] = false === $svg ? '' : _ww_icon_symbol( $name, $svg );
	}
	return $GLOBALS['ww_icon_symbols'][ $name ];
}

/**
 * Een icoon als <svg> met een verwijzing naar de sprite, voor in een template. Het icoon is een bestand
 * assets/icons/{naam}.svg in het child-thema (of in assets/icons/ van de parent; het child wint). Geeft '' voor een
 * onbekend of overgeslagen icoon (bij WP_DEBUG met een melding). De verwijzing is een pad vanaf de root van de site,
 * zonder host: een <use> naar een ander domein negeert de browser, ook bij een CDN of een www-afwijking. Kan de sprite
 * niet geschreven worden, dan verwijst het icoon naar een symbool dat in de footer inline wordt afgedrukt; een icoon
 * dat na wp_footer (prioriteit 20) wordt aangeroepen blijft dan leeg, zonder melding.
 *
 * Standaard is het icoon versiering (aria-hidden, focusable="false"). Met $attr['label'] heeft het betekenis
 * (role="img", aria-label); $attr['aria-label'] telt als label als label ontbreekt. $attr['class'] komt bij de
 * klassen; andere sleutels worden attributen (waarde true: zonder waarde, false of null: weggelaten). Nooit
 * overgenomen: width, height, role, aria-label, aria-hidden en focusable; die zet de functie zelf, zodat ze elkaar
 * niet tegenspreken.
 *
 * @param string               $name Naam van het icoon (a-z, 0-9 en -).
 * @param int                  $size Breedte en hoogte in pixels.
 * @param array<string,mixed>  $attr Extra attributen op de <svg>.
 * @return string HTML, of ''.
 */
function ww_icon( string $name, int $size = 24, array $attr = array() ): string {
	$symbol = _ww_icon_symbol_for( $name );
	if ( '' === $symbol ) {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			_doing_it_wrong( __FUNCTION__, esc_html( sprintf( 'Het icoon "%s" bestaat niet: zet assets/icons/%s.svg in het child-thema.', $name, $name ) ), '0.20.0' );
		}
		return '';
	}

	$sprite = _ww_icon_sprite_url();
	if ( '' === $sprite ) {
		$GLOBALS['ww_inline_icons'][ $name ] = $symbol;
	}

	$classes = 'ww-icon ww-icon--' . $name;
	if ( isset( $attr['class'] ) && is_scalar( $attr['class'] ) && '' !== trim( (string) $attr['class'] ) ) {
		$classes .= ' ' . trim( (string) $attr['class'] );
	}
	$label = isset( $attr['label'] ) && is_scalar( $attr['label'] ) ? (string) $attr['label'] : '';
	if ( '' === $label && isset( $attr['aria-label'] ) && is_scalar( $attr['aria-label'] ) ) {
		$label = (string) $attr['aria-label'];
	}
	unset( $attr['class'], $attr['label'] );

	$html = ' class="' . esc_attr( $classes ) . '" width="' . (int) $size . '" height="' . (int) $size . '"';
	// Altijd overgeslagen, met of zonder label: zo staan role/aria-label nooit naast aria-hidden.
	$set = array( 'class', 'width', 'height', 'role', 'aria-label', 'aria-hidden', 'focusable' );
	if ( '' !== $label ) {
		$html .= ' role="img" aria-label="' . esc_attr( $label ) . '"';
	} else {
		$html .= ' aria-hidden="true" focusable="false"';
	}
	foreach ( $attr as $key => $value ) {
		$key = (string) $key;
		if ( false === $value || null === $value || ! preg_match( '/^[a-zA-Z_:][-a-zA-Z0-9_:.]*$/', $key ) || in_array( strtolower( $key ), $set, true ) ) {
			continue;
		}
		$set[] = strtolower( $key );
		if ( true === $value ) {
			$html .= ' ' . $key;
		} elseif ( is_scalar( $value ) ) {
			$html .= ' ' . $key . '="' . esc_attr( (string) $value ) . '"';
		}
	}

	return '<svg' . $html . '><use href="' . esc_url( wp_make_link_relative( $sprite ) . '#' . $name ) . '"></use></svg>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- namen gecontroleerd, waarden ge-escaped.
}

/**
 * Drukt de symbolen af die ww_icon() in de terugval (de sprite kon niet geschreven worden) heeft aangevraagd: één keer
 * per icoon, in een verborgen <svg>. Zonder aangevraagde symbolen gebeurt er niets.
 */
function _ww_print_inline_icons(): void {
	if ( is_admin() || empty( $GLOBALS['ww_inline_icons'] ) ) {
		return;
	}
	echo '<svg xmlns="' . esc_url( WW_ICON_SVG_NS ) . '" hidden aria-hidden="true">' . implode( '', $GLOBALS['ww_inline_icons'] ) . "</svg>
"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- symbolen door _ww_icon_symbol() opgeschoond en ge-escaped.
	$GLOBALS['ww_inline_icons'] = array();
}
add_action( 'wp_footer', '_ww_print_inline_icons', 20 );
