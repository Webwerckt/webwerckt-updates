<?php
/**
 * Mail (beslissing 0034): de SMTP-aansluiting.
 *
 * Zet de mailer van WordPress op SMTP met de instellingen van de site en verstuurt de mail zelf. Het wachtwoord komt uit
 * `WW_MAIL_SMTP_PASSWORD` of de versleutelde opslag en komt nooit in een foutmelding.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once dirname( __DIR__ ) . '/class-ww-phpmailer.php';

/**
 * Verstuurt mail via een SMTP-server.
 */
class WW_Mail_Transport_Smtp implements WW_Mail_Transport {

	/**
	 * Id van de aansluiting.
	 */
	public function id(): string {
		return 'smtp';
	}

	/**
	 * Naam op het scherm.
	 */
	public function label(): string {
		return 'SMTP';
	}

	/**
	 * Velddefinities voor het scherm.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public function settings(): array {
		return array(
			array(
				'name'     => 'host',
				'label'    => __( 'Server', 'webwerckt-base' ),
				'type'     => 'text',
				'default'  => '',
				'required' => true,
				'secret'   => false,
			),
			array(
				'name'     => 'port',
				'label'    => __( 'Poort', 'webwerckt-base' ),
				'type'     => 'number',
				'default'  => 587,
				'required' => false,
				'secret'   => false,
			),
			array(
				'name'     => 'secure',
				'label'    => __( 'Versleuteling', 'webwerckt-base' ),
				'type'     => 'select',
				'options'  => array(
					'tls' => __( 'TLS (STARTTLS)', 'webwerckt-base' ),
					'ssl' => __( 'SSL', 'webwerckt-base' ),
					''    => __( 'Geen', 'webwerckt-base' ),
				),
				'default'  => 'tls',
				'required' => false,
				'secret'   => false,
			),
			array(
				'name'     => 'username',
				'label'    => __( 'Gebruiker', 'webwerckt-base' ),
				'type'     => 'text',
				'default'  => '',
				'required' => false,
				'secret'   => false,
			),
			array(
				'name'     => 'password',
				'label'    => __( 'Wachtwoord', 'webwerckt-base' ),
				'type'     => 'password',
				'default'  => '',
				'required' => false,
				'secret'   => true,
				'constant' => 'WW_MAIL_SMTP_PASSWORD',
			),
		);
	}

	/**
	 * De server, schoongemaakt.
	 */
	private function host(): string {
		$host = _ww_mail_setting( 'smtp', 'host', '' );
		return is_string( $host ) ? trim( $host ) : '';
	}

	/**
	 * De gebruiker, schoongemaakt.
	 */
	private function username(): string {
		$user = _ww_mail_setting( 'smtp', 'username', '' );
		return is_string( $user ) ? trim( $user ) : '';
	}

	/**
	 * Het wachtwoord, of null als het ontbreekt of niet te lezen is.
	 */
	private function password(): ?string {
		return _ww_mail_secret( 'smtp', 'password', 'WW_MAIL_SMTP_PASSWORD' );
	}

	/**
	 * Of de server is ingevuld en, bij een gebruiker, ook een leesbaar wachtwoord.
	 */
	public function is_configured(): bool {
		if ( '' === $this->host() ) {
			return false;
		}
		return '' === $this->username() || null !== $this->password();
	}

	/**
	 * Zet de mailer op SMTP volgens de instellingen.
	 *
	 * @param WW_PHPMailer $mail De mailer.
	 */
	public function configure( WW_PHPMailer $mail ): void {
		$port   = (int) _ww_mail_setting( 'smtp', 'port', 587 );
		$secure = _ww_mail_setting( 'smtp', 'secure', 'tls' );
		$secure = ( is_string( $secure ) && in_array( $secure, array( '', 'ssl', 'tls' ), true ) ) ? $secure : 'tls';
		$user   = $this->username();

		$mail->isSMTP();
		$mail->Host        = $this->host();
		$mail->Port        = $port > 0 ? $port : 587;
		$mail->SMTPSecure  = $secure;
		$mail->SMTPAutoTLS = '' !== $secure;
		$mail->SMTPAuth    = '' !== $user;
		$mail->Username    = $user;
		$mail->Password    = '' !== $user ? (string) $this->password() : '';
		$mail->SMTPDebug   = 0;
	}

	/**
	 * Verstuurt de mail. `wp_mail()` heeft de mailer als `mail` opgebouwd (zonder To: en Subject: in de header en met Bcc),
	 * dus na het instellen wordt de mail opnieuw opgebouwd voor SMTP.
	 *
	 * @param WW_PHPMailer $mail De mailer, na preSend().
	 * @return true|WP_Error
	 */
	public function send( WW_PHPMailer $mail ): true|WP_Error {
		try {
			$this->configure( $mail );
			if ( ! $mail->preSend() ) {
				return new WP_Error( 'ww_mail_smtp', $mail->ErrorInfo );
			}
			if ( ! $mail->postSend() ) {
				return new WP_Error( 'ww_mail_smtp', $mail->ErrorInfo );
			}
		} catch ( PHPMailer\PHPMailer\Exception $e ) {
			$message = '' !== $mail->ErrorInfo ? $mail->ErrorInfo : $e->getMessage();
			return new WP_Error( 'ww_mail_smtp', $message );
		}
		return true;
	}
}
