<?php
/**
 * Mail (beslissing 0034): de Brevo-aansluiting (HTTP-API).
 *
 * Zet de mail die WordPress in de mailer heeft klaargezet om in de JSON van `POST /v3/smtp/email` en verstuurt die met
 * `wp_remote_post()`. De sleutel komt uit `WW_MAIL_BREVO_KEY` of de versleutelde opslag en komt nooit in een foutmelding:
 * staat hij in een antwoord van Brevo, dan wordt hij vervangen door `***`.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once dirname( __DIR__ ) . '/class-ww-phpmailer.php';

/**
 * Verstuurt mail via de HTTP-API van Brevo.
 */
class WW_Mail_Transport_Brevo implements WW_Mail_Transport {

	/**
	 * Adres van de API.
	 */
	const URL = 'https://api.brevo.com/v3/smtp/email';

	/**
	 * Id van de aansluiting.
	 */
	public function id(): string {
		return 'brevo';
	}

	/**
	 * Naam op het scherm.
	 */
	public function label(): string {
		return 'Brevo (API)';
	}

	/**
	 * Velddefinities voor het scherm.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public function settings(): array {
		return array(
			array(
				'name'     => 'key',
				'label'    => __( 'API-sleutel', 'webwerckt-base' ),
				'type'     => 'password',
				'default'  => '',
				'required' => true,
				'secret'   => true,
				'constant' => 'WW_MAIL_BREVO_KEY',
			),
		);
	}

	/**
	 * De sleutel, of null als die ontbreekt of niet te lezen is.
	 */
	private function key(): ?string {
		$key = _ww_mail_secret( 'brevo', 'key', 'WW_MAIL_BREVO_KEY' );
		return ( null === $key || '' === $key ) ? null : $key;
	}

	/**
	 * Of er een leesbare sleutel is.
	 */
	public function is_configured(): bool {
		return null !== $this->key();
	}

	/**
	 * Een adres voor Brevo: `{email, name}`, zonder `name` als die leeg is.
	 *
	 * @param string $email Adres.
	 * @param string $name  Naam.
	 * @return array<string,string>
	 */
	private function address( string $email, string $name ): array {
		$address = array( 'email' => $email );
		if ( '' !== $name ) {
			$address['name'] = $name;
		}
		return $address;
	}

	/**
	 * Een lijst adressen van PHPMailer (`[adres, naam]`) als lijst voor Brevo.
	 *
	 * @param array<mixed> $list Adressen uit de mailer.
	 * @return array<int,array<string,string>>
	 */
	private function addresses( array $list ): array {
		$addresses = array();
		foreach ( $list as $entry ) {
			if ( is_array( $entry ) && isset( $entry[0] ) ) {
				$addresses[] = $this->address( (string) $entry[0], (string) ( $entry[1] ?? '' ) );
			}
		}
		return $addresses;
	}

	/**
	 * De body voor Brevo uit de mailer.
	 *
	 * @param WW_PHPMailer $mail De mailer.
	 * @return array<string,mixed>|WP_Error De body, of een fout als een bijlage niet te lezen is.
	 */
	public function payload( WW_PHPMailer $mail ): array|WP_Error {
		// phpcs:disable WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- PHPMailer.
		$payload = array(
			'sender' => $this->address( $mail->From, $mail->FromName ),
		);
		foreach (
			array(
				'to'  => $mail->getToAddresses(),
				'cc'  => $mail->getCcAddresses(),
				'bcc' => $mail->getBccAddresses(),
			) as $key => $list
		) {
			$addresses = $this->addresses( $list );
			if ( array() !== $addresses ) {
				$payload[ $key ] = $addresses;
			}
		}

		$reply_to = $this->addresses( array_values( $mail->getReplyToAddresses() ) );
		if ( array() !== $reply_to ) {
			$payload['replyTo'] = $reply_to[0];
		}

		$payload['subject'] = $mail->Subject;
		// preSend() zet ContentType op multipart/alternative zodra er een AltBody is; PHPMailer stuurt Body dan als HTML.
		if ( str_starts_with( strtolower( (string) $mail->ContentType ), 'text/html' ) || $mail->alternativeExists() ) {
			$payload['htmlContent'] = $mail->Body;
			if ( '' !== $mail->AltBody ) {
				$payload['textContent'] = $mail->AltBody;
			}
		} else {
			$payload['textContent'] = $mail->Body;
		}
		// phpcs:enable WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase

		$headers = array();
		foreach ( $mail->getCustomHeaders() as $header ) {
			if ( is_array( $header ) && isset( $header[0] ) ) {
				$headers[ (string) $header[0] ] = (string) ( $header[1] ?? '' );
			}
		}
		if ( array() !== $headers ) {
			$payload['headers'] = $headers;
		}

		$attachments = array();
		foreach ( $mail->getAttachments() as $attachment ) {
			$name = (string) ( $attachment[2] ?? '' );
			if ( ! empty( $attachment[5] ) ) {
				$content = (string) $attachment[0];
			} else {
				$path    = (string) $attachment[0];
				$content = ( '' !== $path && is_file( $path ) && is_readable( $path ) ) ? file_get_contents( $path ) : false; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- lokaal bestand.
				if ( false === $content ) {
					return new WP_Error(
						'ww_mail_brevo_attachment',
						/* translators: %s: naam van de bijlage. */
						sprintf( __( 'Brevo: bijlage %s is niet te lezen.', 'webwerckt-base' ), $name )
					);
				}
			}
			$attachments[] = array(
				'name'    => $name,
				'content' => base64_encode( $content ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Brevo wil de inhoud als base64.
			);
		}
		if ( array() !== $attachments ) {
			$payload['attachment'] = $attachments;
		}

		return $payload;
	}

	/**
	 * Vervangt de sleutel in een tekst door `***`.
	 *
	 * @param string $text Tekst.
	 * @param string $key  Sleutel.
	 */
	private function scrub( string $text, string $key ): string {
		return '' === $key ? $text : str_replace( $key, '***', $text );
	}

	/**
	 * Verstuurt de mail naar Brevo.
	 *
	 * @param WW_PHPMailer $mail De mailer, na preSend().
	 * @return true|WP_Error
	 */
	public function send( WW_PHPMailer $mail ): true|WP_Error {
		$mail->ww_transport   = $this->id();
		$mail->ww_provider_id = '';

		$key = $this->key();
		if ( null === $key ) {
			return new WP_Error(
				'ww_mail_not_configured',
				/* translators: %s: naam van de aansluiting. */
				sprintf( __( '%s is niet ingesteld.', 'webwerckt-base' ), $this->label() )
			);
		}

		$payload = $this->payload( $mail );
		if ( is_wp_error( $payload ) ) {
			return $payload;
		}
		$body = wp_json_encode( $payload );
		if ( false === $body ) {
			return new WP_Error( 'ww_mail_brevo', __( 'Brevo: de mail kon niet worden omgezet naar JSON.', 'webwerckt-base' ) );
		}

		$response = wp_remote_post(
			self::URL,
			array(
				'timeout' => 15,
				'headers' => array(
					'api-key'      => $key,
					'content-type' => 'application/json',
					'accept'       => 'application/json',
				),
				'body'    => $body,
			)
		);
		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'ww_mail_brevo', $this->scrub( 'Brevo: ' . $response->get_error_message(), $key ) );
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$json   = json_decode( wp_remote_retrieve_body( $response ), true );
		$json   = is_array( $json ) ? $json : array();

		if ( $status < 200 || $status > 299 ) {
			$code    = isset( $json['code'] ) && is_scalar( $json['code'] ) ? (string) $json['code'] : '';
			$message = isset( $json['message'] ) && is_scalar( $json['message'] ) ? (string) $json['message'] : '';
			$text    = (string) $status;
			if ( '' !== $code || '' !== $message ) {
				$text .= ' ' . $code . ': ' . $message;
			}
			return new WP_Error( 'ww_mail_brevo', $this->scrub( $text, $key ) );
		}

		$provider_id = '';
		if ( isset( $json['messageId'] ) && is_scalar( $json['messageId'] ) ) {
			$provider_id = (string) $json['messageId'];
		} elseif ( isset( $json['messageIds'] ) && is_array( $json['messageIds'] ) ) {
			$first       = reset( $json['messageIds'] );
			$provider_id = is_scalar( $first ) ? (string) $first : '';
		}
		$mail->ww_provider_id = $provider_id;
		return true;
	}
}
