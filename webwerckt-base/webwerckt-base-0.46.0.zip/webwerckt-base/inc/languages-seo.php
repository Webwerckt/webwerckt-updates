<?php
/**
 * Meertalig (beslissing 0040), onderdeel seo: hreflang en og:locale:alternate.
 *
 * Deze uitvoer komt in de paginacache voor bezoekers, dus een verborgen taal staat er nooit in, ook niet voor een
 * ingelogde redacteur (_ww_visible_language_codes(), niet _ww_routable_language_codes()). Een pagina met noindex krijgt
 * niets. og:locale zelf volgt de locale al via get_locale() (inc/seo.php).
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Een WordPress-locale als BCP 47-taalcode: en_GB wordt en-GB. Een variant (de_DE_formal) valt weg, want die is geen
 * geldige BCP 47-subtag. Een ongeldige locale geeft de taalcode.
 *
 * @param string $locale WordPress-locale.
 * @param string $code   Taalcode van de module, voor als de locale niet geldig is.
 */
function _ww_languages_bcp47( string $locale, string $code ): string {
	if ( 1 !== preg_match( '/^([a-z]{2,3})(?:_([A-Z]{2}))?(?:_[a-z0-9]+)?$/', $locale, $match ) ) {
		return $code;
	}
	return $match[1] . ( isset( $match[2] ) ? '-' . $match[2] : '' );
}

/**
 * Of de huidige pagina geen hreflang krijgt: noindex volgens de SEO van het thema, of met een SEO-plugin de 404 en de
 * zoekresultaten.
 */
function _ww_languages_seo_noindex(): bool {
	return _ww_seo_enabled() ? _ww_seo_is_noindex() : _ww_is_noindex_page();
}

/**
 * De adressen van de huidige pagina per zichtbare taal (taalcode => URL), voor hreflang en og:locale:alternate.
 *
 * - Een bericht of pagina (ook de voorpagina en de berichtenpagina): alleen de gepubliceerde leden van de groep, en
 *   niets bij minder dan twee.
 * - Een archief (ook een term en de homepage met berichten): elke zichtbare taal, vanaf de canonical van het archief of
 *   anders het adres van het verzoek zonder querystring; niets als alleen de standaardtaal zichtbaar is. Een
 *   termarchief krijgt per taal de slug van die taal (_ww_languages_term_archive_urls()).
 * - Leeg zonder module, bij noindex en op een bericht van een niet-vertaalbaar post type.
 *
 * @return array<string,string>
 */
function _ww_languages_alternate_urls(): array {
	if ( ! _ww_languages_active() || _ww_languages_seo_noindex() ) {
		return array();
	}
	$codes = array_merge( array( _ww_default_language() ), _ww_visible_language_codes() );
	$group = _ww_languages_current_group();
	$urls  = array();

	if ( null !== $group ) {
		foreach ( $codes as $code ) {
			$id   = $group[ $code ] ?? 0;
			$link = $id > 0 && 'publish' === get_post_status( $id ) ? get_permalink( $id ) : false;
			if ( is_string( $link ) && '' !== $link ) {
				$urls[ $code ] = $link;
			}
		}
		return count( $urls ) > 1 ? $urls : array();
	}
	if ( is_singular() ) {
		return array();
	}

	// Een termarchief: per taal de slug van die taal (inc/languages-terms.php). Elk adres krijgt de vertaalde URL-basis
	// van zijn taal (inc/languages-bases.php).
	$urls = _ww_languages_term_archive_urls( $codes );
	if ( null === $urls ) {
		$urls = array();
		$base = _ww_seo_archive_canonical();
		if ( '' === $base ) {
			$base = (string) preg_replace( '/[?#].*$/s', '', _ww_languages_request_url() );
		}
		foreach ( $codes as $code ) {
			$urls[ $code ] = _ww_language_base_relink( $base, $code );
		}
	} else {
		foreach ( $urls as $code => $url ) {
			$urls[ $code ] = _ww_language_base_swap( $url, $code );
		}
	}
	// Zijn alle extra talen verborgen, dan is de site voor bezoekers een site in één taal: geen hreflang.
	return count( $urls ) > 1 ? $urls : array();
}

/**
 * De hreflang-links van de huidige pagina: BCP 47-code => URL, plus x-default naar de standaardtaal als die erbij is.
 * Leeg bij noindex of zonder vertalingen.
 *
 * @return array<string,string>
 */
function _ww_languages_alternates(): array {
	$urls       = _ww_languages_alternate_urls();
	$alternates = array();
	foreach ( $urls as $code => $url ) {
		$language = _ww_language( $code );
		if ( null !== $language ) {
			$alternates[ _ww_languages_bcp47( $language['locale'], $code ) ] = $url;
		}
	}
	if ( array() !== $alternates && isset( $urls[ _ww_default_language() ] ) ) {
		$alternates['x-default'] = $urls[ _ww_default_language() ];
	}
	return $alternates;
}

/**
 * Actie wp_head (prioriteit 3): de hreflang-links.
 */
function _ww_languages_print_hreflang(): void {
	foreach ( _ww_languages_alternates() as $hreflang => $url ) {
		printf( '<link rel="alternate" hreflang="%s" href="%s" />' . "\n", esc_attr( $hreflang ), esc_url( $url ) );
	}
}

/**
 * Filter ww_seo_social_tags: og:locale:alternate per andere zichtbare taal met een gepubliceerde versie van deze pagina,
 * direct na og:locale. In het formaat van og:locale (en_GB).
 *
 * @param mixed $tags Tags van _ww_seo_social_tags().
 * @return mixed
 */
function _ww_languages_social_tags( mixed $tags ): mixed {
	if ( ! is_array( $tags ) ) {
		return $tags;
	}
	$extra = array();
	foreach ( array_keys( _ww_languages_alternate_urls() ) as $code ) {
		$language = _ww_language( $code );
		if ( null !== $language && ww_current_language() !== $code ) {
			$extra[] = array( 'property', 'og:locale:alternate', $language['locale'] );
		}
	}
	if ( array() === $extra ) {
		return $tags;
	}

	$position = count( $tags );
	foreach ( array_values( $tags ) as $index => $tag ) {
		if ( is_array( $tag ) && 'og:locale' === ( $tag[1] ?? null ) ) {
			$position = $index + 1;
			break;
		}
	}
	$tags = array_values( $tags );
	array_splice( $tags, $position, 0, $extra );
	return $tags;
}

/**
 * Hangt de hooks van dit onderdeel op. Draait ook na init (zie _ww_languages_boot()). Met alleen de standaardtaal is er
 * niets om naar te verwijzen.
 */
function _ww_languages_boot_seo(): void {
	if ( array() === _ww_extra_language_codes() ) {
		return;
	}
	add_action( 'wp_head', '_ww_languages_print_hreflang', 3 );
	add_filter( 'ww_seo_social_tags', '_ww_languages_social_tags' );
}
