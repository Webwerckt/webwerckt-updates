<?php
/**
 * REST-endpoint voor meer laden: GET /wp-json/ww/v1/cards.
 *
 * Publieke GET zonder nonce (een nonce verloopt in pagina's uit de cache).
 * Geeft alleen publieke items van post types die via ww_register_archive() zijn aangemeld.
 * Met Meertalig geeft het de kaarten in de taal van de pagina (zie _ww_cards_endpoint()).
 *
 * De standaardroutes van WordPress zijn alleen voor ingelogde gebruikers (beslissing 0027, zie _ww_rest_block_core_routes()).
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Grenzen aan publieke invoer, zodat elke combinatie een redelijke query en cache-item blijft.
const WW_REST_MAX_PAGE = 1000;
const WW_REST_MAX_TAX  = 3;

// Namespace van de eigen REST-routes (ook die van de editor, inc/editor.php).
const WW_REST_NAMESPACE = 'ww/v1';

// Basis van elk REST-argument: valideren en saneren tegen het eigen schema (type, grenzen).
const WW_REST_SCHEMA_ARG = array(
	'validate_callback' => 'rest_validate_request_arg',
	'sanitize_callback' => 'rest_sanitize_request_arg',
);

// Standaardroutes van WordPress: de index (/), wp/v2, site health, block editor, abilities, oembed en batch.
// Op naam en niet als wp-*: plugins als WP Statistics hebben ook een namespace met wp- ervoor.
// Hoofdletters tellen niet, net als bij WordPress zelf.
const WW_REST_CORE_ROUTE_PATTERN = '#^/(?:$|(?:wp|wp-site-health|wp-block-editor|wp-abilities|oembed|batch)(?:/|$))#i';

/**
 * Of een anonieme bezoeker deze route niet mag aanroepen: een standaardroute van WordPress. De eigen routes (ww/v1)
 * en die van plugins vallen erbuiten.
 *
 * @param string $route Route van het verzoek, zoals /wp/v2/users.
 */
function _ww_rest_is_blocked_route( string $route ): bool {
	$route   = '/' . ltrim( $route, '/' );
	$blocked = 1 === preg_match( WW_REST_CORE_ROUTE_PATTERN, $route );
	/**
	 * Zet een standaardroute van WordPress toch open voor bezoekers zonder login, bijvoorbeeld oEmbed.
	 *
	 * @param bool   $blocked Standaard true voor de standaardroutes van WordPress.
	 * @param string $route   Route van het verzoek, met een / ervoor.
	 */
	return (bool) apply_filters( 'ww_rest_block_route', $blocked, $route );
}

/**
 * De standaardroutes van WordPress (berichten, pagina's, gebruikers, media, instellingen, de lijst van alle routes)
 * zijn alleen voor ingelogde gebruikers: met cookie en nonce (de admin, Visueel bewerken) of met een
 * applicatiewachtwoord (de MCP Adapter). Een bezoeker zonder login krijgt een 401, zodat hij geen gebruikersnamen
 * of concepten opvraagt en niet ziet welke plugins er draaien. Batch staat ook dicht: die zou de andere routes langs
 * dit filter aanroepen. Eigen routes en die van plugins blijven werken.
 *
 * @param mixed           $result  Antwoord van een eerder filter, of null.
 * @param WP_REST_Server  $server  REST-server.
 * @param WP_REST_Request $request Verzoek.
 * @return mixed
 */
function _ww_rest_block_core_routes( $result, $server, $request ) {
	if ( null !== $result || is_user_logged_in() || ! _ww_rest_is_blocked_route( $request->get_route() ) ) {
		return $result;
	}
	return new WP_Error(
		'rest_not_logged_in',
		__( 'Deze route is alleen beschikbaar voor ingelogde gebruikers.', 'webwerckt-base' ),
		array( 'status' => 401 )
	);
}
add_filter( 'rest_pre_dispatch', '_ww_rest_block_core_routes', 10, 3 );

/**
 * Registreert de route. Alle argumenten worden tegen hun schema gevalideerd (type, grenzen),
 * zodat verkeerde invoer een 400 geeft en nooit de code in gaat.
 */
function _ww_register_rest_routes(): void {
	register_rest_route(
		WW_REST_NAMESPACE,
		'/cards',
		array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => '_ww_rest_cards',
			'permission_callback' => '__return_true',
			'args'                => array(
				'post_type' => WW_REST_SCHEMA_ARG + array(
					'type'     => 'string',
					'required' => true,
					'pattern'  => '^[a-z0-9_-]{1,20}$',
				),
				'page'      => WW_REST_SCHEMA_ARG + array(
					'type'    => 'integer',
					'default' => 2,
					'minimum' => 1,
					'maximum' => WW_REST_MAX_PAGE,
				),
				'tax'       => WW_REST_SCHEMA_ARG + array(
					'type'                 => 'object',
					'default'              => array(),
					'maxProperties'        => WW_REST_MAX_TAX,
					'additionalProperties' => array(
						'type'      => 'string',
						'maxLength' => 200,
					),
				),
				'lang'      => WW_REST_SCHEMA_ARG + array(
					'type'    => 'string',
					'pattern' => '^[a-z0-9_-]{2,20}$',
				),
			),
		)
	);
}
add_action( 'rest_api_init', '_ww_register_rest_routes' );

/**
 * URL van het kaarten-endpoint voor de scripts, met de taal van de pagina, zodat meer laden en filteren
 * kaarten in die taal geven. Met de taalmodule (beslissing 0040) krijgt een extra taal ?lang=, zodat elke taal een
 * eigen URL heeft, ook in de cache; de standaardtaal en een site zonder Meertalig houden de URL zonder taal.
 */
function _ww_cards_endpoint(): string {
	$lang = _ww_current_language();
	$url  = rest_url( 'ww/v1/cards' );
	// Zonder Meertalig is $lang '' en wordt de optie niet gelezen.
	return '' !== $lang && in_array( $lang, _ww_extra_language_codes(), true ) ? add_query_arg( 'lang', $lang, $url ) : $url;
}

/**
 * Het endpoint voor rest.js (meer laden en filteren), als moduledata: WordPress zet het in
 * <script type="application/json" id="wp-script-module-data-ww-rest">. Een data-attribuut kon via een tekstveld in de
 * pagina komen (wp_kses_post laat data-* door) en het script laten praten met een ander bestand op het domein; een
 * script-element laat KSES niet door (B5 van de security-audit van 2026-11-15).
 *
 * @param array<string,mixed> $data Moduledata.
 * @return array<string,mixed>
 */
function _ww_rest_module_data( array $data ): array {
	$data['endpoint'] = _ww_cards_endpoint();
	return $data;
}
add_filter( 'script_module_data_ww-rest', '_ww_rest_module_data' );

/**
 * Geeft de kaarten van één pagina terug als `{ html, has_more, next_url, total }`.
 *
 * next_url is de gewone URL van de volgende pagina met hetzelfde filter (of ''), voor de href
 * van de meer-laden-knop; total is het aantal items met dit filter.
 *
 * @param WP_REST_Request $request Verzoek.
 * @return WP_REST_Response|WP_Error
 */
function _ww_rest_cards( WP_REST_Request $request ) {
	$lang = (string) $request->get_param( 'lang' );
	if ( _ww_languages_active() ) {
		// De taalmodule: de taal en de locale voor de query, de kaarten en next_url (de linkfilters geven het
		// voorvoegsel). Een verborgen of onbekende taal wordt de standaardtaal.
		_ww_languages_set_current( '' === $lang ? _ww_default_language() : _ww_languages_valid_language( $lang, __FUNCTION__ ) );
	}

	$post_type = (string) $request->get_param( 'post_type' );
	$config    = _ww_archive_config( $post_type );
	$object    = get_post_type_object( $post_type );

	if ( array() === $config || ! $object || ! $object->public ) {
		return new WP_Error( 'ww_invalid_post_type', __( 'Onbekend post type.', 'webwerckt-base' ), array( 'status' => 404 ) );
	}

	$page = max( 1, (int) $request->get_param( 'page' ) );
	// Alleen publieke taxonomieën: anders verraadt het endpoint welke items in een interne term zitten.
	$tax    = array_filter(
		(array) $request->get_param( 'tax' ),
		static fn( $taxonomy ) => null !== _ww_public_taxonomy( (string) $taxonomy ),
		ARRAY_FILTER_USE_KEY
	);
	$result = _ww_query_ids(
		$post_type,
		array(
			'limit'   => $config['per_page'],
			'paged'   => $page,
			// Een slug in de taal van de pagina wordt de gewone slug; next_url houdt de slug uit het verzoek.
			'tax'     => _ww_term_plain_tax( $tax ),
			'orderby' => $config['orderby'],
			'order'   => $config['order'],
			// De taal zoals de taalmodule hem heeft vastgesteld (een onbekende code wordt de standaardtaal); zonder
			// Meertalig ''.
			'lang'    => _ww_current_language(),
		)
	);
	$has_more = $page < $result['max_pages'];
	_ww_prime_thumbnails( $result['ids'] );

	// Cachebaar: het antwoord is publiek en draagt de tags van het post type.
	do_action( 'ww_cacheable', true, 'ww/v1/cards' );

	return rest_ensure_response(
		array(
			'html'     => implode( '', array_map( '_ww_card_html', $result['ids'] ) ),
			'has_more' => $has_more,
			'next_url' => $has_more ? esc_url_raw( ww_paged_url( ww_filter_url( $post_type, $tax ), $page + 1 ) ) : '',
			'total'    => $result['total'],
		)
	);
}
