<?php
/**
 * Afbeeldingen in moderne formaten (beslissing 0021): Imagick maakt via cron van elk bestand in de mediabibliotheek
 * een AVIF- en WebP-versie ernaast (foto-800x600.jpg.avif), en ww_image() serveert die via <picture>.
 *
 * Het geüploade bestand en de formaten van WordPress blijven onaangeroerd; de extra bestanden weggooien is genoeg
 * om alles terug te draaien. De status staat per bestand en per formaat in _ww_image_variants, zodat een nieuw
 * formaat van het child-thema of een bijsnijding vanzelf in de wachtrij komt.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Zo lang mag één run duren, ruim onder max_execution_time; AVIF kost seconden per bestand.
const WW_IMAGES_BUDGET = 20;
// Na zoveel mislukte pogingen slaat de cron een bestand over.
const WW_IMAGES_MAX_TRIES = 3;
// Geheugen dat ImageMagick per run mag gebruiken, tegen geheugenproblemen op gedeelde hosting.
const WW_IMAGES_MEMORY = 256 * MB_IN_BYTES;
// Grotere afbeeldingen (in pixels) slaat de cron over. Een pixel kost ImageMagick (Q16, RGBA) 8 bytes, dus 25 MP is
// 200 MB en past met ruimte voor de encoder in WW_IMAGES_MEMORY; groter zou naar een trage pixelcache op schijf gaan.
// WordPress verkleint originelen standaard tot 2560 px (6,5 MP), dus dit raakt alleen sites die dat uitzetten.
const WW_IMAGES_MAX_PIXELS = 25000000;
// Zo lang blijft het slot van een run staan, als de run afbreekt zonder het vrij te geven.
const WW_IMAGES_LOCK_TTL = 15 * MINUTE_IN_SECONDS;
// Option met het slot van een run, en de cronhook van de runs.
const WW_IMAGES_LOCK     = 'ww_images_lock';
const WW_IMAGES_RUN_HOOK = 'ww_images_run';
// Hooguit zo vaak meldt de optimaliseerder met ww_output_changed dat er nieuwe bestanden zijn.
const WW_IMAGES_CHANGED_DELAY = 15 * MINUTE_IN_SECONDS;
// Formaten die de optimaliseerder maakt, in de volgorde waarin de browser ze moet proberen.
const WW_IMAGES_FORMATS = array( 'avif', 'webp' );
// Metasleutels per bijlage: status per bestand en formaat, stand in de wachtrij, en het kenmerk van de laatste keer
// dat de afbeelding in de wachtrij kwam.
const WW_IMAGES_META_VARIANTS = '_ww_image_variants';
const WW_IMAGES_META_STATE    = '_ww_image_state';
const WW_IMAGES_META_QUEUED   = '_ww_image_queued';
/** Afmetingen ("{w}x{h}") van het hoofdbestand als het te groot was om te verwerken. */
const WW_IMAGES_META_SKIP_SIZE = '_ww_image_skip_size';
/** De generatie (van Alles opnieuw maken) waarin de run de afbeelding het laatst verwerkte. */
const WW_IMAGES_META_GENERATION = '_ww_image_generation';
// Bronbestanden: extensie => formaat. Het formaat is de coder van ImageMagick en het MIME-type is image/<formaat>.
const WW_IMAGES_SOURCES = array(
	'jpg'  => 'jpeg',
	'jpeg' => 'jpeg',
	'jpe'  => 'jpeg',
	'png'  => 'png',
	'gif'  => 'gif',
	'webp' => 'webp',
);

/**
 * MIME-types van de bronbestanden.
 *
 * @return string[]
 */
function _ww_images_mime_types(): array {
	return array_values( array_unique( array_map( static fn( string $format ): string => 'image/' . $format, WW_IMAGES_SOURCES ) ) );
}

/**
 * Formaat van een bronbestand volgens zijn extensie, of '' als het geen bron is.
 */
function _ww_images_source_format( string $file ): string {
	return WW_IMAGES_SOURCES[ strtolower( pathinfo( $file, PATHINFO_EXTENSION ) ) ] ?? '';
}

/**
 * Option met de instellingen van het scherm Afbeeldingen, en de toegestane tijdsbudgetten (seconden) per run.
 */
const WW_IMAGES_SETTINGS   = 'ww_images_settings';
const WW_IMAGES_GENERATION = 'ww_images_generation';
const WW_IMAGES_BUDGETS  = array( 10, 20, 30, 45 );

/**
 * Standaardinstellingen: wat de optimaliseerder deed voordat er instellingen bestonden.
 *
 * @return array{enabled:bool,formats:string[],quality:array{avif:int,webp:int},budget:int}
 */
function _ww_images_default_settings(): array {
	return array(
		'enabled' => true,
		'formats' => WW_IMAGES_FORMATS,
		'quality' => array(
			'avif' => 60,
			'webp' => 80,
		),
		'budget'  => WW_IMAGES_BUDGET,
	);
}

/**
 * Maakt van een ruwe waarde geldige instellingen. Wat ontbreekt of niet deugt, wordt de waarde uit $current.
 *
 * @param mixed                $value   Ruwe invoer (de option of een formulier).
 * @param array<string,mixed>  $current Terugvalwaarden; standaard de ingebouwde standaarden.
 * @return array{enabled:bool,formats:string[],quality:array{avif:int,webp:int},budget:int}
 */
function _ww_images_sanitize_settings( $value, array $current = array() ): array {
	$defaults = _ww_images_default_settings();
	$value    = is_array( $value ) ? $value : array();

	$enabled = $current['enabled'] ?? $defaults['enabled'];
	if ( array_key_exists( 'enabled', $value ) ) {
		$enabled = filter_var( $value['enabled'], FILTER_VALIDATE_BOOLEAN );
	}

	$formats = is_array( $current['formats'] ?? null ) ? $current['formats'] : $defaults['formats'];
	if ( is_array( $value['formats'] ?? null ) ) {
		$formats = $value['formats'];
	}
	// Alleen bekende formaten, in de volgorde van WW_IMAGES_FORMATS.
	$formats = array_values( array_intersect( WW_IMAGES_FORMATS, $formats ) );

	$quality = array();
	foreach ( $defaults['quality'] as $format => $default ) {
		$fallback = $current['quality'][ $format ] ?? $default;
		$given    = is_array( $value['quality'] ?? null ) ? ( $value['quality'][ $format ] ?? $fallback ) : $fallback;
		$quality[ $format ] = max( 1, min( 100, (int) $given ) );
	}

	$budget = (int) ( $value['budget'] ?? $current['budget'] ?? $defaults['budget'] );
	if ( ! in_array( $budget, WW_IMAGES_BUDGETS, true ) ) {
		$budget = (int) ( in_array( (int) ( $current['budget'] ?? 0 ), WW_IMAGES_BUDGETS, true ) ? $current['budget'] : $defaults['budget'] );
	}

	return array(
		'enabled' => (bool) $enabled,
		'formats' => $formats,
		'quality' => $quality,
		'budget'  => $budget,
	);
}

/**
 * De opgeschoonde instellingen, aangevuld met de standaarden.
 *
 * @return array{enabled:bool,formats:string[],quality:array{avif:int,webp:int},budget:int}
 */
function _ww_images_settings(): array {
	return _ww_images_sanitize_settings( get_option( WW_IMAGES_SETTINGS, array() ) );
}

/**
 * Of een filter van een plugin of child-thema de instelling overneemt (het scherm toont het veld dan vergrendeld).
 *
 * @param string $filter Naam van het filter, bijvoorbeeld 'ww_image_quality'.
 */
function _ww_images_locked( string $filter ): bool {
	return false !== has_filter( $filter );
}

/**
 * Of de optimaliseerder aan staat.
 */
function _ww_images_enabled(): bool {
	/**
	 * Zet het maken en serveren van AVIF- en WebP-versies uit.
	 *
	 * @param bool $enabled Standaard de instelling op het scherm Afbeeldingen (aan).
	 */
	return (bool) apply_filters( 'ww_image_variants', _ww_images_settings()['enabled'] );
}

/**
 * Formaten die de server kan schrijven, in de volgorde waarin de browser ze moet proberen. Leeg zonder Imagick.
 * Imagick::queryFormats() is traag, dus de uitkomst blijft een dag bewaard. Zonder filter en zonder instellingen.
 *
 * @return string[] 'avif' en/of 'webp'.
 */
function _ww_images_server_formats(): array {
	$formats = get_transient( 'ww_images_formats' );
	if ( is_array( $formats ) ) {
		return array_values( array_intersect( WW_IMAGES_FORMATS, $formats ) );
	}
	if ( ! class_exists( 'Imagick' ) ) {
		return array();
	}
	$supported = array_map( 'strtolower', Imagick::queryFormats() );
	$formats   = array_values( array_intersect( WW_IMAGES_FORMATS, $supported ) );
	set_transient( 'ww_images_formats', $formats, DAY_IN_SECONDS );
	return $formats;
}

/**
 * Formaten die de optimaliseerder maakt: wat de server kan en wat op het scherm Afbeeldingen aanstaat.
 *
 * @return string[] 'avif' en/of 'webp'.
 */
function _ww_images_formats(): array {
	$formats = array_values( array_intersect( _ww_images_server_formats(), _ww_images_settings()['formats'] ) );
	/**
	 * Formaten die de optimaliseerder maakt, bijvoorbeeld zonder 'avif' op een trage server.
	 *
	 * @param string[] $formats Standaard wat de server kan én op het scherm Afbeeldingen aanstaat.
	 */
	$formats = (array) apply_filters( 'ww_image_formats', $formats );
	return array_values( array_intersect( WW_IMAGES_FORMATS, $formats ) );
}

/**
 * Hoe lang één run mag duren, in seconden: de instelling, begrensd onder max_execution_time, dan het filter.
 */
function _ww_images_budget(): int {
	$budget = _ww_images_settings()['budget'];
	$limit  = (int) ini_get( 'max_execution_time' );
	if ( $limit > 0 ) {
		$budget = min( $budget, max( 5, $limit - 10 ) );
	}
	/**
	 * Hoe lang één run van de optimaliseerder mag duren, in seconden.
	 *
	 * @param int $seconds Standaard de instelling op het scherm Afbeeldingen (20), onder max_execution_time.
	 */
	return max( 1, (int) apply_filters( 'ww_image_budget', $budget ) );
}

/**
 * Formaten die van een bestand gemaakt worden: JPEG, PNG en GIF krijgen AVIF en WebP, WebP krijgt alleen AVIF.
 *
 * @param string   $file    Bestandsnaam.
 * @param string[] $formats Formaten die de server kan schrijven.
 * @return string[]
 */
function _ww_images_targets( string $file, array $formats ): array {
	$source = _ww_images_source_format( $file );
	return '' === $source ? array() : array_values( array_diff( $formats, array( $source ) ) );
}

/**
 * Bestanden van een afbeelding die WordPress serveert: het hoofdbestand (eventueel -scaled) en alle formaten,
 * als bestandsnamen in dezelfde map. Het origineel van vóór het verkleinen serveert WordPress niet.
 *
 * @param array<string,mixed> $meta Metadata van de bijlage.
 * @return string[]
 */
function _ww_images_files( array $meta ): array {
	$files = array();
	if ( is_string( $meta['file'] ?? null ) && '' !== $meta['file'] ) {
		$files[] = wp_basename( $meta['file'] );
	}
	foreach ( is_array( $meta['sizes'] ?? null ) ? $meta['sizes'] : array() as $size ) {
		if ( is_string( $size['file'] ?? null ) && '' !== $size['file'] ) {
			$files[] = wp_basename( $size['file'] );
		}
	}
	return array_values( array_unique( $files ) );
}

/**
 * Status per bestand en formaat: 'ok' (gemaakt), 'none' (niet kleiner, niet bewaard), 'skip:anim', 'skip:big', 'skip:exif' of
 * 'skip:file' (kan niet: geanimeerd, te groot, gedraaid volgens EXIF, geen bron; 'skip' is de oude vorm zonder reden), 'failed' (te vaak mislukt) of een getal (zoveel keer mislukt, wordt opnieuw geprobeerd).
 *
 * @return array<string,array<string,string|int>>
 */
function _ww_images_variants( int $attachment_id ): array {
	$variants = get_post_meta( $attachment_id, WW_IMAGES_META_VARIANTS, true );
	// Alleen bestanden met een lijst per formaat: zo hoeft geen aanroeper dat zelf na te gaan.
	return is_array( $variants ) ? array_filter( $variants, 'is_array' ) : array();
}

/**
 * Zet een afbeelding (terug) in de wachtrij. Het kenmerk in _ww_image_queued verandert elke keer, zodat een run die
 * tegelijk loopt ziet dat de afbeelding intussen opnieuw in de wachtrij kwam.
 */
function _ww_images_queue_add( int $attachment_id ): void {
	update_post_meta( $attachment_id, WW_IMAGES_META_STATE, 'pending' );
	update_post_meta( $attachment_id, WW_IMAGES_META_QUEUED, wp_generate_uuid4() );
}

/**
 * Het kenmerk van _ww_images_queue_add(), vers uit de database: een ander verzoek kan het tijdens de run hebben
 * veranderd.
 */
function _ww_images_queued( int $attachment_id ): string {
	wp_cache_delete( $attachment_id, 'post_meta' );
	return _ww_data_to_string( get_post_meta( $attachment_id, WW_IMAGES_META_QUEUED, true ) );
}

/**
 * Nieuwe metadata (upload, bijsnijden, opnieuw genereren): de afbeelding gaat in de wachtrij. De upload zelf wordt
 * er niet trager van; de cron maakt de bestanden. Versies die niet meer bij hun bron horen, vallen meteen uit
 * <picture>, en niet pas bij de volgende run.
 *
 * Bij opnieuw genereren (Regenerate Thumbnails, wp media regenerate) krijgen ook bestanden zonder versie ('none',
 * 'skip', 'failed') een nieuwe kans: de bron kan onder dezelfde naam veranderd zijn, en zo is een mislukte afbeelding
 * opnieuw te verwerken. Bijsnijden maakt nieuwe bestandsnamen, die al vanzelf in de wachtrij komen.
 *
 * @param mixed $meta          Metadata van de bijlage.
 * @param mixed $attachment_id Bijlage-ID.
 * @return mixed De metadata, ongewijzigd.
 */
function _ww_images_on_metadata( $meta, $attachment_id ) {
	$attachment_id = (int) $attachment_id;
	if ( ! is_array( $meta ) || ! wp_attachment_is_image( $attachment_id ) ) {
		return $meta;
	}
	_ww_images_queue_add( $attachment_id );
	$source   = get_attached_file( $attachment_id );
	$variants = _ww_images_variants( $attachment_id );
	if ( is_string( $source ) && '' !== $source && array() !== $variants ) {
		$current = _ww_images_drop_stale( $variants, dirname( $source ), $attachment_id );
		if ( doing_filter( 'wp_generate_attachment_metadata' ) ) {
			$current = _ww_images_reset( $current, static fn( string $file, string $format, $status ): bool => 'ok' !== $status );
		}
		if ( $current !== $variants ) {
			update_post_meta( $attachment_id, WW_IMAGES_META_VARIANTS, $current );
		}
	}
	return $meta;
}
add_filter( 'wp_generate_attachment_metadata', '_ww_images_on_metadata', 10, 2 );
add_filter( 'wp_update_attachment_metadata', '_ww_images_on_metadata', 10, 2 );

/**
 * Verwijdert WordPress een afbeelding (ook een formaat of de backup van een bijsnijding), dan gaan de AVIF- en
 * WebP-versie mee.
 *
 * @param mixed $file Pad van het bestand.
 * @return mixed Het pad, ongewijzigd.
 */
function _ww_images_delete_variants( $file ) {
	if ( is_string( $file ) && '' !== _ww_images_source_format( $file ) ) {
		foreach ( WW_IMAGES_FORMATS as $format ) {
			// Alleen bestaande versies: wp_delete_file() geeft elk pad door aan de filters van andere plugins.
			if ( is_file( $file . '.' . $format ) ) {
				wp_delete_file( $file . '.' . $format );
			}
		}
	}
	return $file;
}
add_filter( 'wp_delete_file', '_ww_images_delete_variants' );

/**
 * Afbeeldingen in de wachtrij, nieuwste eerst: met de status 'pending', of nog nooit bekeken (de bestaande
 * bibliotheek na de update).
 *
 * @param int   $limit Hoeveel.
 * @param int[] $skip  Al bekeken in deze run.
 * @return int[]
 */
function _ww_images_queue( int $limit, array $skip = array() ): array {
	$query = new WP_Query( _ww_images_queue_args( $limit ) + array( 'post__not_in' => $skip ) ); // phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_post__not_in -- hooguit een paar honderd ID's per run.
	return array_map( 'intval', $query->posts );
}

/**
 * Query-argumenten voor de wachtrij. Zonder filters van plugins: een vertaalplugin zou anders alleen de
 * afbeeldingen van één taal teruggeven.
 *
 * @return array<string,mixed>
 */
function _ww_images_queue_args( int $limit ): array {
	return array(
		'post_type'        => 'attachment',
		'post_status'      => 'inherit',
		'post_mime_type'   => _ww_images_mime_types(),
		'fields'           => 'ids',
		'posts_per_page'   => $limit,
		'orderby'          => 'ID',
		'order'            => 'DESC',
		'no_found_rows'    => true,
		'suppress_filters' => true,
		'meta_query'       => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- alleen in de cron en de Site-status.
			'relation' => 'OR',
			array(
				'key'   => WW_IMAGES_META_STATE,
				'value' => 'pending',
			),
			array(
				'key'     => WW_IMAGES_META_STATE,
				'compare' => 'NOT EXISTS',
			),
		),
	);
}

/**
 * Maakt één versie van een bestand, eerst als tijdelijk bestand en dan hernoemd, zodat een bezoeker nooit een half
 * bestand krijgt. Metadata (EXIF, GPS) gaat eruit, het kleurprofiel blijft.
 *
 * Eerst alleen de kop lezen (ping, in een eigen object: ping en read in hetzelfde object geven twee frames), zodat een
 * te grote of geanimeerde afbeelding wordt overgeslagen zonder hem helemaal te laden. Een bestand dat volgens EXIF
 * gedraaid moet worden, wordt ook overgeslagen: zonder de EXIF-gegevens zou de versie scheef staan. WordPress draait
 * zulke foto's bij het uploaden al zelf (-rotated), dus dat komt zelden voor.
 *
 * ImageMagick leest het bestand met de coder van de extensie (jpeg:foto.jpg) in plaats van te raden op de inhoud,
 * zodat een vermomd bestand nooit bij een andere coder (SVG, MVG, MSL) terechtkomt.
 *
 * @param string                  $source Pad van het bronbestand.
 * @param string                  $format 'avif' of 'webp'.
 * @param array{0:int,1:int}|null $size   Krijgt bij 'skip:big' de breedte en hoogte.
 * @return string 'ok', 'none' (niet kleiner), 'skip:*' (kan niet, met de reden) of 'error' (opnieuw proberen).
 */
function _ww_images_make( string $source, string $format, ?array &$size = null ): string {
	$coder = _ww_images_source_format( $source );
	if ( '' === $coder || ! is_file( $source ) ) {
		return 'skip:file';
	}
	$target = $source . '.' . $format;
	$tmp    = $target . '.tmp';
	try {
		$ping = new Imagick();
		$ping->pingImage( $coder . ':' . $source );
		$width  = $ping->getImageWidth();
		$height = $ping->getImageHeight();
		$skip   = _ww_images_skip_reason( $ping->getNumberImages(), $width, $height, $ping->getImageOrientation() );
		$ping->clear();
		if ( '' !== $skip ) {
			if ( 'skip:big' === $skip ) {
				$size = array( $width, $height );
			}
			return $skip;
		}

		$image = new Imagick();
		$image->readImage( $coder . ':' . $source );
		// Het ICC-profiel van een CMYK-bestand hoort niet bij de sRGB-versie; dan gaat het eruit.
		$cmyk = Imagick::COLORSPACE_CMYK === $image->getImageColorspace();
		if ( $cmyk ) {
			$image->transformImageColorspace( Imagick::COLORSPACE_SRGB );
		}
		$profiles = $cmyk ? array() : $image->getImageProfiles( 'icc', true );
		$image->stripImage();
		if ( isset( $profiles['icc'] ) ) {
			$image->profileImage( 'icc', $profiles['icc'] );
		}
		$image->setImageFormat( $format );
		$image->setImageCompressionQuality( _ww_images_quality( $format ) );
		$image->writeImage( $format . ':' . $tmp );
		$image->clear();
	} catch ( Exception $e ) {
		wp_delete_file( $tmp );
		return 'error';
	}

	clearstatcache( true, $tmp );
	// Geen of een leeg bestand na een geslaagde write (schijf vol, quotum): opnieuw proberen, niet als 'niet kleiner'
	// opgeven. wp_filesize() geeft 0 als het bestand ontbreekt.
	$bytes = wp_filesize( $tmp );
	if ( $bytes <= 0 ) {
		wp_delete_file( $tmp );
		return 'error';
	}
	if ( $bytes >= wp_filesize( $source ) ) {
		wp_delete_file( $tmp );
		return is_file( $tmp ) ? 'error' : 'none';
	}
	return rename( $tmp, $target ) ? 'ok' : 'error'; // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename -- atomair vervangen, net als de samengevoegde CSS.
}

/**
 * Waarom een afbeelding niet verwerkt wordt: 'skip:anim' (meer dan één beeld), 'skip:big' (meer pixels dan
 * WW_IMAGES_MAX_PIXELS), 'skip:exif' (moet volgens EXIF gedraaid worden) of '' (gewoon verwerken). In die volgorde.
 *
 * @param int $orientation Imagick-oriëntatie: 0 (onbekend) en 1 (boven links) zijn goed.
 */
function _ww_images_skip_reason( int $frames, int $width, int $height, int $orientation ): string {
	if ( $frames > 1 ) {
		return 'skip:anim';
	}
	if ( $width * $height > WW_IMAGES_MAX_PIXELS ) {
		return 'skip:big';
	}
	return in_array( $orientation, array( 0, 1 ), true ) ? '' : 'skip:exif';
}

/**
 * Is deze status "overgeslagen"? Zowel de oude 'skip' als de nieuwe 'skip:*' met reden.
 *
 * @param mixed $status Status van één versie.
 */
function _ww_images_is_skip( $status ): bool {
	return is_string( $status ) && str_starts_with( $status, 'skip' );
}

/**
 * Kwaliteit per formaat. De schalen verschillen: AVIF 60 ziet er ongeveer uit als WebP 80.
 */
function _ww_images_quality( string $format ): int {
	/**
	 * Kwaliteit (0-100) van de AVIF- of WebP-versie.
	 *
	 * @param int    $quality Standaard de instelling op het scherm Afbeeldingen (60 voor AVIF, 80 voor WebP).
	 * @param string $format  'avif' of 'webp'.
	 */
	$quality = (int) apply_filters( 'ww_image_quality', _ww_images_settings()['quality'][ $format ] ?? 80, $format );
	return max( 1, min( 100, $quality ) );
}

/**
 * Hoort de versie nog bij het bronbestand? Niet als hij ontbreekt of ouder is dan de bron: dan heeft iets het
 * bronbestand onder dezelfde naam opnieuw geschreven (Regenerate Thumbnails, wp media regenerate, een plugin die
 * een afbeelding vervangt), of de versie verwijderd.
 *
 * @param string $source Pad van het bronbestand.
 * @param string $format 'avif' of 'webp'.
 */
function _ww_images_is_current( string $source, string $format ): bool {
	$target = $source . '.' . $format;
	return is_file( $source ) && is_file( $target ) && filemtime( $target ) >= filemtime( $source ) && filemtime( $target ) >= _ww_images_generation();
}

/**
 * Tijdstip van "alles opnieuw maken": een versie die ouder is, hoort bij een eerdere instelling (kwaliteit) en wordt
 * door de run opnieuw gemaakt. 0 zolang dat nooit gevraagd is.
 */
function _ww_images_generation(): int {
	return (int) get_option( WW_IMAGES_GENERATION, 0 );
}

/**
 * Maakt alle versies opnieuw: de generatie gaat naar nu en elke afbeelding komt weer in de wachtrij. De oude versies
 * blijven staan met status 'ok', zodat <picture> blijft werken; de run zet ze per afbeelding terug en maakt ze opnieuw.
 * Bestanden met 'none' (niet kleiner) probeert de run ook opnieuw (_ww_images_drop_stale()).
 */
function _ww_images_redo(): void {
	update_option( WW_IMAGES_GENERATION, time(), false );
	delete_post_meta_by_key( WW_IMAGES_META_STATE );
	_ww_images_count_restart();
}

/**
 * Formaten waarvoor <picture> een <source> maakt: de gekozen formaten na het filter ww_image_formats, alleen als de
 * optimaliseerder aanstaat en er niet verwijderd wordt. Zonder formaatcheck van de server: dit draait bij elke
 * bezoeker, en _ww_images_srcset() kijkt al of elk bestand er is. Zo blijven al gemaakte versies ook bereikbaar als de
 * server tijdelijk niets meldt.
 *
 * Eerst aan/uit, dan pas het verwijderen: die option wordt alleen gelezen als de optimaliseerder aanstaat.
 *
 * @return string[] 'avif' en/of 'webp'.
 */
function _ww_images_served_formats(): array {
	if ( ! _ww_images_enabled() || _ww_images_wiping() ) {
		return array();
	}
	$formats = array_values( array_intersect( WW_IMAGES_FORMATS, _ww_images_settings()['formats'] ) );
	// Hetzelfde filter als in _ww_images_formats(), daar beschreven.
	$formats = (array) apply_filters( 'ww_image_formats', $formats );
	return array_values( array_intersect( WW_IMAGES_FORMATS, $formats ) );
}

/**
 * Zet de status terug op 0 waar $when( $file, $format, $status ) true geeft, zodat de cron het bestand opnieuw
 * probeert.
 *
 * @param array<string,array<string,string|int>>       $variants Status per bestand.
 * @param callable(string, string, string|int): bool $when     Welke statussen terug moeten.
 * @return array<string,array<string,string|int>>
 */
function _ww_images_reset( array $variants, callable $when ): array {
	foreach ( $variants as $file => $formats ) {
		foreach ( $formats as $format => $status ) {
			if ( $when( (string) $file, (string) $format, $status ) ) {
				$variants[ $file ][ $format ] = 0;
			}
		}
	}
	return $variants;
}

/**
 * Zet versies die niet meer bij hun bron horen terug op 0: <picture> wijst er dan niet meer naar, en de cron maakt
 * ze opnieuw.
 *
 * Na Alles opnieuw maken krijgt ook 'none' (niet kleiner) een nieuwe kans, met de nieuwe kwaliteit: als de afbeelding
 * in een eerdere generatie verwerkt is (of nog nooit met een stempel). <picture> verandert daardoor niet, want 'none'
 * had geen versie.
 *
 * @param array<string,array<string,string|int>> $variants      Status per bestand.
 * @param string                                  $dir           Map van de bestanden.
 * @param int                                     $attachment_id Bijlage-ID, voor de generatie van de laatste verwerking.
 * @return array<string,array<string,string|int>>
 */
function _ww_images_drop_stale( array $variants, string $dir, int $attachment_id ): array {
	$generation = _ww_images_generation();
	$old        = $generation > 0 && (int) get_post_meta( $attachment_id, WW_IMAGES_META_GENERATION, true ) < $generation;
	return _ww_images_reset(
		$variants,
		static fn( string $file, string $format, $status ): bool => ( 'ok' === $status && ! _ww_images_is_current( $dir . '/' . $file, $format ) ) || ( $old && 'none' === $status )
	);
}

/**
 * Nieuwe status van één versie. Een getal betekent "nog te doen" (zoveel pogingen mislukt); elke andere status is
 * klaar en blijft staan.
 *
 * Staat er al een versie die bij de bron hoort, dan wordt die gebruikt in plaats van opnieuw gemaakt: bijlagen die
 * hetzelfde bestand delen, doen het werk zo maar één keer.
 *
 * Een poging telt al vóór het converteren ($count_attempt bewaart hem): breekt PHP halverwege af (timeout,
 * geheugen), dan wordt het bestand na WW_IMAGES_MAX_TRIES runs overgeslagen in plaats van de wachtrij voorgoed op te
 * houden.
 *
 * @param string                   $path          Pad van het bronbestand.
 * @param string                   $format        'avif' of 'webp'.
 * @param string|int               $status        Huidige status.
 * @param float                    $deadline      microtime(true) waarop de run stopt.
 * @param callable(string|int):void $count_attempt Bewaart de status van de poging vóór het converteren.
 * @param array{0:int,1:int}|null   $size          Krijgt bij 'skip:big' de breedte en hoogte.
 * @return string|int
 */
function _ww_images_process_one( string $path, string $format, $status, float $deadline, callable $count_attempt, ?array &$size = null ) {
	if ( ! is_int( $status ) ) {
		return $status;
	}
	if ( _ww_images_is_current( $path, $format ) ) {
		return 'ok';
	}
	if ( microtime( true ) >= $deadline ) {
		return $status;
	}
	$attempt = $status + 1 >= WW_IMAGES_MAX_TRIES ? 'failed' : $status + 1;
	$count_attempt( $attempt );
	$result = _ww_images_make( $path, $format, $size );
	return 'error' === $result ? $attempt : $result;
}

/**
 * Stand van een afbeelding volgens de status van haar versies: 'pending' zolang er één nog te doen is, anders
 * 'failed' als er één te vaak mislukte, anders 'done'.
 *
 * @param array<string,array<string,string|int>> $variants Status per bestand.
 */
function _ww_images_state( array $variants ): string {
	$statuses = array_merge( ...array_values( array_map( 'array_values', $variants ) ) );
	if ( array() !== array_filter( $statuses, 'is_int' ) ) {
		return 'pending';
	}
	return in_array( 'failed', $statuses, true ) ? 'failed' : 'done';
}

/**
 * Werkt de bestanden van één afbeelding af tot het tijdsbudget op is. Bestanden die niet meer bij de afbeelding horen
 * (na bijsnijden), verdwijnen uit de status. Een versie die niet meer bij de bron hoort, wordt opnieuw gemaakt.
 *
 * Kwam de afbeelding tijdens de run opnieuw in de wachtrij (een upload die nog formaten aan het maken is, een
 * bijsnijding), dan blijft ze erin: de metadata van deze run kan al verouderd zijn.
 *
 * @param int      $attachment_id Bijlage-ID.
 * @param float    $deadline      microtime(true) waarop de run stopt.
 * @param string[] $formats       Formaten die de server kan schrijven.
 * @return bool Of er een versie bij is gekomen.
 */
function _ww_images_process( int $attachment_id, float $deadline, array $formats ): bool {
	$queued = _ww_images_queued( $attachment_id );
	$meta   = wp_get_attachment_metadata( $attachment_id );
	$source = get_attached_file( $attachment_id );
	if ( ! is_array( $meta ) || ! is_string( $source ) || '' === $source ) {
		update_post_meta( $attachment_id, WW_IMAGES_META_STATE, _ww_images_queued( $attachment_id ) !== $queued ? 'pending' : 'done' );
		return false;
	}

	$dir        = dirname( $source );
	$generation = _ww_images_generation();
	$old        = _ww_images_drop_stale( _ww_images_variants( $attachment_id ), $dir, $attachment_id );
	$variants = array();
	$made     = false;
	$main     = wp_basename( $source );
	$skipped  = false;
	foreach ( _ww_images_files( $meta ) as $file ) {
		foreach ( _ww_images_targets( $file, $formats ) as $format ) {
			$before = $old[ $file ][ $format ] ?? 0;
			// Wat deze run al weet, plus de poging: zo blijft de telling ook staan als PHP tijdens het converteren afbreekt.
			$count_attempt = static function ( $attempt ) use ( $attachment_id, $old, $variants, $file, $format ): void {
				$variants[ $file ][ $format ] = $attempt;
				update_post_meta( $attachment_id, WW_IMAGES_META_VARIANTS, array_replace_recursive( $old, $variants ) );
			};

			$size                         = null;
			$status                       = _ww_images_process_one( $dir . '/' . $file, $format, $before, $deadline, $count_attempt, $size );
			if ( $file === $main && null !== $size ) {
				update_post_meta( $attachment_id, WW_IMAGES_META_SKIP_SIZE, $size[0] . 'x' . $size[1] );
			}
			$skipped                      = $skipped || ( $file === $main && 'skip:big' === $status );
			$variants[ $file ][ $format ] = $status;
			$made                         = $made || ( is_int( $before ) && 'ok' === $status );
		}
	}

	if ( ! $skipped && ! empty( $variants[ $main ] ) && array() === array_filter( $variants[ $main ], 'is_int' ) ) {
		// Het hoofdbestand is klaar en niet te groot: een oude afmeting hoort er niet meer bij.
		delete_post_meta( $attachment_id, WW_IMAGES_META_SKIP_SIZE );
	}
	update_post_meta( $attachment_id, WW_IMAGES_META_VARIANTS, $variants );
	// De terugzettingen van deze generatie staan nu in de status: een volgende run zet 'none' niet nog eens terug.
	update_post_meta( $attachment_id, WW_IMAGES_META_GENERATION, $generation );
	update_post_meta( $attachment_id, WW_IMAGES_META_STATE, _ww_images_queued( $attachment_id ) !== $queued ? 'pending' : _ww_images_state( $variants ) );
	return $made;
}

/**
 * Waarde van het slot in de database (tijd:kenmerk), of null zonder slot. Rechtstreeks gelezen, buiten de cache van
 * de opties om: een andere run kan het net veranderd hebben.
 */
function _ww_images_lock_value(): ?string {
	global $wpdb;
	$value = $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", WW_IMAGES_LOCK ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	return is_string( $value ) ? $value : null;
}

/**
 * Neemt het slot van de optimaliseerder. Een INSERT IGNORE: van twee runs die tegelijk starten, krijgt er maar één
 * het slot. Een slot ouder dan WW_IMAGES_LOCK_TTL is van een afgebroken run en wordt overgenomen, met een UPDATE op
 * de oude waarde, zodat ook daar maar één run wint.
 *
 * @return string De waarde van het slot (tijd:kenmerk), nodig om het vrij te geven; '' als een andere run het heeft.
 */
function _ww_images_lock(): string {
	global $wpdb;
	$lock = time() . ':' . wp_generate_uuid4();
	if ( $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} ( option_name, option_value, autoload ) VALUES ( %s, %s, 'off' )", WW_IMAGES_LOCK, $lock ) ) ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return $lock;
	}
	$old = _ww_images_lock_value();
	if ( null === $old || (int) $old > time() - WW_IMAGES_LOCK_TTL ) {
		return '';
	}
	$taken = $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = %s AND option_value = %s", $lock, WW_IMAGES_LOCK, $old ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	return $taken ? $lock : '';
}

/**
 * Geeft het slot vrij, maar alleen als het nog van deze run is: heeft een andere run het overgenomen (deze run duurde
 * langer dan WW_IMAGES_LOCK_TTL), dan blijft het slot van die run staan.
 *
 * @param string $lock Waarde van _ww_images_lock().
 */
function _ww_images_unlock( string $lock ): void {
	global $wpdb;
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s", WW_IMAGES_LOCK, $lock ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
}

/**
 * Eén run van de cron: afbeeldingen uit de wachtrij afwerken tot het tijdsbudget op is. Een slot voorkomt dat twee
 * runs tegelijk lopen (een echte cron naast wp-cron), en daarmee ook dat ze hetzelfde tijdelijke bestand schrijven.
 * Vóór elke afbeelding controleert de run of het slot nog van hem is; zo niet, dan stopt hij.
 *
 * Komt er een formaat bij (bijvoorbeeld AVIF op de server), dan gaat de hele bibliotheek opnieuw door de wachtrij;
 * wat al klaar is, wordt daarbij overgeslagen (_ww_images_formats_changed()).
 *
 * Volgorde: eerst de versies verwijderen als dat gevraagd is (zonder Imagick, ook met de optimaliseerder uit), dan de
 * wachtrij, en met de tijd die over is de telling (images-count.php). Ook tellen kan zonder Imagick: zolang er nog geen
 * telling is of er om een nieuwe gevraagd is, draait de run daarvoor ook met de optimaliseerder uit.
 *
 * @return int Het aantal afbeeldingen waarvan een versie gemaakt is.
 */
function _ww_images_run(): int {
	$wiping  = _ww_images_wiping();
	$formats = $wiping ? array() : _ww_images_run_formats();
	if ( ! $wiping && array() === $formats && ! _ww_images_count_pending() ) {
		return 0;
	}
	$budget = _ww_images_budget();
	$lock   = _ww_images_lock();
	if ( '' === $lock ) {
		return 0;
	}

	$deadline = microtime( true ) + $budget;
	$made     = 0;
	$lost     = false;
	if ( $wiping ) {
		// Verwijderen raakt alleen bestanden en meta: geen ImageMagick nodig.
		$wiping = ! _ww_images_wipe_step( $deadline );
	}

	if ( array() !== $formats ) {
		_ww_images_formats_changed( $formats );
		_ww_images_limit_resources();

		$seen = array();
		while ( microtime( true ) < $deadline ) {
			$ids = _ww_images_queue( 10, $seen );
			if ( array() === $ids ) {
				break;
			}
			foreach ( $ids as $id ) {
				if ( _ww_images_lock_value() !== $lock ) {
					$lost = true;
					break 2;
				}
				$seen[] = $id;
				$made  += _ww_images_process( $id, $deadline, $formats ) ? 1 : 0;
			}
		}
		update_option( 'ww_images_last_run', time(), false );
	}

	// Tijd over (de wachtrij is leeg): de telling, als de vorige ronde ouder is dan een uur of er nog geen is.
	if ( ! $wiping && ! $lost && microtime( true ) < $deadline && _ww_images_count_due() ) {
		_ww_images_count_step( $deadline );
	}

	_ww_images_unlock( $lock );
	// Een paginacache (als die er is) toont de nieuwe <picture> pas na legen; de melding gaat hooguit eens per
	// WW_IMAGES_CHANGED_DELAY, zodat een lange wachtrij de cache niet elke run leegt.
	if ( $made > 0 && ! wp_next_scheduled( 'ww_output_changed' ) ) {
		wp_schedule_single_event( time() + WW_IMAGES_CHANGED_DELAY, 'ww_output_changed' );
	}
	return $made;
}
/**
 * De cron-taak: een run, zonder het aantal terug te geven (een action-callback geeft niets terug).
 */
function _ww_images_cron(): void {
	_ww_images_run();
}
add_action( WW_IMAGES_RUN_HOOK, '_ww_images_cron' );

/**
 * Formaten waarmee de run werkt: niets zonder Imagick of met de optimaliseerder uit. Ook de telling rekent hiermee
 * wat nog te doen is.
 *
 * @return string[] 'avif' en/of 'webp'.
 */
function _ww_images_run_formats(): array {
	return class_exists( 'Imagick' ) && _ww_images_enabled() ? _ww_images_formats() : array();
}

/**
 * Kwam er een formaat bij sinds de vorige run (AVIF op de server, of aangevinkt op het scherm), dan gaat de hele
 * bibliotheek opnieuw door de wachtrij; wat al klaar is, wordt daarbij overgeslagen. Gaat er een formaat af, dan
 * hoeft er niets opnieuw: <picture> serveert het alleen niet meer.
 *
 * @param string[] $formats Formaten van deze run.
 */
function _ww_images_formats_changed( array $formats ): void {
	$processed = get_option( 'ww_images_formats_processed' );
	if ( $processed === $formats ) {
		return;
	}
	if ( array() !== array_diff( $formats, is_array( $processed ) ? $processed : array() ) ) {
		delete_post_meta_by_key( WW_IMAGES_META_STATE );
	}
	update_option( 'ww_images_formats_processed', $formats, false );
}

/**
 * Begrenst geheugen en threads van ImageMagick, zodat de cron de server niet volloopt.
 */
function _ww_images_limit_resources(): void {
	Imagick::setResourceLimit( Imagick::RESOURCETYPE_MEMORY, WW_IMAGES_MEMORY );
	Imagick::setResourceLimit( Imagick::RESOURCETYPE_THREAD, 1 );
}

/**
 * Eigen cron-interval van vijf minuten.
 *
 * @param array<string,array{interval:int,display:string}> $schedules Intervallen van WordPress.
 * @return array<string,array{interval:int,display:string}>
 */
function _ww_images_cron_interval( array $schedules ): array {
	$schedules['ww_five_minutes'] = array(
		'interval' => 5 * MINUTE_IN_SECONDS,
		'display'  => __( 'Elke vijf minuten', 'webwerckt-base' ),
	);
	return $schedules;
}
add_filter( 'cron_schedules', '_ww_images_cron_interval' ); // phpcs:ignore WordPress.WP.CronInterval.CronSchedulesInterval -- korte batches houden elke run onder de tijdslimiet.

/**
 * Plant de cron in (ook na een update van de parent), of haalt hem weg als de optimaliseerder uit staat of de server
 * geen Imagick heeft.
 */
function _ww_images_schedule(): void {
	// Bezoekers niet: dat kost zonder paginacache bij elke paginaweergave een query. De admin en de cron plannen.
	if ( _ww_is_visitor_request() ) {
		return;
	}
	// <picture> leest de instellingen bij elke bezoeker: een ontbrekende option kost dan elke keer een query. Een lege
	// option (autoload aan) betekent "de standaarden", zodat die bij een update van het thema blijven meegaan.
	if ( false === get_option( WW_IMAGES_SETTINGS ) ) {
		add_option( WW_IMAGES_SETTINGS, array(), '', true );
	}
	$scheduled = wp_next_scheduled( WW_IMAGES_RUN_HOOK );
	// Ook met de optimaliseerder uit: zolang er versies verwijderd worden, of een telling na het verwijderen nog loopt.
	$wanted = ( _ww_images_enabled() && array() !== _ww_images_formats() ) || _ww_images_wiping() || _ww_images_count_pending();
	if ( $wanted && ! $scheduled ) {
		wp_schedule_event( time() + MINUTE_IN_SECONDS, 'ww_five_minutes', WW_IMAGES_RUN_HOOK );
	} elseif ( ! $wanted && $scheduled ) {
		wp_clear_scheduled_hook( WW_IMAGES_RUN_HOOK );
	}
}
add_action( 'init', '_ww_images_schedule' );

/**
 * Ander thema actief: de cron weg. De bestanden blijven staan (een thema heeft geen uninstall-hook).
 */
function _ww_images_unschedule(): void {
	wp_clear_scheduled_hook( WW_IMAGES_RUN_HOOK );
	wp_clear_scheduled_hook( 'ww_output_changed' );
}
add_action( 'switch_theme', '_ww_images_unschedule' );

/**
 * Zet een <img> van wp_get_attachment_image() in een <picture> met een <source> per formaat, als elk bestand in de
 * srcset een versie in dat formaat heeft, volgens de meta én op de schijf. Ontbreekt er één, dan valt dat formaat voor
 * deze afbeelding weg: een <source> wijst nooit naar een bestand dat er niet is. Niet in Visueel bewerken, waar de
 * <img> aan te klikken is.
 *
 * Het <picture>-element staat op display: contents, zodat de layout (flex, grid, percentages) hetzelfde blijft als
 * met een losse <img>.
 *
 * @param string $img           HTML van de <img>.
 * @param int    $attachment_id Bijlage-ID.
 */
function _ww_images_picture( string $img, int $attachment_id ): string {
	if ( '' === $img || is_admin() || 0 !== _ww_editor_post_id() ) {
		return $img;
	}
	// Leeg als de optimaliseerder uit staat, of tijdens het verwijderen (ook als een filter hem aan houdt).
	$formats = _ww_images_served_formats();
	if ( array() === $formats ) {
		return $img;
	}
	$variants = _ww_images_variants( $attachment_id );
	$source   = get_attached_file( $attachment_id );
	if ( array() === $variants || ! is_string( $source ) || '' === $source ) {
		return $img;
	}

	$tag = new WP_HTML_Tag_Processor( $img );
	if ( ! $tag->next_tag( array( 'tag_name' => 'img' ) ) ) {
		return $img;
	}
	$srcset = $tag->get_attribute( 'srcset' );
	$sizes  = $tag->get_attribute( 'sizes' );
	$src    = $tag->get_attribute( 'src' );
	$set    = is_string( $srcset ) && '' !== $srcset ? $srcset : ( is_string( $src ) ? $src : '' );

	$sources = '';
	foreach ( $formats as $format ) {
		$candidates = _ww_images_srcset( $set, $variants, $format, dirname( $source ) );
		if ( '' !== $candidates ) {
			$sources .= sprintf(
				'<source type="image/%s" srcset="%s"%s>',
				$format,
				esc_attr( $candidates ),
				is_string( $sizes ) && '' !== $sizes ? ' sizes="' . esc_attr( $sizes ) . '"' : ''
			);
		}
	}
	return '' === $sources ? $img : '<picture style="display:contents">' . $sources . $img . '</picture>';
}

/**
 * De srcset (of src) met elke URL vervangen door die van de versie in een formaat, of '' als een bestand die
 * versie niet heeft. De wijzigingsdatum van de versie staat als ver in de URL: maakt de cron hem opnieuw onder
 * dezelfde naam (na Regenerate Thumbnails), dan haalt de browser hem ondanks de lange browsercache opnieuw op.
 *
 * @param string                                  $set      srcset of src van de <img>.
 * @param array<string,array<string,string|int>> $variants Status per bestand.
 * @param string                                  $format   'avif' of 'webp'.
 * @param string                                  $dir      Map van de bestanden.
 */
function _ww_images_srcset( string $set, array $variants, string $format, string $dir ): string {
	$out = array();
	foreach ( explode( ',', $set ) as $candidate ) {
		$parts = preg_split( '/\s+/', trim( $candidate ), 2 );
		$url   = is_array( $parts ) ? $parts[0] : '';
		$file  = wp_basename( (string) wp_parse_url( $url, PHP_URL_PATH ) );
		$path  = $dir . '/' . $file . '.' . $format;
		if ( '' === $url || str_contains( $url, '?' ) || 'ok' !== ( $variants[ $file ][ $format ] ?? '' ) || ! is_file( $path ) ) {
			return '';
		}
		$out[] = trim( $url . '.' . $format . '?ver=' . (int) filemtime( $path ) . ' ' . ( $parts[1] ?? '' ) );
	}
	return implode( ', ', $out );
}

/**
 * Bytes van één bestand vóór en na: het origineel, en het kleinste van het origineel en zijn versies met 'ok' die op
 * de schijf staan. Een bestand dat ontbreekt, telt als 0.
 *
 * @param string                   $path     Pad van het bronbestand.
 * @param array<string,string|int> $statuses Status per formaat.
 * @return array{0:int,1:int}
 */
function _ww_images_file_bytes( string $path, array $statuses ): array {
	$size = is_file( $path ) ? (int) filesize( $path ) : 0;
	$best = $size;
	foreach ( $statuses as $format => $status ) {
		if ( 'ok' === $status && is_file( $path . '.' . $format ) ) {
			$best = min( $best, (int) filesize( $path . '.' . $format ) );
		}
	}
	return array( $size, $best );
}

/**
 * Korte status van één afbeelding voor de beheerder: verwerkt (met de besparing), in de wachtrij, mislukt.
 */
function _ww_images_status_text( int $attachment_id ): string {
	$state = get_post_meta( $attachment_id, WW_IMAGES_META_STATE, true );
	if ( 'done' !== $state && 'failed' !== $state ) {
		return __( 'In de wachtrij', 'webwerckt-base' );
	}

	$source = get_attached_file( $attachment_id );
	$dir    = is_string( $source ) ? dirname( $source ) . '/' : '';
	$before = 0;
	$after  = 0;
	foreach ( _ww_images_variants( $attachment_id ) as $file => $formats ) {
		list( $size, $best ) = _ww_images_file_bytes( $dir . $file, $formats );
		$before             += $size;
		$after              += $best;
	}

	if ( 'failed' === $state ) {
		return __( 'Deels mislukt; de originele bestanden worden gebruikt waar een versie ontbreekt.', 'webwerckt-base' );
	}
	if ( $before <= 0 || $after >= $before ) {
		return __( 'Klaar, geen kleinere versie mogelijk', 'webwerckt-base' );
	}
	/* translators: %d: percentage kleiner. */
	return sprintf( __( 'Klaar, %d%% kleiner', 'webwerckt-base' ), (int) round( 100 * ( $before - $after ) / $before ) );
}

/**
 * Kolom "Optimalisatie" in de lijstweergave van de mediabibliotheek, alleen voor de beheerder.
 *
 * @param array<string,string> $columns Kolommen.
 * @return array<string,string>
 */
function _ww_images_media_column( array $columns ): array {
	if ( current_user_can( 'manage_options' ) && _ww_images_enabled() ) {
		$columns['ww_images'] = __( 'Optimalisatie', 'webwerckt-base' );
	}
	return $columns;
}
add_filter( 'manage_media_columns', '_ww_images_media_column' );

/**
 * Inhoud van de kolom "Optimalisatie".
 *
 * @param string $column        Kolomnaam.
 * @param int    $attachment_id Bijlage-ID.
 */
function _ww_images_media_column_value( string $column, int $attachment_id ): void {
	if ( 'ww_images' === $column && in_array( get_post_mime_type( $attachment_id ), _ww_images_mime_types(), true ) ) {
		echo esc_html( _ww_images_status_text( $attachment_id ) );
	}
}
add_action( 'manage_media_custom_column', '_ww_images_media_column_value', 10, 2 );

/**
 * Dezelfde status in de details van een afbeelding (het venster in de mediabibliotheek en het bewerkscherm).
 *
 * @param array<string,array<string,mixed>> $fields Velden.
 * @param WP_Post                           $post   Bijlage.
 * @return array<string,array<string,mixed>>
 */
function _ww_images_media_field( array $fields, WP_Post $post ): array {
	if ( current_user_can( 'manage_options' ) && _ww_images_enabled() && in_array( $post->post_mime_type, _ww_images_mime_types(), true ) ) {
		$fields['ww_images'] = array(
			'label' => __( 'Optimalisatie', 'webwerckt-base' ),
			'input' => 'html',
			'html'  => esc_html( _ww_images_status_text( $post->ID ) ),
		);
	}
	return $fields;
}
add_filter( 'attachment_fields_to_edit', '_ww_images_media_field', 10, 2 );

/**
 * Hoeveel afbeeldingen een status hebben, voor de Site-status.
 *
 * @param string $state 'queue' (in de wachtrij) of 'failed'.
 */
function _ww_images_count( string $state ): int {
	$args = _ww_images_queue_args( 1 );
	if ( 'failed' === $state ) {
		$args['meta_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- alleen in de Site-status.
			array(
				'key'   => WW_IMAGES_META_STATE,
				'value' => 'failed',
			),
		);
	}
	$args['no_found_rows'] = false;
	return ( new WP_Query( $args ) )->found_posts;
}

/**
 * Loopt de wachtrij achter? Er staat iets in en de laatste run is meer dan een uur geleden. Dezelfde regel voor
 * Site-status en het scherm Afbeeldingen.
 *
 * @param int $queue Aantal afbeeldingen in de wachtrij.
 */
function _ww_images_behind( int $queue ): bool {
	return $queue > 0 && time() - (int) get_option( 'ww_images_last_run', 0 ) > HOUR_IN_SECONDS;
}

/**
 * Test in Site-status: kan de server het, draait de cron, en hoeveel staat er nog in de wachtrij.
 *
 * @return array<string,mixed>
 */
function _ww_images_health(): array {
	$formats = _ww_images_formats();
	$server  = _ww_images_server_formats();
	$queue   = _ww_images_count( 'queue' );
	$failed  = _ww_images_count( 'failed' );
	$last    = (int) get_option( 'ww_images_last_run', 0 );
	$version = class_exists( 'Imagick' ) ? Imagick::getVersion()['versionString'] : '';

	$status = 'good';
	$label  = __( 'Afbeeldingen worden in moderne formaten geserveerd', 'webwerckt-base' );
	// Het filter alleen noemen als het de instelling echt overneemt; anders is het een keuze op het scherm.
	if ( ! _ww_images_enabled() ) {
		$label = _ww_images_locked( 'ww_image_variants' )
			? __( 'De optimaliseerder van afbeeldingen staat uit (filter ww_image_variants)', 'webwerckt-base' )
			: __( 'De optimaliseerder van afbeeldingen staat uit (instelling op het scherm Afbeeldingen)', 'webwerckt-base' );
	} elseif ( ! class_exists( 'Imagick' ) ) {
		$status = 'recommended';
		$label  = __( 'De server kan geen AVIF of WebP maken: Imagick ontbreekt', 'webwerckt-base' );
	} elseif ( array() === $server ) {
		$status = 'recommended';
		$label  = __( 'De server kan geen AVIF of WebP maken: ImageMagick schrijft deze formaten niet', 'webwerckt-base' );
	} elseif ( array() === $formats ) {
		$label = _ww_images_locked( 'ww_image_formats' )
			? __( 'De optimaliseerder van afbeeldingen staat uit: geen formaat gekozen (filter ww_image_formats)', 'webwerckt-base' )
			: __( 'De optimaliseerder van afbeeldingen staat uit: geen formaat gekozen', 'webwerckt-base' );
	} elseif ( _ww_images_behind( $queue ) ) {
		$status = 'recommended';
		$label  = __( 'De optimaliseerder van afbeeldingen heeft al meer dan een uur niet gedraaid', 'webwerckt-base' );
	}

	$rows = array(
		/* translators: %s: versie van ImageMagick. */
		sprintf( __( 'ImageMagick: %s', 'webwerckt-base' ), '' !== $version ? $version : __( 'niet beschikbaar', 'webwerckt-base' ) ),
		/* translators: %s: formaten, bijvoorbeeld "avif, webp". */
		sprintf( __( 'Formaten: %s', 'webwerckt-base' ), array() !== $formats ? implode( ', ', $formats ) : __( 'geen', 'webwerckt-base' ) ),
		/* translators: %s: datum en tijd. */
		sprintf( __( 'Laatste run: %s', 'webwerckt-base' ), $last > 0 ? wp_date( 'j F Y H:i', $last ) : __( 'nog nooit', 'webwerckt-base' ) ),
		/* translators: %d: aantal afbeeldingen. */
		sprintf( __( 'In de wachtrij: %d', 'webwerckt-base' ), $queue ),
		/* translators: %d: aantal afbeeldingen. */
		sprintf( __( 'Deels mislukt: %d', 'webwerckt-base' ), $failed ),
	);

	$description = '<p>' . esc_html__( 'Webwerckt Base maakt op de achtergrond AVIF- en WebP-versies van de afbeeldingen in de mediabibliotheek. Een echte cron (DISABLE_WP_CRON met een taak in Plesk) houdt de wachtrij ook op een stille site kort.', 'webwerckt-base' ) . ' <a href="' . esc_url( admin_url( 'admin.php?page=ww-images' ) ) . '">' . esc_html__( 'Open het scherm Afbeeldingen', 'webwerckt-base' ) . '</a></p><ul><li>' . implode( '</li><li>', array_map( 'esc_html', $rows ) ) . '</li></ul>';
	return _ww_health_result( 'ww_images', $label, $status, $description );
}

/**
 * Meldt de test in Site-status aan.
 *
 * @param array<string,array<string,mixed>> $tests Tests van WordPress.
 * @return array<string,array<string,mixed>>
 */
function _ww_images_health_test( array $tests ): array {
	$tests['direct']['ww_images'] = array(
		'label' => __( 'Afbeeldingen in moderne formaten', 'webwerckt-base' ),
		'test'  => '_ww_images_health',
	);
	return $tests;
}
add_filter( 'site_status_tests', '_ww_images_health_test' );
