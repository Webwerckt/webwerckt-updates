<?php
/**
 * Tabel met de bewaarde pagina's op de pagina Pagina cache (inc/page-cache-admin.php). Wordt pas geladen als die
 * pagina wordt getoond, na WP_List_Table.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * De bewaarde pagina's: titel met pad en de acties Bekijken en Vernieuwen, vernieuwd, blijft bewaard en grootte.
 */
class WW_Page_Cache_List_Table extends WP_List_Table {

	/**
	 * Alle bewaarde pagina's.
	 *
	 * @var list<array{key:string,url:string,created:float,expires:int,post_types:string[],post_id:int,size:int}>
	 */
	private array $entries;

	/**
	 * @param list<array{key:string,url:string,created:float,expires:int,post_types:string[],post_id:int,size:int}> $entries Pagina's.
	 */
	public function __construct( array $entries ) {
		parent::__construct(
			array(
				'singular' => 'pagina',
				'plural'   => 'paginas',
				'ajax'     => false,
			)
		);
		$this->entries = $entries;
	}

	/**
	 * @return array<string,string>
	 */
	public function get_columns() {
		return array(
			'title'   => __( 'Pagina', 'webwerckt-base' ),
			'created' => __( 'Vernieuwd', 'webwerckt-base' ),
			'expires' => __( 'Blijft bewaard', 'webwerckt-base' ),
			'size'    => __( 'Grootte', 'webwerckt-base' ),
		);
	}

	/**
	 * @return array<string,array{0:string,1:bool}>
	 */
	protected function get_sortable_columns() {
		return array(
			'title'   => array( 'title', false ),
			'created' => array( 'created', true ),
			'expires' => array( 'expires', false ),
		);
	}

	/**
	 * @return string
	 */
	protected function get_default_primary_column_name() {
		return 'title';
	}

	/**
	 * Kop met de extra klasse ww-cache-col-size op de kolom Grootte, zodat het scherm hem op smalle schermen kan verbergen.
	 *
	 * @param bool $with_id Of de koppen een id krijgen.
	 */
	public function print_column_headers( $with_id = true ): void {
		ob_start();
		parent::print_column_headers( $with_id );
		echo str_replace( 'column-size', 'column-size ww-cache-col-size', (string) ob_get_clean() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- uitvoer van WP_List_Table.
	}

	/**
	 * Cellen van een rij, met dezelfde extra klasse op de kolom Grootte.
	 *
	 * @param object|array<string,mixed> $item Pagina.
	 */
	protected function single_row_columns( $item ): void {
		ob_start();
		parent::single_row_columns( $item );
		echo str_replace( 'column-size', 'column-size ww-cache-col-size', (string) ob_get_clean() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- uitvoer van WP_List_Table.
	}

	/**
	 * Voegt de titels toe, filtert, sorteert en pagineert.
	 */
	public function prepare_items(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- alleen zoeken en sorteren.
		$search  = isset( $_GET['s'] ) && is_string( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		$orderby = isset( $_GET['orderby'] ) && is_string( $_GET['orderby'] ) ? sanitize_key( $_GET['orderby'] ) : 'title';
		$order   = isset( $_GET['order'] ) && is_string( $_GET['order'] ) ? sanitize_key( $_GET['order'] ) : 'asc';
		// phpcs:enable
		_prime_post_caches( array_values( array_unique( array_filter( array_map( 'intval', array_column( $this->entries, 'post_id' ) ) ) ) ), false, false );
		$entries = array();
		foreach ( $this->entries as $entry ) {
			$entry['title'] = _ww_page_cache_title( $entry['url'], $entry['post_id'] );
			$entries[]      = $entry;
		}
		$rows = _ww_page_cache_admin_rows( $entries, $search, $orderby, $order );

		$this->_column_headers = array( $this->get_columns(), array(), $this->get_sortable_columns(), 'title' );
		$this->set_pagination_args(
			array(
				'total_items' => count( $rows ),
				'per_page'    => WW_PAGE_CACHE_PER_PAGE,
			)
		);
		$this->items = array_slice( $rows, ( $this->get_pagenum() - 1 ) * WW_PAGE_CACHE_PER_PAGE, WW_PAGE_CACHE_PER_PAGE );
	}

	/**
	 * Tekst als er niets in de cache staat.
	 */
	public function no_items(): void {
		esc_html_e( 'Er zijn nog geen pagina\'s bewaard.', 'webwerckt-base' );
	}

	/**
	 * Titel met het pad eronder en de acties Bekijken en Vernieuwen.
	 *
	 * @param array{key:string,url:string,title:string} $item Pagina.
	 */
	protected function column_title( $item ): string {
		$purge   = wp_nonce_url(
			add_query_arg(
				array(
					'action' => 'ww_page_cache_purge',
					'key'    => $item['key'],
				),
				admin_url( 'admin-post.php' )
			),
			'ww_page_cache_purge_' . $item['key']
		);
		$actions = array(
			'view'  => '<a href="' . esc_url( $item['url'] ) . '" target="_blank" rel="noopener">' . esc_html__( 'Bekijken', 'webwerckt-base' ) . '</a>',
			'purge' => '<a href="' . esc_url( $purge ) . '">' . esc_html__( 'Vernieuwen', 'webwerckt-base' ) . '</a>',
		);
		$path    = (string) wp_parse_url( $item['url'], PHP_URL_PATH );
		return '<strong><a href="' . esc_url( $item['url'] ) . '" target="_blank" rel="noopener">' . esc_html( $item['title'] ) . '</a></strong><br><span class="description">' . esc_html( '' !== $path ? $path : $item['url'] ) . '</span>' . $this->row_actions( $actions );
	}

	/**
	 * Hoe lang geleden de pagina werd opgebouwd.
	 *
	 * @param array{created:float} $item Pagina.
	 */
	protected function column_created( $item ): string {
		return esc_html(
			sprintf(
				/* translators: %s: tijdsduur, zoals 5 minuten. */
				__( '%s geleden', 'webwerckt-base' ),
				human_time_diff( (int) $item['created'] )
			)
		);
	}

	/**
	 * Wanneer de pagina verloopt, of dat hij al verlopen is.
	 *
	 * @param array{expires:int} $item Pagina.
	 */
	protected function column_expires( $item ): string {
		if ( $item['expires'] <= time() ) {
			return esc_html__( 'Verlopen', 'webwerckt-base' );
		}
		return esc_html(
			sprintf(
				/* translators: %s: tijdsduur, zoals 5 minuten. */
				__( 'over %s', 'webwerckt-base' ),
				human_time_diff( time(), $item['expires'] )
			)
		);
	}

	/**
	 * Grootte van HTML en meta.json samen.
	 *
	 * @param array{size:int} $item Pagina.
	 */
	protected function column_size( $item ): string {
		return esc_html( (string) size_format( $item['size'] ) );
	}
}
