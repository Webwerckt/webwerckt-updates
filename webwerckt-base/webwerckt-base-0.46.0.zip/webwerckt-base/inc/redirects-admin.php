<?php
/**
 * Redirects: het scherm Redirects (een hoofditem), alleen voor beheerders (beslissing 0031).
 *
 * De acties en de gegevens van het scherm. Het zijpaneel en de weergaven (Redirects, het formulier, 404-logboek,
 * Importeren en exporteren) staan in inc/redirects-admin-sections.php. Elke actie komt binnen op admin_init met
 * ww_redirects_action, een nonce en de rechten van manage_options, en stuurt daarna terug naar het scherm.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const WW_REDIRECTS_SCREEN   = 'ww-redirects';
const WW_REDIRECTS_PER_PAGE = 50;
const WW_REDIRECTS_ACTIONS  = array( 'save', 'delete', 'bulk-delete', 'import-preview', 'import-apply', 'export', 'log-delete', 'log-bulk-delete', 'log-clear' );

/**
 * Voegt Redirects toe als hoofditem, in het Webwerckt-blok (beslissing 0035).
 */
function _ww_redirects_admin_menu(): void {
	add_menu_page(
		__( 'Redirects', 'webwerckt-base' ),
		__( 'Redirects', 'webwerckt-base' ),
		'manage_options',
		WW_REDIRECTS_SCREEN,
		'_ww_redirects_admin_render',
		'dashicons-randomize'
	);
}
add_action( 'admin_menu', '_ww_redirects_admin_menu' );

/**
 * Laadt de stijl, alleen op dit scherm.
 *
 * @param string $hook Admin-scherm.
 */
function _ww_redirects_admin_assets( string $hook ): void {
	if ( 'toplevel_page_' . WW_REDIRECTS_SCREEN !== $hook ) {
		return;
	}
	wp_enqueue_style( 'ww-redirects-admin', _ww_asset_url( 'css/redirects-admin.css' ), array(), WW_BASE_VERSION );
	if ( 'form' !== _ww_redirects_admin_view() ) {
		return;
	}
	// Alleen gemak: de nieuwe URL uit bij Pagina is weg, en de samenvatting. Zonder script werkt het formulier ook.
	wp_enqueue_script( 'ww-redirects-admin', _ww_asset_url( 'js/redirects-admin.js' ), array(), WW_BASE_VERSION, array( 'in_footer' => true ) );
	$l10n = array(
		'host'  => (string) wp_parse_url( home_url(), PHP_URL_HOST ),
		/* translators: 1: oude URL, 2: nieuwe URL. */
		's301'  => __( 'Bezoekers van %1$s gaan naar %2$s. Google neemt de nieuwe URL over.', 'webwerckt-base' ),
		/* translators: 1: oude URL, 2: nieuwe URL. */
		's302'  => __( 'Bezoekers van %1$s gaan voorlopig naar %2$s. Google blijft de oude URL kennen.', 'webwerckt-base' ),
		/* translators: %1$s: oude URL. */
		's410'  => __( 'Bezoekers van %1$s krijgen de melding dat de pagina weg is. Google haalt hem uit de zoekresultaten.', 'webwerckt-base' ),
		'below' => __( ' en alles eronder', 'webwerckt-base' ),
	);
	wp_add_inline_script( 'ww-redirects-admin', 'window.wwRedirectsL10n = ' . wp_json_encode( $l10n ) . ';', 'before' );
}
add_action( 'admin_enqueue_scripts', '_ww_redirects_admin_assets' );

/**
 * URL van het scherm, eventueel met extra queryvariabelen.
 *
 * @param array<string,string> $args Queryvariabelen.
 */
function _ww_redirects_admin_url( array $args = array() ): string {
	// Zelf coderen: add_query_arg() codeert de nieuwe waarden niet, en een pad kan & of + bevatten.
	return add_query_arg( array_map( 'rawurlencode', array( 'page' => WW_REDIRECTS_SCREEN ) + $args ), admin_url( 'admin.php' ) );
}

/**
 * Een link naar een actie met een nonce.
 *
 * @param string               $action Actie uit WW_REDIRECTS_ACTIONS.
 * @param array<string,string> $args   Extra queryvariabelen.
 */
function _ww_redirects_admin_action_url( string $action, array $args = array() ): string {
	return wp_nonce_url( _ww_redirects_admin_url( array( 'ww_redirects_action' => $action ) + $args ), 'ww_redirects_' . $action );
}

/**
 * Het formulier zoals de beheerder het invulde, na een fout bij opslaan, zodat het niet leeg terugkomt.
 *
 * @param array<string,mixed>|null $set Met een waarde: onthoud die.
 * @return array<string,mixed>|null
 */
function _ww_redirects_admin_form( ?array $set = null ): ?array {
	static $form = null;
	if ( null !== $set ) {
		$form = $set;
	}
	return $form;
}

/**
 * Een regel op id, of null.
 *
 * @param int $id Id van de regel.
 */
function _ww_redirects_admin_get( int $id ): ?object {
	global $wpdb;
	$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . _ww_redirects_table() . ' WHERE id = %d', $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_redirects_table().
	return is_object( $row ) ? $row : null;
}

/**
 * De regels voor de tabel: zoeken in bron en doel, filteren op herkomst, sorteren en een pagina.
 *
 * @param string $search  Zoekterm, of ''.
 * @param string $origin  manual, import of slug; ander is alles.
 * @param string $orderby source, hits of last_hit; ander is source.
 * @param string $order   asc of desc.
 * @param int    $paged   Paginanummer, vanaf 1.
 * @return array{items:list<object>,total:int}
 */
function _ww_redirects_admin_list( string $search, string $origin, string $orderby, string $order, int $paged ): array {
	global $wpdb;
	$table = _ww_redirects_table();

	$where  = array();
	$values = array();
	if ( '' !== $search ) {
		$like     = '%' . $wpdb->esc_like( $search ) . '%';
		$where[]  = '(source LIKE %s OR target LIKE %s)';
		$values[] = $like;
		$values[] = $like;
	}
	if ( in_array( $origin, array( 'manual', 'import', 'slug' ), true ) ) {
		$where[]  = 'origin = %s';
		$values[] = $origin;
	}
	$sql_where = array() === $where ? '' : ' WHERE ' . implode( ' AND ', $where );

	$orderby = in_array( $orderby, array( 'hits', 'last_hit' ), true ) ? $orderby : 'source';
	$dir     = 'desc' === strtolower( $order ) ? 'DESC' : 'ASC';
	$offset  = max( 0, $paged - 1 ) * WW_REDIRECTS_PER_PAGE;

	$count_sql = "SELECT COUNT(*) FROM $table$sql_where";
	$total     = (int) ( array() === $values ? $wpdb->get_var( $count_sql ) : $wpdb->get_var( $wpdb->prepare( $count_sql, $values ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- tabelnaam, kolom en richting komen uit vaste lijsten.

	$list_sql = "SELECT * FROM $table$sql_where ORDER BY $orderby $dir, id ASC LIMIT %d OFFSET %d";
	$items    = $wpdb->get_results( $wpdb->prepare( $list_sql, array_merge( $values, array( WW_REDIRECTS_PER_PAGE, $offset ) ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- tabelnaam, kolom en richting komen uit vaste lijsten.

	return array(
		'items' => array_values( array_filter( (array) $items, 'is_object' ) ),
		'total' => $total,
	);
}

/**
 * De rijen van het 404-logboek voor de tabel: zoeken in het pad, sorteren en een pagina.
 *
 * @param string $search  Zoekterm, of ''.
 * @param string $orderby path, hits, first_seen of last_seen; ander is hits.
 * @param string $order   asc of desc.
 * @param int    $paged   Paginanummer, vanaf 1.
 * @return array{items:list<object>,total:int}
 */
function _ww_404_log_admin_list( string $search, string $orderby, string $order, int $paged ): array {
	global $wpdb;
	$table = _ww_404_log_table();

	$sql_where = '';
	$values    = array();
	if ( '' !== $search ) {
		$sql_where = ' WHERE path LIKE %s';
		$values[]  = '%' . $wpdb->esc_like( $search ) . '%';
	}

	$orderby = in_array( $orderby, array( 'path', 'first_seen', 'last_seen' ), true ) ? $orderby : 'hits';
	$dir     = 'asc' === strtolower( $order ) ? 'ASC' : 'DESC';
	$offset  = max( 0, $paged - 1 ) * WW_REDIRECTS_PER_PAGE;

	$count_sql = "SELECT COUNT(*) FROM $table$sql_where";
	$total     = (int) ( array() === $values ? $wpdb->get_var( $count_sql ) : $wpdb->get_var( $wpdb->prepare( $count_sql, $values ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- tabelnaam, kolom en richting komen uit vaste lijsten.

	$list_sql = "SELECT * FROM $table$sql_where ORDER BY $orderby $dir, path ASC LIMIT %d OFFSET %d";
	$items    = $wpdb->get_results( $wpdb->prepare( $list_sql, array_merge( $values, array( WW_REDIRECTS_PER_PAGE, $offset ) ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- tabelnaam, kolom en richting komen uit vaste lijsten.

	return array(
		'items' => array_values( array_filter( (array) $items, 'is_object' ) ),
		'total' => $total,
	);
}

/**
 * Valt er een gepubliceerd bericht onder dit voorvoegsel? Een handvol queries, geen scan: de pagina of het bericht op
 * het pad zelf, en het berichttype waarvan de permalinkstructuur met dit pad begint (/blog/%postname%/ onder /blog/).
 *
 * @param string $source Genormaliseerde bron van een voorvoegselregel.
 */
function _ww_redirects_prefix_covers_post( string $source ): bool {
	$types = array_values( array_diff( get_post_types( array( 'public' => true ) ), array( 'attachment' ) ) );

	$page = get_page_by_path( trim( $source, '/' ), OBJECT, $types );
	if ( $page instanceof WP_Post && 'publish' === $page->post_status ) {
		return true;
	}
	$post_id = url_to_postid( home_url( $source ) );
	if ( $post_id > 0 && 'publish' === get_post_status( $post_id ) ) {
		return true;
	}

	$structure = (string) get_option( 'permalink_structure' );
	$fixed     = substr( $structure, 0, (int) strpos( $structure . '%', '%' ) );
	if ( '' === $fixed ) {
		return false;
	}
	$fixed = _ww_redirect_normalize( rtrim( $fixed, '/' ) . '/' );
	return null !== $fixed && '/' !== $fixed && str_starts_with( $fixed, $source ) && (int) wp_count_posts( 'post' )->publish > 0;
}

/**
 * Bewaart bij het opslaan of er een gepubliceerd bericht onder een voorvoegselregel valt (transient
 * ww_redirect_warn_posts_{id}, een week), zodat de lijst het alleen hoeft te lezen.
 *
 * @param int $id Id van de opgeslagen regel.
 */
function _ww_redirects_check_prefix( int $id ): void {
	delete_transient( 'ww_redirect_warn_posts_' . $id );
	$rule = _ww_redirects_admin_get( $id );
	if ( null !== $rule && 'prefix' === $rule->match_type && '/' !== $rule->source && _ww_redirects_prefix_covers_post( (string) $rule->source ) ) {
		set_transient( 'ww_redirect_warn_posts_' . $id, '1', WEEK_IN_SECONDS );
	}
}

/**
 * De waarschuwingen bij een regel; ze blokkeren het opslaan niet.
 *
 * Het doel en de berichten onder een voorvoegsel zijn bij het opslaan gecontroleerd (_ww_redirects_check_target en
 * _ww_redirects_check_prefix) en worden hier alleen uit hun transient gelezen.
 *
 * @param object $rule Regel uit de tabel (id, source, match_type).
 * @return string[]
 */
function _ww_redirects_warnings( object $rule ): array {
	$warnings = array();

	$code = get_transient( 'ww_redirect_warn_' . (int) $rule->id );
	if ( false !== $code && (int) $code > 0 ) {
		$warnings[] = sprintf(
			/* translators: %d: HTTP-statuscode. */
			__( 'Het doel gaf bij het opslaan HTTP %d in plaats van 200: controleer of de pagina bestaat.', 'webwerckt-base' ),
			(int) $code
		);
	}

	if ( 'prefix' === $rule->match_type ) {
		if ( '/' === $rule->source ) {
			$warnings[] = __( 'Dit voorvoegsel staat op /: elke pagina van de site die geen eigen regel heeft, wordt doorgestuurd.', 'webwerckt-base' );
		} elseif ( false !== get_transient( 'ww_redirect_warn_posts_' . (int) $rule->id ) ) {
			$warnings[] = __( 'Onder dit voorvoegsel staat een gepubliceerde pagina of een gepubliceerd bericht: die is niet meer te bereiken.', 'webwerckt-base' );
		}
	} elseif ( false !== get_transient( 'ww_redirect_warn_posts_' . (int) $rule->id ) ) {
		// Gezet door _ww_redirect_release_source(): iemand zonder manage_options publiceerde op deze bron.
		$warnings[] = __( 'Op deze URL is een pagina of bericht gepubliceerd door iemand zonder beheerdersrechten. De regel is blijven staan, dus die pagina is niet te bereiken. Verwijder de regel als de pagina voor moet gaan.', 'webwerckt-base' );
	}

	return $warnings;
}

/**
 * Controleert bij het opslaan of een intern doel een 200 geeft (HEAD op de eigen site, 3 seconden) en bewaart een
 * afwijkende status een week in een transient. Mislukt het verzoek, dan volgt geen waarschuwing.
 *
 * @param int $id Id van de opgeslagen regel.
 */
function _ww_redirects_check_target( int $id ): void {
	delete_transient( 'ww_redirect_warn_' . $id );

	$rule = _ww_redirects_admin_get( $id );
	if ( null === $rule || 410 === (int) $rule->status || null === _ww_redirect_internal_path( (string) $rule->target ) ) {
		return;
	}

	$url      = str_starts_with( (string) $rule->target, '/' ) ? home_url( (string) $rule->target ) : (string) $rule->target;
	$response = wp_remote_head(
		$url,
		array(
			'timeout'     => 3,
			'redirection' => 0,
		)
	);
	if ( is_wp_error( $response ) ) {
		return;
	}
	$status = (int) wp_remote_retrieve_response_code( $response );
	if ( $status > 0 && 200 !== $status ) {
		set_transient( 'ww_redirect_warn_' . $id, (string) $status, WEEK_IN_SECONDS );
	}
}

/**
 * Naam van het exportbestand: redirects-{host}-{datum}.csv.
 */
function _ww_redirects_export_filename(): string {
	$host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
	return 'redirects-' . sanitize_file_name( $host ) . '-' . gmdate( 'Y-m-d' ) . '.csv';
}

/**
 * Stuurt de export: headers (als die nog kunnen) en de CSV.
 */
function _ww_redirects_export_send(): void {
	if ( ! headers_sent() ) {
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=' . _ww_redirects_export_filename() );
	}
	echo _ww_redirects_export_csv(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSV, geen HTML.
}

/**
 * Meldt iets op het scherm en stuurt terug naar het tabblad (de melding reist mee in een transient, zoals bij options.php).
 *
 * @param string               $tab     redirects, 404 of io.
 * @param string               $message Tekst.
 * @param string               $type    success, error, warning of info.
 * @param array<string,string> $args    Extra queryvariabelen voor de URL.
 */
function _ww_redirects_admin_done( string $tab, string $message, string $type = 'success', array $args = array() ): void {
	add_settings_error( 'ww_redirects', 'ww_redirects_' . $type, esc_html( $message ), $type );
	set_transient( 'settings_errors', get_settings_errors(), 30 );
	if ( wp_safe_redirect(
		_ww_redirects_admin_url(
			array(
				'tab'              => $tab,
				'settings-updated' => 'true',
			) + $args
		)
	) ) {
		exit;
	}
}

/**
 * Leest een tekstveld uit het verzoek, zonder het te saniteren: %-codes in paden moeten blijven.
 *
 * @param array<mixed> $source $_POST of $_GET.
 * @param string       $key    Veldnaam.
 */
function _ww_redirects_admin_field( array $source, string $key ): string {
	return trim( _ww_data_to_string( wp_unslash( $source[ $key ] ?? '' ) ) );
}

/**
 * De ids of paden uit een lijstveld van het verzoek.
 *
 * @param string $key Veldnaam in $_POST.
 * @return string[]
 */
function _ww_redirects_admin_list_field( string $key ): array {
	// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput -- de nonce is gecontroleerd in _ww_redirects_admin_handle(); paden worden alleen als waarde in een query gebruikt.
	$values = isset( $_POST[ $key ] ) && is_array( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : array();
	return array_values( array_map( '_ww_data_to_string', $values ) );
}

/**
 * Voert de actie uit het verzoek uit (admin_init). Zie WW_REDIRECTS_ACTIONS.
 */
function _ww_redirects_admin_handle(): void {
	_ww_redirects_admin_form( array() );
	// phpcs:disable WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput -- de nonce wordt hieronder per actie gecontroleerd.
	$action = isset( $_REQUEST['ww_redirects_action'] ) ? sanitize_key( _ww_data_to_string( wp_unslash( $_REQUEST['ww_redirects_action'] ) ) ) : '';
	if ( '' === $action && ! wp_doing_ajax() && isset( $_REQUEST['page'] ) && WW_REDIRECTS_SCREEN === _ww_data_to_string( wp_unslash( $_REQUEST['page'] ) ) ) {
		// Het keuzelijstje boven en onder de tabel stuurt zijn keuze als action en action2, alleen op dit scherm.
		foreach ( array( 'action', 'action2' ) as $key ) {
			$chosen = isset( $_REQUEST[ $key ] ) ? sanitize_key( _ww_data_to_string( wp_unslash( $_REQUEST[ $key ] ) ) ) : '';
			if ( in_array( $chosen, array( 'bulk-delete', 'log-bulk-delete' ), true ) ) {
				$action = $chosen;
				break;
			}
		}
	}
	// phpcs:enable
	if ( ! in_array( $action, WW_REDIRECTS_ACTIONS, true ) ) {
		return;
	}

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Je hebt geen rechten om redirects te beheren.', 'webwerckt-base' ), 403 );
	}
	check_admin_referer( 'ww_redirects_' . $action );

	global $wpdb;

	switch ( $action ) {
		case 'save':
			$edit = absint( _ww_redirects_admin_field( $_POST, 'ww_id' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce gecontroleerd.
			$rule = array(
				'source'     => _ww_redirects_admin_field( $_POST, 'ww_source' ), // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce gecontroleerd.
				'target'     => _ww_redirects_admin_field( $_POST, 'ww_target' ), // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce gecontroleerd.
				'status'     => (int) _ww_redirects_admin_field( $_POST, 'ww_status' ), // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce gecontroleerd.
				// Een vinkje: zonder vinkje komt het veld niet mee, en dan is het exact.
				'match_type' => 'prefix' === _ww_redirects_admin_field( $_POST, 'ww_match_type' ) ? 'prefix' : 'exact', // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce gecontroleerd.
				'origin'     => 'manual',
			);
			// Bij een ongewijzigde bron blijft de regel wat hij was: een slug-regel blijft aan zijn bericht gekoppeld.
			$current = $edit > 0 ? _ww_redirects_admin_get( $edit ) : null;
			if ( null !== $current && _ww_redirect_normalize( $rule['source'] ) === $current->source ) {
				$rule['origin']  = (string) $current->origin;
				$rule['post_id'] = (int) $current->post_id;
			}
			$from_log = '404' === _ww_redirects_admin_field( $_POST, 'ww_from' ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce gecontroleerd.
			$id       = ww_redirect_save( $rule );
			if ( $id instanceof WP_Error ) {
				_ww_redirects_admin_form(
					$rule + array(
						'id'   => $edit,
						'from' => $from_log ? '404' : '',
					)
				);
				add_settings_error( 'ww_redirects', $id->get_error_code(), esc_html( $id->get_error_message() ) );
				return;
			}
			if ( $edit > 0 && $edit !== $id ) {
				// De bron is veranderd: de oude regel gaat weg.
				ww_redirect_delete( $edit );
			}
			_ww_redirects_check_target( $id );
			_ww_redirects_check_prefix( $id );
			if ( $from_log ) {
				_ww_redirects_admin_done( '404', __( 'De redirect is opgeslagen.', 'webwerckt-base' ) . ' ' . __( 'Het pad is uit het 404-logboek gehaald.', 'webwerckt-base' ) );
				return;
			}
			_ww_redirects_admin_done( 'redirects', __( 'De redirect is opgeslagen.', 'webwerckt-base' ) );
			return;

		case 'delete':
			$id = absint( _ww_redirects_admin_field( $_POST, 'id' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce gecontroleerd.
			ww_redirect_delete( $id );
			_ww_redirects_admin_done( 'redirects', __( 'De redirect is verwijderd.', 'webwerckt-base' ) );
			return;

		case 'bulk-delete':
			$count = 0;
			foreach ( _ww_redirects_admin_list_field( 'ids' ) as $raw_id ) {
				$id = absint( $raw_id );
				if ( $id > 0 && ww_redirect_delete( $id ) ) {
					++$count;
				}
			}
			_ww_redirects_admin_done(
				'redirects',
				sprintf(
					/* translators: %d: aantal redirects. */
					_n( '%d redirect verwijderd.', '%d redirects verwijderd.', $count, 'webwerckt-base' ),
					$count
				)
			);
			return;

		case 'import-preview':
			$csv = _ww_redirects_admin_uploaded_csv();
			if ( '' === trim( $csv ) ) {
				add_settings_error( 'ww_redirects', 'ww_redirects_import_empty', __( 'Kies een CSV-bestand of plak de regels in het tekstveld.', 'webwerckt-base' ) );
				return;
			}
			$rules = _ww_redirects_parse_csv( $csv );
			if ( $rules instanceof WP_Error ) {
				add_settings_error( 'ww_redirects', $rules->get_error_code(), esc_html( $rules->get_error_message() ) );
				return;
			}
			if ( array() === $rules ) {
				add_settings_error( 'ww_redirects', 'ww_redirects_import_empty', __( 'Het bestand bevat geen regels.', 'webwerckt-base' ) );
				return;
			}
			set_transient( 'ww_redirects_import_' . get_current_user_id(), $rules, HOUR_IN_SECONDS );
			if ( wp_safe_redirect(
				_ww_redirects_admin_url(
					array(
						'tab'       => 'io',
						'ww_import' => 'preview',
					)
				)
			) ) {
				exit;
			}
			return;

		case 'import-apply':
			$key   = 'ww_redirects_import_' . get_current_user_id();
			$rules = get_transient( $key );
			if ( ! is_array( $rules ) ) {
				add_settings_error( 'ww_redirects', 'ww_redirects_import_expired', __( 'Het voorbeeld is verlopen: kies het bestand opnieuw.', 'webwerckt-base' ) );
				return;
			}
			delete_transient( $key );
			$result = _ww_redirects_import( $rules, false );
			foreach ( $result['rows'] as $row ) {
				if ( 'error' === $row['result'] && ! empty( $row['message'] ) ) {
					add_settings_error( 'ww_redirects', 'ww_redirects_import_row', esc_html( $row['source'] ) . ': ' . esc_html( $row['message'] ), 'warning' );
				}
			}
			$totals = $result['totals'];
			_ww_redirects_admin_done(
				'io',
				sprintf(
					/* translators: 1: nieuwe regels, 2: bijgewerkte regels, 3: ongewijzigde regels, 4: foute regels. */
					__( 'Geïmporteerd: %1$d nieuw, %2$d bijgewerkt, %3$d ongewijzigd, %4$d met een fout.', 'webwerckt-base' ),
					$totals['new'],
					$totals['update'],
					$totals['unchanged'],
					$totals['error']
				),
				'success',
				array( 'ww_imported' => '1' )
			);
			return;

		case 'export':
			_ww_redirects_export_send();
			exit;

		case 'log-delete':
			$wpdb->delete( _ww_404_log_table(), array( 'path' => _ww_redirects_admin_field( $_GET, 'path' ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- nonce gecontroleerd.
			_ww_redirects_admin_done( '404', __( 'Het pad is uit het logboek gehaald.', 'webwerckt-base' ) );
			return;

		case 'log-bulk-delete':
			$count = 0;
			foreach ( _ww_redirects_admin_list_field( 'paths' ) as $path ) {
				$count += (int) $wpdb->delete( _ww_404_log_table(), array( 'path' => $path ) );
			}
			_ww_redirects_admin_done(
				'404',
				sprintf(
					/* translators: %d: aantal paden. */
					_n( '%d pad uit het logboek gehaald.', '%d paden uit het logboek gehaald.', $count, 'webwerckt-base' ),
					$count
				)
			);
			return;

		case 'log-clear':
			$wpdb->query( 'DELETE FROM ' . _ww_404_log_table() ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_404_log_table().
			_ww_redirects_admin_done( '404', __( 'Het 404-logboek is leeggemaakt.', 'webwerckt-base' ) );
			return;
	}
}
add_action( 'admin_init', '_ww_redirects_admin_handle' );

/**
 * De CSV uit het formulier: het geuploade bestand, of anders de geplakte tekst. Een BOM blijft staan voor de parser.
 */
function _ww_redirects_admin_uploaded_csv(): string {
	// phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput -- nonce gecontroleerd in _ww_redirects_admin_handle(); een bestand wordt alleen gelezen en geparsed.
	if ( isset( $_FILES['ww_csv']['tmp_name'], $_FILES['ww_csv']['error'] ) && UPLOAD_ERR_OK === (int) $_FILES['ww_csv']['error'] ) {
		$tmp = _ww_data_to_string( $_FILES['ww_csv']['tmp_name'] );
		if ( is_uploaded_file( $tmp ) && filesize( $tmp ) <= 4 * MB_IN_BYTES ) {
			return (string) file_get_contents( $tmp ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- tijdelijk uploadbestand.
		}
	}
	return isset( $_POST['ww_csv_text'] ) ? _ww_data_to_string( wp_unslash( $_POST['ww_csv_text'] ) ) : '';
	// phpcs:enable
}
