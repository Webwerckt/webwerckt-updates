<?php
/**
 * Padfilter: welke paden (bots, statische bestanden) horen niet in het 404-logboek en niet in de statistieken.
 *
 * Alleen functies, geen hooks: dit bestand wordt ook door de mu-plugin geladen, vóór het thema.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Hoort dit (genormaliseerde) pad niet in het logboek, omdat het een bot of een statisch bestand is?
 *
 * Een patroon dat met een punt begint is een extensie en telt alleen aan het eind van het pad; elk ander patroon is een
 * stuk tekst dat in het pad moet voorkomen. Een .xml-bestand wordt genegeerd, behalve als het pad sitemap bevat.
 *
 * @param string $path Genormaliseerd pad.
 */
function _ww_404_log_ignored( string $path ): bool {
	$path = strtolower( $path );

	/**
	 * Patronen van paden die niet in het 404-logboek komen.
	 *
	 * @param string[] $patterns Stukken tekst, of extensies die met een punt beginnen.
	 */
	$patterns = apply_filters(
		'ww_404_log_ignore',
		array(
			'.php',
			'.sql',
			'.bak',
			'.zip',
			'/.env',
			'/.git',
			'wp-login',
			'xmlrpc',
			'/wp-admin',
			'/wp-includes/',
			'/wp-content/plugins/',
			'/wp-content/themes/',
			'/cgi-bin/',
			'/.well-known/',
			'.js',
			'.css',
			'.map',
			'.json',
			'.xml',
			'.ico',
			'.jpg',
			'.jpeg',
			'.png',
			'.gif',
			'.webp',
			'.avif',
			'.svg',
		)
	);

	foreach ( (array) $patterns as $pattern ) {
		$pattern = strtolower( (string) $pattern );
		if ( '' === $pattern ) {
			continue;
		}
		if ( '.xml' === $pattern && str_contains( $path, 'sitemap' ) ) {
			continue;
		}
		if ( str_starts_with( $pattern, '.' ) ? str_ends_with( $path, $pattern ) : str_contains( $path, $pattern ) ) {
			return true;
		}
	}
	return false;
}
