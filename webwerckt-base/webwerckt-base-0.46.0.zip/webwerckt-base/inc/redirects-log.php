<?php
/**
 * 404-logboek: welke paden bezoekers niet vinden, zonder bots en zonder persoonsgegevens (beslissing 0031).
 *
 * Per pad een teller, het eerste en laatste moment en de laatste verwijzer (alleen host en pad). Er wordt geen IP-adres
 * of user agent bewaard. Een dagelijkse cron houdt het logboek klein.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const WW_404_LOG_CLEANUP_HOOK = 'ww_404_log_cleanup';

/**
 * Hoeveel dagen een pad na de eerste keer "nieuw" heet in het beheer.
 */
const WW_404_LOG_NEW_DAYS = 7;

/**
 * Haalt de paden uit het logboek die een regel nu opvangt: bij exact het pad zelf, bij een voorvoegsel ook alles
 * eronder. Een % of _ in de bron is geen joker.
 *
 * @param string $source     Genormaliseerde bron van de regel.
 * @param string $match_type exact of prefix.
 * @return int Aantal verwijderde paden.
 */
function _ww_404_log_forget( string $source, string $match_type ): int {
	global $wpdb;
	$table = _ww_404_log_table();
	if ( 'prefix' === $match_type ) {
		$below   = $wpdb->esc_like( rtrim( $source, '/' ) . '/' ) . '%';
		$deleted = $wpdb->query( $wpdb->prepare( "DELETE FROM $table WHERE path = %s OR path LIKE %s", $source, $below ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_404_log_table().
	} else {
		$deleted = $wpdb->delete( $table, array( 'path' => $source ) );
	}
	return is_int( $deleted ) ? $deleted : 0;
}

/**
 * Het aantal paden dat de laatste WW_404_LOG_NEW_DAYS dagen voor het eerst is gezien.
 */
function _ww_404_log_new_count(): int {
	global $wpdb;
	return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . _ww_404_log_table() . ' WHERE first_seen >= %s', gmdate( 'Y-m-d H:i:s', time() - WW_404_LOG_NEW_DAYS * DAY_IN_SECONDS ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_404_log_table().
}

/**
 * Of een pad met deze first_seen (UTC, uit de tabel) nieuw is.
 *
 * @param string $first_seen Y-m-d H:i:s in UTC.
 */
function _ww_404_log_is_new( string $first_seen ): bool {
	$time = strtotime( $first_seen . ' UTC' );
	return false !== $time && $time >= time() - WW_404_LOG_NEW_DAYS * DAY_IN_SECONDS;
}

/**
 * De teller van één pad, of 0 als het pad niet in het logboek staat.
 *
 * @param string $path Genormaliseerd pad.
 */
function _ww_404_log_hits( string $path ): int {
	global $wpdb;
	return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT hits FROM ' . _ww_404_log_table() . ' WHERE path = %s', $path ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_404_log_table().
}

/**
 * Of een bewaarde verwijzer (host en pad) van deze site zelf komt.
 *
 * @param string $referrer Verwijzer zoals in het logboek, bijvoorbeeld "example.org/over-ons/".
 */
function _ww_404_log_is_internal( string $referrer ): bool {
	if ( '' === $referrer ) {
		return false;
	}
	$host = explode( '/', $referrer, 2 )[0];
	return '' !== $host && strtolower( $host ) === strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
}

/**
 * Telt een 404 voor een pad: een nieuwe rij, of de teller en de laatste keer erbij.
 *
 * De verwijzer wordt ingekort tot host en pad (zonder query-string), hoogstens 255 tekens. Een lege verwijzer laat de
 * vorige staan.
 *
 * @param string $path     Genormaliseerd pad.
 * @param string $referrer Volledige verwijzer, of ''.
 */
function _ww_404_log_record( string $path, string $referrer ): void {
	global $wpdb;

	$short = '';
	if ( '' !== $referrer ) {
		$parts = wp_parse_url( $referrer );
		if ( is_array( $parts ) && ! empty( $parts['host'] ) ) {
			$short = mb_substr( $parts['host'] . ( $parts['path'] ?? '' ), 0, 255 );
		}
	}

	$now = gmdate( 'Y-m-d H:i:s' );
	$wpdb->query( $wpdb->prepare( 'INSERT INTO ' . _ww_404_log_table() . " (path, hits, first_seen, last_seen, referrer) VALUES (%s, 1, %s, %s, %s) ON DUPLICATE KEY UPDATE hits = hits + 1, last_seen = %s, referrer = IF(VALUES(referrer) = '', referrer, VALUES(referrer))", $path, $now, $now, $short, $now ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_404_log_table().
}

/**
 * Logt een echte 404 aan de voorkant (template_redirect, prioriteit 999).
 *
 * Niet bij een 410 van een redirectregel, een bot of statisch bestand, een verzoek dat geen GET of HEAD is, of als de
 * tabellen er nog niet zijn.
 */
function _ww_404_log_maybe(): void {
	if ( ! is_404() || _ww_redirect_was_410() || ! _ww_redirects_ready() || ! _ww_redirect_is_frontend_request() ) {
		return;
	}

	$uri  = isset( $_SERVER['REQUEST_URI'] ) ? _ww_data_to_string( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- het pad wordt genormaliseerd; %-codes moeten blijven.
	$path = '' === $uri ? null : _ww_redirect_normalize( $uri );
	if ( null === $path || _ww_404_log_ignored( $path ) ) {
		return;
	}

	$referrer = wp_get_raw_referer();
	_ww_404_log_record( $path, is_string( $referrer ) ? $referrer : '' );
}
add_action( 'template_redirect', '_ww_404_log_maybe', 999 );

/**
 * Ruimt het logboek op: eerst rijen die te lang niet gezien zijn, dan de rijen met de minste hits boven het maximum
 * (bij gelijke hits de oudste last_seen).
 */
function _ww_404_log_cleanup(): void {
	if ( ! _ww_redirects_ready() ) {
		return;
	}
	global $wpdb;
	$table = _ww_404_log_table();

	/**
	 * Hoeveel dagen een pad in het 404-logboek blijft na de laatste keer dat het gezien is.
	 *
	 * @param int $days Standaard 30.
	 */
	$days = max( 1, (int) apply_filters( 'ww_404_log_max_age', 30 ) );
	$wpdb->query( $wpdb->prepare( "DELETE FROM $table WHERE last_seen < %s", gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_404_log_table().

	/**
	 * Hoeveel rijen het 404-logboek hoogstens heeft.
	 *
	 * @param int $rows Standaard 2000.
	 */
	$max   = max( 1, (int) apply_filters( 'ww_404_log_max_rows', 2000 ) );
	$count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_404_log_table().
	if ( $count <= $max ) {
		return;
	}

	$drop = $wpdb->get_col( $wpdb->prepare( "SELECT path FROM $table ORDER BY hits ASC, last_seen ASC LIMIT %d", $count - $max ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_404_log_table().
	if ( array() === $drop ) {
		return;
	}
	$in = implode( ',', array_fill( 0, count( $drop ), '%s' ) );
	$wpdb->query( $wpdb->prepare( "DELETE FROM $table WHERE path IN ($in)", $drop ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- tabelnaam en placeholders zijn eigen waarden.
}
add_action( WW_404_LOG_CLEANUP_HOOK, '_ww_404_log_cleanup' );

/**
 * Plant de dagelijkse opruiming in als dat nog niet is gebeurd (bij een adminbezoek).
 */
function _ww_404_log_schedule(): void {
	if ( ! wp_next_scheduled( WW_404_LOG_CLEANUP_HOOK ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', WW_404_LOG_CLEANUP_HOOK );
	}
}
add_action( 'admin_init', '_ww_404_log_schedule' );

/**
 * Ander thema actief: de opruiming weg.
 */
function _ww_404_log_unschedule(): void {
	wp_clear_scheduled_hook( WW_404_LOG_CLEANUP_HOOK );
}
add_action( 'switch_theme', '_ww_404_log_unschedule' );
