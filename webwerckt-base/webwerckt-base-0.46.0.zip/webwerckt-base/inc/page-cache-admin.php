<?php
/**
 * Paginacache: het hoofdmenu Pagina cache, alleen voor beheerders (beslissing 0028). Een zijpaneel met de onderdelen
 * Overzicht, Bewaarde pagina's, Overgeslagen en Instellingen (inc/page-cache-admin-sections.php), de acties via
 * admin-post.php die terugsturen naar hun onderdeel, en de meldingen daarna. De techniek staat in Site-gezondheid.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const WW_PAGE_CACHE_ADMIN_PAGE = 'ww-page-cache';
const WW_PAGE_CACHE_ADMIN_CAP  = 'manage_options';
const WW_PAGE_CACHE_PER_PAGE   = 50;

/**
 * Voegt het hoofdmenu Pagina cache toe, onder Instellingen.
 */
function _ww_page_cache_admin_menu(): void {
	add_menu_page(
		__( 'Pagina cache', 'webwerckt-base' ),
		__( 'Pagina cache', 'webwerckt-base' ),
		WW_PAGE_CACHE_ADMIN_CAP,
		WW_PAGE_CACHE_ADMIN_PAGE,
		'_ww_page_cache_admin_render',
		'dashicons-performance',
		81
	);
}
add_action( 'admin_menu', '_ww_page_cache_admin_menu' );

/**
 * Laadt de stijl, alleen op dit scherm.
 *
 * @param string $hook Admin-scherm.
 */
function _ww_page_cache_admin_assets( string $hook ): void {
	if ( 'toplevel_page_' . WW_PAGE_CACHE_ADMIN_PAGE !== $hook || ! current_user_can( WW_PAGE_CACHE_ADMIN_CAP ) ) {
		return;
	}
	wp_enqueue_style( 'ww-page-cache-admin', _ww_asset_url( 'css/page-cache-admin.css' ), array(), WW_BASE_VERSION );
}
add_action( 'admin_enqueue_scripts', '_ww_page_cache_admin_assets' );

/**
 * URL van de pagina Pagina cache, eventueel met extra queryvariabelen. Overzicht is het begin: daar geen tab.
 *
 * @param array<string,string> $args Queryvariabelen.
 */
function _ww_page_cache_admin_url( array $args = array() ): string {
	if ( 'overview' === ( $args['tab'] ?? '' ) ) {
		unset( $args['tab'] );
	}
	return add_query_arg( array( 'page' => WW_PAGE_CACHE_ADMIN_PAGE ) + $args, admin_url( 'admin.php' ) );
}

/**
 * De titel van een pagina voor de lijsten. Niet geëscapet. Het eerste dat past: de titel van het bericht, de titel van
 * het bericht achter de URL, "Home" voor de voorpagina, anders het pad.
 *
 * @param string $url     Volledige URL.
 * @param int    $post_id Bericht-ID als dat bekend is, anders 0.
 */
function _ww_page_cache_title( string $url, int $post_id = 0 ): string {
	if ( $post_id <= 0 ) {
		$post_id = (int) url_to_postid( $url );
	}
	if ( $post_id > 0 && null !== get_post( $post_id ) ) {
		$title = get_the_title( $post_id );
		if ( '' !== $title ) {
			return $title;
		}
	}
	$path = (string) wp_parse_url( $url, PHP_URL_PATH );
	if ( '' === $path || '/' === $path ) {
		return __( 'Home', 'webwerckt-base' );
	}
	return $path;
}

/**
 * Filtert en sorteert de pagina's voor de tabel. Los van de tabel, zodat het te testen is.
 *
 * @param list<array{key:string,url:string,created:float,expires:int,post_types:string[],post_id:int,size:int,title?:string}> $entries Pagina's.
 * @param string                                                                                                              $search  Zoeken in titel en URL.
 * @param string                                                                                                              $orderby 'title', 'created' of 'expires'.
 * @param string                                                                                                              $order   'asc' of 'desc'.
 * @return list<array{key:string,url:string,created:float,expires:int,post_types:string[],post_id:int,size:int,title?:string}>
 */
function _ww_page_cache_admin_rows( array $entries, string $search, string $orderby, string $order ): array {
	if ( '' !== $search ) {
		$entries = array_values(
			array_filter(
				$entries,
				static fn( array $entry ): bool => false !== stripos( $entry['url'], $search ) || ( isset( $entry['title'] ) && false !== stripos( $entry['title'], $search ) )
			)
		);
	}
	$orderby = in_array( $orderby, array( 'title', 'created', 'expires' ), true ) ? $orderby : 'title';
	usort(
		$entries,
		static fn( array $a, array $b ): int => 'title' === $orderby ? strnatcasecmp( $a['title'] ?? $a['url'], $b['title'] ?? $b['url'] ) : $a[ $orderby ] <=> $b[ $orderby ]
	);
	return 'desc' === strtolower( $order ) ? array_reverse( $entries ) : $entries;
}

/**
 * Leegt de hele cache (formulier op de pagina, via admin-post.php).
 */
function _ww_page_cache_admin_flush(): void {
	if ( ! current_user_can( WW_PAGE_CACHE_ADMIN_CAP ) ) {
		wp_die( esc_html__( 'Je hebt geen rechten om de paginacache te legen.', 'webwerckt-base' ), 403 );
	}
	check_admin_referer( 'ww_page_cache_flush' );
	$count = count( _ww_page_cache_entries() );
	_ww_page_cache_flush();
	// Ook de overgeslagen pagina's en de lijst van het opwarmen opnieuw, net als bij _ww_purge_all: anders blijft een
	// pagina die eerder niet in de cache kwam na legen nog een dag leeg.
	_ww_page_cache_preload_reset();
	wp_safe_redirect( _ww_page_cache_admin_url( array( 'ww_flushed' => (string) $count ) ) );
	exit;
}
add_action( 'admin_post_ww_page_cache_flush', '_ww_page_cache_admin_flush' );

/**
 * Leegt één pagina (actie in de tabel, via admin-post.php).
 */
function _ww_page_cache_admin_purge(): void {
	if ( ! current_user_can( WW_PAGE_CACHE_ADMIN_CAP ) ) {
		wp_die( esc_html__( 'Je hebt geen rechten om de paginacache te legen.', 'webwerckt-base' ), 403 );
	}
	$key = isset( $_GET['key'] ) && is_string( $_GET['key'] ) ? wp_unslash( $_GET['key'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput, WordPress.Security.NonceVerification -- gecontroleerd door check_admin_referer() en _ww_page_cache_purge_key().
	check_admin_referer( 'ww_page_cache_purge_' . $key );
	$done = _ww_page_cache_purge_key( $key );
	wp_safe_redirect(
		_ww_page_cache_admin_url(
			array(
				'tab'       => 'pages',
				'ww_purged' => $done ? '1' : '0',
			)
		)
	);
	exit;
}
add_action( 'admin_post_ww_page_cache_purge', '_ww_page_cache_admin_purge' );

/**
 * Zet opwarmen aan of uit (formulier op de pagina, via admin-post.php).
 */
function _ww_page_cache_admin_preload_toggle(): void {
	if ( ! current_user_can( WW_PAGE_CACHE_ADMIN_CAP ) ) {
		wp_die( esc_html__( 'Je hebt geen rechten om het opwarmen te wijzigen.', 'webwerckt-base' ), 403 );
	}
	check_admin_referer( 'ww_page_cache_preload_toggle' );
	$on = isset( $_POST['ww_preload'] ) && '1' === $_POST['ww_preload'];
	update_option( WW_PAGE_CACHE_PRELOAD_OPTION, $on ? '1' : '0', false );
	_ww_page_cache_preload_schedule();
	wp_safe_redirect(
		_ww_page_cache_admin_url(
			array(
				'tab'      => 'settings',
				'ww_saved' => '1',
			)
		)
	);
	exit;
}
add_action( 'admin_post_ww_page_cache_preload_toggle', '_ww_page_cache_admin_preload_toggle' );

/**
 * Probeert een overgeslagen pagina opnieuw (knop in de lijst, via admin-post.php).
 */
function _ww_page_cache_admin_preload_retry(): void {
	if ( ! current_user_can( WW_PAGE_CACHE_ADMIN_CAP ) ) {
		wp_die( esc_html__( 'Je hebt geen rechten om het opwarmen te wijzigen.', 'webwerckt-base' ), 403 );
	}
	check_admin_referer( 'ww_page_cache_preload_retry' );
	$url   = isset( $_POST['url'] ) && is_string( $_POST['url'] ) ? esc_url_raw( wp_unslash( $_POST['url'] ) ) : '';
	$found = '' !== $url && isset( _ww_page_cache_preload_skip( time() )[ $url ] );
	if ( $found ) {
		_ww_page_cache_preload_queue_url( $url );
	}
	wp_safe_redirect(
		_ww_page_cache_admin_url(
			array(
				'tab'        => 'skipped',
				'ww_retried' => $found ? '1' : '0',
			)
		)
	);
	exit;
}
add_action( 'admin_post_ww_page_cache_preload_retry', '_ww_page_cache_admin_preload_retry' );

/**
 * Warmt nu één ronde op (formulier op de pagina, via admin-post.php).
 */
function _ww_page_cache_admin_preload_run(): void {
	if ( ! current_user_can( WW_PAGE_CACHE_ADMIN_CAP ) ) {
		wp_die( esc_html__( 'Je hebt geen rechten om de paginacache op te warmen.', 'webwerckt-base' ), 403 );
	}
	check_admin_referer( 'ww_page_cache_preload_run' );
	$status = _ww_page_cache_preload_run();
	wp_safe_redirect( _ww_page_cache_admin_url( array( 'ww_preloaded' => 'busy' === $status['stop'] ? 'busy' : (string) $status['fetched'] ) ) );
	exit;
}
add_action( 'admin_post_ww_page_cache_preload_run', '_ww_page_cache_admin_preload_run' );

/**
 * Melding na een actie, uit de queryvariabelen van de redirect.
 */
function _ww_page_cache_admin_notice(): string {
	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- alleen een melding tonen.
	if ( isset( $_GET['ww_saved'] ) ) {
		return '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Instellingen opgeslagen.', 'webwerckt-base' ) . '</p></div>';
	}
	if ( isset( $_GET['ww_retried'] ) ) {
		$done = '1' === $_GET['ww_retried'];
		$text = $done ? __( 'De pagina staat vooraan voor de volgende ronde opwarmen.', 'webwerckt-base' ) : __( 'Die pagina stond niet (meer) op de lijst.', 'webwerckt-base' );
		return '<div class="notice ' . ( $done ? 'notice-success' : 'notice-warning' ) . ' is-dismissible"><p>' . esc_html( $text ) . '</p></div>';
	}
	if ( isset( $_GET['ww_preloaded'] ) ) {
		if ( 'busy' === $_GET['ww_preloaded'] ) {
			return '<div class="notice notice-warning is-dismissible"><p>' . esc_html__( 'Er loopt al een ronde opwarmen. Probeer het over een minuut opnieuw.', 'webwerckt-base' ) . '</p></div>';
		}
		$count = absint( $_GET['ww_preloaded'] );
		$text  = sprintf(
			/* translators: %d: aantal pagina's. */
			_n( 'Opgewarmd: %d pagina opgevraagd.', 'Opgewarmd: %d pagina\'s opgevraagd.', $count, 'webwerckt-base' ),
			$count
		);
		return '<div class="notice notice-success is-dismissible"><p>' . esc_html( $text ) . '</p></div>';
	}
	if ( isset( $_GET['ww_flushed'] ) ) {
		$count = absint( $_GET['ww_flushed'] );
		$text  = sprintf(
			/* translators: %d: aantal pagina's. */
			_n( 'De cache is geleegd: %d pagina.', 'De cache is geleegd: %d pagina\'s.', $count, 'webwerckt-base' ),
			$count
		);
		return '<div class="notice notice-success is-dismissible"><p>' . esc_html( $text ) . '</p></div>';
	}
	if ( isset( $_GET['ww_purged'] ) ) {
		$done = '1' === $_GET['ww_purged'];
		$text = $done ? __( 'De pagina is uit de cache gehaald. De volgende bezoeker of de volgende ronde opwarmen zet een verse versie klaar.', 'webwerckt-base' ) : __( 'Die pagina stond niet (meer) in de cache.', 'webwerckt-base' );
		return '<div class="notice ' . ( $done ? 'notice-success' : 'notice-warning' ) . ' is-dismissible"><p>' . esc_html( $text ) . '</p></div>';
	}
	// phpcs:enable
	return '';
}

/**
 * Toont de pagina Pagina cache: het zijpaneel met de onderdelen, dan de inhoud van het gekozen onderdeel.
 */
function _ww_page_cache_admin_render(): void {
	if ( ! current_user_can( WW_PAGE_CACHE_ADMIN_CAP ) ) {
		return;
	}
	$tab      = _ww_page_cache_admin_tab();
	$sections = _ww_page_cache_admin_sections();
	$state    = _ww_page_cache_admin_state();
	$off      = 'off' === $state['level'];
	$entries  = _ww_page_cache_entries();
	$skipped  = _ww_page_cache_preload_skipped( time() );
	$preload  = $off
		? array(
			'cached'  => 0,
			'total'   => 0,
			'pending' => array(),
		)
		: _ww_page_cache_preload_counts();
	$counts   = array(
		'pages'   => count( $entries ),
		'skipped' => count( $skipped ),
		'missing' => array() !== array_filter( $skipped, static fn( array $entry ): bool => 'missing' === _ww_page_cache_skip_reason( $entry['code'] ) ),
		'off'     => $off,
	);
	$status   = '<span class="ww-cache-dot ww-cache-dot--' . esc_attr( $state['level'] ) . '" aria-hidden="true"></span>' . esc_html( $state['label'] );

	switch ( $tab ) {
		case 'pages':
			$body = _ww_page_cache_render_pages( $entries, $off );
			break;
		case 'skipped':
			$body = _ww_page_cache_render_skipped( $skipped, $off );
			break;
		case 'settings':
			$body = _ww_page_cache_render_settings( $state );
			break;
		default:
			$body = _ww_page_cache_render_overview( $state, $preload, $entries );
	}

	// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- de onderdelen geven geëscapete HTML terug.
	echo '<div class="wrap ww-cache"><div class="ww-cache-layout">';
	echo '<nav class="ww-cache-panel" aria-label="' . esc_attr__( 'Onderdelen van de pagina cache', 'webwerckt-base' ) . '">';
	echo '<p class="ww-cache-panel__title">' . esc_html__( 'Pagina cache', 'webwerckt-base' ) . '</p>';
	echo '<p class="ww-cache-panel__status">' . $status . '</p>';
	echo _ww_page_cache_render_nav( $tab, $counts, 'panel' );
	echo _ww_page_cache_render_panel_card( $state, $preload );
	echo '<p class="ww-cache-panel__foot"><span class="dashicons dashicons-info-outline" aria-hidden="true"></span>' . esc_html__( 'Pas je een pagina aan, dan wordt die vanzelf vernieuwd. Je hoeft de cache daarvoor niet te legen.', 'webwerckt-base' ) . '</p>';
	echo '</nav>';

	echo '<div class="ww-cache-main">';
	echo '<h1>' . esc_html( $sections[ $tab ] ) . '</h1><hr class="wp-header-end">';
	echo '<div class="ww-cache-pickers">' . _ww_page_cache_render_nav( $tab, $counts, 'menu' ) . '</div>';
	echo '<p class="ww-cache-status-line">' . $status . '</p>';
	echo _ww_page_cache_admin_notice();
	// Op Overzicht staat bij een uitgezette cache dezelfde zin al in het vak 'Wat betekent dit?'.
	if ( 'settings' !== $tab && ( 'overview' !== $tab || 'off' !== $state['level'] ) && 'ok' !== $state['level'] && '' !== $state['notice'] ) {
		echo '<div class="notice notice-warning inline"><p>' . esc_html( $state['notice'] ) . '</p></div>';
	}
	echo $body;
	echo '</div>';
	echo '</div></div>';
	// phpcs:enable
}
