<?php
/**
 * reCAPTCHA v3 voor formulieren (beslissing 0032): de sleutels uit Formulieren › Instellingen en de controle bij Google.
 *
 * reCAPTCHA is actief als beide sleutels er zijn en het formulier het niet uitzet. De controle (siteverify) stuurt het
 * IP-adres van de bezoeker niet mee. Google onbereikbaar of een onleesbaar antwoord kost nooit een inzending: dat is
 * `none`. Alleen een duidelijk verdacht antwoord (score, actie of hostnaam) is `spam`.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WW_FORMS_OPT_SITE_KEY', 'ww_forms_recaptcha_site_key' );
define( 'WW_FORMS_OPT_SECRET', 'ww_forms_recaptcha_secret' );
define( 'WW_FORMS_OPT_THRESHOLD', 'ww_forms_recaptcha_threshold' );
define( 'WW_FORMS_OPT_ATTACH_MAX', 'ww_forms_attach_max_mb' );

/**
 * De sitesleutel (leeg als die niet is ingesteld).
 */
function _ww_form_recaptcha_site_key(): string {
	return trim( (string) get_option( WW_FORMS_OPT_SITE_KEY, '' ) );
}

/**
 * De geheime sleutel (leeg als die niet is ingesteld).
 */
function _ww_form_recaptcha_secret(): string {
	return trim( (string) get_option( WW_FORMS_OPT_SECRET, '' ) );
}

/**
 * De scoregrens, begrensd tot 0,1 - 0,9 (standaard 0,5).
 */
function _ww_form_recaptcha_threshold(): float {
	$value = get_option( WW_FORMS_OPT_THRESHOLD, 0.5 );
	$value = is_numeric( $value ) ? (float) $value : 0.5;
	return round( min( 0.9, max( 0.1, $value ) ), 2 );
}

/**
 * Zijn beide sleutels ingesteld?
 */
function _ww_form_recaptcha_configured(): bool {
	return '' !== _ww_form_recaptcha_site_key() && '' !== _ww_form_recaptcha_secret();
}

/**
 * Is reCAPTCHA actief voor dit formulier: sleutels ingesteld en het formulier zet het niet uit.
 *
 * @param array<string,mixed> $config Configuratie van het formulier.
 */
function _ww_form_recaptcha_active( array $config ): bool {
	return _ww_form_recaptcha_configured() && ! empty( $config['recaptcha'] );
}

/**
 * Roept siteverify aan. Geeft de gedecodeerde JSON, of null bij een netwerkfout, een andere status dan 200 of ongeldige JSON.
 *
 * @param string $secret   Geheime sleutel.
 * @param string $response Token (mag leeg zijn, voor de sleutelcontrole).
 * @return array<string,mixed>|null
 */
function _ww_form_recaptcha_request( string $secret, string $response ): ?array {
	$reply = wp_remote_post(
		'https://www.google.com/recaptcha/api/siteverify',
		array(
			'timeout' => 5,
			'body'    => array(
				'secret'   => $secret,
				'response' => $response,
			),
		)
	);
	if ( is_wp_error( $reply ) ) {
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- bewust: de beheerder moet het kunnen terugvinden.
		error_log( sprintf( 'webwerckt-base: reCAPTCHA niet bereikbaar (%s).', $reply->get_error_message() ) );
		return null;
	}
	$code = (int) wp_remote_retrieve_response_code( $reply );
	if ( 200 !== $code ) {
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- bewust: de beheerder moet het kunnen terugvinden.
		error_log( sprintf( 'webwerckt-base: reCAPTCHA niet bereikbaar (%s).', 'HTTP ' . $code ) );
		return null;
	}
	$data = json_decode( wp_remote_retrieve_body( $reply ), true );
	return is_array( $data ) ? $data : null;
}

/**
 * Controleert een token bij Google: `pass`, `spam` of `none` (geen oordeel mogelijk).
 *
 * @param string $token Waarde van ww_recaptcha.
 */
function _ww_form_recaptcha_verify( string $token ): string {
	if ( '' === $token ) {
		return 'none';
	}
	$data = _ww_form_recaptcha_request( _ww_form_recaptcha_secret(), substr( $token, 0, 4000 ) );
	if ( null === $data || empty( $data['success'] ) ) {
		return 'none';
	}

	$action = isset( $data['action'] ) && is_string( $data['action'] ) ? $data['action'] : '';
	if ( 'ww_form' !== $action ) {
		return 'spam';
	}

	if ( ! in_array( _ww_form_recaptcha_response_host( $data ), _ww_form_recaptcha_hostnames(), true ) ) {
		return 'spam';
	}

	$score = isset( $data['score'] ) && is_numeric( $data['score'] ) ? (float) $data['score'] : 0.0;
	return $score < _ww_form_recaptcha_threshold() ? 'spam' : 'pass';
}

/**
 * De hostnamen die een geldige token mag hebben, in kleine letters: de host van home_url(), aan te vullen met het filter
 * `ww_form_recaptcha_hostnames`.
 *
 * @return list<string>
 */
function _ww_form_recaptcha_hostnames(): array {
	$home  = wp_parse_url( home_url(), PHP_URL_HOST );
	$hosts = apply_filters( 'ww_form_recaptcha_hostnames', array( is_string( $home ) ? $home : '' ) );
	return array_values( array_map( 'strtolower', array_filter( (array) $hosts, 'is_string' ) ) );
}

/**
 * De hostnaam uit een antwoord van siteverify, in kleine letters ('' als hij ontbreekt).
 *
 * @param array<string,mixed> $data Antwoord van Google.
 */
function _ww_form_recaptcha_response_host( array $data ): string {
	return isset( $data['hostname'] ) && is_string( $data['hostname'] ) ? strtolower( $data['hostname'] ) : '';
}

/**
 * De uitkomst van de reCAPTCHA-controle in deze aanvraag (`pass`, `spam`, `none` of `off`). Standaard `off`; een lege
 * waarde of een onbekende waarde zet hem terug op `off`.
 *
 * @param string|null $set Nieuwe uitkomst.
 */
function _ww_form_recaptcha_result( ?string $set = null ): string {
	static $result = 'off';
	if ( null !== $set ) {
		$result = in_array( $set, array( 'pass', 'spam', 'none' ), true ) ? $set : 'off';
	}
	return $result;
}

/**
 * Een uitkomst van Sleutels controleren.
 *
 * @param string $level   `success`, `warning` of `error`.
 * @param string $message Melding voor het scherm.
 * @return array{ok: bool, level: string, message: string}
 */
function _ww_form_recaptcha_check_result( string $level, string $message ): array {
	return array(
		'ok'      => 'success' === $level,
		'level'   => $level,
		'message' => $message,
	);
}

/**
 * De knop Sleutels controleren. De browser haalt met de sitesleutel een token op (actie `ww_form_check`) en die gaat
 * met de geheime sleutel naar siteverify; zo worden beide sleutels en het domein getest. Zonder geldige token geeft
 * Google voor elke geheime sleutel hetzelfde antwoord, dus dan is de uitkomst hoogstens een waarschuwing.
 *
 * @param string $token Token uit de browser, leeg als die er niet kwam (geen JavaScript, script geblokkeerd).
 * @return array{ok: bool, level: string, message: string}
 */
function _ww_form_recaptcha_check_keys( string $token = '' ): array {
	$secret = _ww_form_recaptcha_secret();
	if ( '' === $secret ) {
		return _ww_form_recaptcha_check_result( 'error', __( 'Er is nog geen geheime sleutel ingesteld.', 'webwerckt-base' ) );
	}
	if ( '' === _ww_form_recaptcha_site_key() ) {
		return _ww_form_recaptcha_check_result( 'error', __( 'Er is nog geen sitesleutel ingesteld.', 'webwerckt-base' ) );
	}
	$data = _ww_form_recaptcha_request( $secret, substr( $token, 0, 4000 ) );
	if ( null === $data ) {
		return _ww_form_recaptcha_check_result( 'error', __( 'Google is niet bereikbaar. Probeer het later opnieuw.', 'webwerckt-base' ) );
	}
	$codes = isset( $data['error-codes'] ) && is_array( $data['error-codes'] ) ? $data['error-codes'] : array();
	if ( in_array( 'invalid-input-secret', $codes, true ) ) {
		return _ww_form_recaptcha_check_result( 'error', __( 'De geheime sleutel is niet juist.', 'webwerckt-base' ) );
	}
	if ( '' === $token ) {
		return _ww_form_recaptcha_check_result( 'warning', __( 'De browser kreeg geen token van Google, dus de sleutels zijn niet gecontroleerd. Kijk of de sitesleutel een sleutel van versie 3 is waar dit domein bij staat, en probeer het zonder adblocker opnieuw. Of de sleutels kloppen, zie je anders bij de eerste inzending (kolom Controle: Gecontroleerd).', 'webwerckt-base' ) );
	}
	if ( empty( $data['success'] ) ) {
		if ( in_array( 'timeout-or-duplicate', $codes, true ) ) {
			return _ww_form_recaptcha_check_result( 'error', __( 'De token was verlopen. Probeer het opnieuw.', 'webwerckt-base' ) );
		}
		return _ww_form_recaptcha_check_result( 'error', __( 'De sitesleutel en de geheime sleutel horen niet bij elkaar, of dit domein staat niet bij de sleutels in de reCAPTCHA-console.', 'webwerckt-base' ) );
	}
	$action = isset( $data['action'] ) && is_string( $data['action'] ) ? $data['action'] : '';
	if ( 'ww_form_check' !== $action ) {
		return _ww_form_recaptcha_check_result( 'error', __( 'Google gaf een onverwacht antwoord. Controleer of het sleutels van reCAPTCHA versie 3 zijn.', 'webwerckt-base' ) );
	}
	$host = _ww_form_recaptcha_response_host( $data );
	if ( ! in_array( $host, _ww_form_recaptcha_hostnames(), true ) ) {
		return _ww_form_recaptcha_check_result(
			'error',
			sprintf(
				/* translators: %s: hostnaam die Google teruggaf */
				__( 'De sleutels werken, maar Google gaf het domein %s terug. Voeg dat domein toe met het filter ww_form_recaptcha_hostnames, anders telt elke inzending als spam.', 'webwerckt-base' ),
				$host
			)
		);
	}
	return _ww_form_recaptcha_check_result( 'success', __( 'De sleutels zijn in orde.', 'webwerckt-base' ) );
}
