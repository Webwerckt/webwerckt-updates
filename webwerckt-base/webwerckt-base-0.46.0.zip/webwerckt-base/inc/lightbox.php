<?php
/**
 * Lightbox: een foto groter bekijken in een <dialog>, met bladeren door een groep foto's.
 *
 * De link, het script, de stijl en de dialoog komen alleen op pagina's waar een link is gemaakt. In Visueel bewerken,
 * in feeds en in de admin verandert er niets.
 *
 * @package webwerckt-base
 */

defined( 'ABSPATH' ) || exit;

/**
 * Mag er een lightbox-link komen? Niet in Visueel bewerken, in feeds en in de admin.
 */
function _ww_lightbox_enabled(): bool {
	return ! is_admin() && ! is_feed() && 0 === _ww_editor_post_id() && '' === _ww_editor_view();
}

/**
 * Bewaart de vlag per verzoek.
 */
function _ww_lightbox_flag( ?bool $set = null ): bool {
	static $used = false;
	if ( null !== $set ) {
		$used = $set;
	}
	return $used;
}

/**
 * Zet de vlag dat deze pagina een lightbox nodig heeft en laadt het script en de stijl.
 */
function _ww_lightbox_use(): void {
	_ww_lightbox_flag( true );
	wp_enqueue_script(
		'ww-lightbox',
		_ww_asset_url( 'js/lightbox.js' ),
		array(),
		WW_BASE_VERSION,
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);
	wp_enqueue_style( 'ww-lightbox', _ww_asset_url( 'css/lightbox.css' ), array(), WW_BASE_VERSION );
}

/**
 * Is er een lightbox-link gemaakt in dit verzoek?
 *
 * @param bool $reset Zet de vlag terug (voor de tests).
 */
function _ww_lightbox_used( bool $reset = false ): bool {
	return $reset ? _ww_lightbox_flag( false ) : _ww_lightbox_flag();
}

/**
 * Een groepsnaam die uniek is in dit verzoek, zodat de foto's van één blok samen bladeren.
 *
 * @param string $prefix Voorvoegsel, bijvoorbeeld 'ww-text'.
 * @param bool   $reset  Zet de teller terug (voor de tests).
 */
function _ww_lightbox_group( string $prefix, bool $reset = false ): string {
	static $count = 0;
	if ( $reset ) {
		$count = 0;
		return '';
	}
	++$count;
	return $prefix . '-' . $count;
}

/**
 * Wikkelt $inner in een link die de foto groot in de dialoog opent. Zonder lightbox of voor een bijlage die geen
 * afbeelding is komt $inner ongewijzigd terug.
 *
 * @param string $inner         De markup van de foto zoals hij op de pagina staat.
 * @param int    $attachment_id De bijlage.
 * @param string $group         Groepsnaam; '' is een losse foto.
 * @param string $caption       Onderschrift voor onder de grote foto (nooit de alt-tekst).
 * @param string $alt           Alt-tekst van de foto; leeg geeft de link een eigen label.
 */
function _ww_lightbox_link( string $inner, int $attachment_id, string $group, string $caption = '', string $alt = '' ): string {
	if ( ! _ww_lightbox_enabled() || ! wp_attachment_is_image( $attachment_id ) ) {
		return $inner;
	}
	$src = wp_get_attachment_image_src( $attachment_id, 'full' );
	if ( ! is_array( $src ) ) {
		return $inner;
	}
	$picture = _ww_images_picture(
		wp_get_attachment_image(
			$attachment_id,
			'full',
			false,
			array(
				'sizes'        => '100vw',
				'loading'      => 'eager',
				'decoding'     => 'async',
				'class'        => 'ww-lightbox__image skip-lazy',
				'alt'          => $alt,
				// Lazy-load en CDN-herschrijvers (LiteSpeed) laten deze <img> zo met rust; anders weigert het script hem.
				'data-no-lazy' => '1',
			)
		),
		$attachment_id
	);

	_ww_lightbox_use();

	return '<a class="ww-lightbox-link" href="' . esc_url( $src[0] ) . '" data-ww-lightbox="' . esc_attr( $group ) . '" aria-haspopup="dialog"'
		. ( '' === $caption ? '' : ' data-ww-lightbox-caption="' . esc_attr( $caption ) . '"' )
		. ( '' === $alt ? ' aria-label="' . esc_attr__( 'Foto vergroten', 'webwerckt-base' ) . '"' : '' )
		. '>' . $inner . '<template class="ww-lightbox-src">' . $picture . '</template></a>';
}

/**
 * De CSS van het raster van ww_gallery(), alleen de eerste keer in het verzoek; daarna ''. Met $reset weer van voren
 * af (tests). Staat direct voor de eerste galerij, zodat het raster er meteen is (ook in Visueel bewerken, waar
 * lightbox.css niet laadt). Elke selector staat in :where() en weegt dus niets: een child-thema overschrijft het
 * zonder !important, ook al staat deze <style> later in de pagina dan zijn stylesheet.
 *
 * @param bool $reset Vlag terugzetten.
 */
function _ww_gallery_css_once( bool $reset = false ): string {
	static $printed = false;
	if ( $reset ) {
		$printed = false;
		return '';
	}
	if ( $printed ) {
		return '';
	}
	$printed = true;
	return '<style id="ww-gallery-css">'
		. ':where(.ww-gallery){display:grid;grid-template-columns:repeat(auto-fill,minmax(var(--ww-gallery-min,160px),1fr));gap:var(--ww-gallery-gap,1rem);list-style:none;margin:0;padding:0}'
		. ':where(.ww-gallery__item .ww-lightbox-link){display:block}'
		. ':where(.ww-gallery__item img){display:block;width:100%;height:auto}'
		. '</style>';
}

/**
 * Meerdere-foto's-veld als raster van foto's die samen in de lightbox bladeren.
 *
 * In Visueel bewerken komen de foto's zonder link op de pagina. De CSS van het raster staat één keer per verzoek
 * direct voor de eerste galerij.
 *
 * @param string                    $name    Veldnaam.
 * @param string                    $size    Geregistreerd afbeeldingsformaat.
 * @param array<string,string|bool> $attr    Extra attributen voor elke <img>, bijvoorbeeld class. Een sleutel
 *                                           'lightbox' hier gaat voor de eigen groep van de galerij (zie ww_image_by_id()).
 * @param int                       $post_id Bericht-ID; 0 is het huidige bericht.
 * @return string Een <ul class="ww-gallery">, of '' bij een leeg veld.
 */
function ww_gallery( string $name, string $size = 'medium', array $attr = array(), int $post_id = 0 ): string {
	$ids = ww_image_ids( $name, $post_id );
	if ( ! $ids ) {
		return '';
	}
	$group = _ww_lightbox_group( 'ww-gallery' );
	$items = '';
	foreach ( $ids as $id ) {
		$items .= '<li class="ww-gallery__item">' . ww_image_by_id( $id, $size, $attr + array( 'lightbox' => $group ) ) . '</li>';
	}
	return _ww_gallery_css_once() . '<ul class="ww-gallery">' . $items . '</ul>';
}

/**
 * Linkt $href naar een bestand van deze bijlage: het hoofdbestand, een van de formaten of het origineel?
 *
 * @param string $href          De href van de link, met of zonder query.
 * @param int    $attachment_id De bijlage.
 */
function _ww_lightbox_links_to_attachment( string $href, int $attachment_id ): bool {
	$url  = wp_get_attachment_url( $attachment_id );
	$meta = wp_get_attachment_metadata( $attachment_id );
	if ( ! is_string( $url ) || '' === $url || ! is_array( $meta ) ) {
		return false;
	}
	$href = (string) strtok( $href, '?#' );
	if ( '' === $href || dirname( $href ) !== dirname( $url ) ) {
		return false;
	}
	$file = wp_basename( $href );
	return in_array( $file, _ww_images_files( $meta ), true )
		|| ( is_string( $meta['original_image'] ?? null ) && wp_basename( $meta['original_image'] ) === $file );
}

/**
 * Een bijschrift als platte tekst voor data-ww-lightbox-caption (het script zet het met textContent): een <br> wordt
 * een spatie, tags gaan weg en witruimte wordt één spatie.
 *
 * @param string $html Bijschrift, mogelijk met HTML.
 */
function _ww_lightbox_caption_text( string $html ): string {
	$text = wp_strip_all_tags( (string) preg_replace( '#<br\b[^>]*>#i', ' ', $html ) );
	$flat = preg_replace( '/\s+/u', ' ', $text );
	return trim( is_string( $flat ) ? $flat : $text );
}

/**
 * Pakt in lopende tekst elke link die om één foto staat en naar een bestand van die foto wijst in als lightbox-link.
 * De foto's van één tekst bladeren samen. Andere links blijven precies zoals ze zijn.
 *
 * Draait in ww_text() en op the_content (na shortcodes en wp_filter_content_tags), maar niet in een excerpt: die
 * gooit de tags weg en zou het script laden voor een pagina die het niet nodig heeft.
 *
 * @param string $html De HTML van de tekst.
 */
function _ww_lightbox_content( string $html ): string {
	/**
	 * Zet de lightbox in lopende tekst uit.
	 *
	 * @param bool $enabled Standaard aan.
	 */
	if ( '' === $html || false === stripos( $html, '<img' ) || ! _ww_lightbox_enabled() || doing_filter( 'get_the_excerpt' ) || ! apply_filters( 'ww_lightbox_content', true ) ) {
		return $html;
	}

	$group = '';
	$out   = preg_replace_callback(
		'#(<a\b[^>]*>)\s*(<img\b[^>]*>)\s*</a>(\s*<figcaption\b[^>]*>(.*?)</figcaption>)?#is',
		static function ( array $m ) use ( &$group ): string {
			$link = new WP_HTML_Tag_Processor( $m[1] );
			$href = $link->next_tag( array( 'tag_name' => 'a' ) ) ? $link->get_attribute( 'href' ) : null;

			$img = new WP_HTML_Tag_Processor( $m[2] );
			$id  = 0;
			$alt = '';
			if ( $img->next_tag( array( 'tag_name' => 'img' ) ) ) {
				foreach ( $img->class_list() as $class ) {
					if ( preg_match( '/^wp-image-(\d+)$/', $class, $found ) ) {
						$id = (int) $found[1];
						break;
					}
				}
				$alt = $img->get_attribute( 'alt' );
				$alt = is_string( $alt ) ? $alt : '';
			}

			if ( ! is_string( $href ) || $id <= 0 || ! wp_attachment_is_image( $id ) || ! _ww_lightbox_links_to_attachment( $href, $id ) ) {
				return $m[0];
			}

			$caption = _ww_lightbox_caption_text( $m[4] ?? '' );
			if ( '' === $caption ) {
				$caption = _ww_lightbox_caption_text( (string) wp_get_attachment_caption( $id ) );
			}
			if ( '' === $group ) {
				$group = _ww_lightbox_group( 'ww-text' );
			}
			$wrapped = _ww_lightbox_link( $m[2], $id, $group, $caption, $alt );
			return $wrapped === $m[2] ? $m[0] : $wrapped . ( $m[3] ?? '' );
		},
		$html
	);
	return is_string( $out ) ? $out : $html;
}
add_filter( 'the_content', '_ww_lightbox_content', 20 );

/**
 * Een knop-icoon als inline SVG (decoratief; de tekst staat in een verborgen span).
 */
function _ww_lightbox_icon( string $path ): string {
	return '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="' . esc_attr( $path ) . '"/></svg>';
}

/**
 * Drukt de dialoog af in de footer, maar alleen als er een lightbox-link is gemaakt.
 */
function _ww_lightbox_print_dialog(): void {
	if ( ! _ww_lightbox_used() ) {
		return;
	}
	/* translators: 1: nummer van de foto, 2: aantal foto's. */
	$counter = __( 'Foto %1$d van %2$d', 'webwerckt-base' );
	$buttons = array(
		'close' => array( 'M6 6l12 12M18 6L6 18', __( 'Sluiten', 'webwerckt-base' ), '' ),
		'prev'  => array( 'M15 5l-7 7 7 7', __( 'Vorige foto', 'webwerckt-base' ), ' hidden' ),
		'next'  => array( 'M9 5l7 7-7 7', __( 'Volgende foto', 'webwerckt-base' ), ' hidden' ),
	);
	?>
<dialog class="ww-lightbox" aria-label="<?php echo esc_attr__( 'Foto', 'webwerckt-base' ); ?>" data-ww-counter="<?php echo esc_attr( $counter ); ?>">
	<figure class="ww-lightbox__figure">
		<div class="ww-lightbox__media"></div>
		<figcaption class="ww-lightbox__caption" hidden></figcaption>
	</figure>
	<p class="ww-lightbox__counter" hidden><span aria-hidden="true"></span><span class="ww-lightbox__sr" aria-live="polite"></span></p>
	<?php foreach ( $buttons as $name => $button ) : ?>
	<button type="button" class="ww-lightbox__<?php echo esc_attr( $name ); ?>"<?php echo $button[2]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- vaste attributen. ?>><?php echo _ww_lightbox_icon( $button[0] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- vaste SVG, het pad is geëscaped. ?><span class="ww-lightbox__sr"><?php echo esc_html( $button[1] ); ?></span></button>
	<?php endforeach; ?>
	<div class="ww-lightbox__preload" hidden></div>
</dialog>
	<?php
}
add_action( 'wp_footer', '_ww_lightbox_print_dialog', 5 );
