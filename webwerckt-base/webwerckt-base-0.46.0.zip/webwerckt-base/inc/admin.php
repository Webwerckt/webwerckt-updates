<?php
/**
 * Beheer: de standaardeditor staat uit, de klant bewerkt alleen titel, uitgelichte afbeelding en velden,
 * alleen een beheerder kiest paginatemplates (regel 66), de klant bewerkt menu's, en hij ziet geen menu's en widgets
 * die hij niet gebruikt. Customizer, Patronen, Lettertypes en Connectoren zijn er voor niemand. De heartbeat in het
 * beheer loopt rustiger.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Haalt de editor weg bij berichten en pagina's. Zonder editor-ondersteuning toont WordPress ook de blokeditor
 * niet, en verschijnen de velden van het thema als metaboxen (inc/field-metaboxes.php).
 *
 * De post types van de parent hebben al geen editor in supports, en een child-thema laat 'editor' ook weg bij
 * zijn eigen post types. Post types van plugins blijven zo ongemoeid.
 */
function _ww_disable_editor(): void {
	remove_post_type_support( 'post', 'editor' );
	remove_post_type_support( 'page', 'editor' );
}
add_action( 'init', '_ww_disable_editor' );

/**
 * Is de huidige gebruiker de klant: ingelogd, maar zonder edit_theme_options in zijn rol (geen beheerder)?
 * WP-CLI, cron en bezoekers zijn het niet, zodat scripts en de frontend ongemoeid blijven. De rol telt, niet
 * current_user_can(): op het menuscherm krijgt de klant edit_theme_options erbij (_ww_grant_menu_cap()).
 */
function _ww_is_client(): bool {
	$user = wp_get_current_user();
	return $user->exists() && ! is_super_admin( $user->ID ) && empty( $user->allcaps['edit_theme_options'] );
}

/**
 * Is dit een klant die pagina's van anderen mag bewerken (de rol Redacteur)? Die beheert ook de menu's en de
 * Site-instellingen.
 *
 * @param array<string,bool> $caps Rechten uit de rol.
 */
function _ww_is_client_editor( array $caps ): bool {
	return ! empty( $caps['edit_others_pages'] ) && empty( $caps['edit_theme_options'] );
}

/**
 * Is dit verzoek het menuscherm, of een AJAX-actie die het menuscherm gebruikt?
 */
function _ww_is_menu_request(): bool {
	global $pagenow;
	if ( ! is_admin() ) {
		return false;
	}
	if ( 'nav-menus.php' === $pagenow ) {
		return true;
	}
	$action = isset( $_REQUEST['action'] ) ? sanitize_key( wp_unslash( $_REQUEST['action'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	return wp_doing_ajax() && in_array( $action, array( 'add-menu-item', 'menu-get-metabox', 'menu-quick-search', 'menu-locations-save' ), true );
}

/**
 * Geeft de klant die menu's bewerkt edit_theme_options, maar alleen op het menuscherm en zijn AJAX-acties, en
 * alleen als daar direct om wordt gevraagd: WordPress schermt menu's daarmee af. Rechten die erop doorverwijzen,
 * zoals customize (de Customizer), krijgt hij niet, en op andere schermen blijft het recht weg, dus templates,
 * widgets en thema-instellingen blijven bij de beheerder.
 *
 * @param array<string,bool> $allcaps Rechten van de gebruiker.
 * @param string[]           $caps    Gevraagde basisrechten.
 * @param mixed[]            $args    Het gevraagde recht en eventuele argumenten.
 * @return array<string,bool>
 */
function _ww_grant_menu_cap( array $allcaps, array $caps, array $args ): array {
	if ( 'edit_theme_options' === ( $args[0] ?? '' ) && _ww_is_client_editor( $allcaps ) && _ww_is_menu_request() ) {
		$allcaps['edit_theme_options'] = true;
	}
	return $allcaps;
}
add_filter( 'user_has_cap', '_ww_grant_menu_cap', 10, 3 );

/**
 * De klant ziet geen templates: een nieuwe pagina is een tekstpagina (het standaardtemplate), en zonder keuzelijst
 * stuurt het scherm geen template mee, dus een vaste pagina houdt het zijne.
 *
 * @param array<string,string> $templates Templates per bestandsnaam.
 * @return array<string,string>
 */
function _ww_lock_templates( array $templates ): array {
	return _ww_is_client() ? array() : $templates;
}
add_filter( 'theme_templates', '_ww_lock_templates' );

/**
 * Houdt het template gelijk als de klant het buiten het scherm om wijzigt (REST, snel bewerken, een plugin).
 * Zonder dit zet WordPress een template dat niet in de lijst staat terug naar het standaardtemplate.
 * Verwijderen telt als terugzetten naar het standaardtemplate.
 *
 * @param mixed $check      null, of een eerder antwoord van een ander filter.
 * @param mixed $object_id  Bericht-ID.
 * @param mixed $meta_key   Meta-sleutel.
 * @param mixed $meta_value Nieuwe waarde.
 * @return mixed false slaat het opslaan of verwijderen over.
 */
function _ww_guard_template_meta( $check, $object_id, $meta_key, $meta_value ) {
	if ( '_wp_page_template' !== $meta_key || ! _ww_is_client() ) {
		return $check;
	}
	$current = _ww_data_to_string( get_post_meta( (int) $object_id, '_wp_page_template', true ) ) ?: 'default';
	$new     = _ww_data_to_string( $meta_value ) ?: 'default';
	return $new === $current ? $check : false;
}
add_filter( 'add_post_metadata', '_ww_guard_template_meta', 10, 4 );
add_filter( 'update_post_metadata', '_ww_guard_template_meta', 10, 4 );
add_filter( 'delete_post_metadata', '_ww_guard_template_meta', 10, 4 );

/**
 * Haalt uit het menu van de klant wat hij niet gebruikt: Extra als daar alleen de standaardpagina van WordPress
 * onder staat (een plugin die er een pagina voor de klant zet, blijft). Reacties staan in inc/comments.php.
 * De pagina's zelf blijven bereikbaar; dit is opruimen, geen beveiliging.
 */
function _ww_client_admin_menu(): void {
	global $submenu;
	if ( ! _ww_is_client() ) {
		return;
	}
	remove_submenu_page( 'tools.php', 'tools.php' );
	if ( empty( $submenu['tools.php'] ) ) {
		remove_menu_page( 'tools.php' );
	}
	// Weergave verschijnt alleen op het menuscherm, door het recht dat de klant daar krijgt; Menu's staat er los.
	remove_menu_page( 'themes.php' );
	if ( _ww_is_client_editor( wp_get_current_user()->allcaps ) && current_theme_supports( 'menus' ) ) {
		add_menu_page( __( 'Menus' ), __( 'Menus' ), 'edit_others_pages', 'nav-menus.php', '', 'dashicons-menu', 61 ); // phpcs:ignore WordPress.WP.I18n.MissingArgDomain -- de vertaling van WordPress zelf.
	}
}
add_action( 'admin_menu', '_ww_client_admin_menu', 999 );

/**
 * Beheerschermen van WordPress die op deze sites niets doen, per bovenliggend menu. Patronen en Lettertypes horen
 * bij de blokeditor, die uit staat (beslissing 0007); de site-editor (bij een thema met editor-styles heet het item
 * Design) dus ook. Connectoren zijn de AI-koppelingen van WordPress, die het thema niet gebruikt.
 *
 * @return array<string,string[]> Slugs van de submenu-items per bovenliggend menu.
 */
function _ww_hidden_admin_screens(): array {
	return array(
		'themes.php'          => array( 'site-editor.php', 'site-editor.php?p=/pattern', 'font-library.php' ),
		'options-general.php' => array( 'options-connectors.php' ),
	);
}

/**
 * Haalt Patronen, Lettertypes en Connectoren uit het menu, voor iedereen, ook de beheerder. De Customizer verdwijnt
 * doordat niemand het recht customize heeft (_ww_no_customizer()).
 */
function _ww_remove_admin_screens(): void {
	foreach ( _ww_hidden_admin_screens() as $parent => $slugs ) {
		foreach ( $slugs as $slug ) {
			remove_submenu_page( $parent, $slug );
		}
	}
}
add_action( 'admin_menu', '_ww_remove_admin_screens', 999 );

/**
 * Een van die schermen via de URL stuurt door naar het dashboard.
 */
function _ww_redirect_hidden_admin_screens(): void {
	global $pagenow;
	if ( in_array( $pagenow, array( 'site-editor.php', 'font-library.php', 'options-connectors.php' ), true ) ) {
		wp_safe_redirect( admin_url() );
		exit;
	}
}
add_action( 'admin_init', '_ww_redirect_hidden_admin_screens' );

/**
 * Niemand heeft het recht customize, ook de beheerder niet: de Customizer (Weergave › Customizer, customize.php,
 * het item in de adminbalk en Live voorbeeld bij thema's) is weg. Het thema zet niets in de Customizer; het
 * site-icoon staat onder Instellingen › Algemeen.
 *
 * @param string[] $caps Basisrechten die nodig zijn.
 * @param string   $cap  Het gevraagde recht.
 * @return string[]
 */
function _ww_no_customizer( array $caps, string $cap ): array {
	if ( 'customize' === $cap ) {
		$caps[] = 'do_not_allow';
	}
	return $caps;
}
add_filter( 'map_meta_cap', '_ww_no_customizer', 10, 2 );

/**
 * Markeert Menu's in het menu van de klant als het menuscherm open is; WordPress zou Weergave markeren.
 *
 * @param mixed $parent_file Bovenliggend menu-item.
 * @return mixed
 */
function _ww_client_menu_parent( $parent_file ) {
	global $pagenow;
	return 'nav-menus.php' === $pagenow && _ww_is_client() ? 'nav-menus.php' : $parent_file;
}
add_filter( 'parent_file', '_ww_client_menu_parent' );

/**
 * Haalt het WordPress-logo (links naar wordpress.org) uit de adminbalk van de klant. De reacties staan in
 * inc/comments.php.
 */
function _ww_client_admin_bar( WP_Admin_Bar $bar ): void {
	if ( ! _ww_is_client() ) {
		return;
	}
	$bar->remove_node( 'wp-logo' );
}
add_action( 'admin_bar_menu', '_ww_client_admin_bar', 999 );

/**
 * Snel concept schrijft in post_content, maar die kolom is een kopie van de velden (ADR 0008): bij opslaan
 * zou de tekst verdwijnen, dus de widget gaat voor iedereen weg. Het nieuws van WordPress is niet voor de klant.
 */
function _ww_dashboard_widgets(): void {
	remove_meta_box( 'dashboard_quick_press', 'dashboard', 'side' );
	if ( _ww_is_client() ) {
		remove_meta_box( 'dashboard_primary', 'dashboard', 'side' );
	}
}
add_action( 'wp_dashboard_setup', '_ww_dashboard_widgets' );

/**
 * De heartbeat in het beheer elke 60 seconden in plaats van elke 15 (een open tabblad met het beheer is anders vier
 * PHP-verzoeken per minuut). Hij blijft aan: het slot op een bericht dat iemand bewerkt en het opnieuw inloggen na
 * een verlopen sessie hebben hem nodig, en die werken met 60 seconden net zo goed (een slot vervalt na 150).
 * De blokeditor staat uit, dus er is geen automatisch opslaan dat sneller moet.
 *
 * @param mixed $settings Instellingen van de heartbeat.
 * @return mixed
 */
function _ww_heartbeat_settings( $settings ) {
	if ( ! is_array( $settings ) || ! is_admin() ) {
		return $settings;
	}
	/**
	 * Interval van de heartbeat in het beheer, in seconden (WordPress houdt 15 tot 120 aan).
	 *
	 * @param int $interval Standaard 60.
	 */
	$settings['interval'] = max( 15, min( 120, (int) apply_filters( 'ww_heartbeat_interval', 60 ) ) );
	return $settings;
}
add_filter( 'heartbeat_settings', '_ww_heartbeat_settings' );


/**
 * De melding dat Pods uit kan (beslissing 0055): het thema tekent, bewaart en controleert de velden zelf. Alleen voor
 * wie plugins mag uitzetten, en alleen als Pods nog actief is. Pods registreert de velden van het thema niet meer,
 * dus zijn vakken verschijnen niet; de opgeslagen waarden blijven staan.
 *
 * @param bool $pods_active Is Pods geladen (PODS_VERSION)?
 */
function _ww_pods_unneeded_message( bool $pods_active ): string {
	if ( ! $pods_active || ! current_user_can( 'activate_plugins' ) ) {
		return '';
	}
	return sprintf(
		'<div class="notice notice-info"><p>%s</p></div>',
		esc_html__( 'Webwerckt Base heeft Pods niet meer nodig. Zet de plugin Pods uit; je velden blijven gewoon staan.', 'webwerckt-base' )
	);
}

/**
 * Toont de melding in de admin zolang Pods actief is.
 */
function _ww_pods_unneeded_notice(): void {
	echo _ww_pods_unneeded_message( defined( 'PODS_VERSION' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- ge-escaped in _ww_pods_unneeded_message().
}
add_action( 'admin_notices', '_ww_pods_unneeded_notice' );
