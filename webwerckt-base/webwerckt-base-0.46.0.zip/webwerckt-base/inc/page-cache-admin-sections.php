<?php
/**
 * Paginacache: de onderdelen van het scherm Pagina cache (inc/page-cache-admin.php). Het zijpaneel met de navigatie en
 * het kaartje, de kiezer voor mobiel, en de inhoud van Overzicht, Bewaarde pagina's, Overgeslagen en Instellingen.
 * Alles geeft geëscapete HTML terug; het scherm zet het in elkaar.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * De onderdelen van het scherm, in volgorde: tab ⇒ label.
 *
 * @return array<string,string>
 */
function _ww_page_cache_admin_sections(): array {
	return array(
		'overview' => __( 'Overzicht', 'webwerckt-base' ),
		'pages'    => __( 'Bewaarde pagina\'s', 'webwerckt-base' ),
		'skipped'  => __( 'Overgeslagen', 'webwerckt-base' ),
		'settings' => __( 'Instellingen', 'webwerckt-base' ),
	);
}

/**
 * Het gekozen onderdeel uit ?tab=, of overview als dat ontbreekt of onbekend is.
 */
function _ww_page_cache_admin_tab(): string {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen lezen, tegen de lijst gehouden.
	$tab = isset( $_GET['tab'] ) && is_string( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : '';
	return array_key_exists( $tab, _ww_page_cache_admin_sections() ) ? $tab : 'overview';
}

/**
 * Een verborgen nonceveld zonder id, zodat meerdere formulieren op één scherm geen dubbele id's geven.
 *
 * @param string $action Naam van de nonce.
 */
function _ww_page_cache_nonce_input( string $action ): string {
	return '<input type="hidden" name="_wpnonce" value="' . esc_attr( wp_create_nonce( $action ) ) . '">';
}

/**
 * Een formulier met één knop voor een actie via admin-post.php.
 *
 * @param string               $action   Actie, zoals ww_page_cache_flush; ook de naam van de nonce.
 * @param string               $label    Tekst op de knop.
 * @param array<string,string> $fields   Extra verborgen velden.
 * @param bool                 $disabled Knop uitgeschakeld.
 * @param string               $class    Klassen van de knop.
 */
function _ww_page_cache_action_form( string $action, string $label, array $fields = array(), bool $disabled = false, string $class = 'button' ): string {
	$html = '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="ww-cache-form">'
		. '<input type="hidden" name="action" value="' . esc_attr( $action ) . '">';
	foreach ( $fields as $name => $value ) {
		$html .= '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '">';
	}
	return $html . _ww_page_cache_nonce_input( $action )
		. '<button type="submit" class="' . esc_attr( $class ) . '"' . ( $disabled ? ' disabled' : '' ) . '>' . esc_html( $label ) . '</button>'
		. '</form>';
}

/**
 * Het aantal achter een onderdeel, of '' (geen aantal bij Overzicht en Instellingen, of als de cache uit staat).
 *
 * @param string                                                $tab    Onderdeel.
 * @param array{pages:int,skipped:int,missing:bool,off:bool} $counts Aantallen.
 */
function _ww_page_cache_nav_count( string $tab, array $counts ): string {
	if ( $counts['off'] || ! in_array( $tab, array( 'pages', 'skipped' ), true ) ) {
		return '';
	}
	$warn = 'skipped' === $tab && $counts['missing'] && $counts['skipped'] > 0;
	return '<span class="ww-cache-count' . ( $warn ? ' ww-cache-count--warn' : '' ) . '">' . esc_html( number_format_i18n( $counts[ $tab ] ) ) . '</span>';
}

/**
 * De navigatie langs de onderdelen: als lijst in het paneel, of als kiezer voor mobiel.
 *
 * @param string                                                $active  Gekozen onderdeel.
 * @param array{pages:int,skipped:int,missing:bool,off:bool} $counts  Aantallen achter Bewaarde pagina's en Overgeslagen.
 * @param string                                                $variant 'panel' of 'menu'.
 */
function _ww_page_cache_render_nav( string $active, array $counts, string $variant ): string {
	$sections = _ww_page_cache_admin_sections();
	$icons    = array(
		'overview' => 'dashicons-chart-bar',
		'pages'    => 'dashicons-database',
		'skipped'  => 'dashicons-controls-skipforward',
		'settings' => 'dashicons-admin-generic',
	);
	$items    = '';
	foreach ( $sections as $tab => $label ) {
		$icon   = 'panel' === $variant ? '<span class="dashicons ' . esc_attr( $icons[ $tab ] ) . '" aria-hidden="true"></span>' : '';
		$items .= '<li><a href="' . esc_url( _ww_page_cache_admin_url( array( 'tab' => $tab ) ) ) . '"' . ( $tab === $active ? ' aria-current="page"' : '' ) . '>'
			. $icon . '<span class="ww-cache-nav__label">' . esc_html( $label ) . '</span>' . _ww_page_cache_nav_count( $tab, $counts ) . '</a></li>';
	}
	if ( 'panel' === $variant ) {
		return '<ul class="ww-cache-panel__nav">' . $items . '</ul>';
	}
	return '<details class="ww-cache-menu"><summary><span>' . esc_html__( 'Onderdeel', 'webwerckt-base' ) . '</span> <b>' . esc_html( $sections[ $active ] ?? $sections['overview'] ) . '</b></summary><ul>' . $items . '</ul></details>';
}

/**
 * Hoe lang tot de volgende ronde opwarmen, zoals "4 minuten". Voor het kaartje en Overzicht. Zonder geplande ronde, of
 * als die al had moeten lopen: één minuut, want hij start bij het volgende bezoek.
 */
function _ww_page_cache_next_round_wait(): string {
	$next = (int) wp_next_scheduled( WW_PAGE_CACHE_PRELOAD_HOOK );
	return human_time_diff( time(), max( $next, time() + MINUTE_IN_SECONDS ) );
}

/**
 * Is het opwarmen gepauzeerd: de cache vraagt aandacht omdat de laatste ronde voortijdig stopte?
 *
 * @param array{level:string,label:string,notice:string} $state Stand van de cache.
 */
function _ww_page_cache_preload_paused( array $state ): bool {
	return 'warning' === $state['level'] && _ww_page_cache_preload_stopped();
}

/**
 * Stopte de laatste ronde opwarmen voortijdig?
 */
function _ww_page_cache_preload_stopped(): bool {
	$status = get_option( WW_PAGE_CACHE_PRELOAD_STATUS );
	return is_array( $status ) && in_array( $status['stop'] ?? '', array( 'error', 'http', 'slow', 'time' ), true );
}

/**
 * Een voortgangsbalk van 6 px: blauw, of groen als alles klaar is.
 *
 * @param int $cached Pagina's klaar.
 * @param int $total  Pagina's om op te warmen.
 */
function _ww_page_cache_bar( int $cached, int $total ): string {
	$pct  = $total > 0 ? (int) min( 100, round( $cached / $total * 100 ) ) : 0;
	$done = $total > 0 && $cached >= $total;
	return '<div class="ww-cache-bar' . ( $done ? ' is-done' : '' ) . '" aria-hidden="true"><span style="width:' . esc_attr( (string) $pct ) . '%"></span></div>';
}

/**
 * Een vak met een kop (zoals een blok bij Statistieken), of zonder kop als $title leeg is.
 *
 * @param string $title Kop, of ''.
 * @param string $inner Geëscapete inhoud.
 * @param string $extra Grijze tekst rechts in de kop, of ''.
 */
function _ww_page_cache_box( string $title, string $inner, string $extra = '' ): string {
	$head = '';
	if ( '' !== $title ) {
		$head = '<h2>' . esc_html( $title ) . ( '' !== $extra ? ' <small>' . esc_html( $extra ) . '</small>' : '' ) . '</h2>';
	}
	return '<section class="ww-cache-box">' . $head . $inner . '</section>';
}

/**
 * Een vak met alleen een zin, zoals "De cache staat uit".
 *
 * @param string $text Tekst, niet geëscapet.
 */
function _ww_page_cache_empty_box( string $text ): string {
	return _ww_page_cache_box( '', '<p class="ww-cache-empty">' . esc_html( $text ) . '</p>' );
}

/**
 * Een rij in een blok op Overzicht: de titel als link, het pad in grijs eronder, rechts een korte tekst.
 *
 * @param string $url   Volledige URL.
 * @param string $title Titel, niet geëscapet.
 * @param string $right Tekst rechts, niet geëscapet.
 */
function _ww_page_cache_overview_row( string $url, string $title, string $right ): string {
	$path = (string) wp_parse_url( $url, PHP_URL_PATH );
	$path = '' !== $path ? $path : $url;
	return '<tr><th scope="row"><a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( $title ) . '</a>'
		. ( $path !== $title ? '<span class="ww-cache-path">' . esc_html( $path ) . '</span>' : '' )
		. '</th><td class="ww-cache-num">' . esc_html( $right ) . '</td></tr>';
}

/**
 * Het kaartje in het paneel: hoeveel pagina's klaar staan, met een balk, en wanneer het opwarmen weer loopt.
 *
 * @param array{level:string,label:string,notice:string}  $state  Stand van de cache (_ww_page_cache_admin_state()).
 * @param array{cached:int,total:int,pending?:list<string>} $counts Opwarmen (_ww_page_cache_preload_counts()).
 */
function _ww_page_cache_render_panel_card( array $state, array $counts ): string {
	if ( 'off' === $state['level'] ) {
		return '<div class="ww-cache-panel__card"><strong>' . esc_html__( 'Pagina cache staat uit', 'webwerckt-base' ) . '</strong></div>';
	}
	if ( ! _ww_page_cache_preload_enabled() ) {
		$line = __( 'Opwarmen staat uit', 'webwerckt-base' );
	} elseif ( _ww_page_cache_preload_paused( $state ) ) {
		/* translators: %s: tijdsduur, zoals 4 minuten. */
		$line = sprintf( __( 'Opwarmen gepauzeerd, over %s', 'webwerckt-base' ), _ww_page_cache_next_round_wait() );
	} else {
		/* translators: %s: tijdsduur, zoals 4 minuten. */
		$line = sprintf( __( 'Volgende ronde over %s', 'webwerckt-base' ), _ww_page_cache_next_round_wait() );
	}

	return '<div class="ww-cache-panel__card"><strong>' . esc_html(
		sprintf(
			/* translators: 1: aantal pagina's klaar, 2: aantal pagina's om op te warmen. */
			__( '%1$d van %2$d klaar', 'webwerckt-base' ),
			$counts['cached'],
			$counts['total']
		)
	) . '</strong>'
		. _ww_page_cache_bar( $counts['cached'], $counts['total'] )
		. '<p>' . esc_html( $line ) . '</p></div>';
}

/**
 * Overzicht: een vak met drie kerncijfers en de knoppen Nu opwarmen en Cache legen, dan de blokken Net vernieuwd en
 * Nog niet klaar. Staat de cache uit, dan alleen het vak "Wat betekent dit?".
 *
 * @param array{level:string,label:string,notice:string}                       $state   Stand van de cache.
 * @param array{cached:int,total:int,pending?:list<string>}                     $counts  Opwarmen (_ww_page_cache_preload_counts()).
 * @param list<array{url:string,created:float,post_id:int,size:int}> $entries Bewaarde pagina's.
 */
function _ww_page_cache_render_overview( array $state, array $counts, array $entries ): string {
	if ( 'off' === $state['level'] ) {
		return _ww_page_cache_box(
			__( 'Wat betekent dit?', 'webwerckt-base' ),
			// De notice van een uitgezette cache is _ww_page_cache_client_reason() van de reden.
			( '' !== $state['notice'] ? '<p class="ww-cache-empty">' . esc_html( $state['notice'] ) . '</p>' : '' )
				. '<p class="ww-cache-empty">' . esc_html__( 'Hier verschijnt weer iets zodra de cache van het thema aan staat.', 'webwerckt-base' ) . '</p>'
		);
	}
	return _ww_page_cache_overview_summary( $state, $counts, $entries )
		. '<div class="ww-cache-blocks">'
		. _ww_page_cache_overview_recent( $entries )
		. _ww_page_cache_overview_pending( $counts )
		. '</div>';
}

/**
 * Het vak met de kerncijfers Klaar voor bezoekers, Bewaard en Opwarmen, en de knoppen eronder.
 *
 * @param array{level:string,label:string,notice:string}       $state   Stand van de cache.
 * @param array{cached:int,total:int,pending?:list<string>}     $counts  Opwarmen.
 * @param list<array{url:string,created:float,post_id:int,size:int}> $entries Bewaarde pagina's.
 */
function _ww_page_cache_overview_summary( array $state, array $counts, array $entries ): string {
	$cached  = $counts['cached'];
	$total   = $counts['total'];
	$left    = max( 0, $total - $cached );
	$stored  = count( $entries );
	$enabled = _ww_page_cache_preload_enabled();

	$ready = '<div class="ww-cache-kpi"><span class="ww-cache-kpi__label">' . esc_html__( 'Klaar voor bezoekers', 'webwerckt-base' ) . '</span>'
		. '<span class="ww-cache-kpi__value">' . esc_html( number_format_i18n( $cached ) ) . ' <small>' . esc_html(
			sprintf(
				/* translators: %d: aantal pagina's om op te warmen. */
				_n( 'van %d pagina', 'van %d pagina\'s', $total, 'webwerckt-base' ),
				$total
			)
		) . '</small></span>'
		. _ww_page_cache_bar( $cached, $total )
		. '<span class="ww-cache-kpi__sub">' . esc_html(
			0 === $left
				? __( 'Elke pagina staat klaar.', 'webwerckt-base' )
				: sprintf(
					/* translators: %d: aantal pagina's. */
					_n( '%d pagina komt in de volgende rondes.', '%d pagina\'s komen in de volgende rondes.', $left, 'webwerckt-base' ),
					$left
				)
		) . '</span></div>';

	$kept = '<div class="ww-cache-kpi"><span class="ww-cache-kpi__label">' . esc_html__( 'Bewaard', 'webwerckt-base' ) . '</span>'
		. '<span class="ww-cache-kpi__value">' . esc_html( number_format_i18n( $stored ) ) . ' <small>' . esc_html( _n( 'pagina', 'pagina\'s', $stored, 'webwerckt-base' ) ) . '</small></span>'
		. '<span class="ww-cache-kpi__sub">' . esc_html(
			sprintf(
				/* translators: %s: grootte, zoals 1,2 MB. */
				__( 'Samen %s', 'webwerckt-base' ),
				size_format( array_sum( array_column( $entries, 'size' ) ) ) ?: '0 B'
			)
		) . '</span></div>';

	if ( $enabled ) {
		$value  = _ww_page_cache_preload_paused( $state ) ? __( 'Gepauzeerd', 'webwerckt-base' ) : __( 'Aan', 'webwerckt-base' );
		$status = get_option( WW_PAGE_CACHE_PRELOAD_STATUS );
		$sub    = '';
		if ( is_array( $status ) && isset( $status['time'] ) ) {
			/* translators: %s: tijdsduur, zoals 3 minuten. */
			$sub .= esc_html( sprintf( __( 'Laatste ronde %s geleden', 'webwerckt-base' ), human_time_diff( (int) $status['time'] ) ) ) . '<br>';
		}
		/* translators: %s: tijdsduur, zoals 4 minuten. */
		$sub .= esc_html( sprintf( __( 'Volgende ronde over %s', 'webwerckt-base' ), _ww_page_cache_next_round_wait() ) );
	} else {
		$value = __( 'Uit', 'webwerckt-base' );
		$sub   = esc_html__( 'Pagina\'s komen pas in de cache als iemand ze bezoekt.', 'webwerckt-base' );
		if ( _ww_page_cache_preload_allowed() ) {
			$sub .= ' <a href="' . esc_url( _ww_page_cache_admin_url( array( 'tab' => 'settings' ) ) ) . '">' . esc_html__( 'Aanzetten', 'webwerckt-base' ) . '</a>';
		}
	}
	$warm = '<div class="ww-cache-kpi"><span class="ww-cache-kpi__label">' . esc_html__( 'Opwarmen', 'webwerckt-base' ) . '</span>'
		. '<span class="ww-cache-kpi__value">' . esc_html( $value ) . '</span>'
		. '<span class="ww-cache-kpi__sub">' . $sub . '</span></div>';

	$foot = '';
	if ( $enabled ) {
		$foot .= _ww_page_cache_action_form( 'ww_page_cache_preload_run', __( 'Nu opwarmen', 'webwerckt-base' ), array(), 0 === $left || array() === ( $counts['pending'] ?? array() ) );
	}
	$foot .= '<details class="ww-cache-confirm"><summary class="button">' . esc_html__( 'Cache legen…', 'webwerckt-base' ) . '</summary>'
		. '<div class="ww-cache-confirm__body"><p>' . esc_html(
			sprintf(
				/* translators: %d: aantal bewaarde pagina's. */
				_n( 'De %d bewaarde pagina wordt opnieuw opgebouwd. De eerste bezoekers wachten daarna heel even langer.', 'Alle %d bewaarde pagina\'s worden opnieuw opgebouwd. De eerste bezoekers wachten daarna heel even langer.', $stored, 'webwerckt-base' ),
				$stored
			)
		) . '</p>'
		. _ww_page_cache_action_form( 'ww_page_cache_flush', __( 'Ja, cache legen', 'webwerckt-base' ), array(), false, 'button button-primary' )
		. '<a href="' . esc_url( _ww_page_cache_admin_url() ) . '">' . esc_html__( 'Annuleren', 'webwerckt-base' ) . '</a></div></details>';
	$foot .= '<span class="ww-cache-summary__hint">' . esc_html__( 'Alleen nodig als je site er vreemd uitziet na een grote wijziging.', 'webwerckt-base' ) . '</span>';

	return '<section class="ww-cache-box ww-cache-summary"><div class="ww-cache-kpis">' . $ready . $kept . $warm . '</div>'
		. '<div class="ww-cache-summary__foot">' . $foot . '</div></section>';
}

/**
 * Het blok Net vernieuwd: de vijf nieuwste bewaarde pagina's.
 *
 * @param list<array{url:string,created:float,post_id:int,size:int}> $entries Bewaarde pagina's.
 */
function _ww_page_cache_overview_recent( array $entries ): string {
	if ( array() === $entries ) {
		return _ww_page_cache_box( __( 'Net vernieuwd', 'webwerckt-base' ), '<p class="ww-cache-empty">' . esc_html__( 'Nog niets bewaard.', 'webwerckt-base' ) . '</p>' );
	}
	usort( $entries, static fn( array $a, array $b ): int => $b['created'] <=> $a['created'] );
	$rows = '';
	foreach ( array_slice( $entries, 0, 5 ) as $entry ) {
		$rows .= _ww_page_cache_overview_row(
			$entry['url'],
			_ww_page_cache_title( $entry['url'], $entry['post_id'] ),
			/* translators: %s: tijdsduur, zoals 5 minuten. */
			sprintf( __( '%s geleden', 'webwerckt-base' ), human_time_diff( (int) $entry['created'] ) )
		);
	}
	$more = sprintf(
		/* translators: %d: aantal bewaarde pagina's. */
		__( 'Alle bewaarde pagina\'s (%d)', 'webwerckt-base' ),
		count( $entries )
	);
	return _ww_page_cache_box(
		__( 'Net vernieuwd', 'webwerckt-base' ),
		'<table class="ww-cache-list"><tbody>' . $rows . '</tbody></table>'
			. '<a class="ww-cache-more" href="' . esc_url( _ww_page_cache_admin_url( array( 'tab' => 'pages' ) ) ) . '">' . esc_html( $more ) . '</a>'
	);
}

/**
 * Het blok Nog niet klaar: hoeveel pagina's nog niet klaar zijn (zoals het kerncijfer), de eerste vijf die nog in de
 * wachtrij staan, en een link naar Overgeslagen. Staan alleen overgeslagen pagina's open, dan alleen die link.
 *
 * @param array{cached:int,total:int,pending?:list<string>} $counts Opwarmen (_ww_page_cache_preload_counts()).
 */
function _ww_page_cache_overview_pending( array $counts ): string {
	$left    = max( 0, $counts['total'] - $counts['cached'] );
	$pending = $counts['pending'] ?? array();
	$count   = count( $pending );
	$inner   = '';
	if ( 0 === $left ) {
		$inner = '<p class="ww-cache-empty">' . esc_html__( 'Alles staat klaar.', 'webwerckt-base' ) . '</p>';
	} elseif ( $count > 0 ) {
		$when = _ww_page_cache_preload_enabled() ? __( 'volgende ronde', 'webwerckt-base' ) : __( 'bij eerste bezoek', 'webwerckt-base' );
		$rows = '';
		foreach ( array_slice( $pending, 0, 5 ) as $url ) {
			$rows .= _ww_page_cache_overview_row( $url, _ww_page_cache_title( $url ), $when );
		}
		if ( $count > 5 ) {
			$rows .= '<tr><td colspan="2" class="ww-cache-rest">' . esc_html(
				sprintf(
					/* translators: %d: aantal pagina's. */
					_n( 'en nog %d pagina', 'en nog %d pagina\'s', $count - 5, 'webwerckt-base' ),
					$count - 5
				)
			) . '</td></tr>';
		}
		$inner = '<table class="ww-cache-list"><tbody>' . $rows . '</tbody></table>';
	}
	$skipped = count( _ww_page_cache_preload_skipped( time() ) );
	if ( $skipped > 0 ) {
		$inner .= '<a class="ww-cache-more" href="' . esc_url( _ww_page_cache_admin_url( array( 'tab' => 'skipped' ) ) ) . '">' . esc_html(
			sprintf(
				/* translators: %d: aantal pagina's. */
				_n( '%d pagina overgeslagen, bekijk waarom', '%d pagina\'s overgeslagen, bekijk waarom', $skipped, 'webwerckt-base' ),
				$skipped
			)
		) . '</a>';
	}
	return _ww_page_cache_box(
		__( 'Nog niet klaar', 'webwerckt-base' ),
		$inner,
		sprintf(
			/* translators: %d: aantal pagina's. */
			_n( '%d pagina', '%d pagina\'s', $left, 'webwerckt-base' ),
			$left
		)
	);
}

/**
 * Bewaarde pagina's: een inleiding en de tabel met zoeken, in een GET-formulier dat op dit onderdeel blijft. Staat de
 * cache uit, dan alleen een vak.
 *
 * @param list<array{key:string,url:string,created:float,expires:int,post_types:string[],post_id:int,size:int}> $entries Pagina's.
 * @param bool                                                                                                   $off     De cache staat uit.
 */
function _ww_page_cache_render_pages( array $entries, bool $off = false ): string {
	if ( $off ) {
		return _ww_page_cache_empty_box( __( 'De cache staat uit, dus er zijn geen bewaarde pagina\'s.', 'webwerckt-base' ) );
	}
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
	require_once __DIR__ . '/class-ww-page-cache-list-table.php';
	$table = new WW_Page_Cache_List_Table( $entries );
	$table->prepare_items();
	ob_start();
	echo '<p class="ww-cache-lead">' . esc_html__( 'Deze pagina\'s staan klaar en gaan direct naar bezoekers. Ziet een pagina er niet goed uit? Kies Vernieuwen; de volgende bezoeker of de volgende ronde opwarmen zet dan een verse versie klaar.', 'webwerckt-base' ) . '</p>';
	echo '<form method="get">';
	echo '<input type="hidden" name="page" value="' . esc_attr( WW_PAGE_CACHE_ADMIN_PAGE ) . '">';
	echo '<input type="hidden" name="tab" value="pages">';
	$table->search_box( __( 'Zoek een pagina', 'webwerckt-base' ), 'ww-page-cache' );
	$table->display();
	echo '</form>';
	return (string) ob_get_clean();
}

/**
 * Overgeslagen: een inleiding en de tabel, buiten elk ander formulier, want elke rij heeft zijn eigen formulier Nu
 * opnieuw proberen. Staat de cache uit, dan alleen een vak.
 *
 * @param list<array{url:string,until:int,code:int}> $skipped Pagina's (_ww_page_cache_preload_skipped()).
 * @param bool                                       $off     De cache staat uit.
 */
function _ww_page_cache_render_skipped( array $skipped, bool $off = false ): string {
	if ( $off ) {
		return _ww_page_cache_empty_box( __( 'De cache staat uit, dus er wordt niets opgewarmd of overgeslagen.', 'webwerckt-base' ) );
	}
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
	require_once __DIR__ . '/class-ww-page-cache-skip-list-table.php';
	$table = new WW_Page_Cache_Skip_List_Table( $skipped );
	$table->prepare_items();
	ob_start();
	echo '<p class="ww-cache-lead">' . esc_html__( 'Bij het opwarmen kwamen deze pagina\'s niet in de cache. Het thema slaat ze een tijdje over en probeert het daarna opnieuw. Meestal hoef je niets te doen.', 'webwerckt-base' ) . '</p>';
	$table->display();
	return (string) ob_get_clean();
}

/**
 * Instellingen: een form-table met opwarmen aan of uit. De checkbox is uit en uitgeschakeld als het filter opwarmen
 * tegenhoudt; het hele formulier is uitgeschakeld als de cache uit staat. Opslaan is dan ook uitgeschakeld, want een
 * uitgeschakelde checkbox wordt niet verstuurd en zou opwarmen uitzetten.
 *
 * @param array{level:string,label:string,notice:string} $state Stand van de cache.
 */
function _ww_page_cache_render_settings( array $state ): string {
	$allowed  = _ww_page_cache_preload_allowed();
	$on       = $allowed && '0' !== get_option( WW_PAGE_CACHE_PRELOAD_OPTION, '1' );
	$disabled = ! $allowed || 'off' === $state['level'] ? ' disabled' : '';
	$text     = $allowed
		? __( 'Het thema zet nieuwe en aangepaste pagina\'s zelf in de cache, zodat ook de eerste bezoeker niet hoeft te wachten. Rustig voor de server: het stopt vanzelf als de site druk is.', 'webwerckt-base' )
		: __( 'Opwarmen is voor deze site uitgezet.', 'webwerckt-base' );

	return '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'
		. '<input type="hidden" name="action" value="ww_page_cache_preload_toggle">'
		. _ww_page_cache_nonce_input( 'ww_page_cache_preload_toggle' )
		. '<section class="ww-cache-box ww-cache-settings"><table class="form-table" role="presentation"><tbody><tr>'
		. '<th scope="row">' . esc_html__( 'Opwarmen', 'webwerckt-base' ) . '</th>'
		. '<td><fieldset><legend class="screen-reader-text"><span>' . esc_html__( 'Opwarmen', 'webwerckt-base' ) . '</span></legend>'
		. '<label for="ww-cache-preload"><input type="checkbox" name="ww_preload" value="1" id="ww-cache-preload"' . ( $on ? ' checked' : '' ) . $disabled . '> '
		. esc_html__( 'Pagina\'s vooraf klaarzetten', 'webwerckt-base' ) . '</label>'
		. '<p class="description">' . esc_html( $text ) . '</p></fieldset></td>'
		. '</tr></tbody></table></section>'
		. '<p class="submit"><button type="submit" class="button button-primary"' . $disabled . '>' . esc_html__( 'Wijzigingen opslaan', 'webwerckt-base' ) . '</button></p>'
		. '</form>';
}
