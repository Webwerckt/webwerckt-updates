<?php
/**
 * Tabel van de wachtrij op het scherm Afbeeldingen (inc/images-admin.php). Wordt pas geladen als dat scherm wordt
 * getoond, na WP_List_Table.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * De afbeeldingen die nog versies nodig hebben, in de volgorde waarin de cron ze afwerkt (nieuwste eerst).
 */
class WW_Images_Queue_List_Table extends WP_List_Table {

	public function __construct() {
		parent::__construct(
			array(
				'singular' => 'afbeelding',
				'plural'   => 'afbeeldingen',
				'ajax'     => false,
			)
		);
	}

	/**
	 * @return array<string,string>
	 */
	public function get_columns() {
		return array(
			'image'    => __( 'Afbeelding', 'webwerckt-base' ),
			'status'   => __( 'Status', 'webwerckt-base' ),
			'todo'     => __( 'Te maken', 'webwerckt-base' ),
			'uploaded' => __( 'Geüpload', 'webwerckt-base' ),
		);
	}

	/**
	 * @return string
	 */
	protected function get_default_primary_column_name() {
		return 'image';
	}

	/**
	 * Haalt één pagina uit de wachtrij, in de volgorde van _ww_images_queue_args().
	 */
	public function prepare_items(): void {
		$args                  = _ww_images_queue_args( WW_IMAGES_PER_PAGE );
		$args['paged']         = $this->get_pagenum();
		$args['no_found_rows'] = false;
		$query                 = new WP_Query( $args );
		$this->_column_headers = array( $this->get_columns(), array(), array(), 'image' );
		$this->items           = array_map( 'intval', $query->posts );
		$this->set_pagination_args(
			array(
				'total_items' => $query->found_posts,
				'per_page'    => WW_IMAGES_PER_PAGE,
			)
		);
	}

	/**
	 * Tekst als de wachtrij leeg is.
	 */
	public function no_items(): void {
		esc_html_e( 'De wachtrij is leeg. Alle afbeeldingen zijn verwerkt.', 'webwerckt-base' );
	}

	/**
	 * Kolom Te maken verdwijnt op smalle schermen. De kop en de cellen hebben al de class column-todo; de stijl (assets/css/images-admin.css) verbergt die onder 960 px. De cellen krijgen hier ook hide-md.
	 *
	 * @param string $column_name Kolom.
	 * @return string
	 */
	protected function get_column_css_classes_hide( string $column_name ): string {
		return 'todo' === $column_name ? ' hide-md' : '';
	}

	/**
	 * Zoals WP_List_Table::single_row_columns(), met hide-md op de cel Te maken.
	 *
	 * @param mixed $item Rij.
	 */
	protected function single_row_columns( $item ): void {
		list( $columns, , , $primary ) = $this->get_column_info();
		foreach ( $columns as $column_name => $column_display_name ) {
			$classes = "$column_name column-$column_name" . $this->get_column_css_classes_hide( $column_name );
			if ( $primary === $column_name ) {
				$classes .= ' has-row-actions column-primary';
			}
			$data = ' data-colname="' . esc_attr( wp_strip_all_tags( $column_display_name ) ) . '"';
			echo '<td class="' . esc_attr( $classes ) . '"' . $data . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $data is al geëscaped.
			echo $this->{"column_$column_name"}( $item ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- de kolomfuncties escapen zelf.
			if ( $primary === $column_name ) {
				echo $this->handle_row_actions( $item, $column_name, $primary ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- toont de knop voor kleine schermen.
			}
			echo '</td>';
		}
	}

	/**
	 * Het aantal bestanden van een afbeelding: uit de versies, anders uit de metadata.
	 *
	 * @param int $id Bijlage-ID.
	 */
	private function file_count( int $id ): int {
		$variants = _ww_images_variants( $id );
		if ( array() !== $variants ) {
			return count( $variants );
		}
		$meta = wp_get_attachment_metadata( $id );
		return count( _ww_images_files( is_array( $meta ) ? $meta : array() ) );
	}

	/**
	 * Miniatuur, titel en bestandsnaam, met de acties Bewerken en Bekijken.
	 *
	 * @param int $item Bijlage-ID.
	 */
	protected function column_image( $item ): string {
		return _ww_images_list_image_cell( (int) $item, $this->row_actions( _ww_images_list_row_actions( (int) $item ) ) );
	}

	/**
	 * Status, met als die er is een regel uitleg eronder.
	 *
	 * @param int $item Bijlage-ID.
	 */
	protected function column_status( $item ): string {
		$status = _ww_images_queue_status( _ww_images_variants( (int) $item ), $this->file_count( (int) $item ) );
		return '<span class="ww-images-status ww-images-status--' . esc_attr( $status['class'] ) . '">' . esc_html( $status['label'] ) . '</span>'
			. ( '' !== $status['detail'] ? '<br><small>' . esc_html( $status['detail'] ) . '</small>' : '' );
	}

	/**
	 * Bestanden × formaten.
	 *
	 * @param int $item Bijlage-ID.
	 */
	protected function column_todo( $item ): string {
		$files   = $this->file_count( (int) $item );
		$formats = count( _ww_images_formats() );
		return esc_html(
			sprintf(
				/* translators: 1: aantal bestanden, 2: aantal formaten, bijvoorbeeld "3 bestanden". */
				__( '%1$s × %2$s', 'webwerckt-base' ),
				sprintf(
					/* translators: %s: aantal bestanden. */
					_n( '%s bestand', '%s bestanden', $files, 'webwerckt-base' ),
					number_format_i18n( $files )
				),
				sprintf(
					/* translators: %s: aantal formaten. */
					_n( '%s formaat', '%s formaten', $formats, 'webwerckt-base' ),
					number_format_i18n( $formats )
				)
			)
		);
	}

	/**
	 * Datum van de upload.
	 *
	 * @param int $item Bijlage-ID.
	 */
	protected function column_uploaded( $item ): string {
		return esc_html( date_i18n( get_option( 'date_format' ), (int) get_post_time( 'U', true, (int) $item ) ) );
	}
}
