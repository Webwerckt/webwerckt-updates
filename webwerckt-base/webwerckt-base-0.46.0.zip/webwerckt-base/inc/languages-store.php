<?php
/**
 * Meertalig (beslissing 0040), onderdeel store: de taxonomie ww_language, de taal van een bericht en de vertaalgroep.
 *
 * Een bericht heeft hooguit één term in ww_language (slug = taalcode); zonder term hoort het bij de standaardtaal.
 * De vertaalgroep staat als meta _ww_translations ({ taalcode: post-ID }, inclusief het bericht zelf) op elk lid, gelijk
 * voor allemaal. Een groep van één lid heeft geen meta. Elke wijziging van een groep leegt de cache van alle oude en
 * nieuwe leden (_ww_purge_post), want hun hreflang en taalwisselaar veranderen.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * De vertaalbare post types: de standaardlijst voor zover geregistreerd, uitbreidbaar met het filter
 * ww_translatable_post_types. Nooit attachment. ww_form alleen met Meertalig actief (beslissing 0043): zonder
 * post_type_exists, want de taxonomie wordt op init 6 geregistreerd en ww_form pas op init 10.
 *
 * @return string[]
 */
function _ww_translatable_post_types(): array {
	$active = _ww_languages_active();
	$types  = array_values( array_filter( array( 'page', 'post', 'project', 'faq', 'service', 'review', 'team_member' ), 'post_type_exists' ) );
	if ( $active ) {
		$types[] = 'ww_form';
	}

	/**
	 * Filtert de vertaalbare post types.
	 *
	 * @param string[] $types Post types.
	 */
	$types = apply_filters( 'ww_translatable_post_types', $types );
	$types = array_filter( (array) $types, 'is_string' );

	return array_values( array_diff( array_unique( $types ), $active ? array( 'attachment' ) : array( 'attachment', 'ww_form' ) ) );
}

/**
 * Of een post type vertaalbaar is.
 */
function _ww_is_translatable( string $post_type ): bool {
	return in_array( $post_type, _ww_translatable_post_types(), true );
}

/**
 * Registreert de verborgen taxonomie ww_language voor de vertaalbare post types. Draait ook in de uit-stand.
 */
function _ww_languages_register_taxonomy(): void {
	register_taxonomy(
		'ww_language',
		_ww_translatable_post_types(),
		array(
			'label'              => __( 'Taal', 'webwerckt-base' ),
			'public'             => false,
			'publicly_queryable' => false,
			'show_ui'            => false,
			'show_in_menu'       => false,
			'show_in_nav_menus'  => false,
			'show_in_rest'       => false,
			'show_admin_column'  => false,
			'hierarchical'       => false,
			'rewrite'            => false,
			'query_var'          => false,
		)
	);
}

/**
 * Zorgt dat de taxonomie op init (prioriteit 6, na de post types op 5) wordt geregistreerd, of direct als init al geweest is.
 */
function _ww_languages_hook_taxonomy(): void {
	if ( did_action( 'init' ) ) {
		_ww_languages_register_taxonomy();
		return;
	}
	add_action( 'init', '_ww_languages_register_taxonomy', 6 );
}

/**
 * Maakt of werkt per ingestelde taal een term bij (slug = code, naam = name). Verwijdert niets: een taal in gebruik
 * kan niet worden verwijderd (zie beheer).
 */
function _ww_languages_sync_terms(): void {
	if ( ! taxonomy_exists( 'ww_language' ) ) {
		return;
	}
	foreach ( _ww_languages_config()['languages'] as $language ) {
		$term = get_term_by( 'slug', $language['code'], 'ww_language' );
		if ( $term instanceof WP_Term ) {
			if ( $term->name !== $language['name'] ) {
				wp_update_term( $term->term_id, 'ww_language', array( 'name' => $language['name'] ) );
			}
			continue;
		}
		wp_insert_term( $language['name'], 'ww_language', array( 'slug' => $language['code'] ) );
	}
}

/**
 * De taal van een bericht: de term, of de standaardtaal zonder term. '' als het post type niet vertaalbaar is.
 */
function _ww_post_language( int $post_id ): string {
	$type = get_post_type( $post_id );
	if ( false === $type || ! _ww_is_translatable( $type ) ) {
		return '';
	}

	$terms = taxonomy_exists( 'ww_language' ) ? get_the_terms( $post_id, 'ww_language' ) : false;
	if ( is_array( $terms ) && array() !== $terms ) {
		$term = reset( $terms );
		if ( in_array( $term->slug, _ww_language_codes(), true ) ) {
			return $term->slug;
		}
	}
	return _ww_default_language();
}

/**
 * De taalvoorwaarde voor een query (tax_query). Voor de standaardtaal: de term of geen taalterm (een bericht zonder term
 * hoort bij de standaardtaal). Voor een extra taal: alleen de term.
 *
 * @return array<int|string,mixed>
 */
function _ww_languages_tax_query( string $lang ): array {
	$term = array(
		'taxonomy' => 'ww_language',
		'field'    => 'slug',
		'terms'    => array( $lang ),
	);
	if ( $lang !== _ww_default_language() ) {
		return array( $term );
	}
	return array(
		'relation' => 'OR',
		$term,
		array(
			'taxonomy' => 'ww_language',
			'operator' => 'NOT EXISTS',
		),
	);
}

/**
 * De vertaalgroep van een bericht: taalcode => post-ID, inclusief het bericht zelf. Zonder meta alleen het bericht.
 *
 * @return array<string,int>
 */
function _ww_translations( int $post_id ): array {
	$meta = get_post_meta( $post_id, '_ww_translations', true );
	if ( is_array( $meta ) && array() !== $meta ) {
		$group = array();
		foreach ( $meta as $lang => $id ) {
			$group[ (string) $lang ] = (int) $id;
		}
		return $group;
	}

	$lang = _ww_post_language( $post_id );
	return '' !== $lang ? array( $lang => $post_id ) : array();
}

/**
 * Schrijft een groep op alle leden (bij minder dan twee leden geen meta) en haalt de meta weg bij wie de groep verlaat.
 *
 * @param array<string,int> $group   De nieuwe groep.
 * @param int[]             $removed Leden die de groep verlaten.
 */
function _ww_translations_write( array $group, array $removed = array() ): void {
	foreach ( $removed as $id ) {
		delete_post_meta( $id, '_ww_translations' );
	}
	foreach ( $group as $id ) {
		if ( count( $group ) < 2 ) {
			delete_post_meta( $id, '_ww_translations' );
		} else {
			update_post_meta( $id, '_ww_translations', $group );
		}
	}
	_ww_languages_translated_flush();
}

/**
 * Leegt de cache van elk bericht in de lijst, ieder een keer, en de pagina's met een menu als een van hen in een menu
 * staat: het automatische menu van een extra taal toont de vertaling van een bericht in het menu (inc/languages-menus.php).
 *
 * @param int[] $ids Post-ID's.
 */
function _ww_translations_purge( array $ids ): void {
	foreach ( array_unique( array_map( 'intval', $ids ) ) as $id ) {
		do_action( '_ww_purge_post', $id );
	}
	_ww_cache_purge_menu_of_posts( $ids );
}

/**
 * Haalt een bericht uit zijn groep en werkt de rest bij.
 *
 * @return int[] De leden van de oude groep (inclusief het bericht), voor het legen van de cache.
 */
function _ww_translations_leave( int $post_id ): array {
	if ( ! is_array( get_post_meta( $post_id, '_ww_translations', true ) ) ) {
		return array( $post_id );
	}

	$group = _ww_translations( $post_id );
	$rest  = array_filter( $group, static fn( int $id ): bool => $id !== $post_id );
	_ww_translations_write( $rest, array( $post_id ) );
	return array_values( $group );
}

/**
 * Zet de taal van een bericht. Weigert een taal die al een ander lid in de groep heeft.
 *
 * @return true|WP_Error
 */
function _ww_set_post_language( int $post_id, string $lang ): true|WP_Error {
	$type = get_post_type( $post_id );
	if ( false === $type || ! _ww_is_translatable( $type ) ) {
		return new WP_Error( 'ww_languages_type', __( 'Dit soort inhoud is niet vertaalbaar.', 'webwerckt-base' ) );
	}
	if ( ! in_array( $lang, _ww_language_codes(), true ) ) {
		return new WP_Error( 'ww_languages_unknown', __( 'Deze taal bestaat niet.', 'webwerckt-base' ) );
	}

	$old   = _ww_post_language( $post_id );
	$group = _ww_translations( $post_id );
	if ( $old !== $lang && isset( $group[ $lang ] ) && $group[ $lang ] !== $post_id ) {
		return new WP_Error( 'ww_languages_taken', __( 'Er is in deze groep al een vertaling in die taal.', 'webwerckt-base' ) );
	}

	if ( ! term_exists( $lang, 'ww_language' ) ) {
		_ww_languages_sync_terms();
	}
	wp_set_object_terms( $post_id, $lang, 'ww_language' );

	if ( $old !== $lang && count( $group ) > 1 ) {
		unset( $group[ $old ] );
		$group[ $lang ] = $post_id;
		_ww_translations_write( $group );
		_ww_translations_purge( array_values( $group ) );
	}
	return true;
}

/**
 * Koppelt twee berichten als vertaling. $other_id verlaat zijn oude groep en komt in de groep van $post_id.
 *
 * @return true|WP_Error
 */
function _ww_link_translation( int $post_id, int $other_id ): true|WP_Error {
	$type  = get_post_type( $post_id );
	$other = get_post_type( $other_id );
	if ( false === $type || $type !== $other || ! _ww_is_translatable( $type ) ) {
		return new WP_Error( 'ww_languages_type', __( 'Alleen berichten van hetzelfde soort kunnen vertalingen zijn.', 'webwerckt-base' ) );
	}

	$lang       = _ww_post_language( $post_id );
	$other_lang = _ww_post_language( $other_id );
	if ( $lang === $other_lang ) {
		return new WP_Error( 'ww_languages_same_language', __( 'Een vertaling moet in een andere taal staan.', 'webwerckt-base' ) );
	}

	$group = _ww_translations( $post_id );
	if ( isset( $group[ $other_lang ] ) && $group[ $other_lang ] === $other_id ) {
		return true;
	}
	if ( isset( $group[ $other_lang ] ) ) {
		return new WP_Error( 'ww_languages_taken', __( 'Er is in deze groep al een vertaling in die taal.', 'webwerckt-base' ) );
	}

	$touched              = _ww_translations_leave( $other_id );
	$group[ $other_lang ] = $other_id;
	_ww_translations_write( $group );
	_ww_translations_purge( array_merge( $touched, array_values( $group ) ) );
	return true;
}

/**
 * Haalt een bericht uit zijn vertaalgroep.
 */
function _ww_unlink_translation( int $post_id ): void {
	_ww_translations_purge( _ww_translations_leave( $post_id ) );
}

/**
 * Hook wp_trash_post en before_delete_post: het bericht verlaat de groep. Bij de prullenbak onthoudt het de groep
 * in _ww_translations_trashed, zodat untrashed_post hem kan terugzetten.
 *
 * @param int|string $post_id Post-ID.
 */
function _ww_languages_on_remove( $post_id ): void {
	$post_id = (int) $post_id;
	if ( ! is_array( get_post_meta( $post_id, '_ww_translations', true ) ) ) {
		return;
	}
	if ( 'wp_trash_post' === current_action() ) {
		update_post_meta( $post_id, '_ww_translations_trashed', _ww_translations( $post_id ) );
	}
	_ww_translations_purge( _ww_translations_leave( $post_id ) );
}

/**
 * Hook untrashed_post: zet het bericht terug in zijn oude groep, als zijn taal daar nog vrij is.
 *
 * @param int|string $post_id Post-ID.
 */
function _ww_languages_on_untrash( $post_id ): void {
	$post_id = (int) $post_id;
	$saved   = get_post_meta( $post_id, '_ww_translations_trashed', true );
	delete_post_meta( $post_id, '_ww_translations_trashed' );
	if ( ! is_array( $saved ) ) {
		return;
	}

	$lang = _ww_post_language( $post_id );
	foreach ( $saved as $other_id ) {
		$other_id = (int) $other_id;
		$status   = get_post_status( $other_id );
		if ( $other_id === $post_id || false === $status || 'trash' === $status ) {
			continue;
		}
		$group = _ww_translations( $other_id );
		if ( isset( $group[ $lang ] ) && $group[ $lang ] !== $post_id ) {
			return;
		}
		$group[ $lang ] = $post_id;
		_ww_translations_write( $group );
		_ww_translations_purge( array_values( $group ) );
		return;
	}
}

/**
 * Hook transition_post_status: wordt een bericht in een vertaalgroep zichtbaar of onzichtbaar voor bezoekers
 * (publiceren, terug naar concept), dan veranderen de taalwisselaar en hreflang van de andere leden. Dan gaan alle
 * leden uit de cache. Een gewone opslag leegt alleen de eigen taal (inc/cache.php).
 *
 * @param mixed $new_status Nieuwe status.
 * @param mixed $old_status Vorige status.
 * @param mixed $post       Bericht.
 */
function _ww_languages_on_status( $new_status, $old_status, $post ): void {
	if ( ! $post instanceof WP_Post || is_post_status_viewable( (string) $new_status ) === is_post_status_viewable( (string) $old_status ) ) {
		return;
	}
	if ( ! is_array( get_post_meta( $post->ID, '_ww_translations', true ) ) ) {
		return;
	}
	_ww_translations_purge( array_values( _ww_translations( $post->ID ) ) );
}

/**
 * Hangt de hooks van dit onderdeel op. Draait ook na init (zie _ww_languages_boot()).
 */
function _ww_languages_boot_store(): void {
	_ww_languages_hook_taxonomy();
	add_action( 'wp_trash_post', '_ww_languages_on_remove' );
	add_action( 'before_delete_post', '_ww_languages_on_remove' );
	add_action( 'untrashed_post', '_ww_languages_on_untrash' );
	add_action( 'transition_post_status', '_ww_languages_on_status', 10, 3 );
	// De telling vertaald per taal (inc/languages-translated.php) blijft actueel.
	add_action( 'set_object_terms', '_ww_languages_translated_on_terms', 10, 4 );
	add_action( 'transition_post_status', '_ww_languages_translated_on_status', 10, 3 );
	add_action( 'deleted_post', '_ww_languages_translated_on_delete', 10, 2 );
}
