<?php
/**
 * Taal en vertalingen: de themastrings als .po/.mo en de huidige taal.
 *
 * De bronstrings zijn Nederlands; een vertaling staat in languages/{locale}.mo (sjabloon: languages/webwerckt-base.pot).
 * De huidige taal komt van de taalmodule als die aan staat (inc/languages.php, beslissing 0040); zonder Meertalig is er
 * geen taal en is de site eentalig.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Laadt de vertaling van de themastrings. Een bestand in wp-content/languages/themes/ gaat voor.
 */
function _ww_load_textdomain(): void {
	load_theme_textdomain( 'webwerckt-base', get_template_directory() . '/languages' );
}
add_action( 'after_setup_theme', '_ww_load_textdomain' );

/**
 * Code van de huidige taal ('en'): met de taalmodule aan (beslissing 0040) de taal uit de routing, anders ''.
 */
function _ww_current_language(): string {
	return _ww_languages_active() ? ww_current_language() : '';
}

/**
 * Terugval op dezelfde taal voor de .mo van de themastrings: bestaat het gevraagde bestand niet (en_US, de_AT, fr_BE),
 * dan het eerste bestaande bestand in dezelfde map met hetzelfde voorvoegsel en dezelfde taalcode, alfabetisch
 * (en_GB, de_DE, fr_FR). Geldt voor het textdomain van de parent en van het child-thema, ook zonder Meertalig.
 * Zonder bestand in die taal blijft het gevraagde pad staan en dus het Nederlands.
 *
 * @param string $mofile Pad naar het gevraagde .mo-bestand.
 * @param string $domain Textdomain.
 */
function _ww_mofile_fallback( string $mofile, string $domain ): string {
	if ( '' === $domain || ( 'webwerckt-base' !== $domain && (string) wp_get_theme()->get( 'TextDomain' ) !== $domain ) ) {
		return $mofile;
	}
	if ( file_exists( $mofile ) ) {
		return $mofile;
	}

	// {voorvoegsel}{locale}.mo, ook met een variant (de_DE_formal): het voorvoegsel is meestal leeg (languages/de_DE.mo).
	if ( 1 !== preg_match( '/^(.*?)([a-z]{2,3})_[A-Za-z0-9_]+\.mo$/', basename( $mofile ), $parts ) ) {
		return $mofile;
	}

	$candidates = glob( dirname( $mofile ) . '/' . $parts[1] . $parts[2] . '_*.mo' );
	if ( ! is_array( $candidates ) || array() === $candidates ) {
		return $mofile;
	}
	sort( $candidates );
	return $candidates[0];
}
add_filter( 'load_textdomain_mofile', '_ww_mofile_fallback', 10, 2 );
