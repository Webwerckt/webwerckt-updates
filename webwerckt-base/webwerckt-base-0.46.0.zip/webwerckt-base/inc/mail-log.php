<?php
/**
 * Email log (beslissing 0034): tabel, vullen, opruimen en privacy.
 *
 * Eén eigen tabel {prefix}ww_mail_log met één regel per mail, geslaagd of mislukt. Het schema wordt bij admin_init en na
 * een themawissel aangelegd, zoals bij formulieren; bij het vullen telt alleen de optie ww_mail_db_version. Tijden staan in
 * UTC. De log bewaart alleen adressen, het onderwerp, de tekst (hoogstens 65 536 bytes), de namen van de bijlagen (geen
 * paden, geen inhoud) en de fout. De log laat een mail nooit mislukken: een fout gaat als vaste tekst naar error_log.
 * Een dagelijkse cron ruimt regels ouder dan 30 dagen op.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const WW_MAIL_DB_VERSION       = '1';
const WW_MAIL_LOG_CLEANUP_HOOK = 'ww_mail_log_cleanup';
const WW_MAIL_LOG_MAX_MESSAGE  = 65536;

/**
 * Naam van de tabel van de email log.
 */
function _ww_mail_log_table(): string {
	global $wpdb;
	return $wpdb->prefix . 'ww_mail_log';
}

/**
 * Legt de tabel aan (of werkt hem bij) en bewaart de schemaversie.
 */
function _ww_mail_log_install(): void {
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';

	dbDelta(
		'CREATE TABLE ' . _ww_mail_log_table() . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  created datetime NOT NULL,
  recipients text NOT NULL,
  subject varchar(255) NOT NULL DEFAULT '',
  message mediumtext NOT NULL,
  headers text NOT NULL,
  attachments text NOT NULL,
  transport varchar(40) NOT NULL DEFAULT '',
  status varchar(10) NOT NULL DEFAULT '',
  error text NOT NULL,
  provider_id varchar(190) NOT NULL DEFAULT '',
  resent_of bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY  (id),
  KEY created (created),
  KEY status (status)
) " . $wpdb->get_charset_collate() . ';'
	);

	// Alleen als de tabel er echt is, is het schema klaar. Een SELECT in plaats van SHOW TABLES: die laat tijdelijke tabellen (de testsuite) niet zien.
	$suppressed = $wpdb->suppress_errors( true );
	$complete   = false !== $wpdb->query( 'SELECT 1 FROM ' . _ww_mail_log_table() . ' LIMIT 1' ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_mail_log_table().
	$wpdb->suppress_errors( $suppressed );
	if ( ! $complete ) {
		return;
	}

	update_option( 'ww_mail_db_version', WW_MAIL_DB_VERSION, true );
	wp_set_option_autoload( 'ww_mail_db_version', true );
}

/**
 * Is de tabel aangelegd voor deze schemaversie? Leest alleen de optie.
 */
function _ww_mail_log_ready(): bool {
	return WW_MAIL_DB_VERSION === (string) get_option( 'ww_mail_db_version' );
}

add_action(
	'admin_init',
	static function (): void {
		if ( ! _ww_mail_log_ready() ) {
			_ww_mail_log_install();
		}
	}
);
add_action( 'after_switch_theme', '_ww_mail_log_install' );

/**
 * Leest of zet het id van de regel die de volgende mail opnieuw verstuurt (voor Opnieuw versturen).
 *
 * Zonder argument: het huidige id (0 als er geen is). Met een id: zet dat id voor de volgende regel. De volgende regel
 * gebruikt het één keer en zet het terug op 0. Het staat in de cache van de mail, zodat `_ww_mail_reset()` het ook leegt.
 *
 * @param int|null $id Id van de oorspronkelijke regel, 0 om te wissen, of null om alleen te lezen.
 */
function _ww_mail_log_resent_of( ?int $id = null ): int {
	$cache = &_ww_mail_cache();
	if ( null !== $id ) {
		$cache['resent_of'] = max( 0, $id );
	}
	return (int) ( $cache['resent_of'] ?? 0 );
}

/**
 * Kort tekst in tot hoogstens $bytes bytes zonder een UTF-8-teken te splitsen. Ingekorte tekst eindigt op '…'.
 * Ongeldige UTF-8 wordt eerst vervangen, zodat de database de tekst altijd aanneemt.
 *
 * @param string $text  Tekst.
 * @param int    $bytes Hoogstens zoveel bytes.
 */
function _ww_mail_log_cut_bytes( string $text, int $bytes ): string {
	$text = mb_scrub( $text, 'UTF-8' );
	if ( strlen( $text ) <= $bytes ) {
		return $text;
	}
	return mb_strcut( $text, 0, $bytes - strlen( '…' ), 'UTF-8' ) . '…';
}

/**
 * Kort tekst in tot hoogstens $chars tekens (voor een varchar-kolom). Ingekorte tekst eindigt op '…'.
 *
 * @param string $text  Tekst.
 * @param int    $chars Hoogstens zoveel tekens.
 */
function _ww_mail_log_cut_chars( string $text, int $chars ): string {
	$text = mb_scrub( $text, 'UTF-8' );
	if ( mb_strlen( $text, 'UTF-8' ) <= $chars ) {
		return $text;
	}
	return mb_substr( $text, 0, $chars - 1, 'UTF-8' ) . '…';
}

/**
 * Alleen de adressen uit een lijst: een tekst met komma's of een array, met of zonder naam ("Jan <jan@x.nl>").
 *
 * @param mixed $list Adressen.
 * @return list<string>
 */
function _ww_mail_log_addresses( $list ): array {
	if ( is_string( $list ) ) {
		$list = explode( ',', $list );
	}
	$addresses = array();
	foreach ( is_array( $list ) ? $list : array() as $item ) {
		if ( is_array( $item ) ) {
			// Uit PHPMailer: array( adres, naam ).
			$item = $item[0] ?? '';
		}
		if ( ! is_string( $item ) ) {
			continue;
		}
		if ( preg_match( '/<(.+)>/', $item, $matches ) ) {
			$item = $matches[1];
		}
		$item = trim( $item );
		if ( '' !== $item ) {
			$addresses[] = _ww_mail_log_cut_chars( $item, 254 );
		}
	}
	return $addresses;
}

/**
 * Alleen de namen van de bijlagen: de tekstsleutel, anders de bestandsnaam van het pad. Nooit een pad of inhoud.
 *
 * @param mixed $attachments Bijlagen uit wp_mail().
 * @return list<string>
 */
function _ww_mail_log_attachment_names( $attachments ): array {
	if ( is_string( $attachments ) ) {
		$attachments = explode( "\n", str_replace( "\r\n", "\n", $attachments ) );
	}
	$names = array();
	foreach ( is_array( $attachments ) ? $attachments : array() as $key => $path ) {
		if ( is_string( $key ) && '' !== trim( $key ) ) {
			$name = wp_basename( $key );
		} elseif ( is_string( $path ) ) {
			$name = wp_basename( trim( $path ) );
		} else {
			continue;
		}
		if ( '' !== $name ) {
			$names[] = _ww_mail_log_cut_chars( $name, 255 );
		}
	}
	return $names;
}

/**
 * JSON voor de log: slashes en tekens leesbaar, zodat zoeken op een adres (LIKE) het adres letterlijk vindt.
 *
 * @param mixed $value Waarde.
 */
function _ww_mail_log_json( $value ): string {
	$json = wp_json_encode( $value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
	return is_string( $json ) ? $json : '';
}

/**
 * Bewaart één mail in de log. Geeft het id van de regel, of 0 als er niets bewaard is (geen tabel, fout).
 *
 * Aan, onderwerp, tekst en bijlagen komen uit $mail_data. CC, BCC, Van, Reply-To en content-type komen uit de mailer
 * (`$GLOBALS['phpmailer']`), want wp_mail() heeft de headers daar al uitgelezen. wp_mail() leegt die lijsten vóór elke
 * mail; een mail die mislukt voordat de adressen erin staan (bij het Van-adres) heeft dus lege lijsten. Het content-type
 * is in dat geval nog dat van de vorige mail.
 *
 * @param array<string,mixed> $mail_data Mailgegevens van wp_mail_succeeded of wp_mail_failed.
 * @param string              $status    `sent` of `failed`.
 * @param string              $error     Foutmelding, anders ''.
 */
function _ww_mail_log_record( array $mail_data, string $status, string $error = '' ): int {
	global $wpdb;
	if ( ! _ww_mail_log_ready() ) {
		return 0;
	}

	$mailer      = $GLOBALS['phpmailer'] ?? null;
	$is_mailer   = $mailer instanceof PHPMailer\PHPMailer\PHPMailer;
	$transport   = '';
	$provider_id = '';
	if ( $mailer instanceof WW_PHPMailer && '' !== $mailer->ww_transport ) {
		$transport   = $mailer->ww_transport;
		$provider_id = $mailer->ww_provider_id;
	}
	if ( '' === $transport ) {
		$transport = _ww_mail_foreign_mailer();
		$transport = '' === $transport ? 'server' : $transport;
	}

	$recipients = array(
		'to'  => _ww_mail_log_addresses( $mail_data['to'] ?? array() ),
		'cc'  => $is_mailer ? _ww_mail_log_addresses( $mailer->getCcAddresses() ) : array(),
		'bcc' => $is_mailer ? _ww_mail_log_addresses( $mailer->getBccAddresses() ) : array(),
	);
	$content_type = $is_mailer ? (string) $mailer->ContentType : ''; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- PHPMailer.
	// Met een AltBody zet preSend() het type op multipart/alternative; Body is dan HTML. Opnieuw versturen heeft text/html nodig.
	if ( str_starts_with( strtolower( $content_type ), 'multipart/alternative' ) ) {
		$content_type = 'text/html';
	}
	$headers = array(
		'content_type' => $content_type,
		'from'         => $is_mailer ? (string) $mailer->From : '', // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- PHPMailer.
		'reply_to'     => $is_mailer ? _ww_mail_log_addresses( array_values( $mailer->getReplyToAddresses() ) ) : array(),
	);

	$subject = $mail_data['subject'] ?? '';
	$message = $mail_data['message'] ?? '';
	$row     = array(
		'created'     => current_time( 'mysql', true ),
		'recipients'  => _ww_mail_log_json( $recipients ),
		'subject'     => _ww_mail_log_cut_chars( is_scalar( $subject ) ? (string) $subject : '', 255 ),
		'message'     => _ww_mail_log_cut_bytes( is_scalar( $message ) ? (string) $message : '', WW_MAIL_LOG_MAX_MESSAGE ),
		'headers'     => _ww_mail_log_json( $headers ),
		'attachments' => _ww_mail_log_json( _ww_mail_log_attachment_names( $mail_data['attachments'] ?? array() ) ),
		'transport'   => _ww_mail_log_cut_chars( $transport, 40 ),
		'status'      => 'sent' === $status ? 'sent' : 'failed',
		'error'       => _ww_mail_log_cut_bytes( $error, 65535 ),
		'provider_id' => _ww_mail_log_cut_chars( $provider_id, 190 ),
		'resent_of'   => _ww_mail_log_resent_of(),
	);
	_ww_mail_log_resent_of( 0 );

	// Geen databasefout op het scherm of in error_log: de query bevat de tekst van de mail.
	$suppressed = $wpdb->suppress_errors( true );
	try {
		$inserted = $wpdb->insert( _ww_mail_log_table(), $row, array( '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d' ) );
	} finally {
		$wpdb->suppress_errors( $suppressed );
	}
	return false === $inserted ? 0 : (int) $wpdb->insert_id;
}

/**
 * Bewaart een mail en vangt elke fout af: de log laat een mail nooit mislukken. Een fout gaat als vaste tekst naar
 * error_log, zonder iets van de mail en zonder de query.
 *
 * @param array<string,mixed> $mail_data Mailgegevens.
 * @param string              $status    `sent` of `failed`.
 * @param string              $error     Foutmelding, anders ''.
 */
function _ww_mail_log_record_safely( array $mail_data, string $status, string $error = '' ): void {
	try {
		if ( _ww_mail_log_ready() && 0 === _ww_mail_log_record( $mail_data, $status, $error ) ) {
			error_log( 'ww mail log: regel niet opgeslagen.' ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- vaste tekst, niets van de mail.
		}
	} catch ( Throwable $e ) {
		error_log( 'ww mail log: regel niet opgeslagen (' . get_class( $e ) . ').' ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- vaste tekst en de klasse, niets van de mail.
	}
}

/**
 * Handler van wp_mail_succeeded.
 *
 * @param mixed $mail_data Mailgegevens van wp_mail().
 */
function _ww_mail_log_on_succeeded( $mail_data ): void {
	_ww_mail_log_record_safely( is_array( $mail_data ) ? $mail_data : array(), 'sent' );
}
add_action( 'wp_mail_succeeded', '_ww_mail_log_on_succeeded' );

/**
 * Handler van wp_mail_failed: de mailgegevens zitten in de data van de fout.
 *
 * @param mixed $error Fout van wp_mail().
 */
function _ww_mail_log_on_failed( $error ): void {
	if ( ! $error instanceof WP_Error ) {
		return;
	}
	$data = $error->get_error_data();
	_ww_mail_log_record_safely( is_array( $data ) ? $data : array(), 'failed', $error->get_error_message() );
}
add_action( 'wp_mail_failed', '_ww_mail_log_on_failed' );

/**
 * Zet een rij uit de tabel om: recipients, headers en attachments als array.
 *
 * @param object $row Rij uit de database.
 */
function _ww_mail_log_decode( object $row ): object {
	$recipients       = json_decode( (string) $row->recipients, true );
	$headers          = json_decode( (string) $row->headers, true );
	$attachments      = json_decode( (string) $row->attachments, true );
	$recipients       = is_array( $recipients ) ? $recipients : array();
	$row->recipients  = array(
		'to'  => is_array( $recipients['to'] ?? null ) ? $recipients['to'] : array(),
		'cc'  => is_array( $recipients['cc'] ?? null ) ? $recipients['cc'] : array(),
		'bcc' => is_array( $recipients['bcc'] ?? null ) ? $recipients['bcc'] : array(),
	);
	$headers          = is_array( $headers ) ? $headers : array();
	$row->headers     = array(
		'content_type' => is_string( $headers['content_type'] ?? null ) ? $headers['content_type'] : '',
		'from'         => is_string( $headers['from'] ?? null ) ? $headers['from'] : '',
		'reply_to'     => is_array( $headers['reply_to'] ?? null ) ? $headers['reply_to'] : array(),
	);
	$row->attachments = is_array( $attachments ) ? $attachments : array();
	return $row;
}

/**
 * Eén regel, gedecodeerd, of null.
 *
 * @param int $id Id van de regel.
 */
function _ww_mail_log_get( int $id ): ?object {
	global $wpdb;
	if ( $id < 1 || ! _ww_mail_log_ready() ) {
		return null;
	}
	$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . _ww_mail_log_table() . ' WHERE id = %d', $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_mail_log_table().
	return is_object( $row ) ? _ww_mail_log_decode( $row ) : null;
}

/**
 * Het eerstvolgende hogere (nieuwere) en lagere (oudere) id, of 0. Bladeren gaat door het hele logboek: de weergave
 * Mislukt en de zoekterm tellen bewust niet mee.
 *
 * @param int $id Id van de regel.
 * @return array{newer:int,older:int}
 */
function _ww_mail_log_neighbors( int $id ): array {
	global $wpdb;
	if ( ! _ww_mail_log_ready() ) {
		return array(
			'newer' => 0,
			'older' => 0,
		);
	}
	$table = _ww_mail_log_table();
	return array(
		'newer' => (int) $wpdb->get_var( $wpdb->prepare( 'SELECT MIN(id) FROM ' . $table . ' WHERE id > %d', $id ) ), // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_mail_log_table().
		'older' => (int) $wpdb->get_var( $wpdb->prepare( 'SELECT MAX(id) FROM ' . $table . ' WHERE id < %d', $id ) ), // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_mail_log_table().
	);
}

/**
 * Het aantal regels in het logboek: alle, verstuurde en mislukte. Eén query op de index van status; een lege tabel of een
 * log die nog niet klaar is geeft nullen.
 *
 * @return array{all:int,sent:int,failed:int}
 */
function _ww_mail_log_counts(): array {
	global $wpdb;
	$counts = array(
		'all'    => 0,
		'sent'   => 0,
		'failed' => 0,
	);
	if ( ! _ww_mail_log_ready() ) {
		return $counts;
	}
	$rows = $wpdb->get_results( 'SELECT status, COUNT(*) AS total FROM ' . _ww_mail_log_table() . ' GROUP BY status', ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_mail_log_table().
	foreach ( (array) $rows as $row ) {
		$total          = (int) ( $row['total'] ?? 0 );
		$counts['all'] += $total;
		if ( isset( $row['status'] ) && isset( $counts[ $row['status'] ] ) ) {
			$counts[ $row['status'] ] += $total;
		}
	}
	return $counts;
}

/**
 * De nieuwste regel van het logboek, of null.
 */
function _ww_mail_log_latest(): ?object {
	global $wpdb;
	if ( ! _ww_mail_log_ready() ) {
		return null;
	}
	$id = (int) $wpdb->get_var( 'SELECT MAX(id) FROM ' . _ww_mail_log_table() ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_mail_log_table().
	return _ww_mail_log_get( $id );
}

/**
 * Verwijdert regels. Geeft het aantal verwijderde rijen terug.
 *
 * @param array<int|string,mixed> $ids Regels.
 */
function _ww_mail_log_delete( array $ids ): int {
	global $wpdb;
	$ids = array_values( array_filter( array_map( 'absint', $ids ) ) );
	if ( ! $ids || ! _ww_mail_log_ready() ) {
		return 0;
	}
	$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
	$deleted      = $wpdb->query( $wpdb->prepare( 'DELETE FROM ' . _ww_mail_log_table() . " WHERE id IN ($placeholders)", $ids ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- tabelnaam uit _ww_mail_log_table(), placeholders voor de ID's.
	return (int) $deleted;
}

/**
 * Ruimt op: regels ouder dan 30 dagen, in porties van 1000, hoogstens 20 porties per run.
 */
function _ww_mail_log_cleanup(): void {
	global $wpdb;
	if ( ! _ww_mail_log_ready() ) {
		return;
	}
	$cutoff = gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS );
	$table  = _ww_mail_log_table();

	for ( $batch = 0; $batch < 20; $batch++ ) {
		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM $table WHERE created < %s ORDER BY id ASC LIMIT 1000", $cutoff ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_mail_log_table().
		if ( ! is_array( $ids ) || ! $ids ) {
			break;
		}
		_ww_mail_log_delete( $ids );
		if ( count( $ids ) < 1000 ) {
			break;
		}
	}
}
add_action( WW_MAIL_LOG_CLEANUP_HOOK, '_ww_mail_log_cleanup' );

/**
 * Plant de dagelijkse opruiming in bij een adminbezoek.
 */
function _ww_mail_log_schedule(): void {
	if ( ! wp_next_scheduled( WW_MAIL_LOG_CLEANUP_HOOK ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', WW_MAIL_LOG_CLEANUP_HOOK );
	}
}
add_action( 'admin_init', '_ww_mail_log_schedule' );

/**
 * Haalt de opruiming weg bij een themawissel.
 */
function _ww_mail_log_unschedule(): void {
	wp_clear_scheduled_hook( WW_MAIL_LOG_CLEANUP_HOOK );
}
add_action( 'switch_theme', '_ww_mail_log_unschedule' );

/**
 * Een stap van 100 regels waarin het adres in de ontvangers of de headers voorkomt, op id oplopend. LIKE met esc_like()
 * als voorselectie (_ en % kunnen in een adres staan); _ww_mail_privacy_matches() beslist.
 *
 * @param string $email    Adres, in kleine letters.
 * @param int    $offset   Overslaan.
 * @param int    $after_id Alleen regels met een hoger id.
 * @return object[] Gedecodeerde regels.
 */
function _ww_mail_privacy_candidates( string $email, int $offset = 0, int $after_id = 0 ): array {
	global $wpdb;
	if ( ! _ww_mail_log_ready() ) {
		return array();
	}
	$like = '%' . $wpdb->esc_like( $email ) . '%';
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . _ww_mail_log_table() . ' WHERE ( recipients LIKE %s OR headers LIKE %s ) AND id > %d ORDER BY id ASC LIMIT 100 OFFSET %d', $like, $like, $after_id, $offset ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_mail_log_table().
	return array_map( '_ww_mail_log_decode', is_array( $rows ) ? $rows : array() );
}

/**
 * Staat het adres (hoofdletters genegeerd) als ontvanger (to, cc, bcc) of Reply-To in deze regel? Het Van-adres telt niet.
 *
 * @param object $row   Gedecodeerde regel.
 * @param string $email Adres, in kleine letters.
 */
function _ww_mail_privacy_matches( object $row, string $email ): bool {
	$lists = array( $row->recipients['to'], $row->recipients['cc'], $row->recipients['bcc'], $row->headers['reply_to'] );
	foreach ( $lists as $list ) {
		foreach ( $list as $address ) {
			if ( is_string( $address ) && strtolower( trim( $address ) ) === $email ) {
				return true;
			}
		}
	}
	return false;
}

/**
 * Exporter voor de privacytools: per regel de datum, het onderwerp en de status, 100 per stap.
 *
 * @param string $email Adres.
 * @param int    $page  Stap.
 * @return array{data: list<array<string,mixed>>, done: bool}
 */
function _ww_mail_privacy_exporter( string $email, int $page = 1 ): array {
	$email = strtolower( trim( $email ) );
	$page  = max( 1, $page );
	$rows  = '' === $email ? array() : _ww_mail_privacy_candidates( $email, ( $page - 1 ) * 100 );
	$data  = array();
	foreach ( $rows as $row ) {
		if ( ! _ww_mail_privacy_matches( $row, $email ) ) {
			continue;
		}
		$data[] = array(
			'group_id'    => 'ww-mail-log',
			'group_label' => __( 'Email log', 'webwerckt-base' ),
			'item_id'     => 'ww-mail-log-' . (int) $row->id,
			'data'        => array(
				array(
					'name'  => __( 'Datum', 'webwerckt-base' ),
					'value' => get_date_from_gmt( (string) $row->created, 'Y-m-d H:i' ),
				),
				array(
					'name'  => __( 'Onderwerp', 'webwerckt-base' ),
					'value' => (string) $row->subject,
				),
				array(
					'name'  => __( 'Status', 'webwerckt-base' ),
					'value' => 'sent' === $row->status ? __( 'Verstuurd', 'webwerckt-base' ) : __( 'Mislukt', 'webwerckt-base' ),
				),
			),
		);
	}
	return array(
		'data' => $data,
		'done' => count( $rows ) < 100,
	);
}

/**
 * Eraser voor de privacytools: verwijdert de regels van dit adres helemaal.
 *
 * Wissen verschuift de posities in de resultaten, dus werkt één aanroep alle stappen van 100 af (met het laatste id als
 * beginpunt in plaats van een offset) en meldt dan klaar.
 *
 * @param string $email Adres.
 * @param int    $page  Stap (niet gebruikt).
 * @return array{items_removed: bool, items_retained: bool, messages: list<string>, done: bool}
 */
function _ww_mail_privacy_eraser( string $email, int $page = 1 ): array {
	$email   = strtolower( trim( $email ) );
	$removed = 0;
	$last    = 0;
	while ( '' !== $email ) {
		$rows = _ww_mail_privacy_candidates( $email, 0, $last );
		$ids  = array();
		foreach ( $rows as $row ) {
			$last = max( $last, (int) $row->id );
			if ( _ww_mail_privacy_matches( $row, $email ) ) {
				$ids[] = (int) $row->id;
			}
		}
		$removed += _ww_mail_log_delete( $ids );
		if ( count( $rows ) < 100 ) {
			break;
		}
	}
	return array(
		'items_removed'  => $removed > 0,
		'items_retained' => false,
		'messages'       => array(),
		'done'           => true,
	);
}

add_filter(
	'wp_privacy_personal_data_exporters',
	static function ( $exporters ) {
		$exporters                        = is_array( $exporters ) ? $exporters : array();
		$exporters['webwerckt-base-mail'] = array(
			'exporter_friendly_name' => __( 'Email log', 'webwerckt-base' ),
			'callback'               => '_ww_mail_privacy_exporter',
		);
		return $exporters;
	}
);
add_filter(
	'wp_privacy_personal_data_erasers',
	static function ( $erasers ) {
		$erasers                        = is_array( $erasers ) ? $erasers : array();
		$erasers['webwerckt-base-mail'] = array(
			'eraser_friendly_name' => __( 'Email log', 'webwerckt-base' ),
			'callback'             => '_ww_mail_privacy_eraser',
		);
		return $erasers;
	}
);
