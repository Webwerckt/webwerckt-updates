<?php
/**
 * Mail (beslissing 0034): de interface voor aansluitingen en hun registratie.
 *
 * Een aansluiting (SMTP, Brevo) verstuurt een mail die WordPress in een `WW_PHPMailer` heeft klaargezet. Aansluitingen
 * worden geregistreerd met het filter `ww_mail_transports` (id => klassenaam) en één keer per verzoek aangemaakt.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Een aansluiting die mail verstuurt.
 */
interface WW_Mail_Transport {

	/**
	 * Id van de aansluiting (sanitize_key), bijv. `smtp` of `brevo`.
	 */
	public function id(): string;

	/**
	 * Naam op het scherm, bijv. `SMTP` of `Brevo (API)`.
	 */
	public function label(): string;

	/**
	 * Velddefinities voor het scherm: per veld `name`, `label`, `type`, `options`, `default`, `required`, `secret`, `constant`.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public function settings(): array;

	/**
	 * Of alle verplichte velden en geheimen aanwezig en leesbaar zijn.
	 */
	public function is_configured(): bool;

	/**
	 * Verstuurt de mail die WordPress in de mailer heeft klaargezet.
	 *
	 * @param WW_PHPMailer $mail De mailer, na preSend().
	 * @return true|WP_Error
	 */
	public function send( WW_PHPMailer $mail ): true|WP_Error;
}

/**
 * Per verzoek bewaarde gegevens van de mail (de aangemaakte aansluitingen). Leeg te maken met `_ww_mail_reset()`.
 *
 * @return array<string,mixed>
 */
function &_ww_mail_cache(): array {
	static $cache = array();
	return $cache;
}

/**
 * Vergeet wat per verzoek bewaard is (voor tests, of na het wijzigen van de registratie).
 */
function _ww_mail_reset(): void {
	$cache = &_ww_mail_cache();
	$cache = array();
}

/**
 * De geregistreerde aansluitingen, id => instantie. Een klasse die niet bestaat of de interface niet implementeert, wordt
 * overgeslagen.
 *
 * @return array<string,WW_Mail_Transport>
 */
function _ww_mail_transports(): array {
	$cache = &_ww_mail_cache();
	if ( isset( $cache['transports'] ) && is_array( $cache['transports'] ) ) {
		return $cache['transports'];
	}

	require_once __DIR__ . '/mail/class-ww-mail-transport-smtp.php';
	require_once __DIR__ . '/mail/class-ww-mail-transport-brevo.php';

	/**
	 * Filtert de aansluitingen: id => klassenaam van een klasse die `WW_Mail_Transport` implementeert.
	 *
	 * @param mixed $transports Id => klassenaam (een array; iets anders telt als leeg).
	 */
	$classes    = apply_filters(
		'ww_mail_transports',
		array(
			'smtp'  => 'WW_Mail_Transport_Smtp',
			'brevo' => 'WW_Mail_Transport_Brevo',
		)
	);
	$transports = array();
	if ( ! is_array( $classes ) ) {
		$classes = array();
	}
	foreach ( $classes as $id => $class ) {
		$id = sanitize_key( (string) $id );
		if ( '' === $id || ! is_string( $class ) || ! class_exists( $class ) ) {
			continue;
		}
		$interfaces = class_implements( $class );
		if ( ! is_array( $interfaces ) || ! isset( $interfaces['WW_Mail_Transport'] ) ) {
			continue;
		}
		$transport = new $class();
		if ( $transport instanceof WW_Mail_Transport ) {
			$transports[ $id ] = $transport;
		}
	}

	$cache['transports'] = $transports;
	return $transports;
}

/**
 * De gekozen aansluiting, of null bij "Geen" ('') of een onbekende id.
 */
function _ww_mail_transport(): ?WW_Mail_Transport {
	$id = _ww_mail_transport_id();
	if ( '' === $id ) {
		return null;
	}
	return _ww_mail_transports()[ sanitize_key( $id ) ] ?? null;
}

/**
 * Een andere mailplugin die het versturen overneemt: `wp-mail-smtp` als WP Mail SMTP actief is, anders ''.
 */
function _ww_mail_foreign_mailer(): string {
	$foreign = class_exists( 'WPMailSMTP\Core' ) ? 'wp-mail-smtp' : '';
	/**
	 * Intern filter: laat een test een andere mailplugin nabootsen.
	 *
	 * @param string $foreign Id van de mailplugin, of ''.
	 */
	$foreign = apply_filters( '_ww_mail_foreign_mailer', $foreign );
	return $foreign;
}
