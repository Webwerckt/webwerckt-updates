<?php
/**
 * Paginacache opwarmen (beslissing 0030): elke vijf minuten vraagt de cron een handvol pagina's op die nog niet in de
 * cache staan, zodat een bezoeker vrijwel altijd een bewaarde pagina krijgt.
 *
 * Het opvragen is een gewoon verzoek zonder cookies naar de eigen site: WordPress bouwt de pagina op en de outputbuffer
 * van inc/page-cache.php bewaart hem, net als bij een bezoeker. Er komt dus geen tweede manier van bewaren bij.
 *
 * Rustig voor gedeelde hosting: één verzoek tegelijk, hoogstens 20 pagina's en 20 seconden per ronde (minder als de
 * tijdslimiet van PHP dat vraagt), na elke pagina even wachten (zo lang als de pagina duurde, hoogstens 2 s), en
 * stoppen bij een trage reactie of een fout van de server.
 *
 * Alleen pagina's die ontbreken. Een verlopen of oude pagina gaat eerst weg: de regels in .htaccess (beslissing 0029)
 * sturen een bestand dat er staat, ook als het verlopen is, en dan zou het opvragen niets nieuws opleveren.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Niet 'ww_page_cache_preload': dat is het filter, en acties en filters delen één register.
const WW_PAGE_CACHE_PRELOAD_HOOK     = 'ww_page_cache_preload_run';
const WW_PAGE_CACHE_PRELOAD_OPTION   = 'ww_page_cache_preload';
const WW_PAGE_CACHE_PRELOAD_STATUS   = 'ww_page_cache_preload_status';
const WW_PAGE_CACHE_PRELOAD_QUEUE    = 'ww_page_cache_preload_queue';
const WW_PAGE_CACHE_PRELOAD_SKIP     = 'ww_page_cache_preload_skip';
const WW_PAGE_CACHE_PRELOAD_URLS     = 'ww_page_cache_preload_urls';
const WW_PAGE_CACHE_PRELOAD_LOCK     = 'ww_page_cache_preload_lock';
const WW_PAGE_CACHE_PRELOAD_BATCH    = 20;
const WW_PAGE_CACHE_PRELOAD_BUDGET   = 20.0;
const WW_PAGE_CACHE_PRELOAD_SLOW     = 5.0;
const WW_PAGE_CACHE_PRELOAD_PAUSE    = 2.0;
const WW_PAGE_CACHE_PRELOAD_TIMEOUT  = 10;
const WW_PAGE_CACHE_PRELOAD_MARGIN   = 5.0;
const WW_PAGE_CACHE_PRELOAD_MAX_URLS = 2000;
const WW_PAGE_CACHE_PRELOAD_QUEUE_MAX = 50;
const WW_PAGE_CACHE_PRELOAD_RETRY     = HOUR_IN_SECONDS;

/**
 * Staat opwarmen aan? Alleen als de paginacache zelf aan staat, de beheerder het niet heeft uitgezet en het filter
 * het niet tegenhoudt.
 */
function _ww_page_cache_preload_enabled(): bool {
	return '' === _ww_page_cache_status() && _ww_page_cache_preload_allowed() && '0' !== get_option( WW_PAGE_CACHE_PRELOAD_OPTION, '1' );
}

/**
 * Laat het filter opwarmen toe? Los van de schakelaar in het menu, zodat het menu kan zeggen waarom het uit staat.
 */
function _ww_page_cache_preload_allowed(): bool {
	/**
	 * Zet het opwarmen van de paginacache aan of uit, voor bijvoorbeeld een site op een krappe server.
	 *
	 * @param bool $enabled Standaard true.
	 */
	return (bool) apply_filters( 'ww_page_cache_preload', true );
}

/**
 * Hoeveel pagina's een ronde hoogstens opvraagt.
 */
function _ww_page_cache_preload_batch(): int {
	/**
	 * Hoeveel pagina's het opwarmen per ronde (elke vijf minuten) hoogstens opvraagt. Een ronde stopt ook na 20 seconden.
	 *
	 * @param int $pages Standaard 20.
	 */
	return max( 1, (int) apply_filters( 'ww_page_cache_preload_batch', WW_PAGE_CACHE_PRELOAD_BATCH ) );
}

/**
 * De pagina's om op te warmen, in volgorde: de homepage, dan de sitemap van WordPress (pagina's eerst, dan de andere
 * post types, dan termarchieven). Zo vallen pagina's met noindex en uitgevinkte post types vanzelf weg. Staat de sitemap
 * uit (een SEO-plugin), dan de berichten van de publieke post types. Een uur bewaard; een purge van alles of van een
 * post type maakt de lijst opnieuw.
 *
 * @return list<string>
 */
function _ww_page_cache_preload_urls(): array {
	$cached = get_transient( WW_PAGE_CACHE_PRELOAD_URLS );
	if ( is_array( $cached ) ) {
		return array_values( array_filter( $cached, 'is_string' ) );
	}
	$max  = max( 1, (int) apply_filters( 'ww_page_cache_preload_max_urls', WW_PAGE_CACHE_PRELOAD_MAX_URLS ) );
	$urls = array_merge( array( home_url( '/' ) ), _ww_page_cache_preload_sitemap_urls( $max ) );
	/**
	 * De pagina's die het opwarmen opvraagt, in volgorde. Alleen URL's op de host van de site tellen.
	 *
	 * @param string[] $urls De homepage en de URL's uit de sitemap.
	 */
	$urls = array_filter( (array) apply_filters( 'ww_page_cache_preload_urls', $urls ), 'is_string' );
	$host = _ww_page_cache_url_host( home_url() );
	$urls = array_values( array_unique( array_filter( $urls, static fn( string $url ): bool => _ww_page_cache_url_host( $url ) === $host ) ) );
	$urls = array_slice( $urls, 0, $max );
	set_transient( WW_PAGE_CACHE_PRELOAD_URLS, $urls, HOUR_IN_SECONDS );
	return $urls;
}

/**
 * URL's uit de sitemap van WordPress, of uit de publieke post types als die sitemap uit staat. Met Meertalig eerst de
 * sitemap van de taal van het verzoek (in cron de standaardtaal), dan die van elke zichtbare extra taal
 * (_ww_page_cache_preload_language_urls()).
 *
 * @return list<string>
 */
function _ww_page_cache_preload_sitemap_urls( int $max ): array {
	$providers = wp_sitemaps_get_server()->registry->get_providers();
	if ( array() === $providers ) {
		$types = array_values( array_diff( get_post_types( array( 'public' => true ) ), array( 'attachment' ) ) );
		$ids   = get_posts(
			array(
				'post_type'      => $types,
				'post_status'    => 'publish',
				'posts_per_page' => $max,
				'orderby'        => array(
					'type' => 'ASC',
					'date' => 'DESC',
				),
				'fields'         => 'ids',
				'has_password'   => false,
			)
		);
		return array_values( array_filter( array_map( static fn( $id ): string => (string) get_permalink( $id ), $ids ) ) );
	}
	$urls = _ww_page_cache_preload_provider_urls( $providers, $max );
	return array_merge( $urls, _ww_page_cache_preload_language_urls( $max - count( $urls ) ) );
}

/**
 * URL's uit de providers van de sitemap, in de taal van het verzoek: pagina's eerst, dan de andere post types, dan
 * termarchieven.
 *
 * @param array<string,WP_Sitemaps_Provider> $providers Providers van de sitemap.
 * @param int                                $max       Hoogstens zoveel URL's.
 * @return list<string>
 */
function _ww_page_cache_preload_provider_urls( array $providers, int $max ): array {
	$urls = array();
	foreach ( $providers as $provider ) {
		$subtypes = array_keys( $provider->get_object_subtypes() );
		if ( in_array( 'page', $subtypes, true ) ) {
			$subtypes = array_merge( array( 'page' ), array_diff( $subtypes, array( 'page' ) ) );
		}
		if ( array() === $subtypes ) {
			$subtypes = array( '' );
		}
		foreach ( $subtypes as $subtype ) {
			$pages = (int) $provider->get_max_num_pages( (string) $subtype );
			for ( $page = 1; $page <= $pages && count( $urls ) < $max; $page++ ) {
				foreach ( $provider->get_url_list( $page, (string) $subtype ) as $entry ) {
					if ( is_string( $entry['loc'] ?? null ) ) {
						$urls[] = $entry['loc'];
					}
				}
			}
		}
	}
	return $urls;
}

/**
 * De URL's van de zichtbare extra talen (beslissing 0044): per taal de hoofdpagina en de sitemap van die taal. Rond het
 * ophalen staat de taal van het verzoek op die taal (_ww_languages_set_current()), zodat de query's van de sitemap op die
 * taal filteren (_ww_languages_sitemap_query_args(), want cron is geen frontend) en archief- en termlinks het
 * voorvoegsel krijgen; daarna komt de oude taal terug. Een verborgen taal staat er nooit in, ook niet als een
 * ingelogde redacteur op de knop drukt. Zonder Meertalig of naast een SEO-plugin array().
 *
 * @param int $max Hoogstens zoveel URL's.
 * @return list<string>
 */
function _ww_page_cache_preload_language_urls( int $max ): array {
	if ( $max <= 0 || ! _ww_languages_active() || ! _ww_seo_enabled() ) {
		return array();
	}
	$codes = _ww_visible_language_codes();
	if ( array() === $codes ) {
		return array();
	}
	$providers = wp_sitemaps_get_server()->registry->get_providers();
	$previous  = _ww_languages_state()['current'];
	$urls      = array();
	try {
		foreach ( $codes as $code ) {
			if ( count( $urls ) >= $max ) {
				break;
			}
			_ww_languages_set_current( $code );
			$urls[] = _ww_languages_home( $code );
			$urls   = array_merge( $urls, _ww_page_cache_preload_provider_urls( $providers, $max - count( $urls ) ) );
		}
	} finally {
		_ww_languages_set_current( $previous );
	}
	return $urls;
}

/**
 * Sleutel en pad van een URL in de cache, of null als die URL nooit in de cache komt (een andere host, parameters).
 *
 * @return array{key:string,path:string}|null
 */
function _ww_page_cache_preload_target( string $url ): ?array {
	$host = _ww_page_cache_url_host( $url );
	if ( ! in_array( $host, _ww_page_cache_hosts(), true ) ) {
		return null;
	}
	$path  = (string) wp_parse_url( $url, PHP_URL_PATH );
	$path  = '' === $path ? '/' : $path;
	$query = (string) wp_parse_url( $url, PHP_URL_QUERY );
	$key   = _ww_page_cache_key( $host, $path . ( '' === $query ? '' : '?' . $query ), _ww_page_cache_ignored_params() );
	return null === $key ? null : array(
		'key'  => $key,
		'path' => $path,
	);
}

/**
 * Staat deze pagina goed in de cache: niet verlopen, niet oud door een purge, en de HTML is er? Leest alleen meta.json,
 * zodat een ronde ook bij duizenden pagina's licht blijft.
 *
 * @phpstan-impure Leest de cachemap, die tussen twee aanroepen verandert.
 *
 * @param array{key:string,path:string}                                    $target Sleutel en pad.
 * @param array{all:float,types:array<string,float>,posts:array<int,float>} $marker De laatste purges.
 */
function _ww_page_cache_preload_cached( array $target, array $marker ): bool {
	$dir  = _ww_page_cache_dir() . '/' . $target['key'];
	$meta = json_decode( (string) @file_get_contents( $dir . '/meta.json' ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents, WordPress.PHP.NoSilencedErrors -- een ontbrekende pagina is geen fout.
	if ( ! is_array( $meta ) || ( $meta['path'] ?? null ) !== $target['path'] || (int) ( $meta['expires'] ?? 0 ) <= time() ) {
		return false;
	}
	$types = array_values( array_filter( (array) ( $meta['post_types'] ?? array() ), 'is_string' ) );
	if ( _ww_page_cache_is_stale( (float) ( $meta['created'] ?? 0 ), $types, (int) ( $meta['post_id'] ?? 0 ), $marker ) ) {
		return false;
	}
	return is_file( $dir . '/' . _ww_page_cache_html_file( $meta ) );
}

/**
 * Vraagt een pagina op zoals een bezoeker zonder login: geen cookies, geen redirects volgen.
 *
 * @return array{code:int,time:float,error:string}
 */
function _ww_page_cache_preload_fetch( string $url ): array {
	$start    = microtime( true );
	$response = wp_remote_get(
		$url,
		array(
			'timeout'     => WW_PAGE_CACHE_PRELOAD_TIMEOUT,
			'redirection' => 0,
			'sslverify'   => (bool) apply_filters( 'https_local_ssl_verify', false ),
			'user-agent'  => 'Webwerckt Base page cache preload; ' . home_url( '/' ),
			'headers'     => array( 'Accept' => 'text/html' ),
		)
	);
	$time = microtime( true ) - $start;
	if ( is_wp_error( $response ) ) {
		return array(
			'code'  => 0,
			'time'  => $time,
			'error' => $response->get_error_message(),
		);
	}
	return array(
		'code'  => (int) wp_remote_retrieve_response_code( $response ),
		'time'  => $time,
		'error' => '',
	);
}

/**
 * Wacht na een pagina even, zo lang als die pagina duurde (hoogstens 2 s): een trage site krijgt zo vanzelf meer rust.
 */
function _ww_page_cache_preload_pause( float $seconds ): void {
	$seconds = min( max( 0.0, $seconds ), WW_PAGE_CACHE_PRELOAD_PAUSE );
	if ( $seconds > 0 ) {
		usleep( (int) ( $seconds * 1000000 ) );
	}
}

/**
 * Seconden die een ronde mag beginnen met opvragen. Standaard 20, maar nooit voorbij de tijdslimiet van PHP: wp-cron.php
 * draait alle taken in één proces (ook de beeldoptimalisatie), en via HTTP gestart geldt max_execution_time. Na de
 * laatste start blijft er ruimte voor één verzoek (de time-out), de pauze en een marge.
 *
 * @param int   $limit max_execution_time, 0 is geen limiet.
 * @param float $spent Seconden die dit proces al draait.
 */
function _ww_page_cache_preload_budget( int $limit, float $spent ): float {
	if ( $limit <= 0 ) {
		return WW_PAGE_CACHE_PRELOAD_BUDGET;
	}
	return min( WW_PAGE_CACHE_PRELOAD_BUDGET, $limit - $spent - WW_PAGE_CACHE_PRELOAD_TIMEOUT - WW_PAGE_CACHE_PRELOAD_MARGIN );
}

/**
 * Eén ronde opwarmen (de cron, of de knop in het menu). Loopt de lijst langs, met de pagina's in de wachtrij eerst, en
 * vraagt op wat ontbreekt. Stopt na het maximum aantal pagina's of de tijd, en meteen bij een fout of een trage reactie:
 * dan is de server druk of niet bereikbaar, en de volgende ronde probeert het opnieuw.
 *
 * Een pagina die na het opvragen nog steeds niet in de cache staat, slaat het opwarmen een tijd over: zonder 200 (een
 * redirect, een 404) tot de maximale bewaartijd voorbij is, met een 200 een uur. Een 200 die niet bewaard werd, kan
 * iets tijdelijks zijn (een opslag of purge tijdens het opbouwen); een dag wachten liet zulke pagina's te lang leeg.
 *
 * @return array{time:int,fetched:int,stop:string,url:string,code:int,error:string,seconds:float}
 */
function _ww_page_cache_preload_run(): array {
	$status = array(
		'time'    => time(),
		'fetched' => 0,
		'stop'    => '',
		'url'     => '',
		'code'    => 0,
		'error'   => '',
		'seconds' => 0.0,
	);
	if ( ! _ww_page_cache_preload_enabled() ) {
		$status['stop'] = 'off';
		return $status;
	}
	if ( false !== get_transient( WW_PAGE_CACHE_PRELOAD_LOCK ) ) {
		$status['stop'] = 'busy';
		return $status;
	}
	$start  = microtime( true );
	$budget = _ww_page_cache_preload_budget( (int) ini_get( 'max_execution_time' ), $start - _ww_page_cache_request_time() );
	if ( $budget <= 0 ) {
		$status['stop'] = 'time';
		update_option( WW_PAGE_CACHE_PRELOAD_STATUS, $status, false );
		return $status;
	}
	set_transient( WW_PAGE_CACHE_PRELOAD_LOCK, time(), 2 * MINUTE_IN_SECONDS );

	$batch   = _ww_page_cache_preload_batch();
	$marker  = _ww_page_cache_marker();
	$now     = time();
	$skip    = _ww_page_cache_preload_skip( $now );
	$queue   = array_values( array_filter( (array) get_option( WW_PAGE_CACHE_PRELOAD_QUEUE, array() ), 'is_string' ) );
	$urls    = array_values( array_unique( array_merge( $queue, _ww_page_cache_preload_urls() ) ) );
	$handled = array();
	$added   = array();

	foreach ( $urls as $url ) {
		if ( $status['fetched'] >= $batch || microtime( true ) - $start >= $budget ) {
			break;
		}
		$target = _ww_page_cache_preload_target( $url );
		if ( isset( $skip[ $url ] ) || null === $target || _ww_page_cache_preload_cached( $target, $marker ) ) {
			$handled[] = $url;
			continue;
		}
		// Verlopen of oud: eerst weg, anders sturen de regels in .htaccess het oude bestand en verandert er niets.
		_ww_page_cache_unlink( _ww_page_cache_dir() . '/' . $target['key'] );

		$result    = _ww_page_cache_preload_fetch( $url );
		$handled[] = $url;
		++$status['fetched'];
		if ( '' !== $result['error'] || in_array( $result['code'], array( 401, 403, 429 ), true ) || $result['code'] >= 500 ) {
			$status = array_merge(
				$status,
				array(
					'stop'  => '' !== $result['error'] ? 'error' : 'http',
					'url'   => $url,
					'code'  => $result['code'],
					'error' => $result['error'],
				)
			);
			break;
		}
		if ( ! _ww_page_cache_preload_cached( $target, $marker ) ) {
			$added[ $url ] = array(
				'until' => $now + ( 200 === $result['code'] ? min( WW_PAGE_CACHE_PRELOAD_RETRY, _ww_page_cache_max_age() ) : _ww_page_cache_max_age() ),
				'code'  => $result['code'],
			);
		}
		if ( $result['time'] > WW_PAGE_CACHE_PRELOAD_SLOW ) {
			$status = array_merge(
				$status,
				array(
					'stop'    => 'slow',
					'url'     => $url,
					'seconds' => round( $result['time'], 1 ),
				)
			);
			break;
		}
		_ww_page_cache_preload_pause( $result['time'] );
	}

	// De wachtrij opnieuw lezen: een opslag tijdens deze ronde kan er een URL aan hebben toegevoegd.
	$queue = array_values( array_diff( array_filter( (array) get_option( WW_PAGE_CACHE_PRELOAD_QUEUE, array() ), 'is_string' ), $handled ) );
	update_option( WW_PAGE_CACHE_PRELOAD_QUEUE, $queue, false );
	// Ook de overgeslagen pagina's opnieuw lezen: alles legen of een opslag tijdens deze ronde kan de lijst hebben
	// geleegd, en die mag de ronde niet terugschrijven. Alleen wat deze ronde overslaat, komt erbij.
	update_option( WW_PAGE_CACHE_PRELOAD_SKIP, array_merge( _ww_page_cache_preload_skip_raw( time() ), $added ), false );
	update_option( WW_PAGE_CACHE_PRELOAD_STATUS, $status, false );
	delete_transient( WW_PAGE_CACHE_PRELOAD_LOCK );
	return $status;
}

/**
 * De ruwe regels van de overslaanlijst die nog niet aan de beurt zijn: URL => tijdstip (oude vorm) of array{until,code}.
 *
 * @return array<string,int|array{until:int,code?:int}>
 */
function _ww_page_cache_preload_skip_raw( int $now ): array {
	$raw = array();
	foreach ( (array) get_option( WW_PAGE_CACHE_PRELOAD_SKIP, array() ) as $url => $entry ) {
		$until = is_array( $entry ) ? ( $entry['until'] ?? 0 ) : $entry;
		if ( is_string( $url ) && is_int( $until ) && $until > $now ) {
			$raw[ $url ] = $entry;
		}
	}
	return $raw;
}

/**
 * De overgeslagen pagina's die nog niet aan de beurt zijn: URL => tijdstip waarop het opwarmen ze weer probeert.
 *
 * @return array<string,int>
 */
function _ww_page_cache_preload_skip( int $now ): array {
	return array_map( static fn( $entry ): int => is_array( $entry ) ? (int) $entry['until'] : (int) $entry, _ww_page_cache_preload_skip_raw( $now ) );
}

/**
 * De overgeslagen pagina's met hun HTTP-code, de vroegste eerst. Een oude regel heeft code 0.
 *
 * @return list<array{url:string,until:int,code:int}>
 */
function _ww_page_cache_preload_skipped( int $now ): array {
	$list = array();
	foreach ( _ww_page_cache_preload_skip_raw( $now ) as $url => $entry ) {
		$list[] = array(
			'url'   => $url,
			'until' => is_array( $entry ) ? (int) $entry['until'] : (int) $entry,
			'code'  => is_array( $entry ) ? (int) ( $entry['code'] ?? 0 ) : 0,
		);
	}
	usort( $list, static fn( array $a, array $b ): int => $a['until'] <=> $b['until'] );
	return $list;
}

/**
 * Waarom een pagina is overgeslagen: redirect (3xx), missing (4xx) of temp (al het andere).
 */
function _ww_page_cache_skip_reason( int $code ): string {
	if ( $code >= 300 && $code < 400 ) {
		return 'redirect';
	}
	return $code >= 400 && $code < 500 ? 'missing' : 'temp';
}

/**
 * De cron: één ronde.
 */
function _ww_page_cache_preload_cron(): void {
	_ww_page_cache_preload_run();
}
add_action( WW_PAGE_CACHE_PRELOAD_HOOK, '_ww_page_cache_preload_cron' );

/**
 * Hoeveel pagina's uit de lijst in de cache staan, voor het menu Pagina cache, en welke nog niet klaar zijn (niet bewaard
 * en niet overgeslagen, in de volgorde van de lijst).
 *
 * @return array{cached:int,total:int,pending:list<string>}
 */
function _ww_page_cache_preload_counts(): array {
	$urls    = _ww_page_cache_preload_urls();
	$marker  = _ww_page_cache_marker();
	$skip    = _ww_page_cache_preload_skip( time() );
	$cached  = 0;
	$pending = array();
	foreach ( $urls as $url ) {
		$target = _ww_page_cache_preload_target( $url );
		if ( null !== $target && _ww_page_cache_preload_cached( $target, $marker ) ) {
			++$cached;
		} elseif ( ! isset( $skip[ $url ] ) ) {
			$pending[] = $url;
		}
	}
	return array(
		'cached'  => $cached,
		'total'   => count( $urls ),
		'pending' => $pending,
	);
}

/**
 * Zet een URL vooraan in de wachtrij en haalt hem van de overslaanlijst.
 */
function _ww_page_cache_preload_queue_url( string $url ): void {
	$queue = array_values( array_filter( (array) get_option( WW_PAGE_CACHE_PRELOAD_QUEUE, array() ), 'is_string' ) );
	$queue = array_slice( array_values( array_unique( array_merge( array( $url ), $queue ) ) ), 0, WW_PAGE_CACHE_PRELOAD_QUEUE_MAX );
	update_option( WW_PAGE_CACHE_PRELOAD_QUEUE, $queue, false );
	$skip = (array) get_option( WW_PAGE_CACHE_PRELOAD_SKIP, array() );
	if ( isset( $skip[ $url ] ) ) {
		unset( $skip[ $url ] );
		update_option( WW_PAGE_CACHE_PRELOAD_SKIP, $skip, false );
	}
}

/**
 * Een opgeslagen bericht vooraan in de wachtrij: zijn eigen pagina is net geleegd, en komt zo binnen een ronde terug.
 *
 * @param mixed $post_id Bericht-ID.
 */
function _ww_page_cache_preload_queue_post( $post_id ): void {
	$post_id = absint( $post_id );
	if ( 0 === $post_id || ! is_post_publicly_viewable( $post_id ) || post_password_required( $post_id ) ) {
		return;
	}
	$url = get_permalink( $post_id );
	if ( ! is_string( $url ) || '' === $url ) {
		return;
	}
	_ww_page_cache_preload_queue_url( $url );
}
add_action( '_ww_purge_post', '_ww_page_cache_preload_queue_post', 20 );

/**
 * Een nieuw bericht of een andere slug: de lijst opnieuw maken.
 */
function _ww_page_cache_preload_forget_urls(): void {
	delete_transient( WW_PAGE_CACHE_PRELOAD_URLS );
}
add_action( '_ww_purge_post_type', '_ww_page_cache_preload_forget_urls', 20, 0 );

/**
 * Alles geleegd: ook de lijst en de overgeslagen pagina's opnieuw, want een pagina die een 404 gaf, kan er nu zijn.
 */
function _ww_page_cache_preload_reset(): void {
	delete_transient( WW_PAGE_CACHE_PRELOAD_URLS );
	delete_option( WW_PAGE_CACHE_PRELOAD_SKIP );
}
add_action( '_ww_purge_all', '_ww_page_cache_preload_reset', 20, 0 );

/**
 * Plant het opwarmen elke vijf minuten in, of haalt het weg als het uit staat. Niet bij bezoekers: dat kost bij elke
 * misser een query.
 */
function _ww_page_cache_preload_schedule(): void {
	if ( _ww_is_visitor_request() ) {
		return;
	}
	$scheduled = wp_next_scheduled( WW_PAGE_CACHE_PRELOAD_HOOK );
	$wanted    = _ww_page_cache_preload_enabled();
	if ( $wanted && ! $scheduled ) {
		wp_schedule_event( time() + MINUTE_IN_SECONDS, 'ww_five_minutes', WW_PAGE_CACHE_PRELOAD_HOOK );
	} elseif ( ! $wanted && $scheduled ) {
		wp_clear_scheduled_hook( WW_PAGE_CACHE_PRELOAD_HOOK );
	}
}
add_action( 'init', '_ww_page_cache_preload_schedule' );

/**
 * Ander thema: het opwarmen hoeft niet meer.
 */
function _ww_page_cache_preload_unschedule(): void {
	wp_clear_scheduled_hook( WW_PAGE_CACHE_PRELOAD_HOOK );
	delete_transient( WW_PAGE_CACHE_PRELOAD_LOCK );
}
add_action( 'switch_theme', '_ww_page_cache_preload_unschedule' );
