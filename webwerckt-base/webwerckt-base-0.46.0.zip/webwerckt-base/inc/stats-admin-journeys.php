<?php
/**
 * Statistieken: het tabblad Paden (beslissing 0039).
 *
 * Bovenaan de populaire routes uit de dagtabel (flow en exit, elke periode). Daaronder de losse bezoeken van de laatste
 * 30 dagen uit _ww_stats_journeys(), met filters en bladeren. Elke regel is een samenvatting (het pad, de begintijd)
 * en linkt naar het bezoek op een eigen URL (&visit=dag.bezoeker.start). Met JavaScript opent dezelfde link een
 * venster (assets/js/stats-visits.js) met het detail uit een <template> per regel; zonder JavaScript toont de server
 * het detail.
 *
 * @package webwerckt-base
 */

defined( 'ABSPATH' ) || exit;

/**
 * _ww_stats_page_label() met een geheugen per verzoek: een pagina met 50 bezoeken vraagt hetzelfde pad vaak op, en elk
 * pad kost een url_to_postid().
 *
 * @param string $path  Pad, zoals bewaard.
 * @param bool   $reset Leeg het geheugen (aan het begin van het tabblad).
 * @return array{label:string,url:string}
 */
function _ww_stats_journey_page( string $path, bool $reset = false ): array {
	static $labels = array();
	if ( $reset ) {
		$labels = array();
	}
	if ( ! isset( $labels[ $path ] ) ) {
		$labels[ $path ] = _ww_stats_page_label( $path );
	}
	return $labels[ $path ];
}

/**
 * Een pad als titel met een link (zonder link als er geen adres is), geëscapet.
 *
 * @param string $path Pad, zoals bewaard.
 */
function _ww_stats_journey_page_link( string $path ): string {
	$page = _ww_stats_journey_page( $path );
	return '' !== $page['url'] ? '<a href="' . esc_url( $page['url'] ) . '">' . esc_html( $page['label'] ) . '</a>' : esc_html( $page['label'] );
}

/**
 * Eén regel van de tijdlijn als geëscapete HTML: de tijd (H:i in de tijdzone van de site, of "tijd onbekend" bij ts 0)
 * en wat er gebeurde. Een weergave is de titel van de pagina met een link; een klik "Klik: tekst (soort: doel)"; een
 * formulier begonnen, een stap of verstuurd. De weergave van een formulier (kind view) en onbekende soorten geven ''.
 *
 * @param array<string,mixed> $item Een item van een bezoek (WWStatsItem).
 */
function _ww_stats_timeline_line( array $item ): string {
	$parts = _ww_stats_timeline_parts( $item );
	return null === $parts ? '' : '<span class="ww-stats-timeline__time">' . $parts['time'] . '</span> ' . $parts['text'];
}

/**
 * De tijd en de tekst van een regel van de tijdlijn, elk als geëscapete HTML (zie _ww_stats_timeline_line()). Null bij
 * een item dat geen regel krijgt.
 *
 * @param array<string,mixed> $item Een item van een bezoek (WWStatsItem).
 * @return array{time:string,text:string}|null
 */
function _ww_stats_timeline_parts( array $item ): ?array {
	$type = (string) ( $item['type'] ?? '' );
	$kind = (string) ( $item['kind'] ?? '' );
	$ts   = (int) ( $item['ts'] ?? 0 );

	if ( 'view' === $type ) {
		$text = _ww_stats_journey_page_link( (string) ( $item['path'] ?? '' ) );
	} elseif ( 'click' === $type ) {
		$label  = trim( (string) ( $item['label'] ?? '' ) );
		$label  = '' !== $label ? $label : __( '(zonder tekst)', 'webwerckt-base' );
		$soort  = _ww_stats_click_kind_label( $kind );
		$target = (string) ( $item['target'] ?? '' );
		if ( '' !== $soort && '' !== $target ) {
			/* translators: 1: tekst van de link of knop, 2: soort klik (zoals Bellen), 3: doel (nummer, adres of pad). */
			$text = sprintf( __( 'Klik: %1$s (%2$s: %3$s)', 'webwerckt-base' ), $label, $soort, $target );
		} elseif ( '' !== $soort ) {
			/* translators: 1: tekst van de link of knop, 2: soort klik (zoals Knop). */
			$text = sprintf( __( 'Klik: %1$s (%2$s)', 'webwerckt-base' ), $label, $soort );
		} else {
			/* translators: %s: tekst van de link of knop. */
			$text = sprintf( __( 'Klik: %s', 'webwerckt-base' ), $label );
		}
		$text = esc_html( $text );
	} elseif ( 'form' === $type ) {
		$title = _ww_stats_form_title( (int) ( $item['form_id'] ?? 0 ) );
		switch ( $kind ) {
			case 'start':
				/* translators: %s: titel van het formulier. */
				$text = sprintf( __( 'Formulier begonnen: %s', 'webwerckt-base' ), $title );
				break;
			case 'step':
				/* translators: 1: nummer van de stap, 2: titel van het formulier. */
				$text = sprintf( __( 'Formulier stap %1$d: %2$s', 'webwerckt-base' ), (int) ( $item['step'] ?? 0 ), $title );
				break;
			case 'sent':
				/* translators: %s: titel van het formulier. */
				$text = sprintf( __( 'Formulier verstuurd: %s', 'webwerckt-base' ), $title );
				break;
			default:
				return null; // view is ruis; andere soorten bestaan niet.
		}
		$text = esc_html( $text );
	} else {
		return null;
	}

	$time = $ts > 0 ? (string) wp_date( 'H:i', $ts ) : __( 'tijd onbekend', 'webwerckt-base' );
	return array(
		'time' => esc_html( $time ),
		'text' => $text,
	);
}

/**
 * De pictogrammen van een bezoek: gebeld, gemaild, gedownload en formulier verstuurd, elk met tekst voor schermlezers.
 * Bellen en mailen komen uit de items (het bezoek kent alleen contact, voor beide samen).
 *
 * @param array<string,mixed> $visit Een bezoek (WWStatsVisit).
 */
function _ww_stats_visit_icons( array $visit ): string {
	$tel    = false;
	$mailto = false;
	foreach ( (array) ( $visit['items'] ?? array() ) as $item ) {
		if ( 'click' === ( $item['type'] ?? '' ) ) {
			$tel    = $tel || 'tel' === $item['kind'];
			$mailto = $mailto || 'mailto' === $item['kind'];
		}
	}
	$icons = array(
		'phone'    => array( $tel, __( 'Gebeld', 'webwerckt-base' ) ),
		'email'    => array( $mailto, __( 'Gemaild', 'webwerckt-base' ) ),
		'download' => array( ! empty( $visit['download'] ), __( 'Gedownload', 'webwerckt-base' ) ),
		'yes-alt'  => array( ! empty( $visit['sent'] ), __( 'Formulier verstuurd', 'webwerckt-base' ) ),
	);
	$html = '';
	foreach ( $icons as $icon => list( $on, $text ) ) {
		if ( $on ) {
			$html .= '<span class="ww-stats-icon" title="' . esc_attr( $text ) . '"><span class="dashicons dashicons-' . $icon . '" aria-hidden="true"></span><span class="screen-reader-text">' . esc_html( $text ) . '</span></span>';
		}
	}
	return $html;
}

/**
 * De duur van een bezoek: "< 1 min" bij 0, anders in hele minuten.
 *
 * @param int $seconds Laatste minus eerste tijdstip.
 */
function _ww_stats_visit_duration( int $seconds ): string {
	$minutes = intdiv( max( 0, $seconds ), 60 );
	if ( 0 === $minutes ) {
		return __( '< 1 min', 'webwerckt-base' );
	}
	/* translators: %s: aantal minuten. */
	return sprintf( _n( '%s minuut', '%s minuten', $minutes, 'webwerckt-base' ), number_format_i18n( $minutes ) );
}

/**
 * De sleutel van een bezoek in de URL (&visit=): dag, bezoeker en begintijd, met punten ertussen. De dag komt uit de
 * rijen (day), niet uit de begintijd: een bezoek met ts 0 heeft ook een sleutel.
 *
 * @param array<string,mixed> $visit Een bezoek (WWStatsVisit) met day.
 */
function _ww_stats_visit_key( array $visit ): string {
	return (string) ( $visit['day'] ?? '' ) . '.' . (string) ( $visit['visitor'] ?? '' ) . '.' . (int) ( $visit['start'] ?? 0 );
}

/**
 * Leest een sleutel uit _ww_stats_visit_key(). Alles wat niet precies dat formaat heeft geeft null.
 *
 * @param string $key Waarde van &visit=.
 * @return array{day:string,visitor:string,start:int}|null
 */
function _ww_stats_parse_visit_key( string $key ): ?array {
	if ( 1 !== preg_match( '/^(\d{4}-\d{2}-\d{2})\.([A-Za-z0-9]{1,16})\.(\d{1,10})$/', $key, $m ) ) {
		return null;
	}
	return array(
		'day'     => $m[1],
		'visitor' => $m[2],
		'start'   => (int) $m[3],
	);
}

/**
 * Het pad van een bezoek als titels, geëscapet: "Home → Diensten → Contact". Bij meer dan 4 weergaven de eerste 3 en
 * "… +N"; zonder weergave "(geen pagina)".
 *
 * @param array<string,mixed> $visit Een bezoek (WWStatsVisit).
 */
function _ww_stats_visit_path( array $visit ): string {
	$titles = array();
	foreach ( (array) ( $visit['items'] ?? array() ) as $item ) {
		if ( 'view' === ( $item['type'] ?? '' ) ) {
			$titles[] = _ww_stats_journey_page( (string) ( $item['path'] ?? '' ) )['label'];
		}
	}
	if ( array() === $titles ) {
		return esc_html__( '(geen pagina)', 'webwerckt-base' );
	}
	$count = count( $titles );
	if ( $count > 4 ) {
		$titles   = array_slice( $titles, 0, 3 );
		$titles[] = '… +' . number_format_i18n( $count - 3 );
	}
	return esc_html( implode( ' → ', $titles ) );
}

/**
 * Het aantal regels van de tijdlijn van een bezoek (items die een regel krijgen).
 *
 * @param array<string,mixed> $visit Een bezoek (WWStatsVisit).
 */
function _ww_stats_visit_line_count( array $visit ): int {
	$count = 0;
	foreach ( (array) ( $visit['items'] ?? array() ) as $item ) {
		if ( null !== _ww_stats_timeline_parts( (array) $item ) ) {
			++$count;
		}
	}
	return $count;
}

/**
 * Eén rij van de lijst Bezoeken: een link naar het bezoek met het pad als titel en daaronder de begintijd, de herkomst,
 * het apparaat en het aantal regels; dan de duur en de pictogrammen. Met JavaScript opent de link het venster met het
 * detail uit <template id="ww-stats-visit-{index}">.
 *
 * @param array<string,mixed> $visit Een bezoek (WWStatsVisit).
 * @param string              $url   URL van het bezoek (&visit=).
 * @param int                 $index Plaats op de pagina, vanaf 0.
 * @return list<string> Geëscapete cellen.
 */
function _ww_stats_visit_row( array $visit, string $url, int $index ): array {
	$start = (int) $visit['start'];
	$count = _ww_stats_visit_line_count( $visit );
	$meta  = array( $start > 0 ? (string) wp_date( 'j M H:i', $start ) : __( 'tijd onbekend', 'webwerckt-base' ) );
	if ( (int) $visit['pages'] > 0 ) {
		$meta[] = _ww_stats_referrer_label( _ww_stats_referrer_group( (string) $visit['referrer'] ) );
		if ( '' !== $visit['device'] ) {
			$meta[] = _ww_stats_device_label( (string) $visit['device'] );
		}
	}
	/* translators: %s: aantal regels in de tijdlijn. */
	$meta[] = sprintf( _n( '%s regel', '%s regels', $count, 'webwerckt-base' ), number_format_i18n( $count ) );

	$link = '<a class="ww-stats-visit-link" href="' . esc_url( $url ) . '" data-ww-visit="' . $index . '" aria-haspopup="dialog">'
		. '<strong>' . _ww_stats_visit_path( $visit ) . '</strong>'
		. '<span class="ww-stats-visit-meta">' . esc_html( implode( ' · ', $meta ) ) . '</span></a>';

	return array(
		$link,
		esc_html( _ww_stats_visit_duration( (int) $visit['end'] - $start ) ),
		_ww_stats_visit_icons( $visit ),
	);
}

/**
 * De titel van een bezoek: "Bezoek van 14 nov. 2026 10:42", of "Bezoek, tijd onbekend" bij ts 0. Niet geëscapet.
 *
 * @param array<string,mixed> $visit Een bezoek (WWStatsVisit).
 */
function _ww_stats_visit_title( array $visit ): string {
	$start = (int) ( $visit['start'] ?? 0 );
	if ( $start <= 0 ) {
		return __( 'Bezoek, tijd onbekend', 'webwerckt-base' );
	}
	/* translators: %s: datum en tijd van het begin van het bezoek. */
	return sprintf( __( 'Bezoek van %s', 'webwerckt-base' ), (string) wp_date( 'j M Y H:i', $start ) );
}

/**
 * Het detail van een bezoek, geëscapet: de feiten (binnenkomst, herkomst, apparaat, land, pagina's, duur) en de
 * tijdlijn met een pictogram per soort. Bij 2 minuten of meer na de vorige regel staat erbij hoe lang. Onderaan de
 * uitleg over wanneer een bezoek eindigt. Voor het venster en voor de eigen URL.
 *
 * @param array<string,mixed> $visit Een bezoek (WWStatsVisit).
 */
function _ww_stats_visit_detail( array $visit ): string {
	$pages = (int) $visit['pages'];
	if ( $pages > 0 ) {
		$entry    = _ww_stats_journey_page_link( (string) $visit['entry_path'] );
		$referrer = esc_html( _ww_stats_referrer_label( _ww_stats_referrer_group( (string) $visit['referrer'] ) ) );
		$device   = '' !== $visit['device'] ? esc_html( _ww_stats_device_label( (string) $visit['device'] ) ) : '–';
		$country  = esc_html( _ww_stats_country_label( (string) $visit['country'] ) );
	} else {
		$entry    = esc_html__( '(geen pagina)', 'webwerckt-base' );
		$referrer = '–';
		$device   = '–';
		$country  = '–';
	}
	$facts = array(
		__( 'Binnenkomst', 'webwerckt-base' ) => $entry,
		__( 'Herkomst', 'webwerckt-base' )    => $referrer,
		__( 'Apparaat', 'webwerckt-base' )    => $device,
		__( 'Land', 'webwerckt-base' )        => $country,
		__( "Pagina's", 'webwerckt-base' )    => esc_html( number_format_i18n( $pages ) ),
		__( 'Duur', 'webwerckt-base' )        => esc_html( _ww_stats_visit_duration( (int) $visit['end'] - (int) $visit['start'] ) ),
	);
	$html = '<dl class="ww-stats-visit-facts">';
	foreach ( $facts as $label => $value ) {
		$html .= '<div><dt>' . esc_html( (string) $label ) . '</dt><dd>' . $value . '</dd></div>';
	}
	$html .= '</dl>';

	$icons = array(
		'view'  => array( 'dashicons-media-default', __( 'Pagina bekeken', 'webwerckt-base' ) ),
		'click' => array( 'dashicons-admin-links', __( 'Klik', 'webwerckt-base' ) ),
		'form'  => array( 'dashicons-feedback', __( 'Formulier', 'webwerckt-base' ) ),
	);
	$lines = '';
	$prev  = 0;
	foreach ( (array) $visit['items'] as $item ) {
		$item  = (array) $item;
		$parts = _ww_stats_timeline_parts( $item );
		if ( null === $parts ) {
			continue;
		}
		$type = (string) $item['type'];
		$ts   = (int) $item['ts'];
		$gap  = '';
		if ( $prev > 0 && $ts - $prev >= 120 ) {
			/* translators: %s: aantal minuten. */
			$gap = '<small>' . esc_html( sprintf( __( '%s min na de vorige stap', 'webwerckt-base' ), number_format_i18n( intdiv( $ts - $prev, 60 ) ) ) ) . '</small>';
		}
		$prev   = $ts;
		$icon   = $icons[ $type ] ?? $icons['view'];
		$lines .= '<li class="ww-stats-timeline__' . esc_attr( $type ) . '"><span class="ww-stats-timeline__time">' . $parts['time'] . '</span>'
			. '<span class="ww-stats-timeline__icon" title="' . esc_attr( $icon[1] ) . '"><span class="dashicons ' . $icon[0] . '" aria-hidden="true"></span></span>'
			. '<span class="ww-stats-timeline__text">' . $parts['text'] . $gap . '</span></li>';
	}
	$html .= '<h3>' . esc_html__( 'Tijdlijn', 'webwerckt-base' ) . '</h3><ol class="ww-stats-timeline">' . $lines . '</ol>';
	return $html . '<p class="description">' . esc_html__( 'Een bezoek eindigt na 30 minuten zonder activiteit en om middernacht. Tijden zijn afgerond op de minuut. Bezoekers op hetzelfde netwerk met dezelfde browser kunnen samen als één bezoek tellen.', 'webwerckt-base' ) . '</p>';
}

/**
 * Het lege venster voor het detail van een bezoek, één keer per pagina. stats-visits.js vult het uit de <template> van
 * de regel; zonder JavaScript blijft het dicht.
 */
function _ww_stats_visit_dialog(): string {
	return '<dialog class="ww-stats-dialog" id="ww-stats-visit-dialog" aria-labelledby="ww-stats-visit-dialog-title" data-pos-format="' . esc_attr(
		/* translators: 1: plaats van het bezoek op de pagina, 2: aantal bezoeken op de pagina. */
		__( '%1$s van %2$s', 'webwerckt-base' )
	) . '">'
		. '<div class="ww-stats-dialog__head"><h2 id="ww-stats-visit-dialog-title"></h2>'
		. '<button type="button" class="ww-stats-dialog__close" data-ww-close aria-label="' . esc_attr__( 'Sluiten', 'webwerckt-base' ) . '"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></button></div>'
		. '<div class="ww-stats-dialog__body" data-ww-body></div>'
		. '<div class="ww-stats-dialog__foot"><button type="button" class="button" data-ww-prev>' . esc_html__( '‹ Vorig bezoek', 'webwerckt-base' ) . '</button>'
		. '<span data-ww-pos></span><button type="button" class="button" data-ww-next>' . esc_html__( 'Volgend bezoek ›', 'webwerckt-base' ) . '</button></div>'
		. '</dialog>';
}

/**
 * De filters als queryvariabelen, alleen die aan staan: sent=1, contact=1 en entry=pad. Voor het bladeren en voor de
 * periodekeuze, zodat een andere periode of pagina de filters houdt.
 *
 * @param array{sent:bool, contact:bool, entry:string} $filters Uit _ww_stats_journey_filters().
 * @return array<string,string>
 */
function _ww_stats_journey_args( array $filters ): array {
	$args = array();
	if ( $filters['sent'] ) {
		$args['sent'] = '1';
	}
	if ( $filters['contact'] ) {
		$args['contact'] = '1';
	}
	if ( '' !== $filters['entry'] ) {
		$args['entry'] = $filters['entry'];
	}
	return $args;
}

/**
 * Het filterformulier van de lijst Bezoeken (GET): page, tab, de periode zoals die nu geldt (range, of from en to),
 * de selectievakjes sent en contact en de keuzelijst entry met de top 50 pagina's. Bladeren begint daarna weer op 1.
 *
 * @param array<string,string>                         $period  Uit _ww_stats_period().
 * @param array{sent:bool, contact:bool, entry:string} $filters Uit _ww_stats_journey_filters().
 * @param list<string>                                 $entries Uit _ww_stats_journey_entries().
 */
function _ww_stats_journey_form( array $period, array $filters, array $entries ): string {
	$html  = '<form method="get" action="' . esc_url( admin_url( 'admin.php' ) ) . '" class="ww-stats-journey-filters">';
	$html .= '<input type="hidden" name="page" value="' . esc_attr( WW_STATS_PAGE ) . '">';
	$html .= '<input type="hidden" name="tab" value="journeys">';
	if ( 'custom' === $period['range'] ) {
		$html .= '<input type="hidden" name="from" value="' . esc_attr( $period['from'] ) . '">';
		$html .= '<input type="hidden" name="to" value="' . esc_attr( $period['to'] ) . '">';
	} else {
		$html .= '<input type="hidden" name="range" value="' . esc_attr( $period['range'] ) . '">';
	}
	$html .= '<label><input type="checkbox" name="sent" value="1"' . checked( $filters['sent'], true, false ) . '> ' . esc_html__( 'Met verstuurd formulier', 'webwerckt-base' ) . '</label>';
	$html .= '<label><input type="checkbox" name="contact" value="1"' . checked( $filters['contact'], true, false ) . '> ' . esc_html__( 'Met klik op bellen of mail', 'webwerckt-base' ) . '</label>';

	// Een gekozen pad dat niet (meer) in de top 50 staat blijft kiesbaar.
	if ( '' !== $filters['entry'] && ! in_array( $filters['entry'], $entries, true ) ) {
		array_unshift( $entries, $filters['entry'] );
	}
	$html .= '<span class="ww-stats-journey-filters__entry"><label for="ww-stats-entry">' . esc_html__( 'Binnenkomstpagina', 'webwerckt-base' ) . '</label> ';
	$html .= '<select id="ww-stats-entry" name="entry"><option value="">' . esc_html__( 'Alle', 'webwerckt-base' ) . '</option>';
	foreach ( $entries as $path ) {
		$html .= '<option value="' . esc_attr( $path ) . '"' . selected( $filters['entry'], $path, false ) . '>' . esc_html( _ww_stats_journey_page( $path )['label'] ) . '</option>';
	}
	$html .= '</select></span>';
	$html .= '<button type="submit" class="button">' . esc_html__( 'Filteren', 'webwerckt-base' ) . '</button>';
	return $html . '</form>';
}

/**
 * Het tabblad Paden: populaire routes (Van → naar en Laatste pagina) en de lijst Bezoeken; of, met &visit=, het detail
 * van één bezoek.
 *
 * De filters, de pagina en het bezoek komen rechtstreeks uit $_GET: _ww_stats_admin_query() maakt alles schoon met
 * sanitize_text_field(), en dat haalt procentcodes uit een pad. _ww_stats_journey_filters() en
 * _ww_stats_parse_visit_key() controleren zelf.
 *
 * @param array<string,string> $period Uit _ww_stats_period().
 * @param array<string,mixed>  $query  Uit _ww_stats_admin_query(); dit tabblad leest zijn filters zelf.
 */
function _ww_stats_render_journeys( array $period, array $query ): void { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed -- zelfde aanroep als _ww_stats_render_clicks().
	_ww_stats_journey_page( '', true );
	$today = (string) wp_date( 'Y-m-d' );

	// De bezoeken van deze pagina.
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen lezen.
	$get     = wp_unslash( $_GET );
	$filters = _ww_stats_journey_filters( $get );
	$paged   = max( 1, absint( _ww_data_to_string( $get['paged'] ?? '' ) ) );
	$result  = _ww_stats_journeys( $period['from'], $period['to'], $filters, $paged, $today );
	$pages   = (int) ceil( $result['total'] / 50 );
	if ( $pages > 0 && $paged > $pages ) {
		// Een pagina voorbij de laatste (oude link, of minder bezoeken na een filter): toon de laatste.
		$paged  = $pages;
		$result = _ww_stats_journeys( $period['from'], $period['to'], $filters, $paged, $today );
	}
	$args = _ww_stats_journey_args( $filters );
	$here = $args + ( $paged > 1 ? array( 'paged' => (string) $paged ) : array() );
	$urls = array();
	foreach ( $result['visits'] as $visit ) {
		$urls[] = _ww_stats_tab_url( $period, 'journeys', $here + array( 'visit' => _ww_stats_visit_key( $visit ) ) );
	}

	// Eén bezoek op zijn eigen URL.
	$wanted = _ww_data_to_string( $get['visit'] ?? '' );
	if ( '' !== $wanted ) {
		if ( _ww_stats_render_visit( $wanted, $result['visits'], $urls, _ww_stats_tab_url( $period, 'journeys', $here ), $today ) ) {
			return;
		}
		echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'Dit bezoek is niet gevonden.', 'webwerckt-base' ) . '</p></div>';
	}

	$lists = _ww_stats_query( $period['from'], $period['to'], $today )['lists'];

	// 1. Populaire routes.
	$rows = array();
	foreach ( $lists['flow'] ?? array() as $entry ) {
		$parts = explode( ' → ', $entry['item'], 2 );
		$route = 2 === count( $parts )
			? _ww_stats_journey_page_link( $parts[0] ) . ' → ' . _ww_stats_journey_page_link( $parts[1] )
			: _ww_stats_journey_page_link( $entry['item'] ); // (overige) wordt Overige.
		$rows[] = array( $route, esc_html( number_format_i18n( $entry['views'] ) ), esc_html( number_format_i18n( $entry['visitors'] ) ) );
	}
	$blocks = _ww_stats_block(
		__( 'Van → naar', 'webwerckt-base' ),
		array( __( 'Route', 'webwerckt-base' ), __( 'Aantal', 'webwerckt-base' ), __( 'Bezoekers', 'webwerckt-base' ) ),
		$rows,
		array(
			'open'  => 25,
			'cards' => true,
			'size'  => 'wide',
			'empty' => __( 'Nog geen routes gemeten in deze periode.', 'webwerckt-base' ),
		)
	);

	$rows = array();
	foreach ( $lists['exit'] ?? array() as $entry ) {
		$rows[] = array( _ww_stats_journey_page_link( $entry['item'] ), esc_html( number_format_i18n( $entry['views'] ) ), esc_html( number_format_i18n( $entry['visitors'] ) ) );
	}
	$blocks .= _ww_stats_block(
		__( 'Laatste pagina', 'webwerckt-base' ),
		array( __( 'Pagina', 'webwerckt-base' ), __( 'Bezoeken', 'webwerckt-base' ), __( 'Bezoekers', 'webwerckt-base' ) ),
		$rows,
		array(
			'open'  => 25,
			'cards' => true,
			'size'  => 'wide',
			'empty' => __( 'Nog geen routes gemeten in deze periode.', 'webwerckt-base' ),
		)
	);
	echo '<div class="ww-stats-blocks">' . $blocks . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_stats_block() en de cellen zijn geëscapet.

	// 2. Bezoeken.
	if ( $result['clipped'] ) {
		echo '<div class="notice notice-info inline"><p>' . esc_html__( 'Losse bezoeken worden 30 dagen bewaard. Oudere bezoeken zijn alleen als totalen te zien.', 'webwerckt-base' ) . '</p></div>';
	}

	$intro = _ww_stats_journey_form( $period, $filters, _ww_stats_journey_entries( $period['from'], $period['to'], $today, $lists['page'] ?? array() ) );
	if ( $result['capped'] ) {
		/* translators: %s: het maximale aantal bezoeken (1.000). */
		$intro .= '<p class="ww-stats-journey-count">' . esc_html( sprintf( __( 'Meer dan %s bezoeken.', 'webwerckt-base' ), number_format_i18n( $result['total'] ) ) ) . '</p>';
		$intro .= '<div class="notice notice-info inline"><p>' . esc_html__( 'Kies een kortere periode of een filter om oudere bezoeken te zien.', 'webwerckt-base' ) . '</p></div>';
	} elseif ( $result['total'] > 0 ) {
		/* translators: %s: aantal bezoeken. */
		$intro .= '<p class="ww-stats-journey-count">' . esc_html( sprintf( _n( '%s bezoek.', '%s bezoeken.', $result['total'], 'webwerckt-base' ), number_format_i18n( $result['total'] ) ) ) . '</p>';
	}

	$rows      = array();
	$templates = '';
	foreach ( $result['visits'] as $i => $visit ) {
		$rows[]     = _ww_stats_visit_row( $visit, $urls[ $i ], $i );
		$templates .= '<template id="ww-stats-visit-' . $i . '" data-title="' . esc_attr( _ww_stats_visit_title( $visit ) ) . '">' . _ww_stats_visit_detail( $visit ) . '</template>';
	}

	$outro = '';
	if ( $pages > 1 ) {
		$links = paginate_links(
			array(
				'base'      => add_query_arg( 'paged', '%#%', _ww_stats_tab_url( $period, 'journeys', $args ) ),
				'format'    => '',
				'current'   => $paged,
				'total'     => $pages,
				'prev_text' => __( '« Vorige', 'webwerckt-base' ),
				'next_text' => __( 'Volgende »', 'webwerckt-base' ),
			)
		);
		if ( '' !== $links ) {
			$outro = '<nav class="ww-stats-pagination" aria-label="' . esc_attr__( 'Pagina\'s met bezoeken', 'webwerckt-base' ) . '">' . wp_kses_post( $links ) . '</nav>';
		}
	}
	$outro .= '<p class="description">' . esc_html__( 'Een bezoek eindigt na 30 minuten zonder activiteit en om middernacht. Tijden zijn afgerond op de minuut. Bezoekers op hetzelfde netwerk met dezelfde browser kunnen samen als één bezoek tellen.', 'webwerckt-base' ) . '</p>';

	echo _ww_stats_block( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_stats_block() en de cellen zijn geëscapet.
		__( 'Bezoeken', 'webwerckt-base' ),
		array( __( 'Bezoek', 'webwerckt-base' ), __( 'Duur', 'webwerckt-base' ), __( 'Acties', 'webwerckt-base' ) ),
		$rows,
		array(
			'open'     => 50,
			'max'      => 50,
			'num_from' => 1,
			'intro'    => $intro,
			'empty'    => __( 'Geen bezoeken gevonden in deze periode.', 'webwerckt-base' ),
		)
	);
	echo $outro; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hierboven geëscapet.
	if ( array() !== $rows ) {
		echo $templates . _ww_stats_visit_dialog(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_stats_visit_detail() en _ww_stats_visit_dialog() escapen.
	}
}

/**
 * Toont één bezoek op zijn eigen URL (zonder JavaScript, of na een klik met Ctrl): een link terug naar de lijst, de
 * titel, het detail en, als het bezoek op de huidige pagina van de lijst staat, Vorig bezoek en Volgend bezoek. Staat
 * het er niet op (een andere periode of filter), dan wordt het opgezocht op zijn dag, zonder Vorig en Volgend.
 *
 * @param string                    $wanted Waarde van &visit=, niet vertrouwd.
 * @param list<array<string,mixed>> $visits De bezoeken van de huidige pagina (WWStatsVisit met day).
 * @param list<string>              $urls   Hun URL's, parallel aan $visits.
 * @param string                    $back   URL van de lijst.
 * @param string                    $today  Vandaag, Y-m-d.
 * @return bool Of het bezoek gevonden en getoond is.
 */
function _ww_stats_render_visit( string $wanted, array $visits, array $urls, string $back, string $today ): bool {
	$key = _ww_stats_parse_visit_key( $wanted );
	if ( null === $key ) {
		return false;
	}

	$index = null;
	foreach ( $visits as $i => $visit ) {
		if ( ( $visit['day'] ?? '' ) === $key['day'] && $visit['visitor'] === $key['visitor'] && (int) $visit['start'] === $key['start'] ) {
			$index = $i;
			break;
		}
	}
	if ( null !== $index ) {
		$found = $visits[ $index ];
	} else {
		// Alleen binnen de bewaarde 30 dagen (de dag ervoor telt mee, zoals in _ww_stats_journeys()).
		$first = ( new DateTimeImmutable( $today, wp_timezone() ) )->modify( '-30 days' )->format( 'Y-m-d' );
		if ( $key['day'] < $first || $key['day'] > $today ) {
			return false;
		}
		$found = null;
		foreach ( _ww_stats_visitor_visits( $key['day'], array( $key['visitor'] ) ) ?? array() as $visit ) {
			if ( (int) $visit['start'] === $key['start'] ) {
				$found        = $visit;
				$found['day'] = $key['day'];
				break;
			}
		}
		if ( null === $found ) {
			return false;
		}
	}

	echo '<p class="ww-stats-visit-back"><a href="' . esc_url( $back ) . '">' . esc_html__( '← Terug naar de bezoeken', 'webwerckt-base' ) . '</a></p>';
	echo '<section class="ww-stats-visit-page"><h2>' . esc_html( _ww_stats_visit_title( $found ) ) . '</h2>';
	echo _ww_stats_visit_detail( $found ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_stats_visit_detail() escapet.
	echo '</section>';
	if ( null !== $index && ( isset( $urls[ $index - 1 ] ) || isset( $urls[ $index + 1 ] ) ) ) {
		echo '<nav class="ww-stats-visit-nav" aria-label="' . esc_attr__( 'Andere bezoeken', 'webwerckt-base' ) . '">';
		if ( isset( $urls[ $index - 1 ] ) ) {
			echo '<a class="button" href="' . esc_url( $urls[ $index - 1 ] ) . '" rel="prev">' . esc_html__( '‹ Vorig bezoek', 'webwerckt-base' ) . '</a> ';
		}
		if ( isset( $urls[ $index + 1 ] ) ) {
			echo '<a class="button" href="' . esc_url( $urls[ $index + 1 ] ) . '" rel="next">' . esc_html__( 'Volgend bezoek ›', 'webwerckt-base' ) . '</a>';
		}
		echo '</nav>';
	}
	return true;
}
