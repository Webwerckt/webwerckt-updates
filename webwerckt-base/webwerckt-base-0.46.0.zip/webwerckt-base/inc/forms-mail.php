<?php
/**
 * Mails van formulieren (beslissing 0032): de melding aan de site-eigenaar en de bevestiging aan de inzender.
 *
 * Platte tekst via wp_mail(); het Van-adres zet dit bestand niet (dat doet de mail van het thema als ww_mail_from is
 * ingesteld, anders blijft dat van WordPress). De melding krijgt de bestanden van een inzending als bijlage (of, als ze
 * te groot zijn, een verwijzing naar de inzending) en altijd de link naar de inzending. Headers komen nooit rechtstreeks
 * uit de invoer: alleen Content-Type en een Reply-To met een adres dat is_email() doorstaat. In de bevestiging mag een
 * bot-ingevulde waarde alleen als korte, vaste of onschuldige tekst terugkomen (zie _ww_form_confirm_allowed()).
 *
 * De waarden ($values) hebben de vorm die de verwerking oplevert: veldsleutel => tekst; bij een vinkje '1' of '';
 * bij een keuzeveld met meerdere keuzes een lijst met tekst; bij een bestandsveld een lijst metadata (name, file, size, mime). Een ontbrekende sleutel telt als leeg.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Of de bevestiging alle tags mag gebruiken. Standaard alleen als de reCAPTCHA-controle van deze aanvraag geslaagd is
 * (pass); bij none, spam en off blijft de beperking. Het filter kan beide omdraaien.
 *
 * @param int $form_id Formulier-ID.
 */
function _ww_form_confirm_unrestricted( int $form_id ): bool {
	return (bool) apply_filters( 'ww_form_confirm_unrestricted', 'pass' === _ww_form_recaptcha_result(), $form_id );
}

/**
 * Platte tekst van een label: zonder HTML (het label van een vinkje mag een link bevatten) en zonder entiteiten.
 *
 * @param string $label Label uit de configuratie.
 */
function _ww_form_mail_plain( string $label ): string {
	return wp_specialchars_decode( wp_strip_all_tags( $label ), ENT_QUOTES );
}

/**
 * De oorspronkelijke bestandsnamen van een bestandsveld, gescheiden door ", ".
 *
 * @param mixed $files Lijst metadata van de verwerking.
 */
function _ww_form_file_names( $files ): string {
	$names = array();
	foreach ( is_array( $files ) ? $files : array() as $item ) {
		$name = is_array( $item ) ? _ww_form_string( $item['name'] ?? '' ) : '';
		if ( '' !== $name ) {
			$names[] = $name;
		}
	}
	return implode( ', ', $names );
}

/**
 * De tags van een mail: tag => waarde.
 *
 * Elk veld geeft {sleutel} met zijn leesbare waarde, daarnaast {alle_velden}, {formulier}, {site}, {datum} en {pagina}.
 * {alle_velden} heeft per veld een regel "Label: waarde"; bij een tekstvak begint de waarde op een nieuwe regel. Een
 * veld zonder waarde staat er wel in, met een lege waarde, zodat de ontvanger ziet dat het leeg bleef. Een bestandsveld
 * geeft als {sleutel} de namen en in {alle_velden} de namen met grootte; in de beperkte set komt het niet voor.
 *
 * Met $restricted (de bevestiging aan de inzender) blijven alleen de tags uit _ww_form_confirm_allowed() over. Een
 * 'short' veld wordt op 40 tekens afgekapt en is leeg als de waarde op een link of e-mailadres lijkt.
 *
 * @param int                 $form_id    Formulier-ID.
 * @param array<string,mixed> $config     Opgeschoonde configuratie.
 * @param array<string,mixed> $values     Waarden per veldsleutel.
 * @param string              $page_url   Pagina waarop is ingevuld.
 * @param bool                $restricted Alleen de tags die in de bevestiging mogen.
 * @return array<string,string>
 */
function _ww_form_mail_tags( int $form_id, array $config, array $values, string $page_url, bool $restricted ): array {
	$tags = array();
	$all  = array();

	foreach ( _ww_form_array( $config['fields'] ?? array() ) as $field ) {
		$display = _ww_form_display_value( $field, $values[ $field['key'] ] ?? '' );
		// Bij een bestandsveld is de tag alleen de namen; {alle_velden} laat er de grootte bij zien.
		$tags[ $field['key'] ] = 'file' === $field['type'] ? _ww_form_file_names( $values[ $field['key'] ] ?? array() ) : $display;

		$label = _ww_form_mail_plain( (string) $field['label'] );
		if ( 'text' === $field['type'] && '' !== $display ) {
			$all[] = $label . ":\n" . $display;
		} else {
			$all[] = $label . ': ' . $display;
		}
	}

	$tags['alle_velden'] = implode( "\n", $all );
	$tags['formulier']   = wp_specialchars_decode( (string) get_post_field( 'post_title', $form_id ), ENT_QUOTES );
	$tags['site']        = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	$tags['datum']       = wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) );
	$tags['pagina']      = $page_url;

	if ( ! $restricted ) {
		return $tags;
	}

	$limited = array();
	foreach ( _ww_form_confirm_allowed( $config ) as $tag => $mode ) {
		$value = $tags[ $tag ] ?? '';
		if ( 'short' === $mode ) {
			if ( false !== strpos( $value, '://' ) || false !== stripos( $value, 'www.' ) || false !== strpos( $value, '@' ) || preg_match( '/\w\.[a-z]{2,}/i', $value ) ) {
				$value = '';
			} else {
				$value = mb_substr( $value, 0, 40 );
			}
		}
		$limited[ $tag ] = $value;
	}
	return $limited;
}

/**
 * Vervangt {tags} in een tekst in één keer (een waarde die zelf op een tag lijkt, wordt niet nog eens vervangen). Een
 * onbekende tag wordt leeg. In een onderwerp gaan regeleindes en tabs eruit en blijft hoogstens 200 tekens over.
 *
 * @param string               $text    Tekst met tags.
 * @param array<string,string> $tags    Tag => waarde.
 * @param bool                 $subject Het is een onderwerp.
 */
function _ww_form_mail_replace( string $text, array $tags, bool $subject ): string {
	$text = (string) preg_replace_callback(
		'/\{([A-Za-z0-9_]+)\}/',
		static fn( array $m ): string => $tags[ $m[1] ] ?? '',
		$text
	);
	if ( $subject ) {
		$text = trim( (string) preg_replace( '/[\r\n\t]+/', ' ', $text ) );
		$text = mb_substr( $text, 0, 200 );
	}
	return $text;
}

/**
 * De tekst van een mail met de tags ingevuld. Blijft er niets over (leeg gelaten, of alleen tags die leeg blijven), dan
 * de standaardtekst: wp_mail() weigert een mail zonder tekst.
 *
 * @param string               $body    Tekst met tags.
 * @param string               $default Standaardtekst met tags.
 * @param array<string,string> $tags    Tag => waarde.
 */
function _ww_form_mail_body( string $body, string $default, array $tags ): string {
	$message = _ww_form_mail_replace( $body, $tags, false );
	return '' !== trim( $message ) ? $message : _ww_form_mail_replace( $default, $tags, false );
}

/**
 * De ontvangers van de melding: de adressen uit "to", anders het e-mailadres uit de Site-instellingen, anders het
 * beheerdersadres van WordPress.
 *
 * @param array<string,mixed> $config Opgeschoonde configuratie.
 * @return string[]
 */
function _ww_form_notify_recipients( array $config ): array {
	$notify = _ww_form_array( $config['mail']['notify'] ?? array() );
	$to     = array();
	foreach ( explode( ',', _ww_form_string( $notify['to'] ?? '' ) ) as $address ) {
		$address = trim( $address );
		if ( is_email( $address ) ) {
			$to[] = $address;
		}
	}
	if ( $to ) {
		return $to;
	}

	$site = trim( _ww_setting_string( 'email' ) );
	if ( is_email( $site ) ) {
		return array( $site );
	}
	return array( (string) get_option( 'admin_email' ) );
}

/**
 * De headers van een mail: platte tekst en, alleen met een geldig adres, Reply-To.
 *
 * @param string $reply_to Adres of leeg.
 * @return string[]
 */
function _ww_form_mail_headers( string $reply_to ): array {
	$headers  = array( 'Content-Type: text/plain; charset=UTF-8' );
	$reply_to = trim( $reply_to );
	if ( is_email( $reply_to ) ) {
		$headers[] = 'Reply-To: ' . $reply_to;
	}
	return $headers;
}

/**
 * Verstuurt één mail via wp_mail(), na het filter ww_form_mail.
 *
 * @param array<string,mixed> $mail    to, subject, message, headers, attachments.
 * @param string              $kind    notify of confirm.
 * @param array<string,mixed> $values  Waarden per veldsleutel.
 * @param int                 $form_id Formulier-ID.
 * @return string sent, failed of off.
 */
function _ww_form_mail_dispatch( array $mail, string $kind, array $values, int $form_id ): string {
	$filtered = apply_filters( 'ww_form_mail', $mail, $kind, $values, $form_id );
	if ( false === $filtered ) {
		return 'off';
	}
	if ( is_array( $filtered ) ) {
		// Een filter dat alleen een deel teruggeeft (bijvoorbeeld subject), houdt de rest van de mail.
		$mail = $filtered + $mail;
	}
	return wp_mail( $mail['to'], $mail['subject'], $mail['message'], $mail['headers'], _ww_form_array( $mail['attachments'] ?? array() ) ) ? 'sent' : 'failed';
}

/**
 * De grens voor bijlagen in bytes: de optie in MB, begrensd tot 0 - 25 (standaard 10).
 */
function _ww_form_attach_max_bytes(): int {
	$value = get_option( WW_FORMS_OPT_ATTACH_MAX, 10 );
	$value = is_numeric( $value ) ? (int) $value : 10;
	return min( 25, max( 0, $value ) ) * MB_IN_BYTES;
}

/**
 * De bijlagen van de melding: de bestanden van de inzending als oorspronkelijke naam => pad.
 *
 * Alleen als de bestanden samen niet groter zijn dan de grens (optie WW_FORMS_OPT_ATTACH_MAX, standaard 10, hoogstens
 * 25 MB) en die grens niet 0 is. Bij 0 gaat er nooit iets mee en blijft het bij de gewone link; zijn de bestanden te
 * groot, dan is too_large waar en krijgt het bericht de verwijzing naar de inzending. Een tweede bestand met dezelfde
 * naam krijgt -2 voor de extensie. Het pad wordt uit de map van de inzending opgebouwd; er worden geen kopieen gemaakt.
 *
 * @param int                 $form_id  Formulier-ID.
 * @param int                 $entry_id Inzending-ID.
 * @param array<string,mixed> $config   Opgeschoonde configuratie.
 * @param array<string,mixed> $values   Waarden per veldsleutel.
 * @return array{files: array<string,string>, too_large: bool}
 */
function _ww_form_mail_attachments( int $form_id, int $entry_id, array $config, array $values ): array {
	$none = array(
		'files'     => array(),
		'too_large' => false,
	);
	$dir  = $entry_id > 0 ? _ww_form_entry_dir( $form_id, $entry_id ) : '';
	if ( '' === $dir ) {
		return $none;
	}

	$found = array();
	$total = 0;
	foreach ( _ww_form_array( $config['fields'] ?? array() ) as $field ) {
		if ( 'file' !== $field['type'] || ! is_array( $values[ $field['key'] ] ?? null ) ) {
			continue;
		}
		foreach ( $values[ $field['key'] ] as $item ) {
			$name = is_array( $item ) ? _ww_form_string( $item['name'] ?? '' ) : '';
			$file = is_array( $item ) ? _ww_form_string( $item['file'] ?? '' ) : '';
			$path = $dir . '/' . $file;
			if ( '' === $name || ! preg_match( '/^[0-9a-f]{32}\.[a-z0-9]{2,5}$/', $file ) || ! is_file( $path ) ) {
				continue;
			}
			$found[] = array( $name, $path );
			$total  += (int) ( $item['size'] ?? 0 );
		}
	}
	if ( ! $found ) {
		return $none;
	}

	$max = _ww_form_attach_max_bytes();
	if ( 0 === $max ) {
		return $none;
	}
	if ( $total > $max ) {
		return array(
			'files'     => array(),
			'too_large' => true,
		);
	}

	$files = array();
	foreach ( $found as list( $name, $path ) ) {
		$key = $name;
		$n   = 2;
		while ( isset( $files[ $key ] ) ) {
			$dot = strrpos( $name, '.' );
			$key = false === $dot || 0 === $dot ? $name . '-' . $n : substr( $name, 0, $dot ) . '-' . $n . substr( $name, $dot );
			++$n;
		}
		$files[ $key ] = $path;
	}
	return array(
		'files'     => $files,
		'too_large' => false,
	);
}

/**
 * Verstuurt de melding en de bevestiging van een inzending.
 *
 * De bevestiging gaat alleen naar de waarde van to_field als die is_email() doorstaat, en gebruikt de beperkte tags
 * tenzij _ww_form_confirm_unrestricted(). Een leeg onderwerp of een lege tekst valt terug op de standaard van die mail.
 * Het filter ww_form_mail kan een mail aanpassen of met false uitzetten. Met een $entry_id staat onder de melding de link
 * naar de inzending en gaan de bestanden mee als bijlage (zie _ww_form_mail_attachments()); de bevestiging krijgt nooit
 * bijlagen of die link.
 *
 * @param int                 $form_id  Formulier-ID.
 * @param array<string,mixed> $config   Opgeschoonde configuratie.
 * @param array<string,mixed> $values   Waarden per veldsleutel.
 * @param string              $page_url Pagina waarop is ingevuld.
 * @param int                 $entry_id Opgeslagen inzending, 0 als er niet is opgeslagen.
 * @return array{notify: string, confirm: string} Per mail sent, failed of off.
 */
function _ww_form_send_mails( int $form_id, array $config, array $values, string $page_url, int $entry_id = 0 ): array {
	$result   = array(
		'notify'  => 'off',
		'confirm' => 'off',
	);
	$defaults = _ww_form_default_config()['mail'];
	$settings = _ww_form_array( $config['mail'] ?? array() );
	$notify   = _ww_form_array( $settings['notify'] ?? array() );
	$confirm  = _ww_form_array( $settings['confirm'] ?? array() );
	$to       = _ww_form_notify_recipients( $config );

	if ( ! empty( $notify['enabled'] ) ) {
		$tags     = _ww_form_mail_tags( $form_id, $config, $values, $page_url, false );
		$subject  = _ww_form_string( $notify['subject'] ?? '' );
		$reply_to = _ww_form_string( $notify['reply_to_field'] ?? '' );

		$message     = _ww_form_mail_body( _ww_form_string( $notify['body'] ?? '' ), $defaults['notify']['body'], $tags );
		$attachments = array();
		if ( $entry_id > 0 ) {
			$attached    = _ww_form_mail_attachments( $form_id, $entry_id, $config, $values );
			$attachments = $attached['files'];
			$link        = _ww_forms_entries_url( array( 'entry' => (string) $entry_id ) );
			if ( $attached['too_large'] ) {
				$message .= "\n\n" . __( 'De bestanden zijn te groot om mee te sturen. Je vindt ze bij de inzending:', 'webwerckt-base' ) . "\n" . $link;
			} else {
				/* translators: %s: link naar de inzending in het beheer. */
				$message .= "\n\n" . sprintf( __( 'Inzending bekijken: %s', 'webwerckt-base' ), $link );
			}
		}

		$result['notify'] = _ww_form_mail_dispatch(
			array(
				'to'          => $to,
				'subject'     => _ww_form_mail_replace( '' !== $subject ? $subject : $defaults['notify']['subject'], $tags, true ),
				'message'     => $message,
				'headers'     => _ww_form_mail_headers( '' !== $reply_to ? _ww_form_string( $values[ $reply_to ] ?? '' ) : '' ),
				'attachments' => $attachments,
			),
			'notify',
			$values,
			$form_id
		);
	}

	$address = trim( _ww_form_string( $values[ _ww_form_string( $confirm['to_field'] ?? '' ) ] ?? '' ) );
	if ( ! empty( $confirm['enabled'] ) && is_email( $address ) ) {
		$tags    = _ww_form_mail_tags( $form_id, $config, $values, $page_url, ! _ww_form_confirm_unrestricted( $form_id ) );
		$subject = _ww_form_string( $confirm['subject'] ?? '' );

		$result['confirm'] = _ww_form_mail_dispatch(
			array(
				'to'          => $address,
				'subject'     => _ww_form_mail_replace( '' !== $subject ? $subject : $defaults['confirm']['subject'], $tags, true ),
				'message'     => _ww_form_mail_body( _ww_form_string( $confirm['body'] ?? '' ), $defaults['confirm']['body'], $tags ),
				'headers'     => _ww_form_mail_headers( $to[0] ),
				'attachments' => array(),
			),
			'confirm',
			$values,
			$form_id
		);
	}

	return $result;
}
