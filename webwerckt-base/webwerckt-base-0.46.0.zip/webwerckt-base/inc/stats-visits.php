<?php
/**
 * Statistieken: bezoeken knippen uit de ruwe rijen (beslissing 0039).
 *
 * Een bezoek is dezelfde bezoeker op dezelfde dag, met hoogstens 1800 seconden tussen twee
 * opeenvolgende items (weergave of gebeurtenis). Er wordt alleen met de UTC-`ts` gerekend.
 *
 * @package webwerckt-base
 *
 * @phpstan-type WWStatsItem array{id:int, ts:int, type:string, path:string, kind:string, target:string, label:string, form_id:int, step:int, referrer:string, device:string, country:string, entry:int}
 * @phpstan-type WWStatsVisit array{visitor:string, start:int, end:int, items:list<WWStatsItem>, pages:int, entry_path:string, referrer:string, device:string, country:string, sent:bool, contact:bool, download:bool, day?:string}
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Zet de weergaven en gebeurtenissen van één bezoeker in één lijst.
 *
 * Op `ts`; binnen dezelfde minuut eerst de weergaven op `id`, en elke gebeurtenis direct na de
 * laatste weergave van hetzelfde pad in die minuut. Zonder zo'n weergave komt de gebeurtenis
 * vóór de weergaven van die minuut.
 *
 * @param list<WWStatsItem> $views  Weergaven van de bezoeker (type `view`).
 * @param list<WWStatsItem> $events Gebeurtenissen van de bezoeker.
 * @return list<WWStatsItem>
 */
function _ww_stats_order_items( array $views, array $events ): array {
	$by_view  = array();
	$by_event = array();
	foreach ( $views as $view ) {
		$by_view[ $view['ts'] ][] = $view;
	}
	foreach ( $events as $event ) {
		$by_event[ $event['ts'] ][] = $event;
	}

	$minutes = array_unique( array_merge( array_keys( $by_view ), array_keys( $by_event ) ) );
	sort( $minutes, SORT_NUMERIC );

	$by_id = static fn( array $a, array $b ): int => $a['id'] <=> $b['id'];

	$out = array();
	foreach ( $minutes as $minute ) {
		$v = $by_view[ $minute ] ?? array();
		$e = $by_event[ $minute ] ?? array();
		usort( $v, $by_id );
		usort( $e, $by_id );

		$last = array(); // Pad => index van de laatste weergave met dat pad.
		foreach ( $v as $i => $view ) {
			$last[ $view['path'] ] = $i;
		}

		foreach ( $e as $event ) {
			if ( ! isset( $last[ $event['path'] ] ) ) {
				$out[] = $event;
			}
		}
		foreach ( $v as $i => $view ) {
			$out[] = $view;
			if ( $last[ $view['path'] ] === $i ) {
				foreach ( $e as $event ) {
					if ( $event['path'] === $view['path'] ) {
						$out[] = $event;
					}
				}
			}
		}
	}
	return $out;
}

/**
 * Knipt de gesorteerde items van één bezoeker in bezoeken, bij een gat van meer dan 1800 seconden.
 *
 * @param string            $visitor Bezoeker.
 * @param list<WWStatsItem> $items   Items in volgorde (zie _ww_stats_order_items()).
 * @return list<WWStatsVisit>
 */
function _ww_stats_split_visits( string $visitor, array $items ): array {
	$groups = array();
	$cur    = array();
	$prev   = null;
	foreach ( $items as $item ) {
		if ( null !== $prev && $item['ts'] - $prev > 1800 ) {
			$groups[] = $cur;
			$cur      = array();
		}
		$cur[] = $item;
		$prev  = $item['ts'];
	}
	if ( $cur ) {
		$groups[] = $cur;
	}

	$visits = array();
	foreach ( $groups as $group ) {
		$visit = array(
			'visitor'    => $visitor,
			'start'      => $group[0]['ts'],
			'end'        => $group[ count( $group ) - 1 ]['ts'],
			'items'      => $group,
			'pages'      => 0,
			'entry_path' => '',
			'referrer'   => '',
			'device'     => '',
			'country'    => '',
			'sent'       => false,
			'contact'    => false,
			'download'   => false,
		);
		$first = true;
		foreach ( $group as $item ) {
			if ( 'view' === $item['type'] ) {
				++$visit['pages'];
				if ( $first ) {
					$first               = false;
					$visit['entry_path'] = $item['path'];
					$visit['referrer']   = $item['referrer'];
					$visit['device']     = $item['device'];
					$visit['country']    = $item['country'];
				}
			} elseif ( 'form' === $item['type'] && 'sent' === $item['kind'] ) {
				$visit['sent'] = true;
			} elseif ( 'click' === $item['type'] ) {
				if ( 'tel' === $item['kind'] || 'mailto' === $item['kind'] ) {
					$visit['contact'] = true;
				} elseif ( 'download' === $item['kind'] ) {
					$visit['download'] = true;
				}
			}
		}
		$visits[] = $visit;
	}
	return $visits;
}

/**
 * De kolommen die voor bezoeken gelezen worden.
 *
 * @param bool $details Of alle velden gelezen worden; anders alleen die het samenvatten nodig heeft.
 * @return array{hits:string, events:string} Vaste kolomlijsten voor de tabel met weergaven en die met gebeurtenissen.
 */
function _ww_stats_visit_columns( bool $details ): array {
	return array(
		'hits'   => $details ? 'id, ts, visitor, path, referrer, device, country, entry' : 'id, ts, visitor, path',
		'events' => $details ? 'id, ts, visitor, path, type, kind, target, label, form_id, step' : 'id, ts, visitor, path, type, kind',
	);
}

/**
 * Leest de weergaven en gebeurtenissen van één dag en knipt ze in bezoeken.
 *
 * Bezoeken staan gegroepeerd per bezoeker, gesorteerd op de bezoeker als tekst (SORT_STRING); binnen een bezoeker op
 * tijd. Leest de hele dag in één keer; het samenvatten en de lijst Bezoeken gebruiken _ww_stats_each_visit_batch().
 *
 * @param string $day     Dag (Y-m-d, in de tijdzone van de site).
 * @param bool   $details Of alle velden gelezen worden; anders alleen die het samenvatten nodig heeft.
 * @return list<WWStatsVisit>|null Null als een query faalde.
 */
function _ww_stats_day_visits( string $day, bool $details = true ): ?array {
	global $wpdb;

	$cols   = _ww_stats_visit_columns( $details );
	$hits   = _ww_stats_read( $wpdb->prepare( "SELECT {$cols['hits']} FROM " . _ww_stats_hits_table() . ' WHERE day = %s ORDER BY visitor, ts, id', $day ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- vaste kolomlijst.
	$events = _ww_stats_read( $wpdb->prepare( "SELECT {$cols['events']} FROM " . _ww_stats_events_table() . ' WHERE day = %s ORDER BY visitor, ts, id', $day ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- vaste kolomlijst.
	if ( null === $hits || null === $events ) {
		return null;
	}
	return _ww_stats_rows_to_visits( $hits, $events );
}

/**
 * Bezoeken van één dag in porties: telkens de volgende hoogstens $batch bezoekers (keyset op visitor), en dan alleen
 * hun weergaven en gebeurtenissen. Zo staat nooit de hele dag tegelijk in het geheugen.
 *
 * - Zonder $details (het samenvatten): alleen bezoekers met weergaven komen langs, met de minimale kolommen. Een bezoek
 *   zonder weergaven heeft geen flow en geen uitstap. Hun gebeurtenissen worden wel gelezen, want een klik kan een gat
 *   van meer dan 1800 seconden overbruggen.
 * - Met $details (de lijst Bezoeken): ook bezoekers met alleen gebeurtenissen (de keyset loopt over beide tabellen),
 *   met alle kolommen. Samen geven de porties dan dezelfde bezoeken als _ww_stats_day_visits( $day, true ).
 *
 * @param string                                $day     Dag (Y-m-d).
 * @param int                                   $batch   Hoeveel bezoekers per portie (minstens 1).
 * @param callable(list<WWStatsVisit>):void     $each    Krijgt de bezoeken van elke portie.
 * @param bool                                  $details Alle kolommen en ook bezoekers met alleen gebeurtenissen.
 * @return bool False als een query faalde.
 */
function _ww_stats_each_visit_batch( string $day, int $batch, callable $each, bool $details = false ): bool {
	global $wpdb;
	$hits   = _ww_stats_hits_table();
	$events = _ww_stats_events_table();
	$cols   = _ww_stats_visit_columns( $details );
	$batch  = max( 1, $batch );
	$after  = null;
	do {
		// Zonder ondergrens bij de eerste portie (ook een lege visitor telt dan mee), daarna na de laatste bezoeker.
		$from = null === $after ? '' : ' AND visitor > %s';
		$args = null === $after ? array( $day ) : array( $day, $after );
		if ( $details ) {
			$names = _ww_stats_read( $wpdb->prepare( "SELECT visitor FROM {$hits} WHERE day = %s{$from} UNION SELECT visitor FROM {$events} WHERE day = %s{$from} ORDER BY visitor LIMIT %d", ...array_merge( $args, $args, array( $batch ) ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnamen uit de helpers, $from is een vaste voorwaarde.
		} else {
			$names = _ww_stats_read( $wpdb->prepare( "SELECT DISTINCT visitor FROM {$hits} WHERE day = %s{$from} ORDER BY visitor LIMIT %d", ...array_merge( $args, array( $batch ) ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit de helper, $from is een vaste voorwaarde.
		}
		if ( null === $names ) {
			return false;
		}
		if ( array() === $names ) {
			break;
		}
		$last = (string) $names[ count( $names ) - 1 ]['visitor'];
		$rows = _ww_stats_read( $wpdb->prepare( "SELECT {$cols['hits']} FROM {$hits} WHERE day = %s{$from} AND visitor <= %s ORDER BY visitor, ts, id", ...array_merge( $args, array( $last ) ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam en kolommen uit de helpers, $from is een vaste voorwaarde.
		$more = _ww_stats_read( $wpdb->prepare( "SELECT {$cols['events']} FROM {$events} WHERE day = %s{$from} AND visitor <= %s ORDER BY visitor, ts, id", ...array_merge( $args, array( $last ) ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam en kolommen uit de helpers, $from is een vaste voorwaarde.
		if ( null === $rows || null === $more ) {
			return false;
		}
		$each( _ww_stats_rows_to_visits( $rows, $more ) );
		$after = $last;
	} while ( count( $names ) === $batch );
	return true;
}

/**
 * De filters van de lijst Bezoeken uit de query-string.
 *
 * `sent` en `contact` zijn alleen waar bij de tekst `'1'`. `entry` gaat door _ww_stats_path() en moet daarna een pad
 * zijn zoals de browser het stuurt (`location.pathname`: ASCII met procentcodering); anders, en bij een leeg of
 * ontbrekend pad, wordt het `''` (geen filter). Een waarde die geen tekst is (zoals `entry[]=`) geeft de standaard.
 *
 * @param array<array-key,mixed> $query Query-parameters, al ontdaan van slashes.
 * @return array{sent:bool, contact:bool, entry:string}
 */
function _ww_stats_journey_filters( array $query ): array {
	$entry = $query['entry'] ?? '';
	$path  = is_string( $entry ) && '' !== trim( $entry ) ? _ww_stats_path( $entry ) : null;
	if ( null !== $path && ! preg_match( '#^/[a-z0-9/._~%!$&\'()*+,;=:@-]*$#', $path ) ) {
		$path = null;
	}
	return array(
		'sent'    => '1' === ( $query['sent'] ?? null ),
		'contact' => '1' === ( $query['contact'] ?? null ),
		'entry'   => $path ?? '',
	);
}

/**
 * Leest de losse bezoeken voor de lijst Bezoeken: nieuwste eerst, gefilterd, 50 per pagina.
 *
 * - **Venster:** alleen dagen vanaf vandaag − 29 (de ruwe rijen blijven 30 dagen) en binnen `from`..`to`, tot en met
 *   vandaag. `clipped` is waar als `from` vóór vandaag − 29 ligt.
 * - **Volgorde:** dagen van nieuw naar oud; binnen een dag de nieuwste `start` eerst, bij gelijke `start` de bezoeker
 *   oplopend (strcmp).
 * - **Stoppen:** het totaal is pas bekend als alle dagen van het venster gelezen zijn. "Genoeg voor de pagina én het
 *   totaal bekend" komt dus neer op: alle dagen lezen, behalve als er meer dan 1.000 bezoeken door het filter kwamen.
 *   Dan stopt het na die dag, met `capped` en `total` 1000; er zijn dan hoogstens 20 pagina's. Precies 1.000 is nog
 *   geen grens: dan worden de oudere dagen ook gelezen, om te zien of er meer zijn. Een dag wordt altijd helemaal
 *   gelezen, want binnen een dag komen de bezoekers per bezoeker langs en niet op tijd.
 * - **Geheugen:** een dag wordt in porties van 100 bezoekers gelezen (_ww_stats_each_visit_batch() met details; een
 *   portie is begrensd in bezoekers, niet in rijen, en met alle kolommen weegt een rij meer). Van elk
 *   bezoek dat door het filter komt blijft alleen de kop over (zonder items), en alleen zoveel koppen als de pagina
 *   nodig heeft (hoogstens `page × 50`, en nooit meer dan 1.000); de rest wordt alleen geteld. Pas daarna worden de
 *   items gelezen van de hoogstens 50 bezoeken op de pagina: per dag de rijen van die bezoekers, opnieuw geknipt, en
 *   op bezoeker en `start` bij de kop gezocht.
 * - **Fouten:** een dag waarvan een query faalt telt niet mee; een bezoek dat bij het tweede lezen niet meer gevonden
 *   wordt (opgeruimd) valt weg.
 *
 * Er komen geen datumfuncties van SQL in de queries: de dagen worden in PHP berekend.
 *
 * @param string                                       $from    Eerste dag, Y-m-d.
 * @param string                                       $to      Laatste dag, Y-m-d.
 * @param array{sent:bool, contact:bool, entry:string} $filters Zie _ww_stats_journey_filters().
 * @param int                                          $page    Pagina, vanaf 1 (kleiner wordt 1).
 * @param string|null                                  $today   Vandaag (Y-m-d); standaard de datum van de site.
 * @return array{visits:list<WWStatsVisit>, total:int, capped:bool, clipped:bool}
 */
function _ww_stats_journeys( string $from, string $to, array $filters, int $page, ?string $today = null ): array {
	$per   = 50;
	$cap   = 1000;
	$page  = max( 1, $page );
	$today = $today ?? wp_date( 'Y-m-d' );
	$tz    = wp_timezone();
	$first = ( new DateTimeImmutable( $today, $tz ) )->modify( '-29 days' )->format( 'Y-m-d' );
	$start = $from > $first ? $from : $first;
	$end   = $to < $today ? $to : $today;
	$out   = array(
		'visits'  => array(),
		'total'   => 0,
		'capped'  => false,
		'clipped' => $from < $first,
	);
	if ( $start > $end ) {
		return $out;
	}
	$before = ( new DateTimeImmutable( $start, $tz ) )->modify( '-1 day' )->format( 'Y-m-d' );
	$days   = _ww_stats_raw_days( $before, $end ) ?? array();

	$keep  = min( $page * $per, $cap );
	$order = static fn( array $a, array $b ): int => ( $b['start'] <=> $a['start'] ) ?: strcmp( $a['visitor'], $b['visitor'] );
	$heads = array(); // Koppen in de volgorde van de lijst, met hun dag.
	foreach ( array_reverse( $days ) as $day ) {
		$need  = $keep - count( $heads );
		$found = array();
		$count = 0;
		$ok    = _ww_stats_each_visit_batch(
			$day,
			100,
			static function ( array $visits ) use ( &$found, &$count, $filters, $need, $order ): void {
				foreach ( $visits as $visit ) {
					if ( ( $filters['sent'] && ! $visit['sent'] )
						|| ( $filters['contact'] && ! $visit['contact'] )
						|| ( '' !== $filters['entry'] && $filters['entry'] !== $visit['entry_path'] ) ) {
						continue;
					}
					++$count;
					if ( $need > 0 ) {
						$visit['items'] = array();
						$found[]        = $visit;
					}
				}
				// Alleen de nieuwste $need koppen van de dag bewaren.
				if ( count( $found ) > $need ) {
					usort( $found, $order );
					$found = array_slice( $found, 0, $need );
				}
			},
			true
		);
		if ( ! $ok ) {
			continue;
		}
		usort( $found, $order );
		foreach ( $found as $visit ) {
			$heads[] = array(
				'day'   => $day,
				'visit' => $visit,
			);
		}
		$out['total'] += $count;
		if ( $out['total'] > $cap ) {
			$out['total']  = $cap;
			$out['capped'] = true;
			break;
		}
	}

	// De items van de bezoeken op deze pagina, per dag in één keer.
	$slice = array_slice( $heads, ( $page - 1 ) * $per, $per );
	$by    = array();
	foreach ( $slice as $head ) {
		$by[ $head['day'] ][ $head['visit']['visitor'] ] = true;
	}
	$full = array();
	foreach ( $by as $day => $visitors ) {
		$visits = _ww_stats_visitor_visits( (string) $day, array_map( 'strval', array_keys( $visitors ) ) );
		foreach ( $visits ?? array() as $visit ) {
			$visit['day'] = (string) $day; // Voor de sleutel van een bezoek (_ww_stats_visit_key()), ook bij ts 0.
			$full[ $day . '|' . $visit['visitor'] . '|' . $visit['start'] ] = $visit;
		}
	}
	foreach ( $slice as $head ) {
		$key = $head['day'] . '|' . $head['visit']['visitor'] . '|' . $head['visit']['start'];
		if ( isset( $full[ $key ] ) ) {
			$out['visits'][] = $full[ $key ];
		}
	}
	return $out;
}

/**
 * De bezoeken van enkele bezoekers op één dag, met alle velden.
 *
 * @param string       $day      Dag (Y-m-d).
 * @param list<string> $visitors Bezoekers (hoogstens een pagina vol).
 * @return list<WWStatsVisit>|null Null als een query faalde.
 */
function _ww_stats_visitor_visits( string $day, array $visitors ): ?array {
	global $wpdb;
	if ( array() === $visitors ) {
		return array();
	}
	$cols   = _ww_stats_visit_columns( true );
	$in     = implode( ', ', array_fill( 0, count( $visitors ), '%s' ) );
	$hits   = _ww_stats_read( $wpdb->prepare( "SELECT {$cols['hits']} FROM " . _ww_stats_hits_table() . " WHERE day = %s AND visitor IN ({$in}) ORDER BY visitor, ts, id", $day, ...$visitors ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- tabelnaam en kolommen uit de helpers, $in zijn alleen placeholders.
	$events = _ww_stats_read( $wpdb->prepare( "SELECT {$cols['events']} FROM " . _ww_stats_events_table() . " WHERE day = %s AND visitor IN ({$in}) ORDER BY visitor, ts, id", $day, ...$visitors ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- tabelnaam en kolommen uit de helpers, $in zijn alleen placeholders.
	if ( null === $hits || null === $events ) {
		return null;
	}
	return _ww_stats_rows_to_visits( $hits, $events );
}

/**
 * De keuzelijst van het filter `entry`: de top 50 paden van de periode.
 *
 * Uit de lijst `page` van _ww_stats_query(), zonder `(overige)`. Die lijst telt weergaven, geen binnenkomsten: er is
 * geen lijst met binnenkomstpagina's in de dagtabel. De volgorde is die van de meest bekeken pagina's.
 *
 * Heeft de aanroeper de lijst `page` van dezelfde periode al gelezen, dan geeft hij die mee: _ww_stats_query() vat de
 * ruwe rijen van vandaag live samen, en dat hoeft per verzoek maar één keer.
 *
 * @param string                                               $from  Eerste dag, Y-m-d.
 * @param string                                               $to    Laatste dag, Y-m-d.
 * @param string|null                                          $today Vandaag (Y-m-d); standaard de datum van de site.
 * @param list<array{item:string,views:int,visitors:int}>|null $pages De lijst `page` van _ww_stats_query() voor deze
 *                                                                    periode; null leest hem zelf.
 * @return list<string>
 */
function _ww_stats_journey_entries( string $from, string $to, ?string $today = null, ?array $pages = null ): array {
	$paths = array();
	foreach ( $pages ?? _ww_stats_query( $from, $to, $today )['lists']['page'] ?? array() as $row ) {
		if ( '(overige)' === $row['item'] ) {
			continue;
		}
		$paths[] = $row['item'];
		if ( 50 === count( $paths ) ) {
			break;
		}
	}
	return $paths;
}

/**
 * Zet gelezen weergaven en gebeurtenissen om naar bezoeken: per bezoeker (gesorteerd als tekst) in volgorde gezet en
 * geknipt. Ontbrekende kolommen worden leeg of 0.
 *
 * @param list<array<string,mixed>> $hits   Rijen uit de tabel met weergaven.
 * @param list<array<string,mixed>> $events Rijen uit de tabel met gebeurtenissen.
 * @return list<WWStatsVisit>
 */
function _ww_stats_rows_to_visits( array $hits, array $events ): array {
	$views_by  = array();
	$events_by = array();
	$visitors  = array();
	foreach ( $hits as $row ) {
		$visitor                = (string) $row['visitor'];
		$visitors[ $visitor ]   = true;
		$views_by[ $visitor ][] = array(
			'id'       => (int) $row['id'],
			'ts'       => (int) $row['ts'],
			'type'     => 'view',
			'path'     => (string) $row['path'],
			'kind'     => '',
			'target'   => '',
			'label'    => '',
			'form_id'  => 0,
			'step'     => 0,
			'referrer' => (string) ( $row['referrer'] ?? '' ),
			'device'   => (string) ( $row['device'] ?? '' ),
			'country'  => (string) ( $row['country'] ?? '' ),
			'entry'    => (int) ( $row['entry'] ?? 0 ),
		);
	}
	foreach ( $events as $row ) {
		$visitor                 = (string) $row['visitor'];
		$visitors[ $visitor ]    = true;
		$events_by[ $visitor ][] = array(
			'id'       => (int) $row['id'],
			'ts'       => (int) $row['ts'],
			'type'     => (string) $row['type'],
			'path'     => (string) $row['path'],
			'kind'     => (string) $row['kind'],
			'target'   => (string) ( $row['target'] ?? '' ),
			'label'    => (string) ( $row['label'] ?? '' ),
			'form_id'  => (int) ( $row['form_id'] ?? 0 ),
			'step'     => (int) ( $row['step'] ?? 0 ),
			'referrer' => '',
			'device'   => '',
			'country'  => '',
			'entry'    => 0,
		);
	}

	$names = array_map( 'strval', array_keys( $visitors ) );
	sort( $names, SORT_STRING );

	$visits = array();
	foreach ( $names as $visitor ) {
		$items = _ww_stats_order_items( $views_by[ $visitor ] ?? array(), $events_by[ $visitor ] ?? array() );
		foreach ( _ww_stats_split_visits( $visitor, $items ) as $visit ) {
			$visits[] = $visit;
		}
	}
	return $visits;
}
