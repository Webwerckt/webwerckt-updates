<?php
/**
 * De termvelden van een taxonomie-pod (pods/*.json met type taxonomy), zonder Pods: op de schermen Nieuwe term
 * (edit-tags.php) en Term bewerken (term.php), getekend door de tekenlaag van de Site-instellingen
 * (inc/settings-fields-render.php) en opgeslagen als term meta via de opslaglaag (_ww_fields_save_term()), byte voor
 * byte zoals Pods.
 *
 * Zoals het bewerkscherm (inc/field-metaboxes.php):
 * - Opslaan alleen vanuit het formulier, met de nonce ww_term_fields_new_{taxonomie} (Nieuwe term) of
 *   ww_term_fields_{term_id} (Term bewerken) en het recht edit_term. Snel bewerken, REST en wp_update_term() sturen
 *   die nonce niet mee en raken de velden dus niet.
 * - Alleen de velden die op het scherm stonden (ww_fields_shown[]); een afgeschermd veld of een soort zonder invoer
 *   staat er nooit bij.
 * - Een veld dat de gebruiker niet wijzigde, blijft ongemoeid (_ww_field_box_unchanged()). Een nieuwe term krijgt
 *   alleen een rij voor een veld dat is ingevuld of een getoonde default_value heeft.
 * - Een relatie met een term of bericht dat weg is, verliest dat ID zonder fout.
 * - Een leeg verplicht veld of een geweigerde waarde wordt niet opgeslagen en gemeld op Term bewerken.
 *
 * Nieuwe term wordt met AJAX verstuurd: een opgemaakte tekst (wysiwyg) bewaart daar niet betrouwbaar; vul die op Term
 * bewerken in.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registreert de haken van de schermen per taxonomie met termvelden. Op admin_init: de taxonomieën zijn dan
 * geregistreerd, en het opslaan via admin-ajax.php (Nieuwe term) en edit-tags.php (Term bewerken) loopt ook langs hier.
 */
function _ww_term_fields_hooks(): void {
	foreach ( _ww_pods_taxonomies() as $taxonomy ) {
		add_action( $taxonomy . '_add_form_fields', '_ww_term_fields_add_form' );
		add_action( $taxonomy . '_edit_form_fields', '_ww_term_fields_edit_form', 10, 2 );
		add_action( 'created_' . $taxonomy, '_ww_term_fields_created' );
		add_action( 'edited_' . $taxonomy, '_ww_term_fields_edited' );
	}
}
add_action( 'admin_init', '_ww_term_fields_hooks' );

/**
 * De termvelden van een taxonomie die de gebruiker mag zien, op naam. Elk veld krijgt ww_term (de veldlaag van de
 * abilities en Visueel bewerken kent geen termvelden; zie _ww_settings_render_field()).
 *
 * @return array<string,array<string,mixed>>
 */
function _ww_term_fields( string $taxonomy ): array {
	$fields = array();
	foreach ( _ww_pods_taxonomy_fields( $taxonomy ) as $field ) {
		$name = _ww_data_to_string( $field['name'] ?? '' );
		if ( '' !== $name && ! _ww_field_restricted( $field ) ) {
			$fields[ $name ] = array( 'ww_term' => true ) + $field;
		}
	}
	return $fields;
}

/*
 * Tekenen.
 */

/**
 * De verborgen velden van het formulier: de nonce en per veld met invoer een ww_fields_shown[].
 *
 * @param array<string,array<string,mixed>> $fields Velden op naam.
 */
function _ww_term_fields_hidden( array $fields, string $action ): string {
	$html = '<input type="hidden" name="ww_term_fields_nonce" value="' . esc_attr( wp_create_nonce( $action ) ) . '">';
	foreach ( $fields as $name => $field ) {
		if ( _ww_settings_field_supported( $field ) ) {
			$html .= '<input type="hidden" name="ww_fields_shown[]" value="' . esc_attr( (string) $name ) . '">';
		}
	}
	return $html;
}

/**
 * Tekent de velden op Nieuwe term ({taxonomie}_add_form_fields): per veld een div.form-field met label, invoer en
 * omschrijving, zoals de velden van WordPress daar. Een getoonde default_value gaat bij het toevoegen de database in.
 *
 * @param string $taxonomy Taxonomie.
 */
function _ww_term_fields_add_form( $taxonomy ): void {
	$fields = _ww_term_fields( (string) $taxonomy );
	if ( array() === $fields ) {
		return;
	}
	$html = '';
	foreach ( $fields as $name => $field ) {
		$label = _ww_data_to_string( $field['label'] ?? $name );
		$html .= '<div class="form-field ww-term-field term-' . esc_attr( sanitize_html_class( (string) $name ) ) . '-wrap" data-field="' . esc_attr( (string) $name ) . '">'
			. _ww_settings_field_label( $field, $label )
			. _ww_settings_render_field( $field, $field['default_value'] ?? null );
		$description = _ww_data_to_string( $field['description'] ?? '' );
		if ( '' !== $description ) {
			$html .= '<p class="description">' . esc_html( $description ) . '</p>';
		}
		$html .= '</div>';
	}
	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- de tekenlaag escapet elk veld zelf.
	echo '<div class="ww-term-fields">' . $html . _ww_term_fields_hidden( $fields, 'ww_term_fields_new_' . $taxonomy ) . '</div>';
}

/**
 * Tekent de velden op Term bewerken ({taxonomie}_edit_form_fields): een rij per veld in de tabel van het formulier,
 * met de opgeslagen term meta.
 *
 * @param mixed  $term     De term.
 * @param string $taxonomy Taxonomie.
 */
function _ww_term_fields_edit_form( $term, $taxonomy = '' ): void {
	if ( ! $term instanceof WP_Term ) {
		return;
	}
	$fields = _ww_term_fields( $term->taxonomy );
	if ( array() === $fields ) {
		return;
	}
	$rows = '';
	foreach ( $fields as $field ) {
		$row  = _ww_settings_render_row( $field, _ww_field_box_value( $term->term_id, $field, false, 'term' ), array() );
		$rows .= (string) preg_replace( '/^<tr class="ww-settings-row"/', '<tr class="form-field ww-settings-row"', $row );
	}
	// Verborgen velden in een eigen (verborgen) rij: een input los in een tabel schuift de browser eruit.
	$hidden = '<tr class="ww-term-fields-hidden" hidden><td colspan="2">' . _ww_term_fields_hidden( $fields, 'ww_term_fields_' . $term->term_id ) . '</td></tr>';
	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- de tekenlaag escapet elke rij zelf.
	echo $rows . $hidden;
}

/**
 * Laadt het script en de stijl van de invoer op Nieuwe term en Term bewerken van een taxonomie met termvelden, en
 * start het script op het formulier (#addtag of #edittag).
 *
 * @param string $hook Het scherm (edit-tags.php, term.php, ...).
 */
function _ww_term_fields_assets( $hook ): void {
	if ( ! in_array( $hook, array( 'edit-tags.php', 'term.php' ), true ) ) {
		return;
	}
	$screen = get_current_screen();
	$fields = $screen instanceof WP_Screen && '' !== $screen->taxonomy ? _ww_term_fields( $screen->taxonomy ) : array();
	if ( array() === $fields ) {
		return;
	}
	_ww_field_inputs_enqueue( $fields );
	$form = 'term.php' === $hook ? 'edittag' : 'addtag';
	wp_add_inline_script( 'ww-field-inputs', "window.wwFieldInputs && document.getElementById( '" . $form . "' ) && window.wwFieldInputs.init( document.getElementById( '" . $form . "' ), { texts: window.wwFieldInputsTexts || {} } );" );
}
add_action( 'admin_enqueue_scripts', '_ww_term_fields_assets' );

/*
 * Opslaan.
 */

/**
 * Na Nieuwe term (created_{taxonomie}).
 *
 * @param int|string $term_id Term.
 */
function _ww_term_fields_created( $term_id ): void {
	_ww_term_fields_save( (int) $term_id, true );
}

/**
 * Na Term bewerken (edited_{taxonomie}).
 *
 * @param int|string $term_id Term.
 */
function _ww_term_fields_edited( $term_id ): void {
	_ww_term_fields_save( (int) $term_id, false );
}

/**
 * De sleutel van de melding na het opslaan, per term en gebruiker: ww_fields_{soort}_term{term_id}_{user_id}.
 *
 * @param string $kind required (lege verplichte velden) of invalid (geweigerde waarden).
 */
function _ww_term_fields_notice_key( string $kind, int $term_id ): string {
	return 'ww_fields_' . $kind . '_term' . $term_id . '_' . get_current_user_id();
}

/**
 * Slaat de termvelden van het formulier op. Alleen met de nonce van dat formulier en het recht edit_term. Per veld
 * dat op het scherm stond, zoals het bewerkscherm: ongewijzigd blijft ongemoeid; leeg en verplicht wordt overgeslagen
 * en gemeld; een geweigerde waarde ook; de rest gaat in één keer naar _ww_fields_save_term().
 *
 * @param bool $new Nieuwe term (anders Term bewerken).
 */
function _ww_term_fields_save( int $term_id, bool $new ): void {
	static $saving = array();

	$term = get_term( $term_id );
	if ( ! $term instanceof WP_Term || isset( $saving[ $term_id ] ) ) {
		return;
	}
	// phpcs:disable WordPress.Security.NonceVerification.Missing -- de nonce wordt hier gecontroleerd.
	$nonce  = isset( $_POST['ww_term_fields_nonce'] ) && is_string( $_POST['ww_term_fields_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['ww_term_fields_nonce'] ) ) : '';
	$action = $new ? 'ww_term_fields_new_' . $term->taxonomy : 'ww_term_fields_' . $term_id;
	if ( '' === $nonce || ! wp_verify_nonce( $nonce, $action ) || ! current_user_can( 'edit_term', $term_id ) ) {
		return;
	}

	$shown   = isset( $_POST['ww_fields_shown'] ) && is_array( $_POST['ww_fields_shown'] ) ? array_map( 'sanitize_text_field', array_map( '_ww_data_to_string', wp_unslash( $_POST['ww_fields_shown'] ) ) ) : array();
	$allowed = array();
	foreach ( _ww_term_fields( $term->taxonomy ) as $name => $field ) {
		if ( in_array( $name, $shown, true ) && _ww_settings_field_supported( $field ) ) {
			$allowed[ $name ] = $field;
		}
	}
	// Elke waarde gaat hieronder door _ww_settings_post_values() (wp_unslash) en _ww_fields_input_value() (controle).
	$posted = isset( $_POST['ww_fields'] ) && is_array( $_POST['ww_fields'] ) ? $_POST['ww_fields'] : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
	// phpcs:enable WordPress.Security.NonceVerification.Missing
	$values = _ww_settings_post_values( $allowed, array_intersect_key( $posted, $allowed ) );

	$data     = array();
	$required = array();
	$invalid  = array();
	foreach ( $allowed as $name => $field ) {
		if ( ! array_key_exists( $name, $values ) ) {
			continue;
		}
		$label  = _ww_data_to_string( $field['label'] ?? $name );
		$value  = _ww_fields_drop_gone( $field, $values[ $name ] );
		$stored = metadata_exists( 'term', $term_id, $name );
		if ( ( $stored || ! $new || ! isset( $field['default_value'] ) ) && _ww_field_box_unchanged( $field, _ww_field_box_value( $term_id, $field, $new, 'term' ), $value ) ) {
			continue;
		}
		$clean = _ww_fields_input_value( $field, $value );
		if ( ! is_wp_error( $clean ) && _ww_field_is_required( $field ) && in_array( $clean, array( '', null, array() ), true ) ) {
			$required[] = $label;
			continue;
		}
		if ( is_wp_error( $clean ) ) {
			$invalid[] = $label . ': ' . $clean->get_error_message();
			continue;
		}
		$data[ $name ] = $clean;
	}

	if ( array() !== $data ) {
		$saving[ $term_id ] = true;
		$error              = _ww_fields_save_term( $term->taxonomy, $term_id, $data );
		unset( $saving[ $term_id ] );
		if ( $error instanceof WP_Error ) {
			$invalid[] = $error->get_error_message();
		}
	}

	foreach ( array(
		'required' => $required,
		'invalid'  => $invalid,
	) as $kind => $list ) {
		$key = _ww_term_fields_notice_key( $kind, $term_id );
		if ( array() !== $list ) {
			set_transient( $key, $list, 10 * MINUTE_IN_SECONDS );
		} else {
			delete_transient( $key );
		}
	}
}

/**
 * Toont op Term bewerken één keer de lege verplichte velden en de geweigerde waarden van de laatste opslag.
 */
function _ww_term_fields_notice(): void {
	$screen  = get_current_screen();
	$term_id = isset( $_GET['tag_ID'] ) ? absint( _ww_data_to_string( wp_unslash( $_GET['tag_ID'] ) ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen lezen welke term het scherm toont.
	if ( ! $screen instanceof WP_Screen || 'term' !== $screen->base || $term_id <= 0 ) {
		return;
	}
	$messages = array(
		/* translators: %s: labels van de lege verplichte velden, gescheiden door komma's. */
		'required' => __( 'Deze verplichte velden zijn leeg en niet opgeslagen: %s. De rest is opgeslagen.', 'webwerckt-base' ),
		/* translators: %s: de velden met hun foutmelding. */
		'invalid'  => __( 'Deze velden zijn niet opgeslagen: %s', 'webwerckt-base' ),
	);
	foreach ( $messages as $kind => $message ) {
		$key  = _ww_term_fields_notice_key( $kind, $term_id );
		$list = get_transient( $key );
		if ( ! is_array( $list ) ) {
			continue;
		}
		delete_transient( $key );
		$list = array_filter( array_map( '_ww_data_to_string', $list ) );
		if ( array() !== $list ) {
			echo '<div class="notice notice-warning is-dismissible"><p>' . esc_html( sprintf( $message, implode( 'required' === $kind ? ', ' : ' ', $list ) ) ) . '</p></div>';
		}
	}
}
add_action( 'admin_notices', '_ww_term_fields_notice' );
