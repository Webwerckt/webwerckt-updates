<?php
/**
 * Meertalig formulieren (beslissing 0043): een formulier per taal in een vertaalgroep, zoals elk vertaalbaar bericht.
 *
 * Met Meertalig actief is ww_form vertaalbaar (_ww_translatable_post_types()). Een pagina toont het formulier in haar
 * taal als dat gepubliceerd is, anders het formulier zelf (_ww_form_translation_resolve(), vanuit _ww_form_resolve()).
 * De inzendingen van een formulier tonen in het beheer de hele groep (_ww_form_group_ids()), en de builder meldt
 * veldsleutels die anders zijn dan in het formulier in de standaardtaal (_ww_form_field_diff()). Zonder Meertalig doet
 * niets hier iets: dan is een formulier gewoon zichzelf.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Het formulier om te tonen in de taal van het verzoek: met Meertalig actief de gepubliceerde vertaling in die taal
 * (ww_translation_id()), anders het formulier zelf.
 *
 * Ligt het formulier in de prullenbak, dan heeft de kern het uit zijn groep gehaald en de oude groep bewaard in
 * _ww_translations_trashed (_ww_languages_on_remove()). Daaruit komt dan de vertaling in de taal van het verzoek, als
 * dat nog een gepubliceerd formulier in die taal is. Zo toont een Engelse pagina het Engelse formulier nog; de
 * Nederlandse pagina toont niets, want de bron zelf is niet gepubliceerd.
 *
 * @param int $id Formulier.
 */
function _ww_form_translation_resolve( int $id ): int {
	if ( ! _ww_languages_active() || $id <= 0 ) {
		return $id;
	}
	$lang   = ww_current_language();
	$target = ww_translation_id( $id, $lang );

	if ( 0 === $target && 'trash' === get_post_status( $id ) && $lang !== _ww_default_language() && in_array( $lang, _ww_routable_language_codes(), true ) ) {
		$saved     = get_post_meta( $id, '_ww_translations_trashed', true );
		$candidate = is_array( $saved ) ? absint( $saved[ $lang ] ?? 0 ) : 0;
		if ( $candidate > 0 && $candidate !== $id && _ww_post_language( $candidate ) === $lang ) {
			$target = $candidate;
		}
	}

	return $target > 0 && WW_FORM_POST_TYPE === get_post_type( $target ) && 'publish' === get_post_status( $target ) ? $target : $id;
}

/**
 * De formulieren in de vertaalgroep van dit formulier die de gebruiker mag bewerken (edit_post), met het formulier
 * zelf altijd voorop. Zonder Meertalig alleen het formulier zelf.
 *
 * @param int $form_id Formulier.
 * @return int[]
 */
function _ww_form_group_ids( int $form_id ): array {
	$ids = array( $form_id );
	if ( ! _ww_languages_active() || $form_id <= 0 ) {
		return $ids;
	}
	foreach ( _ww_translations( $form_id ) as $id ) {
		if ( $id !== $form_id && WW_FORM_POST_TYPE === get_post_type( $id ) && current_user_can( 'edit_post', $id ) ) {
			$ids[] = $id;
		}
	}
	return $ids;
}

/**
 * De veldsleutels die anders zijn dan in het formulier in de standaardtaal van de groep: missing (staan daar wel, hier
 * niet) en extra (staan hier wel, daar niet), in de volgorde van de formulieren. Null zonder Meertalig, voor het
 * formulier in de standaardtaal zelf, zonder formulier in de standaardtaal in de groep, en zonder verschil.
 *
 * @param int $form_id Formulier.
 * @return array{lang:string,missing:string[],extra:string[]}|null
 */
function _ww_form_field_diff( int $form_id ): ?array {
	if ( ! _ww_languages_active() || WW_FORM_POST_TYPE !== get_post_type( $form_id ) ) {
		return null;
	}
	$default = _ww_default_language();
	if ( _ww_post_language( $form_id ) === $default ) {
		return null;
	}
	$source = _ww_translations( $form_id )[ $default ] ?? 0;
	$theirs = $source > 0 ? _ww_form_config( $source ) : null;
	$ours   = _ww_form_config( $form_id );
	if ( null === $theirs || null === $ours ) {
		return null;
	}

	$their_keys = array_map( '_ww_data_to_string', array_column( (array) $theirs['fields'], 'key' ) );
	$our_keys   = array_map( '_ww_data_to_string', array_column( (array) $ours['fields'], 'key' ) );
	$missing    = array_values( array_diff( $their_keys, $our_keys ) );
	$extra      = array_values( array_diff( $our_keys, $their_keys ) );
	if ( array() === $missing && array() === $extra ) {
		return null;
	}
	return array(
		'lang'    => $default,
		'missing' => $missing,
		'extra'   => $extra,
	);
}

/**
 * De melding boven de builder als de velden anders zijn dan in het formulier in de standaardtaal, of ''. Alleen
 * informatie: niets wordt gelijkgetrokken en opslaan wordt niet geweigerd.
 *
 * @param int $form_id Formulier.
 */
function _ww_form_field_diff_notice( int $form_id ): string {
	$diff = _ww_form_field_diff( $form_id );
	if ( null === $diff ) {
		return '';
	}
	$language = _ww_language( $diff['lang'] );
	$name     = null !== $language ? $language['name'] : $diff['lang'];
	$missing  = implode( ', ', $diff['missing'] );
	$extra    = implode( ', ', $diff['extra'] );

	if ( '' === $extra ) {
		/* translators: 1: naam van de standaardtaal, 2: veldsleutels. */
		$text = sprintf( __( 'Velden anders dan in het %1$s: %2$s ontbreken.', 'webwerckt-base' ), $name, $missing );
	} elseif ( '' === $missing ) {
		/* translators: 1: naam van de standaardtaal, 3: veldsleutels. */
		$text = sprintf( __( 'Velden anders dan in het %1$s: %3$s extra.', 'webwerckt-base' ), $name, $missing, $extra );
	} else {
		/* translators: 1: naam van de standaardtaal, 2: ontbrekende veldsleutels, 3: extra veldsleutels. */
		$text = sprintf( __( 'Velden anders dan in het %1$s: %2$s ontbreken, %3$s extra.', 'webwerckt-base' ), $name, $missing, $extra );
	}
	return '<div class="notice notice-info inline"><p>' . esc_html( $text ) . '</p></div>';
}
