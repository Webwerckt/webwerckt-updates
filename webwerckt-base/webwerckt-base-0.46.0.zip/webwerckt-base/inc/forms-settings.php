<?php
/**
 * Formulieren › Instellingen (beslissing 0032): de reCAPTCHA-sleutels, de scoregrens en de grens voor bijlagen in de
 * melding, alleen voor beheerders. De opties staan zonder autoload; de geheime sleutel komt nooit in de HTML.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const WW_FORMS_SETTINGS_SCREEN = 'ww-form-settings';
const WW_FORMS_SETTINGS_GROUP  = 'ww_forms_settings';

/**
 * Registreert Instellingen onder Formulieren, alleen voor beheerders. Het zijpaneel haalt het weer uit het submenu
 * (inc/forms-panel.php); de pagina blijft bereikbaar.
 */
function _ww_forms_settings_menu(): void {
	add_submenu_page(
		'edit.php?post_type=' . WW_FORM_POST_TYPE,
		__( 'Instellingen', 'webwerckt-base' ),
		__( 'Instellingen', 'webwerckt-base' ),
		'manage_options',
		WW_FORMS_SETTINGS_SCREEN,
		'_ww_forms_settings_render'
	);
}
add_action( 'admin_menu', '_ww_forms_settings_menu' );

/**
 * URL van het scherm Instellingen.
 *
 * @param array<string,string> $args Extra queryvariabelen.
 */
function _ww_forms_settings_url( array $args = array() ): string {
	return add_query_arg(
		array(
			'post_type' => WW_FORM_POST_TYPE,
			'page'      => WW_FORMS_SETTINGS_SCREEN,
		) + $args,
		admin_url( 'edit.php' )
	);
}

/**
 * Een sleutel van Google: `a-zA-Z0-9_-`, hoogstens 100 tekens.
 *
 * @param mixed $value Ingevoerde waarde.
 */
function _ww_forms_sanitize_key( mixed $value ): string {
	if ( ! is_scalar( $value ) ) {
		return '';
	}
	return substr( (string) preg_replace( '/[^a-zA-Z0-9_-]/', '', (string) $value ), 0, 100 );
}

/**
 * De geheime sleutel: een leeg veld laat de bestaande staan, tenzij het vinkje om te wissen aan staat.
 *
 * @param mixed $value Ingevoerde waarde.
 */
function _ww_forms_sanitize_secret( mixed $value ): string {
	// phpcs:ignore WordPress.Security.NonceVerification.Missing -- options.php controleert de nonce van de Settings API.
	if ( ! empty( $_POST['ww_forms_recaptcha_secret_clear'] ) ) {
		return '';
	}
	$new = _ww_forms_sanitize_key( $value );
	return '' !== $new ? $new : _ww_form_recaptcha_secret();
}

/**
 * De scoregrens: afgerond op 0,1 en begrensd tot 0,1 - 0,9 (onleesbaar geeft 0,5).
 *
 * @param mixed $value Ingevoerde waarde.
 */
function _ww_forms_sanitize_threshold( mixed $value ): float {
	if ( is_string( $value ) ) {
		$value = str_replace( ',', '.', trim( $value ) );
	}
	if ( ! is_numeric( $value ) ) {
		return 0.5;
	}
	return round( min( 0.9, max( 0.1, round( (float) $value, 1 ) ) ), 1 );
}

/**
 * De grens voor bijlagen in MB: 0 - 25 (onleesbaar geeft 10).
 *
 * @param mixed $value Ingevoerde waarde.
 */
function _ww_forms_sanitize_attach_max( mixed $value ): int {
	if ( ! is_numeric( $value ) ) {
		return 10;
	}
	return min( 25, max( 0, (int) round( (float) $value ) ) );
}

/**
 * Registreert de opties. Ze worden eerst zonder autoload aangemaakt (update_option laat autoload daarna met rust).
 */
function _ww_forms_settings_register(): void {
	$options = array(
		WW_FORMS_OPT_SITE_KEY   => array( 'string', '_ww_forms_sanitize_key' ),
		WW_FORMS_OPT_SECRET     => array( 'string', '_ww_forms_sanitize_secret' ),
		WW_FORMS_OPT_THRESHOLD  => array( 'number', '_ww_forms_sanitize_threshold' ),
		WW_FORMS_OPT_ATTACH_MAX => array( 'integer', '_ww_forms_sanitize_attach_max' ),
	);
	// Eerst aanmaken, vóór de sanitizers erop hangen: anders maakt add_option van een lege waarde 0,1 van de scoregrens.
	foreach ( array_keys( $options ) as $name ) {
		if ( false === get_option( $name ) ) {
			add_option( $name, '', '', false );
		}
	}
	foreach ( $options as $name => $setting ) {
		register_setting(
			WW_FORMS_SETTINGS_GROUP,
			$name,
			array(
				'type'              => $setting[0],
				'sanitize_callback' => $setting[1],
				'show_in_rest'      => false,
			)
		);
	}
}
add_action( 'admin_init', '_ww_forms_settings_register' );

/**
 * De sitesleutel staat in de gecachte HTML en de geheime sleutel bepaalt of reCAPTCHA aan staat: cache legen.
 */
function _ww_forms_settings_flush_cache(): void {
	if ( function_exists( '_ww_page_cache_flush' ) ) {
		_ww_page_cache_flush();
	}
}
add_action( 'update_option_' . WW_FORMS_OPT_SITE_KEY, '_ww_forms_settings_flush_cache' );
add_action( 'update_option_' . WW_FORMS_OPT_SECRET, '_ww_forms_settings_flush_cache' );

/**
 * Naam van de transient met de uitkomst van Sleutels controleren, per gebruiker.
 */
function _ww_forms_settings_check_transient(): string {
	return 'ww_forms_keys_check_' . get_current_user_id();
}

/**
 * Bewaart de uitkomst van de sleutelcontrole kort, zodat het scherm hem één keer toont (geen gevoelige gegevens).
 *
 * @param array{ok: bool, level?: string, message: string} $result Uitkomst.
 */
function _ww_forms_settings_remember_check( array $result ): void {
	set_transient( _ww_forms_settings_check_transient(), $result, MINUTE_IN_SECONDS );
}

/**
 * De knop Sleutels controleren (admin-post.php): laat Google de token uit de browser controleren en keert terug naar
 * het scherm.
 */
function _ww_forms_settings_check_keys(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Je hebt geen rechten om de instellingen van formulieren te wijzigen.', 'webwerckt-base' ), 403 );
	}
	check_admin_referer( 'ww_forms_check_keys' );
	$token = isset( $_POST['ww_recaptcha'] ) ? (string) preg_replace( '/[^A-Za-z0-9_-]/', '', (string) wp_unslash( $_POST['ww_recaptcha'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- alleen deze tekens blijven over.
	_ww_forms_settings_remember_check( _ww_form_recaptcha_check_keys( substr( $token, 0, 4000 ) ) );
	wp_safe_redirect( _ww_forms_settings_url() );
	exit;
}

/**
 * Het script van Sleutels controleren: haalt bij de klik met de sitesleutel een token op (actie `ww_form_check`) en
 * verstuurt het formulier daarna, of na 5 seconden zonder token. Google laadt dus pas als de beheerder klikt.
 */
function _ww_forms_settings_check_script(): string {
	return <<<'JS'
( function () {
	var form = document.getElementById( 'ww-forms-check-keys' );
	var key = form ? form.getAttribute( 'data-ww-site-key' ) : '';
	if ( ! form || ! key ) {
		return;
	}
	var sent = false;
	form.addEventListener( 'submit', function ( event ) {
		if ( sent ) {
			return;
		}
		event.preventDefault();
		var done = function ( token ) {
			if ( sent ) {
				return;
			}
			sent = true;
			form.elements.ww_recaptcha.value = 'string' === typeof token ? token : '';
			HTMLFormElement.prototype.submit.call( form );
		};
		window.setTimeout( function () { done( '' ); }, 5000 );
		var run = function () {
			try {
				window.grecaptcha.ready( function () {
					try {
						window.grecaptcha.execute( key, { action: 'ww_form_check' } ).then( done, function () { done( '' ); } );
					} catch ( e ) {
						done( '' );
					}
				} );
			} catch ( e ) {
				done( '' );
			}
		};
		if ( window.grecaptcha && window.grecaptcha.ready ) {
			run();
			return;
		}
		var script = document.createElement( 'script' );
		script.async = true;
		script.onload = run;
		script.onerror = function () { done( '' ); };
		script.src = 'https://www.google.com/recaptcha/api.js?render=' + encodeURIComponent( key );
		document.head.appendChild( script );
	} );
} )();
JS;
}
add_action( 'admin_post_ww_forms_check_keys', '_ww_forms_settings_check_keys' );

/**
 * Toont het scherm Instellingen.
 */
function _ww_forms_settings_render(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$site_key   = _ww_form_recaptcha_site_key();
	$has_secret = '' !== _ww_form_recaptcha_secret();
	$attach     = (int) ( _ww_form_attach_max_bytes() / MB_IN_BYTES );
	$check      = get_transient( _ww_forms_settings_check_transient() );
	if ( false !== $check ) {
		delete_transient( _ww_forms_settings_check_transient() );
	}

	echo '<div class="wrap">';
	echo _ww_forms_render_picker( 'settings' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_forms_render_picker() escapet.
	echo '<h1>' . esc_html__( 'Instellingen', 'webwerckt-base' ) . '</h1>';

	settings_errors();
	if ( is_array( $check ) && isset( $check['ok'], $check['message'] ) ) {
		$level = isset( $check['level'] ) && in_array( $check['level'], array( 'success', 'warning', 'error' ), true ) ? $check['level'] : ( $check['ok'] ? 'success' : 'error' );
		printf(
			'<div class="notice notice-%1$s"><p>%2$s</p></div>',
			esc_attr( $level ),
			esc_html( (string) $check['message'] )
		);
	}
	if ( ( '' !== $site_key ) !== $has_secret ) {
		echo '<div class="notice notice-warning"><p>' . esc_html__( 'Er is maar één van beide sleutels ingevuld. reCAPTCHA staat uit totdat je de sitesleutel en de geheime sleutel allebei hebt ingevuld.', 'webwerckt-base' ) . '</p></div>';
	}

	echo '<form method="post" action="' . esc_url( admin_url( 'options.php' ) ) . '">';
	settings_fields( WW_FORMS_SETTINGS_GROUP );
	echo '<h2>' . esc_html__( 'reCAPTCHA v3', 'webwerckt-base' ) . '</h2>';
	echo '<p>' . esc_html__( 'Met beide sleutels controleert elk formulier inzendingen onzichtbaar met reCAPTCHA. Je krijgt de sleutels bij Google reCAPTCHA (versie 3).', 'webwerckt-base' ) . '</p>';
	echo '<table class="form-table" role="presentation"><tbody>';

	printf(
		'<tr><th scope="row"><label for="ww-forms-site-key">%1$s</label></th><td><input type="text" class="regular-text" id="ww-forms-site-key" name="%2$s" value="%3$s" maxlength="100" autocomplete="off"></td></tr>',
		esc_html__( 'Sitesleutel', 'webwerckt-base' ),
		esc_attr( WW_FORMS_OPT_SITE_KEY ),
		esc_attr( $site_key )
	);

	echo '<tr><th scope="row"><label for="ww-forms-secret">' . esc_html__( 'Geheime sleutel', 'webwerckt-base' ) . '</label></th><td>';
	printf(
		'<input type="password" class="regular-text" id="ww-forms-secret" name="%s" value="" maxlength="100" autocomplete="off">',
		esc_attr( WW_FORMS_OPT_SECRET )
	);
	if ( $has_secret ) {
		echo '<p class="description"><strong>' . esc_html__( 'Ingesteld', 'webwerckt-base' ) . '</strong> ' . esc_html__( 'Laat het veld leeg om de sleutel te behouden.', 'webwerckt-base' ) . '</p>';
		echo '<p><label><input type="checkbox" name="ww_forms_recaptcha_secret_clear" value="1"> ' . esc_html__( 'Geheime sleutel wissen', 'webwerckt-base' ) . '</label></p>';
	}
	echo '</td></tr>';

	printf(
		'<tr><th scope="row"><label for="ww-forms-threshold">%1$s</label></th><td><input type="number" id="ww-forms-threshold" name="%2$s" value="%3$s" min="0.1" max="0.9" step="0.1" class="small-text"><p class="description">%4$s</p></td></tr>',
		esc_html__( 'Scoregrens', 'webwerckt-base' ),
		esc_attr( WW_FORMS_OPT_THRESHOLD ),
		esc_attr( (string) _ww_form_recaptcha_threshold() ),
		esc_html__( 'Van 0,1 tot 0,9. Een score onder de grens geldt als spam. Standaard 0,5.', 'webwerckt-base' )
	);
	echo '</tbody></table>';

	echo '<h2>' . esc_html__( 'Bijlagen in de melding', 'webwerckt-base' ) . '</h2>';
	echo '<table class="form-table" role="presentation"><tbody>';

	printf(
		'<tr><th scope="row"><label for="ww-forms-attach-max">%1$s</label></th><td><input type="number" id="ww-forms-attach-max" name="%2$s" value="%3$s" min="0" max="25" step="1" class="small-text"> MB<p class="description">%4$s</p></td></tr>',
		esc_html__( 'Grens voor bijlagen in de melding', 'webwerckt-base' ),
		esc_attr( WW_FORMS_OPT_ATTACH_MAX ),
		esc_attr( (string) $attach ),
		esc_html__( 'Bestanden van een inzending gaan als bijlage mee met de melding zolang ze samen onder deze grens blijven, anders staat er een link. Van 0 tot 25 MB; 0 betekent nooit bijlagen.', 'webwerckt-base' )
	);
	echo '</tbody></table>';
	submit_button();
	echo '</form>';

	echo '<h2>' . esc_html__( 'Sleutels controleren', 'webwerckt-base' ) . '</h2>';
	echo '<p>' . esc_html__( 'Vraagt Google met de sitesleutel een token voor dit domein en controleert die met de geheime sleutel. Sla eerst eventuele wijzigingen op.', 'webwerckt-base' ) . '</p>';
	printf(
		'<form method="post" action="%1$s" id="ww-forms-check-keys" data-ww-site-key="%2$s">',
		esc_url( admin_url( 'admin-post.php' ) ),
		esc_attr( $site_key )
	);
	echo '<input type="hidden" name="action" value="ww_forms_check_keys">';
	echo '<input type="hidden" name="ww_recaptcha" value="">';
	wp_nonce_field( 'ww_forms_check_keys' );
	submit_button( __( 'Sleutels controleren', 'webwerckt-base' ), 'secondary', 'submit', false );
	echo '</form>';
	wp_print_inline_script_tag( _ww_forms_settings_check_script() );

	echo '<h2>' . esc_html__( 'Grenzen van de server', 'webwerckt-base' ) . '</h2>';
	echo '<p>' . esc_html__( 'Bestanden die een bezoeker meestuurt, kunnen niet groter zijn dan wat de server toelaat.', 'webwerckt-base' ) . '</p>';
	echo '<table class="widefat striped" style="max-width:32rem"><tbody>';
	foreach ( array( 'upload_max_filesize', 'post_max_size' ) as $ini ) {
		echo '<tr><td><code>' . esc_html( $ini ) . '</code></td><td>' . esc_html( (string) ini_get( $ini ) ) . '</td></tr>';
	}
	echo '<tr><td><code>wp_max_upload_size()</code></td><td>' . esc_html( (string) size_format( wp_max_upload_size() ) ) . '</td></tr>';
	echo '</tbody></table></div>';
}
