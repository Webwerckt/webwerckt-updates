<?php
/**
 * Video's van YouTube en Vimeo als placeholder (beslissing 0037): de oEmbed-iframe wordt een link met een lokale
 * thumbnail. Pas een klik laadt de speler, van youtube-nocookie.com of van Vimeo met dnt=1 (assets/js/video.js).
 * Zonder JavaScript is het een gewone link naar de video bij de dienst. Andere embeds blijven ongewijzigd.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * De dienst van een video-URL: youtube, vimeo of ''.
 *
 * @param string $url URL van de video zoals de redacteur hem plaatste.
 */
function _ww_video_service( string $url ): string {
	$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
	if ( preg_match( '/(^|\.)(youtube\.com|youtu\.be|youtube-nocookie\.com)$/', $host ) ) {
		return 'youtube';
	}
	if ( preg_match( '/(^|\.)vimeo\.com$/', $host ) ) {
		return 'vimeo';
	}
	return '';
}

/**
 * Een starttijd als 90, 90s, 1m30s of 1h2m3s in seconden; 0 als hij niet te lezen is.
 *
 * @param string $time Waarde van t of start uit de URL.
 */
function _ww_video_seconds( string $time ): int {
	if ( preg_match( '/^\d+$/', $time ) ) {
		return (int) $time;
	}
	if ( '' === $time || ! preg_match( '/^(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s)?$/', $time, $parts ) ) {
		return 0;
	}
	return 3600 * (int) ( $parts[1] ?? 0 ) + 60 * (int) ( $parts[2] ?? 0 ) + (int) ( $parts[3] ?? 0 );
}

/**
 * De URL die de speler pas na een klik laadt. YouTube via youtube-nocookie.com, met de starttijd uit t of start van
 * de oorspronkelijke URL; Vimeo met dnt=1. De query van de oEmbed-iframe (list, h van een niet-openbare video) blijft.
 *
 * @param string $iframe_src src van de oEmbed-iframe.
 * @param string $url        URL van de video zoals de redacteur hem plaatste.
 * @param string $service    youtube of vimeo.
 */
function _ww_video_play_url( string $iframe_src, string $url, string $service ): string {
	if ( 'youtube' === $service ) {
		$src = (string) preg_replace( '#^(https?:)?//[^/]+#i', 'https://www.youtube-nocookie.com', $iframe_src );
		$src = add_query_arg( 'autoplay', '1', $src );

		$query = array();
		wp_parse_str( (string) wp_parse_url( $url, PHP_URL_QUERY ), $query );
		$time  = $query['t'] ?? $query['start'] ?? '';
		$start = is_string( $time ) ? _ww_video_seconds( $time ) : 0;
		return $start > 0 ? add_query_arg( 'start', (string) $start, $src ) : $src;
	}
	return add_query_arg(
		array(
			'dnt'      => '1',
			'autoplay' => '1',
		),
		$iframe_src
	);
}

/**
 * Absoluut pad van de lokale thumbnail: uploads/ww-video/{dienst}-{hash}.jpg. Een hash van de URL in plaats van de
 * video-ID, zodat er geen ID-parser nodig is.
 *
 * @param string $service youtube of vimeo.
 * @param string $url     URL van de video zoals de redacteur hem plaatste.
 */
function _ww_video_thumb_path( string $service, string $url ): string {
	return wp_upload_dir( null, false )['basedir'] . '/ww-video/' . _ww_video_thumb_name( $service, $url );
}

/**
 * Bestandsnaam van de lokale thumbnail, voor het pad en de URL.
 *
 * @param string $service youtube of vimeo.
 * @param string $url     URL van de video zoals de redacteur hem plaatste.
 */
function _ww_video_thumb_name( string $service, string $url ): string {
	return $service . '-' . substr( md5( $url ), 0, 12 ) . '.jpg';
}

/**
 * Haalt de thumbnail op bij de dienst en bewaart hem lokaal, zodat een bezoeker de dienst niet hoeft te benaderen om
 * hem te zien. Alleen bij code 200 en een afbeelding; eerst naar een tijdelijk bestand, dan een rename.
 *
 * @param string $service   youtube of vimeo.
 * @param string $url       URL van de video zoals de redacteur hem plaatste.
 * @param string $thumb_url URL van de thumbnail volgens de oEmbed-gegevens.
 */
function _ww_video_store_thumb( string $service, string $url, string $thumb_url ): bool {
	if ( '' === $service || '' === $thumb_url ) {
		return false;
	}
	$response = wp_safe_remote_get(
		$thumb_url,
		array(
			'timeout'             => 5,
			'limit_response_size' => 2 * MB_IN_BYTES,
		)
	);
	if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
		return false;
	}
	$type = wp_remote_retrieve_header( $response, 'content-type' );
	$body = wp_remote_retrieve_body( $response );
	if ( ! is_string( $type ) || ! str_starts_with( strtolower( trim( $type ) ), 'image/' ) || '' === $body ) {
		return false;
	}

	$path = _ww_video_thumb_path( $service, $url );
	if ( ! wp_mkdir_p( dirname( $path ) ) ) {
		return false;
	}
	$tmp = $path . '.' . wp_generate_password( 8, false ) . '.tmp';
	if ( false === file_put_contents( $tmp, $body ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- eigen map in uploads.
		return false;
	}
	if ( ! rename( $tmp, $path ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename -- atomair vervangen.
		wp_delete_file( $tmp );
		return false;
	}
	return true;
}

/**
 * Zorgt dat de thumbnail er is bij het renderen: bestaat hij niet en is er de afgelopen 24 uur niets misgegaan, dan
 * haalt dit één keer de oEmbed-gegevens op en bewaart de thumbnail. Lukt dat niet, dan wacht het een dag.
 *
 * @param string $service youtube of vimeo.
 * @param string $url     URL van de video zoals de redacteur hem plaatste.
 */
function _ww_video_ensure_thumb( string $service, string $url ): void {
	if ( file_exists( _ww_video_thumb_path( $service, $url ) ) ) {
		return;
	}
	$fail = 'ww_video_thumb_fail_' . md5( $url );
	if ( false !== get_transient( $fail ) ) {
		return;
	}
	$oembed = _wp_oembed_get_object();
	$data   = $oembed->get_data( $url );
	$thumb  = is_object( $data ) && isset( $data->thumbnail_url ) && is_string( $data->thumbnail_url ) ? $data->thumbnail_url : '';
	if ( ! _ww_video_store_thumb( $service, $url, $thumb ) ) {
		set_transient( $fail, 1, DAY_IN_SECONDS );
	}
}

/**
 * Filter op oembed_dataparse: bewaart de thumbnail zodra de oEmbed-gegevens binnen zijn; de HTML blijft ongewijzigd.
 *
 * @param string|false $result HTML van de oEmbed.
 * @param object       $data   Gegevens van de oEmbed-aanvraag.
 * @param string       $url    URL van de video zoals de redacteur hem plaatste.
 * @return string|false
 */
function _ww_video_dataparse( $result, $data, $url ) {
	$service = _ww_video_service( (string) $url );
	if ( '' !== $service && isset( $data->thumbnail_url ) && is_string( $data->thumbnail_url )
		&& ! file_exists( _ww_video_thumb_path( $service, (string) $url ) ) ) {
		_ww_video_store_thumb( $service, (string) $url, $data->thumbnail_url );
	}
	return $result;
}
add_filter( 'oembed_dataparse', '_ww_video_dataparse', 10, 3 );

/**
 * De CSS van de placeholder, alleen de eerste keer in het verzoek; daarna ''. Met $reset weer van voren af (tests).
 *
 * @param bool $reset Vlag terugzetten.
 */
function _ww_video_css_once( bool $reset = false ): string {
	static $printed = false;
	if ( $reset ) {
		$printed = false;
		return '';
	}
	if ( $printed ) {
		return '';
	}
	$printed = true;
	return '<style id="ww-video-css">'
		. '.ww-video{position:relative;width:100%;margin:0 0 1.5em;overflow:hidden;background:#1a1a1a;color:#fff}'
		. '.ww-video__link{position:absolute;inset:0;display:block;color:inherit;text-decoration:none}'
		. '.ww-video__link:focus-visible{outline:3px solid currentColor;outline-offset:-6px}'
		. '.ww-video__link img{display:block;width:100%;height:100%;object-fit:cover}'
		. '.ww-video__play{position:absolute;top:50%;left:50%;width:68px;height:48px;border-radius:12px;transform:translate(-50%,-50%);background:var(--ww-video-play-bg,rgba(0,0,0,.75))}'
		. '.ww-video__play::after{content:"";position:absolute;top:50%;left:50%;transform:translate(-35%,-50%);border-style:solid;border-width:10px 0 10px 18px;border-color:transparent transparent transparent #fff}'
		. '.ww-video__title{position:absolute;top:0;right:0;left:0;padding:.75em 1em;background:linear-gradient(rgba(0,0,0,.7),transparent)}'
		. '.ww-video__notice{position:absolute;right:0;bottom:0;left:0;padding:.5em 1em;font-size:.8em;background:rgba(0,0,0,.7)}'
		. '.ww-video iframe{display:block;width:100%;height:100%;border:0}'
		. '</style>';
}

/**
 * Filter op embed_oembed_html: een iframe van YouTube of Vimeo wordt een placeholder, andere embeds blijven gelijk.
 * Werkt ook voor de autoembeds in ww_text() en voor gecachete oEmbeds.
 *
 * @param string $html HTML van de oEmbed.
 * @param string $url  URL van de video zoals de redacteur hem plaatste.
 */
function _ww_video_placeholder( string $html, string $url ): string {
	$service = _ww_video_service( $url );
	/**
	 * Zet de placeholder uit (false), per video of helemaal.
	 *
	 * @param bool   $placeholder Standaard true.
	 * @param string $url         URL van de video.
	 */
	if ( '' === $service || ! apply_filters( 'ww_video_placeholder', true, $url ) ) {
		return $html;
	}
	// Een excerpt draait the_content en gooit de tags weg. Ook daar een placeholder (nooit de iframe), maar zonder CSS
	// en script, zodat de CSS niet al "geprint" is voor de echte inhoud van de pagina.
	$excerpt = doing_filter( 'get_the_excerpt' );

	$tag = new WP_HTML_Tag_Processor( $html );
	if ( ! $tag->next_tag( array( 'tag_name' => 'iframe' ) ) ) {
		return $html;
	}
	$src = $tag->get_attribute( 'src' );
	// Alleen een speler van dezelfde dienst; een iframe van elders blijft zoals hij is.
	if ( ! is_string( $src ) || _ww_video_service( $src ) !== $service ) {
		return $html;
	}
	$width  = (int) $tag->get_attribute( 'width' );
	$height = (int) $tag->get_attribute( 'height' );
	$ratio  = $width > 0 && $height > 0 ? $width . ' / ' . $height : '16 / 9';
	$title  = $tag->get_attribute( 'title' );
	$title  = is_string( $title ) ? trim( $title ) : '';
	$name   = 'youtube' === $service ? 'YouTube' : 'Vimeo';

	$img = '';
	_ww_video_ensure_thumb( $service, $url );
	if ( file_exists( _ww_video_thumb_path( $service, $url ) ) ) {
		$img = '<img src="' . esc_url( wp_upload_dir( null, false )['baseurl'] . '/ww-video/' . _ww_video_thumb_name( $service, $url ) ) . '" alt="" loading="lazy">';
	}
	$label = '' === $title
		/* translators: %s: naam van de dienst, YouTube of Vimeo. */
		? sprintf( __( 'Video van %s afspelen', 'webwerckt-base' ), $name )
		/* translators: %s: titel van de video. */
		: sprintf( __( 'Video afspelen: %s', 'webwerckt-base' ), $title );
	/* translators: %s: naam van de dienst, YouTube of Vimeo. */
	$notice = sprintf( __( 'Deze video komt van %s. Bij afspelen gelden hun voorwaarden.', 'webwerckt-base' ), $name );

	if ( ! $excerpt ) {
		wp_enqueue_script(
			'ww-video',
			_ww_asset_url( 'js/video.js' ),
			array(),
			WW_BASE_VERSION,
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
	}

	// esc_attr( esc_url_raw() ) in plaats van esc_url(): dat geeft & als &amp; en niet als &#038;, zodat video.js de URL ongewijzigd leest.
	return ( $excerpt ? '' : _ww_video_css_once() )
		. '<figure class="ww-video" data-ww-video="' . esc_attr( esc_url_raw( _ww_video_play_url( $src, $url, $service ) ) ) . '" style="aspect-ratio: ' . esc_attr( $ratio ) . '">'
		. '<a class="ww-video__link" href="' . esc_attr( esc_url_raw( $url ) ) . '" aria-label="' . esc_attr( $label ) . '">'
		. $img
		. '<span class="ww-video__play" aria-hidden="true"></span>'
		. ( '' === $title ? '' : '<span class="ww-video__title">' . esc_html( $title ) . '</span>' )
		. '</a>'
		. '<figcaption class="ww-video__notice">' . esc_html( $notice ) . '</figcaption>'
		. '</figure>';
}
add_filter( 'embed_oembed_html', '_ww_video_placeholder', 10, 2 ); // De hook geeft vier argumenten ($html, $url, $attr, $post_id); alleen de eerste twee zijn nodig.
