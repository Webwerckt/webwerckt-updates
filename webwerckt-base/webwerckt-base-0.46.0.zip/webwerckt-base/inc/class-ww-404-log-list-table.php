<?php
/**
 * Tabel met het 404-logboek op het scherm Redirects (inc/redirects-admin.php). Wordt pas geladen als dat
 * scherm wordt getoond, na WP_List_Table.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Het 404-logboek: pad met de acties Redirect maken en Uit het logboek halen, hoe vaak gezocht, laatst en eerst gezien,
 * de verwijzer en een knop Redirect maken.
 */
class WW_404_Log_List_Table extends WP_List_Table {

	/**
	 * Of er een rij getoond is met een verwijzer van de eigen site (dan volgt onder de tabel een uitleg).
	 *
	 * @var bool
	 */
	public $has_internal = false;

	public function __construct() {
		parent::__construct(
			array(
				'singular' => 'pad',
				'plural'   => 'paden',
				'ajax'     => false,
			)
		);
	}

	/**
	 * @return array<string,string>
	 */
	public function get_columns() {
		return array(
			'cb'         => '<input type="checkbox">',
			'path'       => __( 'Pad', 'webwerckt-base' ),
			'hits'       => __( 'Gezocht', 'webwerckt-base' ),
			'last_seen'  => __( 'Laatst', 'webwerckt-base' ),
			'first_seen' => __( 'Eerst', 'webwerckt-base' ),
			'referrer'   => __( 'Kwam van', 'webwerckt-base' ),
			'create'     => '<span class="screen-reader-text">' . esc_html__( 'Actie', 'webwerckt-base' ) . '</span>',
		);
	}

	/**
	 * @return array<string,array{0:string,1:bool}>
	 */
	protected function get_sortable_columns() {
		return array(
			'path'       => array( 'path', false ),
			'hits'       => array( 'hits', true ),
			'first_seen' => array( 'first_seen', true ),
			'last_seen'  => array( 'last_seen', true ),
		);
	}

	/**
	 * @return array<string,string>
	 */
	protected function get_bulk_actions() {
		return array( 'log-bulk-delete' => __( 'Uit het logboek halen', 'webwerckt-base' ) );
	}

	/**
	 * Zoekt, sorteert (standaard op hits, aflopend) en pagineert via _ww_404_log_admin_list().
	 */
	public function prepare_items(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- alleen zoeken en sorteren.
		$search  = isset( $_GET['s'] ) ? sanitize_text_field( _ww_data_to_string( wp_unslash( $_GET['s'] ) ) ) : '';
		$orderby = isset( $_GET['orderby'] ) ? sanitize_key( _ww_data_to_string( $_GET['orderby'] ) ) : 'hits';
		$order   = isset( $_GET['order'] ) ? sanitize_key( _ww_data_to_string( $_GET['order'] ) ) : 'desc';
		// phpcs:enable
		$result = _ww_404_log_admin_list( $search, $orderby, $order, $this->get_pagenum() );

		$this->_column_headers = array( $this->get_columns(), array(), $this->get_sortable_columns(), 'path' );
		$this->set_pagination_args(
			array(
				'total_items' => $result['total'],
				'per_page'    => WW_REDIRECTS_PER_PAGE,
			)
		);
		$this->items = $result['items'];
	}

	/**
	 * Tekst als het logboek leeg is.
	 */
	public function no_items(): void {
		esc_html_e( "Er zijn de laatste 30 dagen geen pagina's gezocht die niet bestaan. Hier verschijnen ze zodra dat gebeurt.", 'webwerckt-base' );
	}

	/**
	 * Selectievakje voor de bulkactie.
	 *
	 * @param object $item Rij.
	 */
	protected function column_cb( $item ): string {
		return '<input type="checkbox" name="paths[]" value="' . esc_attr( (string) $item->path ) . '">';
	}

	/**
	 * De link naar het formulier met dit pad als oude URL, met de weg terug naar het logboek.
	 *
	 * @param object $item Rij.
	 */
	private function create_url( $item ): string {
		return _ww_redirects_admin_url(
			array(
				'tab'     => 'redirects',
				'source'  => (string) $item->path,
				'ww_from' => '404',
			)
		);
	}

	/**
	 * Pad (met "nieuw" als het de laatste week voor het eerst gezocht is) en de acties Redirect maken en Uit het logboek
	 * halen.
	 *
	 * @param object $item Rij.
	 */
	protected function column_path( $item ): string {
		$delete  = _ww_redirects_admin_action_url(
			'log-delete',
			array(
				'tab'  => '404',
				'path' => (string) $item->path,
			)
		);
		$actions = array(
			'create' => '<a href="' . esc_url( $this->create_url( $item ) ) . '">' . esc_html__( 'Redirect maken', 'webwerckt-base' ) . '</a>',
			'delete' => '<a class="submitdelete" href="' . esc_url( $delete ) . '">' . esc_html__( 'Uit het logboek halen', 'webwerckt-base' ) . '</a>',
		);
		$new     = _ww_404_log_is_new( (string) $item->first_seen ) ? ' <span class="ww-redirects-chip ww-redirects-chip--new">' . esc_html__( 'nieuw', 'webwerckt-base' ) . '</span>' : '';
		return '<strong class="ww-redirects-path">' . esc_html( (string) $item->path ) . '</strong>' . $new . $this->row_actions( $actions );
	}

	/**
	 * Hoe vaak het pad gezocht is.
	 *
	 * @param object $item Rij.
	 */
	protected function column_hits( $item ): string {
		$hits = (int) $item->hits;
		return esc_html(
			sprintf(
				/* translators: %s: aantal keer. */
				_n( '%s keer', '%s keer', $hits, 'webwerckt-base' ),
				number_format_i18n( $hits )
			)
		);
	}

	/**
	 * De knop Redirect maken (op mobiel verborgen; de rij-actie blijft).
	 *
	 * @param object $item Rij.
	 */
	protected function column_create( $item ): string {
		return '<a class="button" href="' . esc_url( $this->create_url( $item ) ) . '">' . esc_html__( 'Redirect maken', 'webwerckt-base' ) . '</a>';
	}

	/**
	 * Hoe lang geleden het pad voor het eerst werd gevraagd.
	 *
	 * @param object $item Rij.
	 */
	protected function column_first_seen( $item ): string {
		return $this->ago( (string) $item->first_seen );
	}

	/**
	 * Hoe lang geleden het pad voor het laatst werd gevraagd.
	 *
	 * @param object $item Rij.
	 */
	protected function column_last_seen( $item ): string {
		return $this->ago( (string) $item->last_seen );
	}

	/**
	 * De laatste verwijzer (host en pad), met "eigen site" als die van deze site komt; anders "onbekend".
	 *
	 * @param object $item Rij.
	 */
	protected function column_referrer( $item ): string {
		$referrer = (string) $item->referrer;
		if ( '' === $referrer ) {
			return '<span class="ww-redirects-muted">' . esc_html__( 'onbekend', 'webwerckt-base' ) . '</span>';
		}
		$html = '<span class="ww-redirects-referrer">' . esc_html( $referrer ) . '</span>';
		if ( _ww_404_log_is_internal( $referrer ) ) {
			$this->has_internal = true;
			$html              .= ' <span class="ww-redirects-chip ww-redirects-chip--internal" title="' . esc_attr__( 'Een link op je eigen site werkt niet', 'webwerckt-base' ) . '">' . esc_html__( 'eigen site', 'webwerckt-base' ) . '</span>';
		}
		return $html;
	}

	/**
	 * Een UTC-tijd als "5 minuten geleden".
	 *
	 * @param string $utc Tijd uit de tabel.
	 */
	private function ago( string $utc ): string {
		$time = strtotime( $utc . ' UTC' );
		if ( false === $time ) {
			return '&mdash;';
		}
		return esc_html(
			sprintf(
				/* translators: %s: tijdsduur, zoals 5 minuten. */
				__( '%s geleden', 'webwerckt-base' ),
				human_time_diff( $time )
			)
		);
	}
}
