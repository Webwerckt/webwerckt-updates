<?php
/**
 * Meertalig sitebreed (beslissing 0042): menu's per taal.
 *
 * Met Meertalig actief krijgt elke menulocatie per extra taal een kopie ({locatie}__{lang}). In een extra taal geeft
 * ww_menu() het menu van die kopie, en zonder menu daar het menu van de standaardtaal met de berichten vertaald.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Splitst een menulocatie in de basislocatie en de extra taal: primary__en wordt primary en en. Een locatie zonder
 * voorvoegsel, of met de standaardtaal of een onbekende taal erachter, heeft lang ''. Zonder Meertalig is er geen
 * extra taal en dus ook nooit een lang.
 *
 * @param string $location Menulocatie.
 * @return array{base:string,lang:string}
 */
function _ww_menu_location_language( string $location ): array {
	$plain = array(
		'base' => $location,
		'lang' => '',
	);
	$pos   = strrpos( $location, '__' );
	if ( false === $pos || 0 === $pos || ! _ww_languages_active() ) {
		return $plain;
	}
	$lang = substr( $location, $pos + 2 );
	if ( ! in_array( $lang, _ww_extra_language_codes(), true ) ) {
		return $plain;
	}
	return array(
		'base' => substr( $location, 0, $pos ),
		'lang' => $lang,
	);
}

/**
 * Registreert per extra taal een kopie van elke menulocatie, met het label "{label} ({naam van de taal})". Ook voor
 * verborgen talen, zodat een redacteur ze kan voorbereiden. Draait op init prioriteit 20: een locatie die het
 * child-thema later registreert krijgt geen kopie (ww_menu() vertaalt dan automatisch). Zonder Meertalig niets.
 */
function _ww_languages_register_menu_locations(): void {
	if ( ! _ww_languages_active() ) {
		return;
	}
	$copies = array();
	foreach ( get_registered_nav_menus() as $location => $label ) {
		if ( '' !== _ww_menu_location_language( (string) $location )['lang'] ) {
			continue;
		}
		foreach ( _ww_extra_language_codes() as $code ) {
			$language = _ww_language( $code );
			if ( null === $language ) {
				continue;
			}
			/* translators: 1: naam van de menulocatie, 2: naam van de taal. */
			$copies[ $location . '__' . $code ] = sprintf( __( '%1$s (%2$s)', 'webwerckt-base' ), $label, $language['name'] );
		}
	}
	if ( array() !== $copies ) {
		register_nav_menus( $copies );
	}
}

/**
 * Het menu dat op de locatie van een taal staat, of 0 als er geen (bestaand) menu is.
 *
 * @param string $location Basislocatie.
 * @param string $lang     Extra taal.
 */
function _ww_languages_own_menu( string $location, string $lang ): int {
	$menu_id = absint( get_nav_menu_locations()[ $location . '__' . $lang ] ?? 0 );
	return $menu_id > 0 && wp_get_nav_menu_object( $menu_id ) instanceof WP_Term ? $menu_id : 0;
}

/**
 * De automatische vertaling van de items van een menu in een extra taal. Een item naar een bericht van een vertaalbaar
 * post type wordt de gepubliceerde vertaling in die taal, met titel en permalink van de vertaling (een eigen label is
 * in de standaardtaal en vervalt). Zonder vertaling, of met een vertaling in een taal die de bezoeker niet ziet, valt
 * het item weg; zijn kinderen komen dan op het hoogste niveau. Een niet-vertaalbaar post type, een term, een archief en
 * een losse link blijven ongewijzigd. Draait vóór _wp_menu_item_classes_by_context(), zodat het huidige item klopt.
 *
 * Een item naar een bericht dat zelf al in een extra taal staat, wordt de vertaling in de gevraagde taal: in die taal
 * zelf blijft het dat bericht (ww_translation_id() geeft het bericht terug als het in zijn eigen taal wordt gevraagd).
 *
 * @param array<int,object> $items Items van wp_get_nav_menu_items().
 * @param string            $lang  Extra taal.
 * @return array<int,object>
 */
function _ww_languages_menu_items( array $items, string $lang ): array {
	_ww_languages_prime_menu_items( $items, $lang );
	$out = array();
	foreach ( $items as $item ) {
		if ( 'post_type' !== ( $item->type ?? '' ) || ! _ww_is_translatable( (string) ( $item->object ?? '' ) ) ) {
			$out[] = $item;
			continue;
		}
		$target = ww_translation_id( (int) ( $item->object_id ?? 0 ), $lang );
		if ( $target <= 0 ) {
			continue;
		}
		$item            = clone $item;
		$item->object_id = (string) $target;
		$item->url       = (string) get_permalink( $target );
		// Zoals wp_setup_nav_menu_item(): de titel door the_title, zonder "Beveiligd:" of "Privé:" ervoor.
		$item->title = apply_filters( 'the_title', (string) get_post_field( 'post_title', $target ), $target );
		$out[]       = $item;
	}
	return $out;
}

/**
 * Zet de berichten van een menu en hun vertalingen in die taal in de cache, met hun termen (de taal), zoals
 * _ww_languages_current_group(): één query voor de berichten en één voor de termen per post type, hoe lang het menu ook
 * is. Anders kost elk item een query voor zijn taal en een voor de status van de vertaling.
 *
 * @param array<int,object> $items Items van wp_get_nav_menu_items().
 * @param string            $lang  Extra taal.
 */
function _ww_languages_prime_menu_items( array $items, string $lang ): void {
	$sources = array();
	foreach ( $items as $item ) {
		$type = (string) ( $item->object ?? '' );
		if ( 'post_type' === ( $item->type ?? '' ) && _ww_is_translatable( $type ) && (int) ( $item->object_id ?? 0 ) > 0 ) {
			$sources[ $type ][] = (int) $item->object_id;
		}
	}
	foreach ( $sources as $type => $ids ) {
		$ids = array_values( array_unique( $ids ) );
		// Bronnen eerst: _ww_translations() kijkt zonder groepsmeta naar de taalterm van de bron.
		_prime_post_caches( $ids, false, false );
		update_postmeta_cache( $ids );
		update_object_term_cache( $ids, $type );
		$targets = array();
		foreach ( $ids as $id ) {
			$targets[] = _ww_translations( $id )[ $lang ] ?? 0;
		}
		$targets = array_values( array_unique( array_filter( $targets ) ) );
		if ( array() !== $targets ) {
			_prime_post_caches( $targets, false, false );
			update_object_term_cache( $targets, $type );
		}
	}
}

/**
 * Filter wp_nav_menu_args: in een extra taal de locatie van die taal als er een menu op staat. Er is geen automatische
 * vertaling; zonder menu daar blijft de locatie zoals ze is.
 *
 * @param array<string,mixed> $args Argumenten van wp_nav_menu().
 * @return array<string,mixed>
 */
function _ww_languages_nav_menu_args( array $args ): array {
	$location = is_string( $args['theme_location'] ?? null ) ? $args['theme_location'] : '';
	$lang     = ww_current_language();
	if ( '' === $location || ! in_array( $lang, _ww_extra_language_codes(), true ) || '' !== _ww_menu_location_language( $location )['lang'] ) {
		return $args;
	}
	if ( _ww_languages_own_menu( $location, $lang ) > 0 ) {
		$args['theme_location'] = $location . '__' . $lang;
	}
	return $args;
}

/**
 * Hangt de hooks van dit onderdeel op. Draait ook na init (zie _ww_languages_boot()): de locaties dan direct.
 */
function _ww_languages_boot_menus(): void {
	if ( did_action( 'init' ) ) {
		_ww_languages_register_menu_locations();
	} else {
		add_action( 'init', '_ww_languages_register_menu_locations', 20 );
	}
	add_filter( 'wp_nav_menu_args', '_ww_languages_nav_menu_args' );
}
