<?php
/**
 * Zoeken: de hoofdquery van de zoekpagina zoekt alleen in post types met een eigen pagina, een lege zoekopdracht
 * geeft niets, en ?type= beperkt de resultaten tot één post type. ww_search_counts() geeft per post type het aantal
 * treffers. De resultaten zelf blijven de gewone hoofdquery, met paginering en ww_card(). Het child-thema maakt de
 * HTML in search.php; een child-thema zonder search.php en zonder eigen index.php krijgt de kale versie uit de
 * index.php van de parent.
 *
 * WordPress zoekt in titel en post_content; de tekstvelden staan daar dankzij de kopie uit inc/content.php (ADR 0008).
 * Noindex staat in inc/integrations/seo.php, niet cachen in inc/notfound.php.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Queryparameter die de resultaten beperkt tot één post type: ?s=dak&type=project.
 */
const WW_SEARCH_TYPE_PARAM = 'type';

/**
 * Langste zoekopdracht in tekens. De zoekpagina komt niet in de cache en draait per post type een extra LIKE-query
 * (ww_search_counts()), dus een lange zoekopdracht wordt ingekort voordat de database hem ziet.
 */
const WW_SEARCH_MAX_LENGTH = 100;

/**
 * Publieke post types met een eigen pagina, niet uitgesloten van zoeken, zonder bijlagen: de standaard voor
 * _ww_search_post_types().
 *
 * @return string[]
 */
function _ww_viewable_post_types(): array {
	$types = get_post_types(
		array(
			'public'              => true,
			'exclude_from_search' => false,
		)
	);
	return array_values( array_diff( array_filter( $types, 'is_post_type_viewable' ), array( 'attachment' ) ) );
}

/**
 * Post types waarin de zoekfunctie zoekt: publiek, met een eigen pagina, niet uitgesloten van zoeken, geen bijlagen.
 * Een child-thema past de lijst aan met het filter ww_search_post_types.
 *
 * @return string[]
 */
function _ww_search_post_types(): array {
	$types = apply_filters( 'ww_search_post_types', _ww_viewable_post_types() );
	return array_values( array_filter( is_array( $types ) ? $types : array(), static fn( $type ): bool => is_string( $type ) && post_type_exists( $type ) ) );
}

/**
 * Het post type uit ?type=, als dat een post type is waarin gezocht wordt; anders ''.
 */
function _ww_search_type(): string {
	$type = _ww_query_key( WW_SEARCH_TYPE_PARAM );
	return in_array( $type, _ww_search_post_types(), true ) ? $type : '';
}

/**
 * De zoekopdracht van een query, zonder spaties eromheen.
 */
function _ww_search_terms( WP_Query $query ): string {
	return trim( _ww_data_to_string( $query->get( 's' ) ) );
}

/**
 * Past de hoofdquery van de zoekpagina aan: alleen de toegestane post types (of het type uit ?type=), de zoekopdracht
 * ingekort tot WW_SEARCH_MAX_LENGTH tekens, en geen resultaten bij een lege zoekopdracht (WordPress toont dan alle
 * berichten).
 */
function _ww_apply_search_query( WP_Query $query ): void {
	if ( is_admin() || ! $query->is_main_query() || ! $query->is_search() ) {
		return;
	}
	$type = _ww_search_type();
	$query->set( 'post_type', '' === $type ? _ww_search_post_types() : $type );
	$terms = _ww_search_terms( $query );
	if ( mb_strlen( $terms ) > WW_SEARCH_MAX_LENGTH ) {
		$query->set( 's', trim( mb_substr( $terms, 0, WW_SEARCH_MAX_LENGTH ) ) );
	}
	if ( '' === _ww_search_terms( $query ) ) {
		$query->set( 'post__in', array( 0 ) );
	}
}
add_action( 'pre_get_posts', '_ww_apply_search_query' );

/**
 * URL van de zoekresultaten voor deze zoekopdracht, eventueel beperkt tot één post type. Niet ge-escaped.
 */
function _ww_search_url( string $terms, string $type = '' ): string {
	$url = add_query_arg( 's', rawurlencode( $terms ), home_url( '/' ) );
	return '' === $type ? $url : add_query_arg( WW_SEARCH_TYPE_PARAM, $type, $url );
}

/**
 * Aantal treffers per post type voor de huidige zoekopdracht, alleen types met treffers, in de volgorde van
 * _ww_search_post_types(). Buiten de zoekpagina of bij een lege zoekopdracht array().
 *
 * Elk item is een array met post_type, label (meervoud, ge-escaped), count, url (de resultaten van alleen dat type,
 * ge-escaped) en current (bool, dit type staat in ?type=):
 *
 *     <?php foreach ( ww_search_counts() as $group ) : ?>
 *         <a href="<?php echo $group['url']; ?>"><?php echo $group['label']; ?> (<?php echo $group['count']; ?>)</a>
 *     <?php endforeach; ?>
 *
 * @return array<int,array{post_type:string,label:string,count:int,url:string,current:bool}>
 */
function ww_search_counts(): array {
	$main  = _ww_main_query();
	$terms = null !== $main && $main->is_search() ? _ww_search_terms( $main ) : '';
	if ( '' === $terms ) {
		return array();
	}

	$current = _ww_search_type();
	$counts  = array();
	foreach ( _ww_search_post_types() as $post_type ) {
		$query = new WP_Query(
			array(
				'post_type'              => $post_type,
				'post_status'            => 'publish',
				's'                      => $terms,
				'posts_per_page'         => 1,
				'fields'                 => 'ids',
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			)
		);
		$type  = get_post_type_object( $post_type );
		if ( $query->found_posts > 0 && $type instanceof WP_Post_Type ) {
			$counts[] = array(
				'post_type' => $post_type,
				'label'     => esc_html( $type->labels->name ),
				'count'     => (int) $query->found_posts,
				'url'       => esc_url( _ww_search_url( $terms, $post_type ) ),
				'current'   => $current === $post_type,
			);
		}
	}
	return $counts;
}
