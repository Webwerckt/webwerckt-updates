<?php
/**
 * Formulieren: de afgeschermde map voor geüploade bestanden (beslissing 0032).
 *
 * De map staat in `{basedir}/ww-forms-{geheim}/{form_id}/{entry_id}/`. Alleen de mapnaam staat in de optie
 * `ww_forms_upload_dir`; het volledige pad wordt elke keer opgebouwd uit `wp_upload_dir()`, zodat een andere basedir
 * na een migratie gewoon werkt. Bestanden krijgen op schijf een willekeurige naam. Pad en URL worden nooit bewaard.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WW_FORMS_OPT_UPLOAD_DIR', 'ww_forms_upload_dir' );

/**
 * Het pad van de hoofdmap voor bestanden, zonder slash aan het eind.
 *
 * Zonder `$create` en zonder de optie is het resultaat leeg. Met `$create` wordt de map (en de optie) aangemaakt en
 * worden ontbrekende beveiligingsbestanden teruggezet.
 */
function _ww_form_files_base( bool $create = false ): string {
	$name = (string) get_option( WW_FORMS_OPT_UPLOAD_DIR, '' );
	if ( 1 !== preg_match( '/^ww-forms-[a-z0-9]{16}$/', $name ) ) {
		if ( ! $create ) {
			return '';
		}
		$name = _ww_form_files_claim_name( $name );
	}

	$uploads = wp_upload_dir( null, false );
	$base    = untrailingslashit( str_replace( '\\', '/', (string) $uploads['basedir'] ) ) . '/' . $name;
	if ( $create ) {
		_ww_form_files_protect( $base );
	}
	return $base;
}

/**
 * Legt de mapnaam vast en geeft de naam die in de database staat.
 *
 * Twee gelijktijdige eerste uploads mogen geen eigen map krijgen: de optie wordt daarom met `INSERT IGNORE` gemaakt
 * (add_option doet `ON DUPLICATE KEY UPDATE` en overschrijft dus), en daarna opnieuw uit de database gelezen. Wie
 * verliest, gebruikt de naam van de winnaar. Alleen een ongeldige waarde die er al stond, wordt overschreven.
 *
 * @param string $current De (ongeldige of lege) waarde die get_option gaf.
 */
function _ww_form_files_claim_name( string $current ): string {
	global $wpdb;
	$chars     = 'abcdefghijklmnopqrstuvwxyz0123456789';
	$candidate = 'ww-forms-';
	for ( $i = 0; $i < 16; $i++ ) {
		$candidate .= $chars[ random_int( 0, strlen( $chars ) - 1 ) ];
	}

	// phpcs:disable WordPress.DB.DirectDatabaseQuery -- atomisch aanmaken; add_option kan dat niet.
	if ( '' === $current ) {
		$wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, %s)", WW_FORMS_OPT_UPLOAD_DIR, $candidate, 'off' ) );
	}
	_ww_form_files_forget_option();
	$stored = (string) $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", WW_FORMS_OPT_UPLOAD_DIR ) );
	// phpcs:enable

	if ( 1 !== preg_match( '/^ww-forms-[a-z0-9]{16}$/', $stored ) ) {
		update_option( WW_FORMS_OPT_UPLOAD_DIR, $candidate, false );
		$stored = $candidate;
	}
	return $stored;
}

/**
 * Wist de optie van de mapnaam uit de objectcache (ook uit notoptions), zodat get_option de database leest.
 */
function _ww_form_files_forget_option(): void {
	wp_cache_delete( WW_FORMS_OPT_UPLOAD_DIR, 'options' );
	$notoptions = wp_cache_get( 'notoptions', 'options' );
	if ( is_array( $notoptions ) && isset( $notoptions[ WW_FORMS_OPT_UPLOAD_DIR ] ) ) {
		unset( $notoptions[ WW_FORMS_OPT_UPLOAD_DIR ] );
		wp_cache_set( 'notoptions', $notoptions, 'options' );
	}
}

/**
 * Maakt de hoofdmap en zet `.htaccess` en `index.php` terug als ze ontbreken.
 */
function _ww_form_files_protect( string $base ): void {
	wp_mkdir_p( $base );
	// phpcs:disable WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- de eigen, afgeschermde map.
	if ( ! file_exists( $base . '/.htaccess' ) ) {
		file_put_contents( $base . '/.htaccess', "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n" );
	}
	if ( ! file_exists( $base . '/index.php' ) ) {
		file_put_contents( $base . '/index.php', "<?php // Stil.\n" );
	}
	// phpcs:enable
}

/**
 * De map van één inzending, `{base}/{form_id}/{entry_id}`; leeg als de hoofdmap er niet is.
 *
 * Met `$create` komt er een `index.php` in elke submap.
 */
function _ww_form_entry_dir( int $form_id, int $entry_id, bool $create = false ): string {
	$base = _ww_form_files_base( $create );
	if ( '' === $base ) {
		return '';
	}
	$form_dir  = $base . '/' . $form_id;
	$entry_dir = $form_dir . '/' . $entry_id;
	if ( $create ) {
		wp_mkdir_p( $entry_dir );
		// phpcs:disable WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- de eigen, afgeschermde map.
		foreach ( array( $form_dir, $entry_dir ) as $dir ) {
			if ( is_dir( $dir ) && ! file_exists( $dir . '/index.php' ) ) {
				file_put_contents( $dir . '/index.php', "<?php // Stil.\n" );
			}
		}
		// phpcs:enable
	}
	return $entry_dir;
}

/**
 * Is dit een bestand dat PHP zelf bij deze aanvraag heeft ontvangen? Een filter laat de tests het nabootsen.
 */
function _ww_form_is_uploaded( string $tmp ): bool {
	return (bool) apply_filters( '_ww_form_is_uploaded', is_uploaded_file( $tmp ), $tmp );
}

/**
 * Verplaatst een ontvangen bestand naar de bestemming en zet de rechten op 0644.
 *
 * Het filter `_ww_form_move_upload` laat de tests kopiëren; een andere uitkomst dan null vervangt `move_uploaded_file()`.
 */
function _ww_form_move_upload( string $tmp, string $dest ): bool {
	$filtered = apply_filters( '_ww_form_move_upload', null, $tmp, $dest );
	$moved    = null !== $filtered ? (bool) $filtered : move_uploaded_file( $tmp, $dest );
	if ( ! $moved ) {
		return false;
	}
	chmod( $dest, 0644 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.chmod_chmod -- rechten van het eigen bestand.
	return true;
}

/**
 * Slaat de gevalideerde bestanden op in de map van de inzending.
 *
 * @param int                                                                                       $form_id  Formulier.
 * @param int                                                                                       $entry_id Inzending.
 * @param array<string,list<array{name:string,tmp:string,ext:string,mime:string,size:int}>> $files    Sleutel => bestanden.
 * @return array<string,list<array{name:string,file:string,size:int,mime:string}>>|null Metadata per veld, of null als één bestand mislukt (dan is alles al verwijderd).
 */
function _ww_form_store_files( int $form_id, int $entry_id, array $files ): ?array {
	$dir = _ww_form_entry_dir( $form_id, $entry_id, true );
	if ( '' === $dir || ! is_dir( $dir ) ) {
		return null;
	}

	$stored = array();
	foreach ( $files as $key => $list ) {
		$stored[ $key ] = array();
		foreach ( $list as $file ) {
			$ext  = preg_replace( '/[^a-z0-9]/', '', strtolower( (string) $file['ext'] ) );
			$name = bin2hex( random_bytes( 16 ) ) . '.' . $ext;
			if ( ! _ww_form_move_upload( $file['tmp'], $dir . '/' . $name ) ) {
				_ww_form_delete_dir( $dir );
				return null;
			}
			$stored[ $key ][] = array(
				'name' => $file['name'],
				'file' => $name,
				'size' => (int) $file['size'],
				'mime' => $file['mime'],
			);
		}
	}
	return $stored;
}

/**
 * Verwijdert een map met inhoud, maar alleen als hij binnen de hoofdmap voor bestanden ligt.
 */
function _ww_form_delete_dir( string $dir ): void {
	$base = _ww_form_files_base();
	if ( '' === $base || ! is_dir( $dir ) ) {
		return;
	}
	$real_base = realpath( $base );
	$real_dir  = realpath( $dir );
	if ( false === $real_base || false === $real_dir ) {
		return;
	}
	// Eén scheidingsteken en een afsluitend teken, zodat `ww-forms-abc` niet `ww-forms-abcdef` toelaat.
	$real_base = rtrim( str_replace( '\\', '/', $real_base ), '/' ) . '/';
	$real_dir  = rtrim( str_replace( '\\', '/', $real_dir ), '/' ) . '/';
	if ( 0 !== strpos( $real_dir, $real_base ) ) {
		return;
	}
	_ww_page_cache_rmdir( $dir );
}

/**
 * Het pad van bestand `$n` van veld `$key` van een gedecodeerde inzending, of null.
 *
 * Het pad komt uit de metadata van de inzending, nooit uit de aanvraag; de naam moet aan het vaste patroon voldoen
 * en het bestand moet bestaan.
 */
function _ww_form_file_path( object $entry, string $key, int $n ): ?string {
	$meta = $entry->fields[ $key ]['value'][ $n ] ?? null;
	$file = is_array( $meta ) && is_string( $meta['file'] ?? null ) ? $meta['file'] : '';
	if ( 1 !== preg_match( '/^[0-9a-f]{32}\.[a-z0-9]{2,5}$/', $file ) ) {
		return null;
	}
	$dir = _ww_form_entry_dir( (int) $entry->form_id, (int) $entry->id );
	if ( '' === $dir ) {
		return null;
	}
	$path = $dir . '/' . $file;
	return is_file( $path ) ? $path : null;
}

/**
 * Verwijdert de bestanden van inzendingen: de map `{base}/{form_id}/{entry_id}` van elke inzending.
 *
 * Zoekt `form_id` op in de tabel, dus aanroepen vóórdat de rijen weg zijn.
 *
 * @param int[] $entry_ids Inzendingen.
 */
function _ww_form_delete_entry_files( array $entry_ids ): void {
	global $wpdb;
	$entry_ids = array_values( array_filter( array_map( 'absint', $entry_ids ) ) );
	if ( ! $entry_ids || '' === _ww_form_files_base() || ! _ww_forms_ready() ) {
		return;
	}
	foreach ( array_chunk( $entry_ids, 500 ) as $chunk ) {
		$placeholders = implode( ',', array_fill( 0, count( $chunk ), '%d' ) );
		$rows         = $wpdb->get_results( $wpdb->prepare( 'SELECT id, form_id FROM ' . _ww_form_entries_table() . " WHERE id IN ($placeholders)", $chunk ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- tabelnaam uit _ww_form_entries_table(), placeholders voor de ID's.
		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			$dir = _ww_form_entry_dir( (int) $row->form_id, (int) $row->id );
			if ( '' !== $dir ) {
				_ww_form_delete_dir( $dir );
			}
		}
	}
}

/**
 * Verwijdert mappen van inzendingen die niet meer in de tabel staan (achtergebleven na een fout) en lege
 * formuliermappen. Mapnamen die geen getal zijn worden overgeslagen. Doet niets zonder hoofdmap.
 *
 * @param int $limit Hoogstens zoveel inzendingsmappen per keer.
 * @return int Het aantal verwijderde inzendingsmappen.
 */
function _ww_form_files_cleanup_orphans( int $limit ): int {
	global $wpdb;
	$base = _ww_form_files_base();
	if ( '' === $base || ! is_dir( $base ) || $limit < 1 || ! _ww_forms_ready() ) {
		return 0;
	}
	$removed = 0;
	foreach ( glob( $base . '/*', GLOB_ONLYDIR ) ?: array() as $form_dir ) {
		if ( $removed >= $limit ) {
			break;
		}
		if ( 1 !== preg_match( '/^\d+$/', basename( $form_dir ) ) ) {
			continue;
		}
		foreach ( glob( $form_dir . '/*', GLOB_ONLYDIR ) ?: array() as $entry_dir ) {
			if ( $removed >= $limit ) {
				break;
			}
			if ( 1 !== preg_match( '/^\d+$/', basename( $entry_dir ) ) ) {
				continue;
			}
			$exists = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . _ww_form_entries_table() . ' WHERE id = %d', (int) basename( $entry_dir ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_form_entries_table().
			if ( '' !== $wpdb->last_error ) {
				return $removed; // De tabel is niet bereikbaar: niets verwijderen op een vermoeden.
			}
			if ( null === $exists ) {
				_ww_form_delete_dir( $entry_dir );
				++$removed;
			}
		}
		// Een formuliermap zonder inzendingsmappen (alleen index.php) is leeg.
		$left = array_diff( scandir( $form_dir ) ?: array(), array( '.', '..', 'index.php' ) );
		if ( ! $left ) {
			_ww_form_delete_dir( $form_dir );
		}
	}
	return $removed;
}

/**
 * De link waarmee een redacteur bestand `$n` van veld `$key` van een inzending downloadt.
 *
 * Bevat alleen de inzending, de veldsleutel en de index, plus een nonce; het pad komt pas bij het downloaden uit de
 * metadata van de inzending.
 */
function _ww_form_file_url( int $entry_id, string $key, int $n ): string {
	$url = add_query_arg(
		array(
			'action' => 'ww_form_file',
			'entry'  => $entry_id,
			'field'  => rawurlencode( $key ),
			'n'      => $n,
		),
		admin_url( 'admin-post.php' )
	);
	return wp_nonce_url( $url, 'ww_form_file_' . $entry_id );
}

/**
 * De waarde van de header `Content-Disposition` voor een download: `attachment` met de naam als `filename*` (UTF-8,
 * percent-gecodeerd) en een terugval met alleen veilige ASCII-tekens voor oude clients.
 */
function _ww_form_file_disposition( string $name ): string {
	$fallback = (string) preg_replace( '/[^A-Za-z0-9._ -]/', '_', $name );
	return 'attachment; filename="' . $fallback . '"; filename*=UTF-8\'\'' . rawurlencode( $name );
}

/**
 * Stuurt een bestand naar de browser en stopt.
 *
 * De actie `_ww_form_file_before_send` gaat vlak voor de headers; de tests onderscheppen hem om `exit` te voorkomen.
 */
function _ww_form_file_send( string $path, string $name, string $mime ): never {
	do_action( '_ww_form_file_before_send', $path, $name, $mime );
	// Open buffers (een plugin, een losse notice, zlib-compressie) zouden het bestand beschadigen of in het geheugen houden.
	while ( ob_get_level() > 0 ) {
		ob_end_clean();
	}
	nocache_headers();
	header( 'Content-Type: ' . $mime );
	header( 'Content-Disposition: ' . _ww_form_file_disposition( $name ) );
	header( 'X-Content-Type-Options: nosniff' );
	header( 'Content-Length: ' . (int) filesize( $path ) );
	readfile( $path );
	exit;
}

/**
 * Download van een bestand uit een inzending (`admin-post.php?action=ww_form_file`).
 *
 * Vereist `edit_others_pages` en de nonce `ww_form_file_{inzending}`. Het pad komt uit de metadata van de inzending,
 * nooit uit de aanvraag.
 */
function _ww_form_file_download(): void {
	if ( ! current_user_can( 'edit_others_pages' ) ) {
		wp_die( esc_html__( 'Je hebt geen rechten om dit bestand te downloaden.', 'webwerckt-base' ), 403 );
	}
	// phpcs:disable WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput -- de nonce wordt hieronder gecontroleerd; alleen getallen en een sleutel worden gebruikt.
	$entry_id = absint( _ww_data_to_string( wp_unslash( $_GET['entry'] ?? '' ) ) );
	$key      = sanitize_key( _ww_data_to_string( wp_unslash( $_GET['field'] ?? '' ) ) );
	$n        = absint( _ww_data_to_string( wp_unslash( $_GET['n'] ?? '' ) ) );
	// phpcs:enable
	check_admin_referer( 'ww_form_file_' . $entry_id );

	$entry = $entry_id > 0 ? _ww_form_entry_get( $entry_id ) : null;
	$path  = null === $entry ? null : _ww_form_file_path( $entry, $key, $n );
	if ( null === $entry || null === $path ) {
		wp_die( esc_html__( 'Dit bestand bestaat niet meer.', 'webwerckt-base' ), 404 );
	}
	$meta = $entry->fields[ $key ]['value'][ $n ];
	_ww_form_file_send( $path, _ww_data_to_string( $meta['name'] ?? '' ), _ww_data_to_string( $meta['mime'] ?? 'application/octet-stream' ) );
}
add_action( 'admin_post_ww_form_file', '_ww_form_file_download' );
