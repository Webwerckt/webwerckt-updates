<?php
/**
 * Meertalig door het thema (beslissing 0040): aanzetten, de optie ww_languages, de toestand en de boot.
 *
 * De module staat aan met het vinkje Meertalig (optie ww_languages_enabled, Instellingen > Algemeen). Met het vinkje uit
 * en zonder extra talen in de optie, of met een vertaalplugin actief, hangt het thema geen enkele hook uit
 * inc/languages*.php op, behalve het vinkje zelf (met een vertaalplugin ook de melding daarover), en geeft
 * ww_current_language() ''. Met het vinkje uit en wel extra
 * talen in de optie draait de uit-stand (_ww_languages_boot_off()).
 * De opslag, routing, links, beheer en SEO staan in de andere inc/languages-*.php; _ww_languages_boot() roept hun
 * _ww_languages_boot_*() aan.
 *
 * Optie ww_languages: { default: 'nl', languages: [ { code, locale, name, visible, bases?, tagline? } ], default_bases? }
 * (bases, tagline en default_bases: beslissing 0044).
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Of het vinkje Meertalig aan staat (optie ww_languages_enabled).
 */
function _ww_languages_enabled(): bool {
	return _ww_languages_option_stored( 'ww_languages_enabled' ) && (bool) get_option( 'ww_languages_enabled' );
}

/**
 * Of een optie van de module bestaat, zonder query: beide opties (ww_languages_enabled en ww_languages) worden altijd
 * met autoload aan geschreven, dus een optie die niet in alloptions staat, bestaat niet. Zo kost een site die
 * Meertalig nooit aanzette geen enkele query (get_option() op een ontbrekende optie vraagt de database).
 *
 * @param string $option ww_languages_enabled of ww_languages.
 */
function _ww_languages_option_stored( string $option ): bool {
	return isset( wp_load_alloptions()[ $option ] );
}

/**
 * Of een vertaalplugin actief is, herkend aan zijn versieconstante. Het thema werkt niet samen met vertaalplugins
 * (beslissing 0044); dit is het vangnet: dan doet de module niets en ziet de beheerder een melding
 * (_ww_languages_plugin_notice()). Het filter krijgt de uitkomst van de constantencheck en mag hem overschrijven.
 */
function _ww_languages_plugin_active(): bool {
	$active = defined( 'ICL_SITEPRESS_VERSION' ) || defined( 'POLYLANG_VERSION' ) || defined( 'TRP_PLUGIN_VERSION' );
	return (bool) apply_filters( 'ww_languages_plugin_active', $active );
}

/**
 * Of de module draait: het vinkje is aan, geen vertaalplugin en een geldige optie.
 */
function _ww_languages_active(): bool {
	return _ww_languages_enabled() && ! _ww_languages_plugin_active() && '' !== _ww_languages_config()['default'];
}

/**
 * Of de uit-stand geldt: het vinkje is uit, de optie heeft minstens een extra taal en er is geen vertaalplugin actief.
 * De bezoeker ziet dan een site in een taal; de vertalingen blijven bewaard.
 */
function _ww_languages_off_mode(): bool {
	if ( _ww_languages_enabled() || _ww_languages_plugin_active() ) {
		return false;
	}
	return array() !== _ww_extra_language_codes();
}

/**
 * Controleert een waarde voor de optie ww_languages en maakt hem schoon.
 *
 * Een extra taal zonder `visible` is verborgen; de standaardtaal is altijd zichtbaar. Per taal mogen `bases`
 * (post type- of taxonomienaam => vertaalde URL-basis) en `tagline` (de ondertitel) erbij, en op het hoogste niveau
 * `default_bases` (de basis van de standaardtaal na een set-default; beslissing 0044). Die staan er alleen in als ze
 * een waarde hebben; een ongeldige waarde valt weg zonder fout, zodat de module er niet door uitvalt. Onbekende
 * sleutels vallen weg.
 *
 * @param mixed $value Ruwe waarde, bijvoorbeeld uit het formulier of de optie.
 * @return array{default:string,languages:array<int,array{code:string,locale:string,name:string,visible:bool,bases?:array<string,string>,tagline?:string}>,default_bases?:array<string,string>}|WP_Error
 */
function _ww_languages_sanitize( mixed $value ): array|WP_Error {
	if ( ! is_array( $value ) || ! isset( $value['languages'] ) || ! is_array( $value['languages'] ) ) {
		return new WP_Error( 'ww_languages_invalid', __( 'De taalinstellingen hebben een ongeldige vorm.', 'webwerckt-base' ) );
	}

	$default = isset( $value['default'] ) && is_string( $value['default'] ) ? $value['default'] : '';
	$list    = array();
	$seen    = array();

	foreach ( $value['languages'] as $row ) {
		if ( ! is_array( $row ) ) {
			return new WP_Error( 'ww_languages_invalid', __( 'De taalinstellingen hebben een ongeldige vorm.', 'webwerckt-base' ) );
		}

		$code   = isset( $row['code'] ) && is_string( $row['code'] ) ? trim( $row['code'] ) : '';
		$locale = isset( $row['locale'] ) && is_string( $row['locale'] ) ? trim( $row['locale'] ) : '';
		$name   = isset( $row['name'] ) && is_string( $row['name'] ) ? trim( $row['name'] ) : '';

		if ( 1 !== preg_match( '/^[a-z]{2,3}(-[a-z]{2,4})?$/', $code ) ) {
			/* translators: %s: taalcode zoals die is ingevuld */
			return new WP_Error( 'ww_languages_code', sprintf( __( 'De taalcode "%s" is ongeldig. Gebruik 2 of 3 kleine letters, eventueel met een regio (pt-br).', 'webwerckt-base' ), $code ) );
		}
		if ( 1 !== preg_match( '/^[a-z]{2,3}(_[A-Z]{2})?(_[a-z0-9]+)?$/', $locale ) ) {
			/* translators: %s: locale zoals die is ingevuld */
			return new WP_Error( 'ww_languages_locale', sprintf( __( 'De locale "%s" is ongeldig. Gebruik bijvoorbeeld en_GB.', 'webwerckt-base' ), $locale ) );
		}
		if ( '' === $name || mb_strlen( $name ) > 50 ) {
			return new WP_Error( 'ww_languages_name', __( 'De naam van een taal is verplicht en hoogstens 50 tekens.', 'webwerckt-base' ) );
		}
		if ( isset( $seen[ $code ] ) ) {
			/* translators: %s: taalcode */
			return new WP_Error( 'ww_languages_duplicate', sprintf( __( 'De taalcode "%s" staat er twee keer in.', 'webwerckt-base' ), $code ) );
		}
		$seen[ $code ] = true;

		$visible = isset( $row['visible'] ) && filter_var( $row['visible'], FILTER_VALIDATE_BOOLEAN );
		$clean   = array(
			'code'    => $code,
			'locale'  => $locale,
			'name'    => $name,
			'visible' => $code === $default ? true : $visible,
		);
		$bases   = _ww_languages_sanitize_bases( $row['bases'] ?? null );
		if ( array() !== $bases ) {
			$clean['bases'] = $bases;
		}
		$tagline = isset( $row['tagline'] ) && is_string( $row['tagline'] ) ? sanitize_text_field( $row['tagline'] ) : '';
		if ( '' !== $tagline ) {
			$clean['tagline'] = $tagline;
		}
		$list[] = $clean;
	}

	if ( '' === $default || ! isset( $seen[ $default ] ) ) {
		return new WP_Error( 'ww_languages_default', __( 'De standaardtaal moet in de lijst met talen staan.', 'webwerckt-base' ) );
	}

	$result        = array(
		'default'   => $default,
		'languages' => $list,
	);
	$default_bases = _ww_languages_sanitize_bases( $value['default_bases'] ?? null );
	if ( array() !== $default_bases ) {
		$result['default_bases'] = $default_bases;
	}
	return $result;
}

/**
 * Maakt een lijst met URL-basissen schoon: naam (sanitize_key()) => basis (sanitize_title()). Een lege of ongeldige
 * waarde valt weg; geen array geeft een lege lijst.
 *
 * @param mixed $bases Ruwe waarde.
 * @return array<string,string>
 */
function _ww_languages_sanitize_bases( mixed $bases ): array {
	if ( ! is_array( $bases ) ) {
		return array();
	}
	$clean = array();
	foreach ( $bases as $name => $base ) {
		$name = sanitize_key( (string) $name );
		$base = is_string( $base ) ? sanitize_title( $base ) : '';
		if ( '' !== $name && '' !== $base ) {
			$clean[ $name ] = $base;
		}
	}
	return $clean;
}

/**
 * De gecontroleerde optie ww_languages; bij een ongeldige optie een lege configuratie.
 * Wordt vaak aangeroepen, dus het resultaat wordt onthouden zolang de ruwe optie gelijk blijft.
 *
 * @return array{default:string,languages:array<int,array{code:string,locale:string,name:string,visible:bool,bases?:array<string,string>,tagline?:string}>,default_bases?:array<string,string>}
 */
function _ww_languages_config(): array {
	static $raw    = null;
	static $result = array(
		'default'   => '',
		'languages' => array(),
	);

	$option = _ww_languages_option_stored( 'ww_languages' ) ? get_option( 'ww_languages', array() ) : array();
	if ( null !== $raw && $raw === $option ) {
		return $result;
	}

	$checked = _ww_languages_sanitize( $option );
	$raw     = $option;
	$result  = is_wp_error( $checked ) ? array(
		'default'   => '',
		'languages' => array(),
	) : $checked;
	return $result;
}

/**
 * Alle taalcodes, in volgorde.
 *
 * @return string[]
 */
function _ww_language_codes(): array {
	return array_column( _ww_languages_config()['languages'], 'code' );
}

/**
 * De extra talen: alles behalve de standaardtaal. Alleen die krijgen een voorvoegsel.
 *
 * @return string[]
 */
function _ww_extra_language_codes(): array {
	return array_values( array_diff( _ww_language_codes(), array( _ww_default_language() ) ) );
}

/**
 * De extra talen die een bezoeker kan bereiken: de zichtbare, en voor wie bewerkrechten heeft alle extra talen.
 * Gebruik dit, niet _ww_extra_language_codes(), voor alles wat een bezoeker ziet.
 *
 * @return string[]
 */
function _ww_routable_language_codes(): array {
	$editor = function_exists( 'current_user_can' ) && current_user_can( 'edit_posts' );
	$codes  = array();

	foreach ( _ww_languages_config()['languages'] as $language ) {
		if ( $language['code'] !== _ww_default_language() && ( $language['visible'] || $editor ) ) {
			$codes[] = $language['code'];
		}
	}
	return $codes;
}

/**
 * Code van de standaardtaal, of '' als er geen geldige optie is.
 */
function _ww_default_language(): string {
	return _ww_languages_config()['default'];
}

/**
 * De gegevens van één taal.
 *
 * @return array{code:string,locale:string,name:string,visible:bool,bases?:array<string,string>,tagline?:string}|null
 */
function _ww_language( string $code ): ?array {
	foreach ( _ww_languages_config()['languages'] as $language ) {
		if ( $language['code'] === $code ) {
			return $language;
		}
	}
	return null;
}

/**
 * De toestand van het huidige verzoek: `current` (taalcode), `original_uri` (het pad voor het voorvoegsel eraf ging) en
 * `old_slug` (post type en naam van een singulier verzoek dat in de taal van het verzoek niet bestond, voor de
 * oude-slug-redirect; zie _ww_languages_old_slug_restore()).
 *
 * @param bool $reset Zet de toestand terug (alleen voor de tests).
 * @return array{current:string,original_uri:string,old_slug:array{0:string,1:string}|null}
 */
function &_ww_languages_state( bool $reset = false ): array {
	static $state = array(
		'current'      => '',
		'original_uri' => '',
		'old_slug'     => null,
	);

	if ( $reset ) {
		$state = array(
			'current'      => '',
			'original_uri' => '',
			'old_slug'     => null,
		);
	}
	return $state;
}

/**
 * Hangt de onderdelen van de module op: alle als hij actief is (zie _ww_languages_active()), in de uit-stand alleen
 * _ww_languages_boot_off(). Elk onderdeel moet ook laat werken: wat op init hoort, doet het direct als init al geweest is.
 */
function _ww_languages_boot(): void {
	// Zonder een van beide opties is de module uit en is er geen uit-stand: niets ophangen en niets opvragen.
	if ( ! _ww_languages_option_stored( 'ww_languages_enabled' ) && ! _ww_languages_option_stored( 'ww_languages' ) ) {
		return;
	}
	if ( _ww_languages_active() ) {
		_ww_languages_boot_store();
		_ww_languages_boot_routing();
		_ww_languages_boot_links();
		_ww_languages_boot_admin();
		_ww_languages_boot_seo();
		_ww_languages_boot_sitemap();
		_ww_languages_boot_settings();
		_ww_languages_boot_menus();
		_ww_languages_boot_terms();
		_ww_languages_boot_bases();
		_ww_languages_boot_tagline();
	} elseif ( _ww_languages_off_mode() ) {
		_ww_languages_boot_off();
	}
}
add_action( 'after_setup_theme', '_ww_languages_boot', 1 );

/**
 * Schrijft het vinkje Meertalig. De bijwerkingen (optie aanmaken, flushen, cache legen) lopen via de hooks hieronder.
 */
function _ww_languages_set_enabled( bool $on ): void {
	update_option( 'ww_languages_enabled', $on ? 1 : 0, true );
}

/**
 * Wat bij elke wissel van het vinkje gebeurt. De eerste keer aan maakt de optie ww_languages met alleen de
 * standaardtaal uit get_locale() (code = het deel voor de _). Daarna flusht hij de rewrite rules en leegt de cache.
 */
function _ww_languages_switched( bool $on ): void {
	if ( $on && '' === _ww_languages_config()['default'] ) {
		$locale = (string) get_locale();
		$code   = strtolower( (string) strstr( $locale . '_', '_', true ) );
		if ( 1 !== preg_match( '/^[a-z]{2,3}$/', $code ) ) {
			$code   = 'nl';
			$locale = 'nl_NL';
		}
		$name  = function_exists( 'locale_get_display_language' ) ? ucfirst( (string) locale_get_display_language( $locale, $locale ) ) : '';
		$saved = _ww_languages_sanitize(
			array(
				'default'   => $code,
				'languages' => array(
					array(
						'code'    => $code,
						'locale'  => $locale,
						'name'    => '' !== $name ? $name : strtoupper( $code ),
						'visible' => true,
					),
				),
			)
		);
		if ( ! is_wp_error( $saved ) ) {
			update_option( 'ww_languages', $saved, true );
		}
	}

	flush_rewrite_rules( false );
	do_action( '_ww_purge_all' );
}

/**
 * Hook update_option_ww_languages_enabled: update_option roept hem alleen aan bij een echte wissel.
 *
 * @param mixed $old_value Oude waarde.
 * @param mixed $value     Nieuwe waarde.
 */
function _ww_languages_option_updated( $old_value, $value ): void {
	_ww_languages_switched( (bool) $value );
}
add_action( 'update_option_ww_languages_enabled', '_ww_languages_option_updated', 10, 2 );

/**
 * Hook add_option_ww_languages_enabled: de eerste keer dat het vinkje wordt opgeslagen. Alleen een aangezet vinkje
 * doet iets; de eerste keer opslaan met het vinkje uit flusht en leegt niets.
 *
 * @param string $option Naam van de optie.
 * @param mixed  $value  Waarde.
 */
function _ww_languages_option_added( $option, $value ): void {
	if ( ! $value ) {
		return;
	}
	_ww_languages_switched( true );
}
add_action( 'add_option_ww_languages_enabled', '_ww_languages_option_added', 10, 2 );

/**
 * Registreert de optie en het veld Meertalig onder Taal van de site (Instellingen > Algemeen). Hangt altijd, want
 * het vinkje wordt gezet als de module uit staat. Met een vertaalplugin actief hangt hij ook de melding daarover op.
 */
function _ww_languages_register_setting(): void {
	if ( _ww_languages_plugin_active() ) {
		add_action( 'admin_notices', '_ww_languages_plugin_notice' );
	}
	register_setting(
		'general',
		'ww_languages_enabled',
		array(
			'type'              => 'boolean',
			'default'           => false,
			'show_in_rest'      => false,
			'sanitize_callback' => '_ww_languages_sanitize_enabled',
		)
	);
	add_settings_field(
		'ww_languages_enabled',
		__( 'Meertalig', 'webwerckt-base' ),
		'_ww_languages_render_field',
		'general',
		'default'
	);
}
add_action( 'admin_init', '_ww_languages_register_setting' );

/**
 * Adminmelding voor een beheerder als er een vertaalplugin actief is: de module doet dan niets.
 */
function _ww_languages_plugin_notice(): void {
	if ( ! _ww_languages_plugin_active() || ! current_user_can( 'manage_options' ) ) {
		return;
	}
	printf( '<div class="notice notice-warning"><p>%s</p></div>', esc_html( _ww_languages_plugin_message() ) );
}

/**
 * De melding als er een vertaalplugin actief is (beslissing 0044).
 */
function _ww_languages_plugin_message(): string {
	return __( 'Een vertaalplugin is actief. Webwerckt Base werkt niet samen met vertaalplugins; zet Meertalig aan in Instellingen → Algemeen en schakel de plugin uit.', 'webwerckt-base' );
}

/**
 * Maakt de waarde van het vinkje schoon. Met een vertaalplugin actief is het veld uitgeschakeld en blijft de waarde staan.
 *
 * @param mixed $value Ruwe waarde uit het formulier.
 */
function _ww_languages_sanitize_enabled( $value ): int {
	if ( _ww_languages_plugin_active() ) {
		return (int) _ww_languages_enabled();
	}
	return filter_var( $value, FILTER_VALIDATE_BOOLEAN ) ? 1 : 0;
}

/**
 * Toont het vinkje, de uitleg en, in de uit-stand, de melding over de bewaarde vertalingen.
 */
function _ww_languages_render_field(): void {
	$plugin = _ww_languages_plugin_active();

	printf(
		'<label for="ww_languages_enabled"><input name="ww_languages_enabled" type="checkbox" id="ww_languages_enabled" value="1"%s%s /> %s</label>',
		checked( _ww_languages_enabled(), true, false ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- checked() geeft een vaste attribuutstring.
		$plugin ? ' disabled="disabled"' : '', // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- vaste string.
		esc_html__( 'Talen, vertalingen en een taalwisselaar. Daarna verschijnt het menu-item Talen.', 'webwerckt-base' )
	);

	if ( $plugin ) {
		// De melding met uitleg staat bovenaan de pagina (_ww_languages_plugin_notice()).
		return;
	}

	if ( _ww_languages_off_mode() ) {
		$count   = count( _ww_extra_language_codes() );
		$default = _ww_language( _ww_default_language() );
		echo '<p class="description">' . esc_html(
			sprintf(
				/* translators: 1: aantal talen, 2: naam van de standaardtaal */
				_n(
					'Er zijn vertalingen bewaard in %1$d taal. Bezoekers zien alleen %2$s. Zet Meertalig aan om ze terug te halen.',
					'Er zijn vertalingen bewaard in %1$d talen. Bezoekers zien alleen %2$s. Zet Meertalig aan om ze terug te halen.',
					$count,
					'webwerckt-base'
				),
				$count,
				$default ? $default['name'] : ''
			)
		) . '</p>';
	}
}

/**
 * De taal van dit verzoek (code), of '' als de module uit staat.
 */
function ww_current_language(): string {
	if ( ! _ww_languages_active() ) {
		return '';
	}
	$current = _ww_languages_state()['current'];
	return '' !== $current ? $current : _ww_default_language();
}

/**
 * Hangt het filter op de ondertitel op (alleen in de actieve boot).
 */
function _ww_languages_boot_tagline(): void {
	add_filter( 'option_blogdescription', '_ww_languages_option_tagline' );
}

/**
 * Filter option_blogdescription: in een extra taal op de frontend (en het kaarten-endpoint) de ondertitel van die taal,
 * of anders die van de standaardtaal. De admin, cron, WP-CLI en de standaardtaal zien de echte blogdescription
 * (_ww_settings_language() beslist, net als bij de instellingen). Werkt door in de titel van de homepage, het schema en
 * get_bloginfo( 'description' ) in een child-thema (beslissing 0044).
 *
 * @param mixed $value De opgeslagen ondertitel.
 * @return mixed
 */
function _ww_languages_option_tagline( mixed $value ): mixed {
	$lang = _ww_settings_language( null );
	if ( '' === $lang ) {
		return $value;
	}
	$language = _ww_language( $lang );
	$tagline  = null !== $language && isset( $language['tagline'] ) ? $language['tagline'] : '';
	return '' !== $tagline ? $tagline : $value;
}

/**
 * De ondertitel van een taal: voor een extra taal de eigen (leeg als die er niet is), voor de standaardtaal de echte
 * blogdescription, zonder het filter hierboven.
 *
 * @param string $code Taalcode.
 */
function _ww_language_tagline( string $code ): string {
	if ( _ww_default_language() !== $code ) {
		$language = _ww_language( $code );
		return null !== $language && isset( $language['tagline'] ) ? $language['tagline'] : '';
	}
	$hooked = has_filter( 'option_blogdescription', '_ww_languages_option_tagline' );
	if ( false !== $hooked ) {
		remove_filter( 'option_blogdescription', '_ww_languages_option_tagline' );
	}
	$value = _ww_data_to_string( get_option( 'blogdescription', '' ) );
	if ( false !== $hooked ) {
		add_filter( 'option_blogdescription', '_ww_languages_option_tagline' );
	}
	return $value;
}

/**
 * Slaat de ondertitel van een extra taal op (sanitize_text_field; leeg wist hem) en leegt de paginacache: de ondertitel
 * staat op elke pagina in die taal.
 *
 * @param string $lang    Code van een extra taal.
 * @param string $tagline De ondertitel.
 * @return true|WP_Error ww_languages_inactive, ww_languages_unknown of ww_language_default.
 */
function _ww_language_save_tagline( string $lang, string $tagline ): true|WP_Error {
	if ( ! _ww_languages_active() ) {
		return new WP_Error( 'ww_languages_inactive', __( 'Meertalig staat uit, of een vertaalplugin regelt de talen.', 'webwerckt-base' ) );
	}
	if ( null === _ww_language( $lang ) ) {
		/* translators: %s: taalcode */
		return new WP_Error( 'ww_languages_unknown', sprintf( __( 'De taal "%s" bestaat niet.', 'webwerckt-base' ), $lang ) );
	}
	if ( _ww_default_language() === $lang ) {
		return new WP_Error( 'ww_language_default', __( 'De ondertitel van de standaardtaal staat in Instellingen → Algemeen.', 'webwerckt-base' ) );
	}

	$config = _ww_languages_config();
	foreach ( $config['languages'] as $index => $language ) {
		if ( $language['code'] === $lang ) {
			$config['languages'][ $index ]['tagline'] = $tagline;
		}
	}
	$clean = _ww_languages_sanitize( $config );
	if ( $clean instanceof WP_Error ) {
		return $clean;
	}
	update_option( 'ww_languages', $clean, true );
	do_action( '_ww_purge_all' );
	return true;
}

/**
 * De uit-stand (het vinkje uit, wel extra talen in de optie): hier komt wat de parent dan nog doet. Dat is de taxonomie
 * ww_language registreren (functie uit inc/languages-store.php), het query-filter met de standaardtaal
 * (inc/languages-links.php) en de 404-check voor een bericht in een extra taal (inc/languages-routing.php). Geen
 * routing met voorvoegsel, linkfilters, hreflang, menu-item of metabox. Draait ook na init, dus wat op init hoort doet
 * hij direct als init al geweest is.
 *
 * Het query-filter, het opzoeken op naam en de 404-check kennen hier geen voorvoegsel: de taal van elk verzoek is de
 * standaardtaal. Zo geeft /contact/ de Nederlandse pagina, ook als de Engelse dezelfde slug heeft, en staan Engelse
 * berichten niet in lijsten, archieven en zoeken. De admin wordt niet gefilterd.
 */
function _ww_languages_boot_off(): void {
	_ww_languages_hook_taxonomy();
	add_filter( 'request', '_ww_languages_request' );
	_ww_languages_hook_wrong_language();
	_ww_languages_hook_query();
}

/**
 * De extra talen die een bezoeker ziet (visible true), los van de rechten van de huidige gebruiker. Voor uitvoer die in
 * de paginacache voor bezoekers kan komen: hreflang en og:locale:alternate.
 *
 * @return string[]
 */
function _ww_visible_language_codes(): array {
	$codes = array();
	foreach ( _ww_languages_config()['languages'] as $language ) {
		if ( $language['code'] !== _ww_default_language() && $language['visible'] ) {
			$codes[] = $language['code'];
		}
	}
	return $codes;
}

/**
 * De hoofdpagina van een taal (/ of /en/), uit het ruwe adres van de site, nooit uit het gefilterde home_url( '/' ).
 *
 * @param string $lang Taalcode; de standaardtaal of '' geeft de hoofdpagina zonder voorvoegsel.
 */
function _ww_languages_home( string $lang = '' ): string {
	// home_url() zonder pad krijgt geen voorvoegsel (zie het filter home_url); relink haalt er een eventueel toch af.
	return _ww_languages_relink( trailingslashit( _ww_languages_relink( home_url(), '' ) ), $lang );
}

/**
 * Het oorspronkelijke adres van dit verzoek, met het voorvoegsel en de querystring: schema en host van de site plus het
 * REQUEST_URI van vóór de routing.
 */
function _ww_languages_request_url(): string {
	// Beide komen uit $_SERVER, dat wp_magic_quotes() van slashes voorziet.
	$uri = _ww_languages_state()['original_uri'];
	if ( '' === $uri ) {
		$uri = isset( $_SERVER['REQUEST_URI'] ) && is_string( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/'; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- wordt een adres, dat de aanroeper escapet.
	}
	$uri = wp_unslash( $uri );
	$parts  = wp_parse_url( home_url() );
	$origin = is_array( $parts ) && isset( $parts['host'] ) ? ( $parts['scheme'] ?? 'http' ) . '://' . $parts['host'] . ( isset( $parts['port'] ) ? ':' . $parts['port'] : '' ) : '';
	return $origin . '/' . ltrim( (string) $uri, '/' );
}

/**
 * De vertaalgroep van de huidige pagina, of null als de pagina geen vertaalbaar object is (archief, zoeken, 404, een
 * homepage met berichten). Een bericht of pagina geeft zijn eigen groep, de voorpagina (ook /en/) dus die van de
 * voorpagina. De berichtenpagina geeft de groep van die pagina, want haar vertaling heeft een eigen slug. Zet de leden
 * en hun termen in de cache.
 *
 * @return array<string,int>|null
 */
function _ww_languages_current_group(): ?array {
	$post_id = 0;
	if ( is_singular() ) {
		$post_id = (int) get_queried_object_id();
	} elseif ( is_home() && ! is_front_page() ) {
		$post_id = _ww_languages_raw_page_option( 'page_for_posts' );
	}
	if ( $post_id <= 0 || '' === _ww_post_language( $post_id ) ) {
		return null;
	}
	$group = _ww_translations( $post_id );

	// De leden in één keer in de cache: één query voor de berichten en één voor hun termen, hoe groot de groep ook is.
	// Anders kost elk lid een query voor het bericht (de status) en een voor zijn taal (de linkfilters).
	$ids = array_values( array_unique( array_filter( $group ) ) );
	_prime_post_caches( $ids, false, false );
	update_object_term_cache( $ids, (string) get_post_type( $post_id ) );
	return $group;
}

/**
 * Het adres van de huidige pagina in elk van deze talen, met of het een echte vertaling is.
 *
 * - Een bericht of pagina (en de voorpagina): de gepubliceerde vertaling; zonder die de hoofdpagina van de taal, met
 *   translated false. Het huidige bericht zelf telt altijd (ook als concept in de preview).
 * - Anders (archief, term, zoeken, 404): het oorspronkelijke adres van het verzoek in die taal, met translated true. Een
 *   termarchief krijgt per taal de slug van die taal (_ww_languages_term_archive_urls()).
 *
 * @param string[] $codes Taalcodes.
 * @return array<string,array{url:string,translated:bool}>
 */
function _ww_languages_urls( array $codes ): array {
	$group   = _ww_languages_current_group();
	$current = is_singular() ? (int) get_queried_object_id() : 0;
	$request = null === $group ? _ww_languages_request_url() : '';
	// Een termarchief: per taal de slug van die taal (inc/languages-terms.php), met de querystring van het verzoek.
	$terms = null === $group ? _ww_languages_term_archive_urls( $codes ) : null;
	$query = null !== $terms ? (string) wp_parse_url( $request, PHP_URL_QUERY ) : '';
	$urls  = array();

	foreach ( $codes as $code ) {
		if ( null === $group ) {
			// Met de vertaalde URL-basis van elke taal (inc/languages-bases.php).
			$urls[ $code ] = array(
				'url'        => null !== $terms && isset( $terms[ $code ] ) ? _ww_language_base_swap( $terms[ $code ] . ( '' !== $query ? '?' . $query : '' ), $code ) : _ww_language_base_relink( $request, $code ),
				'translated' => true,
			);
			continue;
		}
		$id   = $group[ $code ] ?? 0;
		$link = $id > 0 && ( $id === $current || 'publish' === get_post_status( $id ) ) ? get_permalink( $id ) : false;
		if ( is_string( $link ) && '' !== $link ) {
			$urls[ $code ] = array(
				'url'        => $link,
				'translated' => true,
			);
			continue;
		}
		$urls[ $code ] = array(
			'url'        => _ww_languages_home( $code ),
			'translated' => false,
		);
	}
	return $urls;
}

/**
 * De talen voor een taalwisselaar, in volgorde: de standaardtaal en de extra talen die de gebruiker kan bereiken (een
 * verborgen taal alleen voor wie edit_posts heeft, met visible false). Elk met code, name, locale, url (de huidige
 * pagina in die taal), current en translated. Zonder module (ook in de uit-stand en met een vertaalplugin) array(), en ook
 * array() als de gebruiker minder dan twee talen kan bereiken (alleen de standaardtaal, of alle extra talen verborgen
 * voor een bezoeker): een site in één taal heeft geen taalwisselaar, dus `if ( $languages )` volstaat.
 *
 * @return array<int,array{code:string,name:string,locale:string,url:string,current:bool,translated:bool,visible:bool}>
 */
function ww_languages(): array {
	if ( ! _ww_languages_active() ) {
		return array();
	}
	$extra = _ww_routable_language_codes();
	if ( array() === $extra ) {
		return array();
	}
	$codes   = array_merge( array( _ww_default_language() ), $extra );
	$urls    = _ww_languages_urls( $codes );
	$current = ww_current_language();
	$list    = array();

	foreach ( _ww_languages_config()['languages'] as $language ) {
		if ( ! isset( $urls[ $language['code'] ] ) ) {
			continue;
		}
		$list[] = array(
			'code'       => $language['code'],
			'name'       => $language['name'],
			'locale'     => $language['locale'],
			'url'        => $urls[ $language['code'] ]['url'],
			'current'    => $language['code'] === $current,
			'translated' => $urls[ $language['code'] ]['translated'],
			'visible'    => $language['visible'],
		);
	}
	return $list;
}

/**
 * De ID van de gepubliceerde vertaling van een bericht in een taal, of 0. Ook voor een ingelogde redacteur alleen een
 * gepubliceerde, zodat de preview dezelfde links ziet als de bezoeker. Een verborgen taal geeft voor een bezoeker 0.
 * Zonder module 0.
 *
 * @param int    $id   Post-ID.
 * @param string $lang Taalcode.
 */
function ww_translation_id( int $id, string $lang ): int {
	if ( ! _ww_languages_active() || $id <= 0 ) {
		return 0;
	}
	if ( $lang !== _ww_default_language() && ! in_array( $lang, _ww_routable_language_codes(), true ) ) {
		return 0;
	}
	$target = _ww_translations( $id )[ $lang ] ?? 0;
	return $target > 0 && 'publish' === get_post_status( $target ) ? $target : 0;
}
