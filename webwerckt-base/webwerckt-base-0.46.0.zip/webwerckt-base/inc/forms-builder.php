<?php
/**
 * De builder in het bewerkscherm van een formulier (beslissing 0032): de metabox Formulier onder de titel, het opslaan
 * en de meldingen daarna. Plaatsen en de knoppen om op te slaan staan in het zijpaneel (inc/forms-panel.php).
 *
 * De builder zelf is assets/js/form-builder.js. Het script leest de configuratie uit het verborgen tekstvak
 * ww_form_config en schrijft hem daar na elke wijziging als JSON terug. Opslaan gaat met Bijwerken in het paneel:
 * save_post_ww_form controleert de nonce en het recht, en bewaart via _ww_form_save_config(), dus altijd door
 * ww_form_sanitize(). De server is leidend; wat de builder aan de voorkant doet (sleutels, toegestane tags) is
 * alleen gemak. De waarschuwingen van het opschonen komen eenmalig als melding na het herladen.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * De metabox Formulier onder de titel. Plaatsen staat als kaart in het zijpaneel (_ww_forms_render_place_card()).
 */
function _ww_form_builder_metabox(): void {
	add_meta_box( 'ww-form-builder', __( 'Formulier', 'webwerckt-base' ), '_ww_form_builder_render', WW_FORM_POST_TYPE, 'normal', 'high' );
}
add_action( 'add_meta_boxes_' . WW_FORM_POST_TYPE, '_ww_form_builder_metabox' );

/**
 * De metabox: de nonce, het verborgen tekstvak met de configuratie, de container voor het script en een melding
 * zonder JavaScript. Bovenaan, met Meertalig, de melding over velden die anders zijn dan in de standaardtaal (0043).
 *
 * @param WP_Post $post Het formulier.
 */
function _ww_form_builder_render( WP_Post $post ): void {
	$config = _ww_form_config( $post->ID ) ?? _ww_form_default_config();
	echo wp_kses_post( _ww_form_field_diff_notice( $post->ID ) );
	wp_nonce_field( 'ww_form_builder', 'ww_form_builder_nonce' );
	printf(
		'<textarea name="ww_form_config" id="ww-form-config" hidden>%s</textarea>',
		esc_textarea( (string) wp_json_encode( $config ) )
	);
	echo '<div id="ww-form-builder-app" class="ww-fb"></div>';
	printf(
		'<noscript><p class="ww-fb-noscript">%s</p></noscript>',
		esc_html__( 'De builder heeft JavaScript nodig. Zet JavaScript aan in je browser om dit formulier te bewerken.', 'webwerckt-base' )
	);
}

/**
 * Sleutel van de transient met de waarschuwingen, per formulier en gebruiker.
 *
 * @param int $post_id Formulier.
 */
function _ww_form_builder_warnings_key( int $post_id ): string {
	return 'ww_form_warnings_' . $post_id . '_' . get_current_user_id();
}

/**
 * Slaat de configuratie uit de builder op, bij Bijwerken of Publiceren.
 *
 * @param int $post_id Formulier.
 */
function _ww_form_builder_save( int $post_id ): void {
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
		return;
	}
	$nonce = isset( $_POST['ww_form_builder_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['ww_form_builder_nonce'] ) ) : '';
	if ( '' === $nonce || ! wp_verify_nonce( $nonce, 'ww_form_builder' ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	if ( WW_FORM_POST_TYPE !== get_post_type( $post_id ) || ! isset( $_POST['ww_form_config'] ) || ! is_string( $_POST['ww_form_config'] ) ) {
		return;
	}
	// De JSON wordt hieronder als geheel door ww_form_sanitize() opgeschoond; sanitize_text_field zou hem breken.
	$config = json_decode( wp_unslash( $_POST['ww_form_config'] ), true ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
	if ( ! is_array( $config ) ) {
		return; // Kapotte JSON: de bestaande configuratie blijft staan.
	}

	$warnings = _ww_form_save_config( $post_id, $config );
	$key      = _ww_form_builder_warnings_key( $post_id );
	if ( $warnings ) {
		set_transient( $key, $warnings, 60 );
	} else {
		delete_transient( $key );
	}
}
add_action( 'save_post_' . WW_FORM_POST_TYPE, '_ww_form_builder_save' );

/**
 * Toont de waarschuwingen van de laatste opslag één keer op het bewerkscherm van dat formulier.
 */
function _ww_form_builder_notice(): void {
	$screen = get_current_screen();
	$post   = get_post();
	if ( ! $screen instanceof WP_Screen || 'post' !== $screen->base || WW_FORM_POST_TYPE !== $screen->post_type || ! $post instanceof WP_Post ) {
		return;
	}
	$key      = _ww_form_builder_warnings_key( $post->ID );
	$warnings = get_transient( $key );
	if ( ! is_array( $warnings ) ) {
		return;
	}
	delete_transient( $key );
	foreach ( $warnings as $warning ) {
		printf( '<div class="notice notice-warning"><p>%s</p></div>', esc_html( _ww_form_string( $warning ) ) );
	}
}
add_action( 'admin_notices', '_ww_form_builder_notice' );

/**
 * De gepubliceerde pagina's voor Doorsturen naar, op titel.
 *
 * @return list<array{id: int, title: string}>
 */
function _ww_form_builder_pages(): array {
	$pages = get_posts(
		array(
			'post_type'      => 'page',
			'post_status'    => 'publish',
			'posts_per_page' => 500,
			'orderby'        => 'title',
			'order'          => 'ASC',
			'no_found_rows'  => true,
		)
	);
	$out   = array();
	foreach ( $pages as $page ) {
		$out[] = array(
			'id'    => $page->ID,
			'title' => _ww_plain_text( get_the_title( $page ) ),
		);
	}
	return $out;
}

/**
 * De veldtypen met hun naam in de builder, een dashicon en een korte uitleg voor het menu Veld toevoegen.
 *
 * @return array<string,array{name: string, icon: string, desc: string}>
 */
function _ww_form_builder_types(): array {
	return array(
		'line'     => array(
			'name' => __( 'Regel', 'webwerckt-base' ),
			'icon' => 'dashicons-editor-textcolor',
			'desc' => __( 'Eén regel: tekst, e-mailadres of telefoonnummer', 'webwerckt-base' ),
		),
		'text'     => array(
			'name' => __( 'Tekst', 'webwerckt-base' ),
			'icon' => 'dashicons-editor-paragraph',
			'desc' => __( 'Meerdere regels, voor een bericht of vraag', 'webwerckt-base' ),
		),
		'checkbox' => array(
			'name' => __( 'Vinkje', 'webwerckt-base' ),
			'icon' => 'dashicons-yes-alt',
			'desc' => __( 'Eén vinkje, bijvoorbeeld akkoord met de privacyverklaring', 'webwerckt-base' ),
		),
		'select'   => array(
			'name' => __( 'Keuzelijst', 'webwerckt-base' ),
			'icon' => 'dashicons-arrow-down-alt2',
			'desc' => __( 'Eén keuze uit een uitklaplijst', 'webwerckt-base' ),
		),
		'choice'   => array(
			'name' => __( 'Meerkeuze', 'webwerckt-base' ),
			'icon' => 'dashicons-editor-ul',
			'desc' => __( 'Rondjes of vinkjes onder elkaar', 'webwerckt-base' ),
		),
		'file'     => array(
			'name' => __( 'Bestand', 'webwerckt-base' ),
			'icon' => 'dashicons-paperclip',
			'desc' => __( 'Bezoekers sturen een of meer bestanden mee', 'webwerckt-base' ),
		),
	);
}

/**
 * Alle teksten van de builder, vertaalbaar. %s, %d en %1$s worden in het script ingevuld.
 *
 * @return array<string,string>
 */
function _ww_form_builder_texts(): array {
	return array(
		'tabs'              => __( 'Onderdelen van het formulier', 'webwerckt-base' ),
		'tabFields'         => __( 'Velden', 'webwerckt-base' ),
		'tabMail'           => __( 'Mail', 'webwerckt-base' ),
		'tabAfter'          => __( 'Na versturen', 'webwerckt-base' ),
		'tabStorage'        => __( 'Opslag', 'webwerckt-base' ),
		'sections'          => __( 'Onderdelen', 'webwerckt-base' ),
		'unsaved'           => __( 'Niet opgeslagen wijzigingen', 'webwerckt-base' ),

		'noFields'          => __( 'Nog geen velden. Voeg je eerste veld toe.', 'webwerckt-base' ),
		'addField'          => __( 'Veld toevoegen', 'webwerckt-base' ),
		'maxFields'         => __( 'Een formulier heeft hoogstens 50 velden.', 'webwerckt-base' ),
		'noLabel'           => __( '(nog geen label)', 'webwerckt-base' ),
		'requiredMark'      => __( 'verplicht', 'webwerckt-base' ),
		/* translators: %s: label van het veld. */
		'moveUp'            => __( '%s naar boven', 'webwerckt-base' ),
		/* translators: %s: label van het veld. */
		'moveDown'          => __( '%s naar beneden', 'webwerckt-base' ),
		/* translators: %s: label van het veld. */
		'remove'            => __( '%s verwijderen', 'webwerckt-base' ),
		/* translators: 1: label, 2: nieuwe plaats, 3: aantal. */
		'moved'             => __( '%1$s staat nu op plaats %2$s van %3$s.', 'webwerckt-base' ),
		/* translators: %s: label van het veld. */
		'removed'           => __( '%s is verwijderd.', 'webwerckt-base' ),
		'drag'              => __( 'Slepen om te verplaatsen', 'webwerckt-base' ),
		'edit'              => __( 'Bewerken', 'webwerckt-base' ),
		/* translators: %s: label van het veld. */
		'editField'         => __( '%s bewerken', 'webwerckt-base' ),
		/* translators: %s: naam van het veldtype. */
		'newField'          => __( 'Nieuw veld: %s', 'webwerckt-base' ),
		'close'             => __( 'Sluiten', 'webwerckt-base' ),
		'done'              => __( 'Klaar', 'webwerckt-base' ),
		'addThis'           => __( 'Toevoegen', 'webwerckt-base' ),
		'discard'           => __( 'Niet toevoegen', 'webwerckt-base' ),
		'removeField'       => __( 'Veld verwijderen', 'webwerckt-base' ),
		'removeAsk'         => __( 'Dit veld verwijderen? Bestaande inzendingen houden hun waarden.', 'webwerckt-base' ),
		'removeYes'         => __( 'Verwijderen', 'webwerckt-base' ),
		'cancel'            => __( 'Annuleren', 'webwerckt-base' ),
		'prevField'         => __( 'Vorig veld', 'webwerckt-base' ),
		'nextField'         => __( 'Volgend veld', 'webwerckt-base' ),
		/* translators: 1: plaats van het veld, 2: aantal velden. */
		'fieldNofM'         => __( 'Veld %1$d van %2$d', 'webwerckt-base' ),
		'order'             => __( 'Volgorde', 'webwerckt-base' ),
		'orderDone'         => __( 'Klaar met volgorde', 'webwerckt-base' ),
		'optionOne'         => __( '1 optie', 'webwerckt-base' ),
		/* translators: %d: aantal opties. */
		'optionsCount'      => __( '%d opties', 'webwerckt-base' ),

		'label'             => __( 'Label', 'webwerckt-base' ),
		'labelCheckbox'     => __( 'Tekst naast het vinkje', 'webwerckt-base' ),
		'labelCheckboxHelp' => __( 'Een link mag, bijvoorbeeld: Ik ga akkoord met de <a href="/privacy/">privacyverklaring</a>.', 'webwerckt-base' ),
		'tag'               => __( 'Tag voor de mail', 'webwerckt-base' ),
		'tagPending'        => __( 'De tag verschijnt zodra het veld een label heeft.', 'webwerckt-base' ),
		'tagHelp'           => __( 'De tag blijft gelijk, ook als je het label later wijzigt.', 'webwerckt-base' ),
		'copy'              => __( 'Kopiëren', 'webwerckt-base' ),
		/* translators: %s: de tag, bijvoorbeeld {naam}. */
		'copyTag'           => __( '%s kopiëren', 'webwerckt-base' ),
		'copied'            => __( 'Gekopieerd', 'webwerckt-base' ),
		'required'          => __( 'Verplicht', 'webwerckt-base' ),
		'help'              => __( 'Hulptekst onder het veld', 'webwerckt-base' ),
		'placeholder'       => __( 'Voorbeeldtekst in het veld (placeholder)', 'webwerckt-base' ),
		'input'             => __( 'Soort invoer', 'webwerckt-base' ),
		'inputText'         => __( 'Tekst', 'webwerckt-base' ),
		'inputEmail'        => __( 'E-mailadres', 'webwerckt-base' ),
		'inputTel'          => __( 'Telefoonnummer', 'webwerckt-base' ),
		'maxLength'         => __( 'Hoogstens zoveel tekens', 'webwerckt-base' ),
		'emptyOption'       => __( 'Eerste, lege keuze', 'webwerckt-base' ),
		'emptyOptionHelp'   => __( 'Laat leeg als er geen lege eerste keuze moet zijn.', 'webwerckt-base' ),
		'emptyOptionText'   => __( 'Maak een keuze', 'webwerckt-base' ),
		'multiple'          => __( 'Meer dan één keuze toestaan (vinkjes in plaats van rondjes)', 'webwerckt-base' ),
		'options'           => __( 'Opties', 'webwerckt-base' ),
		'noOptions'         => __( 'Nog geen opties.', 'webwerckt-base' ),
		'addOption'         => __( 'Optie toevoegen', 'webwerckt-base' ),
		'maxOptions'        => __( 'Een veld heeft hoogstens 100 opties.', 'webwerckt-base' ),
		/* translators: %s: nummer van de optie. */
		'optionLabel'       => __( 'Optie %s', 'webwerckt-base' ),
		'optionValue'       => __( 'Waarde', 'webwerckt-base' ),
		'submitLabel'       => __( 'Tekst op de verzendknop', 'webwerckt-base' ),
		'fileAccept'        => __( 'Soorten bestanden', 'webwerckt-base' ),
		'fileMaxSize'       => __( 'Hoogstens zoveel MB per bestand', 'webwerckt-base' ),
		/* translators: %d: grootste bestand in MB dat de server aanneemt. */
		'fileServerMax'     => __( 'De server staat hoogstens %d MB toe', 'webwerckt-base' ),
		'fileMaxFiles'      => __( 'Hoogstens zoveel bestanden', 'webwerckt-base' ),
		'fileMaxFilesHelp'  => __( 'Tussen 1 en 5.', 'webwerckt-base' ),

		'step'              => __( 'Stap', 'webwerckt-base' ),
		/* translators: %d: nummer van de stap */
		'stepN'             => __( 'Stap %d', 'webwerckt-base' ),
		'stepTitle'         => __( 'Titel', 'webwerckt-base' ),
		'stepEmpty'         => __( 'Deze stap heeft geen velden en wordt niet opgeslagen.', 'webwerckt-base' ),
		/* translators: 1: naam van de stap, 2: aantal stappen. */
		'stepAdded'         => __( '%1$s is onderaan toegevoegd. Het formulier heeft nu %2$d stappen.', 'webwerckt-base' ),
		/* translators: %s: naam van de stap. */
		'stepRemoved'       => __( '%s is verwijderd. De velden horen nu bij de stap erboven.', 'webwerckt-base' ),
		/* translators: %s: naam van de stap. */
		'stepsRemoved'      => __( '%s is verwijderd. Het formulier heeft geen stappen meer.', 'webwerckt-base' ),

		'notify'            => __( 'Melding aan jou', 'webwerckt-base' ),
		'notifyEnabled'     => __( 'Bij elke inzending een mail sturen', 'webwerckt-base' ),
		'notifyTo'          => __( 'Aan', 'webwerckt-base' ),
		'notifyToHelp'      => __( 'Meerdere adressen scheiden met een komma. Leeg: het e-mailadres uit de Site-instellingen.', 'webwerckt-base' ),
		'replyTo'           => __( 'Antwoorden gaan naar', 'webwerckt-base' ),
		'replyToNone'       => __( 'Het standaardadres', 'webwerckt-base' ),
		'confirm'           => __( 'Bevestiging aan de inzender', 'webwerckt-base' ),
		'confirmEnabled'    => __( 'De inzender een bevestiging sturen', 'webwerckt-base' ),
		'confirmTo'         => __( 'Naar het adres uit', 'webwerckt-base' ),
		'confirmToNone'     => __( 'Kies een veld', 'webwerckt-base' ),
		'confirmNoEmail'    => __( 'Voeg eerst een verplicht veld toe van het type Regel met als invoer E-mailadres.', 'webwerckt-base' ),
		'confirmLimit'      => __( 'Iedereen kan hier elk adres invullen. Daarom kun je in de bevestiging alleen tags gebruiken waarvan de inhoud vastligt; een regel tekst wordt ingekort tot 40 tekens.', 'webwerckt-base' ),
		'subject'           => __( 'Onderwerp', 'webwerckt-base' ),
		'body'              => __( 'Bericht', 'webwerckt-base' ),
		'insert'            => __( 'Veld invoegen', 'webwerckt-base' ),
		/* translators: %s: Onderwerp of Bericht. */
		'insertIn'          => __( 'Veld invoegen in %s', 'webwerckt-base' ),
		/* translators: %s: de tag, bijvoorbeeld {naam}. */
		'inserted'          => __( '%s ingevoegd.', 'webwerckt-base' ),
		'tagAll'            => __( 'Alle velden', 'webwerckt-base' ),
		'tagForm'           => __( 'Naam van het formulier', 'webwerckt-base' ),
		'tagSite'           => __( 'Naam van de site', 'webwerckt-base' ),
		'tagDate'           => __( 'Datum en tijd', 'webwerckt-base' ),
		'tagPage'           => __( 'Pagina van het formulier', 'webwerckt-base' ),
		'tagShort'          => __( 'hoogstens 40 tekens', 'webwerckt-base' ),
		'confirmRecaptcha'  => __( 'Zonder geslaagde reCAPTCHA-controle blijven sommige tags leeg.', 'webwerckt-base' ),

		'afterType'         => __( 'Wat ziet de bezoeker na het versturen?', 'webwerckt-base' ),
		'afterMessage'      => __( 'Een bedankbericht', 'webwerckt-base' ),
		'afterRedirect'     => __( 'Een andere pagina', 'webwerckt-base' ),
		'message'           => __( 'Bedankbericht', 'webwerckt-base' ),
		'messageHelp'       => __( 'Een link, vet en cursief mogen, met <a href="…">, <strong> en <em>.', 'webwerckt-base' ),
		'page'              => __( 'Pagina', 'webwerckt-base' ),
		'pageNone'          => __( 'Geen pagina, gebruik de URL', 'webwerckt-base' ),
		/* translators: %s: ID van de pagina. */
		'pageUnpublished'   => __( 'Pagina %s (niet gepubliceerd)', 'webwerckt-base' ),
		'url'               => __( 'Of een URL', 'webwerckt-base' ),
		'urlHelp'           => __( 'Een volledige URL (https://…) of een pad zoals /bedankt/. Geldt alleen als er geen pagina gekozen is.', 'webwerckt-base' ),

		'store'             => __( 'Inzendingen opslaan', 'webwerckt-base' ),
		'storeHelp'         => __( 'Uitzetten verwijdert bestaande inzendingen niet; die worden opgeruimd na de bewaartermijn. Zonder opslag moet de melding aan staan, anders gaat een inzending verloren.', 'webwerckt-base' ),
		'retention'         => __( 'Bewaartermijn in maanden', 'webwerckt-base' ),
		'retentionHelp'     => __( 'Tussen 1 en 120. Oudere inzendingen worden elke dag verwijderd.', 'webwerckt-base' ),
		'storeFile'         => __( 'Formulieren met een uploadveld slaan inzendingen altijd op.', 'webwerckt-base' ),
		'recaptcha'         => __( 'reCAPTCHA gebruiken', 'webwerckt-base' ),
		'recaptchaMissing'  => __( 'reCAPTCHA is niet ingesteld.', 'webwerckt-base' ),
		'recaptchaSettings' => __( 'Stel eerst de sleutels in.', 'webwerckt-base' ),
	);
}

/**
 * De gegevens voor het script (window.wwFormBuilder). De link naar Instellingen krijgt alleen een beheerder; de
 * sleutels zelf gaan nooit mee, alleen of ze er zijn.
 *
 * @param array<string,mixed>|null $config Opgeslagen configuratie, of null voor een nieuw formulier.
 * @return array<string,mixed>
 */
function _ww_form_builder_data( ?array $config ): array {
	return array(
		// Terugval; het script leest de configuratie uit het tekstvak ww_form_config, dat na een wijziging leidend is.
		'config'              => $config ?? _ww_form_default_config(),
		'types'               => _ww_form_builder_types(),
		'pages'               => _ww_form_builder_pages(),
		'builtinTags'         => _ww_form_builtin_tags(),
		'confirmBuiltin'      => array_keys( _ww_form_confirm_allowed( array( 'fields' => array() ) ) ),
		'fileGroups'          => _ww_form_file_groups(),
		'fileMaxMb'           => _ww_form_file_max_mb(),
		// Zoals ww_form_sanitize(): hoogstens 10 stappen.
		'maxSteps'            => 10,
		'recaptchaConfigured' => _ww_form_recaptcha_configured(),
		'settingsUrl'         => current_user_can( 'manage_options' ) ? _ww_forms_settings_url() : '',
		'texts'               => _ww_form_builder_texts(),
	);
}

/**
 * Laadt de builder, alleen op het bewerkscherm van een formulier.
 *
 * @param string $hook Admin-scherm.
 */
function _ww_form_builder_assets( string $hook ): void {
	$screen = get_current_screen();
	if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) || ! $screen instanceof WP_Screen || WW_FORM_POST_TYPE !== $screen->post_type ) {
		return;
	}
	$post = get_post();
	$data = _ww_form_builder_data( $post instanceof WP_Post ? _ww_form_config( $post->ID ) : null );
	wp_enqueue_style( 'ww-form-builder', _ww_asset_url( 'css/form-builder.css' ), array(), WW_BASE_VERSION );
	wp_enqueue_script( 'ww-form-builder', _ww_asset_url( 'js/form-builder.js' ), array(), WW_BASE_VERSION, array( 'in_footer' => true ) );
	wp_add_inline_script( 'ww-form-builder', 'window.wwFormBuilder = ' . wp_json_encode( $data ) . ';', 'before' );
}
add_action( 'admin_enqueue_scripts', '_ww_form_builder_assets' );
