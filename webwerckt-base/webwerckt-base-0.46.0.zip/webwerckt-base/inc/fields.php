<?php
/**
 * De veldlaag van de abilities (inc/abilities.php), Visueel bewerken (inc/editor.php), het bewerkscherm, de
 * Site-instellingen en de termschermen: welke velden een bericht en de Site-instellingen hebben, hun waarde als gewone
 * waarde, de controle van nieuwe waarden en het opslaan (ook van de termvelden van een taxonomie-pod).
 *
 * - Een bericht krijgt alleen de velden die in de admin bij zijn paginatemplate staan, de Site-instellingen alleen
 *   de velden die de gebruiker mag bewerken. Velden met restrict_capability vallen weg, net als op het bewerkscherm
 *   en de Site-instellingen.
 * - Onbekende velden, verkeerde waarden en lege verplichte velden worden geweigerd, nog voordat er iets is opgeslagen.
 *   Eigen controles haken in op het filter ww_field_validate (zoals de openingstijden in inc/contact.php).
 * - Schrijven loopt via de opslaglaag van het thema (inc/field-store.php), byte voor byte zoals Pods.
 *
 * De foutcodes beginnen met ww_abilities_: ze zijn deel van de antwoorden van de abilities (semver).
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * Welke velden.
 */

/**
 * Velden van een bericht bij zijn template, op naam.
 *
 * @return array<string,array<string,mixed>>
 */
function _ww_fields_for_post( WP_Post $post ): array {
	$fields = array_filter( _ww_pods_fields( $post->post_type, $post->ID ), static fn( array $field ): bool => ! _ww_field_restricted( $field ) );
	return array_column( $fields, null, 'name' );
}

/**
 * Velden van de Site-instellingen die de gebruiker mag bewerken, op naam. Elk veld heeft zijn instellingen-pod als
 * `pod` en het label van zijn groep als `group`.
 *
 * @return array<string,array<string,mixed>>
 */
function _ww_fields_for_settings(): array {
	$allowed = current_user_can( 'edit_theme_options' ) || current_user_can( 'ww_edit_settings' );
	$fields  = array_filter(
		_ww_pods_setting_fields(),
		static fn( array $field ): bool => $allowed && ! _ww_field_restricted( $field )
	);
	return array_column( $fields, null, 'name' );
}

/**
 * Is dit veld afgeschermd voor de huidige gebruiker? Pods kent per veld restrict_capability met capability_allowed
 * (een of meer rechten, gescheiden door komma's; één ervan is genoeg). Pods verbergt zo'n veld in zijn eigen
 * schermen; de abilities en de editor gebruiken dit om hetzelfde te doen.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 */
function _ww_field_restricted( array $field ): bool {
	if ( 1 !== (int) ( $field['restrict_capability'] ?? 0 ) ) {
		return false;
	}
	$caps = array_filter( array_map( 'trim', explode( ',', _ww_data_to_string( $field['capability_allowed'] ?? '' ) ) ) );
	foreach ( $caps as $cap ) {
		if ( current_user_can( $cap ) ) {
			return false;
		}
	}
	return true;
}

/*
 * Soorten velden.
 */

/**
 * Is dit veld er een met meerdere waarden (relatie, meerkeuze of bestanden)? Andere soorten hebben altijd één waarde.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 */
function _ww_fields_is_multi( array $field ): bool {
	$type = $field['type'] ?? '';
	if ( 'pick' === $type ) {
		return 'multi' === ( $field['pick_format_type'] ?? 'single' );
	}
	return 'file' === $type && 'multi' === ( $field['file_format_type'] ?? 'single' );
}

/**
 * Is dit veld een meerkeuze met een vaste lijst (pick met pick_object custom-simple)?
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 */
function _ww_field_is_choice( array $field ): bool {
	return 'pick' === ( $field['type'] ?? '' ) && 'custom-simple' === ( $field['pick_object'] ?? '' );
}

/**
 * De keuzes van een meerkeuze: waarde => label, uit `pick_custom`.
 *
 * Elke regel is `waarde|label`, of alleen `waarde` (het label is dan gelijk). Lege regels vallen weg. pick_custom is
 * tekst met een regel per keuze, of een lijst met regels. Let op: PHP maakt van een waarde als "7" een sleutel 7;
 * cast een sleutel naar tekst als je hem teruggeeft.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @return array<string,string>
 */
function _ww_field_choices( array $field ): array {
	$custom  = $field['pick_custom'] ?? '';
	$lines   = is_array( $custom ) ? array_map( '_ww_data_to_string', $custom ) : ( preg_split( '/\R/', _ww_data_to_string( $custom ) ) ?: array() );
	$choices = array();
	foreach ( $lines as $line ) {
		$parts = explode( '|', trim( $line ), 2 );
		$value = trim( $parts[0] );
		if ( '' === $value ) {
			continue;
		}
		$choices[ $value ] = isset( $parts[1] ) && '' !== trim( $parts[1] ) ? trim( $parts[1] ) : $value;
	}
	return $choices;
}

/**
 * Het formaat waarin een datum, tijd of datum met tijd wordt opgeslagen (zoals Pods), of '' voor een andere soort.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 */
function _ww_field_date_format( array $field ): string {
	$formats = array(
		'date'     => 'Y-m-d',
		'time'     => 'H:i:s',
		'datetime' => 'Y-m-d H:i:s',
	);
	return $formats[ _ww_data_to_string( $field['type'] ?? '' ) ] ?? '';
}

/**
 * Is dit veld een relatie met berichten (pick met pick_object post_type)?
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 */
function _ww_field_is_post_relation( array $field ): bool {
	return 'pick' === ( $field['type'] ?? '' ) && 'post_type' === ( $field['pick_object'] ?? '' );
}

/**
 * Is dit veld een relatie met termen (pick met pick_object taxonomy; pick_val is de taxonomie)?
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 */
function _ww_field_is_term_relation( array $field ): bool {
	return 'pick' === ( $field['type'] ?? '' ) && 'taxonomy' === ( $field['pick_object'] ?? '' );
}

/**
 * Is dit veld een relatie die het thema bewerkt: met berichten of met termen? Pods kent ook relaties met gebruikers
 * en meer; die blijven ongemoeid.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 */
function _ww_field_is_relation( array $field ): bool {
	return _ww_field_is_post_relation( $field ) || _ww_field_is_term_relation( $field );
}

/**
 * Bewerkt de veldlaag dit soort veld (de abilities, en Visueel bewerken voor de velden van een bericht en de
 * Site-instellingen)? Alles behalve een relatie met iets anders dan berichten of termen (zoals gebruikers).
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 */
function _ww_field_layer_supports( array $field ): bool {
	return 'pick' !== ( $field['type'] ?? '' ) || _ww_field_is_choice( $field ) || _ww_field_is_relation( $field );
}

/**
 * Bestaat deze term in deze taxonomie?
 */
function _ww_is_relatable_term( int $term_id, string $taxonomy ): bool {
	return $term_id > 0 && '' !== $taxonomy && get_term( $term_id, $taxonomy ) instanceof WP_Term;
}

/**
 * Mag dit bericht in een relatie met dit post type staan? Het bestaat, heeft dat type en ligt niet in de prullenbak.
 *
 * @param mixed $post Bericht, bijvoorbeeld uit get_post().
 */
function _ww_is_relatable_post( $post, string $post_type ): bool {
	return $post instanceof WP_Post && $post_type === $post->post_type && 'trash' !== $post->post_status;
}

/*
 * Lezen.
 */

/**
 * Opgeslagen waarde als gewone waarde: ID's voor relaties en foto's, de gekozen waarde (tekst, of een lijst met
 * tekst bij meerdere) voor een meerkeuze, bool voor ja/nee, anders tekst. Een lege datum van Pods (0000-00-00,
 * 0000-00-00 00:00:00) is ''.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @param mixed               $raw   Opgeslagen waarde.
 * @return mixed
 */
function _ww_fields_value( array $field, $raw ) {
	$type = _ww_data_to_string( $field['type'] ?? '' );
	if ( _ww_field_is_choice( $field ) ) {
		if ( _ww_fields_is_multi( $field ) ) {
			return _ww_fields_choice_list( $raw );
		}
		return _ww_data_to_string( is_array( $raw ) ? reset( $raw ) : $raw );
	}
	if ( '' !== _ww_field_date_format( $field ) ) {
		$value = _ww_data_to_string( $raw );
		return in_array( $value, array( '0000-00-00', '0000-00-00 00:00:00' ), true ) ? '' : $value;
	}
	if ( 'pick' === $type || 'file' === $type ) {
		$ids = _ww_data_to_ids( $raw );
		return _ww_fields_is_multi( $field ) ? $ids : ( $ids[0] ?? 0 );
	}
	if ( 'boolean' === $type ) {
		return _ww_data_to_bool( $raw );
	}
	return _ww_data_to_string( $raw );
}

/**
 * De opgeslagen keuzes van een meerkeuze als lijst met tekst. Een bericht heeft een rij per keuze (één rij geeft
 * tekst), een instelling een lijst of bij één keuze tekst; een losse tekst met komma's telt ook (zoals de oude optie
 * van de sitemap). Lege waarden vallen weg: Pods slaat een lege meerkeuze op als één lege rij.
 *
 * @param mixed $raw Opgeslagen waarde.
 * @return string[]
 */
function _ww_fields_choice_list( $raw ): array {
	$list = is_array( $raw ) ? $raw : explode( ',', _ww_data_to_string( $raw ) );
	return array_values( array_filter( array_map( static fn( $item ): string => trim( _ww_data_to_string( $item ) ), $list ), static fn( string $item ): bool => '' !== $item ) );
}

/**
 * Een veld met label, type en waarde. Bij een relatie, meerkeuze of bestand ook of het meerdere waarden heeft, bij
 * een meerkeuze de keuzes (lijst met value en label), bij een relatie met termen de taxonomie (taxonomy) en bij een
 * datum of tijd het formaat van de waarde. De abilities
 * en de editor vullen dit aan met wat zij nodig hebben.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @param mixed               $raw   Opgeslagen waarde.
 * @return array<string,mixed>
 */
function _ww_fields_describe( array $field, $raw ): array {
	$item = array(
		'label' => _ww_data_to_string( $field['label'] ?? '' ),
		'type'  => _ww_data_to_string( $field['type'] ?? '' ),
		'value' => _ww_fields_value( $field, $raw ),
	);
	if ( in_array( $item['type'], array( 'pick', 'file' ), true ) ) {
		$item['multiple'] = _ww_fields_is_multi( $field );
	}
	if ( _ww_field_is_term_relation( $field ) ) {
		$item['taxonomy'] = _ww_data_to_string( $field['pick_val'] ?? '' );
	}
	if ( _ww_field_is_choice( $field ) ) {
		$item['choices'] = array();
		foreach ( _ww_field_choices( $field ) as $value => $label ) {
			$item['choices'][] = array(
				'value' => (string) $value,
				'label' => $label,
			);
		}
	}
	$format = _ww_field_date_format( $field );
	if ( '' !== $format ) {
		$item['format'] = $format;
	}
	return $item;
}

/*
 * Controleren.
 */

/**
 * ID's uit de invoer van een relatie- of bestandsveld, of een fout.
 *
 * @param mixed $value Invoer: één ID, een lijst met ID's, of leeg.
 * @param bool  $terms Een relatie met termen (andere foutmelding).
 * @return int[]|WP_Error
 */
function _ww_fields_input_ids( $value, bool $terms = false ) {
	if ( null === $value || '' === $value ) {
		return array();
	}
	$list = is_array( $value ) ? $value : array( $value );
	$ids  = array();
	foreach ( $list as $id ) {
		if ( ! is_int( $id ) && ! ( is_string( $id ) && ctype_digit( $id ) ) ) {
			return new WP_Error( 'ww_abilities_value', $terms ? __( 'Verwacht een term-ID of een lijst met term-ID\'s.', 'webwerckt-base' ) : __( 'Verwacht een post-ID of een lijst met post-ID\'s.', 'webwerckt-base' ) );
		}
		$ids[] = (int) $id;
	}
	return array_values( array_unique( array_filter( $ids ) ) );
}

/**
 * Fout als een ID niet het verwachte soort bericht is, anders null.
 *
 * @param int[]  $ids       Post-ID's.
 * @param string $post_type Verwacht post type ('attachment' voor bestanden).
 * @param bool   $images    Alleen afbeeldingen.
 */
function _ww_fields_ids_error( array $ids, string $post_type, bool $images ): ?WP_Error {
	foreach ( $ids as $id ) {
		$post = get_post( $id );
		if ( ! _ww_is_relatable_post( $post, $post_type ) || ( $images && ! wp_attachment_is_image( $post ) ) ) {
			/* translators: 1: post-ID, 2: verwacht soort bericht. */
			return new WP_Error( 'ww_abilities_value', sprintf( __( 'ID %1$d is geen %2$s.', 'webwerckt-base' ), $id, $images ? 'afbeelding' : $post_type ) );
		}
	}
	return null;
}

/**
 * Fout als een ID geen term van deze taxonomie is, anders null.
 *
 * @param int[] $ids Term-ID's.
 */
function _ww_fields_term_ids_error( array $ids, string $taxonomy ): ?WP_Error {
	foreach ( $ids as $id ) {
		if ( ! _ww_is_relatable_term( $id, $taxonomy ) ) {
			/* translators: 1: term-ID, 2: taxonomie. */
			return new WP_Error( 'ww_abilities_value', sprintf( __( 'ID %1$d is geen term van %2$s.', 'webwerckt-base' ), $id, $taxonomy ) );
		}
	}
	return null;
}

/**
 * De opties van een keuzelijst met eigen opties: waarde => label. Doorgever van _ww_field_choices().
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @return array<string,string>
 */
function _ww_fields_custom_options( array $field ): array {
	return _ww_field_choices( $field );
}

/**
 * Een meerkeuze gecontroleerd: één keuze als tekst ('' is leeg), of bij meerdere een lijst met keuzes zonder dubbele
 * (een losse tekst is een lijst van één); anders een fout.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @param mixed               $value Invoer.
 * @return string|string[]|WP_Error
 */
function _ww_fields_input_choice( array $field, $value ) {
	$multi = _ww_fields_is_multi( $field );
	if ( null === $value || '' === $value ) {
		return $multi ? array() : '';
	}
	$list = $multi && is_array( $value ) ? array_values( $value ) : array( $value );
	if ( ! $multi && is_array( $value ) ) {
		return new WP_Error( 'ww_abilities_value', __( 'Kies een van de opties.', 'webwerckt-base' ) );
	}
	$choices = _ww_field_choices( $field );
	foreach ( $list as $choice ) {
		if ( ! is_string( $choice ) || ! isset( $choices[ $choice ] ) ) {
			/* translators: %s: de toegestane waarden. */
			return new WP_Error( 'ww_abilities_value', sprintf( __( 'Kies uit de opties: %s.', 'webwerckt-base' ), implode( ', ', array_map( 'strval', array_keys( $choices ) ) ) ) );
		}
	}
	return $multi ? array_values( array_unique( $list ) ) : $list[0];
}

/**
 * Een datum, tijd of datum met tijd gecontroleerd en in het formaat van Pods ('' is leeg), of een fout. Een tijd mag
 * zonder seconden (09:30 wordt 09:30:00); een datum met tijd mag een T als scheiding hebben, zoals
 * <input type="datetime-local"> (2026-11-14T09:30 wordt 2026-11-14 09:30:00).
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @param mixed               $value Invoer.
 * @return string|WP_Error
 */
function _ww_fields_input_date( array $field, $value ) {
	if ( null === $value || '' === $value ) {
		return '';
	}
	$type     = _ww_data_to_string( $field['type'] ?? '' );
	$messages = array(
		'date'     => __( 'Verwacht een datum als JJJJ-MM-DD.', 'webwerckt-base' ),
		'time'     => __( 'Verwacht een tijd als UU:MM of UU:MM:SS.', 'webwerckt-base' ),
		'datetime' => __( 'Verwacht een datum met tijd als JJJJ-MM-DD UU:MM(:SS) of JJJJ-MM-DDTUU:MM.', 'webwerckt-base' ),
	);
	$error    = new WP_Error( 'ww_abilities_value', $messages[ $type ] ?? '' );
	if ( ! is_string( $value ) ) {
		return $error;
	}
	$patterns = array(
		'date'     => '/^\d{4}-\d{2}-\d{2}$/',
		'time'     => '/^\d{2}:\d{2}(:\d{2})?$/',
		'datetime' => '/^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}(:\d{2})?$/',
	);
	if ( ! isset( $patterns[ $type ] ) || 1 !== preg_match( $patterns[ $type ], $value ) ) {
		return $error;
	}
	// Seconden erbij en een spatie als scheiding; daarna moet de waarde heen en terug gelijk blijven (geen 25:00 of 30 februari).
	$value  = str_replace( 'T', ' ', $value );
	$value .= 'date' !== $type && 1 !== preg_match( '/:\d{2}:\d{2}$/', $value ) ? ':00' : '';
	$format = _ww_field_date_format( $field );
	$parsed = DateTimeImmutable::createFromFormat( '!' . $format, $value );
	if ( false === $parsed || $parsed->format( $format ) !== $value ) {
		return $error;
	}
	return $value;
}

/**
 * Invoerwaarde van een veld, gecontroleerd en klaar voor de opslaglaag, of een fout.
 *
 * Een fout met de code ww_abilities_pods is een waarde die Pods ook zou weigeren (een getal dat geen getal is of
 * buiten number_min of number_max valt, een website die geen URL is, een melding van het filter ww_field_validate);
 * de andere fouten hebben de code ww_abilities_value.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @param mixed               $value Invoer.
 * @return mixed
 */
function _ww_fields_input_value( array $field, $value ) {
	$clean = _ww_fields_input_checked( $field, $value );
	if ( is_wp_error( $clean ) ) {
		return $clean;
	}

	/**
	 * Eigen controle van een veld, na de controle van zijn soort en vóór het opslaan: voor Visueel bewerken, de
	 * abilities, het vertaalwerk en de Site-instellingen. Geeft true, of een lijst met meldingen.
	 *
	 * @param mixed               $valid true, of een lijst met meldingen van een eerdere controle.
	 * @param mixed               $value Gecontroleerde waarde.
	 * @param array<string,mixed> $field Veld uit de configuratie.
	 */
	$valid = apply_filters( 'ww_field_validate', true, $clean, $field );
	if ( true !== $valid ) {
		$messages = array_filter( array_map( '_ww_data_to_string', is_array( $valid ) ? $valid : array( $valid ) ) );
		$message  = array() === $messages ? __( 'Deze waarde is niet toegestaan.', 'webwerckt-base' ) : implode( ' ', $messages );
		return new WP_Error( 'ww_abilities_pods', $message, array( 'status' => 400 ) );
	}
	return $clean;
}

/**
 * Invoerwaarde gecontroleerd op de soort van het veld (zonder het filter ww_field_validate), of een fout.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @param mixed               $value Invoer.
 * @return mixed
 */
function _ww_fields_input_checked( array $field, $value ) {
	$type = _ww_data_to_string( $field['type'] ?? '' );

	if ( _ww_field_is_choice( $field ) ) {
		return _ww_fields_input_choice( $field, $value );
	}

	if ( '' !== _ww_field_date_format( $field ) ) {
		return _ww_fields_input_date( $field, $value );
	}

	if ( 'pick' === $type || 'file' === $type ) {
		if ( 'pick' === $type && ! _ww_field_is_relation( $field ) ) {
			return new WP_Error( 'ww_abilities_value', __( 'Alleen relaties met berichten of termen en keuzes uit een vaste lijst zijn te bewerken.', 'webwerckt-base' ) );
		}
		$terms = _ww_field_is_term_relation( $field );
		$ids   = _ww_fields_input_ids( $value, $terms );
		if ( is_wp_error( $ids ) ) {
			return $ids;
		}
		if ( ! _ww_fields_is_multi( $field ) && count( $ids ) > 1 ) {
			return new WP_Error( 'ww_abilities_value', __( 'Dit veld heeft één waarde.', 'webwerckt-base' ) );
		}
		if ( $terms ) {
			$error = _ww_fields_term_ids_error( $ids, _ww_data_to_string( $field['pick_val'] ?? '' ) );
		} elseif ( 'pick' === $type ) {
			$error = _ww_fields_ids_error( $ids, _ww_data_to_string( $field['pick_val'] ?? '' ), false );
		} else {
			$error = _ww_fields_ids_error( $ids, 'attachment', 'images' === ( $field['file_type'] ?? 'images' ) );
		}
		if ( null !== $error ) {
			return $error;
		}
		return _ww_fields_is_multi( $field ) ? $ids : ( $ids[0] ?? '' );
	}

	if ( 'boolean' === $type ) {
		if ( ! is_bool( $value ) && ! in_array( $value, array( 0, 1, '0', '1' ), true ) ) {
			return new WP_Error( 'ww_abilities_value', __( 'Verwacht true of false.', 'webwerckt-base' ) );
		}
		return (int) (bool) $value;
	}

	if ( null === $value ) {
		return '';
	}
	if ( ! is_string( $value ) && ! is_int( $value ) && ! is_float( $value ) ) {
		return new WP_Error( 'ww_abilities_value', __( 'Verwacht tekst.', 'webwerckt-base' ) );
	}
	if ( 'email' === $type && '' !== $value && ! is_email( (string) $value ) ) {
		return new WP_Error( 'ww_abilities_value', __( 'Geen geldig e-mailadres.', 'webwerckt-base' ) );
	}
	if ( 'number' === $type ) {
		return _ww_fields_number_error( $field, (string) $value ) ?? (string) $value;
	}
	if ( 'website' === $type ) {
		// Witruimte eromheen eerst weg: " example.com " is een geldig webadres.
		$value = trim( (string) $value );
		if ( '' !== $value && '' === _ww_field_clean( $field, $value ) ) {
			return new WP_Error( 'ww_abilities_pods', __( 'Geen geldig webadres.', 'webwerckt-base' ), array( 'status' => 400 ) );
		}
		return $value;
	}
	return (string) $value;
}

/**
 * Fout als een getal geen getal is (zoals PodsField_Number::validate()) of buiten number_min of number_max valt,
 * anders null. Leeg is geen fout.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 */
function _ww_fields_number_error( array $field, string $value ): ?WP_Error {
	if ( '' === trim( $value ) ) {
		return null;
	}
	$clean = _ww_field_clean_number( $field, $value );
	$rest  = (string) preg_replace( '/[0-9\.\-\s,\']/', '', $value );
	if ( null === $clean || '' !== $rest || ! is_numeric( $clean ) ) {
		return new WP_Error( 'ww_abilities_pods', __( 'Verwacht een getal.', 'webwerckt-base' ), array( 'status' => 400 ) );
	}
	$number = (float) $clean;
	$min    = $field['number_min'] ?? '';
	$max    = $field['number_max'] ?? '';
	if ( ( is_numeric( $min ) && $number < (float) $min ) || ( is_numeric( $max ) && $number > (float) $max ) ) {
		/* translators: 1: kleinste waarde, 2: grootste waarde. */
		$message = sprintf( __( 'Verwacht een getal van %1$s tot en met %2$s.', 'webwerckt-base' ), is_numeric( $min ) ? (string) $min : '…', is_numeric( $max ) ? (string) $max : '…' );
		return new WP_Error( 'ww_abilities_pods', $message, array( 'status' => 400 ) );
	}
	return null;
}

/**
 * Alle invoerwaarden gecontroleerd tegen de toegestane velden: de waarden klaar voor de opslaglaag, of de eerste fout.
 * Een leeg verplicht veld (required) is een fout, zoals bij Pods. Een fout ww_abilities_pods van een veld (zie
 * _ww_fields_input_value()) houdt die code; de andere fouten worden ww_abilities_value.
 *
 * @param mixed                             $input   Invoer (veldnaam => waarde).
 * @param array<string,array<string,mixed>> $allowed Toegestane velden op naam.
 * @return array<string,mixed>|WP_Error
 */
function _ww_fields_input( $input, array $allowed ) {
	$data = array();
	foreach ( is_array( $input ) ? $input : array() as $name => $value ) {
		$name = (string) $name;
		if ( ! isset( $allowed[ $name ] ) ) {
			/* translators: 1: veldnaam, 2: toegestane velden. */
			return new WP_Error( 'ww_abilities_field', sprintf( __( 'Onbekend veld %1$s. Velden: %2$s.', 'webwerckt-base' ), $name, implode( ', ', array_keys( $allowed ) ) ), array( 'status' => 400 ) );
		}
		$clean = _ww_fields_input_value( $allowed[ $name ], $value );
		if ( ! is_wp_error( $clean ) && _ww_field_is_required( $allowed[ $name ] ) && in_array( $clean, array( '', null, array() ), true ) ) {
			$clean = new WP_Error( 'ww_abilities_pods', __( 'Dit veld is verplicht.', 'webwerckt-base' ) );
		}
		if ( is_wp_error( $clean ) ) {
			$code = 'ww_abilities_pods' === $clean->get_error_code() ? 'ww_abilities_pods' : 'ww_abilities_value';
			/* translators: 1: veldnaam, 2: foutmelding. */
			return new WP_Error( $code, sprintf( __( 'Veld %1$s: %2$s', 'webwerckt-base' ), $name, $clean->get_error_message() ), array( 'status' => 400 ) );
		}
		$data[ $name ] = $clean;
	}
	return $data;
}

/**
 * Laat ID's van een relatie of foto's weg die er niet meer in kunnen: een bericht in de prullenbak, van een ander
 * type of verwijderd, een term die weg is of in een andere taxonomie staat, of een foto die geen afbeelding meer is.
 * Een waarde die geen ID is, blijft staan, zodat de controle hem weigert. Voor het bewerkscherm, de termschermen en
 * de Site-instellingen: een verdwenen foto of pagina houdt het opslaan niet tegen.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @param mixed               $value Ingezonden waarde: één ID of een lijst.
 * @return mixed
 */
function _ww_fields_drop_gone( array $field, $value ) {
	$type = _ww_data_to_string( $field['type'] ?? '' );
	if ( ! _ww_field_is_relation( $field ) && 'file' !== $type ) {
		return $value;
	}
	$keep = static function ( $id ) use ( $field, $type ): bool {
		if ( ! is_numeric( $id ) || (int) $id <= 0 ) {
			return true;
		}
		if ( _ww_field_is_term_relation( $field ) ) {
			return _ww_is_relatable_term( (int) $id, _ww_data_to_string( $field['pick_val'] ?? '' ) );
		}
		$post = get_post( (int) $id );
		if ( 'file' === $type ) {
			return _ww_is_relatable_post( $post, 'attachment' ) && ( 'images' !== ( $field['file_type'] ?? 'images' ) || wp_attachment_is_image( $post ) );
		}
		return _ww_is_relatable_post( $post, _ww_data_to_string( $field['pick_val'] ?? '' ) );
	};
	if ( is_array( $value ) ) {
		return array_values( array_filter( $value, $keep ) );
	}
	return '' === $value || null === $value || $keep( $value ) ? $value : '';
}

/*
 * Opslaan.
 */

/**
 * Is dit veld verplicht (required "1", 1 of true)?
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 */
function _ww_field_is_required( array $field ): bool {
	return in_array( $field['required'] ?? 0, array( '1', 1, true ), true );
}

/**
 * Slaat gecontroleerde waarden op via de opslaglaag (inc/field-store.php): bij een bericht ($id > 0) als meta van
 * dat bericht, met de velden van zijn post type $pod; bij $id 0 als opties van de instellingen-pod $pod. Elke waarde
 * wordt eerst opgeschoond zoals Pods dat doet (_ww_field_clean()). Geeft null of een fout. Termvelden slaat
 * _ww_fields_save_term() op.
 *
 * Een bericht krijgt de velden van al zijn templates, zoals Pods de hele pod kende. Een naam zonder veld in de
 * configuratie wordt overgeslagen (Pods sloeg hem op als losse meta). De controle hoort vooraf, bij
 * _ww_fields_input(); een fout komt hier alleen als het bericht niet bestaat of het schrijven een uitzondering gooit.
 *
 * @param array<string,mixed> $data Veldnaam => gecontroleerde waarde.
 */
function _ww_fields_save( string $pod, int $id, array $data ): ?WP_Error {
	if ( $id > 0 ) {
		if ( ! get_post( $id ) instanceof WP_Post ) {
			return new WP_Error( 'ww_abilities_pods', __( 'Het bericht bestaat niet.', 'webwerckt-base' ), array( 'status' => 400 ) );
		}
		$fields = array_column( _ww_pods_fields( $pod ), null, 'name' );
		$clean  = _ww_fields_clean_all( $fields, $data );
		return _ww_fields_store_safely( static fn() => _ww_field_store_post( $id, $fields, $clean ) );
	}

	$fields = array_column(
		array_filter( _ww_pods_setting_fields(), static fn( array $field ): bool => $pod === ( $field['pod'] ?? '' ) ),
		null,
		'name'
	);
	$clean  = _ww_fields_clean_all( $fields, $data );
	return _ww_fields_store_safely(
		static function () use ( $pod, $fields, $clean ): void {
			foreach ( $clean as $name => $value ) {
				_ww_field_store_setting( $pod, $fields[ $name ], $value );
			}
		}
	);
}

/**
 * Slaat gecontroleerde waarden van een term op als term meta, met de velden van de taxonomie-pod $taxonomy, zoals
 * _ww_fields_save() dat voor een bericht doet. Geeft null of een fout.
 *
 * @param array<string,mixed> $data Veldnaam => gecontroleerde waarde.
 */
function _ww_fields_save_term( string $taxonomy, int $term_id, array $data ): ?WP_Error {
	if ( ! get_term( $term_id, $taxonomy ) instanceof WP_Term ) {
		return new WP_Error( 'ww_abilities_pods', __( 'De term bestaat niet.', 'webwerckt-base' ), array( 'status' => 400 ) );
	}
	$fields = array_column( _ww_pods_taxonomy_fields( $taxonomy ), null, 'name' );
	$clean  = _ww_fields_clean_all( $fields, $data );
	return _ww_fields_store_safely( static fn() => _ww_field_store_term( $term_id, $fields, $clean ) );
}

/**
 * De waarden opgeschoond zoals Pods (_ww_field_clean()), alleen voor namen met een veld in $fields.
 *
 * @param array<string,array<string,mixed>> $fields Velden op naam.
 * @param array<string,mixed>               $data   Veldnaam => gecontroleerde waarde.
 * @return array<string,mixed>
 */
function _ww_fields_clean_all( array $fields, array $data ): array {
	$clean = array();
	foreach ( $data as $name => $value ) {
		$name = (string) $name;
		if ( isset( $fields[ $name ] ) ) {
			$clean[ $name ] = _ww_field_clean( $fields[ $name ], $value );
		}
	}
	return $clean;
}

/**
 * Voert het schrijven uit. Een haak die daarbij een uitzondering gooit, wordt een fout in plaats van een afgebroken
 * verzoek (zoals het opslaan via Pods dat deed); wat al geschreven was, blijft staan. De fout zelf gaat naar het
 * foutenlog: de melding van een haak kan paden of interne gegevens bevatten en hoort niet in het antwoord.
 *
 * @param callable $write Schrijft de waarden.
 */
function _ww_fields_store_safely( callable $write ): ?WP_Error {
	try {
		$write();
	} catch ( Throwable $e ) {
		error_log( 'Webwerckt Base: opslaan van velden mislukt: ' . $e->getMessage() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- de oorzaak voor de beheerder, niet in het antwoord.
		return new WP_Error( 'ww_abilities_pods', __( 'Opslaan is mislukt. Probeer het opnieuw; blijft het misgaan, neem dan contact op met de beheerder.', 'webwerckt-base' ), array( 'status' => 400 ) );
	}
	return null;
}

/**
 * Slaat gecontroleerde waarden van de Site-instellingen op, per instellingen-pod. Geeft null of een fout.
 *
 * @param array<string,mixed>               $data    Veldnaam => gecontroleerde waarde.
 * @param array<string,array<string,mixed>> $allowed Velden op naam, met hun pod.
 */
function _ww_fields_save_settings( array $data, array $allowed ): ?WP_Error {
	$per_pod = array();
	foreach ( $data as $name => $value ) {
		$per_pod[ _ww_data_to_string( $allowed[ $name ]['pod'] ?? '' ) ][ $name ] = $value;
	}
	foreach ( $per_pod as $pod => $values ) {
		$error = _ww_fields_save( $pod, 0, $values );
		if ( null !== $error ) {
			return $error;
		}
	}
	return null;
}
