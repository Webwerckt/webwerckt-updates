<?php
/**
 * Mail (beslissing 0034): de eigen PHPMailer, die de mail aan de gekozen aansluiting geeft.
 *
 * WordPress vult deze mailer zoals altijd (ontvangers, Van, onderwerp, tekst, bijlagen, phpmailer_init). Bij versturen
 * gaat de mail naar de aansluiting, of, als er geen gekozen is of WP Mail SMTP actief is, naar het gewone PHPMailer-gedrag.
 * Een fout wordt een exceptie, zodat wp_mail() false geeft en wp_mail_failed start. Er is geen stille terugval.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once ABSPATH . WPINC . '/PHPMailer/PHPMailer.php';
require_once ABSPATH . WPINC . '/PHPMailer/SMTP.php';
require_once ABSPATH . WPINC . '/PHPMailer/Exception.php';

/**
 * PHPMailer die versturen overlaat aan de gekozen aansluiting.
 */
class WW_PHPMailer extends PHPMailer\PHPMailer\PHPMailer {

	/**
	 * Id van de aansluiting die de laatste mail verstuurde (voor de log), of ''.
	 *
	 * @var string
	 */
	public string $ww_transport = '';

	/**
	 * Id van de mail bij de aanbieder (bijv. messageId van Brevo), of ''.
	 *
	 * @var string
	 */
	public string $ww_provider_id = '';

	/**
	 * Maakt de mailer aan, met de vertaalde foutmeldingen van WordPress (6.8 en hoger).
	 *
	 * @param bool|null $exceptions Excepties bij een fout; WordPress gebruikt true.
	 */
	public function __construct( $exceptions = null ) {
		parent::__construct( $exceptions );
		if ( ! class_exists( 'WP_PHPMailer' ) && file_exists( ABSPATH . WPINC . '/class-wp-phpmailer.php' ) ) {
			require_once ABSPATH . WPINC . '/class-wp-phpmailer.php';
		}
		if ( class_exists( 'WP_PHPMailer' ) ) {
			WP_PHPMailer::setLanguage();
		}
	}

	/**
	 * Verstuurt de mail via de gekozen aansluiting.
	 *
	 * @throws PHPMailer\PHPMailer\Exception Bij een fout (wp_mail() vangt die af).
	 */
	public function send(): bool {
		$this->ww_transport   = '';
		$this->ww_provider_id = '';

		$id = _ww_mail_transport_id();
		if ( '' === $id || '' !== _ww_mail_foreign_mailer() ) {
			return parent::send();
		}

		$transport = _ww_mail_transport();
		if ( null === $transport ) {
			$this->ww_transport = sanitize_key( $id );
			$result             = new WP_Error(
				'ww_mail_unavailable',
				/* translators: %s: id van de aansluiting. */
				sprintf( __( 'Aansluiting %s is niet beschikbaar.', 'webwerckt-base' ), $id )
			);
		} else {
			$this->ww_transport = $transport->id();
			if ( ! $transport->is_configured() ) {
				$result = new WP_Error(
					'ww_mail_not_configured',
					/* translators: %s: naam van de aansluiting. */
					sprintf( __( '%s is niet ingesteld.', 'webwerckt-base' ), $transport->label() )
				);
			} else {
				if ( ! $this->preSend() ) {
					throw new PHPMailer\PHPMailer\Exception( $this->ErrorInfo ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- geen HTML.
				}
				try {
					$result = $transport->send( $this );
				} catch ( PHPMailer\PHPMailer\Exception $e ) {
					throw $e;
				} catch ( Throwable $e ) {
					// Alleen de klasse: de melding van een andere aansluiting kan een geheim bevatten.
					$message = sprintf(
						/* translators: 1: id van de aansluiting, 2: klasse van de fout. */
						__( 'Aansluiting %1$s gaf een fout (%2$s).', 'webwerckt-base' ),
						$this->ww_transport,
						get_class( $e )
					);
					throw new PHPMailer\PHPMailer\Exception( $message ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- geen HTML; wp_mail() maakt er een WP_Error van.
				}
			}
		}

		if ( is_wp_error( $result ) ) {
			throw new PHPMailer\PHPMailer\Exception( $result->get_error_message() ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- geen HTML; wp_mail() maakt er een WP_Error van.
		}
		return true;
	}
}
