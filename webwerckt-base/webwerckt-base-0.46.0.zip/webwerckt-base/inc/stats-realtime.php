<?php
/**
 * Statistieken: "Nu op de site" (beslissing 0039).
 *
 * Telt de bezoekers met een weergave in de laatste 5 minuten, alleen op de UTC-`ts`. De dagkolom speelt
 * geen rol, dus een andere tijdzone of middernacht maakt niets uit. Het resultaat wordt nooit gecachet.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Hoeveel bezoekers er nu zijn en op welke pagina's.
 *
 * Het venster loopt van de huidige minuut min 300 seconden tot nu. Een bezoeker telt één keer mee, op
 * zijn laatste pagina in het venster. De top 10 gaat op aantal en bij gelijk aantal op pad.
 * Bij een databasefout is het antwoord 0 bezoekers zonder pagina's.
 *
 * @param int|null $now Tijdstip, null voor nu.
 * @return array{count:int, pages:list<array{path:string, visitors:int}>}
 */
function _ww_stats_realtime( ?int $now = null ): array {
	global $wpdb;
	$empty = array(
		'count' => 0,
		'pages' => array(),
	);
	$since = _ww_stats_minute( $now ?? time() ) - 300;
	$hits  = _ww_stats_hits_table();

	$wpdb->last_error = '';
	$total            = _ww_stats_read( $wpdb->prepare( "SELECT COUNT(DISTINCT visitor) AS visitors FROM {$hits} WHERE ts >= %d", $since ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_stats_hits_table().
	$rows             = _ww_stats_read( $wpdb->prepare( "SELECT visitor, path FROM {$hits} WHERE ts >= %d ORDER BY visitor, ts, id", $since ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_stats_hits_table().
	if ( null === $total || null === $rows ) {
		return $empty;
	}

	// Op volgorde van tijd: de laatste rij van een bezoeker wint.
	$last = array();
	foreach ( $rows as $row ) {
		$last[ (string) $row['visitor'] ] = (string) $row['path'];
	}
	$counts = array();
	foreach ( $last as $path ) {
		$counts[ $path ] = ( $counts[ $path ] ?? 0 ) + 1;
	}
	$pages = array();
	foreach ( $counts as $path => $visitors ) {
		$pages[] = array(
			'path'     => (string) $path,
			'visitors' => $visitors,
		);
	}
	usort(
		$pages,
		static fn( array $a, array $b ): int => array( $b['visitors'], $a['path'] ) <=> array( $a['visitors'], $b['path'] )
	);

	return array(
		'count' => (int) ( $total[0]['visitors'] ?? 0 ),
		'pages' => array_slice( $pages, 0, 10 ),
	);
}

/**
 * Verrijkt de pagina's met titel en adres.
 *
 * @param array{count:int, pages:list<array<string,mixed>>} $data Uit _ww_stats_realtime().
 * @return list<array{path:string, title:string, url:string, visitors:int}>
 */
function _ww_stats_realtime_pages( array $data ): array {
	$pages = array();
	foreach ( $data['pages'] as $page ) {
		$path = (string) $page['path'];
		if ( isset( $page['title'], $page['url'] ) ) {
			$title = (string) $page['title'];
			$url   = (string) $page['url'];
		} else {
			$label = _ww_stats_page_label( $path );
			$title = $label['label'];
			$url   = $label['url'];
		}
		$pages[] = array(
			'path'     => $path,
			'title'    => $title,
			'url'      => $url,
			'visitors' => (int) $page['visitors'],
		);
	}
	return $pages;
}

/**
 * Ajax: de actuele waarden voor het blok "Nu op de site".
 */
function _ww_stats_realtime_ajax(): void {
	check_ajax_referer( 'ww_stats_realtime' );
	if ( ! current_user_can( 'edit_others_pages' ) ) {
		wp_send_json_error( null, 403 );
	}
	$data = _ww_stats_realtime();
	wp_send_json_success(
		array(
			'count' => $data['count'],
			'pages' => _ww_stats_realtime_pages( $data ),
		)
	);
}
add_action( 'wp_ajax_ww_stats_realtime', '_ww_stats_realtime_ajax' );

/**
 * De HTML van het blok. Het script vernieuwt het getal en de lijst vanuit data-nonce en data-url.
 *
 * @param array{count:int, pages:list<array<string,mixed>>} $data    Uit _ww_stats_realtime().
 * @param bool                                              $compact Alleen de regel voor het dashboardwidget.
 */
function _ww_stats_realtime_html( array $data, bool $compact ): string {
	$count = (int) $data['count'];
	$attrs = sprintf(
		' data-ww-realtime data-nonce="%s" data-url="%s"%s',
		esc_attr( wp_create_nonce( 'ww_stats_realtime' ) ),
		esc_url( admin_url( 'admin-ajax.php' ) ),
		$compact ? ' data-compact' : ''
	);

	if ( $compact ) {
		return '<p class="ww-realtime ww-realtime--compact"' . $attrs . '>'
			. esc_html__( 'Nu op de site: ', 'webwerckt-base' )
			. '<strong data-ww-realtime-count aria-live="polite">' . esc_html( (string) $count ) . '</strong></p>';
	}

	$items = '';
	foreach ( _ww_stats_realtime_pages( $data ) as $page ) {
		$name   = '' !== $page['title'] ? $page['title'] : $page['path'];
		$link   = '' !== $page['url'] ? '<a href="' . esc_url( $page['url'] ) . '">' . esc_html( $name ) . '</a>' : esc_html( $name );
		$items .= '<li>' . $link . ' <span class="ww-realtime__visitors">' . esc_html( (string) $page['visitors'] ) . '</span></li>';
	}

	return '<div class="ww-realtime"' . $attrs . '>'
		. '<h2 class="ww-realtime__title">' . esc_html__( 'Nu op de site', 'webwerckt-base' ) . '</h2>'
		. '<p class="ww-realtime__count"><span class="ww-realtime__dot" aria-hidden="true"></span>'
		. '<strong data-ww-realtime-count aria-live="polite">' . esc_html( (string) $count ) . '</strong></p>'
		. '<p data-ww-realtime-empty' . ( 0 === $count ? '' : ' hidden' ) . '>' . esc_html__( 'Er is nu niemand op de site.', 'webwerckt-base' ) . '</p>'
		. '<ol class="ww-realtime__pages" data-ww-realtime-list>' . $items . '</ol>'
		. '</div>';
}
