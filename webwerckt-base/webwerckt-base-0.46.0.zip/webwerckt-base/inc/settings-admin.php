<?php
/**
 * Het opslaan van de Site-instellingen per onderdeel. Het scherm bewaart alleen de velden van het onderdeel waarop
 * de gebruiker staat, via de veldlaag van het thema (inc/fields.php): dezelfde controle als de abilities en de
 * editor. Eén fout bewaart niets.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * De groepen van een onderdeel, in de volgorde van de configuratie, met alleen de velden die de gebruiker mag
 * bewerken. Een groep zonder zulke velden valt weg.
 *
 * @param string $section Slug van het onderdeel.
 * @return array<int,array{group:array<string,mixed>,fields:array<string,array<string,mixed>>}>
 */
function _ww_settings_section_groups( string $section ): array {
	$pages    = _ww_settings_pages();
	$editable = _ww_fields_for_settings();
	$result   = array();
	foreach ( _ww_settings_groups() as $group ) {
		if ( _ww_settings_group_page( $group, $pages ) !== $section ) {
			continue;
		}
		$fields = array();
		foreach ( is_array( $group['fields'] ?? null ) ? $group['fields'] : array() as $item ) {
			$name = is_array( $item ) ? _ww_data_to_string( $item['name'] ?? '' ) : '';
			if ( '' !== $name && isset( $editable[ $name ] ) ) {
				$fields[ $name ] = $editable[ $name ];
			}
		}
		if ( array() !== $fields ) {
			$result[] = array(
				'group'  => $group,
				'fields' => $fields,
			);
		}
	}
	return $result;
}

/**
 * De bewerkbare velden van een onderdeel, plat op naam, zonder de soorten die het thema niet tekent.
 *
 * @param string $section Slug van het onderdeel.
 * @return array<string,array<string,mixed>>
 */
function _ww_settings_section_fields( string $section ): array {
	$fields = array();
	foreach ( _ww_settings_section_groups( $section ) as $item ) {
		foreach ( $item['fields'] as $name => $field ) {
			if ( _ww_settings_field_supported( $field ) ) {
				$fields[ $name ] = $field;
			}
		}
	}
	return $fields;
}

/**
 * Controleert en bewaart de velden van één onderdeel. Een veld van een ander onderdeel, een afgeschermd veld of een
 * soort die het thema niet tekent geeft een fout; dan wordt niets bewaard. Een foto, pagina of term die inmiddels weg
 * is (of in de prullenbak ligt), valt eerst stil uit zijn veld, zoals op het bewerkscherm: anders hield één
 * verwijderde foto het hele onderdeel tegen.
 *
 * @param string              $section Slug van het onderdeel.
 * @param array<string,mixed> $posted  Ingezonden waarden (`ww_fields`), nog met slashes.
 * @return WP_Error|null null als het gelukt is.
 */
function _ww_settings_save( string $section, array $posted ): ?WP_Error {
	$fields = _ww_settings_section_fields( $section );
	$values = _ww_settings_post_values( $fields, $posted );
	foreach ( $values as $name => $value ) {
		if ( isset( $fields[ $name ] ) ) {
			$values[ $name ] = _ww_fields_drop_gone( $fields[ $name ], $value );
		}
	}
	$data = _ww_fields_input( $values, $fields );
	if ( is_wp_error( $data ) ) {
		return $data;
	}
	return _ww_fields_save_settings( $data, $fields );
}

/**
 * Op load-{hook} van het scherm: verwerkt een opslag. Alleen bij POST met `ww_settings_section`. Bij succes een
 * redirect (naar `ww_next` als dat een zichtbaar onderdeel is); bij een fout blijven de fout en de ingevulde waarden
 * in globals staan en tekent het scherm zich in hetzelfde verzoek.
 */
function _ww_settings_handle_save(): void {
	if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) || ! isset( $_POST['ww_settings_section'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- de nonce volgt hieronder.
		return;
	}
	$section = is_string( $_POST['ww_settings_section'] ) ? sanitize_key( wp_unslash( $_POST['ww_settings_section'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
	$nonce   = isset( $_POST['_wpnonce'] ) && is_string( $_POST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ) : '';
	$pages   = _ww_settings_visible_pages();
	if ( ! wp_verify_nonce( $nonce, 'ww_settings_save_' . $section ) || ! isset( $pages[ $section ] ) ) {
		wp_die( esc_html__( 'Deze pagina van de Site-instellingen bestaat niet of je mag hem niet bewerken.', 'webwerckt-base' ), 403 );
	}

	$posted = isset( $_POST['ww_fields'] ) && is_array( $_POST['ww_fields'] ) ? $_POST['ww_fields'] : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput -- nonce hierboven; waarden gecontroleerd door _ww_fields_input().
	$error  = _ww_settings_save( $section, $posted );
	if ( null !== $error ) {
		$GLOBALS['ww_settings_error']  = $error;
		$GLOBALS['ww_settings_posted'] = _ww_settings_post_values( _ww_settings_section_fields( $section ), $posted );
		return;
	}

	$next = isset( $_POST['ww_next'] ) && is_string( $_POST['ww_next'] ) ? sanitize_key( wp_unslash( $_POST['ww_next'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
	wp_safe_redirect( _ww_settings_url( isset( $pages[ $next ] ) ? $next : $section, array( 'saved' => '1' ) ) );
	exit;
}

/*
 * Het scherm: zijpaneel, kop, meldingen en het formulier.
 */

// De onderdelen van de parent. Andere onderdelen (van het child-thema en Overige) staan in het paneel onder een lijn.
const WW_SETTINGS_PARENT_PAGES = array( 'contact', 'social', 'notfound', 'seo', 'scripts' );

/**
 * Icoon en omschrijving per onderdeel. Een onderdeel van het child-thema heeft geen omschrijving.
 *
 * @return array<string,array{icon:string,desc:string}>
 */
function _ww_settings_section_meta(): array {
	$meta   = array(
		'contact'  => array(
			'icon' => 'dashicons-location',
			'desc' => __( 'Adres, telefoon en openingstijden. Ze staan in de footer, op de contactpagina en in de gegevens voor zoekmachines.', 'webwerckt-base' ),
		),
		'social'   => array(
			'icon' => 'dashicons-share',
			'desc' => __( 'Links naar je social media en de tekst onderaan elke pagina.', 'webwerckt-base' ),
		),
		'notfound' => array(
			'icon' => 'dashicons-editor-unlink',
			'desc' => __( 'Wat bezoekers zien als een pagina niet bestaat, en als zoeken niets oplevert.', 'webwerckt-base' ),
		),
		'seo'      => array(
			'icon' => 'dashicons-search',
			'desc' => __( 'Titels, beschrijvingen en de afbeelding bij delen. Per pagina staat er een eigen box SEO.', 'webwerckt-base' ),
		),
		'scripts'  => array(
			'icon' => 'dashicons-editor-code',
			'desc' => __( 'Code van bijvoorbeeld Google Tag Manager, precies zoals de dienst hem geeft.', 'webwerckt-base' ),
		),
	);
	$result = array();
	foreach ( array_keys( _ww_settings_pages() ) as $slug ) {
		$result[ $slug ] = $meta[ $slug ] ?? array(
			'icon' => WW_SETTINGS_OTHER === $slug ? 'dashicons-ellipsis' : 'dashicons-admin-generic',
			'desc' => '',
		);
	}
	return $result;
}

/**
 * Wat zoekmachines missen in het schema van de organisatie, met per gegeven een link naar het veld. Leeg zonder
 * schema van het thema of als een SEO-plugin het schema levert. Het logo staat onder Instellingen › Algemeen en heeft
 * geen onderdeel; de link ernaartoe staat er alleen voor wie dat scherm mag openen (manage_options), anders is url ''.
 *
 * @return array<int,array{label:string,url:string,section:string}>
 */
function _ww_settings_missing(): array {
	if ( ! _ww_schema_enabled() || '' !== _ww_schema_plugin() ) {
		return array();
	}
	$fields = array(
		'address'                   => 'street',
		'telephone'                 => 'phone',
		'openingHoursSpecification' => 'hours_monday',
	);
	$result = array();
	foreach ( _ww_schema_missing_map() as $key => $label ) {
		if ( isset( $fields[ $key ] ) ) {
			$section  = _ww_activity_settings_page( $fields[ $key ] );
			$result[] = array(
				'label'   => $label,
				'url'     => _ww_settings_url( $section ) . '#ww-field-' . $fields[ $key ],
				'section' => $section,
			);
		} elseif ( 'logo' === $key ) {
			$result[] = array(
				'label'   => $label,
				'url'     => current_user_can( 'manage_options' ) ? admin_url( 'options-general.php' ) : '',
				'section' => '',
			);
		}
	}
	return $result;
}

/**
 * De laatste wijziging van een onderdeel volgens het Activiteitenlog, of null zonder tabel of zonder regel.
 *
 * @param string $section Slug van het onderdeel.
 * @return array{time:int,user:string}|null
 */
function _ww_settings_last_change( string $section ): ?array {
	if ( ! _ww_activity_ready() ) {
		return null;
	}
	global $wpdb;
	$suppressed = $wpdb->suppress_errors( true );
	$row        = $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->prepare(
			'SELECT created, user_name, agent FROM ' . _ww_activity_table() . ' WHERE object_type = %s AND object_subtype = %s ORDER BY created DESC, id DESC LIMIT 1', // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_activity_table().
			'settings',
			$section
		)
	);
	$wpdb->suppress_errors( $suppressed );
	if ( ! is_object( $row ) ) {
		return null;
	}
	$time = strtotime( _ww_data_to_string( $row->created ?? '' ) . ' UTC' );
	$user = _ww_data_to_string( $row->user_name ?? '' );
	return array(
		'time' => false !== $time ? $time : 0,
		'user' => '' !== $user ? $user : _ww_data_to_string( $row->agent ?? '' ),
	);
}

/**
 * Heeft een onderdeel een veld dat alleen wie code mag plaatsen bewerkt (restrict_capability)? Uit de configuratie,
 * los van de rechten van de gebruiker.
 *
 * @param string $section Slug van het onderdeel.
 */
function _ww_settings_section_locked( string $section ): bool {
	$pages = _ww_settings_pages();
	foreach ( _ww_settings_groups() as $group ) {
		if ( _ww_settings_group_page( $group, $pages ) !== $section ) {
			continue;
		}
		foreach ( is_array( $group['fields'] ?? null ) ? $group['fields'] : array() as $field ) {
			if ( is_array( $field ) && 1 === (int) ( $field['restrict_capability'] ?? 0 ) ) {
				return true;
			}
		}
	}
	return false;
}

/**
 * De onderdelen als links, in twee varianten: panel (het zijpaneel, met Dashicon en slotje) en menu (een uitklapper
 * voor mobiel, met het actieve onderdeel in de summary). De gele stip staat in beide. Elke link heeft
 * data-ww-section, voor het script dat bij wijzigingen eerst vraagt.
 *
 * @param string $active  Actief onderdeel.
 * @param string $variant panel of menu.
 * @return string Geëscapete HTML.
 */
function _ww_settings_render_nav( string $active, string $variant ): string {
	$pages   = _ww_settings_visible_pages();
	$meta    = _ww_settings_section_meta();
	$missing = array_flip( array_filter( array_column( _ww_settings_missing(), 'section' ) ) );
	$lists   = array(
		'parent' => '',
		'child'  => '',
	);
	foreach ( $pages as $slug => $label ) {
		$slug = (string) $slug;
		$icon = 'panel' === $variant ? '<span class="dashicons ' . esc_attr( $meta[ $slug ]['icon'] ?? 'dashicons-admin-generic' ) . '" aria-hidden="true"></span>' : '';
		$dot  = isset( $missing[ $slug ] )
			? '<span class="ww-settings-dot ww-settings-panel__dot" aria-hidden="true"></span><span class="screen-reader-text">' . esc_html__( ', zoekmachines missen hier iets', 'webwerckt-base' ) . '</span>'
			: '';
		$lock = '';
		if ( 'panel' === $variant && _ww_settings_section_locked( $slug ) ) {
			$text = __( 'Alleen voor wie code mag plaatsen', 'webwerckt-base' );
			$lock = '<span class="dashicons dashicons-lock ww-settings-panel__lock" title="' . esc_attr( $text ) . '" aria-hidden="true"></span><span class="screen-reader-text">, ' . esc_html( $text ) . '</span>';
		}
		$item = '<li><a href="' . esc_url( _ww_settings_url( $slug ) ) . '" data-ww-section="' . esc_attr( $slug ) . '"' . ( $slug === $active ? ' aria-current="page"' : '' ) . '>'
			. $icon . '<span class="ww-settings-nav__label">' . esc_html( $label ) . '</span>' . $dot . $lock . '</a></li>';

		$lists[ in_array( $slug, WW_SETTINGS_PARENT_PAGES, true ) ? 'parent' : 'child' ] .= $item;
	}

	if ( 'panel' === $variant ) {
		$html = '' !== $lists['parent'] ? '<ul class="ww-settings-panel__nav">' . $lists['parent'] . '</ul>' : '';
		if ( '' !== $lists['child'] ) {
			$html .= ( '' !== $html ? '<hr class="ww-settings-panel__sep">' : '' ) . '<ul class="ww-settings-panel__nav">' . $lists['child'] . '</ul>';
		}
		return $html;
	}
	$sep = '' !== $lists['parent'] && '' !== $lists['child'] ? '<li class="ww-settings-menu__sep" aria-hidden="true"></li>' : '';
	return '<details class="ww-settings-menu"><summary><span>' . esc_html__( 'Onderdeel', 'webwerckt-base' ) . '</span> <b>' . esc_html( $pages[ $active ] ?? '' ) . '</b></summary>'
		. '<ul>' . $lists['parent'] . $sep . $lists['child'] . '</ul></details>';
}

/**
 * Eén ontbrekend gegeven: een link naar het veld, of alleen de tekst als er geen link is.
 *
 * @param array{label:string,url:string,section:string} $item Uit _ww_settings_missing().
 * @return string Geëscapete HTML.
 */
function _ww_settings_missing_item( array $item ): string {
	$label = esc_html( ucfirst( $item['label'] ) );
	return '' !== $item['url'] ? '<a href="' . esc_url( $item['url'] ) . '">' . $label . '</a>' : $label;
}

/**
 * Het kaartje voor zoekmachines. panel: in het zijpaneel, met de lijst van wat mist of dat alles compleet is. mobile:
 * onder de kop op mobiel, alleen als er iets mist, met één link naar het eerste ontbrekende gegeven. '' zonder schema
 * van het thema of naast een SEO-plugin.
 *
 * @param string $variant panel of mobile.
 * @return string Geëscapete HTML.
 */
function _ww_settings_render_card( string $variant ): string {
	if ( ! _ww_schema_enabled() || '' !== _ww_schema_plugin() ) {
		return '';
	}
	$missing = _ww_settings_missing();
	$count   = count( $missing );
	$title   = sprintf(
		/* translators: %s: aantal ontbrekende gegevens. */
		_n( 'Zoekmachines missen %s gegeven', 'Zoekmachines missen %s gegevens', $count, 'webwerckt-base' ),
		number_format_i18n( $count )
	);
	$dot     = '<span class="ww-settings-dot" aria-hidden="true"></span>';

	if ( 'mobile' === $variant ) {
		if ( 0 === $count ) {
			return '';
		}
		// De eerste met een link; zonder link (alleen het logo, voor wie Instellingen niet mag openen) alleen de tekst.
		$linked = array_values( array_filter( $missing, static fn( array $item ): bool => '' !== $item['url'] ) );
		$first  = $linked[0] ?? $missing[0];
		return '<div class="ww-settings-mobile-card"><p>' . $dot . '<strong>' . esc_html( $title ) . '</strong></p>'
			. '<p>' . _ww_settings_missing_item( $first ) . '</p></div>';
	}

	if ( 0 === $count ) {
		return '<div class="ww-settings-panel__card"><p><span class="dashicons dashicons-yes-alt ww-settings-ok" aria-hidden="true"></span><strong>' . esc_html__( 'Compleet voor zoekmachines', 'webwerckt-base' ) . '</strong></p>'
			. '<p>' . esc_html__( 'Zoekmachines vinden alle gegevens van je bedrijf.', 'webwerckt-base' ) . '</p></div>';
	}
	$items = '';
	foreach ( $missing as $item ) {
		$items .= '<li>' . _ww_settings_missing_item( $item ) . '</li>';
	}
	return '<div class="ww-settings-panel__card"><p>' . $dot . '<strong>' . esc_html( $title ) . '</strong></p><ul>' . $items . '</ul>'
		. '<p>' . esc_html__( 'Met deze gegevens toont Google je bedrijf completer.', 'webwerckt-base' ) . '</p></div>';
}

/**
 * De voet van het paneel: teksten staan ook in de pagina zelf, met een link naar de homepage in Visueel bewerken
 * voor wie daar de Site-instellingen mag bewerken (en alleen als er een vaste homepage is).
 *
 * @return string Geëscapete HTML.
 */
function _ww_settings_render_foot(): string {
	$html  = '<p class="ww-settings-panel__foot"><span class="dashicons dashicons-info-outline" aria-hidden="true"></span><span>';
	$html .= esc_html__( 'Teksten zoals de footer en de 404 pas je ook aan in de pagina zelf.', 'webwerckt-base' );
	$home  = (int) get_option( 'page_on_front' );
	if ( $home > 0 && _ww_editor_can_edit_settings() ) {
		$html .= ' <a href="' . esc_url( _ww_editor_url( $home ) ) . '">' . esc_html__( 'Naar Visueel bewerken', 'webwerckt-base' ) . '</a>';
	}
	return $html . '</span></p>';
}

/**
 * De kop van de inhoud: label, omschrijving en de laatste wijziging uit het Activiteitenlog.
 *
 * @param string $section Slug van het onderdeel.
 * @param string $label   Label van het onderdeel.
 * @return string Geëscapete HTML.
 */
function _ww_settings_render_head( string $section, string $label ): string {
	$html = '<h1>' . esc_html( $label ) . '</h1><hr class="wp-header-end">';
	$desc = _ww_settings_section_meta()[ $section ]['desc'] ?? '';
	if ( '' !== $desc ) {
		$html .= '<p class="ww-settings-desc">' . esc_html( $desc ) . '</p>';
	}
	$last = _ww_settings_last_change( $section );
	if ( null === $last ) {
		return $html . '<p class="ww-settings-last">' . esc_html__( 'Nog geen wijzigingen in het Activiteitenlog', 'webwerckt-base' ) . '</p>';
	}
	$text = sprintf(
		/* translators: 1: datum, 2: tijd, 3: naam van wie het wijzigde. */
		__( 'Laatst gewijzigd: %1$s om %2$s door %3$s', 'webwerckt-base' ),
		wp_date( _ww_data_to_string( get_option( 'date_format' ) ), $last['time'] ),
		wp_date( _ww_data_to_string( get_option( 'time_format' ) ), $last['time'] ),
		$last['user']
	);
	$link = current_user_can( 'manage_options' )
		? ' <a href="' . esc_url( _ww_activity_admin_url( array( 'type' => 'settings' ) ) ) . '">' . esc_html__( 'Bekijk in Activiteitenlog', 'webwerckt-base' ) . '</a>'
		: '';
	return $html . '<p class="ww-settings-last">' . esc_html( $text ) . $link . '</p>';
}

/**
 * De balk onderin en het venster bij wisselen, verborgen. Het script toont ze bij wijzigingen; zonder script blijven ze
 * weg en werkt de knop onder het formulier.
 *
 * @param string $label Label van het onderdeel.
 * @return string Geëscapete HTML.
 */
function _ww_settings_render_savebar( string $label ): string {
	/* translators: %s: naam van het onderdeel, zoals SEO. */
	$bar = sprintf( __( 'Niet-opgeslagen wijzigingen in %s', 'webwerckt-base' ), $label );
	/* translators: %s: naam van het onderdeel, zoals SEO. */
	$text = sprintf( __( 'Je hebt iets veranderd in %s. Elk onderdeel slaat apart op; zonder opslaan ben je die wijzigingen kwijt.', 'webwerckt-base' ), $label );

	return '<div class="ww-settings-savebar" hidden><p class="ww-settings-savebar__text"><span class="ww-settings-dot" aria-hidden="true"></span>' . esc_html( $bar ) . '</p>'
		. '<p class="ww-settings-savebar__actions"><button type="button" class="button" data-ww-action="undo">' . esc_html__( 'Ongedaan maken', 'webwerckt-base' ) . '</button>'
		. '<button type="submit" class="button button-primary" data-ww-action="save">' . esc_html__( 'Wijzigingen opslaan', 'webwerckt-base' ) . '</button></p></div>'
		. '<div class="ww-settings-dialog" role="alertdialog" aria-modal="true" aria-labelledby="ww-settings-dialog-title" aria-describedby="ww-settings-dialog-text" hidden>'
		. '<div class="ww-settings-dialog__box"><h2 id="ww-settings-dialog-title">' . esc_html__( 'Wijzigingen opslaan?', 'webwerckt-base' ) . '</h2>'
		. '<p id="ww-settings-dialog-text">' . esc_html( $text ) . '</p>'
		. '<p class="ww-settings-dialog__actions"><button type="button" class="button" data-ww-action="stay">' . esc_html__( 'Blijven', 'webwerckt-base' ) . '</button>'
		. '<button type="button" class="button" data-ww-action="discard">' . esc_html__( 'Niet opslaan', 'webwerckt-base' ) . '</button>'
		. '<button type="button" class="button button-primary" data-ww-action="save-next">' . esc_html__( 'Opslaan en verder', 'webwerckt-base' ) . '</button></p></div></div>';
}

/**
 * Het scherm (callback van het menu-item): het zijpaneel, de mobiele kiezer, de kop, de meldingen, het mobiele
 * kaartje en het formulier van het onderdeel. Na een fout bij opslaan komen de ingezonden waarden terug.
 */
function _ww_settings_render(): void {
	$pages   = _ww_settings_visible_pages();
	$section = _ww_settings_current_page();
	if ( ! isset( $pages[ $section ] ) ) {
		return; // _ww_settings_screen_load() weigert dit verzoek al.
	}
	$label = $pages[ $section ];

	$notice = '';
	$error  = $GLOBALS['ww_settings_error'] ?? null;
	if ( $error instanceof WP_Error ) {
		$notice = '<div class="notice notice-error"><p>' . implode( '<br>', array_map( 'esc_html', $error->get_error_messages() ) ) . '</p></div>';
	} elseif ( '1' === _ww_query_key( 'saved' ) ) {
		$notice = '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Instellingen opgeslagen.', 'webwerckt-base' ) . '</p></div>';
	}

	$groups = _ww_settings_section_groups( $section );
	$fields = array();
	foreach ( $groups as $item ) {
		$fields += $item['fields'];
	}
	$values = _ww_settings_values( $fields );
	$boxes  = '';
	foreach ( $groups as $item ) {
		$boxes .= _ww_settings_render_group( $item['group'], $item['fields'], $values );
	}

	$html  = '<div class="wrap ww-settings"><div class="ww-settings-layout">';
	$html .= '<nav class="ww-settings-panel" aria-label="' . esc_attr__( 'Onderdelen van de Site-instellingen', 'webwerckt-base' ) . '">'
		. '<p class="ww-settings-panel__title">' . esc_html__( 'Site-instellingen', 'webwerckt-base' ) . '</p>'
		. '<p class="ww-settings-panel__sub">' . esc_html__( 'Gelden voor de hele site', 'webwerckt-base' ) . '</p>'
		. _ww_settings_render_nav( $section, 'panel' ) . _ww_settings_render_card( 'panel' ) . _ww_settings_render_foot() . '</nav>';

	$html .= '<div class="ww-settings-main">';
	$html .= '<div class="ww-settings-pickers">' . _ww_settings_render_nav( $section, 'menu' ) . '</div>';
	$html .= _ww_settings_render_head( $section, $label ) . $notice;
	$html .= 'contact' !== $section ? _ww_settings_render_card( 'mobile' ) : '';

	// Na een fout staan er niet-opgeslagen waarden in het formulier: het script begint dan met wijzigingen.
	$html .= '<form method="post" action="' . esc_url( _ww_settings_url( $section ) ) . '" class="ww-settings-form" id="ww-settings-form"' . ( $error instanceof WP_Error ? ' data-ww-dirty="1"' : '' ) . '>'
		. wp_nonce_field( 'ww_settings_save_' . $section, '_wpnonce', true, false )
		. '<input type="hidden" name="ww_settings_section" value="' . esc_attr( $section ) . '">'
		. '<input type="hidden" name="ww_next" value="">'
		. $boxes;
	// Zonder velden die het thema tekent valt er niets op te slaan: geen knop en geen balk.
	if ( array() !== _ww_settings_section_fields( $section ) ) {
		/* translators: %s: naam van het onderdeel, zoals SEO. */
		$only  = sprintf( __( 'Slaat alleen %s op.', 'webwerckt-base' ), $label );
		$html .= '<p class="submit"><button type="submit" class="button button-primary">' . esc_html__( 'Wijzigingen opslaan', 'webwerckt-base' ) . '</button> <span class="ww-settings-submit-note">' . esc_html( $only ) . '</span></p>';
		$html .= _ww_settings_render_savebar( $label );
	}
	$html .= '</form>';

	$html .= '</div></div></div>';
	echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- alle onderdelen escapen zelf.
}

/**
 * De teksten van het script, vertaald in PHP: het thema maakt geen vertaal-JSON voor scripts. Het script vult %s en
 * %1$d zelf in. De teksten van de invoer (lijsten en afbeeldingen) staan in _ww_field_inputs_texts().
 *
 * @return array<string,string>
 */
function _ww_settings_script_texts(): array {
	return array(
		'hoursBad'  => __( 'Schrijf als 08:00-16:00', 'webwerckt-base' ),
		/* translators: %s: openingstijden, bijvoorbeeld 08:00–12:30 en 13:00–18:00. */
		'hoursOpen' => __( 'Open %s', 'webwerckt-base' ),
		'and'       => __( 'en', 'webwerckt-base' ),
		'closed'    => __( 'Gesloten', 'webwerckt-base' ),
		/* translators: 1: aantal tekens, 2: het maximum. */
		'counter'   => __( '%1$d / %2$d tekens', 'webwerckt-base' ),
		'tooLong'   => __( ', wordt waarschijnlijk afgekapt', 'webwerckt-base' ),
	);
}

/**
 * Stijl en script van het scherm, alleen daar. De invoer van de velden (_ww_field_inputs_enqueue(): script, stijl,
 * mediabibliotheek en editor naar behoefte) laadt eerst; de code-editor alleen als het onderdeel een codeveld heeft.
 *
 * @param string $hook Hook van het scherm.
 */
function _ww_settings_admin_assets( string $hook ): void {
	if ( 'toplevel_page_' . WW_SETTINGS_SCREEN !== $hook ) {
		return;
	}
	$fields = _ww_settings_section_fields( _ww_settings_current_page() );
	_ww_field_inputs_enqueue( $fields );
	wp_enqueue_style( 'ww-settings-admin', _ww_asset_url( 'css/settings-admin.css' ), array( 'ww-field-inputs' ), WW_BASE_VERSION );
	$types = array();
	foreach ( $fields as $field ) {
		$types[ _ww_data_to_string( $field['type'] ?? '' ) ] = true;
	}
	$deps = array( 'ww-field-inputs' );
	// De code-editor moet vóór het script laden, anders is wp.codeEditor er nog niet als het script start.
	$code = isset( $types['code'] ) ? wp_enqueue_code_editor( array( 'type' => 'text/html' ) ) : false;
	if ( false !== $code ) {
		$deps[] = 'code-editor';
	}

	wp_enqueue_script( 'ww-settings-admin', _ww_asset_url( 'js/settings-admin.js' ), $deps, WW_BASE_VERSION, array( 'in_footer' => true ) );
	$data = array(
		'code'  => is_array( $code ) ? $code : null,
		'texts' => _ww_settings_script_texts(),
	);
	wp_add_inline_script( 'ww-settings-admin', 'window.wwSettings = ' . wp_json_encode( $data ) . ';', 'before' );
}
add_action( 'admin_enqueue_scripts', '_ww_settings_admin_assets' );
