<?php
/**
 * Browsercache zonder LiteSpeed Cache (beslissing 0022): de parent schrijft zelf de cacheregels en MIME-types in een
 * eigen blok in .htaccess, en herstelt dat blok als iets anders (Duplicator, een plugin) het weghaalt. CSS en JS
 * uit het child-thema krijgen een versie die meebeweegt met het bestand, zodat een lange cachetijd veilig is. In
 * hetzelfde blok staan een paar beveiligingsheaders (_ww_security_headers()); die blijven ook als de browsercache uit
 * staat of een andere plugin hem regelt.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Naam van het blok tussen # BEGIN en # END in .htaccess.
const WW_HTACCESS_MARKER = 'webwerckt-base';

// Option die onthoudt of de server de regels uitvoert, en de cronhook van de dagelijkse controle.
const WW_HTACCESS_SERVER_OPTION = 'ww_htaccess_server';
const WW_HTACCESS_CHECK_HOOK    = 'ww_htaccess_check';

/**
 * Of de parent de cacheregels schrijft.
 */
function _ww_browser_cache_enabled(): bool {
	/**
	 * Zet de browsercache-regels van het thema in .htaccess uit, bijvoorbeeld als de server ze zelf al zet.
	 *
	 * @param bool $enabled Standaard true.
	 */
	return (bool) apply_filters( 'ww_browser_cache', true );
}

/**
 * De regels in het blok. Alles staat in <IfModule>, zodat een server zonder die module geen fout geeft.
 * CSS en JS hebben een versie in de URL, de AVIF- en WebP-versies ook (inc/images.php); de samengevoegde CSS (een
 * hash als naam, beslissing 0020) en lettertypen veranderen nooit en zijn immutable. Afbeeldingen uit de
 * mediabibliotheek zelf hebben geen versie: maakt WordPress er een opnieuw onder dezelfde naam, dan kan de browser de
 * oude tot een jaar houden waar geen AVIF- of WebP-versie geserveerd wordt.
 *
 * Alleen directives die AllowOverride FileInfo nodig hebben, net als de rewrite-regels van WordPress. mod_expires
 * staat er bewust niet in: die vraagt AllowOverride Indexes, en waar dat niet mag, geeft de hele site (ook de admin)
 * een 500-fout. Cache-Control gaat in browsers toch vóór Expires.
 *
 * @return string[]
 */
function _ww_browser_cache_rules(): array {
	$rules = array(
		'<IfModule mod_mime.c>',
		'AddType image/avif .avif',
		'AddType image/webp .webp',
		'AddType font/woff2 .woff2',
		'</IfModule>',
		'<IfModule mod_headers.c>',
		'<FilesMatch "\.(css|js|mjs|jpe?g|png|gif|webp|avif|svg|ico)$">',
		'Header set Cache-Control "public, max-age=31536000"',
		'</FilesMatch>',
		'<FilesMatch "(\.woff2?|^' . WW_STYLES_PATTERN . '|^' . WW_SPRITE_PATTERN . ')$">',
		'Header set Cache-Control "public, max-age=31536000, immutable"',
		'</FilesMatch>',
		'</IfModule>',
	);
	/**
	 * Regels in het blok van webwerckt-base in .htaccess, één regel per item, zonder commentaar.
	 *
	 * @param string[] $rules Standaardregels.
	 */
	return _ww_htaccess_lines( (array) apply_filters( 'ww_browser_cache_rules', $rules ) );
}

/**
 * Beveiligingsheaders voor elk antwoord van de site, ook de pagina's uit de statische paginacache (beslissing 0029),
 * die PHP niet raken; daarom in .htaccess en niet via send_headers.
 *
 * - X-Content-Type-Options: de browser raadt geen ander bestandstype dan de server opgeeft.
 * - Referrer-Policy: andere sites zien alleen het domein, niet de hele URL (met zoektermen of tokens).
 * - X-Frame-Options: geen andere site kan de site in een iframe laden (clickjacking); de visuele editor laadt de
 *   pagina van dezelfde site en werkt gewoon.
 *
 * Header set en niet Header always set: WordPress stuurt in het beheer en op het inlogscherm zelf X-Frame-Options en
 * Referrer-Policy (met dezelfde waarden), en set vervangt die in plaats van een tweede header toe te voegen.
 *
 * @return array<string,string> Naam => waarde.
 */
function _ww_security_headers(): array {
	$headers = array(
		'X-Content-Type-Options' => 'nosniff',
		'Referrer-Policy'        => 'strict-origin-when-cross-origin',
		'X-Frame-Options'        => 'SAMEORIGIN',
	);
	/**
	 * Beveiligingsheaders in het blok van webwerckt-base in .htaccess. Een header weghalen of een lege array (alles
	 * uit) kan, bijvoorbeeld als de server ze zelf al zet; een extra header toevoegen ook.
	 *
	 * @param array<string,string> $headers Naam => waarde.
	 */
	$headers = (array) apply_filters( 'ww_security_headers', $headers );

	$clean = array();
	foreach ( $headers as $name => $value ) {
		$name  = preg_replace( '/[^A-Za-z0-9-]/', '', (string) $name );
		$value = trim( (string) preg_replace( '/["\r\n]/', '', _ww_data_to_string( $value ) ) );
		if ( '' !== $name && '' !== $value ) {
			$clean[ $name ] = $value;
		}
	}
	return $clean;
}

/**
 * De regels van de beveiligingsheaders, of geen als _ww_security_headers() leeg is.
 *
 * @return string[]
 */
function _ww_security_header_rules(): array {
	$headers = _ww_security_headers();
	if ( array() === $headers ) {
		return array();
	}
	$rules = array( '<IfModule mod_headers.c>' );
	foreach ( $headers as $name => $value ) {
		$rules[] = 'Header set ' . $name . ' "' . $value . '"';
	}
	$rules[] = '</IfModule>';
	return $rules;
}

/**
 * Map van de uploads ten opzichte van de map met .htaccess (zoals `wp-content/uploads`), of '' als de uploads daar
 * niet onder staan.
 */
function _ww_htaccess_uploads_path(): string {
	require_once ABSPATH . 'wp-admin/includes/file.php';
	$home    = wp_normalize_path( get_home_path() );
	$uploads = wp_normalize_path( (string) wp_upload_dir( null, false )['basedir'] );
	return '' !== $home && str_starts_with( $uploads, $home ) ? trim( substr( $uploads, strlen( $home ) ), '/' ) : '';
}

/**
 * Regels die bestanden afschermen die nooit via de browser opgevraagd horen te worden:
 *
 * - wp-config.php en readme.html (die noemt de versie van WordPress);
 * - verborgen bestanden en mappen (.git, .env, .user.ini), behalve .well-known (Let's Encrypt);
 * - back-ups, databasedumps en logbestanden (.sql, .bak, .old, .orig, .swp, .log, een ~ aan het eind), zoals debug.log;
 * - PHP in de uploads: daar hoort geen code te staan, en een geüpload script draait dan niet.
 *
 * Met mod_rewrite, want die vraagt net als de regels van WordPress alleen AllowOverride FileInfo. Require all denied
 * vraagt AuthConfig en Options -Indexes vraagt Options: waar dat niet mag, geeft de hele site een 500-fout. Mappen
 * zonder index tonen daarom nog steeds een lijst als de server dat toestaat.
 *
 * Een bestand dat bestaat, slaan de regels van WordPress over, dus deze regels zien het ook na `# BEGIN WordPress`.
 * Een map met een eigen .htaccess met RewriteEngine (zoals de paginacache) volgt deze regels niet.
 *
 * @return string[]
 */
function _ww_protect_files_rules(): array {
	/**
	 * Zet het afschermen van gevoelige bestanden en PHP in de uploads uit, bijvoorbeeld als de server het zelf al doet.
	 *
	 * @param bool $protect Standaard true.
	 */
	if ( ! apply_filters( 'ww_protect_files', true ) ) {
		return array();
	}
	$rules   = array(
		'<IfModule mod_rewrite.c>',
		'RewriteEngine On',
		'RewriteRule (^|/)(wp-config\.php|readme\.html)$ - [F]',
		'RewriteCond %{REQUEST_URI} !/\.well-known/',
		'RewriteRule (^|/)\. - [F]',
		'RewriteRule (\.(sql|sql\.gz|bak|old|orig|swp|log)|~)$ - [NC,F]',
	);
	// Alleen een gewoon pad: een spatie of aanhalingsteken breekt de regel, en dan geeft de hele site een 500-fout.
	$uploads = _ww_htaccess_uploads_path();
	if ( 1 === preg_match( '#^[A-Za-z0-9._/-]+$#', $uploads ) ) {
		$rules[] = 'RewriteRule ^' . str_replace( '.', '\.', $uploads ) . '/.*\.(php[0-9]?|phtml|phar|pht)$ - [NC,F]';
	}
	$rules[] = '</IfModule>';
	return $rules;
}

/**
 * Alle regels in het blok bij een stand van _ww_htaccess_wanted(): de browsercache alleen bij 'ok', de
 * beveiligingsheaders en het afschermen van bestanden altijd.
 *
 * @param string $status Stand van _ww_htaccess_wanted().
 * @return string[]
 */
function _ww_htaccess_rules( string $status ): array {
	$cache = 'ok' === $status || 'server' === $status ? _ww_browser_cache_rules() : array();
	return array_merge( $cache, _ww_security_header_rules(), _ww_protect_files_rules() );
}

/**
 * Regels zonder lege regels en commentaar, zoals ze in het blok vergeleken worden. insert_with_markers() zet zelf
 * uitleg als commentaar in het blok.
 *
 * @param array<mixed> $lines Regels.
 * @return string[]
 */
function _ww_htaccess_lines( array $lines ): array {
	$lines = array_map( static fn( mixed $line ): string => trim( _ww_data_to_string( $line ) ), $lines );
	return array_values( array_filter( $lines, static fn( string $line ): bool => '' !== $line && ! str_starts_with( $line, '#' ) ) );
}

/**
 * Zet een andere cacheplugin al browsercache-regels in .htaccess? Dan schrijft de parent niets, tegen dubbele of
 * tegenstrijdige headers.
 *
 * @param string $htaccess Inhoud van .htaccess.
 */
function _ww_browser_cache_other_plugin( string $htaccess ): bool {
	foreach ( array( '### marker BROWSER CACHE start ###', '# BEGIN W3TC Browser Cache', '# BEGIN WP Rocket' ) as $marker ) {
		if ( str_contains( $htaccess, $marker ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Pad van de .htaccess van de site.
 */
function _ww_htaccess_path(): string {
	require_once ABSPATH . 'wp-admin/includes/file.php';
	return get_home_path() . '.htaccess';
}

/**
 * Leest .htaccess de server? Apache en LiteSpeed wel (WordPress zet $is_apache voor beide), nginx niet. Op de
 * commandoregel (WP-CLI, een cron in Plesk met php wp-cron.php) is dat niet te zien; dan geldt wat het laatste
 * webverzoek in de admin zag (_ww_htaccess_remember_server()), zodat de dagelijkse controle, een deploy-script en een
 * themawissel via WP-CLI ook werken.
 *
 * @param string $sapi Server-API van PHP.
 */
function _ww_htaccess_supported( string $sapi = PHP_SAPI ): bool {
	if ( 'cli' === $sapi && empty( $GLOBALS['is_apache'] ) ) {
		return '1' === get_option( WW_HTACCESS_SERVER_OPTION );
	}
	return ! empty( $GLOBALS['is_apache'] );
}

/**
 * Onthoudt bij een webverzoek in de admin of de server .htaccess leest, voor de commandoregel. Vóór de controle op
 * admin_init, zodat die en een themawissel de actuele stand zien.
 *
 * @param string $sapi Server-API van PHP.
 */
function _ww_htaccess_remember_server( string $sapi = PHP_SAPI ): void {
	if ( 'cli' === $sapi ) {
		return;
	}
	$supported = _ww_htaccess_supported( $sapi ) ? '1' : '0';
	if ( get_option( WW_HTACCESS_SERVER_OPTION ) !== $supported ) {
		update_option( WW_HTACCESS_SERVER_OPTION, $supported, true );
	}
}
add_action( 'admin_init', '_ww_htaccess_remember_server', 9, 0 );

/**
 * Wat er in het blok hoort, zonder te schrijven.
 *
 * @param string $file Pad van .htaccess.
 * @return string 'ok' (de regels), 'disabled' (filter ww_browser_cache), 'other' (een andere plugin zet de regels)
 *                of 'server' (de server leest geen .htaccess). Alleen bij 'ok' staan de browsercache-regels in het
 *                blok; de beveiligingsheaders staan er altijd in (_ww_htaccess_rules()).
 */
function _ww_htaccess_wanted( string $file ): string {
	if ( ! _ww_htaccess_supported() ) {
		return 'server';
	}
	if ( ! _ww_browser_cache_enabled() ) {
		return 'disabled';
	}
	$contents = is_file( $file ) ? (string) file_get_contents( $file ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- lokaal bestand.
	return _ww_browser_cache_other_plugin( $contents ) ? 'other' : 'ok';
}

/**
 * Of het blok in .htaccess precies deze regels bevat.
 *
 * @param string   $file  Pad van .htaccess.
 * @param string[] $rules Regels.
 */
function _ww_htaccess_matches( string $file, array $rules ): bool {
	require_once ABSPATH . 'wp-admin/includes/misc.php';
	return _ww_htaccess_lines( extract_from_markers( $file, WW_HTACCESS_MARKER ) ) === $rules;
}

/**
 * Zet regels in het blok, alleen als het afwijkt. Buiten het blok verandert niets.
 *
 * @param string   $file  Pad van .htaccess.
 * @param string[] $rules Regels; leeg haalt het blok leeg.
 * @return bool Of het blok nu klopt.
 */
function _ww_htaccess_write( string $file, array $rules ): bool {
	return _ww_htaccess_matches( $file, $rules ) || insert_with_markers( $file, WW_HTACCESS_MARKER, $rules );
}

/**
 * Zorgt dat het blok in .htaccess klopt.
 *
 * @param string $file Pad van .htaccess; leeg is die van de site.
 * @return string De stand van _ww_htaccess_wanted(), of 'unwritable' als het blok niet bijgewerkt kon worden.
 */
function _ww_htaccess_sync( string $file = '' ): string {
	$file   = '' !== $file ? $file : _ww_htaccess_path();
	$status = _ww_htaccess_wanted( $file );
	if ( 'server' === $status ) {
		return $status;
	}
	return _ww_htaccess_write( $file, _ww_htaccess_rules( $status ) ) ? $status : 'unwritable';
}

/**
 * Controleert het blok: na het activeren van het thema, bij het eerste bezoek van een beheerder aan de admin (na
 * een Duplicator-installatie die .htaccess vervangt) en dagelijks via de cron. Het controleren is één keer een klein
 * bestand lezen. Een eigen functie zonder parameters, want after_switch_theme geeft argumenten mee.
 */
function _ww_htaccess_check(): void {
	_ww_htaccess_sync();
}
add_action( 'after_switch_theme', '_ww_htaccess_check' );
add_action( WW_HTACCESS_CHECK_HOOK, '_ww_htaccess_check' );

/**
 * Controle bij een bezoek van een beheerder aan de admin.
 */
function _ww_htaccess_admin_check(): void {
	if ( current_user_can( 'manage_options' ) && ! wp_doing_ajax() ) {
		_ww_htaccess_sync();
	}
}
add_action( 'admin_init', '_ww_htaccess_admin_check' );

/**
 * Plant de dagelijkse controle in.
 */
function _ww_htaccess_schedule(): void {
	if ( ! wp_next_scheduled( WW_HTACCESS_CHECK_HOOK ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', WW_HTACCESS_CHECK_HOOK );
	}
}
add_action( 'init', '_ww_htaccess_schedule' );

/**
 * Ander thema actief: het blok leeg en de controle weg.
 */
function _ww_htaccess_remove(): void {
	if ( _ww_htaccess_supported() ) {
		_ww_htaccess_write( _ww_htaccess_path(), array() );
	}
	wp_clear_scheduled_hook( WW_HTACCESS_CHECK_HOOK );
}
add_action( 'switch_theme', '_ww_htaccess_remove' );

/**
 * Test in Site-status: staat het blok in .htaccess, en zo niet, waarom. Schrijft zelf niets: admin_init heeft het
 * blok in dit verzoek al bijgewerkt, dus wijkt het nog af, dan is .htaccess niet schrijfbaar.
 *
 * @return array<string,mixed>
 */
function _ww_browser_cache_health(): array {
	$file   = _ww_htaccess_path();
	$status = _ww_htaccess_wanted( $file );
	$rules  = _ww_htaccess_rules( $status );
	if ( 'server' !== $status && ! _ww_htaccess_matches( $file, $rules ) ) {
		$status = 'unwritable';
	}
	$labels      = array(
		'ok'         => __( 'De browsercache-regels van Webwerckt Base staan in .htaccess', 'webwerckt-base' ),
		'disabled'   => __( 'De browsercache-regels van Webwerckt Base staan uit (filter ww_browser_cache)', 'webwerckt-base' ),
		'other'      => __( 'Een andere cacheplugin zet de browsercache-regels in .htaccess', 'webwerckt-base' ),
		'server'     => __( 'De server leest geen .htaccess: stel de browsercache in de serverconfiguratie in', 'webwerckt-base' ),
		'unwritable' => __( '.htaccess is niet schrijfbaar: het blok van Webwerckt Base klopt niet', 'webwerckt-base' ),
	);
	$description = '<p>' . esc_html__( 'Afbeeldingen, CSS, JavaScript en lettertypen mogen een jaar in de browser blijven; een nieuwe versie krijgt een nieuwe URL.', 'webwerckt-base' ) . '</p>';
	if ( 'unwritable' === $status || 'server' === $status ) {
		$block        = '# BEGIN ' . WW_HTACCESS_MARKER . "\n" . implode( "\n", $rules ) . "\n# END " . WW_HTACCESS_MARKER;
		$description .= '<p>' . esc_html__( 'Zet dit blok zelf in de .htaccess van de site (of de serverconfiguratie):', 'webwerckt-base' ) . '</p><pre>' . esc_html( $block ) . '</pre>';
	}

	return _ww_health_result( 'ww_browser_cache', $labels[ $status ], in_array( $status, array( 'unwritable', 'server' ), true ) ? 'recommended' : 'good', $description );
}

/**
 * Meldt de test in Site-status aan.
 *
 * @param array<string,array<string,mixed>> $tests Tests van WordPress.
 * @return array<string,array<string,mixed>>
 */
function _ww_browser_cache_health_test( array $tests ): array {
	$tests['direct']['ww_browser_cache'] = array(
		'label' => __( 'Browsercache', 'webwerckt-base' ),
		'test'  => '_ww_browser_cache_health',
	);
	return $tests;
}
add_filter( 'site_status_tests', '_ww_browser_cache_health_test' );

/**
 * Geeft CSS en JS uit het child-thema de wijzigingsdatum van het bestand als versie, als het child-thema zelf geen
 * eigen versie meegeeft (geen, die van WordPress of die van het thema). Dan breekt een vergeten versieophoging
 * niets: met een cachetijd van een jaar zou de browser anders het oude bestand blijven gebruiken.
 *
 * @param mixed $src URL van de stylesheet of het script.
 * @return mixed
 */
function _ww_asset_version( $src ) {
	$file = is_string( $src ) ? _ww_theme_file( $src, get_stylesheet_directory_uri(), get_stylesheet_directory() ) : '';
	if ( '' === $file ) {
		return $src;
	}
	wp_parse_str( (string) wp_parse_url( $src, PHP_URL_QUERY ), $query );
	$version = _ww_data_to_string( $query['ver'] ?? '' );
	if ( ! in_array( $version, array( '', get_bloginfo( 'version' ), (string) wp_get_theme()->get( 'Version' ) ), true ) || ! is_file( $file ) ) {
		return $src;
	}
	return add_query_arg( 'ver', (string) filemtime( $file ), $src );
}
add_filter( 'style_loader_src', '_ww_asset_version' );
add_filter( 'script_loader_src', '_ww_asset_version' );
add_filter( 'script_module_loader_src', '_ww_asset_version' );
