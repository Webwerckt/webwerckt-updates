<?php
/**
 * Een bericht dupliceren als concept (spec pagina-dupliceren).
 *
 * _ww_post_duplicate() doet de controles, zet de bovenliggende pagina om en laat het kopiëren aan _ww_post_copy()
 * (post-copy.php) in de modus duplicate. De kopie hoort bij geen vertaalgroep, heeft de taal van de bron en staat als
 * één regel "Gedupliceerd" in het activiteitenlog. Wat niet meeging, onthoudt een transient per gebruiker, zodat de
 * editor van de kopie het één keer kan melden.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Mag de huidige gebruiker dit bericht dupliceren? Dezelfde rechten als vertalen, een soort inhoud die de abilities
 * kennen (geen formulier, bijlage of intern type) en een bron die niet in de prullenbak ligt.
 */
function _ww_post_can_duplicate( int $source_id ): bool {
	$status = get_post_status( $source_id );
	return false !== $status && 'trash' !== $status
		&& null !== _ww_abilities_type_object( (string) get_post_type( $source_id ) )
		&& _ww_translation_can_create( $source_id );
}

/**
 * Dupliceert een bericht als concept: zelfde template, velden, termen en bovenliggende pagina, de huidige gebruiker
 * als auteur en een lege slug.
 *
 * @param int                  $source_id Bericht om te dupliceren.
 * @param array<string,string> $args      title (optioneel); leeg wordt "Kopie van …".
 * @return array{id:int,source_id:int,status:'draft',edit_url:string,dropped:array<int,array{field:string,id:int}>,dropped_labels:string[]}|WP_Error
 */
function _ww_post_duplicate( int $source_id, array $args = array() ): array|WP_Error {
	$source = get_post( $source_id );
	if ( ! $source instanceof WP_Post || 'trash' === $source->post_status ) {
		return new WP_Error( 'ww_duplicate_source', __( 'Het bericht om te dupliceren bestaat niet.', 'webwerckt-base' ), array( 'status' => 404 ) );
	}
	if ( null === _ww_abilities_type_object( $source->post_type ) ) {
		return new WP_Error( 'ww_duplicate_type', __( 'Dit soort inhoud kun je niet dupliceren.', 'webwerckt-base' ), array( 'status' => 400 ) );
	}
	if ( ! _ww_post_can_duplicate( $source_id ) ) {
		return new WP_Error( 'ww_duplicate_forbidden', __( 'Je mag dit bericht niet dupliceren.', 'webwerckt-base' ), array( 'status' => 403 ) );
	}

	$dropped = array();
	$parent  = $source->post_parent;
	if ( $parent > 0 && in_array( get_post_status( $parent ), array( false, 'trash' ), true ) ) {
		$dropped[] = array(
			'field' => 'post_parent',
			'id'    => $parent,
		);
		$parent    = 0;
	}

	$title = isset( $args['title'] ) && '' !== trim( $args['title'] )
		? $args['title']
		/* translators: %s: titel van het bericht dat gedupliceerd wordt. */
		: sprintf( __( 'Kopie van %s', 'webwerckt-base' ), $source->post_title );
	$copied = _ww_post_copy(
		$source,
		'duplicate',
		array(
			'title'  => $title,
			'slug'   => '',
			'parent' => $parent,
			'lang'   => _ww_languages_active() ? _ww_post_language( $source_id ) : '',
		)
	);
	if ( is_wp_error( $copied ) ) {
		return $copied;
	}
	$new     = $copied['id'];
	$dropped = array_merge( $dropped, $copied['dropped'] );
	$target  = get_post( $new );

	// Eén regel in het log: "Gedupliceerd" gaat boven het "Aangemaakt" en "Bijgewerkt" van de kopie in de buffer.
	if ( _ww_activity_post_type_logged( $source->post_type ) ) {
		_ww_activity_add( 'post', $new, 'duplicated', array(), $source->post_type, $title );
	}

	$labels = $target instanceof WP_Post ? _ww_duplicate_dropped_labels( $dropped, $target ) : array();
	if ( array() !== $labels ) {
		_ww_duplicate_remember( $new, $labels );
	}

	$edit_url = $target instanceof WP_Post && _ww_editor_supports( $target )
		? _ww_editor_url( $new )
		: ( get_edit_post_link( $new, 'raw' ) ?? admin_url( 'post.php?post=' . $new . '&action=edit' ) );

	return array(
		'id'             => $new,
		'source_id'      => $source_id,
		'status'         => 'draft',
		'edit_url'       => $edit_url,
		'dropped'        => $dropped,
		'dropped_labels' => $labels,
	);
}

/**
 * De labels van de velden die niet meegingen, elk één keer, in volgorde. Zonder controle op rechten: ook een
 * afgeschermd veld krijgt zijn label. Een onbekend veld krijgt zijn naam.
 *
 * @param array<int,array{field:string,id:int}> $dropped Wat wegviel.
 * @param WP_Post                               $post    De kopie (voor de velden van zijn template).
 * @return string[]
 */
function _ww_duplicate_dropped_labels( array $dropped, WP_Post $post ): array {
	$known = array( 'post_parent' => __( 'Bovenliggende pagina', 'webwerckt-base' ) );
	foreach ( _ww_pods_fields( $post->post_type, $post->ID ) as $field ) {
		$name = _ww_data_to_string( $field['name'] ?? '' );
		if ( '' !== $name && ! isset( $known[ $name ] ) ) {
			$known[ $name ] = _ww_data_to_string( $field['label'] ?? $name );
		}
	}
	$labels = array();
	foreach ( $dropped as $item ) {
		$labels[] = $known[ $item['field'] ] ?? $item['field'];
	}
	return array_values( array_unique( $labels ) );
}

/**
 * Onthoudt voor de huidige gebruiker wat er bij het dupliceren niet meeging (10 minuten).
 *
 * @param string[] $labels Labels uit _ww_duplicate_dropped_labels().
 */
function _ww_duplicate_remember( int $post_id, array $labels ): void {
	set_transient(
		'ww_duplicate_dropped_' . get_current_user_id(),
		array(
			'id'     => $post_id,
			'labels' => array_values( $labels ),
		),
		10 * MINUTE_IN_SECONDS
	);
}

/**
 * De onthouden labels voor deze kopie, één keer: daarna is de transient weg. Voor een ander bericht een lege lijst
 * (en de transient blijft).
 *
 * @return string[]
 */
function _ww_duplicate_take( int $post_id ): array {
	$key    = 'ww_duplicate_dropped_' . get_current_user_id();
	$stored = get_transient( $key );
	if ( ! is_array( $stored ) || (int) ( $stored['id'] ?? 0 ) !== $post_id ) {
		return array();
	}
	delete_transient( $key );
	return array_values( array_filter( (array) ( $stored['labels'] ?? array() ), 'is_string' ) );
}

/**
 * Onthoudt voor de huidige gebruiker de melding van een mislukte poging uit de lijst (1 minuut). De melding gaat niet
 * via de URL: daar staat alleen de foutcode.
 */
function _ww_duplicate_remember_error( string $message ): void {
	set_transient( 'ww_duplicate_error_' . get_current_user_id(), $message, MINUTE_IN_SECONDS );
}

/**
 * De onthouden melding van een mislukte poging, één keer; '' als er geen is.
 */
function _ww_duplicate_take_error(): string {
	$key     = 'ww_duplicate_error_' . get_current_user_id();
	$message = get_transient( $key );
	delete_transient( $key );
	return is_string( $message ) ? $message : '';
}

/**
 * POST ww/v1/editor/{id}/duplicate: dupliceert de pagina vanuit Visueel bewerken. Geregistreerd door
 * _ww_editor_register_routes().
 */
function _ww_duplicate_register_route(): void {
	register_rest_route(
		WW_REST_NAMESPACE,
		'/editor/(?P<id>\d+)/duplicate',
		array(
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => '_ww_duplicate_rest',
			'permission_callback' => static fn( WP_REST_Request $request ): bool => _ww_post_can_duplicate( (int) $request->get_param( 'id' ) ),
			'args'                => array(
				'id' => WW_EDITOR_ID_ARG,
			),
		)
	);
}

/**
 * POST ww/v1/editor/{id}/duplicate: de uitvoer van _ww_post_duplicate() plus editor_url (gelijk aan edit_url, dezelfde
 * naam als bij translations). Een fout gaat door met zijn status.
 *
 * @return array<string,mixed>|WP_Error
 */
function _ww_duplicate_rest( WP_REST_Request $request ): array|WP_Error {
	$result = _ww_post_duplicate( (int) $request->get_param( 'id' ) );
	if ( is_wp_error( $result ) ) {
		return $result;
	}
	return $result + array( 'editor_url' => $result['edit_url'] );
}

/**
 * De beveiligde link die een bericht dupliceert.
 */
function _ww_duplicate_url( int $post_id ): string {
	return wp_nonce_url( admin_url( 'admin-post.php?action=ww_duplicate&post=' . $post_id ), 'ww_duplicate_' . $post_id );
}

/**
 * Zet "Dupliceren" in de tabel, na Visueel bewerken (prioriteit 10), voor wie het bericht mag dupliceren.
 *
 * @param array<string,string> $actions Acties per sleutel, als HTML.
 * @return array<string,string>
 */
function _ww_duplicate_row_action( array $actions, WP_Post $post ): array {
	if ( ! _ww_post_can_duplicate( $post->ID ) ) {
		return $actions;
	}
	$actions['ww_duplicate'] = sprintf( '<a href="%s">%s</a>', esc_url( _ww_duplicate_url( $post->ID ) ), esc_html__( 'Dupliceren', 'webwerckt-base' ) );
	return $actions;
}
add_filter( 'page_row_actions', '_ww_duplicate_row_action', 20, 2 );
add_filter( 'post_row_actions', '_ww_duplicate_row_action', 20, 2 );

/**
 * Dupliceert het bericht uit de link en gaat naar de kopie; bij een fout terug naar de lijst met de foutcode, en de
 * melding van de fout onthouden voor _ww_duplicate_notices().
 */
function _ww_duplicate_handle(): void {
	$id = isset( $_REQUEST['post'] ) ? absint( wp_unslash( $_REQUEST['post'] ) ) : 0;
	check_admin_referer( 'ww_duplicate_' . $id );

	$result = _ww_post_duplicate( $id );
	if ( is_wp_error( $result ) ) {
		_ww_duplicate_remember_error( $result->get_error_message() );
		$type = get_post_type( $id );
		wp_safe_redirect(
			add_query_arg(
				'ww_duplicate_error',
				$result->get_error_code(),
				admin_url( 'edit.php?post_type=' . ( false !== $type ? $type : 'page' ) )
			)
		);
		exit;
	}
	wp_safe_redirect( $result['edit_url'] );
	exit;
}
add_action( 'admin_post_ww_duplicate', '_ww_duplicate_handle' );

/**
 * Meldingen: een fout na een mislukte poging (lijst) en wat er niet meeging (scherm van de kopie, één keer).
 */
function _ww_duplicate_notices(): void {
	global $pagenow;
	if ( 'edit.php' === $pagenow && isset( $_GET['ww_duplicate_error'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen een melding.
		// De melding van de fout komt uit de transient, nooit uit de URL.
		$message = _ww_duplicate_take_error();
		$text    = '' !== $message
			/* translators: %s: melding van de fout, zoals "Je mag dit bericht niet dupliceren." */
			? sprintf( __( 'Dupliceren is niet gelukt: %s', 'webwerckt-base' ), $message )
			: __( 'Dupliceren is niet gelukt.', 'webwerckt-base' );
		printf( '<div class="notice notice-error is-dismissible"><p>%s</p></div>', esc_html( $text ) );
		return;
	}
	if ( 'post.php' === $pagenow && isset( $_GET['post'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen een melding.
		$labels = _ww_duplicate_take( absint( wp_unslash( $_GET['post'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( array() !== $labels ) {
			/* translators: %s: namen van de velden die niet meegingen. */
			printf( '<div class="notice notice-warning is-dismissible"><p>%s</p></div>', esc_html( sprintf( __( 'Niet alles kon mee: %s', 'webwerckt-base' ), implode( ', ', $labels ) ) ) );
		}
	}
}
add_action( 'admin_notices', '_ww_duplicate_notices' );
