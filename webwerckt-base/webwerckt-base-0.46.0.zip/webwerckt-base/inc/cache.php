<?php
/**
 * Wat er in een paginacache leeg moet als er iets verandert (beslissing 0014 en 0028).
 *
 * Deze laag kent geen cache. Ze luistert naar WordPress en meldt met drie interne acties wat er leeg moet:
 * _ww_purge_post ($post_id: de eigen pagina van dat bericht), _ww_purge_post_type ($post_type: elke pagina die items
 * van dat post type toont) en _ww_purge_all (alles).
 * De afnemers vertalen dat naar hun eigen cache: inc/integrations/litespeed.php naar LiteSpeed, en straks de
 * eigen paginacache. Zo bepaalt één plek wat er leeg moet, en lopen de caches nooit uit elkaar.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Meldt dat elke pagina met items van dit post type leeg moet.
 *
 * @param mixed $post_type Post type; een hook kan van alles doorgeven, dus pas na controle een string.
 */
function _ww_cache_purge_post_type( $post_type ): void {
	$post_type = _ww_data_to_string( $post_type );
	if ( '' !== $post_type ) {
		do_action( '_ww_purge_post_type', $post_type );
	}
}

/**
 * Meldt dat de hele cache leeg moet.
 */
function _ww_cache_purge_all(): void {
	do_action( '_ww_purge_all' );
}
add_action( 'ww_output_changed', '_ww_cache_purge_all' );

/**
 * Leegt de eigen pagina van een opgeslagen of verwijderd item, en de pagina's die zijn post type tonen. LiteSpeed
 * leegt de eigen pagina zelf en luistert alleen naar het post type.
 */
function _ww_cache_purge_post( int $post_id ): void {
	if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
		return;
	}
	do_action( '_ww_purge_post', $post_id );
	$post_type = get_post_type( $post_id );
	if ( $post_type ) {
		_ww_cache_purge_post_type( $post_type );
	}
}
add_action( 'deleted_post', '_ww_cache_purge_post' );

/**
 * Opgeslagen, gepubliceerd, teruggezet naar concept of naar de prullenbak: leegt het post type als het item voor
 * of na de wijziging zichtbaar is voor bezoekers. Een concept of auto-draft staat op geen enkele openbare
 * pagina, dus tussentijds opslaan laat de cache staan.
 *
 * @param mixed $new_status Nieuwe status.
 * @param mixed $old_status Vorige status ('new' bij een nieuw bericht).
 * @param mixed $post       Bericht.
 */
function _ww_cache_purge_on_status( $new_status, $old_status, $post ): void {
	if ( ! $post instanceof WP_Post ) {
		return;
	}
	if ( is_post_status_viewable( (string) $new_status ) || is_post_status_viewable( (string) $old_status ) ) {
		_ww_cache_purge_post( $post->ID );
	}
}
add_action( 'transition_post_status', '_ww_cache_purge_on_status', 10, 3 );

/**
 * Term aangemaakt, gewijzigd of verwijderd: de pagina's van de post types van die taxonomie leeg,
 * want daar staan de termen als filterlinks of labels.
 *
 * @param mixed $term_id  Term-ID.
 * @param mixed $tt_id    Term-taxonomie-ID.
 * @param mixed $taxonomy Taxonomie; een hook kan van alles doorgeven, dus pas na controle een string.
 */
function _ww_cache_purge_term( $term_id, $tt_id, $taxonomy ): void {
	$object = is_string( $taxonomy ) ? get_taxonomy( $taxonomy ) : false;
	foreach ( $object ? $object->object_type : array() as $post_type ) {
		_ww_cache_purge_post_type( (string) $post_type );
	}
}
add_action( 'created_term', '_ww_cache_purge_term', 10, 3 );
add_action( 'edited_term', '_ww_cache_purge_term', 10, 3 );
add_action( 'delete_term', '_ww_cache_purge_term', 10, 3 );

/**
 * Leegt de pagina's die een menu tonen (ww_menu()) als een bericht of term in een menu staat.
 * Menu-items zelf zijn berichten: opslaan of verwijderen leegt nav_menu_item al via de purges hierboven.
 *
 * @param string $object_type 'post_type' of 'taxonomy'.
 */
function _ww_cache_purge_menu_of( string $object_type, int $object_id, string $taxonomy = '' ): void {
	if ( array() !== wp_get_associated_nav_menu_items( $object_id, $object_type, $taxonomy ) ) {
		_ww_cache_purge_post_type( 'nav_menu_item' );
	}
}

/**
 * Leegt de pagina's die een menu tonen als een van deze berichten in een menu staat; één keer, hoeveel er ook in staan.
 * Voor Meertalig (beslissing 0042): het automatische menu van een extra taal toont de vertaling van een bericht dat
 * zelf in het menu staat, dus een wijziging aan een lid van een vertaalgroep raakt het menu van de hele groep.
 *
 * @param int[] $post_ids Post-ID's.
 */
function _ww_cache_purge_menu_of_posts( array $post_ids ): void {
	foreach ( array_unique( array_map( 'intval', $post_ids ) ) as $id ) {
		if ( $id > 0 && array() !== wp_get_associated_nav_menu_items( $id, 'post_type' ) ) {
			_ww_cache_purge_post_type( 'nav_menu_item' );
			return;
		}
	}
}

/**
 * Titel, slug, ouder of status van een bericht gewijzigd: het menu toont zijn titel en URL, of verbergt het. Met
 * Meertalig ook als een ander lid van zijn vertaalgroep in een menu staat. Publiceren, de prullenbak en verwijderen
 * van een lid leegt het menu ook via _ww_translations_purge() (inc/languages-store.php).
 *
 * @param mixed $post_id Bericht-ID.
 * @param mixed $after   Bericht na de wijziging.
 * @param mixed $before  Bericht voor de wijziging.
 */
function _ww_cache_purge_menu_on_post_update( $post_id, $after, $before ): void {
	if ( ! $after instanceof WP_Post || ! $before instanceof WP_Post ) {
		return;
	}
	$changed = $after->post_title !== $before->post_title
		|| $after->post_name !== $before->post_name
		|| $after->post_parent !== $before->post_parent
		|| $after->post_status !== $before->post_status;
	if ( $changed ) {
		$group = _ww_languages_active() ? array_values( _ww_translations( (int) $post_id ) ) : array();
		_ww_cache_purge_menu_of_posts( array_merge( array( (int) $post_id ), $group ) );
	}
}
add_action( 'post_updated', '_ww_cache_purge_menu_on_post_update', 10, 3 );

/**
 * Term gewijzigd: het menu toont zijn naam en URL.
 *
 * @param mixed $term_id  Term-ID.
 * @param mixed $tt_id    Term-taxonomie-ID.
 * @param mixed $taxonomy Taxonomie.
 */
function _ww_cache_purge_menu_on_term_edit( $term_id, $tt_id, $taxonomy ): void {
	if ( is_string( $taxonomy ) ) {
		_ww_cache_purge_menu_of( 'taxonomy', (int) $term_id, $taxonomy );
	}
}
add_action( 'edited_term', '_ww_cache_purge_menu_on_term_edit', 10, 3 );

/**
 * Ander menu op een menulocatie (menuscherm of Customizer): de pagina's met een menu leeg.
 * Een filter, omdat set_theme_mod() alleen hier de oude en nieuwe waarde samen doorgeeft; de waarde blijft gelijk.
 *
 * @param mixed $value     Nieuwe menulocaties.
 * @param mixed $old_value Vorige menulocaties.
 * @return mixed
 */
function _ww_cache_purge_on_menu_locations( $value, $old_value ) {
	if ( $value !== $old_value ) {
		_ww_cache_purge_post_type( 'nav_menu_item' );
	}
	return $value;
}
add_filter( 'pre_set_theme_mod_nav_menu_locations', '_ww_cache_purge_on_menu_locations', 10, 2 );

// Opties van WordPress zelf die op elke pagina terugkomen: sitenaam, icoon, voorpagina, permalinks, datum en taal.
const WW_CACHE_PURGE_OPTIONS = array( 'blogname', 'blogdescription', 'site_icon', 'show_on_front', 'page_on_front', 'page_for_posts', 'permalink_structure', 'category_base', 'tag_base', 'date_format', 'time_format', 'start_of_week', 'WPLANG', 'timezone_string', 'gmt_offset' );

/**
 * Optie van de Site-instellingen of een optie uit WW_CACHE_PURGE_OPTIONS gewijzigd: hele cache leeg, want ze staan op
 * elke pagina.
 *
 * @param mixed $option Naam van de optie; een hook kan van alles doorgeven, dus pas na controle een string.
 */
function _ww_cache_purge_on_settings_save( $option ): void {
	if ( ! is_string( $option ) ) {
		return;
	}
	$prefix = _ww_settings_prefix();
	if ( ( '' !== $prefix && str_starts_with( $option, $prefix ) ) || in_array( $option, WW_CACHE_PURGE_OPTIONS, true ) ) {
		_ww_cache_purge_all();
	}
}
add_action( 'added_option', '_ww_cache_purge_on_settings_save' );
add_action( 'updated_option', '_ww_cache_purge_on_settings_save' );
add_action( 'deleted_option', '_ww_cache_purge_on_settings_save' );

/**
 * Update van WordPress, een plugin, een thema of een vertaling: hele cache leeg. Bewaarde pagina's verwijzen anders
 * naar CSS en JS met de oude ?ver=, of tonen uitvoer van de oude versie.
 */
function _ww_cache_purge_on_upgrade(): void {
	_ww_cache_purge_all();
}
add_action( 'upgrader_process_complete', '_ww_cache_purge_on_upgrade', 10, 0 );

// Een plugin aan of uit, of opslaan in de Customizer: de uitvoer van elke pagina kan anders zijn.
add_action( 'activated_plugin', '_ww_cache_purge_all', 10, 0 );
add_action( 'deactivated_plugin', '_ww_cache_purge_all', 10, 0 );
add_action( 'customize_save_after', '_ww_cache_purge_all', 10, 0 );
