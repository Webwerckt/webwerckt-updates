<?php
/**
 * Telling en verwijderen voor het scherm Afbeeldingen (beslissing 0051). Beide lopen in stukjes in de cron van de
 * optimaliseerder (_ww_images_run() in images.php), per 50 bijlagen op ID oplopend, met een cursor in een option:
 * zo blijft elke run onder de tijdslimiet, ook bij duizenden afbeeldingen.
 *
 * De telling leest bestandsgroottes van de schijf en bewaart de uitkomst in ww_images_totals, zodat het scherm snel
 * blijft. Verwijderen gooit alle AVIF- en WebP-versies weg en zet de optimaliseerder uit.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Options (autoload uit): de laatste telling, de tussenstand van de telling die loopt, en de cursor van het verwijderen.
const WW_IMAGES_TOTALS         = 'ww_images_totals';
const WW_IMAGES_COUNT_PROGRESS = 'ww_images_count_progress';
const WW_IMAGES_WIPE           = 'ww_images_wipe';
// Zoveel bijlagen per query.
const WW_IMAGES_COUNT_BATCH = 50;
// Na zoveel seconden begint een nieuwe telling.
const WW_IMAGES_COUNT_AGE = HOUR_IN_SECONDS;
// Zoveel afbeeldingen met de grootste winst houdt de telling bij.
const WW_IMAGES_COUNT_TOP = 5;

/**
 * Lege aantallen per formaat en status.
 *
 * @return array<string,array{ok:int,none:int,skip:int,failed:int,todo:int}>
 */
function _ww_images_empty_formats(): array {
	return array_fill_keys(
		WW_IMAGES_FORMATS,
		array(
			'ok'     => 0,
			'none'   => 0,
			'skip'   => 0,
			'failed' => 0,
			'todo'   => 0,
		)
	);
}

/**
 * Een lege telling.
 *
 * @return array<string,mixed>
 */
function _ww_images_empty_totals(): array {
	return array(
		'formats'     => _ww_images_empty_formats(),
		'mime'        => array(),
		'before'      => 0,
		'after'       => 0,
		'top'         => array(),
		'files'       => 0,
		'files_bytes' => 0,
		'counted_at'  => 0,
	);
}

/**
 * Onder welke stand een status valt: 'ok', 'none', 'skip' (ook de oude 'skip' zonder reden), 'failed', of 'todo'
 * (een getal: nog te doen).
 *
 * @param string|int $status Status van één versie.
 */
function _ww_images_bucket( $status ): string {
	if ( 'ok' === $status || 'none' === $status || 'failed' === $status ) {
		return $status;
	}
	return _ww_images_is_skip( $status ) ? 'skip' : 'todo';
}

/**
 * Telling van één bijlage: per formaat het aantal statussen, de soort bron, de bytes vóór en na (per bestand het
 * kleinste van het origineel en zijn versies), dezelfde bytes van alleen het hoofdbestand, en de versiebestanden die
 * op de schijf staan.
 *
 * Een bestand zonder status telt als nog te doen voor de formaten waarmee de run werkt (_ww_images_run_formats()):
 * een formaat dat de server niet kan of dat een filter weghaalt, blijft niet op "nog te doen" staan.
 *
 * @param int           $id      Bijlage-ID.
 * @param string[]|null $formats Formaten van de run; null om ze op te halen (de telling geeft ze één keer per stap mee).
 * @return array{formats:array<string,array{ok:int,none:int,skip:int,failed:int,todo:int}>, mime:string, before:int, after:int, main_before:int, main_after:int, files:int, files_bytes:int}
 */
function _ww_images_attachment_totals( int $id, ?array $formats = null ): array {
	$totals = array(
		'formats'     => _ww_images_empty_formats(),
		'mime'        => (string) get_post_mime_type( $id ),
		'before'      => 0,
		'after'       => 0,
		'main_before' => 0,
		'main_after'  => 0,
		'files'       => 0,
		'files_bytes' => 0,
	);
	$meta   = wp_get_attachment_metadata( $id );
	$source = get_attached_file( $id );
	if ( ! is_array( $meta ) || ! is_string( $source ) || '' === $source ) {
		return $totals;
	}

	$dir      = dirname( $source );
	$main     = wp_basename( $source );
	$variants = _ww_images_variants( $id );
	$chosen   = $formats ?? _ww_images_run_formats();
	foreach ( _ww_images_files( $meta ) as $file ) {
		$statuses = is_array( $variants[ $file ] ?? null ) ? $variants[ $file ] : array();
		foreach ( array_unique( array_merge( array_keys( $statuses ), _ww_images_targets( $file, $chosen ) ) ) as $format ) {
			if ( isset( $totals['formats'][ $format ] ) ) {
				++$totals['formats'][ $format ][ _ww_images_bucket( $statuses[ $format ] ?? 0 ) ];
			}
		}
		list( $before, $after ) = _ww_images_file_bytes( $dir . '/' . $file, $statuses );
		$totals['before']      += $before;
		$totals['after']       += $after;
		if ( $file === $main ) {
			$totals['main_before'] = $before;
			$totals['main_after']  = $after;
		}
	}

	// Versiebestanden op de schijf, ook van bestanden die na een bijsnijding niet meer in de metadata staan.
	foreach ( array_unique( array_merge( _ww_images_files( $meta ), array_map( 'strval', array_keys( $variants ) ) ) ) as $file ) {
		foreach ( WW_IMAGES_FORMATS as $format ) {
			if ( is_file( $dir . '/' . $file . '.' . $format ) ) {
				++$totals['files'];
				$totals['files_bytes'] += (int) filesize( $dir . '/' . $file . '.' . $format );
			}
		}
	}
	return $totals;
}

/**
 * Telt één bijlage op bij de tussenstand en houdt de top bij op bespaarde bytes van het hoofdbestand.
 *
 * @param array<string,mixed> $totals Tussenstand.
 * @param int                 $id     Bijlage-ID.
 * @param array<string,mixed> $one    Uitkomst van _ww_images_attachment_totals().
 * @return array<string,mixed>
 */
function _ww_images_count_add( array $totals, int $id, array $one ): array {
	foreach ( $one['formats'] as $format => $buckets ) {
		foreach ( $buckets as $bucket => $number ) {
			$totals['formats'][ $format ][ $bucket ] = ( $totals['formats'][ $format ][ $bucket ] ?? 0 ) + $number;
		}
	}
	$mime                             = '' !== $one['mime'] ? $one['mime'] : 'application/octet-stream';
	$totals['mime'][ $mime ]        ??= array(
		'images' => 0,
		'before' => 0,
		'after'  => 0,
	);
	++$totals['mime'][ $mime ]['images'];
	$totals['mime'][ $mime ]['before'] += $one['before'];
	$totals['mime'][ $mime ]['after']  += $one['after'];
	$totals['before']                  += $one['before'];
	$totals['after']                   += $one['after'];
	$totals['files']                   += $one['files'];
	$totals['files_bytes']             += $one['files_bytes'];

	if ( $one['main_before'] > $one['main_after'] ) {
		$totals['top'][] = array(
			'id'     => $id,
			'before' => $one['main_before'],
			'after'  => $one['main_after'],
		);
		usort( $totals['top'], static fn( array $a, array $b ): int => ( $b['before'] - $b['after'] ) <=> ( $a['before'] - $a['after'] ) ?: $a['id'] <=> $b['id'] );
		$totals['top'] = array_slice( $totals['top'], 0, WW_IMAGES_COUNT_TOP );
	}
	return $totals;
}

/**
 * Afbeeldingen in de bibliotheek na een ID, oplopend. Rechtstreeks uit de database: zonder filters van plugins (een
 * vertaalplugin zou anders alleen de afbeeldingen van één taal geven), en met de cursor als voorwaarde.
 *
 * @param int $cursor Laatste ID van de vorige keer.
 * @param int $limit  Hoeveel.
 * @return int[]
 */
function _ww_images_ids_after( int $cursor, int $limit ): array {
	global $wpdb;
	$mimes        = _ww_images_mime_types();
	$placeholders = implode( ', ', array_fill( 0, count( $mimes ), '%s' ) );
	// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- alleen in de cron; de placeholders voor de MIME-types worden hierboven gemaakt.
	$ids = $wpdb->get_col(
		$wpdb->prepare(
			"SELECT ID FROM {$wpdb->posts} WHERE post_type = 'attachment' AND post_status = 'inherit' AND post_mime_type IN ( {$placeholders} ) AND ID > %d ORDER BY ID ASC LIMIT %d",
			array_merge( $mimes, array( $cursor, $limit ) )
		)
	);
	// phpcs:enable
	return array_map( 'intval', $ids );
}

/**
 * Loopt de bibliotheek af vanaf de cursor in $state, tot alles gedaan is of de tijd op is. Vóór elke bijlage
 * controleert hij de tijd. De cursor gaat ook voorbij bijlagen zonder bestanden, zodat een ronde altijd eindigt.
 *
 * @param float                              $deadline microtime(true) waarop de stap stopt.
 * @param array<string,mixed>                $state    Stand met 'cursor'; wordt bijgewerkt.
 * @param callable(int):void                 $each     Werk per bijlage.
 * @param callable(array<string,mixed>):bool $save     Bewaart de stand na elk stuk; false = stoppen zonder verder werk.
 * @return bool True als alles gedaan is.
 */
function _ww_images_walk( float $deadline, array &$state, callable $each, callable $save ): bool {
	while ( microtime( true ) < $deadline ) {
		$ids = _ww_images_ids_after( (int) $state['cursor'], WW_IMAGES_COUNT_BATCH );
		if ( array() === $ids ) {
			return true;
		}
		// Berichten en meta van het hele stuk in twee query's, in plaats van een paar per bijlage.
		_prime_post_caches( $ids, false, false );
		update_meta_cache( 'post', $ids );
		foreach ( $ids as $id ) {
			if ( microtime( true ) >= $deadline ) {
				$save( $state );
				return false;
			}
			$each( $id );
			$state['cursor'] = $id;
		}
		if ( ! $save( $state ) ) {
			return false;
		}
	}
	return false;
}

/**
 * Waarde van een option rechtstreeks uit de database, buiten de cache van de opties om: een ander verzoek (het scherm)
 * kan hem tijdens deze run veranderd hebben. False als hij er niet is.
 *
 * @phpstan-impure Elke aanroep leest opnieuw; de waarde kan intussen veranderd zijn.
 * @return mixed
 */
function _ww_images_option_fresh( string $name ) {
	global $wpdb;
	$value = $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $name ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	return is_string( $value ) ? maybe_unserialize( $value ) : false;
}

/**
 * Kenmerk van de laatste herstart van de telling, vers uit de database. Een telling die met een ander kenmerk begon,
 * hoort bij de tijd van vóór Alles opnieuw maken of Versies verwijderen en mag niets meer bewaren.
 */
function _ww_images_count_token(): string {
	$raw = _ww_images_option_fresh( WW_IMAGES_TOTALS );
	return is_array( $raw ) && is_string( $raw['restart'] ?? null ) ? $raw['restart'] : '';
}

/**
 * De laatste telling, of null als er nog geen is (ook vlak na het verwijderen, als alleen het kenmerk van de herstart
 * er staat). Na Alles opnieuw maken blijven de oude getallen staan met counted_at 0.
 *
 * @return array<string,mixed>|null
 */
function _ww_images_totals(): ?array {
	$totals = get_option( WW_IMAGES_TOTALS );
	return is_array( $totals ) && isset( $totals['counted_at'] ) ? $totals : null;
}

/**
 * Of een nieuwe telling moet beginnen of doorgaan: er is er nog geen, of de laatste is ouder dan een uur.
 */
function _ww_images_count_due(): bool {
	$totals = _ww_images_totals();
	return null === $totals || (int) ( $totals['counted_at'] ?? 0 ) < time() - WW_IMAGES_COUNT_AGE;
}

/**
 * Of er een telling te doen is die niet op het uur hoeft te wachten: er is er nog nooit een geweest, er is om een
 * nieuwe gevraagd (na Alles opnieuw maken of het verwijderen), of er loopt er een. Dan blijft de cron gepland en draait
 * de run tot de telling klaar is, ook zonder Imagick of met de optimaliseerder uit: tellen leest alleen de schijf.
 */
function _ww_images_count_pending(): bool {
	$raw = get_option( WW_IMAGES_TOTALS );
	return false !== get_option( WW_IMAGES_COUNT_PROGRESS, false ) || ! is_array( $raw ) || 0 === (int) ( $raw['counted_at'] ?? 0 );
}

/**
 * Eén stap van de telling. Klaar: alles in ww_images_totals met counted_at, en de tussenstand weg.
 *
 * Werd de telling intussen herstart of begon het verwijderen (in een ander verzoek, zonder het slot), dan bewaart deze
 * stap niets: zo komt er nooit een tussenstand of telling van vóór de herstart terug.
 *
 * @param float $deadline microtime(true) waarop de stap stopt.
 * @return bool True als de ronde klaar is.
 */
function _ww_images_count_step( float $deadline ): bool {
	if ( false !== _ww_images_option_fresh( WW_IMAGES_WIPE ) ) {
		return false;
	}
	$token = _ww_images_count_token();
	$state = get_option( WW_IMAGES_COUNT_PROGRESS );
	if ( ! is_array( $state ) || ! is_array( $state['totals'] ?? null ) || array() === $state['totals'] || $token !== ( $state['token'] ?? '' ) ) {
		$state = array(
			'cursor' => 0,
			'totals' => _ww_images_empty_totals(),
		);
	}
	$state['cursor'] = (int) ( $state['cursor'] ?? 0 );
	$state['token']  = $token;
	$current         = static fn(): bool => false === _ww_images_option_fresh( WW_IMAGES_WIPE ) && _ww_images_count_token() === $token;
	$formats         = _ww_images_run_formats();

	$done = _ww_images_walk(
		$deadline,
		$state,
		static function ( int $id ) use ( &$state, $formats ): void {
			$state['totals'] = _ww_images_count_add( $state['totals'], $id, _ww_images_attachment_totals( $id, $formats ) );
		},
		static function ( array $state ) use ( $current ): bool {
			if ( ! $current() ) {
				return false;
			}
			update_option( WW_IMAGES_COUNT_PROGRESS, $state, false );
			return true;
		}
	);
	if ( ! $done || ! $current() ) {
		return false;
	}

	$totals               = $state['totals'];
	$totals['counted_at'] = time();
	$totals['restart']    = $token;
	update_option( WW_IMAGES_TOTALS, $totals, false );
	delete_option( WW_IMAGES_COUNT_PROGRESS );
	return true;
}

/**
 * Laat de volgende run meteen een nieuwe telling beginnen (na Alles opnieuw maken en na het verwijderen). De vorige
 * uitkomst blijft staan tot de nieuwe klaar is, maar geldt als verouderd (counted_at 0). Een nieuw kenmerk zorgt dat
 * een telling die nu nog loopt, niets meer bewaart.
 */
function _ww_images_count_restart(): void {
	delete_option( WW_IMAGES_COUNT_PROGRESS );
	$totals = get_option( WW_IMAGES_TOTALS );
	$totals = is_array( $totals ) ? $totals : array();
	if ( isset( $totals['counted_at'] ) ) {
		$totals['counted_at'] = 0;
	}
	$totals['restart'] = wp_generate_uuid4();
	update_option( WW_IMAGES_TOTALS, $totals, false );
}

/**
 * Of de versies verwijderd worden. Zolang dat zo is, serveert <picture> niets.
 */
function _ww_images_wiping(): bool {
	return false !== get_option( WW_IMAGES_WIPE, false );
}

/**
 * Begint met het verwijderen van alle versies: de optimaliseerder gaat uit, <picture> serveert meteen niets meer, en de
 * cron verwijdert de bestanden in stukjes. De telling klopt dan niet meer: die gaat weg, en een lopende telling stopt.
 */
function _ww_images_wipe_start(): void {
	$settings            = _ww_images_settings();
	$settings['enabled'] = false;
	// Autoload aan: <picture> leest de instellingen bij elke bezoeker.
	update_option( WW_IMAGES_SETTINGS, $settings, true );
	update_option(
		WW_IMAGES_WIPE,
		array(
			'cursor' => 0,
			'done'   => 0,
		),
		false
	);
	// De getallen kloppen niet meer: weg (het scherm toont "Wordt geteld"), en een lopende telling bewaart niets meer.
	delete_option( WW_IMAGES_TOTALS );
	_ww_images_count_restart();
	// Gecachte pagina's wijzen nog naar versies die nu verdwijnen, en een browser valt bij een ontbrekende <source> niet
	// terug op de <img>: de paginacache meteen legen, en aan het eind nog eens.
	wp_clear_scheduled_hook( 'ww_output_changed' );
	wp_schedule_single_event( time(), 'ww_output_changed' );
}

/**
 * Eén stap van het verwijderen: per bijlage alle AVIF- en WebP-versies en de metasleutels van de optimaliseerder weg.
 * Klaar: ww_images_wipe weg, een nieuwe telling, en de paginacache legen.
 *
 * @param float $deadline microtime(true) waarop de stap stopt.
 * @return bool True als alles verwijderd is (of er niets te verwijderen was).
 */
function _ww_images_wipe_step( float $deadline ): bool {
	$state = get_option( WW_IMAGES_WIPE );
	if ( false === $state ) {
		return true;
	}
	$state = array(
		'cursor' => (int) ( is_array( $state ) ? $state['cursor'] ?? 0 : 0 ),
		'done'   => (int) ( is_array( $state ) ? $state['done'] ?? 0 : 0 ),
	);

	$done = _ww_images_walk(
		$deadline,
		$state,
		static function ( int $id ) use ( &$state ): void {
			_ww_images_wipe_one( $id );
			++$state['done'];
		},
		static function ( array $state ): bool {
			update_option( WW_IMAGES_WIPE, $state, false );
			return true;
		}
	);
	if ( ! $done ) {
		return false;
	}

	delete_option( WW_IMAGES_WIPE );
	_ww_images_count_restart();
	// De paginacache kan nog <picture> met de verwijderde versies bevatten. Een oudere melding vervalt: deze is nu.
	wp_clear_scheduled_hook( 'ww_output_changed' );
	wp_schedule_single_event( time(), 'ww_output_changed' );
	return true;
}

/**
 * Verwijdert de versies en de meta van de optimaliseerder van één bijlage, ook van bestanden die na een bijsnijding
 * niet meer in de metadata staan.
 */
function _ww_images_wipe_one( int $id ): void {
	$source = get_attached_file( $id );
	if ( is_string( $source ) && '' !== $source ) {
		$meta  = wp_get_attachment_metadata( $id );
		$files = array_merge( is_array( $meta ) ? _ww_images_files( $meta ) : array(), array_map( 'strval', array_keys( _ww_images_variants( $id ) ) ) );
		foreach ( array_unique( $files ) as $file ) {
			_ww_images_delete_variants( dirname( $source ) . '/' . $file );
		}
	}
	delete_post_meta( $id, WW_IMAGES_META_VARIANTS );
	delete_post_meta( $id, WW_IMAGES_META_STATE );
	delete_post_meta( $id, WW_IMAGES_META_SKIP_SIZE );
	delete_post_meta( $id, WW_IMAGES_META_GENERATION );
}
