<?php
/**
 * Tabel van Overgeslagen en mislukt op het scherm Afbeeldingen (inc/images-admin.php). Wordt pas geladen als dat
 * scherm wordt getoond, na WP_List_Table.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * De afbeeldingen met een overgeslagen of mislukt bestand, met de reden in gewone taal.
 */
class WW_Images_Skip_List_Table extends WP_List_Table {

	/**
	 * ID's per soort; één keer opgehaald per scherm.
	 *
	 * @var array{skip:int[],failed:int[]}|null
	 */
	private ?array $buckets = null;

	public function __construct() {
		parent::__construct(
			array(
				'singular' => 'afbeelding',
				'plural'   => 'afbeeldingen',
				'ajax'     => false,
			)
		);
	}

	/**
	 * @return array{skip:int[],failed:int[]}
	 */
	private function buckets(): array {
		if ( null === $this->buckets ) {
			$this->buckets = _ww_images_problem_buckets();
		}
		return $this->buckets;
	}

	/**
	 * De weergave uit het verzoek: all, skip of failed.
	 */
	public function get_view(): string {
		$view = isset( $_GET['view'] ) ? sanitize_key( _ww_data_to_string( wp_unslash( $_GET['view'] ) ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen filteren.
		return in_array( $view, array( 'skip', 'failed' ), true ) ? $view : 'all';
	}

	/**
	 * @return array<string,string>
	 */
	public function get_columns() {
		return array(
			'image'  => __( 'Afbeelding', 'webwerckt-base' ),
			'reason' => __( 'Waarom', 'webwerckt-base' ),
		);
	}

	/**
	 * @return string
	 */
	protected function get_default_primary_column_name() {
		return 'image';
	}

	/**
	 * De weergaven Alles, Overgeslagen en Mislukt met hun aantallen.
	 *
	 * @return array<string,string>
	 */
	protected function get_views() {
		$current = $this->get_view();
		$counts  = array(
			'all'    => _ww_images_problem_ids( 'all', 0, 0, $this->buckets() )['total'],
			'skip'   => count( $this->buckets()['skip'] ),
			'failed' => count( $this->buckets()['failed'] ),
		);
		$labels  = array(
			'all'    => __( 'Alles', 'webwerckt-base' ),
			'skip'   => __( 'Overgeslagen', 'webwerckt-base' ),
			'failed' => __( 'Mislukt', 'webwerckt-base' ),
		);
		$views   = array();
		foreach ( $labels as $key => $label ) {
			$url           = _ww_images_admin_url(
				array(
					'tab'  => 'problems',
					'view' => $key,
				)
			);
			$views[ $key ] = '<a href="' . esc_url( $url ) . '"' . ( $current === $key ? ' class="current" aria-current="page"' : '' ) . '>' . esc_html( $label ) . ' <span class="count">(' . esc_html( number_format_i18n( $counts[ $key ] ) ) . ')</span></a>';
		}
		return $views;
	}

	/**
	 * Haalt één pagina van de gekozen weergave.
	 */
	public function prepare_items(): void {
		$page                  = $this->get_pagenum();
		$result                = _ww_images_problem_ids( $this->get_view(), WW_IMAGES_PER_PAGE, ( $page - 1 ) * WW_IMAGES_PER_PAGE, $this->buckets() );
		$this->_column_headers = array( $this->get_columns(), array(), array(), 'image' );
		$this->items           = $result['ids'];
		$this->set_pagination_args(
			array(
				'total_items' => $result['total'],
				'per_page'    => WW_IMAGES_PER_PAGE,
			)
		);
	}

	/**
	 * Tekst als er niets overgeslagen of mislukt is.
	 */
	public function no_items(): void {
		esc_html_e( 'Niets overgeslagen of mislukt. Bij alle afbeeldingen is gedaan wat kon.', 'webwerckt-base' );
	}

	/**
	 * Miniatuur, titel en bestandsnaam, met Bewerken en (als het zin heeft) Opnieuw proberen.
	 *
	 * @param int $item Bijlage-ID.
	 */
	protected function column_image( $item ): string {
		$id      = (int) $item;
		$actions = _ww_images_list_row_actions( $id, false );
		// Geanimeerd of te groot blijft hetzelfde als je het opnieuw probeert.
		$retryable = array_diff( array_column( _ww_images_problem_reasons( $id ), 'status' ), array( 'skip:big', 'skip:anim' ) );
		if ( array() !== $retryable ) {
			$url                = wp_nonce_url(
				add_query_arg(
					array(
						'action'        => 'ww_images_retry',
						'attachment_id' => $id,
					),
					admin_url( 'admin-post.php' )
				),
				'ww_images_retry_' . $id
			);
			$actions['retry'] = '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Opnieuw proberen', 'webwerckt-base' ) . '</a>';
		}
		return _ww_images_list_image_cell( $id, $this->row_actions( $actions ) );
	}

	/**
	 * Per reden een label met een zin eronder.
	 *
	 * @param int $item Bijlage-ID.
	 */
	protected function column_reason( $item ): string {
		$html = '';
		foreach ( _ww_images_problem_reasons( (int) $item ) as $reason ) {
			$html .= '<p class="ww-images-reason ww-images-reason--' . esc_attr( $reason['kind'] ) . '"><strong>' . esc_html( $reason['label'] ) . '</strong><br><small>' . esc_html( $reason['text'] ) . '</small></p>';
		}
		return $html;
	}
}
