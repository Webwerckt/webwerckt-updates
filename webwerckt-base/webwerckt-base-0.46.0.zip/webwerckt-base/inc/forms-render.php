<?php
/**
 * Formulieren: weergave (beslissing 0032). ww_form() en ww_get_form() tonen een formulier uit inc/forms.php, de
 * shortcode [ww_form] doet hetzelfde.
 *
 * De markup volgt de spec: geen CSS (behalve de honeypot), geen nonce (een nonce veroudert in de paginacache) en geen
 * novalidate (zonder JavaScript controleert de browser zelf, form.js zet novalidate bij het laden). Velden heten
 * ww_fields[sleutel], zodat een veldnaam nooit een publieke queryvariabele van WordPress kan zijn.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registreert form.js (footer, geen jQuery). Geladen wordt het pas door ww_get_form(), zodra er een formulier is.
 */
function _ww_form_register_script(): void {
	if ( ! wp_script_is( 'ww-form', 'registered' ) ) {
		wp_register_script( 'ww-form', _ww_asset_url( 'js/form.js' ), array(), WW_BASE_VERSION, array( 'in_footer' => true ) );
	}
}
add_action( 'wp_enqueue_scripts', '_ww_form_register_script' );

/**
 * De meldingen rond bestanden, één bron voor de server (inc/forms-files.php) en form.js. %s en %d staan op de plek van
 * naam, grootte, aantal en lijst; bij twee waarden genummerd (%1$s, %2$d), zodat een vertaling ze kan omdraaien.
 *
 * @return array<string,string>
 */
function _ww_form_file_messages(): array {
	return array(
		/* translators: 1: bestandsnaam, 2: maximale grootte in MB */
		'too_big'       => __( '%1$s is te groot (max. %2$d MB).', 'webwerckt-base' ),
		/* translators: %d: maximale grootte in MB */
		'file_too_big'  => __( 'Dit bestand is te groot (max. %d MB).', 'webwerckt-base' ),
		/* translators: %d: maximaal aantal bestanden */
		'too_many'      => __( 'Kies hoogstens %d bestanden.', 'webwerckt-base' ),
		/* translators: 1: bestandsnaam, 2: lijst met toegestane extensies */
		'bad_type'      => __( '%1$s is geen toegestaan bestand. Toegestaan: %2$s.', 'webwerckt-base' ),
		'upload_failed' => __( 'Uploaden is niet gelukt. Probeer het opnieuw.', 'webwerckt-base' ),
		/* translators: %d: maximale grootte van alle bestanden samen in MB */
		'post_too_big'  => __( 'Je bestanden zijn samen te groot. Het maximum is %d MB.', 'webwerckt-base' ),
		'reselect'      => __( 'Kies het bestand opnieuw.', 'webwerckt-base' ),
	);
}

/**
 * De toegestane extensies van een bestandsveld: de extensies van de gekozen groepen, in groepsvolgorde.
 *
 * @param array<string,mixed> $field Opgeschoond bestandsveld.
 * @return list<string>
 */
function _ww_form_file_extensions( array $field ): array {
	$groups = _ww_form_file_groups();
	$exts   = array();
	foreach ( _ww_form_array( $field['accept'] ?? array() ) as $group ) {
		foreach ( $groups[ $group ]['ext'] ?? array() as $ext ) {
			$exts[ $ext ] = $ext;
		}
	}
	return array_values( $exts );
}

/**
 * De grootste toegestane grootte van een bestandsveld in MB: de ingestelde grootte, begrensd op wat de server nu toelaat
 * (die limiet kan sinds het opslaan gedaald zijn).
 *
 * @param array<string,mixed> $field Opgeschoond bestandsveld.
 */
function _ww_form_file_limit_mb( array $field ): int {
	return max( 1, min( (int) ( $field['max_size_mb'] ?? 5 ), _ww_form_file_max_mb() ) );
}

/**
 * De regel onder de hulptekst van een bestandsveld: extensies, grootte en eventueel het aantal bestanden.
 *
 * @param array<string,mixed> $field Opgeschoond bestandsveld.
 */
function _ww_form_file_help( array $field ): string {
	$parts = array(
		implode( ', ', _ww_form_file_extensions( $field ) ),
		/* translators: %d: maximale grootte in MB */
		sprintf( __( 'max. %d MB', 'webwerckt-base' ), _ww_form_file_limit_mb( $field ) ),
	);
	$files = (int) ( $field['max_files'] ?? 1 );
	if ( $files > 1 ) {
		/* translators: %d: maximaal aantal bestanden */
		$parts[] = sprintf( __( 'hoogstens %d bestanden', 'webwerckt-base' ), $files );
	}
	return implode( ' · ', $parts );
}

/**
 * Geeft de teksten van form.js mee als window.wwForm (vertaalbaar), één keer per pagina.
 */
function _ww_form_script_texts(): void {
	if ( wp_scripts()->get_data( 'ww-form', 'before' ) ) {
		return;
	}
	$files = _ww_form_file_messages();
	$texts = array(
		'summary'    => __( 'Controleer de gemarkeerde velden.', 'webwerckt-base' ),
		'network'    => __( 'Versturen is niet gelukt. Controleer je verbinding en probeer het opnieuw.', 'webwerckt-base' ),
		'required'   => __( 'Dit veld is verplicht.', 'webwerckt-base' ),
		'tooBig'     => $files['too_big'],
		'tooMany'    => $files['too_many'],
		'badType'    => $files['bad_type'],
		'postTooBig' => $files['post_too_big'],
		/* translators: 1: nummer van de stap, 2: aantal stappen */
		'stepStatus' => __( 'Stap %1$d van %2$d', 'webwerckt-base' ),
		'email'      => __( 'Vul een geldig e-mailadres in.', 'webwerckt-base' ),
		/* translators: %d: het grootste aantal tekens. */
		'tooLong'    => __( 'Maximaal %d tekens.', 'webwerckt-base' ),
	);
	wp_add_inline_script( 'ww-form', 'window.wwForm = ' . wp_json_encode( array( 'texts' => $texts ) ) . ';', 'before' );
}

/**
 * Geeft het HTML-id voor een formulier: het gevraagde id, bij een tweede keer op dezelfde pagina met -2, -3.
 *
 * @param string|null $base Gevraagd id; null zet de teller terug (voor tests).
 */
function _ww_form_unique_id( ?string $base ): string {
	static $seen = array();
	if ( null === $base ) {
		$seen = array();
		return '';
	}
	$seen[ $base ] = ( $seen[ $base ] ?? 0 ) + 1;
	return $seen[ $base ] > 1 ? $base . '-' . $seen[ $base ] : $base;
}

/**
 * De toestand van een formulier voor deze aanvraag: waarden en fouten uit de verwerking van een POST (via het filter
 * _ww_form_state, dat inc/forms-submit.php vult) en of ?ww_form_sent het id van dit formulier is.
 *
 * @return array{values: array<string,mixed>, errors: array<string,string>, general: string, sent: bool, reselect: bool}
 */
function _ww_form_state( int $form_id ): array {
	$default = array(
		'values'   => array(),
		'errors'   => array(),
		'general'  => '',
		'sent'     => false,
		'reselect' => false,
	);
	$state   = apply_filters( '_ww_form_state', $default, $form_id );
	$state   = is_array( $state ) ? $state + $default : $default;

	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Een openbare melding na doorsturen, geen actie.
	$sent = $_GET['ww_form_sent'] ?? '';
	if ( is_string( $sent ) && ctype_digit( $sent ) && (int) $sent === $form_id ) {
		$state['sent'] = true;
	}
	$state['sent']     = (bool) $state['sent'];
	$state['reselect'] = (bool) $state['reselect'];
	$state['values']   = _ww_form_array( $state['values'] );
	$state['errors']   = _ww_form_array( $state['errors'] );
	$state['general']  = _ww_form_string( $state['general'] );
	return $state;
}

/**
 * Toont een formulier (ww_form_sanitize() bepaalt wat er in staat). Zie ww_get_form().
 *
 * @param int|string               $form Post-ID of slug van een ww_form.
 * @param array<string,string|int> $args class (extra klasse op het formulier), id (HTML-id) en step_heading (kopniveau van de stappen, 2 tot en met 6).
 */
function ww_form( int|string $form, array $args = array() ): void {
	echo ww_get_form( $form, $args ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Al ge-escapet in _ww_form_render().
}

/**
 * Geeft een formulier als HTML. Niet gevonden, niet gepubliceerd of zonder velden: niets, behalve voor wie
 * formulieren beheert (edit_others_pages), die een korte melding ziet. form.js wordt alleen geladen als er een
 * formulier staat.
 *
 * De pagina meldt ww_shows_post_type voor ww_form, ook als het formulier (nog) niet beschikbaar is: zo leegt het
 * opslaan of publiceren van een formulier de gecachete pagina's die het tonen.
 *
 * @param int|string               $form Post-ID of slug van een ww_form.
 * @param array<string,string|int> $args class (extra klasse op het formulier), id (HTML-id, standaard ww-form-{id}) en
 *                                       step_heading (kopniveau van de stappen, 2 tot en met 6, anders 2).
 */
function ww_get_form( int|string $form, array $args = array() ): string {
	do_action( 'ww_shows_post_type', WW_FORM_POST_TYPE );
	$form_id = _ww_form_resolve( $form );
	if ( ! $form_id ) {
		if ( current_user_can( 'edit_others_pages' ) ) {
			return '<p class="ww-form__notice">' . esc_html__( 'Formulier niet gevonden of nog niet gepubliceerd.', 'webwerckt-base' ) . '</p>';
		}
		return '';
	}
	$config = _ww_form_config( $form_id );
	if ( ! $config ) {
		return '';
	}

	$args['step_heading'] = _ww_form_heading_level( $args['step_heading'] ?? 2 );

	$state = _ww_form_state( $form_id );
	if ( ! $state['sent'] ) {
		$args['id'] = _ww_form_unique_id( '' !== _ww_form_string( $args['id'] ?? '' ) ? sanitize_html_class( _ww_form_string( $args['id'] ) ) : 'ww-form-' . $form_id );
		_ww_form_register_script();
		wp_enqueue_script( 'ww-form' );
		_ww_form_script_texts();
	}
	return _ww_form_render( $form_id, $config, $args, $state );
}

/**
 * Het kopniveau van de stappen: 2 tot en met 6, elke andere waarde wordt 2.
 *
 * @param mixed $value Gevraagd niveau (getal of tekst met cijfers).
 */
function _ww_form_heading_level( mixed $value ): int {
	if ( is_int( $value ) || ( is_string( $value ) && ctype_digit( $value ) ) ) {
		$level = (int) $value;
		if ( $level >= 2 && $level <= 6 ) {
			return $level;
		}
	}
	return 2;
}

/**
 * De shortcode [ww_form id="12"] of [ww_form slug="contact"], met heading="3" voor het kopniveau van de stappen.
 *
 * @param array<string,string>|string $atts Attributen.
 */
function _ww_form_shortcode( $atts ): string {
	$atts = shortcode_atts(
		array(
			'id'      => '',
			'slug'    => '',
			'class'   => '',
			'heading' => '',
		),
		$atts,
		'ww_form'
	);
	$form = '' !== $atts['id'] ? $atts['id'] : $atts['slug'];
	if ( '' === $form ) {
		return '';
	}
	$args = '' !== $atts['class'] ? array( 'class' => $atts['class'] ) : array();
	if ( '' !== $atts['heading'] ) {
		$args['step_heading'] = $atts['heading'];
	}
	return ww_get_form( $form, $args );
}
add_shortcode( 'ww_form', '_ww_form_shortcode' );

/**
 * Het hele formulier, of na versturen het bedankbericht.
 *
 * @param int                  $form_id Post-ID van het formulier.
 * @param array<string,mixed>  $config  Opgeschoonde configuratie.
 * @param array<string,string|int> $args    class, id (al uniek gemaakt door ww_get_form()) en step_heading (al gecontroleerd).
 * @param array<string,mixed>  $state   Toestand: values, errors, general, sent, reselect.
 */
function _ww_form_render( int $form_id, array $config, array $args, array $state ): string {
	if ( ! empty( $state['sent'] ) ) {
		$html = '<div class="ww-form__success" role="status" tabindex="-1">' . wp_kses_post( _ww_form_after_message( $config ) ) . '</div>';
		return (string) apply_filters( 'ww_form_html', $html, $form_id );
	}

	$base   = _ww_form_string( $args['id'] ?? '' );
	$base   = '' !== $base ? $base : 'ww-form-' . $form_id;
	$groups = _ww_form_step_groups( $config );
	$class  = trim( 'ww-form ' . ( $groups ? 'ww-form--steps ' : '' ) . _ww_form_string( $args['class'] ?? '' ) );
	$errors = _ww_form_array( $state['errors'] ?? array() );
	$values = _ww_form_array( $state['values'] ?? array() );

	// Zonder JavaScript kan een bestandsveld na een fout niet opnieuw gevuld worden: zeg dat in het veld zelf.
	if ( ! empty( $state['reselect'] ) ) {
		$reselect = _ww_form_file_messages()['reselect'];
		foreach ( $config['fields'] as $field ) {
			if ( 'file' === $field['type'] && '' === _ww_form_string( $errors[ $field['key'] ] ?? '' ) ) {
				$errors[ $field['key'] ] = $reselect;
			}
		}
	}

	$field_html = array();
	foreach ( $config['fields'] as $field ) {
		$key                = $field['key'];
		$error              = _ww_form_string( $errors[ $key ] ?? '' );
		$html               = _ww_form_field_html( $field, $base . '-' . $key, $values[ $key ] ?? '', $error );
		$field_html[ $key ] = (string) apply_filters( 'ww_form_field_html', $html, $field, $form_id, $state ) . "\n";
	}

	$attributes = '';
	if ( _ww_form_has_file_field( $config ) ) {
		$attributes .= ' enctype="multipart/form-data" data-ww-post-max="' . (int) wp_convert_hr_to_bytes( (string) ini_get( 'post_max_size' ) ) . '"';
	}
	$recaptcha = _ww_form_recaptcha_active( $config );
	if ( $recaptcha ) {
		$attributes .= ' data-ww-recaptcha="' . esc_attr( _ww_form_recaptcha_site_key() ) . '"';
	}

	$html  = '<form class="' . esc_attr( $class ) . '" id="' . esc_attr( $base ) . '" method="post"' . $attributes . ' data-ww-form>' . "\n";
	$html .= _ww_form_error_summary( $config['fields'], $base, $errors, _ww_form_string( $state['general'] ?? '' ) ) . "\n";
	if ( $groups ) {
		$html .= _ww_form_steps_html( $groups, $base, $field_html, _ww_form_heading_level( $args['step_heading'] ?? 2 ) );
	} else {
		$html .= implode( '', $field_html );
	}
	$html .= '<div class="ww-form__hp" style="position:absolute;left:-10000px;width:1px;height:1px;overflow:hidden" aria-hidden="true">'
		. '<label for="' . esc_attr( $base ) . '-hp">' . esc_html__( 'Laat dit veld leeg', 'webwerckt-base' ) . '</label>'
		. '<input id="' . esc_attr( $base ) . '-hp" name="ww_hp" type="text" tabindex="-1" autocomplete="off">'
		. "</div>\n";
	$html .= '<input type="hidden" name="ww_form" value="' . esc_attr( (string) $form_id ) . '">' . "\n";
	if ( $recaptcha ) {
		$html .= '<input type="hidden" name="ww_recaptcha" value="">' . "\n";
	}
	$html .= '<button class="ww-form__submit" type="submit">' . esc_html( _ww_form_string( $config['submit_label'] ) ) . "</button>\n";
	if ( $recaptcha ) {
		$notice = sprintf(
			/* translators: 1: link naar het privacybeleid van Google, 2: link naar de voorwaarden van Google */
			__( 'Deze site wordt beschermd door reCAPTCHA; het %1$s en de %2$s van Google zijn van toepassing.', 'webwerckt-base' ),
			'<a href="https://policies.google.com/privacy">' . esc_html__( 'privacybeleid', 'webwerckt-base' ) . '</a>',
			'<a href="https://policies.google.com/terms">' . esc_html__( 'voorwaarden', 'webwerckt-base' ) . '</a>'
		);
		/**
		 * Filtert de tekst onder de verzendknop als reCAPTCHA actief is. Google staat het verbergen van het badge alleen
		 * toe met deze tekst in de buurt van het formulier.
		 *
		 * @param string $notice  HTML van de tekst.
		 * @param int    $form_id Post-ID van het formulier.
		 */
		$notice = (string) apply_filters( 'ww_form_recaptcha_notice', $notice, $form_id );
		$html  .= '<p class="ww-form__recaptcha">' . wp_kses_post( $notice ) . "</p>\n";
	}
	$html .= "</form>\n";

	return (string) apply_filters( 'ww_form_html', $html, $form_id );
}

/**
 * De voortgangslijst, de statusregel en de stappen van een formulier met stappen. Zonder JavaScript blijft alles
 * onder elkaar staan; form.js haalt hidden weg van de lijst, de statusregel en de stapknoppen.
 *
 * @param list<array{step: array{key: string, title: string, from: string}, fields: list<array<string,mixed>>}> $groups     Stappen met hun velden.
 * @param string                                                                                                  $base       HTML-id van het formulier.
 * @param array<string,string>                                                                                    $field_html De HTML van elk veld, per veldsleutel.
 * @param int                                                                                                     $level      Kopniveau van de staptitels.
 */
function _ww_form_steps_html( array $groups, string $base, array $field_html, int $level ): string {
	$total    = count( $groups );
	$progress = '';
	$steps    = '';
	foreach ( $groups as $n => $group ) {
		$key     = $group['step']['key'];
		$title   = $group['step']['title'];
		if ( '' === $title ) {
			/* translators: %d: nummer van de stap */
			$title = sprintf( __( 'Stap %d', 'webwerckt-base' ), $n + 1 );
		}
		$step_id = $base . '-step-' . $key;

		$progress .= '<li class="ww-form__progress-item"><button type="button" class="ww-form__progress-button" data-ww-goto="' . esc_attr( $key ) . '"'
			. ( 0 === $n ? ' aria-current="step"' : ' disabled' ) . '>' . esc_html( $title ) . '</button></li>';

		$steps .= '<div class="ww-form__step" id="' . esc_attr( $step_id ) . '" role="group" aria-labelledby="' . esc_attr( $step_id ) . '-title" data-ww-step="' . esc_attr( $key ) . "\">\n"
			. '<h' . $level . ' class="ww-form__step-title" id="' . esc_attr( $step_id ) . '-title" tabindex="-1">' . esc_html( $title ) . '</h' . $level . ">\n";
		foreach ( $group['fields'] as $field ) {
			$steps .= $field_html[ $field['key'] ] ?? '';
		}
		$steps .= '<div class="ww-form__step-nav" hidden>'
			. '<button type="button" class="ww-form__prev" data-ww-prev>' . esc_html__( 'Vorige', 'webwerckt-base' ) . '</button>'
			. '<button type="button" class="ww-form__next" data-ww-next>' . esc_html__( 'Volgende', 'webwerckt-base' ) . '</button>'
			. "</div>\n</div>\n";
	}
	/* translators: 1: nummer van de stap, 2: aantal stappen */
	$status = sprintf( __( 'Stap %1$d van %2$d', 'webwerckt-base' ), 1, $total );
	return '<ol class="ww-form__progress" hidden>' . $progress . "</ol>\n"
		. '<p class="ww-form__step-status" aria-live="polite" hidden>' . esc_html( $status ) . "</p>\n"
		. $steps;
}

/**
 * Het foutoverzicht bovenaan. Het element staat er altijd (verborgen zonder fouten), zodat form.js het kan vullen.
 * Een fout van een veld dat niet (meer) in de configuratie staat, krijgt alleen de melding.
 *
 * @param list<array<string,mixed>> $fields  Velden van de configuratie.
 * @param string                    $base    HTML-id van het formulier.
 * @param array<string,mixed>       $errors  Fouten per veldsleutel.
 * @param string                    $general Algemene fout.
 */
function _ww_form_error_summary( array $fields, string $base, array $errors, string $general ): string {
	$items = '';
	if ( '' !== $general ) {
		$items .= '<li>' . esc_html( $general ) . '</li>';
	}
	$known = array();
	foreach ( $fields as $field ) {
		$known[ $field['key'] ] = $field;
	}
	foreach ( $known as $key => $field ) {
		$message = _ww_form_string( $errors[ $key ] ?? '' );
		if ( '' !== $message ) {
			$items .= '<li><a href="#' . esc_attr( $base . '-' . $key ) . '">' . esc_html( wp_strip_all_tags( $field['label'] ) ) . '</a>: ' . esc_html( $message ) . '</li>';
		}
	}
	foreach ( $errors as $key => $message ) {
		$message = _ww_form_string( $message );
		if ( ! isset( $known[ $key ] ) && '' !== $message ) {
			$items .= '<li>' . esc_html( $message ) . '</li>';
		}
	}

	if ( '' === $items ) {
		return '<div class="ww-form__errors" role="alert" tabindex="-1" hidden></div>';
	}
	return '<div class="ww-form__errors" role="alert" tabindex="-1"><ul>' . $items . '</ul></div>';
}

/**
 * Het placeholder-attribuut van een veld, of niets.
 *
 * @param array<string,mixed> $field Opgeschoond veld.
 */
function _ww_form_placeholder( array $field ): string {
	$placeholder = (string) ( $field['placeholder'] ?? '' );
	return '' !== $placeholder ? ' placeholder="' . esc_attr( $placeholder ) . '"' : '';
}

/**
 * De markup van één veld, met label, hulptekst en foutplek.
 *
 * @param array<string,mixed> $field   Opgeschoond veld.
 * @param string              $html_id HTML-id van het invoerelement (of de fieldset bij een keuzeveld).
 * @param mixed               $value   Ingevulde waarde bij het opnieuw tonen (een tekst, of een lijst bij meerdere keuzes).
 * @param string              $error   Foutmelding van dit veld, of leeg.
 */
function _ww_form_field_html( array $field, string $html_id, $value, string $error ): string {
	$type     = (string) $field['type'];
	$key      = (string) $field['key'];
	$name     = 'ww_fields[' . $key . ']';
	$required = ! empty( $field['required'] );
	$help     = (string) ( $field['help'] ?? '' );
	if ( 'file' === $type ) {
		$help = trim( $help . ' ' . _ww_form_file_help( $field ) );
	}

	$classes = 'ww-form__field ww-form__field--' . $type . ( $required ? ' ww-form__field--required' : '' ) . ( '' !== $error ? ' ww-form__field--error' : '' );
	$mark    = $required ? ' <span class="ww-form__required" aria-hidden="true">*</span>' : '';

	$described = array();
	if ( '' !== $help ) {
		$described[] = $html_id . '-help';
	}
	if ( '' !== $error ) {
		$described[] = $html_id . '-error';
	}
	$describedby = $described ? ' aria-describedby="' . esc_attr( implode( ' ', $described ) ) . '"' : '';
	$common      = $describedby . ( '' !== $error ? ' aria-invalid="true"' : '' );
	$req    = $required ? ' required' : '';
	$id_at  = ' id="' . esc_attr( $html_id ) . '"';
	$label  = static fn( string $text ): string => '<label class="ww-form__label" for="' . esc_attr( $html_id ) . '">' . $text . $mark . '</label>';

	$text   = _ww_form_string( $value );
	$tail   = ( '' !== $help ? '<p class="ww-form__help" id="' . esc_attr( $html_id ) . '-help">' . esc_html( $help ) . '</p>' : '' )
		. '<p class="ww-form__error" id="' . esc_attr( $html_id ) . '-error"' . ( '' === $error ? ' hidden>' : '>' . esc_html( $error ) ) . '</p>';
	$inner  = '';
	$prefix = '';

	switch ( $type ) {
		case 'line':
			$input_type = (string) ( $field['input'] ?? 'text' );
			$max        = 'tel' === $input_type ? 30 : 255;
			$prefix     = $label( esc_html( (string) $field['label'] ) );
			$inner      = '<input class="ww-form__input"' . $id_at . ' name="' . esc_attr( $name ) . '" type="' . esc_attr( $input_type ) . '"'
				. ( '' !== $text ? ' value="' . esc_attr( $text ) . '"' : '' )
				. _ww_form_placeholder( $field ) . $req . ' maxlength="' . $max . '"' . $common . '>';
			break;

		case 'text':
			$prefix = $label( esc_html( (string) $field['label'] ) );
			$inner  = '<textarea class="ww-form__input"' . $id_at . ' name="' . esc_attr( $name ) . '"'
				. _ww_form_placeholder( $field ) . $req . ' maxlength="' . (int) $field['max_length'] . '"' . $common . '>' . esc_textarea( $text ) . '</textarea>';
			break;

		case 'file':
			$max_files = (int) ( $field['max_files'] ?? 1 );
			$prefix    = $label( esc_html( (string) $field['label'] ) );
			$inner     = '<input class="ww-form__input"' . $id_at . ' name="' . esc_attr( 'ww_files[' . $key . '][]' ) . '" type="file"' . $req
				. ' accept="' . esc_attr( '.' . implode( ',.', _ww_form_file_extensions( $field ) ) ) . '"'
				. ' data-ww-max-size="' . ( _ww_form_file_limit_mb( $field ) * MB_IN_BYTES ) . '"'
				. ' data-ww-max-files="' . $max_files . '"'
				. ( $max_files > 1 ? ' multiple' : '' ) . $common . '>';
			break;

		case 'checkbox':
			$prefix = '';
			$inner  = '<label class="ww-form__label ww-form__label--checkbox" for="' . esc_attr( $html_id ) . '">'
				. '<input class="ww-form__input"' . $id_at . ' name="' . esc_attr( $name ) . '" type="checkbox" value="1"'
				. $req . ( '1' === $text ? ' checked' : '' ) . $common . '> '
				. wp_kses_post( (string) $field['label'] ) . $mark . '</label>';
			break;

		case 'select':
			$empty   = (string) ( $field['empty_option'] ?? '' );
			$prefix  = $label( esc_html( (string) $field['label'] ) );
			$options = '' !== $empty ? '<option value="">' . esc_html( $empty ) . '</option>' : '';
			foreach ( $field['options'] as $option ) {
				$options .= '<option value="' . esc_attr( $option['value'] ) . '"' . ( $text === $option['value'] ? ' selected' : '' ) . '>' . esc_html( $option['label'] ) . '</option>';
			}
			// Zonder lege optie is de eerste optie al gekozen: required zou dan niets controleren.
			$inner = '<select class="ww-form__input"' . $id_at . ' name="' . esc_attr( $name ) . '"' . ( '' !== $empty ? $req : '' ) . $common . '>' . $options . '</select>';
			break;

		case 'choice':
			$multiple = ! empty( $field['multiple'] );
			$chosen   = array();
			foreach ( is_array( $value ) ? $value : array( $value ) as $one ) {
				$chosen[] = _ww_form_string( $one );
			}
			$items = '';
			foreach ( $field['options'] as $n => $option ) {
				$option_id = $html_id . '-' . ( $n + 1 );
				$items    .= '<div class="ww-form__option"><label for="' . esc_attr( $option_id ) . '">'
					. '<input id="' . esc_attr( $option_id ) . '" name="' . esc_attr( $multiple ? $name . '[]' : $name ) . '" type="' . ( $multiple ? 'checkbox' : 'radio' ) . '"'
					. ' value="' . esc_attr( $option['value'] ) . '"'
					. ( $multiple ? '' : $req ) . ( in_array( $option['value'], $chosen, true ) ? ' checked' : '' ) . '> '
					. esc_html( $option['label'] ) . '</label></div>';
			}
			return '<div class="' . esc_attr( $classes ) . '"><fieldset' . $id_at . $describedby . '>'
				. '<legend class="ww-form__label">' . esc_html( (string) $field['label'] ) . $mark . '</legend>'
				. $items . $tail . '</fieldset></div>';
	}

	return '<div class="' . esc_attr( $classes ) . '">' . $prefix . $inner . $tail . '</div>';
}
