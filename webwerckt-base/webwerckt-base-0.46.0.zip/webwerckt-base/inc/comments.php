<?php
/**
 * Reacties en pingbacks staan helemaal uit (beslissing 0026): niet te plaatsen, niet te tonen, niet in het beheer,
 * de REST API, XML-RPC of de feeds. De instellingen onder Instellingen → Discussie doen niets meer.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Nergens open, ook niet bij een bericht dat in de database nog op open staat. Ook wp-comments-post.php weigert dan.
add_filter( 'comments_open', '__return_false', 20 );
add_filter( 'pings_open', '__return_false', 20 );
add_filter( 'pre_option_default_comment_status', static fn() => 'closed' );
add_filter( 'pre_option_default_ping_status', static fn() => 'closed' );

// Reacties die nog in de database staan, toont een child-thema ook met comments_template() niet.
add_filter( 'comments_array', '__return_empty_array', 20 );
add_filter( 'get_comments_number', '__return_zero', 20 );

/**
 * Haalt de ondersteuning voor reacties en trackbacks weg bij elk post type, ook die van het child-thema en plugins.
 * Daarmee verdwijnen ook de box Discussie en de kolom Reacties in de berichtenlijst.
 */
function _ww_remove_comment_support(): void {
	foreach ( get_post_types() as $post_type ) {
		remove_post_type_support( $post_type, 'comments' );
		remove_post_type_support( $post_type, 'trackbacks' );
	}
}
add_action( 'init', '_ww_remove_comment_support', 100 );

/**
 * Geen X-Pingback-header.
 *
 * @param array<string,string> $headers Headers van WordPress.
 * @return array<string,string>
 */
function _ww_remove_pingback_header( array $headers ): array {
	unset( $headers['X-Pingback'] );
	return $headers;
}
add_filter( 'wp_headers', '_ww_remove_pingback_header' );

/**
 * Geen pingbacks via XML-RPC.
 *
 * @param array<string,mixed> $methods Methoden van XML-RPC.
 * @return array<string,mixed>
 */
function _ww_remove_pingback_methods( array $methods ): array {
	unset( $methods['pingback.ping'], $methods['pingback.extensions.getPingbacks'] );
	return $methods;
}
add_filter( 'xmlrpc_methods', '_ww_remove_pingback_methods' );

/**
 * Geen reacties in de REST API.
 *
 * @param array<string,mixed> $endpoints Routes van de REST API.
 * @return array<string,mixed>
 */
function _ww_remove_comment_endpoints( array $endpoints ): array {
	foreach ( array_keys( $endpoints ) as $route ) {
		if ( str_starts_with( (string) $route, '/wp/v2/comments' ) ) {
			unset( $endpoints[ $route ] );
		}
	}
	return $endpoints;
}
add_filter( 'rest_endpoints', '_ww_remove_comment_endpoints' );

// Geen links naar reactiefeeds in de head.
add_filter( 'feed_links_show_comments_feed', '__return_false' );
add_filter( 'feed_links_extra_show_post_comments_feed', '__return_false' );

/**
 * Een reactiefeed stuurt door naar de homepage. Een 404 kan hier niet: WordPress toont een feed ook dan.
 */
function _ww_redirect_comment_feed(): void {
	if ( is_comment_feed() ) {
		wp_safe_redirect( home_url( '/' ), 301 );
		exit;
	}
}
add_action( 'template_redirect', '_ww_redirect_comment_feed', 9 );

/**
 * Geen script voor het antwoordformulier.
 */
function _ww_dequeue_comment_reply(): void {
	wp_dequeue_script( 'comment-reply' );
}
add_action( 'wp_enqueue_scripts', '_ww_dequeue_comment_reply', 100 );

/**
 * Geen widget Recente reacties.
 */
function _ww_unregister_comment_widget(): void {
	unregister_widget( 'WP_Widget_Recent_Comments' );
}
add_action( 'widgets_init', '_ww_unregister_comment_widget', 20 );
add_filter( 'show_recent_comments_widget_style', '__return_false' );

/**
 * Reacties en Instellingen → Discussie verdwijnen uit het menu, voor iedereen.
 */
function _ww_remove_comment_menus(): void {
	remove_menu_page( 'edit-comments.php' );
	remove_submenu_page( 'options-general.php', 'options-discussion.php' );
}
add_action( 'admin_menu', '_ww_remove_comment_menus', 999 );

/**
 * Het reactie-icoon verdwijnt uit de adminbalk, voor iedereen.
 */
function _ww_remove_comment_admin_bar( WP_Admin_Bar $bar ): void {
	$bar->remove_node( 'comments' );
}
add_action( 'admin_bar_menu', '_ww_remove_comment_admin_bar', 999 );

/**
 * In het beheer telt WordPress geen reacties: niets bij "In een oogopslag" op het dashboard. Buiten het beheer
 * (WP-CLI) blijft de echte telling, zodat oude reacties op te ruimen zijn.
 *
 * @param array<mixed>|stdClass $count Leeg, of een telling van een eerder filter.
 * @return array<mixed>|stdClass
 */
function _ww_count_no_comments( $count ) {
	if ( ! is_admin() ) {
		return $count;
	}
	return (object) array_fill_keys( array( 'approved', 'moderated', 'spam', 'trash', 'post-trashed', 'total_comments', 'all' ), 0 );
}
add_filter( 'wp_count_comments', '_ww_count_no_comments', 20 );

/**
 * Op het dashboard vindt een zoekopdracht naar reacties niets: de widget Activiteit leest ze zonder filter uit de
 * database. Alleen daar, zodat WP-CLI en plugins de oude reacties nog wel vinden.
 *
 * @param mixed            $comments Null, of een resultaat van een eerder filter.
 * @param WP_Comment_Query $query    De zoekopdracht.
 * @return mixed
 */
function _ww_dashboard_no_comments( $comments, WP_Comment_Query $query ) {
	global $pagenow;
	if ( null !== $comments || ! is_admin() || 'index.php' !== $pagenow ) {
		return $comments;
	}
	return empty( $query->query_vars['count'] ) ? array() : 0;
}
add_filter( 'comments_pre_query', '_ww_dashboard_no_comments', 10, 2 );

/**
 * Of dit een beheerscherm voor reacties is: de lijst, één reactie bewerken of Instellingen → Discussie.
 */
function _ww_is_comment_screen(): bool {
	global $pagenow;
	return in_array( $pagenow, array( 'edit-comments.php', 'comment.php', 'options-discussion.php' ), true );
}

/**
 * Een beheerscherm voor reacties via de URL stuurt door naar het dashboard.
 */
function _ww_redirect_comment_screens(): void {
	if ( _ww_is_comment_screen() ) {
		wp_safe_redirect( admin_url() );
		exit;
	}
}
add_action( 'admin_init', '_ww_redirect_comment_screens' );
