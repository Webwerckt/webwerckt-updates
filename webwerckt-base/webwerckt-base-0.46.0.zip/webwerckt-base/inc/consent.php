<?php
/**
 * Toestemmingslaag (beslissing 0037): code uit de vier consent-velden van de Site-instellingen komt in
 * <template>-elementen in de HTML en draait pas nadat de bezoeker toestemming gaf. De HTML is voor iedereen
 * gelijk, dus de paginacache blijft werken; PHP zet geen cookies. Zoals bij scripts.php zien en bewerken alleen
 * wie ongefilterde HTML mag plaatsen de velden (pods/settings.json, _ww_field_restricted()).
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * De code van een consent-veld, of '' als hij er niet hoort (admin, Visueel bewerken). Een afsluitende
 * </template in de code wordt onschadelijk gemaakt, zodat de code het element niet kan afsluiten.
 *
 * @param string $category statistics of marketing.
 * @param string $place    head of body.
 */
function _ww_consent_code( string $category, string $place ): string {
	$code = _ww_setting_scripts( "consent_{$category}_{$place}" );
	return (string) preg_replace( '#</(template)#i', '<\/$1', $code );
}

/**
 * Welke categorieën actief zijn: er staat code in minstens één van de twee velden, en het filter
 * ww_consent_categories zet de categorie niet uit.
 *
 * @return array<string,bool>
 */
function _ww_consent_categories(): array {
	$categories = array();
	foreach ( array( 'statistics', 'marketing' ) as $category ) {
		$categories[ $category ] = '' !== _ww_consent_code( $category, 'head' ) || '' !== _ww_consent_code( $category, 'body' );
	}
	/**
	 * Zet een categorie uit (false), bijvoorbeeld per taal of per pagina. Aanzetten kan niet: een categorie zonder code blijft uit.
	 *
	 * @param array<string,bool> $categories Sleutels statistics en marketing.
	 */
	$filtered = apply_filters( 'ww_consent_categories', $categories );
	foreach ( $categories as $category => $active ) {
		// Het filter mag alleen uitzetten: een categorie zonder code blijft uit.
		$categories[ $category ] = $active && ! empty( $filtered[ $category ] );
	}
	return $categories;
}

/**
 * Is er minstens één categorie actief, dus hoort er een banner en een keuze?
 */
function _ww_consent_active(): bool {
	return in_array( true, _ww_consent_categories(), true );
}

/**
 * Versie van de keuze: verandert met de code, zodat een bezoeker opnieuw gevraagd wordt als de code wijzigt.
 */
function _ww_consent_version(): string {
	$codes = array();
	foreach ( array( 'statistics', 'marketing' ) as $category ) {
		foreach ( array( 'head', 'body' ) as $place ) {
			$codes[] = _ww_consent_code( $category, $place );
		}
	}
	return substr( md5( implode( "\0", $codes ) ), 0, 8 );
}

/**
 * Print de templates van één plek.
 *
 * @param string $place head of body.
 */
function _ww_consent_print_templates( string $place ): void {
	foreach ( _ww_consent_categories() as $category => $active ) {
		$code = $active ? _ww_consent_code( $category, $place ) : '';
		if ( '' !== $code ) {
			echo '<template data-ww-consent="' . esc_attr( $category ) . '" data-ww-place="' . esc_attr( $place ) . '">' . $code . "</template>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- code van een beheerder (manage_options), bewust ongewijzigd.
		}
	}
}

/**
 * Templates in de <head>, direct na de gewone scripts.
 */
function _ww_consent_print_head_templates(): void {
	_ww_consent_print_templates( 'head' );
}
add_action( 'wp_head', '_ww_consent_print_head_templates', 1 );

/**
 * Templates direct na <body>, na de gewone scripts.
 */
function _ww_consent_print_body_templates(): void {
	_ww_consent_print_templates( 'body' );
}
add_action( 'wp_body_open', '_ww_consent_print_body_templates', 1 );

/**
 * De standaardtekst van de banner, voor als consent_text leeg is.
 */
function _ww_consent_default_text(): string {
	return __( 'We gebruiken cookies voor statistieken en marketing, alleen als je daar toestemming voor geeft.', 'webwerckt-base' );
}

/**
 * De banner: voor elke bezoeker dezelfde HTML (paginacache); consent.js toont hem als dat nodig is.
 * Alleen actieve categorieën krijgen een schakelaar, geen enkele staat vooraf aan.
 */
function _ww_consent_banner_html(): string {
	$text = trim( _ww_setting_string( 'consent_text' ) );
	if ( '' === $text ) {
		$text = _ww_consent_default_text();
	}
	$privacy_url = get_privacy_policy_url();

	$labels  = array(
		'statistics' => __( 'Statistieken', 'webwerckt-base' ),
		'marketing'  => __( 'Marketing', 'webwerckt-base' ),
	);
	$choices = '<label><input type="checkbox" checked disabled> ' . esc_html__( 'Noodzakelijk', 'webwerckt-base' ) . '</label>';
	foreach ( _ww_consent_categories() as $category => $active ) {
		if ( $active ) {
			$choices .= '<label><input type="checkbox" name="' . esc_attr( $category ) . '"> ' . esc_html( $labels[ $category ] ) . '</label>';
		}
	}

	$html  = '<section class="ww-consent" data-ww-consent-banner hidden data-ww-consent-version="' . esc_attr( _ww_consent_version() ) . '" aria-label="' . esc_attr__( 'Cookiemelding', 'webwerckt-base' ) . '">';
	$html .= '<p class="ww-consent__text">' . esc_html( $text );
	if ( '' !== $privacy_url ) {
		$html .= ' <a href="' . esc_url( $privacy_url ) . '">' . esc_html__( 'Privacyverklaring', 'webwerckt-base' ) . '</a>';
	}
	$html .= '</p>';
	$html .= '<div class="ww-consent__choices" id="ww-consent-choices" data-ww-consent-choices hidden>' . $choices . '</div>';
	$html .= '<div class="ww-consent__buttons">';
	$html .= '<button type="button" class="ww-consent__button" data-ww-consent-action="accept">' . esc_html__( 'Accepteren', 'webwerckt-base' ) . '</button>';
	$html .= '<button type="button" class="ww-consent__button" data-ww-consent-action="reject">' . esc_html__( 'Weigeren', 'webwerckt-base' ) . '</button>';
	$html .= '<button type="button" class="ww-consent__button" data-ww-consent-action="settings" aria-expanded="false" aria-controls="ww-consent-choices">' . esc_html__( 'Instellingen', 'webwerckt-base' ) . '</button>';
	$html .= '<button type="button" class="ww-consent__button" data-ww-consent-action="save" hidden>' . esc_html__( 'Keuze opslaan', 'webwerckt-base' ) . '</button>';
	$html .= '</div></section>' . "\n";
	return $html;
}

/**
 * Print de banner in de footer, alleen als er een categorie actief is.
 */
function _ww_consent_print_banner(): void {
	if ( _ww_consent_active() ) {
		echo _ww_consent_banner_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- elk onderdeel is in _ww_consent_banner_html() geëscaped.
	}
}
add_action( 'wp_footer', '_ww_consent_print_banner' );

/**
 * Laad consent.js en consent.css, alleen als er een banner is.
 */
function _ww_consent_enqueue(): void {
	if ( ! _ww_consent_active() ) {
		return;
	}
	wp_enqueue_style( 'ww-consent', _ww_asset_url( 'css/consent.css' ), array(), WW_BASE_VERSION );
	wp_enqueue_script(
		'ww-consent',
		_ww_asset_url( 'js/consent.js' ),
		array(),
		WW_BASE_VERSION,
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);
}
add_action( 'wp_enqueue_scripts', '_ww_consent_enqueue' );

/**
 * Knop die de banner opent (voor in de footer of een privacypagina), of '' als er geen banner is.
 *
 * @param string $label Tekst op de knop; leeg is Cookie-instellingen.
 */
function ww_consent_link( string $label = '' ): string {
	if ( ! _ww_consent_active() ) {
		return '';
	}
	if ( '' === $label ) {
		$label = __( 'Cookie-instellingen', 'webwerckt-base' );
	}
	return '<button type="button" class="ww-consent-link" data-ww-consent-open>' . esc_html( $label ) . '</button>';
}
