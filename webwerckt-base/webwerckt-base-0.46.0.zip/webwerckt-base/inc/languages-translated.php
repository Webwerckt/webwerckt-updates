<?php
/**
 * Telling vertaald per taal: hoeveel berichten in de standaardtaal een vertaling in een extra taal hebben. Het vak
 * Vertaald op de pagina van een taal (inc/languages-admin-screen.php) en het filter Zonder vertaling in de lijst
 * (_ww_languages_pre_get_posts()) gebruiken hem.
 *
 * @package webwerckt-base
 */

defined( 'ABSPATH' ) || exit;

/**
 * De waarde die in de geserialiseerde meta _ww_translations staat voor deze sleutel: s:{lengte}:"{code}";. Zo telt
 * een taal met dezelfde beginletters (en-us naast en) niet mee.
 */
function _ww_languages_translated_needle( string $code ): string {
	return 's:' . strlen( $code ) . ':"' . $code . '";';
}

/**
 * Per vertaalbaar post type met berichten in de standaardtaal: het totaal en het aantal met een vertaling in deze taal.
 * Statussen van _ww_languages_counted_statuses() zonder trash. Eén uur bewaard (transient per taal), geleegd door
 * _ww_languages_translated_flush().
 *
 * @param string $code Taalcode.
 * @return array<string,array{total:int,translated:int}>
 */
function _ww_languages_translated_counts( string $code ): array {
	$key    = 'ww_languages_translated_' . $code;
	$cached = get_transient( $key );
	if ( is_array( $cached ) ) {
		/** @var array<string,array{total:int,translated:int}> $cached */
		return $cached;
	}

	$statuses = array_values( array_diff( _ww_languages_counted_statuses(), array( 'trash' ) ) );
	$counts   = array();
	foreach ( _ww_translatable_post_types() as $type ) {
		$base  = array(
			'post_type'           => $type,
			'post_status'         => $statuses,
			'tax_query'           => _ww_languages_tax_query( _ww_default_language() ), // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- alleen in het beheer, daarna in een transient.
			'fields'              => 'ids',
			'posts_per_page'      => 1,
			'ignore_sticky_posts' => true,
			'no_found_rows'       => false,
		);
		$total = ( new WP_Query( $base ) )->found_posts;
		if ( $total < 1 ) {
			continue;
		}
		$translated = ( new WP_Query(
			$base + array(
				'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- idem.
					array(
						'key'     => '_ww_translations',
						'value'   => _ww_languages_translated_needle( $code ),
						'compare' => 'LIKE',
					),
				),
			)
		) )->found_posts;

		$counts[ $type ] = array(
			'total'      => (int) $total,
			'translated' => (int) $translated,
		);
	}

	set_transient( $key, $counts, HOUR_IN_SECONDS );
	return $counts;
}

/**
 * Wist de transient van elke taal.
 *
 * @param list<string> $also Codes die er (nog) bij horen, zoals de talen van voor het opslaan van de configuratie.
 */
function _ww_languages_translated_flush( array $also = array() ): void {
	foreach ( array_unique( array_merge( _ww_language_codes(), $also ) ) as $code ) {
		delete_transient( 'ww_languages_translated_' . $code );
	}
}

/**
 * Hook set_object_terms: een vertaalbaar bericht krijgt een andere taal.
 *
 * @param mixed $object_id Object-ID.
 * @param mixed $terms     Termen.
 * @param mixed $tt_ids    Term-taxonomie-ID's.
 * @param mixed $taxonomy  Taxonomie.
 */
function _ww_languages_translated_on_terms( $object_id, $terms, $tt_ids, $taxonomy ): void {
	if ( 'ww_language' === $taxonomy && _ww_is_translatable( (string) get_post_type( (int) $object_id ) ) ) {
		_ww_languages_translated_flush();
	}
}

/**
 * Hook transition_post_status: een vertaalbaar bericht krijgt een andere status (nieuw, prullenbak, concept). Een
 * opslag zonder statuswissel doet niets.
 *
 * @param mixed $new_status Nieuwe status.
 * @param mixed $old_status Vorige status.
 * @param mixed $post       Bericht.
 */
function _ww_languages_translated_on_status( $new_status, $old_status, $post ): void {
	if ( $new_status !== $old_status && $post instanceof WP_Post && _ww_is_translatable( $post->post_type ) ) {
		_ww_languages_translated_flush();
	}
}

/**
 * Hook deleted_post: een vertaalbaar bericht is definitief weg.
 *
 * @param mixed $post_id Post-ID.
 * @param mixed $post    Bericht.
 */
function _ww_languages_translated_on_delete( $post_id, $post = null ): void {
	if ( $post instanceof WP_Post && _ww_is_translatable( $post->post_type ) ) {
		_ww_languages_translated_flush();
	}
}

/**
 * De meta_query van het filter Zonder vertaling: geen _ww_translations, of een groep zonder deze taal.
 *
 * @param string $code Taalcode.
 * @return array<int|string,mixed>
 */
function _ww_languages_untranslated_meta_query( string $code ): array {
	return array(
		'relation' => 'OR',
		array(
			'key'     => '_ww_translations',
			'compare' => 'NOT EXISTS',
		),
		array(
			'key'     => '_ww_translations',
			'value'   => _ww_languages_translated_needle( $code ),
			'compare' => 'NOT LIKE',
		),
	);
}
