<?php
/**
 * Tabel van het logboek op het scherm Mail (inc/mail-admin-sections.php). Wordt pas geladen als dat scherm wordt
 * getoond, na WP_List_Table.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * De mails: onderwerp (link naar het detail), aan, status, via en wanneer. Alles wat uit de log komt, wordt
 * ge-escaped.
 */
class WW_Mail_Log_List_Table extends WP_List_Table {

	public function __construct() {
		parent::__construct(
			array(
				'singular' => 'mail',
				'plural'   => 'mails',
				'ajax'     => false,
			)
		);
	}

	/**
	 * De statusfilter: sent, failed of '' (alle).
	 */
	public function get_status_filter(): string {
		$status = isset( $_GET['status'] ) ? sanitize_key( _ww_data_to_string( wp_unslash( $_GET['status'] ) ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen filteren.
		return in_array( $status, array( 'sent', 'failed' ), true ) ? $status : '';
	}

	/**
	 * De zoekterm, of ''.
	 */
	public function get_search_term(): string {
		return isset( $_GET['s'] ) ? trim( sanitize_text_field( _ww_data_to_string( wp_unslash( $_GET['s'] ) ) ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen zoeken.
	}

	/**
	 * Het id van de regel waarvoor het verwijderen wordt bevestigd, of 0.
	 */
	public function get_confirm_id(): int {
		return isset( $_GET['ww_confirm'] ) ? absint( _ww_data_to_string( wp_unslash( $_GET['ww_confirm'] ) ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen een vraag tonen; verwijderen heeft een nonce.
	}

	/**
	 * De weergave en de zoekterm, voor in een link naar dit scherm.
	 *
	 * @return array<string,string>
	 */
	private function keep_args(): array {
		return array_filter(
			array(
				'status' => $this->get_status_filter(),
				's'      => $this->get_search_term(),
			),
			static fn( string $value ): bool => '' !== $value
		);
	}

	/**
	 * De pagina uit het verzoek, voor in een link; leeg als er geen is.
	 *
	 * @return array<string,string>
	 */
	private function page_arg(): array {
		$paged = isset( $_GET['paged'] ) ? absint( _ww_data_to_string( wp_unslash( $_GET['paged'] ) ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen een link.
		return $paged > 0 ? array( 'paged' => (string) $paged ) : array();
	}

	/**
	 * De weergaven Alle, Verstuurd en Mislukt met hun aantallen; de zoekterm blijft staan.
	 *
	 * @return array<string,string>
	 */
	protected function get_views() {
		$counts  = _ww_mail_log_counts();
		$current = $this->get_status_filter();
		$search  = $this->get_search_term();
		$labels  = array(
			'all'    => array( '', __( 'Alle', 'webwerckt-base' ) ),
			'sent'   => array( 'sent', __( 'Verstuurd', 'webwerckt-base' ) ),
			'failed' => array( 'failed', __( 'Mislukt', 'webwerckt-base' ) ),
		);
		$views   = array();
		foreach ( $labels as $key => $view ) {
			$args          = array_filter(
				array(
					'status' => $view[0],
					's'      => $search,
				),
				static fn( string $value ): bool => '' !== $value
			);
			$views[ $key ] = '<a href="' . esc_url( _ww_mail_log_url( $args ) ) . '"' . ( $current === $view[0] ? ' class="current" aria-current="page"' : '' ) . '>' . esc_html( $view[1] ) . ' <span class="count">(' . esc_html( number_format_i18n( $counts[ $key ] ) ) . ')</span></a>';
		}
		return $views;
	}

	/**
	 * Het zoekveld, met een placeholder.
	 *
	 * @param string $text     Tekst van de knop.
	 * @param string $input_id Id van het veld.
	 */
	public function search_box( $text, $input_id ): void {
		ob_start();
		parent::search_box( $text, $input_id );
		echo str_replace( '<input type="search"', '<input type="search" placeholder="' . esc_attr__( 'Ontvanger of onderwerp', 'webwerckt-base' ) . '"', (string) ob_get_clean() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- uitvoer van WordPress zelf; alleen een geëscapete placeholder erbij.
	}

	/**
	 * @return array<string,string>
	 */
	public function get_columns() {
		return array(
			'cb'        => '<input type="checkbox">',
			'subject'   => __( 'Onderwerp', 'webwerckt-base' ),
			'recipient' => __( 'Aan', 'webwerckt-base' ),
			'status'    => __( 'Status', 'webwerckt-base' ),
			'transport' => __( 'Via', 'webwerckt-base' ),
			'created'   => __( 'Wanneer', 'webwerckt-base' ),
		);
	}

	/**
	 * @return array<string,string>
	 */
	protected function get_bulk_actions() {
		return array(
			'bulk-resend' => __( 'Opnieuw versturen', 'webwerckt-base' ),
			'bulk-delete' => __( 'Verwijderen', 'webwerckt-base' ),
		);
	}

	/**
	 * Zoekt, filtert en pagineert via _ww_mail_log_query().
	 */
	public function prepare_items(): void {
		$result = _ww_mail_log_query(
			array(
				'status'   => $this->get_status_filter(),
				'search'   => $this->get_search_term(),
				'page'     => $this->get_pagenum(),
				'per_page' => WW_MAIL_LOG_PER_PAGE,
			)
		);

		$this->_column_headers = array( $this->get_columns(), array(), array(), 'subject' );
		$this->set_pagination_args(
			array(
				'total_items' => $result['total'],
				'per_page'    => WW_MAIL_LOG_PER_PAGE,
			)
		);
		$this->items = $result['items'];
	}

	/**
	 * De primaire kolom is het onderwerp: daar staan de rijacties.
	 */
	protected function get_default_primary_column_name(): string {
		return 'subject';
	}

	/**
	 * Tekst als er geen mails zijn.
	 */
	public function no_items(): void {
		if ( 'failed' === $this->get_status_filter() && '' === $this->get_search_term() ) {
			esc_html_e( 'Geen mislukte mails. Alles wat de site de afgelopen 30 dagen verstuurde, kwam aan bij de aansluiting.', 'webwerckt-base' );
			return;
		}
		esc_html_e( 'Er zijn geen mails.', 'webwerckt-base' );
	}

	/**
	 * Het onderwerp, of de tekst voor een mail zonder onderwerp.
	 *
	 * @param object $item Regel.
	 */
	private function subject_text( object $item ): string {
		return '' === (string) $item->subject ? __( '(geen onderwerp)', 'webwerckt-base' ) : (string) $item->subject;
	}

	/**
	 * De eerste ontvanger, of ''.
	 *
	 * @param object $item Regel.
	 */
	private function first_recipient( object $item ): string {
		$to = array_values( array_filter( (array) $item->recipients['to'], 'is_string' ) );
		return $to[0] ?? '';
	}

	/**
	 * De rij, en onder de rij waarvoor het verwijderen wordt bevestigd de vraag met twee knoppen.
	 *
	 * @param object $item Regel.
	 */
	public function single_row( $item ): void {
		parent::single_row( $item );
		if ( (int) $item->id !== $this->get_confirm_id() ) {
			return;
		}
		$subject = '<strong>' . esc_html( $this->subject_text( $item ) ) . '</strong>';
		$to      = $this->first_recipient( $item );
		if ( '' === $to ) {
			/* translators: %s: onderwerp van de mail. */
			$text = sprintf( esc_html__( '%s definitief uit het logboek verwijderen? Dit kan niet ongedaan worden gemaakt.', 'webwerckt-base' ), $subject );
		} else {
			/* translators: 1: onderwerp van de mail, 2: ontvanger. */
			$text = sprintf( esc_html__( '%1$s aan %2$s definitief uit het logboek verwijderen? Dit kan niet ongedaan worden gemaakt.', 'webwerckt-base' ), $subject, esc_html( $to ) );
		}
		$cancel = _ww_mail_log_url( $this->keep_args() + $this->page_arg() );
		echo '<tr class="ww-mail-confirm-row"><td colspan="' . esc_attr( (string) $this->get_column_count() ) . '"><p>' . $text . '</p><p class="ww-mail-confirm-buttons">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $text is opgebouwd uit geëscapete delen.
		echo '<a class="button ww-mail-button-delete" href="' . esc_url( _ww_mail_log_action_url( 'delete', array( 'id' => (string) $item->id ) ) ) . '">' . esc_html__( 'Verwijderen', 'webwerckt-base' ) . '</a> ';
		echo '<a class="button" href="' . esc_url( $cancel ) . '">' . esc_html__( 'Annuleren', 'webwerckt-base' ) . '</a>';
		echo '</p></td></tr>';
	}

	/**
	 * Selectievakje voor de bulkactie.
	 *
	 * @param object $item Regel.
	 */
	protected function column_cb( $item ): string {
		return '<input type="checkbox" name="ids[]" value="' . esc_attr( (string) $item->id ) . '">';
	}

	/**
	 * Het moment van versturen in de tijdzone van de site.
	 *
	 * @param object $item Regel.
	 */
	protected function column_created( $item ): string {
		return esc_html( _ww_mail_log_date( (string) $item->created ) );
	}

	/**
	 * De eerste ontvanger, met "+N" bij meer ontvangers.
	 *
	 * @param object $item Regel.
	 */
	protected function column_recipient( $item ): string {
		$to    = array_values( array_filter( (array) $item->recipients['to'], 'is_string' ) );
		$first = $this->first_recipient( $item );
		if ( '' === $first ) {
			return '&mdash;';
		}
		$more = count( $to ) - 1;
		return esc_html( $first ) . ( $more > 0 ? ' <span class="description">+' . esc_html( (string) $more ) . '</span>' : '' );
	}

	/**
	 * Het onderwerp als link naar het detail, bij een mislukte mail met de fout eronder, en de acties.
	 *
	 * @param object $item Regel.
	 */
	protected function column_subject( $item ): string {
		$id      = (string) $item->id;
		$url     = _ww_mail_log_url( array( 'id' => $id ) );
		$ask     = _ww_mail_log_url( array( 'ww_confirm' => $id ) + $this->keep_args() + $this->page_arg() );
		$actions = array(
			'view'   => '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Bekijken', 'webwerckt-base' ) . '</a>',
			'resend' => '<a href="' . esc_url( _ww_mail_log_action_url( 'resend', array( 'id' => $id ) ) ) . '">' . esc_html__( 'Opnieuw versturen', 'webwerckt-base' ) . '</a>',
			'delete' => '<a href="' . esc_url( $ask ) . '">' . esc_html__( 'Verwijderen', 'webwerckt-base' ) . '</a>',
		);
		$error   = 'failed' === $item->status && '' !== (string) $item->error ? '<span class="ww-mail-error">' . esc_html( (string) $item->error ) . '</span>' : '';
		return '<strong><a class="row-title" href="' . esc_url( $url ) . '">' . esc_html( $this->subject_text( $item ) ) . '</a></strong>' . $error . $this->row_actions( $actions );
	}

	/**
	 * De aansluiting waarlangs de mail ging.
	 *
	 * @param object $item Regel.
	 */
	protected function column_transport( $item ): string {
		return esc_html( _ww_mail_log_transport_label( (string) $item->transport ) );
	}

	/**
	 * Verstuurd of Mislukt, als chip.
	 *
	 * @param object $item Regel.
	 */
	protected function column_status( $item ): string {
		return _ww_mail_status_chip( (string) $item->status );
	}
}
