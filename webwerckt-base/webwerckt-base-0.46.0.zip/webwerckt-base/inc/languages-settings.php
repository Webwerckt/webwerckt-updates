<?php
/**
 * Meertalig sitebreed (beslissing 0042): Site-instellingen per taal.
 *
 * Per extra taal staat één optie ww_settings_{lang}: een array veldnaam => waarde, alleen vertaalbare velden en zonder
 * lege waarden. De opties site_settings_{veld} blijven de standaardtaal. Zonder _ww_languages_active() wordt
 * ww_settings_{lang} nooit gelezen.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Of een veld van de Site-instellingen per taal bewaard kan worden: type text, paragraph of wysiwyg, en niet
 * "ww_translate": false. Alle andere types (telefoon, e-mail, keuzelijsten, foto's, relaties) gelden voor alle talen.
 *
 * @param array<string,mixed> $field Veldconfiguratie.
 */
function _ww_setting_translatable( array $field ): bool {
	if ( false === ( $field['ww_translate'] ?? true ) ) {
		return false;
	}
	return in_array( _ww_data_to_string( $field['type'] ?? '' ), array( 'text', 'paragraph', 'wysiwyg' ), true );
}

/**
 * Het veld uit de Site-instellingen op naam, zonder rechtencontrole. De velden op naam staan per request in een
 * cache met dezelfde sleutel als _ww_pods_config(), want dit draait bij elke instelling die het template leest.
 *
 * @return array<string,mixed>|null
 */
function _ww_setting_field( string $name ): ?array {
	static $maps = array();

	$key = _ww_pods_config_key();
	if ( ! isset( $maps[ $key ] ) ) {
		$maps[ $key ] = array();
		foreach ( _ww_pods_setting_fields() as $field ) {
			$maps[ $key ][ _ww_data_to_string( $field['name'] ?? '' ) ] ??= $field;
		}
	}
	return $maps[ $key ][ $name ] ?? null;
}

/**
 * Of een veld een relatie naar berichten is (pick met pick_object post_type).
 *
 * @param array<string,mixed> $field Veldconfiguratie.
 */
function _ww_setting_is_post_relation( array $field ): bool {
	return 'pick' === ( $field['type'] ?? '' ) && 'post_type' === ( $field['pick_object'] ?? '' );
}

/**
 * De taal om een instelling in te lezen: $lang als het een extra taal is. Bij null op de frontend (niet in de admin,
 * niet onder WP-CLI of cron en niet in REST, behalve het kaarten-endpoint) de huidige taal als die een extra taal is.
 * Anders '': de standaardtaal.
 */
function _ww_settings_language( ?string $lang ): string {
	if ( null !== $lang ) {
		return in_array( $lang, _ww_extra_language_codes(), true ) ? $lang : '';
	}
	if ( is_admin() || _ww_languages_cli_or_cron() ) {
		return '';
	}
	if ( defined( 'REST_REQUEST' ) && REST_REQUEST && ! _ww_languages_is_cards_request() ) {
		return '';
	}
	$current = ww_current_language();
	return in_array( $current, _ww_extra_language_codes(), true ) ? $current : '';
}

/**
 * De extra taal waarin Site-instellingen bewerkt worden: $lang als Meertalig actief is en het een extra taal is, anders
 * ''. Voor alles wat een taal uit invoer neemt (editor, abilities); _ww_settings_save_translation() controleert dit
 * zelf niet.
 */
function _ww_settings_edit_language( string $lang ): string {
	return _ww_languages_active() && in_array( $lang, _ww_extra_language_codes(), true ) ? $lang : '';
}

/**
 * De taal uit invoer voor het bewerken van Site-instellingen: een extra taal, of '' voor de standaardtaal (leeg of de
 * code van de standaardtaal, alleen met Meertalig actief). Elke andere code is een fout, zodat een waarde nooit stil
 * in de standaardtaal terechtkomt.
 *
 * @param mixed $lang Invoer.
 */
function _ww_settings_input_language( mixed $lang ): string|WP_Error {
	if ( null === $lang || '' === $lang ) {
		return '';
	}
	if ( is_string( $lang ) ) {
		$extra = _ww_settings_edit_language( $lang );
		if ( '' !== $extra ) {
			return $extra;
		}
		if ( _ww_languages_active() && _ww_default_language() === $lang ) {
			return '';
		}
	}
	return new WP_Error( 'ww_abilities_value', __( 'Onbekende taal: gebruik de code van een extra taal.', 'webwerckt-base' ), array( 'status' => 400 ) );
}

/**
 * De bewaarde vertalingen van een taal: veldnaam => waarde.
 *
 * @return array<string,mixed>
 */
function _ww_settings_translation( string $lang ): array {
	$stored = get_option( 'ww_settings_' . $lang, array() );
	return is_array( $stored ) ? $stored : array();
}

/**
 * Een vertaalde waarde met dezelfde sanering als de standaardtaal: de opslaglaag (_ww_field_clean()), die per veld
 * HTML weghaalt of door wp_kses_post() haalt, shortcodes weghaalt en inkort volgens de veldopties, zoals Pods.
 *
 * @param array<string,mixed> $field Veldconfiguratie uit _ww_setting_field().
 * @param mixed               $value Gecontroleerde waarde.
 */
function _ww_settings_sanitize_translation( array $field, mixed $value ): string {
	return _ww_data_to_string( _ww_field_clean( $field, _ww_data_to_string( $value ) ) );
}

/**
 * Bewaart vertalingen van Site-instellingen voor een extra taal. $data is al gecontroleerd (waarde en rechten); hier
 * wordt bepaald of het veld vertaalbaar is, en de waarde krijgt dezelfde sanering als de standaardtaal
 * (_ww_settings_sanitize_translation()). Een waarde die daarna en na trim() leeg is, verwijdert de sleutel (de
 * standaardtaal komt terug). Eén niet-vertaalbaar veld en er wordt niets bewaard.
 *
 * @param array<string,mixed> $data Veldnaam => waarde.
 */
function _ww_settings_save_translation( array $data, string $lang ): ?WP_Error {
	$fields = array();
	foreach ( array_keys( $data ) as $name ) {
		$field = _ww_setting_field( (string) $name );
		if ( null === $field || ! _ww_setting_translatable( $field ) ) {
			/* translators: %s: veldnaam */
			$message = __( 'Het veld %s geldt voor alle talen en kan niet per taal bewaard worden.', 'webwerckt-base' );
			return new WP_Error( 'ww_settings_not_translatable', sprintf( $message, (string) $name ), array( 'status' => 400 ) );
		}
		$fields[ $name ] = $field;
	}
	$stored = _ww_settings_translation( $lang );
	foreach ( $data as $name => $value ) {
		$value = _ww_settings_sanitize_translation( $fields[ $name ], $value );
		if ( '' === trim( $value ) ) {
			unset( $stored[ $name ] );
		} else {
			$stored[ $name ] = $value;
		}
	}
	update_option( 'ww_settings_' . $lang, $stored, true );
	return null;
}

/**
 * De waarde van een veld in een extra taal. Een vertaalbaar veld geeft de vertaling als die niet leeg is, anders de
 * standaardwaarde. Een relatie naar berichten wordt per ID de gepubliceerde vertaling; wat niet vertaald is, valt weg,
 * en een ID van een niet-vertaalbaar post type blijft gelijk. Een formulier (ww_form) houdt ook het ID van de bron: de
 * taalkeuze gebeurt bij het tonen (_ww_form_resolve()), met het formulier van de standaardtaal als terugval. Een relatie met één waarde geeft één ID of null.
 *
 * @param array<string,mixed> $field         Veldconfiguratie.
 * @param mixed               $default_value Waarde van de standaardtaal.
 * @return mixed
 */
function _ww_settings_translated_value( array $field, string $name, mixed $default_value, string $lang ): mixed {
	if ( _ww_setting_is_post_relation( $field ) ) {
		if ( null === $default_value ) {
			return null;
		}
		$ids = array();
		foreach ( _ww_data_to_ids( $default_value ) as $id ) {
			// Een bericht van een post type dat niet vertaalbaar is, geldt voor alle talen en blijft staan; een formulier ook.
			$type = (string) get_post_type( $id );
			if ( WW_FORM_POST_TYPE === $type || ! _ww_is_translatable( $type ) ) {
				$ids[] = $id;
				continue;
			}
			$translated = ww_translation_id( $id, $lang );
			if ( $translated > 0 ) {
				$ids[] = $translated;
			}
		}
		// Een relatie met één waarde blijft één ID, zoals in de standaardtaal.
		return _ww_fields_is_multi( $field ) ? $ids : ( $ids[0] ?? null );
	}
	if ( ! _ww_setting_translatable( $field ) ) {
		return $default_value;
	}
	$value = _ww_settings_translation( $lang )[ $name ] ?? null;
	return '' !== trim( _ww_data_to_string( $value ) ) ? $value : $default_value;
}

/**
 * Elke wijziging van ww_settings_{lang} leegt de hele paginacache, zoals elke wijziging van Site-instellingen (0028).
 * Draait ook na init (zie _ww_languages_boot()).
 */
function _ww_languages_boot_settings(): void {
	foreach ( _ww_extra_language_codes() as $code ) {
		add_action( 'update_option_ww_settings_' . $code, '_ww_cache_purge_all', 10, 0 );
		add_action( 'add_option_ww_settings_' . $code, '_ww_cache_purge_all', 10, 0 );
	}
}
