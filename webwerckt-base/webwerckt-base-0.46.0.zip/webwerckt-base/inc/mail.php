<?php
/**
 * Mail (beslissing 0034): constanten, instellingen en versleutelde geheimen.
 *
 * Mail gaat via een aansluiting (Brevo, SMTP) en een eigen PHPMailer. Dit bestand levert de opslag (constanten uit
 * wp-config.php die voorgaan, instellingen per aansluiting en geheimen die versleuteld in de database staan), zet vóór
 * elke mail de eigen PHPMailer klaar en zet het Van-adres. Een geheim komt nooit in HTML, de log, een foutmelding of
 * error_log.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Waarde van een constante uit wp-config.php, of null als die ontbreekt of leeg is.
 *
 * Het interne filter `_ww_mail_constant` laat tests een constante nabootsen.
 *
 * @param string $name Naam van de constante.
 */
function _ww_mail_constant( string $name ): ?string {
	$value = null;
	if ( defined( $name ) ) {
		$raw = constant( $name );
		if ( is_scalar( $raw ) && '' !== (string) $raw ) {
			$value = (string) $raw;
		}
	}
	/**
	 * Intern filter: laat een test een constante nabootsen.
	 *
	 * @param string|null $value Waarde of null.
	 * @param string      $name  Naam van de constante.
	 */
	$value = apply_filters( '_ww_mail_constant', $value, $name );
	return ( is_scalar( $value ) && '' !== (string) $value ) ? (string) $value : null;
}

/**
 * Sleutel voor de geheimen, afgeleid van de salts van de site. Bewust niet bewaard, zodat een wijziging van de salts direct telt.
 */
function _ww_mail_secret_key(): string {
	return sodium_crypto_generichash( wp_salt( 'auth' ), '', SODIUM_CRYPTO_SECRETBOX_KEYBYTES );
}

/**
 * Versleutelt een geheim: base64 van een willekeurige nonce plus de versleutelde waarde.
 *
 * @param string $plain Leesbare waarde.
 */
function _ww_mail_encrypt( string $plain ): string {
	$key    = _ww_mail_secret_key();
	$nonce  = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
	$stored = base64_encode( $nonce . sodium_crypto_secretbox( $plain, $nonce, $key ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- opslagformaat, geen verhulling.
	sodium_memzero( $key );
	sodium_memzero( $plain );
	return $stored;
}

/**
 * Ontsleutelt een opgeslagen geheim. Null als dat niet lukt (andere salts, beschadigde waarde).
 *
 * @param string $stored Opgeslagen waarde.
 */
function _ww_mail_decrypt( string $stored ): ?string {
	$raw = base64_decode( $stored, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- opslagformaat, geen verhulling.
	if ( false === $raw || strlen( $raw ) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES + SODIUM_CRYPTO_SECRETBOX_MACBYTES ) {
		return null;
	}
	$nonce  = substr( $raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
	$cipher = substr( $raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
	$key    = _ww_mail_secret_key();
	$plain  = sodium_crypto_secretbox_open( $cipher, $nonce, $key );
	sodium_memzero( $key );
	return false === $plain ? null : $plain;
}

/**
 * De opgeslagen (versleutelde) geheimen, per aansluiting en veld.
 *
 * @return array<string,mixed>
 */
function _ww_mail_stored_secrets(): array {
	$all = get_option( 'ww_mail_secrets', array() );
	return is_array( $all ) ? $all : array();
}

/**
 * De opgeslagen versleutelde waarde van een veld, of '' als die ontbreekt.
 *
 * @param string $transport Id van de aansluiting.
 * @param string $field     Naam van het veld.
 */
function _ww_mail_stored_secret( string $transport, string $field ): string {
	$all = _ww_mail_stored_secrets();
	$raw = $all[ $transport ][ $field ] ?? '';
	return is_string( $raw ) ? $raw : '';
}

/**
 * Het geheim van een veld: de constante gaat voor, anders ontsleuteld uit de database. Null als het ontbreekt of niet te lezen is.
 *
 * @param string      $transport Id van de aansluiting.
 * @param string      $field     Naam van het veld.
 * @param string|null $constant  Naam van een constante die voorgaat.
 */
function _ww_mail_secret( string $transport, string $field, ?string $constant = null ): ?string {
	if ( null !== $constant ) {
		$value = _ww_mail_constant( $constant );
		if ( null !== $value ) {
			return $value;
		}
	}
	$stored = _ww_mail_stored_secret( $transport, $field );
	return '' === $stored ? null : _ww_mail_decrypt( $stored );
}

/**
 * Toestand van een geheim: `constant`, `set`, `unreadable` (opgeslagen maar niet te ontsleutelen) of `empty`.
 *
 * @param string      $transport Id van de aansluiting.
 * @param string      $field     Naam van het veld.
 * @param string|null $constant  Naam van een constante die voorgaat.
 */
function _ww_mail_secret_state( string $transport, string $field, ?string $constant = null ): string {
	if ( null !== $constant && null !== _ww_mail_constant( $constant ) ) {
		return 'constant';
	}
	$stored = _ww_mail_stored_secret( $transport, $field );
	if ( '' === $stored ) {
		return 'empty';
	}
	return null === _ww_mail_decrypt( $stored ) ? 'unreadable' : 'set';
}

/**
 * Bewaart een geheim versleuteld, of verwijdert het (null of '').
 *
 * @param string      $transport Id van de aansluiting.
 * @param string      $field     Naam van het veld.
 * @param string|null $value     Nieuwe waarde, of null of '' om te verwijderen.
 */
function _ww_mail_set_secret( string $transport, string $field, ?string $value ): void {
	$all = _ww_mail_stored_secrets();
	if ( isset( $all[ $transport ] ) && ! is_array( $all[ $transport ] ) ) {
		$all[ $transport ] = array();
	}
	if ( null === $value || '' === $value ) {
		unset( $all[ $transport ][ $field ] );
		if ( isset( $all[ $transport ] ) && array() === $all[ $transport ] ) {
			unset( $all[ $transport ] );
		}
	} else {
		$all[ $transport ][ $field ] = _ww_mail_encrypt( $value );
	}
	update_option( 'ww_mail_secrets', $all, false );
}

/**
 * Een instelling van een aansluiting uit `ww_mail_settings`.
 *
 * @param string $transport Id van de aansluiting.
 * @param string $field     Naam van het veld.
 * @param mixed  $default   Waarde als het veld niet is opgeslagen.
 * @return mixed
 */
function _ww_mail_setting( string $transport, string $field, $default = null ) {
	$all = get_option( 'ww_mail_settings', array() );
	if ( is_array( $all ) && isset( $all[ $transport ] ) && is_array( $all[ $transport ] ) && array_key_exists( $field, $all[ $transport ] ) ) {
		return $all[ $transport ][ $field ];
	}
	return $default;
}

/**
 * Id van de gekozen aansluiting: `WW_MAIL_TRANSPORT`, anders de optie, anders '' (Geen: de server).
 */
function _ww_mail_transport_id(): string {
	$constant = _ww_mail_constant( 'WW_MAIL_TRANSPORT' );
	if ( null !== $constant ) {
		return $constant;
	}
	$option = get_option( 'ww_mail_transport', '' );
	return is_string( $option ) ? $option : '';
}

/**
 * Zet vóór elke mail (pre_wp_mail) de eigen PHPMailer klaar als er een aansluiting gekozen is en geen andere mailplugin
 * het versturen overneemt. Ook een onbekende aansluiting krijgt de eigen mailer, zodat de mail mislukt in plaats van via
 * de server te gaan. Bij "Geen" blijft de mailer van WordPress staan. Geeft de invoer ongewijzigd terug.
 *
 * @param mixed $result Kortsluitwaarde van pre_wp_mail.
 * @return mixed
 */
function _ww_mail_prepare( $result ) {
	global $phpmailer;

	$id = _ww_mail_transport_id();
	if ( $phpmailer instanceof WW_PHPMailer ) {
		// Een mail die mislukt vóór send() mag niet de waarden van de vorige mail dragen.
		$phpmailer->ww_provider_id = '';
		$phpmailer->ww_transport   = '' !== _ww_mail_foreign_mailer() ? '' : sanitize_key( $id );
		return $result;
	}
	if ( '' === $id || '' !== _ww_mail_foreign_mailer() ) {
		return $result;
	}

	require_once __DIR__ . '/class-ww-phpmailer.php';
	$phpmailer               = new WW_PHPMailer( true ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- wp_mail() vult de mailer die hier staat.
	$phpmailer->ww_transport = sanitize_key( $id );
	// Zoals wp_mail() doet als het zelf een mailer maakt.
	PHPMailer\PHPMailer\PHPMailer::$validator = static function ( $email ) {
		return (bool) is_email( $email );
	};
	return $result;
}
add_filter( 'pre_wp_mail', '_ww_mail_prepare', PHP_INT_MAX );

/**
 * Het ingestelde Van-adres (`ww_mail_from`), of '' als dat leeg of ongeldig is.
 */
function _ww_mail_from_address(): string {
	$from = get_option( 'ww_mail_from', '' );
	return ( is_string( $from ) && is_email( $from ) ) ? $from : '';
}

/**
 * De Van-naam: `ww_mail_from_name`, anders de sitenaam.
 */
function _ww_mail_from_name_value(): string {
	$name = get_option( 'ww_mail_from_name', '' );
	if ( is_string( $name ) && '' !== trim( $name ) ) {
		return $name;
	}
	return wp_specialchars_decode( (string) get_option( 'blogname', '' ), ENT_QUOTES );
}

/**
 * Of het Van-adres altijd gebruikt wordt (`ww_mail_from_force`, standaard aan).
 */
function _ww_mail_from_forced(): bool {
	return (bool) (int) get_option( 'ww_mail_from_force', '1' );
}

/**
 * Het standaard Van-adres van WordPress: wordpress@ plus het domein van de site zonder www.
 */
function _ww_mail_wordpress_from(): string {
	$host = wp_parse_url( network_home_url(), PHP_URL_HOST );
	$from = 'wordpress@';
	if ( is_string( $host ) ) {
		$from .= str_starts_with( $host, 'www.' ) ? substr( $host, 4 ) : $host;
	}
	return $from;
}

/**
 * Van-adres op prioriteit 5: zonder "altijd gebruiken" vervangt het thema alleen de standaard van WordPress.
 *
 * @param mixed $from Van-adres tot nu toe.
 * @return mixed
 */
function _ww_mail_from_default( $from ) {
	$address = _ww_mail_from_address();
	if ( '' === $address || _ww_mail_from_forced() || _ww_mail_wordpress_from() !== $from ) {
		return $from;
	}
	return $address;
}
add_filter( 'wp_mail_from', '_ww_mail_from_default', 5 );

/**
 * Van-adres op de hoogste prioriteit: met "altijd gebruiken" wint het thema van plugins en van een From-header.
 *
 * @param mixed $from Van-adres tot nu toe.
 * @return mixed
 */
function _ww_mail_from_force( $from ) {
	$address = _ww_mail_from_address();
	return ( '' !== $address && _ww_mail_from_forced() ) ? $address : $from;
}
add_filter( 'wp_mail_from', '_ww_mail_from_force', PHP_INT_MAX );

/**
 * Van-naam op prioriteit 5: zonder "altijd gebruiken" vervangt het thema alleen de standaard 'WordPress'.
 *
 * @param mixed $name Van-naam tot nu toe.
 * @return mixed
 */
function _ww_mail_from_name_default( $name ) {
	if ( '' === _ww_mail_from_address() || _ww_mail_from_forced() || 'WordPress' !== $name ) {
		return $name;
	}
	$value = _ww_mail_from_name_value();
	return '' === $value ? $name : $value;
}
add_filter( 'wp_mail_from_name', '_ww_mail_from_name_default', 5 );

/**
 * Van-naam op de hoogste prioriteit: met "altijd gebruiken" wint het thema van plugins en van een From-header.
 *
 * @param mixed $name Van-naam tot nu toe.
 * @return mixed
 */
function _ww_mail_from_name_force( $name ) {
	if ( '' === _ww_mail_from_address() || ! _ww_mail_from_forced() ) {
		return $name;
	}
	$value = _ww_mail_from_name_value();
	return '' === $value ? $name : $value;
}
add_filter( 'wp_mail_from_name', '_ww_mail_from_name_force', PHP_INT_MAX );
