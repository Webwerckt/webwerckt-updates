<?php
/**
 * Tabel met de overgeslagen pagina's op de pagina Pagina cache (inc/page-cache-admin.php). Wordt pas geladen als die
 * pagina wordt getoond, na WP_List_Table.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * De overgeslagen pagina's: titel met pad en acties, waarom, en wanneer het opwarmen het weer probeert.
 */
class WW_Page_Cache_Skip_List_Table extends WP_List_Table {

	/**
	 * Alle overgeslagen pagina's, de vroegste eerst.
	 *
	 * @var list<array{url:string,until:int,code:int}>
	 */
	private array $skipped;

	/**
	 * @param list<array{url:string,until:int,code:int}> $skipped Pagina's (_ww_page_cache_preload_skipped()).
	 */
	public function __construct( array $skipped ) {
		parent::__construct(
			array(
				'singular' => 'overgeslagen pagina',
				'plural'   => 'overgeslagen paginas',
				'ajax'     => false,
			)
		);
		$this->skipped = $skipped;
	}

	/**
	 * @return array<string,string>
	 */
	public function get_columns() {
		return array(
			'title'  => __( 'Pagina', 'webwerckt-base' ),
			'reason' => __( 'Waarom', 'webwerckt-base' ),
			'until'  => __( 'Opnieuw', 'webwerckt-base' ),
		);
	}

	/**
	 * @return string
	 */
	protected function get_default_primary_column_name() {
		return 'title';
	}

	/**
	 * Alle pagina's op één lijst, zonder paginering.
	 */
	public function prepare_items(): void {
		$this->_column_headers = array( $this->get_columns(), array(), array(), 'title' );
		$items                 = array();
		foreach ( $this->skipped as $entry ) {
			$entry['title'] = _ww_page_cache_title( $entry['url'] );
			$items[]        = $entry;
		}
		$this->items = $items;
	}

	/**
	 * Geen paginering.
	 *
	 * @param string $which 'top' of 'bottom'.
	 */
	protected function pagination( $which ): void {}

	/**
	 * Tekst als er niets is overgeslagen.
	 */
	public function no_items(): void {
		esc_html_e( 'Er zijn geen overgeslagen pagina\'s.', 'webwerckt-base' );
	}

	/**
	 * Titel met het pad eronder en de acties Bekijken en Nu opnieuw proberen.
	 *
	 * @param array{url:string,title:string} $item Pagina.
	 */
	protected function column_title( $item ): string {
		$retry   = '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="ww-cache-retry">'
			. '<input type="hidden" name="action" value="ww_page_cache_preload_retry">'
			. '<input type="hidden" name="url" value="' . esc_attr( $item['url'] ) . '">'
			. _ww_page_cache_nonce_input( 'ww_page_cache_preload_retry' )
			. '<button type="submit" class="button-link">' . esc_html__( 'Nu opnieuw proberen', 'webwerckt-base' ) . '</button>'
			. '</form>';
		$actions = array(
			'view'  => '<a href="' . esc_url( $item['url'] ) . '" target="_blank" rel="noopener">' . esc_html__( 'Bekijken', 'webwerckt-base' ) . '</a>',
			'retry' => $retry,
		);
		$path    = (string) wp_parse_url( $item['url'], PHP_URL_PATH );
		return '<strong><a href="' . esc_url( $item['url'] ) . '" target="_blank" rel="noopener">' . esc_html( $item['title'] ) . '</a></strong><br><span class="description">' . esc_html( '' !== $path ? $path : $item['url'] ) . '</span>' . $this->row_actions( $actions );
	}

	/**
	 * Een label met een zin eronder.
	 *
	 * @param array{code:int} $item Pagina.
	 */
	protected function column_reason( $item ): string {
		$reason = _ww_page_cache_skip_reason( $item['code'] );
		switch ( $reason ) {
			case 'redirect':
				$label    = __( 'Verwijst door', 'webwerckt-base' );
				$sentence = __( 'Deze pagina stuurt bezoekers naar een andere pagina. Daar valt niets te bewaren.', 'webwerckt-base' );
				break;
			case 'missing':
				$label    = __( 'Bestaat niet meer', 'webwerckt-base' );
				$sentence = __( 'De pagina geeft "niet gevonden". Staat hij nog in een menu of link?', 'webwerckt-base' );
				break;
			default:
				$label    = __( 'Even niet gelukt', 'webwerckt-base' );
				$sentence = __( 'De pagina kwam net niet in de cache, waarschijnlijk omdat hij op dat moment werd aangepast.', 'webwerckt-base' );
		}
		return '<span class="ww-cache-reason ww-cache-reason--' . esc_attr( $reason ) . '">' . esc_html( $label ) . '</span><small>' . esc_html( $sentence ) . '</small>';
	}

	/**
	 * Wanneer het opwarmen de pagina weer probeert.
	 *
	 * @param array{until:int} $item Pagina.
	 */
	protected function column_until( $item ): string {
		return esc_html(
			sprintf(
				/* translators: %s: tijdsduur, zoals 5 minuten. */
				__( 'over %s', 'webwerckt-base' ),
				human_time_diff( time(), $item['until'] )
			)
		);
	}
}
