<?php
/**
 * Paginacache zonder PHP (beslissing 0029): rewrite-regels in een eigen blok in .htaccess, vóór de regels van
 * WordPress. Apache of LiteSpeed kijkt dan zelf of er een bewaarde index.html is en stuurt die als statisch bestand;
 * PHP en de database komen er niet aan te pas. Wat de regels niet kunnen, doet de rest van de cache:
 *
 * - Verlopen: de opruiming (elk uur, via een echte cron) haalt verlopen pagina's weg.
 * - Legen: verwijdert de bestanden echt, eerst de HTML (inc/page-cache.php).
 * - Headers: een pagina met andere headers dan Content-Type heet page.html en gaat altijd via PHP.
 * - Een pad zonder slash aan het eind, marketingparameters en een host met poort: via de mu-plugin, zoals voorheen.
 *
 * Alleen aan als de cache aan staat, de server .htaccess leest en WP-Cron uit staat (DISABLE_WP_CRON, met een echte
 * cron in Plesk): een treffer start geen PHP, dus anders draait WP-Cron alleen nog bij missers.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Naam van het blok in .htaccess. Bewust niet 'webwerckt-base-…': WordPress zoekt markers met str_contains(), en dan
// zou het blok van beslissing 0022 dit blok overschrijven.
const WW_PAGE_CACHE_HTACCESS_MARKER = 'ww-page-cache';

/**
 * Waarom de server bewaarde pagina's niet zonder PHP stuurt, of '' als niets dat tegenhoudt.
 *
 * @return string 'cache' (de paginacache staat uit), 'server' (geen .htaccess), 'cron' (geen DISABLE_WP_CRON),
 *                'filter' (ww_page_cache_static) of 'path' (de cachemap past niet in een regel).
 */
function _ww_page_cache_static_reason(): string {
	if ( '' !== _ww_page_cache_status() ) {
		return 'cache';
	}
	if ( ! _ww_htaccess_supported() ) {
		return 'server';
	}
	if ( ! ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) ) {
		return 'cron';
	}
	/**
	 * Zet het serveren zonder PHP (regels in .htaccess) aan of uit. Uit: de mu-plugin serveert de bewaarde pagina's,
	 * zoals zonder .htaccess.
	 *
	 * @param bool $enabled Standaard true.
	 */
	if ( ! apply_filters( 'ww_page_cache_static', true ) ) {
		return 'filter';
	}
	if ( array() === _ww_page_cache_static_site_rules() ) {
		return 'path';
	}
	return '';
}

/**
 * De regels voor deze site, of een lege lijst als de cachemap of de hosts niet in een regel passen.
 *
 * @return string[]
 */
function _ww_page_cache_static_site_rules(): array {
	$cookies = WW_PAGE_CACHE_SKIP_COOKIES;
	if ( defined( 'LOGGED_IN_COOKIE' ) && ! str_starts_with( (string) LOGGED_IN_COOKIE, 'wordpress_logged_in_' ) ) {
		$cookies[] = (string) LOGGED_IN_COOKIE;
	}
	return _ww_page_cache_static_rules(
		_ww_page_cache_hosts(),
		'https' === wp_parse_url( (string) get_option( 'home' ), PHP_URL_SCHEME ),
		_ww_page_cache_dir(),
		(string) wp_parse_url( content_url( 'cache/ww-pages' ), PHP_URL_PATH ),
		$cookies
	);
}

/**
 * De rewrite-regels. Dezelfde voorwaarden als de mu-plugin (_ww_page_cache_request_ok(), _ww_page_cache_current()):
 * GET of HEAD, geen query-string, het schema van de site, een eigen host, geen cookie van een ingelogde bezoeker. Plus
 * een slash aan het eind: alleen daar staat een index.html (_ww_page_cache_html_name()). Los van WordPress, zodat het
 * te testen is.
 *
 * @param string[] $hosts   Hosts van de site; een host met poort slaat de regel over (de sleutel heeft daar een _).
 * @param bool     $https   Of de site op https staat.
 * @param string   $dir     Pad van de cachemap op de schijf.
 * @param string   $url     Pad van de cachemap in de URL.
 * @param string[] $cookies Voorvoegsels van cookies die de cache overslaan.
 * @return string[] Leeg als de map of de URL tekens heeft die niet veilig in een regel passen, of er geen host is.
 */
function _ww_page_cache_static_rules( array $hosts, bool $https, string $dir, string $url, array $cookies ): array {
	$dir   = rtrim( str_replace( '\\', '/', $dir ), '/' );
	$url   = rtrim( $url, '/' );
	$hosts = array_values( array_filter( $hosts, static fn( string $host ): bool => (bool) preg_match( '/^[a-z0-9]([a-z0-9.-]*[a-z0-9])?$/', $host ) ) );
	if ( array() === $hosts || ! preg_match( '#^[A-Za-z0-9/_.:~-]+$#', $dir ) || ! preg_match( '#^/[A-Za-z0-9/_.~-]+$#', $url ) ) {
		return array();
	}
	$cookies = array_unique( array_filter( $cookies, static fn( string $cookie ): bool => (bool) preg_match( '/^[A-Za-z0-9_-]+$/', $cookie ) ) );
	$file    = '%{HTTP_HOST}%{REQUEST_URI}' . WW_PAGE_CACHE_STATIC_FILE;
	$rules   = array(
		'<IfModule mod_rewrite.c>',
		'RewriteEngine On',
		'RewriteCond %{REQUEST_METHOD} ^(GET|HEAD)$',
		'RewriteCond %{QUERY_STRING} ^$',
		'RewriteCond %{REQUEST_URI} /$',
		$https ? 'RewriteCond %{HTTPS} =on' : 'RewriteCond %{HTTPS} !=on',
		'RewriteCond %{HTTP_HOST} ^(' . implode( '|', array_map( static fn( string $host ): string => str_replace( '.', '\.', $host ), $hosts ) ) . ')$',
	);
	if ( array() !== $cookies ) {
		$rules[] = 'RewriteCond %{HTTP_COOKIE} !(' . implode( '|', array_map( static fn( string $cookie ): string => str_replace( '-', '\-', $cookie ), $cookies ) ) . ')';
	}
	$rules[] = 'RewriteCond ' . $dir . '/' . $file . ' -f';
	$rules[] = 'RewriteRule ^ ' . $url . '/' . $file . ' [L]';
	$rules[] = '</IfModule>';
	return $rules;
}

/**
 * De inhoud van .htaccess met dit blok op zijn plek: vóór `# BEGIN WordPress` (anders stuurt de regel van WordPress
 * het verzoek al naar index.php), of bovenaan als dat blok er niet is. Een blok op een andere plek gaat weg. Zonder
 * regels verdwijnt het blok helemaal.
 *
 * @param string[] $rules Regels.
 */
function _ww_htaccess_with_block( string $contents, string $marker, array $rules ): string {
	$begin = '# BEGIN ' . $marker;
	$end   = '# END ' . $marker;
	$rest  = (string) preg_replace( '/^' . preg_quote( $begin, '/' ) . '\h*\R.*?^' . preg_quote( $end, '/' ) . '\h*(\R|$)(\h*\R)?/ms', '', $contents );
	if ( array() === $rules ) {
		return $rest;
	}
	$block = $begin . "\n" . implode( "\n", $rules ) . "\n" . $end . "\n";
	if ( preg_match( '/^# BEGIN WordPress\h*$/m', $rest, $match, PREG_OFFSET_CAPTURE ) ) {
		return substr( $rest, 0, $match[0][1] ) . $block . "\n" . substr( $rest, $match[0][1] );
	}
	return $block . ( '' === $rest ? '' : "\n" . $rest );
}

/**
 * Zet het blok op zijn plek in .htaccess, alleen als het afwijkt. Buiten het blok verandert niets.
 *
 * @param string[] $rules Regels; leeg haalt het blok weg.
 * @return bool Of het blok nu klopt.
 */
function _ww_htaccess_put_block( string $file, string $marker, array $rules ): bool {
	$contents = is_file( $file ) ? (string) file_get_contents( $file ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- lokaal bestand.
	$wanted   = _ww_htaccess_with_block( $contents, $marker, $rules );
	if ( $wanted === $contents ) {
		return true;
	}
	if ( is_file( $file ) ? ! wp_is_writable( $file ) : ! wp_is_writable( dirname( $file ) ) ) {
		return false;
	}
	return false !== file_put_contents( $file, $wanted, LOCK_EX ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- zoals insert_with_markers().
}

/**
 * De regels met uitleg, zoals ze in het blok staan.
 *
 * @return string[]
 */
function _ww_page_cache_static_block(): array {
	if ( '' !== _ww_page_cache_static_reason() ) {
		return array();
	}
	return array_merge(
		array( '# Webwerckt Base: bewaarde pagina\'s zonder PHP sturen (beslissing 0029). Het thema schrijft dit blok zelf.' ),
		_ww_page_cache_static_site_rules()
	);
}

/**
 * Zorgt dat het blok in .htaccess klopt: de regels als de server zonder PHP mag serveren, anders geen blok.
 *
 * @param string $file Pad van .htaccess; leeg is die van de site.
 * @return string De reden van _ww_page_cache_static_reason(), of 'unwritable' als het blok niet bijgewerkt kon worden.
 */
function _ww_page_cache_static_sync( string $file = '' ): string {
	if ( ! _ww_htaccess_supported() ) {
		return 'server';
	}
	$file   = '' !== $file ? $file : _ww_htaccess_path();
	$reason = _ww_page_cache_static_reason();
	return _ww_htaccess_put_block( $file, WW_PAGE_CACHE_HTACCESS_MARKER, _ww_page_cache_static_block() ) ? $reason : 'unwritable';
}

/**
 * Hoe het nu staat, zonder te schrijven: de reden, of 'unwritable' als het blok in .htaccess afwijkt (admin_init en
 * de cron werken het bij, dus wijkt het nog af, dan is .htaccess niet schrijfbaar).
 */
function _ww_page_cache_static_state(): string {
	$reason = _ww_page_cache_static_reason();
	if ( 'server' === $reason || ( 'cache' === $reason && ! _ww_htaccess_supported() ) ) {
		return $reason;
	}
	$file     = _ww_htaccess_path();
	$contents = is_file( $file ) ? (string) file_get_contents( $file ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- lokaal bestand.
	return _ww_htaccess_with_block( $contents, WW_PAGE_CACHE_HTACCESS_MARKER, _ww_page_cache_static_block() ) === $contents ? $reason : 'unwritable';
}

/**
 * Werkt het blok bij: na het activeren van het thema, elk uur via de cron (ook na een Duplicator-installatie of als
 * de cache uitgaat met WW_PAGE_CACHE) en bij een adminbezoek van een beheerder. Na _ww_page_cache_admin_sync(), dat
 * een cache in een oude indeling eerst leegt.
 */
function _ww_page_cache_static_check(): void {
	if ( is_admin() && ! wp_doing_cron() && ( ! current_user_can( 'manage_options' ) || wp_doing_ajax() ) ) {
		return;
	}
	_ww_page_cache_format_check();
	_ww_page_cache_schedule();
	_ww_page_cache_static_sync();
}
add_action( 'admin_init', '_ww_page_cache_static_check', 21 );
add_action( 'after_switch_theme', '_ww_page_cache_static_check' );
add_action( WW_PAGE_CACHE_CRON_HOOK, '_ww_page_cache_static_check', 20 );

/**
 * Ander thema actief: het blok weg. Lukt dat niet, dan stuurt de server de pagina's niet meer zodra switch_theme de
 * cachemap heeft geleegd (_ww_page_cache_purge_all()).
 */
function _ww_page_cache_static_remove(): void {
	if ( _ww_htaccess_supported() ) {
		_ww_htaccess_put_block( _ww_htaccess_path(), WW_PAGE_CACHE_HTACCESS_MARKER, array() );
	}
}
add_action( 'switch_theme', '_ww_page_cache_static_remove' );

/**
 * Uitleg bij de stand van _ww_page_cache_static_state(), voor het menu Pagina cache. Leeg bij 'cache': dan meldt het
 * menu al dat de cache uit staat.
 */
function _ww_page_cache_static_text( string $state ): string {
	switch ( $state ) {
		case '':
			return __( 'De server stuurt bewaarde pagina\'s zonder PHP, met de regels in .htaccess. Een URL met parameters (utm_source en dergelijke) of zonder slash aan het eind, en een pagina met eigen headers, gaan via PHP.', 'webwerckt-base' );
		case 'server':
			return __( 'De server leest geen .htaccess (nginx): bewaarde pagina\'s gaan via PHP.', 'webwerckt-base' );
		case 'cron':
			return __( 'Bewaarde pagina\'s gaan via PHP. Zonder PHP sturen vraagt een echte cron (een geplande taak in Plesk die wp-cron.php elke paar minuten start) en define( \'DISABLE_WP_CRON\', true ); in wp-config.php: een pagina zonder PHP start WP-Cron niet.', 'webwerckt-base' );
		case 'filter':
			return __( 'Zonder PHP sturen staat uit met het filter ww_page_cache_static: bewaarde pagina\'s gaan via PHP.', 'webwerckt-base' );
		case 'path':
			return __( 'Het pad van de cachemap of de host van de site past niet in een regel van .htaccess: bewaarde pagina\'s gaan via PHP.', 'webwerckt-base' );
		case 'unwritable':
			return __( '.htaccess is niet schrijfbaar: het blok ww-page-cache klopt niet. Bewaarde pagina\'s gaan via PHP, of de server stuurt ze met oude regels.', 'webwerckt-base' );
		default:
			return '';
	}
}
