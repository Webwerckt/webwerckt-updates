<?php
/**
 * Afbeeldingen: het hoofdmenu Afbeeldingen, alleen voor beheerders, het opslaan van de instellingen en de acties via
 * admin-post.php die terugsturen naar hun onderdeel, en het scherm zelf. De onderdelen staan in inc/images-admin-sections.php.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const WW_IMAGES_ADMIN_PAGE = 'ww-images';
const WW_IMAGES_ADMIN_CAP  = 'manage_options';

/**
 * Voegt het hoofdmenu Afbeeldingen toe.
 */
function _ww_images_admin_menu(): void {
	add_menu_page(
		__( 'Afbeeldingen', 'webwerckt-base' ),
		__( 'Afbeeldingen', 'webwerckt-base' ),
		WW_IMAGES_ADMIN_CAP,
		WW_IMAGES_ADMIN_PAGE,
		'_ww_images_admin_render',
		'dashicons-images-alt2',
		81
	);
}
add_action( 'admin_menu', '_ww_images_admin_menu' );

/**
 * Laadt de stijl, alleen op dit scherm.
 *
 * @param string $hook Admin-scherm.
 */
function _ww_images_admin_assets( string $hook ): void {
	if ( 'toplevel_page_' . WW_IMAGES_ADMIN_PAGE !== $hook || ! current_user_can( WW_IMAGES_ADMIN_CAP ) ) {
		return;
	}
	wp_enqueue_style( 'ww-images-admin', _ww_asset_url( 'css/images-admin.css' ), array(), WW_BASE_VERSION );
}
add_action( 'admin_enqueue_scripts', '_ww_images_admin_assets' );

/**
 * URL van de pagina Afbeeldingen, eventueel met extra queryvariabelen. Overzicht is het begin: daar geen tab.
 *
 * @param array<string,string> $args Queryvariabelen.
 */
function _ww_images_admin_url( array $args = array() ): string {
	if ( 'overview' === ( $args['tab'] ?? '' ) ) {
		unset( $args['tab'] );
	}
	return add_query_arg( array( 'page' => WW_IMAGES_ADMIN_PAGE ) + $args, admin_url( 'admin.php' ) );
}

/**
 * Toont de pagina Afbeeldingen: het zijpaneel met de onderdelen, dan de meldingen en de inhoud van het gekozen
 * onderdeel (inc/images-admin-sections.php).
 */
function _ww_images_admin_render(): void {
	if ( ! current_user_can( WW_IMAGES_ADMIN_CAP ) ) {
		return;
	}
	$tab    = _ww_images_admin_tab();
	$counts = _ww_images_admin_counts();
	$status = _ww_images_status_html( _ww_images_admin_status( $counts['queue'] ) );

	switch ( $tab ) {
		case 'queue':
			$body = _ww_images_render_queue();
			break;
		case 'problems':
			$body = _ww_images_render_problems();
			break;
		case 'settings':
			$body = _ww_images_render_settings( $counts );
			break;
		default:
			$body = _ww_images_render_overview( $counts );
	}

	// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- de onderdelen geven geëscapete HTML terug.
	echo '<div class="wrap ww-images"><div class="ww-images-layout">';
	echo '<nav class="ww-images-panel" aria-label="' . esc_attr__( 'Onderdelen van Afbeeldingen', 'webwerckt-base' ) . '">';
	echo '<p class="ww-images-panel__title">' . esc_html__( 'Afbeeldingen', 'webwerckt-base' ) . '</p>';
	echo '<p class="ww-images-panel__status">' . $status . '</p>';
	echo _ww_images_render_nav( $tab, $counts, 'panel' );
	echo _ww_images_render_panel_card( $counts );
	echo '<p class="ww-images-panel__foot"><span class="dashicons dashicons-info-outline" aria-hidden="true"></span>' . esc_html__( 'Het geüploade bestand blijft altijd staan. AVIF en WebP komen ernaast; de browser kiest zelf het kleinste formaat dat hij kent.', 'webwerckt-base' ) . '</p>';
	echo '</nav>';

	echo '<div class="ww-images-main">';
	echo '<div class="ww-images-title"><h1>' . esc_html( _ww_images_admin_title( $tab ) ) . '</h1>' . _ww_images_title_action( $tab, $counts ) . '</div><hr class="wp-header-end">';
	echo '<nav class="ww-images-pickers" aria-label="' . esc_attr__( 'Onderdelen van Afbeeldingen (menu)', 'webwerckt-base' ) . '">' . _ww_images_render_nav( $tab, $counts, 'menu' ) . '</nav>';
	echo '<p class="ww-images-status-line">' . $status . '</p>';
	echo _ww_images_admin_notices( $tab, $counts );
	echo $body;
	echo '</div>';
	echo '</div></div>';
	// phpcs:enable
}

/**
 * Registreert de instellingen, zoals options.php dat vraagt.
 */
function _ww_images_register_settings(): void {
	register_setting(
		'ww_images',
		WW_IMAGES_SETTINGS,
		array(
			'sanitize_callback' => '_ww_images_save_settings',
			'show_in_rest'      => false,
		)
	);
}
add_action( 'admin_init', '_ww_images_register_settings' );

/**
 * Het filter dat een instelling op slot zet, per veld.
 *
 * @return array<string,string>
 */
function _ww_images_locked_filters(): array {
	return array(
		'enabled' => 'ww_image_variants',
		'formats' => 'ww_image_formats',
		'quality' => 'ww_image_quality',
		'budget'  => 'ww_image_budget',
	);
}

/**
 * Bewaart de instellingen. Het formulier post de hele optie: een vinkje dat uit staat, ontbreekt. Een veld dat een
 * filter op slot zet, houdt de bewaarde waarde.
 *
 * @param mixed $value Gepost.
 * @return array{enabled:bool,formats:string[],quality:array{avif:int,webp:int},budget:int}
 */
function _ww_images_save_settings( $value ): array {
	$value  = is_array( $value ) ? $value : array();
	$stored = get_option( WW_IMAGES_SETTINGS, array() );
	$stored = is_array( $stored ) ? $stored : array();
	// Alleen het formulier op het scherm kent vinkjes en sloten; een andere schrijfactie (zoals het verwijderen) wordt alleen opgeschoond.
	if ( ! isset( $_POST['option_page'] ) || 'ww_images' !== $_POST['option_page'] ) { // phpcs:ignore WordPress.Security.NonceVerification -- options.php controleert de nonce.
		return _ww_images_sanitize_settings( $value, $stored );
	}
	$before = _ww_images_settings();
	$unset  = array(
		'enabled' => false,
		'formats' => array(),
	);
	foreach ( _ww_images_locked_filters() as $field => $filter ) {
		if ( _ww_images_locked( $filter ) ) {
			unset( $value[ $field ] );
		} elseif ( isset( $unset[ $field ] ) && ! array_key_exists( $field, $value ) ) {
			$value[ $field ] = $unset[ $field ];
		}
	}
	$saved = _ww_images_sanitize_settings( $value, $stored );

	if ( $saved['quality'] !== $before['quality'] && get_current_user_id() > 0 ) {
		set_transient( 'ww_images_quality_changed_' . get_current_user_id(), '1', 5 * MINUTE_IN_SECONDS );
	}
	return $saved;
}

/**
 * Is de kwaliteit net bewaard? Leest de melding en haalt hem weg: de melding komt één keer.
 */
function _ww_images_quality_changed(): bool {
	$key     = 'ww_images_quality_changed_' . get_current_user_id();
	$changed = false !== get_transient( $key );
	if ( $changed ) {
		delete_transient( $key );
	}
	return $changed;
}

/**
 * Stopt als de gebruiker dit niet mag, en controleert de nonce.
 *
 * @param string $nonce Naam van de nonce-actie.
 */
function _ww_images_admin_guard( string $nonce ): void {
	if ( ! current_user_can( WW_IMAGES_ADMIN_CAP ) ) {
		wp_die( esc_html__( 'Je hebt geen rechten om de afbeeldingen te beheren.', 'webwerckt-base' ), 403 );
	}
	check_admin_referer( $nonce );
}

/**
 * Stuurt terug naar een onderdeel met een melding.
 *
 * @param string $tab  Onderdeel.
 * @param string $done Waarde van ww_done.
 */
function _ww_images_admin_back( string $tab, string $done ): void {
	wp_safe_redirect(
		_ww_images_admin_url(
			array(
				'tab'     => $tab,
				'ww_done' => $done,
			)
		)
	);
	exit;
}

/**
 * Maakt nu één ronde versies (knop op de pagina, via admin-post.php).
 */
function _ww_images_admin_run_now(): void {
	_ww_images_admin_guard( 'ww_images_run_now' );
	$before = _ww_images_lock_value();
	$made   = _ww_images_run();
	// Bleef het slot bij een andere run en gebeurde er niets, dan loopt er al een ronde.
	$busy = null !== $before && 0 === $made && _ww_images_lock_value() === $before;
	_ww_images_admin_back( 'queue', $busy ? 'busy' : 'run:' . $made );
}
add_action( 'admin_post_ww_images_run_now', '_ww_images_admin_run_now' );

/**
 * Probeert een mislukte of overgeslagen afbeelding opnieuw (knop in de lijst, via admin-post.php).
 */
function _ww_images_admin_retry(): void {
	$id = isset( $_GET['attachment_id'] ) ? absint( wp_unslash( $_GET['attachment_id'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification -- gecontroleerd door _ww_images_admin_guard().
	_ww_images_admin_guard( 'ww_images_retry_' . $id );
	if ( $id > 0 && 'attachment' === get_post_type( $id ) ) {
		$variants = get_post_meta( $id, WW_IMAGES_META_VARIANTS, true );
		if ( is_array( $variants ) ) {
			$variants = _ww_images_reset( $variants, static fn( string $file, string $format, $status ): bool => 'failed' === $status || _ww_images_is_skip( $status ) || ( is_int( $status ) && $status > 0 ) );
			update_post_meta( $id, WW_IMAGES_META_VARIANTS, $variants );
		}
		_ww_images_queue_add( $id );
	}
	_ww_images_admin_back( 'problems', 'retry:' . $id );
}
add_action( 'admin_post_ww_images_retry', '_ww_images_admin_retry' );

/**
 * Maakt alle versies opnieuw (na een andere kwaliteit; knop op de pagina, via admin-post.php).
 */
function _ww_images_admin_redo(): void {
	_ww_images_admin_guard( 'ww_images_redo' );
	if ( _ww_images_wiping() ) {
		_ww_images_admin_back( 'settings', 'wiping' );
	}
	_ww_images_redo();
	_ww_images_admin_back( 'settings', 'redo' );
}
add_action( 'admin_post_ww_images_redo', '_ww_images_admin_redo' );

/**
 * Of Versies verwijderen niet kan: een filter houdt de optimaliseerder aan, dus de cron zou alles meteen opnieuw maken.
 */
function _ww_images_wipe_locked(): bool {
	return _ww_images_locked( 'ww_image_variants' ) && _ww_images_enabled();
}

/**
 * Verwijdert alle versies en zet de optimaliseerder uit (knop op de pagina, via admin-post.php). Loopt het verwijderen
 * al, dan verandert er niets (de cursor blijft staan); houdt een filter de optimaliseerder aan, dan weigert het.
 */
function _ww_images_admin_wipe(): void {
	_ww_images_admin_guard( 'ww_images_wipe' );
	if ( _ww_images_wiping() ) {
		_ww_images_admin_back( 'settings', 'wipe' );
	}
	if ( _ww_images_wipe_locked() ) {
		_ww_images_admin_back( 'settings', 'wipe_locked' );
	}
	_ww_images_wipe_start();
	_ww_images_admin_back( 'settings', 'wipe' );
}
add_action( 'admin_post_ww_images_wipe', '_ww_images_admin_wipe' );

const WW_IMAGES_PER_PAGE = 50;

/**
 * Status van een afbeelding in de wachtrij: nog niet bekeken, bezig of een mislukte poging.
 *
 * @param array<string,array<string,string|int>> $variants Status per bestand en formaat.
 * @param int                                    $files    Aantal bestanden van de afbeelding.
 * @return array{label:string,class:string,detail:string}
 */
function _ww_images_queue_status( array $variants, int $files ): array {
	if ( array() === $variants ) {
		return array(
			'label'  => __( 'Nog niet bekeken', 'webwerckt-base' ),
			'class'  => 'new',
			'detail' => '',
		);
	}
	$tries = 0;
	$ready = 0;
	foreach ( $variants as $formats ) {
		$open  = array_filter( $formats, 'is_int' );
		$tries = max( $tries, array() === $open ? 0 : max( $open ) );
		if ( array() === $open ) {
			++$ready;
		}
	}
	if ( $tries > 0 ) {
		return array(
			/* translators: %d: aantal mislukte pogingen. */
			'label'  => sprintf( _n( '%d poging mislukt', '%d pogingen mislukt', $tries, 'webwerckt-base' ), $tries ),
			'class'  => 'retry',
			/* translators: %d: aantal keer overgeslagen voor het opgegeven wordt. */
			'detail' => sprintf( __( 'volgende run opnieuw, na %d keer overgeslagen', 'webwerckt-base' ), WW_IMAGES_MAX_TRIES ),
		);
	}
	if ( $ready >= max( $files, count( $variants ) ) ) {
		// Alles klaar volgens de status, maar de afbeelding wacht: na Alles opnieuw maken (of nieuwe metadata).
		return array(
			'label'  => __( 'Wordt opnieuw gemaakt', 'webwerckt-base' ),
			'class'  => 'busy',
			'detail' => '',
		);
	}
	return array(
		'label'  => __( 'Bezig', 'webwerckt-base' ),
		'class'  => 'busy',
		/* translators: 1: aantal klaar, 2: aantal bestanden. */
		'detail' => sprintf( __( '%1$s van %2$s bestanden klaar', 'webwerckt-base' ), number_format_i18n( $ready ), number_format_i18n( max( $files, count( $variants ) ) ) ),
	);
}

/**
 * Waarom een afbeelding bij Overgeslagen en mislukt staat: één regel per soort reden, met uitleg in gewone taal.
 *
 * @param int $id Bijlage-ID.
 * @return list<array{status:string,label:string,kind:string,text:string}>
 */
function _ww_images_problem_reasons( int $id ): array {
	$variants = _ww_images_variants( $id );
	$total    = count( $variants );
	$files    = array();
	foreach ( $variants as $file => $formats ) {
		foreach ( $formats as $status ) {
			if ( 'failed' === $status || _ww_images_is_skip( $status ) ) {
				// Een onbekende reden (skip:xyz) krijgt de gewone tekst van Overgeslagen.
				$key                    = in_array( $status, array( 'skip:anim', 'skip:big', 'skip:exif', 'skip:file', 'failed' ), true ) ? (string) $status : 'skip';
				$files[ $key ][ $file ] = true;
			}
		}
	}

	$reasons = array();
	foreach ( array( 'skip:anim', 'skip:big', 'skip:exif', 'skip:file', 'skip', 'failed' ) as $status ) {
		if ( ! isset( $files[ $status ] ) ) {
			continue;
		}
		switch ( $status ) {
			case 'skip:anim':
				$label = __( 'Geanimeerd', 'webwerckt-base' );
				$text  = __( 'Bezoekers krijgen het origineel.', 'webwerckt-base' );
				break;
			case 'skip:big':
				$label = __( 'Te groot', 'webwerckt-base' );
				$size  = explode( 'x', (string) get_post_meta( $id, WW_IMAGES_META_SKIP_SIZE, true ) );
				if ( 2 === count( $size ) && (int) $size[0] > 0 && (int) $size[1] > 0 ) {
					$text = sprintf(
						/* translators: 1: breedte, 2: hoogte, 3: megapixels. */
						__( '%1$s × %2$s pixels (%3$s megapixel). Upload een kleinere versie.', 'webwerckt-base' ),
						number_format_i18n( (int) $size[0] ),
						number_format_i18n( (int) $size[1] ),
						number_format_i18n( (int) $size[0] * (int) $size[1] / 1000000, 1 )
					);
				} else {
					$text = __( 'Deze afbeelding heeft te veel pixels. Upload een kleinere versie.', 'webwerckt-base' );
				}
				break;
			case 'skip:exif':
				$label = __( 'Gedraaid volgens EXIF', 'webwerckt-base' );
				$text  = __( 'Draai hem in Media → Bewerken en sla op.', 'webwerckt-base' );
				break;
			case 'skip:file':
				$label = __( 'Bestand niet gevonden', 'webwerckt-base' );
				$text  = __( 'Het bestand staat niet op de server.', 'webwerckt-base' );
				break;
			case 'skip':
				$label = __( 'Overgeslagen', 'webwerckt-base' );
				$text  = __( 'Bezoekers krijgen het origineel.', 'webwerckt-base' );
				break;
			default:
				$label = __( 'Mislukt', 'webwerckt-base' );
				$text  = sprintf(
					/* translators: 1: aantal pogingen, 2: aantal bestanden dat mislukte, 3: aantal bestanden. */
					__( 'Mislukt na %1$d pogingen, bij %2$s van %3$s bestanden.', 'webwerckt-base' ),
					WW_IMAGES_MAX_TRIES,
					number_format_i18n( count( $files[ $status ] ) ),
					number_format_i18n( $total )
				);
		}
		$reasons[] = array(
			'status' => $status,
			'label'  => $label,
			'kind'   => 'failed' === $status ? 'failed' : 'skip',
			'text'   => $text,
		);
	}
	return $reasons;
}

/**
 * Afbeeldingen met een overgeslagen of mislukt bestand, per soort. De database filtert voor (alleen afbeeldingen die
 * klaar of mislukt zijn en het woord in hun versies hebben); PHP kijkt daarna naar de echte statussen.
 *
 * De uitkomst blijft dit verzoek bewaard (een niet-blijvende cachegroep): het paneel en de tabel vragen er allebei om.
 *
 * @return array{skip:int[],failed:int[]} ID's, nieuwste eerst.
 */
function _ww_images_problem_buckets(): array {
	$cached = wp_cache_get( 'problem_buckets', 'ww_images' );
	if ( is_array( $cached ) ) {
		return $cached;
	}
	$ids = ( new WP_Query(
		array(
			'post_type'        => 'attachment',
			'post_status'      => 'inherit',
			'post_mime_type'   => _ww_images_mime_types(),
			'fields'           => 'ids',
			'posts_per_page'   => -1,
			'orderby'          => 'ID',
			'order'            => 'DESC',
			'no_found_rows'    => true,
			'suppress_filters' => true,
			'meta_query'       => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- alleen op het scherm Afbeeldingen; de LIKE houdt de selectie klein.
				'relation' => 'AND',
				array(
					'key'     => WW_IMAGES_META_STATE,
					'value'   => array( 'done', 'failed' ),
					'compare' => 'IN',
				),
				array(
					'relation' => 'OR',
					array(
						'key'     => WW_IMAGES_META_VARIANTS,
						'value'   => 'skip',
						'compare' => 'LIKE',
					),
					array(
						'key'     => WW_IMAGES_META_VARIANTS,
						'value'   => 'failed',
						'compare' => 'LIKE',
					),
				),
			),
		)
	) )->posts;

	$buckets = array(
		'skip'   => array(),
		'failed' => array(),
	);
	foreach ( array_chunk( array_map( 'intval', $ids ), 200 ) as $chunk ) {
		update_meta_cache( 'post', $chunk );
		foreach ( $chunk as $id ) {
			foreach ( _ww_images_problem_reasons( $id ) as $reason ) {
				$buckets[ $reason['kind'] ][ $id ] = $id;
			}
		}
	}
	$buckets = array(
		'skip'   => array_values( $buckets['skip'] ),
		'failed' => array_values( $buckets['failed'] ),
	);
	wp_cache_set( 'problem_buckets', $buckets, 'ww_images' );
	return $buckets;
}
wp_cache_add_non_persistent_groups( array( 'ww_images' ) );

/**
 * Eén pagina met afbeeldingen die bij Overgeslagen en mislukt horen.
 *
 * @param string                              $view    'all', 'skip' of 'failed'.
 * @param int                                 $limit   Aantal per pagina.
 * @param int                                 $offset  Hoeveel er worden overgeslagen.
 * @param array{skip:int[],failed:int[]}|null $buckets Al opgehaalde ID's, om niet opnieuw te zoeken.
 * @return array{ids:int[],total:int}
 */
function _ww_images_problem_ids( string $view, int $limit, int $offset, ?array $buckets = null ): array {
	$buckets = $buckets ?? _ww_images_problem_buckets();
	if ( 'skip' === $view || 'failed' === $view ) {
		$ids = $buckets[ $view ];
	} else {
		$ids = array_unique( array_merge( $buckets['skip'], $buckets['failed'] ) );
		rsort( $ids );
	}
	return array(
		'ids'   => array_slice( array_values( $ids ), $offset, $limit ),
		'total' => count( $ids ),
	);
}

/**
 * De cel Afbeelding in beide lijsten: miniatuur, titel en bestandsnaam, met de rijacties eronder.
 *
 * @param int    $id      Bijlage-ID.
 * @param string $actions Rijacties (row_actions()).
 */
function _ww_images_list_image_cell( int $id, string $actions ): string {
	$thumb = wp_get_attachment_image( $id, array( 48, 48 ), true, array( 'class' => 'ww-images-thumb' ) );
	$title = get_the_title( $id );
	$file  = wp_basename( (string) get_post_meta( $id, '_wp_attached_file', true ) );
	return '<div class="ww-images-cell">' . $thumb . '<div><strong>' . esc_html( '' !== $title ? $title : $file ) . '</strong><br><span class="description">' . esc_html( $file ) . '</span></div></div>' . $actions;
}

/**
 * Bewerken en (tenzij $view_link uit staat) Bekijken, voor row_actions().
 *
 * @param int  $id        Bijlage-ID.
 * @param bool $view_link Of Bekijken erbij komt.
 * @return array<string,string>
 */
function _ww_images_list_row_actions( int $id, bool $view_link = true ): array {
	$actions = array();
	$edit    = get_edit_post_link( $id );
	if ( $edit ) {
		$actions['edit'] = '<a href="' . esc_url( $edit ) . '">' . esc_html__( 'Bewerken', 'webwerckt-base' ) . '</a>';
	}
	$url = $view_link ? wp_get_attachment_url( $id ) : '';
	if ( $url ) {
		$actions['view'] = '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html__( 'Bekijken', 'webwerckt-base' ) . '</a>';
	}
	return $actions;
}
