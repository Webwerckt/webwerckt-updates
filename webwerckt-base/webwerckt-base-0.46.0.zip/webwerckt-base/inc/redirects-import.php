<?php
/**
 * Redirects: CSV inlezen, importeren met een voorbeeld (dry run) en exporteren (beslissing 0031).
 *
 * De import slaat alles op via ww_redirect_save(), in de volgorde van het bestand. Het voorbeeld voorspelt per regel wat
 * er zou gebeuren zonder iets op te slaan. Ook de ability webwerckt/import-redirects gebruikt _ww_redirects_import().
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const WW_REDIRECTS_CSV_MAX_ROWS = 5000;

/**
 * Leest een CSV met kolommen bron, doel, status en type (de laatste twee zijn optioneel).
 *
 * Het scheidingsteken komt uit de eerste regel: een puntkomma daarin betekent puntkomma (Excel in het Nederlands),
 * anders komma. Een BOM, lege regels en een kopregel (eerste kolom begint niet met / of http) worden overgeslagen.
 * Een lege status is 301; een status die geen getal is wordt 0, zodat de validatie hem als fout meldt.
 *
 * Staat in de kopregel een kolom source of bron, dan gaan de kolommen op naam, zoals in de export van de plugin
 * Redirection (source, target of url, code, regex; overige kolommen tellen niet mee). Een regel met regex 1 krijgt
 * een fout, want reguliere expressies worden niet ondersteund. Zonder zulke kopregel gaat het op volgorde.
 *
 * @param string $csv Inhoud van het bestand (UTF-8).
 * @return list<array{line:int,source:string,target:string,status:int,match_type:string,error?:string}>|WP_Error Fout ww_redirects_csv_too_long bij meer dan 5000 regels.
 */
function _ww_redirects_parse_csv( string $csv ) {
	if ( str_starts_with( $csv, "\xEF\xBB\xBF" ) ) {
		$csv = substr( $csv, 3 );
	}

	$lines     = preg_split( '/\r\n|\r|\n/', $csv );
	$delimiter = null;
	$rows      = array();
	$first     = true;
	$columns   = array(
		'source' => 0,
		'target' => 1,
		'status' => 2,
		'type'   => 3,
		'regex'  => -1,
	);

	foreach ( (array) $lines as $index => $line ) {
		$line = (string) $line;
		if ( '' === trim( $line ) ) {
			continue;
		}
		if ( null === $delimiter ) {
			$delimiter = str_contains( $line, ';' ) ? ';' : ',';
		}
		$cols = array_map( 'trim', array_map( 'strval', str_getcsv( $line, $delimiter, '"', '' ) ) );

		if ( $first ) {
			$first = false;
			if ( ! str_starts_with( $cols[0], '/' ) && 0 === preg_match( '#^https?#i', $cols[0] ) ) {
				$names = array_map( 'strtolower', $cols );
				if ( in_array( 'source', $names, true ) || in_array( 'bron', $names, true ) ) {
					$columns = _ww_redirects_csv_columns( $names );
				}
				continue;
			}
		}

		$status_col = $cols[ $columns['status'] ] ?? '';
		$row        = array(
			'line'       => (int) $index + 1,
			'source'     => $cols[ $columns['source'] ] ?? '',
			'target'     => $cols[ $columns['target'] ] ?? '',
			'status'     => '' === $status_col ? 301 : ( ctype_digit( $status_col ) ? (int) $status_col : 0 ),
			'match_type' => 'prefix' === strtolower( $cols[ $columns['type'] ] ?? '' ) ? 'prefix' : 'exact',
		);
		if ( $columns['regex'] >= 0 && in_array( strtolower( $cols[ $columns['regex'] ] ?? '' ), array( '1', 'true', 'yes' ), true ) ) {
			$row['error'] = __( 'Reguliere expressies worden niet ondersteund.', 'webwerckt-base' );
		}
		$rows[] = $row;

		if ( count( $rows ) > WW_REDIRECTS_CSV_MAX_ROWS ) {
			return new WP_Error( 'ww_redirects_csv_too_long', __( 'Het bestand heeft meer dan 5000 regels: splits het in delen.', 'webwerckt-base' ) );
		}
	}

	return $rows;
}

/**
 * Welke kolom welk gegeven bevat, uit de kopregel (in kleine letters). Redirection noemt de statuscode code en gebruikt
 * status voor aan of uit; onze eigen kopregel heeft status voor de code. Het type telt alleen als het prefix is.
 *
 * @param string[] $names Kolomnamen.
 * @return array{source:int,target:int,status:int,type:int,regex:int} Index per gegeven, -1 als de kolom ontbreekt.
 */
function _ww_redirects_csv_columns( array $names ): array {
	$find = static function ( array $wanted ) use ( $names ): int {
		foreach ( $wanted as $name ) {
			$at = array_search( $name, $names, true );
			if ( false !== $at ) {
				return (int) $at;
			}
		}
		return -1;
	};
	return array(
		'source' => $find( array( 'source', 'bron' ) ),
		'target' => $find( array( 'target', 'doel', 'url' ) ),
		'status' => $find( array( 'code', 'status' ) ),
		'type'   => $find( array( 'type' ) ),
		'regex'  => $find( array( 'regex' ) ),
	);
}

/**
 * Importeert regels, of voorspelt in een dry run wat er zou gebeuren.
 *
 * Per regel is het resultaat new, update, unchanged (de bron bestaat al met hetzelfde doel, dezelfde status en hetzelfde
 * type) of error. Het voorbeeld gebruikt alleen de validatie van ww_redirect_save(): een kring binnen het bestand wordt
 * daar niet herkend, de echte import meldt hem wel als error. Een ongewijzigde regel wordt ook echt niet opnieuw opgeslagen.
 *
 * @param array<int,array<string,mixed>> $rules   Regels met source, target, status en match_type (met error is het een foutregel).
 * @param bool                           $dry_run Alleen voorspellen, niets opslaan.
 * @param string                         $origin  Herkomst die bij de regels wordt bewaard.
 * @return array{rows:list<array{source:string,result:string,message?:string}>,totals:array<string,int>}
 */
function _ww_redirects_import( array $rules, bool $dry_run, string $origin = 'import' ): array {
	$rows   = array();
	$totals = array(
		'new'       => 0,
		'update'    => 0,
		'unchanged' => 0,
		'error'     => 0,
	);
	$ready  = _ww_redirects_ready();
	$saved  = 0;

	// Eén keer de cache legen na afloop in plaats van per regel.
	_ww_redirect_purge_suspend( ! $dry_run );
	if ( ! $dry_run ) {
		// Intern: het activiteitenlog schrijft één regel voor de hele import in plaats van een per regel.
		do_action( '_ww_redirects_import_start' );
	}

	foreach ( $rules as $rule ) {
		$rule['origin'] = $origin;
		$row            = array(
			'source' => (string) ( $rule['source'] ?? '' ),
			'result' => 'error',
		);

		if ( ! empty( $rule['error'] ) ) {
			$valid = new WP_Error( 'ww_redirects_csv_row', _ww_data_to_string( $rule['error'] ) );
		} else {
			$valid = $ready ? _ww_redirect_validate( $rule ) : new WP_Error( 'ww_redirect_not_ready', __( 'De redirecttabellen zijn nog niet aangelegd.', 'webwerckt-base' ) );
		}
		if ( $valid instanceof WP_Error ) {
			$row['message'] = $valid->get_error_message();
		} else {
			$row['source'] = $valid['source'];
			$existing      = _ww_redirect_get_by_source( $valid['source'] );
			if ( null === $existing ) {
				$row['result'] = 'new';
			} elseif ( $existing->target === $valid['target'] && (int) $existing->status === $valid['status'] && $existing->match_type === $valid['match_type'] ) {
				$row['result'] = 'unchanged';
			} else {
				$row['result'] = 'update';
			}

			if ( ! $dry_run && 'unchanged' !== $row['result'] ) {
				$result = ww_redirect_save( $valid );
				if ( $result instanceof WP_Error ) {
					$row['result']  = 'error';
					$row['message'] = $result->get_error_message();
				} else {
					++$saved;
				}
			}
		}

		++$totals[ $row['result'] ];
		$rows[] = $row;
	}

	_ww_redirect_purge_suspend( false );
	if ( $saved > 0 ) {
		do_action( '_ww_purge_all' );
	}
	if ( ! $dry_run ) {
		/**
		 * Een import van redirects is klaar (niet bij een voorbeeld).
		 *
		 * @param int $count Aantal opgeslagen regels (nieuw of bijgewerkt, zonder ongewijzigde en fouten); kan 0 zijn.
		 */
		do_action( 'ww_redirects_imported', $saved );
	}

	return array(
		'rows'   => $rows,
		'totals' => $totals,
	);
}

/**
 * Alle regels als CSV met de kopregel bron,doel,status,type, in hetzelfde formaat als de import.
 */
function _ww_redirects_export_csv(): string {
	global $wpdb;
	$rules = _ww_redirects_ensure_ready() ? $wpdb->get_results( 'SELECT source, target, status, match_type FROM ' . _ww_redirects_table() . ' ORDER BY id' ) : array(); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_redirects_table().

	$handle = fopen( 'php://temp', 'w+' );
	if ( false === $handle ) {
		return '';
	}
	fputcsv( $handle, array( 'bron', 'doel', 'status', 'type' ), ',', '"', '' );
	foreach ( (array) $rules as $rule ) {
		fputcsv( $handle, array( $rule->source, $rule->target, $rule->status, $rule->match_type ), ',', '"', '' );
	}
	rewind( $handle );
	$csv = (string) stream_get_contents( $handle );
	fclose( $handle );
	return $csv;
}
