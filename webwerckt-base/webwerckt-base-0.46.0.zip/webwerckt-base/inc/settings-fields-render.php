<?php
/**
 * Het tekenen van de velden van de Site-instellingen: welke soorten het thema tekent, het invoerelement per soort,
 * de rijen (label, veld, omschrijving) en de groepen (vak met rijen, of de dagtabel van de openingstijden). De
 * invoer per veld, het verwerken van de POST en het script van de invoer (assets/js/field-inputs.js) zijn ook voor
 * het bewerkscherm.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tekent het thema dit soort veld? Tekstsoorten, een boolean, code, opgemaakte tekst (wysiwyg), datum en tijd, één of
 * meer afbeeldingen, een keuze uit een vaste lijst (één of meer) en een relatie met berichten of termen. Andere soorten
 * (een ander bestand dan een afbeelding, relaties met gebruikers, onbekende soorten) krijgen geen invoer en blijven bij
 * opslaan ongemoeid.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 */
function _ww_settings_field_supported( array $field ): bool {
	$type = _ww_data_to_string( $field['type'] ?? '' );
	if ( in_array( $type, array( 'text', 'paragraph', 'phone', 'email', 'website', 'number', 'boolean', 'code', 'wysiwyg', 'date', 'time', 'datetime' ), true ) ) {
		return true;
	}
	if ( 'file' === $type ) {
		return 'images' === ( $field['file_type'] ?? 'images' );
	}
	if ( 'pick' === $type ) {
		$object = _ww_data_to_string( $field['pick_object'] ?? '' );
		return in_array( $object, array( 'post_type', 'taxonomy', 'custom-simple' ), true );
	}
	return false;
}

/**
 * Het id van de editor van een wysiwyg: ww_field_{naam}, met alleen kleine letters, cijfers en underscores, want
 * wp_editor() verdraagt geen streepjes of haken.
 */
function _ww_settings_editor_id( string $name ): string {
	return 'ww_field_' . preg_replace( '/[^a-z0-9_]/', '_', strtolower( $name ) );
}

/**
 * Een opgeslagen datum of tijd zoals het invoerelement hem wil: datum met tijd als Y-m-d\TH:i, tijd als H:i, datum
 * ongewijzigd. Seconden die niet :00 zijn blijven staan (Y-m-d\TH:i:s, H:i:s), zodat opslaan zonder wijziging
 * dezelfde waarde terugschrijft; het invoerelement krijgt dan step 1 (_ww_settings_date_step()). Een waarde die al
 * zo is (ingezonden na een fout) blijft gelijk; een lege datum van Pods (0000-00-00) wordt leeg.
 *
 * @param string $type  date, time of datetime.
 * @param mixed  $value Opgeslagen of ingezonden waarde.
 */
function _ww_settings_date_value( string $type, mixed $value ): string {
	$text = trim( _ww_data_to_string( $value ) );
	if ( str_starts_with( $text, '0000-00-00' ) ) {
		return '';
	}
	if ( 'datetime' === $type && 1 === preg_match( '/^(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2})(:\d{2})?/', $text, $match ) ) {
		return $match[1] . 'T' . $match[2] . ( isset( $match[3] ) && ':00' !== $match[3] ? $match[3] : '' );
	}
	if ( 'time' === $type && 1 === preg_match( '/^(\d{2}:\d{2})(:\d{2})?/', $text, $match ) ) {
		return $match[1] . ( isset( $match[2] ) && ':00' !== $match[2] ? $match[2] : '' );
	}
	return $text;
}

/**
 * De attributen van een getal: min en max uit number_min en number_max (als ze gezet zijn), en step uit
 * number_decimals: 1 zonder decimalen (ook als het niet gezet is), anders 0.01 voor twee decimalen enzovoort.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 */
function _ww_settings_number_attrs( array $field ): string {
	$attrs = '';
	foreach ( array( 'min' => 'number_min', 'max' => 'number_max' ) as $attr => $key ) {
		$limit = trim( _ww_data_to_string( $field[ $key ] ?? '' ) );
		if ( '' !== $limit && is_numeric( $limit ) ) {
			$attrs .= ' ' . $attr . '="' . esc_attr( $limit ) . '"';
		}
	}
	$decimals = max( 0, (int) _ww_data_to_string( $field['number_decimals'] ?? 0 ) );
	return $attrs . ' step="' . esc_attr( 0 === $decimals ? '1' : '0.' . str_repeat( '0', $decimals - 1 ) . '1' ) . '"';
}

/**
 * De ID's uit een opgeslagen waarde van een relatie of bestand: één ID, een lijst, of items met 'ID'. Lege en nul vallen weg.
 *
 * @param mixed $value Opgeslagen of ingezonden waarde.
 * @return array<int,int>
 */
function _ww_settings_value_ids( mixed $value ): array {
	if ( ! is_array( $value ) || isset( $value['ID'] ) || isset( $value['id'] ) ) {
		$value = array( $value );
	}
	$ids = array();
	foreach ( $value as $item ) {
		$id = _ww_data_item_id( $item );
		if ( $id > 0 ) {
			$ids[] = $id;
		}
	}
	return $ids;
}

/**
 * De opgeslagen waarden van de velden, op naam. Na een fout bij opslaan gaan de ingezonden waarden voor
 * ($GLOBALS['ww_settings_posted']), zodat het formulier met alles terugkomt. Een veld dat nooit is opgeslagen (geen
 * optie) toont zijn default_value, zoals het scheidingsteken of het land; een bewust leeggemaakt veld blijft leeg.
 *
 * @param array<string,array<string,mixed>> $fields Velden uit de configuratie, op naam.
 * @return array<string,mixed>
 */
function _ww_settings_values( array $fields ): array {
	$posted = isset( $GLOBALS['ww_settings_posted'] ) && is_array( $GLOBALS['ww_settings_posted'] ) ? $GLOBALS['ww_settings_posted'] : array();
	$values = array();
	foreach ( $fields as $name => $field ) {
		$name = (string) $name;
		if ( array_key_exists( $name, $posted ) ) {
			$values[ $name ] = $posted[ $name ];
		} elseif ( null === get_option( _ww_settings_prefix() . $name, null ) && isset( $field['default_value'] ) ) {
			$values[ $name ] = $field['default_value'];
		} else {
			$values[ $name ] = _ww_data_get_setting( $name );
		}
	}
	return $values;
}

/**
 * Status naast een openingstijd: Gesloten (leeg), Open met de tijden (ok) of een hint (bad).
 *
 * @return array{class:string,text:string}
 */
function _ww_settings_hours_status( string $value ): array {
	$ranges = _ww_hours_parse( $value );
	if ( null === $ranges ) {
		return array(
			'class' => 'bad',
			'text'  => __( 'Schrijf als 08:00-16:00', 'webwerckt-base' ),
		);
	}
	if ( array() === $ranges ) {
		return array(
			'class' => '',
			'text'  => __( 'Gesloten', 'webwerckt-base' ),
		);
	}
	$parts = array_map(
		static fn( array $range ): string => _ww_hours_time( $range['from'] ) . '–' . _ww_hours_time( $range['to'] ),
		$ranges
	);
	return array(
		'class' => 'ok',
		/* translators: %s: openingstijden, bijvoorbeeld 08:00–12:30 en 13:00–18:00. */
		'text'  => sprintf( __( 'Open %s', 'webwerckt-base' ), implode( ' ' . __( 'en', 'webwerckt-base' ) . ' ', $parts ) ),
	);
}

/**
 * Berichten van een post type om uit te kiezen, gepubliceerd, maximaal 200, op titel.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @return array<int,string> ID => titel.
 */
function _ww_settings_pick_posts( array $field ): array {
	$posts = get_posts(
		array(
			'post_type'   => _ww_data_to_string( $field['pick_val'] ?? 'page' ),
			'post_status' => 'publish',
			'numberposts' => 200,
			'orderby'     => 'title',
			'order'       => 'ASC',
		)
	);
	$list  = array();
	foreach ( $posts as $post ) {
		$list[ $post->ID ] = '' !== $post->post_title ? $post->post_title : __( '(zonder titel)', 'webwerckt-base' );
	}
	return $list;
}

/**
 * Termen van een taxonomie om uit te kiezen, maximaal 200, op naam (ook termen zonder berichten).
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @return array<int,string> ID => naam.
 */
function _ww_settings_pick_terms( array $field ): array {
	$taxonomy = _ww_data_to_string( $field['pick_val'] ?? '' );
	if ( '' === $taxonomy || ! taxonomy_exists( $taxonomy ) ) {
		return array();
	}
	$terms = get_terms(
		array(
			'taxonomy'   => $taxonomy,
			'hide_empty' => false,
			'orderby'    => 'name',
			'order'      => 'ASC',
			'number'     => 200,
		)
	);
	$list  = array();
	foreach ( is_array( $terms ) ? $terms : array() as $term ) {
		$list[ $term->term_id ] = '' !== $term->name ? $term->name : __( '(zonder naam)', 'webwerckt-base' );
	}
	return $list;
}

/**
 * Naam van een term voor in de lijst; een term die weg is, toont zijn ID.
 */
function _ww_settings_term_label( int $id ): string {
	$term = get_term( $id );
	return $term instanceof WP_Term && '' !== $term->name ? $term->name : '#' . $id;
}

/**
 * Titel van een bericht voor in de lijst, ook als het niet (meer) gepubliceerd is.
 */
function _ww_settings_post_label( int $id ): string {
	$title = get_the_title( $id );
	return '' !== $title ? $title : __( '(zonder titel)', 'webwerckt-base' );
}

/**
 * Het invoerelement of de invoerelementen van één veld, naar soort. Id is ww-field-{naam}; bij een lijst met
 * berichten en bij afbeeldingen staat het id op de knop waarmee je toevoegt of kiest, bij het scheidingsteken en de
 * vinkjes van een meerkeuze op de groep (tabindex -1), bij een wysiwyg is het ww_field_{naam} (de editor). Een
 * verplicht veld krijgt required op een zichtbaar invoerelement met één waarde; niet op een tekstvak dat een editor
 * verbergt (code, wysiwyg), vinkjes of lijsten: daar controleert het opslaan.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @param mixed               $value Huidige waarde.
 */
function _ww_settings_render_field( array $field, mixed $value ): string {
	$name = _ww_data_to_string( $field['name'] ?? '' );
	$type = _ww_data_to_string( $field['type'] ?? '' );
	$id   = 'ww-field-' . $name;
	$post = 'ww_fields[' . $name . ']';
	$req  = _ww_field_is_required( $field ) ? ' required' : '';

	if ( ! _ww_settings_field_supported( $field ) ) {
		return '<p class="description">' . esc_html( _ww_settings_unsupported_text( $field ) ) . '</p>';
	}

	if ( 'wysiwyg' === $type ) {
		return _ww_settings_render_wysiwyg( $field, $value );
	}

	$dates = array(
		'date'     => 'date',
		'time'     => 'time',
		'datetime' => 'datetime-local',
	);
	if ( isset( $dates[ $type ] ) ) {
		$shown = _ww_settings_date_value( $type, $value );
		// Met seconden in de waarde moet de browser seconden kennen, anders is de waarde ongeldig voor het formulier.
		$step = 'date' !== $type && 1 === preg_match( '/\d{2}:\d{2}:\d{2}$/', $shown ) ? ' step="1"' : '';
		return '<input type="' . esc_attr( $dates[ $type ] ) . '" id="' . esc_attr( $id ) . '" name="' . esc_attr( $post ) . '" value="' . esc_attr( $shown ) . '"' . $step . $req . '>';
	}

	if ( 'boolean' === $type ) {
		$label = _ww_data_to_string( $field['boolean_yes_label'] ?? '' );
		return '<input type="hidden" name="' . esc_attr( $post ) . '" value="0">'
			. '<label><input type="checkbox" id="' . esc_attr( $id ) . '" name="' . esc_attr( $post ) . '" value="1"' . checked( ! empty( $value ), true, false ) . '> '
			. esc_html( '' !== $label ? $label : __( 'Aan', 'webwerckt-base' ) ) . '</label>';
	}

	if ( 'paragraph' === $type ) {
		return '<textarea class="large-text" rows="3" id="' . esc_attr( $id ) . '" name="' . esc_attr( $post ) . '"' . $req . '>' . esc_textarea( _ww_data_to_string( $value ) ) . '</textarea>';
	}

	if ( 'code' === $type ) {
		$text  = _ww_data_to_string( $value );
		$lines = max( 4, substr_count( $text, "\n" ) + 1 );
		return '<textarea class="large-text code ww-settings-code" rows="' . (int) $lines . '" id="' . esc_attr( $id ) . '" name="' . esc_attr( $post ) . '" spellcheck="false">' . esc_textarea( $text ) . '</textarea>';
	}

	if ( 'file' === $type ) {
		return _ww_fields_is_multi( $field ) ? _ww_settings_render_images( $field, $value ) : _ww_settings_render_image( $field, $value );
	}

	if ( 'pick' === $type ) {
		if ( _ww_field_is_relation( $field ) ) {
			return _ww_settings_render_posts( $field, $value );
		}
		return _ww_settings_render_options( $field, $value );
	}

	$types = array(
		'phone'   => 'tel',
		'email'   => 'email',
		'website' => 'url',
		'number'  => 'number',
	);
	$extra = 'number' === $type ? _ww_settings_number_attrs( $field ) : '';
	$input = '<input type="' . esc_attr( $types[ $type ] ?? 'text' ) . '" class="regular-text" id="' . esc_attr( $id ) . '" name="' . esc_attr( $post ) . '" value="' . esc_attr( _ww_data_to_string( $value ) ) . '"' . $extra . $req . '>';

	$icons = array(
		'facebook'  => 'dashicons-facebook-alt',
		'instagram' => 'dashicons-instagram',
		'linkedin'  => 'dashicons-linkedin',
	);
	if ( isset( $icons[ $name ] ) ) {
		$input = '<span class="ww-settings-input-icon"><span class="dashicons ' . esc_attr( $icons[ $name ] ) . '" aria-hidden="true"></span>' . $input . '</span>';
	}
	return $input;
}

/**
 * De zin bij een veld zonder invoer. Alleen als de abilities en Visueel bewerken het veld wel bewerken (een veld van
 * een bericht of de Site-instellingen dat de veldlaag kent, _ww_field_layer_supports()), noemt de zin die; anders
 * (een relatie met gebruikers, een termveld) zegt hij dat het thema het veld niet bewerkt.
 *
 * @param array<string,mixed> $field Veld uit de configuratie (een termveld heeft ww_term).
 */
function _ww_settings_unsupported_text( array $field ): string {
	if ( empty( $field['ww_term'] ) && _ww_field_layer_supports( $field ) ) {
		return __( 'Dit veld bewerk je via Visueel bewerken of de abilities.', 'webwerckt-base' );
	}
	return __( 'Dit veld kan het thema niet bewerken; de waarde blijft staan.', 'webwerckt-base' );
}

/**
 * Opgeslagen keuzes van een meerkeuze met meerdere keuzes als lijst met tekst: een lijst, of een losse tekst
 * (één keuze, of gescheiden door komma's).
 *
 * @param mixed $value Opgeslagen of ingezonden waarde.
 * @return array<int,string>
 */
function _ww_settings_value_choices( mixed $value ): array {
	$list = is_array( $value ) ? $value : explode( ',', _ww_data_to_string( $value ) );
	return array_values( array_filter( array_map( static fn( $item ): string => trim( _ww_data_to_string( $item ) ), $list ), static fn( string $item ): bool => '' !== $item ) );
}

/**
 * Keuze uit een vaste lijst: een select, vinkjes bij meerdere keuzes, of bij het scheidingsteken van de SEO-titel
 * keuzerondjes als knoppen.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @param mixed               $value Huidige waarde.
 */
function _ww_settings_render_options( array $field, mixed $value ): string {
	$name    = _ww_data_to_string( $field['name'] ?? '' );
	$post    = 'ww_fields[' . $name . ']';
	$options = _ww_field_choices( $field );
	$current = _ww_data_to_string( $value );

	if ( _ww_fields_is_multi( $field ) ) {
		$chosen = _ww_settings_value_choices( $value );
		// Zonder vinkjes aan moet de naam toch in de POST staan: dan slaat een lege lijst op.
		$html = '<div class="ww-field-checkboxes" role="group" aria-labelledby="ww-label-' . esc_attr( $name ) . '" id="ww-field-' . esc_attr( $name ) . '" tabindex="-1">'
			. '<input type="hidden" name="' . esc_attr( $post ) . '[]" value="">';
		foreach ( $options as $key => $label ) {
			$key   = (string) $key;
			$html .= '<label class="ww-field-checkboxes__item"><input type="checkbox" name="' . esc_attr( $post ) . '[]" value="' . esc_attr( $key ) . '"' . checked( in_array( $key, $chosen, true ), true, false ) . '> <span>' . esc_html( $label ) . '</span></label>';
		}
		return $html . '</div>';
	}

	if ( 'seo_separator' === $name ) {
		$html = '<div class="ww-settings-separators" role="radiogroup" aria-labelledby="ww-label-' . esc_attr( $name ) . '" id="ww-field-' . esc_attr( $name ) . '" tabindex="-1">';
		foreach ( $options as $key => $label ) {
			$key   = (string) $key;
			$sign  = WW_SEO_SEPARATORS[ $key ] ?? $key;
			$html .= '<label class="ww-settings-separator"><input type="radio" name="' . esc_attr( $post ) . '" value="' . esc_attr( $key ) . '"' . checked( $current, $key, false ) . ' aria-label="' . esc_attr( $label ) . '"><span aria-hidden="true">' . esc_html( $sign ) . '</span></label>';
		}
		return $html . '</div>';
	}

	$html = '<select id="ww-field-' . esc_attr( $name ) . '" name="' . esc_attr( $post ) . '"' . ( _ww_field_is_required( $field ) ? ' required' : '' ) . '>';
	// Bovenaan "— Geen —": zo maak je een keuze leeg (zoals bij Pods), en stuurt de browser bij een lege waarde niet de
	// eerste keuze terug. Een verplicht veld krijgt die optie alleen als het leeg is; required houdt haar dan tegen. Een
	// verouderde waarde (niet meer in de lijst) krijgt een eigen gekozen optie, zodat opslaan zonder wijziging haar houdt.
	$known = array_key_exists( $current, $options );
	if ( ! _ww_field_is_required( $field ) || ( ! $known && '' === $current ) ) {
		$html .= '<option value=""' . selected( $current, '', false ) . '>' . esc_html__( '— Geen —', 'webwerckt-base' ) . '</option>';
	}
	if ( ! $known && '' !== $current ) {
		$html .= '<option value="' . esc_attr( $current ) . '" selected>' . esc_html( $current ) . '</option>';
	}
	foreach ( $options as $key => $label ) {
		$html .= '<option value="' . esc_attr( (string) $key ) . '"' . selected( $current, (string) $key, false ) . '>' . esc_html( $label ) . '</option>';
	}
	return $html . '</select>';
}

/**
 * Relatie met berichten of termen: bij meerdere waarden een lijst met omhoog, omlaag en weghalen; anders een select.
 * Een relatie met termen kiest uit de termen van zijn taxonomie (pick_val), op naam.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @param mixed               $value Huidige waarde.
 */
function _ww_settings_render_posts( array $field, mixed $value ): string {
	$name  = _ww_data_to_string( $field['name'] ?? '' );
	$post  = 'ww_fields[' . $name . ']';
	$ids   = _ww_settings_value_ids( $value );
	$terms = _ww_field_is_term_relation( $field );
	$posts = $terms ? _ww_settings_pick_terms( $field ) : _ww_settings_pick_posts( $field );
	$label = $terms ? '_ww_settings_term_label' : '_ww_settings_post_label';

	if ( ! _ww_fields_is_multi( $field ) ) {
		$html = '<select id="ww-field-' . esc_attr( $name ) . '" name="' . esc_attr( $post ) . '"' . ( _ww_field_is_required( $field ) ? ' required' : '' ) . '><option value="">' . esc_html__( '— Geen —', 'webwerckt-base' ) . '</option>';
		$have = $ids[0] ?? 0;
		if ( $have > 0 && ! isset( $posts[ $have ] ) ) {
			$posts[ $have ] = $label( $have );
		}
		foreach ( $posts as $post_id => $title ) {
			$html .= '<option value="' . (int) $post_id . '"' . selected( $have, $post_id, false ) . '>' . esc_html( $title ) . '</option>';
		}
		return $html . '</select>';
	}

	$html = '<div class="ww-settings-pickfield"><ul class="ww-settings-picks">';
	foreach ( $ids as $post_id ) {
		$title = $label( $post_id );
		/* translators: %s: titel van de pagina. */
		$up = sprintf( __( '%s omhoog', 'webwerckt-base' ), $title );
		/* translators: %s: titel van de pagina. */
		$down = sprintf( __( '%s omlaag', 'webwerckt-base' ), $title );
		/* translators: %s: titel van de pagina. */
		$remove = sprintf( __( '%s weghalen', 'webwerckt-base' ), $title );
		$html  .= '<li class="ww-settings-picks__item"><input type="hidden" name="' . esc_attr( $post ) . '[]" value="' . (int) $post_id . '">'
			. '<span class="ww-settings-picks__title">' . esc_html( $title ) . '</span>'
			. '<button type="button" class="button-link ww-settings-picks__up" aria-label="' . esc_attr( $up ) . '"><span class="dashicons dashicons-arrow-up-alt2" aria-hidden="true"></span></button>'
			. '<button type="button" class="button-link ww-settings-picks__down" aria-label="' . esc_attr( $down ) . '"><span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span></button>'
			. '<button type="button" class="button-link button-link-delete ww-settings-picks__remove" aria-label="' . esc_attr( $remove ) . '"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></button></li>';
	}
	$html .= '</ul>';
	// Een lege lijst moet ook opslaan: dit veld zorgt dat de naam altijd in de POST staat.
	$html .= '<input type="hidden" name="' . esc_attr( $post ) . '[]" value="">';
	$texts = $terms
		? array( __( '+ Term toevoegen', 'webwerckt-base' ), __( 'Term toevoegen', 'webwerckt-base' ), __( '— Kies een term —', 'webwerckt-base' ) )
		: array( __( '+ Pagina toevoegen', 'webwerckt-base' ), __( 'Pagina toevoegen', 'webwerckt-base' ), __( '— Kies een pagina —', 'webwerckt-base' ) );
	$html .= '<button type="button" class="button ww-settings-picks__add" id="ww-field-' . esc_attr( $name ) . '">' . esc_html( $texts[0] ) . '</button>';
	$html .= '<select class="ww-settings-picks__select" hidden aria-label="' . esc_attr( $texts[1] ) . '"><option value="">' . esc_html( $texts[2] ) . '</option>';
	foreach ( $posts as $post_id => $title ) {
		$html .= '<option value="' . (int) $post_id . '">' . esc_html( $title ) . '</option>';
	}
	return $html . '</select></div>';
}

/**
 * Één afbeelding: verborgen ID, voorbeeld met bestandsnaam en afmetingen, en de knoppen om te kiezen of te verwijderen.
 * Het id staat op de knop Afbeelding kiezen.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @param mixed               $value Huidige waarde.
 */
function _ww_settings_render_image( array $field, mixed $value ): string {
	$name = _ww_data_to_string( $field['name'] ?? '' );
	$post = 'ww_fields[' . $name . ']';
	$ids  = _ww_settings_value_ids( $value );
	$id   = $ids[0] ?? 0;
	$html = '<div class="ww-settings-image" data-field="' . esc_attr( $name ) . '"><input type="hidden" name="' . esc_attr( $post ) . '" value="' . ( $id > 0 ? (int) $id : '' ) . '">';

	$image = $id > 0 ? wp_get_attachment_image( $id, 'medium' ) : '';
	if ( '' !== $image ) {
		$meta  = wp_get_attachment_metadata( $id );
		$file  = wp_basename( (string) get_attached_file( $id ) );
		$size  = is_array( $meta ) && isset( $meta['width'], $meta['height'] ) ? ' · ' . (int) $meta['width'] . ' × ' . (int) $meta['height'] : '';
		$html .= '<div class="ww-settings-image__preview">' . $image . '<p class="description">' . esc_html( $file . $size ) . '</p></div>';
	} else {
		$html .= '<p class="description ww-settings-image__empty">' . esc_html__( 'Geen afbeelding gekozen.', 'webwerckt-base' ) . '</p>';
	}

	$choose = '' !== $image ? __( 'Andere afbeelding', 'webwerckt-base' ) : __( 'Afbeelding kiezen', 'webwerckt-base' );
	$html  .= '<p><button type="button" class="button ww-settings-image__choose" id="ww-field-' . esc_attr( $name ) . '">' . esc_html( $choose ) . '</button>';
	if ( '' !== $image ) {
		$html .= ' <button type="button" class="button-link button-link-delete ww-settings-image__remove">' . esc_html__( 'Verwijderen', 'webwerckt-base' ) . '</button>';
	}
	return $html . '</p></div>';
}

/**
 * Meerdere afbeeldingen: een lijst met per afbeelding een verborgen ID, een voorbeeld, de bestandsnaam en knoppen
 * omhoog, omlaag en weghalen, zoals de lijst met pagina's. Het id staat op de knop Afbeelding toevoegen.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @param mixed               $value Huidige waarde.
 */
function _ww_settings_render_images( array $field, mixed $value ): string {
	$name = _ww_data_to_string( $field['name'] ?? '' );
	$post = 'ww_fields[' . $name . ']';
	$html = '<div class="ww-field-images" data-field="' . esc_attr( $name ) . '"><ul class="ww-field-images__list">';
	foreach ( _ww_settings_value_ids( $value ) as $id ) {
		$file  = wp_basename( (string) get_attached_file( $id ) );
		$title = '' !== $file ? $file : _ww_settings_post_label( $id );
		/* translators: %s: bestandsnaam of titel van de afbeelding. */
		$up = sprintf( __( '%s omhoog', 'webwerckt-base' ), $title );
		/* translators: %s: bestandsnaam of titel van de afbeelding. */
		$down = sprintf( __( '%s omlaag', 'webwerckt-base' ), $title );
		/* translators: %s: bestandsnaam of titel van de afbeelding. */
		$remove = sprintf( __( '%s weghalen', 'webwerckt-base' ), $title );
		$html  .= '<li class="ww-field-images__item"><input type="hidden" name="' . esc_attr( $post ) . '[]" value="' . (int) $id . '">'
			. wp_get_attachment_image( $id, 'thumbnail', false, array( 'alt' => '' ) )
			. '<span class="ww-field-images__title">' . esc_html( $title ) . '</span>'
			. '<button type="button" class="button-link ww-field-images__up" aria-label="' . esc_attr( $up ) . '"><span class="dashicons dashicons-arrow-up-alt2" aria-hidden="true"></span></button>'
			. '<button type="button" class="button-link ww-field-images__down" aria-label="' . esc_attr( $down ) . '"><span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span></button>'
			. '<button type="button" class="button-link button-link-delete ww-field-images__remove" aria-label="' . esc_attr( $remove ) . '"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></button></li>';
	}
	$html .= '</ul>';
	// Een lege lijst moet ook opslaan: dit veld zorgt dat de naam altijd in de POST staat.
	$html .= '<input type="hidden" name="' . esc_attr( $post ) . '[]" value="">';
	return $html . '<button type="button" class="button ww-field-images__add" id="ww-field-' . esc_attr( $name ) . '">' . esc_html__( '+ Afbeelding toevoegen', 'webwerckt-base' ) . '</button></div>';
}

/**
 * Opgemaakte tekst: de editor van WordPress (TinyMCE en het tabblad Tekst), met de knop Media toevoegen.
 * Shortcodes blijven gewone tekst in de inhoud.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @param mixed               $value Huidige waarde.
 */
function _ww_settings_render_wysiwyg( array $field, mixed $value ): string {
	$name = _ww_data_to_string( $field['name'] ?? '' );
	ob_start();
	wp_editor(
		_ww_data_to_string( $value ),
		_ww_settings_editor_id( $name ),
		array(
			'textarea_name' => 'ww_fields[' . $name . ']',
			'textarea_rows' => 8,
			'media_buttons' => true,
			'teeny'         => false,
		)
	);
	return '<div class="ww-field-wysiwyg">' . (string) ob_get_clean() . '</div>';
}

/**
 * Maakt van `$_POST['ww_fields']` invoer voor _ww_fields_input(). Een uitgezet vinkje en een lege lijst staan niet in
 * de POST zoals een browser die stuurt; ze worden hier aangevuld. Uit elke lijst (relaties, meerkeuze, afbeeldingen)
 * vallen de lege elementen weg, zoals het lege veld dat de naam in de POST houdt. Een naam die niet in $fields staat,
 * blijft staan, zodat _ww_fields_input() hem weigert.
 *
 * @param array<string,array<string,mixed>> $fields Velden op het scherm (bijvoorbeeld _ww_settings_section_fields()).
 * @param array<string,mixed>               $posted Ingezonden waarden, nog met slashes.
 * @return array<string,mixed>
 */
function _ww_settings_post_values( array $fields, array $posted ): array {
	$values = array();
	foreach ( $posted as $name => $value ) {
		$name = (string) $name;
		if ( is_array( $value ) && isset( $fields[ $name ] ) && in_array( $fields[ $name ]['type'] ?? '', array( 'pick', 'file' ), true ) ) {
			$value = array_values( array_filter( array_map( 'wp_unslash', $value ), static fn( $id ): bool => '' !== $id ) );
		} else {
			$value = wp_unslash( $value );
		}
		$values[ $name ] = $value;
	}
	foreach ( $fields as $name => $field ) {
		if ( array_key_exists( $name, $values ) ) {
			continue;
		}
		if ( 'boolean' === ( $field['type'] ?? '' ) ) {
			$values[ $name ] = 0;
		} elseif ( in_array( $field['type'] ?? '', array( 'pick', 'file' ), true ) && _ww_fields_is_multi( $field ) ) {
			$values[ $name ] = array();
		}
	}
	return $values;
}

/**
 * De teksten van assets/js/field-inputs.js, vertaald in PHP: het thema maakt geen vertaal-JSON voor scripts. Het
 * script vult %s zelf in.
 *
 * @return array<string,string>
 */
function _ww_field_inputs_texts(): array {
	return array(
		/* translators: %s: titel van de pagina of naam van de afbeelding. */
		'up'      => __( '%s omhoog', 'webwerckt-base' ),
		/* translators: %s: titel van de pagina of naam van de afbeelding. */
		'down'    => __( '%s omlaag', 'webwerckt-base' ),
		/* translators: %s: titel van de pagina of naam van de afbeelding. */
		'remove'  => __( '%s weghalen', 'webwerckt-base' ),
		'noImage' => __( 'Geen afbeelding gekozen.', 'webwerckt-base' ),
		'other'   => __( 'Andere afbeelding', 'webwerckt-base' ),
		'choose'  => __( 'Afbeelding kiezen', 'webwerckt-base' ),
		'delete'  => __( 'Verwijderen', 'webwerckt-base' ),
	);
}

/**
 * Laadt het script en de stijl van de invoer (ww-field-inputs), met de teksten als window.wwFieldInputsTexts. De
 * mediabibliotheek laadt alleen bij een bestandsveld of een wysiwyg (de knop Media toevoegen), de editor alleen bij
 * een wysiwyg. Voor de Site-instellingen en het bewerkscherm.
 *
 * @param array<string,array<string,mixed>> $fields Velden op het scherm.
 */
function _ww_field_inputs_enqueue( array $fields ): void {
	$types = array();
	foreach ( $fields as $field ) {
		$types[ _ww_data_to_string( $field['type'] ?? '' ) ] = true;
	}
	if ( isset( $types['file'] ) || isset( $types['wysiwyg'] ) ) {
		wp_enqueue_media();
	}
	if ( isset( $types['wysiwyg'] ) ) {
		wp_enqueue_editor();
	}
	wp_enqueue_style( 'ww-field-inputs', _ww_asset_url( 'css/field-inputs.css' ), array(), WW_BASE_VERSION );
	wp_enqueue_script( 'ww-field-inputs', _ww_asset_url( 'js/field-inputs.js' ), array(), WW_BASE_VERSION, array( 'in_footer' => true ) );
	if ( empty( wp_scripts()->get_data( 'ww-field-inputs', 'before' ) ) ) {
		wp_add_inline_script( 'ww-field-inputs', 'window.wwFieldInputsTexts = ' . wp_json_encode( _ww_field_inputs_texts() ) . ';', 'before' );
	}
}

/**
 * Het label van een veld: een echt label bij een invoer met één element (bij een wysiwyg naar het tekstvak van de
 * editor), een span met id (voor aria-labelledby) bij de radiogroep en de vinkjes van een meerkeuze, en alleen tekst
 * bij een veld zonder invoer.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 */
function _ww_settings_field_label( array $field, string $text ): string {
	$name = _ww_data_to_string( $field['name'] ?? '' );
	if ( 'seo_separator' === $name || ( _ww_field_is_choice( $field ) && _ww_fields_is_multi( $field ) ) ) {
		return '<span id="ww-label-' . esc_attr( $name ) . '">' . esc_html( $text ) . '</span>';
	}
	if ( ! _ww_settings_field_supported( $field ) ) {
		return esc_html( $text );
	}
	$for = 'wysiwyg' === ( $field['type'] ?? '' ) ? _ww_settings_editor_id( $name ) : 'ww-field-' . $name;
	return '<label for="' . esc_attr( $for ) . '">' . esc_html( $text ) . '</label>';
}

/**
 * De voorvertoning van de homepage in Google, onder de beschrijving. Het script werkt hem bij; zonder script staat de
 * huidige waarde er.
 *
 * @param array<string,mixed> $values Waarden van het onderdeel.
 */
function _ww_settings_render_serp( array $values ): string {
	$fallback = _ww_plain_text( get_bloginfo( 'name' ) );
	$tagline  = _ww_plain_text( get_bloginfo( 'description' ) );
	if ( '' !== $tagline ) {
		$fallback .= ' ' . WW_SEO_SEPARATORS['ndash'] . ' ' . $tagline;
	}
	$title = _ww_plain_text( _ww_data_to_string( $values['seo_home_title'] ?? '' ) );
	$desc  = _ww_plain_text( _ww_data_to_string( $values['seo_home_description'] ?? '' ) );
	$host  = wp_parse_url( home_url(), PHP_URL_HOST );
	return '<div class="ww-settings-serp" data-fallback="' . esc_attr( $fallback ) . '" aria-hidden="true">'
		. '<span class="ww-settings-serp__url">' . esc_html( is_string( $host ) ? $host : home_url() ) . '</span>'
		. '<span class="ww-settings-serp__title">' . esc_html( '' !== $title ? $title : $fallback ) . '</span>'
		. '<span class="ww-settings-serp__desc">' . esc_html( $desc ) . '</span></div>';
}

/**
 * Een invoer in een gedeelde rij: zonder eigen label, met het veldlabel als placeholder en aria-label.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @param mixed               $value Huidige waarde.
 */
function _ww_settings_inline_input( array $field, mixed $value ): string {
	$html  = _ww_settings_render_field( $field, $value );
	$label = _ww_data_to_string( $field['label'] ?? '' );
	return preg_replace( '/<input /', '<input placeholder="' . esc_attr( $label ) . '" aria-label="' . esc_attr( $label ) . '" ', $html, 1 ) ?? $html;
}

/**
 * De velden die met ww_with in de rij van dit veld komen: alleen velden van het onderdeel ($values heeft ze, dus de
 * gebruiker mag ze bewerken) die het thema tekent. Andere namen vallen weg.
 *
 * @param array<string,mixed> $field  Veld uit de configuratie.
 * @param array<string,mixed> $values Waarden van het onderdeel, op naam.
 * @return array<string,array<string,mixed>> Naam => veld uit de configuratie.
 */
function _ww_settings_with_fields( array $field, array $values ): array {
	$result = array();
	foreach ( is_array( $field['ww_with'] ?? null ) ? $field['ww_with'] : array() as $other ) {
		$other  = _ww_data_to_string( $other );
		$config = array_key_exists( $other, $values ) ? _ww_setting_field( $other ) : null;
		if ( null !== $config && _ww_settings_field_supported( $config ) ) {
			$result[ $other ] = $config;
		}
	}
	return $result;
}

/**
 * De rij van een veld: label, invoer en omschrijving. Met ww_with komen de genoemde velden in dezelfde rij, na het
 * veld zelf. Een verouderd veld (ww_legacy) zonder waarde geeft ''; een soort die het thema niet tekent krijgt de
 * zin zonder invoer.
 *
 * @param array<string,mixed> $field  Veld uit de configuratie.
 * @param mixed               $value  Huidige waarde.
 * @param array<string,mixed> $values Waarden van het onderdeel, op naam (voor ww_with).
 */
function _ww_settings_render_row( array $field, mixed $value, array $values ): string {
	$name = _ww_data_to_string( $field['name'] ?? '' );
	if ( ! empty( $field['ww_legacy'] ) && '' === trim( _ww_data_to_string( $value ) ) ) {
		return '';
	}

	$label = _ww_data_to_string( $field['ww_row_label'] ?? '' );
	$label = '' !== $label ? $label : _ww_data_to_string( $field['label'] ?? $name );
	$html  = '<tr class="ww-settings-row" data-field="' . esc_attr( $name ) . '"><th scope="row">' . _ww_settings_field_label( $field, $label ) . '</th><td>';

	$with = _ww_settings_with_fields( $field, $values );
	if ( array() !== $with ) {
		$html .= '<div class="ww-settings-inline">' . _ww_settings_inline_input( $field, $value );
		foreach ( $with as $other => $config ) {
			$html .= _ww_settings_inline_input( $config, $values[ $other ] ?? null );
		}
		$html .= '</div>';
	} else {
		$html .= _ww_settings_render_field( $field, $value );
		if ( in_array( $name, array( 'seo_home_title', 'seo_home_description' ), true ) ) {
			$html .= '<span class="ww-settings-counter" data-for="ww-field-' . esc_attr( $name ) . '" data-kind="' . ( 'seo_home_title' === $name ? 'title' : 'description' ) . '"></span>';
		}
		if ( 'seo_home_description' === $name ) {
			$html .= _ww_settings_render_serp( $values );
		}
	}

	$description = _ww_data_to_string( $field['description'] ?? '' );
	if ( '' !== $description ) {
		$html .= '<p class="description">' . esc_html( $description ) . '</p>';
	}
	return $html . '</td></tr>';
}

/**
 * De groep als vak: kop, omschrijving en rijen. Bij ww_layout days de dagtabel van de openingstijden.
 *
 * @param array<string,mixed>               $group  Groep uit de configuratie.
 * @param array<string,array<string,mixed>> $fields Velden van de groep, op naam.
 * @param array<string,mixed>               $values Waarden van het onderdeel, op naam.
 */
function _ww_settings_render_group( array $group, array $fields, array $values ): string {
	$name        = _ww_data_to_string( $group['name'] ?? '' );
	$description = _ww_data_to_string( $group['description'] ?? '' );
	$html        = '<section class="ww-settings-box" id="ww-group-' . esc_attr( $name ) . '"><h2>' . esc_html( _ww_data_to_string( $group['label'] ?? $name ) ) . '</h2>';

	if ( 'days' === ( $group['ww_layout'] ?? '' ) ) {
		$html .= '<table class="ww-settings-days"><tbody>';
		foreach ( $fields as $field_name => $field ) {
			$field_name = (string) $field_name;
			$raw        = _ww_data_to_string( $values[ $field_name ] ?? '' );
			$status     = _ww_settings_hours_status( $raw );
			$id         = 'ww-field-' . $field_name;
			$html      .= '<tr data-field="' . esc_attr( $field_name ) . '"><th scope="row"><label for="' . esc_attr( $id ) . '">' . esc_html( _ww_data_to_string( $field['label'] ?? $field_name ) ) . '</label></th>'
				. '<td><input type="text" class="ww-settings-hours" id="' . esc_attr( $id ) . '" name="' . esc_attr( 'ww_fields[' . $field_name . ']' ) . '" value="' . esc_attr( $raw ) . '" placeholder="' . esc_attr__( 'Gesloten', 'webwerckt-base' ) . '"' . ( 'bad' === $status['class'] ? ' aria-invalid="true"' : '' ) . '></td>'
				. '<td><span class="ww-settings-hours-status' . ( '' !== $status['class'] ? ' ' . esc_attr( $status['class'] ) : '' ) . '" aria-live="polite">' . esc_html( $status['text'] ) . '</span></td></tr>';
		}
		$html .= '</tbody></table>';
		$html .= '<p><button type="button" class="button ww-settings-hours-copy" hidden>' . esc_html__( 'Maandag overnemen voor di t/m vr', 'webwerckt-base' ) . '</button></p>';
		if ( '' !== $description ) {
			$html .= '<p class="description">' . esc_html( $description ) . '</p>';
		}
		return $html . '</section>';
	}

	if ( '' !== $description ) {
		$html .= '<p class="description">' . esc_html( $description ) . '</p>';
	}
	$skip = array();
	foreach ( $fields as $field ) {
		$skip += _ww_settings_with_fields( $field, $values );
	}
	$html .= '<table class="form-table" role="presentation"><tbody>';
	foreach ( $fields as $field_name => $field ) {
		if ( ! isset( $skip[ (string) $field_name ] ) ) {
			$html .= _ww_settings_render_row( $field, $values[ (string) $field_name ] ?? null, $values );
		}
	}
	return $html . '</tbody></table></section>';
}
