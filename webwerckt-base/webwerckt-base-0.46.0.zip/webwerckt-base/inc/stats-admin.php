<?php
/**
 * Statistieken: het scherm Statistieken (een hoofditem in het blok Webwerckt) en de dashboardwidget (beslissing 0038).
 *
 * Alleen lezen, voor Redacteur en beheerder (edit_others_pages). De periode gaat via GET, zonder nonce: er wordt
 * niets veranderd. Vóór het lezen worden de afgelopen dagen samengevat. De grafiek is een inline SVG die de server
 * tekent, met een verborgen tabel voor schermlezers.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const WW_STATS_PAGE = 'ww-stats';

/**
 * Voegt Statistieken toe als hoofditem; het blok Webwerckt staat in _ww_admin_menu_groups().
 */
function _ww_stats_admin_menu(): void {
	if ( ! current_user_can( 'edit_others_pages' ) ) {
		return;
	}
	add_menu_page(
		__( 'Statistieken', 'webwerckt-base' ),
		__( 'Statistieken', 'webwerckt-base' ),
		'edit_others_pages',
		WW_STATS_PAGE,
		'_ww_stats_admin_render',
		'dashicons-chart-bar'
	);
}
add_action( 'admin_menu', '_ww_stats_admin_menu' );

/**
 * Laadt de stijl, alleen op dit scherm en op het dashboard.
 *
 * @param string $hook Admin-scherm.
 */
function _ww_stats_admin_assets( string $hook ): void {
	if ( ! in_array( $hook, array( 'toplevel_page_' . WW_STATS_PAGE, 'index.php' ), true ) || ! current_user_can( 'edit_others_pages' ) ) {
		return;
	}
	wp_enqueue_style( 'ww-stats-admin', _ww_asset_url( 'css/stats-admin.css' ), array(), WW_BASE_VERSION );
	wp_enqueue_script( 'ww-stats-realtime', _ww_asset_url( 'js/stats-realtime.js' ), array(), WW_BASE_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
	if ( 'toplevel_page_' . WW_STATS_PAGE === $hook ) {
		// Het venster bij Paden; zonder dit script opent een bezoek op zijn eigen pagina.
		wp_enqueue_script( 'ww-stats-visits', _ww_asset_url( 'js/stats-visits.js' ), array(), WW_BASE_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
	}
}
add_action( 'admin_enqueue_scripts', '_ww_stats_admin_assets' );

/**
 * URL van het scherm, eventueel met extra queryvariabelen.
 *
 * @param array<string,string> $args Queryvariabelen.
 */
function _ww_stats_admin_url( array $args = array() ): string {
	return add_query_arg( array_map( 'rawurlencode', array( 'page' => WW_STATS_PAGE ) + $args ), admin_url( 'admin.php' ) );
}

/**
 * Of de tabellen klaar zijn.
 */
function _ww_stats_ready(): bool {
	return get_option( 'ww_stats_db_version' ) === WW_STATS_DB_VERSION;
}

/**
 * Of er ooit iets is gemeten: een dagrij of een ruwe rij.
 */
function _ww_stats_has_data(): bool {
	global $wpdb;
	return null !== $wpdb->get_var( 'SELECT 1 FROM ' . _ww_stats_daily_table() . ' LIMIT 1' ) // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_stats_daily_table().
		|| null !== $wpdb->get_var( 'SELECT 1 FROM ' . _ww_stats_hits_table() . ' LIMIT 1' ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_stats_hits_table().
}

/**
 * Een verschil in procenten als tekst: +12 %, -50 %, 0 %, of – als er niets is om mee te vergelijken.
 *
 * @param int|null $change Uit _ww_stats_change().
 */
function _ww_stats_format_change( ?int $change ): string {
	if ( null === $change ) {
		return '–';
	}
	$sign = $change > 0 ? '+' : ( $change < 0 ? '-' : '' );
	return $sign . number_format_i18n( abs( $change ) ) . ' %';
}

/**
 * Een deel van een totaal in procenten, afgerond, als tekst.
 */
function _ww_stats_format_share( int $part, int $total ): string {
	return number_format_i18n( $total > 0 ? (int) round( $part / $total * 100 ) : 0 ) . ' %';
}

/**
 * De titel en de link van een pad: de voorpagina of de sitenaam voor /, de titel van het bericht met dat pad
 * (url_to_postid()), anders het pad zelf.
 *
 * @param string $path Pad, zoals bewaard.
 * @return array{label:string,url:string}
 */
function _ww_stats_page_label( string $path ): array {
	if ( '(overige)' === $path ) {
		return array(
			'label' => __( 'Overige', 'webwerckt-base' ),
			'url'   => '',
		);
	}
	if ( '/' === $path ) {
		$front = (int) get_option( 'page_on_front' );
		if ( 'page' === get_option( 'show_on_front' ) && $front > 0 && null !== get_post( $front ) ) {
			return array(
				'label' => _ww_plain_text( get_the_title( $front ) ),
				'url'   => (string) get_permalink( $front ),
			);
		}
		return array(
			'label' => _ww_plain_text( (string) get_bloginfo( 'name' ) ),
			'url'   => home_url( '/' ),
		);
	}
	$id    = url_to_postid( home_url( $path ) );
	$title = $id > 0 ? _ww_plain_text( get_the_title( $id ) ) : '';
	if ( '' !== $title ) {
		return array(
			'label' => $title,
			'url'   => (string) get_permalink( $id ),
		);
	}
	return array(
		'label' => $path,
		'url'   => home_url( $path ),
	);
}

/**
 * Een leesbare naam voor een herkomst: de naam van een bekende dienst, Direct, of de host.
 *
 * @param string $item Groepsnaam of host uit _ww_stats_referrer_group().
 */
function _ww_stats_referrer_label( string $item ): string {
	$names = array(
		'google'     => 'Google',
		'bing'       => 'Bing',
		'duckduckgo' => 'DuckDuckGo',
		'ecosia'     => 'Ecosia',
		'yahoo'      => 'Yahoo',
		'facebook'   => 'Facebook',
		'instagram'  => 'Instagram',
		'linkedin'   => 'LinkedIn',
		'x'          => 'X',
		'youtube'    => 'YouTube',
		'pinterest'  => 'Pinterest',
		'direct'     => __( 'Direct', 'webwerckt-base' ),
		'(overige)'  => __( 'Overige', 'webwerckt-base' ),
	);
	return $names[ $item ] ?? $item;
}

/**
 * De naam van een land in de taal van de gebruiker (intl), anders de ISO-code. Leeg wordt Onbekend.
 *
 * @param string $code ISO-code, of ''.
 */
function _ww_stats_country_label( string $code ): string {
	if ( '' === $code ) {
		return __( 'Onbekend', 'webwerckt-base' );
	}
	if ( '(overige)' === $code ) {
		return __( 'Overige', 'webwerckt-base' );
	}
	if ( class_exists( 'Locale' ) ) {
		$name = Locale::getDisplayRegion( '-' . $code, get_user_locale() );
		if ( is_string( $name ) && '' !== $name && $name !== $code ) {
			return $name;
		}
	}
	return $code;
}

/**
 * De naam van een apparaat.
 *
 * @param string $item mobile, tablet, desktop of (overige).
 */
function _ww_stats_device_label( string $item ): string {
	$names = array(
		'mobile'    => __( 'Mobiel', 'webwerckt-base' ),
		'tablet'    => __( 'Tablet', 'webwerckt-base' ),
		'desktop'   => __( 'Desktop', 'webwerckt-base' ),
		'(overige)' => __( 'Overige', 'webwerckt-base' ),
	);
	return $names[ $item ] ?? $item;
}

/**
 * Telt een reeks per dag op per maand (sleutel Y-m).
 *
 * @param array<string,array{views:int,visitors:int}> $series Reeks per dag.
 * @return array<string,array{views:int,visitors:int}>
 */
function _ww_stats_series_by_month( array $series ): array {
	$months = array();
	foreach ( $series as $day => $counts ) {
		$month = substr( (string) $day, 0, 7 );

		$months[ $month ]['views']    = ( $months[ $month ]['views'] ?? 0 ) + $counts['views'];
		$months[ $month ]['visitors'] = ( $months[ $month ]['visitors'] ?? 0 ) + $counts['visitors'];
	}
	return $months;
}

/**
 * Een sleutel uit de reeks als leesbare datum: 3 nov. 2026 voor een dag, nov. 2026 voor een maand.
 *
 * @param string $key Y-m-d of Y-m.
 */
function _ww_stats_series_label( string $key ): string {
	$is_month = 7 === strlen( $key );
	$date     = DateTimeImmutable::createFromFormat( $is_month ? '!Y-m' : '!Y-m-d', $key, wp_timezone() );
	if ( false === $date ) {
		return $key;
	}
	return (string) wp_date( $is_month ? 'M Y' : 'j M Y', $date->getTimestamp() );
}

/**
 * Een korte datum onder de grafiek: 3 nov. voor een dag; nov. voor een maand, met het jaar erbij in januari en bij de
 * eerste maand.
 *
 * @param string $key   Y-m-d of Y-m.
 * @param bool   $first Of het de eerste datum van de reeks is.
 */
function _ww_stats_axis_date( string $key, bool $first ): string {
	$is_month = 7 === strlen( $key );
	$date     = DateTimeImmutable::createFromFormat( $is_month ? '!Y-m' : '!Y-m-d', $key, wp_timezone() );
	if ( false === $date ) {
		return $key;
	}
	$format = $is_month ? ( $first || '01' === $date->format( 'm' ) ? 'M Y' : 'M' ) : 'j M';
	return (string) wp_date( $format, $date->getTimestamp() );
}

/**
 * Een waarde op de as van de grafiek: hele getallen zonder decimalen, anders met één of twee.
 *
 * @param float $value Waarde.
 */
function _ww_stats_axis_value( float $value ): string {
	$decimals = 0;
	if ( abs( $value - round( $value ) ) > 0.001 ) {
		$decimals = abs( $value * 10 - round( $value * 10 ) ) > 0.001 ? 2 : 1;
	}
	return number_format_i18n( $value, $decimals );
}

/**
 * Tekent de grafiek als inline SVG: balken voor de bezoekers (grijs), een lijn voor de weergaven (de kleur van het
 * beheer, uit stats-admin.css).
 *
 * De grote grafiek heeft links een as met rasterlijnen op 0, ¼, ½, ¾ en het maximum (afgerond naar boven op 1, 2 of 5
 * × 10ⁿ), datums op vaste afstand, en per kolom een onzichtbaar vlak met een <title> (de waarden bij aanwijzen). De
 * mini-variant voor de dashboardwidget heeft geen tekst.
 *
 * @param array<string,array{views:int,visitors:int}> $series Reeks per dag (Y-m-d) of per maand (Y-m).
 * @param bool                                        $mini   Kleine variant voor de dashboardwidget.
 */
function _ww_stats_chart_svg( array $series, bool $mini = false ): string {
	if ( array() === $series ) {
		return '';
	}
	$width  = $mini ? 300 : 720;
	$height = $mini ? 60 : 230;
	$left   = $mini ? 0 : 40; // Ruimte links voor de waarden op de as.
	$right  = $mini ? 0 : 8;
	$top    = $mini ? 2 : 10;
	$plot   = $mini ? $height - 2 : $height - 26; // Onderkant van de grafiek; daaronder de datums.
	$keys   = array_map( 'strval', array_keys( $series ) );
	$count  = count( $keys );
	$max    = 1;
	foreach ( $series as $counts ) {
		$max = max( $max, $counts['views'], $counts['visitors'] );
	}
	if ( ! $mini ) {
		// Naar boven afronden op 1, 2 of 5 × 10ⁿ, zodat de waarden op de as rond zijn.
		$power = 10 ** (int) floor( log10( $max ) );
		$max   = $max <= $power ? $power : ( $max <= 2 * $power ? 2 * $power : ( $max <= 5 * $power ? 5 * $power : 10 * $power ) );
	}
	$step = ( $width - $left - $right ) / $count;
	$bar  = max( 1, $step * 0.6 );
	$y    = static fn( float $value ): float => $plot - ( $plot - $top ) * $value / $max;

	$first = _ww_stats_series_label( $keys[0] );
	$last  = _ww_stats_series_label( $keys[ $count - 1 ] );
	$label = sprintf(
		/* translators: 1: eerste datum, 2: laatste datum. */
		__( 'Grafiek van de weergaven (lijn) en de bezoekers (balken) van %1$s tot en met %2$s', 'webwerckt-base' ),
		$first,
		$last
	);

	$svg = '<svg class="ww-stats-chart' . ( $mini ? ' ww-stats-chart--mini' : '' ) . '" viewBox="0 0 ' . $width . ' ' . $height . '" role="img" aria-label="' . esc_attr( $label ) . '" focusable="false">';
	if ( $mini ) {
		$svg .= '<line class="ww-stats-axis" x1="0" y1="' . $plot . '" x2="' . $width . '" y2="' . $plot . '" stroke="#dcdcde"/>';
	} else {
		for ( $i = 0; $i <= 4; $i++ ) {
			$value = $max * $i / 4;
			$line  = sprintf( '%.1f', $y( $value ) );
			$svg  .= '<line class="' . ( 0 === $i ? 'ww-stats-axis' : 'ww-stats-grid' ) . '" x1="' . $left . '" y1="' . $line . '" x2="' . ( $width - $right ) . '" y2="' . $line . '" stroke="' . ( 0 === $i ? '#dcdcde' : '#f0f0f1' ) . '"/>';
			$svg  .= '<text class="ww-stats-axis-label" x="' . ( $left - 6 ) . '" y="' . sprintf( '%.1f', $y( $value ) + 4 ) . '" text-anchor="end">' . esc_html( _ww_stats_axis_value( (float) $value ) ) . '</text>';
		}
	}

	$points = array();
	$hits   = '';
	$dates  = '';
	$every  = $count <= 8 ? 1 : ( $count <= 12 ? 2 : ( $count <= 20 ? 3 : 7 ) );
	foreach ( $keys as $i => $key ) {
		$x        = $left + $i * $step;
		$visitors = $series[ $key ]['visitors'];
		$views    = $series[ $key ]['views'];
		$bar_h    = $plot - $y( $visitors );
		if ( $bar_h > 0 ) {
			$svg .= sprintf( '<rect class="ww-stats-bar" x="%.1f" y="%.1f" width="%.1f" height="%.1f" fill="#c3c4c7"/>', $x + ( $step - $bar ) / 2, $plot - $bar_h, $bar, $bar_h );
		}
		$points[] = sprintf( '%.1f,%.1f', $x + $step / 2, $y( $views ) );
		if ( $mini ) {
			continue;
		}
		$title = sprintf(
			/* translators: 1: datum, 2: aantal weergaven, 3: aantal bezoekers. */
			__( '%1$s: %2$s weergaven, %3$s bezoekers', 'webwerckt-base' ),
			_ww_stats_series_label( $key ),
			number_format_i18n( $views ),
			number_format_i18n( $visitors )
		);
		$hits .= sprintf( '<rect class="ww-stats-hit" x="%.1f" y="%d" width="%.1f" height="%d" fill="transparent"><title>%s</title></rect>', $x, $top, $step, $plot - $top, esc_html( $title ) );
		if ( 0 === $i % $every ) {
			$dates .= sprintf( '<text class="ww-stats-date" x="%.1f" y="%d" text-anchor="middle">%s</text>', $x + $step / 2, $height - 8, esc_html( _ww_stats_axis_date( $key, 0 === $i ) ) );
		}
	}

	if ( 1 === $count ) {
		// Eén punt geeft geen zichtbare lijn: dan een stip.
		list( $cx, $cy ) = explode( ',', $points[0] );
		$svg            .= '<circle class="ww-stats-dot" cx="' . esc_attr( $cx ) . '" cy="' . esc_attr( $cy ) . '" r="' . ( $mini ? 2 : 4 ) . '" fill="#2271b1"/>';
	} else {
		$svg .= '<polyline class="ww-stats-line" fill="none" stroke="#2271b1" stroke-width="2" points="' . esc_attr( implode( ' ', $points ) ) . '"/>';
	}
	return $svg . $dates . $hits . '</svg>';
}

/**
 * De reeks als tabel voor schermlezers, visueel verborgen.
 *
 * @param array<string,array{views:int,visitors:int}> $series Reeks per dag of per maand.
 */
function _ww_stats_chart_table( array $series ): string {
	$html  = '<table class="screen-reader-text">';
	$html .= '<caption>' . esc_html__( 'Weergaven en bezoekers per periode', 'webwerckt-base' ) . '</caption>';
	$html .= '<thead><tr><th scope="col">' . esc_html__( 'Datum', 'webwerckt-base' ) . '</th><th scope="col">' . esc_html__( 'Weergaven', 'webwerckt-base' ) . '</th><th scope="col">' . esc_html__( 'Bezoekers', 'webwerckt-base' ) . '</th></tr></thead>';
	$html .= '<tbody>';
	foreach ( $series as $key => $counts ) {
		$html .= '<tr><th scope="row">' . esc_html( _ww_stats_series_label( (string) $key ) ) . '</th><td>' . esc_html( number_format_i18n( $counts['views'] ) ) . '</td><td>' . esc_html( number_format_i18n( $counts['visitors'] ) ) . '</td></tr>';
	}
	return $html . '</tbody></table>';
}

/**
 * Een blok met een tabel: de eerste rijen zichtbaar, de rest (tot het maximum) in een uitklapper (zonder JS).
 *
 * Opties:
 * - open: aantal rijen dat open staat (10);
 * - max: aantal rijen in totaal (100);
 * - cards: tabel met ww-stats-table--cards en data-label per cel, voor de kaartweergave op smalle schermen;
 * - num_from: vanaf deze kolom rechts uitgelijnd (1);
 * - intro: geëscapete HTML tussen de titel en de tabel;
 * - outro: geëscapete HTML onder de tabel;
 * - empty: tekst bij geen rijen ("Geen gegevens in deze periode.");
 * - size: wide, narrow of full, voor de breedte in het raster van het Overzicht (klasse ww-stats-block--{size});
 * - shares: aandeel per rij in procenten (0–100), parallel aan $rows; geeft een balkje onder de rijkop.
 *
 * @param string              $title   Titel van het blok.
 * @param string[]            $headers Kolomkoppen.
 * @param list<list<string>>  $rows    Cellen als geëscapete HTML; de eerste cel is de rijkop.
 * @param array<string,mixed> $options Zie boven.
 */
function _ww_stats_block( string $title, array $headers, array $rows, array $options = array() ): string {
	$open     = (int) ( $options['open'] ?? 10 );
	$max      = (int) ( $options['max'] ?? 100 );
	$cards    = ! empty( $options['cards'] );
	$num_from = (int) ( $options['num_from'] ?? 1 );
	$size     = in_array( $options['size'] ?? '', array( 'wide', 'narrow', 'full' ), true ) ? ' ww-stats-block--' . $options['size'] : '';
	$shares   = is_array( $options['shares'] ?? null ) ? array_values( $options['shares'] ) : array();

	foreach ( $rows as $i => $cells ) {
		if ( isset( $shares[ $i ], $cells[0] ) ) {
			$rows[ $i ][0] .= '<span class="ww-stats-share" aria-hidden="true"><span style="width:' . max( 0, min( 100, (int) $shares[ $i ] ) ) . '%"></span></span>';
		}
	}

	$head = '<thead><tr>';
	foreach ( $headers as $i => $header ) {
		$head .= '<th scope="col"' . ( $i >= $num_from ? ' class="num"' : '' ) . '>' . esc_html( $header ) . '</th>';
	}
	$head .= '</tr></thead>';

	$table = static function ( array $part ) use ( $head, $headers, $cards, $num_from ): string {
		$html = '<table class="widefat striped ww-stats-table' . ( $cards ? ' ww-stats-table--cards' : '' ) . '">' . $head . '<tbody>';
		foreach ( $part as $cells ) {
			$html .= '<tr>';
			foreach ( array_values( $cells ) as $i => $cell ) {
				$label = $cards && isset( $headers[ $i ] ) ? ' data-label="' . esc_attr( $headers[ $i ] ) . '"' : '';
				if ( 0 === $i ) {
					$html .= '<th scope="row"' . $label . '>' . $cell . '</th>';
				} else {
					$html .= '<td' . ( $i >= $num_from ? ' class="num"' : '' ) . $label . '>' . $cell . '</td>';
				}
			}
			$html .= '</tr>';
		}
		return $html . '</tbody></table>';
	};

	$html = '<section class="ww-stats-block' . $size . '"><h2>' . esc_html( $title ) . '</h2>' . (string) ( $options['intro'] ?? '' );
	if ( array() === $rows ) {
		$empty = (string) ( $options['empty'] ?? __( 'Geen gegevens in deze periode.', 'webwerckt-base' ) );
		return $html . '<p class="description">' . esc_html( $empty ) . '</p></section>';
	}
	$html .= $table( array_slice( $rows, 0, $open ) );
	$more  = array_slice( $rows, $open, $max - $open );
	if ( array() !== $more ) {
		$html .= '<details><summary>' . esc_html__( 'Meer tonen', 'webwerckt-base' ) . '</summary>' . $table( $more ) . '</details>';
	}
	return $html . (string) ( $options['outro'] ?? '' ) . '</section>';
}

/**
 * Leest de periode uit het verzoek, schoongemaakt.
 *
 * @return array<string,string>
 */
function _ww_stats_admin_query(): array {
	$query = array();
	foreach ( array( 'range', 'from', 'to', 'tab', 'kind' ) as $key ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen lezen.
		$value = _ww_data_to_string( wp_unslash( $_GET[ $key ] ?? '' ) );
		if ( '' !== $value ) {
			$query[ $key ] = sanitize_text_field( $value );
		}
	}
	return $query;
}

/**
 * Een kerncijfer met het verschil: groen (is-good) als het verschil goed is, rood (is-bad) als het slecht is. Meestal
 * is stijgen goed; bij $lower_is_better is dalen goed.
 *
 * @param string   $label           Naam.
 * @param string   $value           Waarde als tekst.
 * @param int|null $change          Verschil in procenten.
 * @param bool     $lower_is_better Of dalen goed is.
 * @param string   $hint            Toelichting achter het verschil, bijvoorbeeld "lager is beter".
 */
function _ww_stats_card( string $label, string $value, ?int $change, bool $lower_is_better = false, string $hint = '' ): string {
	$class = '';
	if ( null !== $change && 0 !== $change ) {
		$class = ( $change > 0 ) !== $lower_is_better ? ' is-good' : ' is-bad';
	}
	return '<div class="ww-stats-card"><span class="ww-stats-card__label">' . esc_html( $label ) . '</span>'
		. '<span class="ww-stats-card__value">' . esc_html( $value ) . '</span>'
		. '<span class="ww-stats-card__change' . $class . '">' . esc_html( _ww_stats_format_change( $change ) )
		. ( '' !== $hint ? ' <span class="ww-stats-card__hint">' . esc_html( $hint ) . '</span>' : '' ) . '</span></div>';
}

/**
 * De tabbladen die er zijn: overview altijd, clicks, forms en journeys alleen als hun render-functie bestaat (Paden
 * komt in fase 2). Tabblad => render-functie; overview heeft er geen in deze lijst.
 *
 * @return array<string,string>
 */
function _ww_stats_tab_renderers(): array {
	$tabs = array( 'overview' => '' );
	foreach (
		array(
			'clicks'   => '_ww_stats_render_clicks',
			'forms'    => '_ww_stats_render_forms',
			'journeys' => '_ww_stats_render_journeys',
		) as $tab => $render
	) {
		if ( function_exists( $render ) ) {
			$tabs[ $tab ] = $render;
		}
	}
	return $tabs;
}

/**
 * Het gekozen tabblad: overview (standaard), of clicks, forms of journeys als dat tabblad er is
 * (_ww_stats_tab_renderers()). Alles anders wordt overview.
 *
 * @param array<string,mixed> $query Uit _ww_stats_admin_query().
 */
function _ww_stats_admin_tab( array $query ): string {
	$tab = $query['tab'] ?? '';
	return is_string( $tab ) && isset( _ww_stats_tab_renderers()[ $tab ] ) ? $tab : 'overview';
}

/**
 * Splitst een klik-item (kind|label|doel) op de eerste en de laatste |, zodat een | in het label blijft staan.
 * (overige) heeft geen soort en geen doel.
 *
 * @param string $item Sleutel uit de lijst click.
 * @return array{kind:string,label:string,target:string}
 */
function _ww_stats_click_parts( string $item ): array {
	$first = strpos( $item, '|' );
	$last  = strrpos( $item, '|' );
	if ( false === $first || $first === $last ) {
		return array(
			'kind'   => '',
			'label'  => $item,
			'target' => '',
		);
	}
	return array(
		'kind'   => substr( $item, 0, $first ),
		'label'  => substr( $item, $first + 1, $last - $first - 1 ),
		'target' => substr( $item, $last + 1 ),
	);
}

/**
 * Telt de acties van de periode: kliks per soort en verstuurde formulieren.
 *
 * @param array<string,list<array{item:string,views:int,visitors:int}>> $lists Uit _ww_stats_query().
 * @return array{tel:int,mailto:int,download:int,extern:int,sent:int}
 */
function _ww_stats_action_counts( array $lists ): array {
	$counts = array(
		'tel'      => 0,
		'mailto'   => 0,
		'download' => 0,
		'extern'   => 0,
		'sent'     => 0,
	);
	foreach ( $lists['click'] ?? array() as $entry ) {
		$kind = _ww_stats_click_parts( $entry['item'] )['kind'];
		if ( isset( $counts[ $kind ] ) && 'sent' !== $kind ) {
			$counts[ $kind ] += $entry['views'];
		}
	}
	foreach ( $lists['form'] ?? array() as $entry ) {
		if ( str_ends_with( $entry['item'], '|sent' ) ) {
			$counts['sent'] += $entry['views'];
		}
	}
	return $counts;
}

/**
 * De regels van het blok Acties: naam, tabblad en soort voor de link.
 *
 * @return array<string,array{label:string,tab:string,kind:string}>
 */
function _ww_stats_action_rows(): array {
	return array(
		'tel'      => array(
			'label' => __( 'Bellen', 'webwerckt-base' ),
			'tab'   => 'clicks',
			'kind'  => 'tel',
		),
		'mailto'   => array(
			'label' => __( 'Mail', 'webwerckt-base' ),
			'tab'   => 'clicks',
			'kind'  => 'mailto',
		),
		'download' => array(
			'label' => __( 'Downloads', 'webwerckt-base' ),
			'tab'   => 'clicks',
			'kind'  => 'download',
		),
		'extern'   => array(
			'label' => __( 'Externe links', 'webwerckt-base' ),
			'tab'   => 'clicks',
			'kind'  => 'extern',
		),
		'sent'     => array(
			'label' => __( 'Formulieren verstuurd', 'webwerckt-base' ),
			'tab'   => 'forms',
			'kind'  => '',
		),
	);
}

/**
 * Link naar een tabblad, met de periode (range, of from en to bij een eigen periode) van het scherm.
 *
 * @param array<string,string> $period Uit _ww_stats_period().
 * @param string               $tab    overview, clicks, forms of journeys.
 * @param array<string,string> $extra  Extra queryvariabelen.
 */
function _ww_stats_tab_url( array $period, string $tab, array $extra = array() ): string {
	$args = array();
	if ( 'custom' === $period['range'] ) {
		$args['from'] = $period['from'];
		$args['to']   = $period['to'];
	} else {
		$args['range'] = $period['range'];
	}
	if ( 'overview' !== $tab ) {
		$args['tab'] = $tab;
	}
	return _ww_stats_admin_url( $args + $extra );
}

/**
 * De namen van de onderdelen die er zijn (_ww_stats_tab_renderers()), op volgorde: tabblad => naam.
 *
 * @return array<string,string>
 */
function _ww_stats_section_labels(): array {
	$labels = array(
		'overview' => __( 'Overzicht', 'webwerckt-base' ),
		'clicks'   => __( 'Kliks', 'webwerckt-base' ),
		'forms'    => __( 'Formulieren', 'webwerckt-base' ),
		'journeys' => __( 'Paden', 'webwerckt-base' ),
	);
	return array_intersect_key( $labels, _ww_stats_tab_renderers() );
}

/**
 * De onderdelen als lijst met links, met de periode erin; het actieve krijgt aria-current. Twee vormen: panel (in het
 * zijpaneel, met een Dashicon) en menu (een uitklapper voor mobiel, met het actieve onderdeel in de summary).
 *
 * @param array<string,string> $period  Uit _ww_stats_period().
 * @param string               $active  Actief tabblad.
 * @param string               $variant panel of menu.
 * @return string Geëscapete HTML.
 */
function _ww_stats_render_nav( array $period, string $active, string $variant ): string {
	$icons  = array(
		'overview' => 'dashicons-chart-bar',
		'clicks'   => 'dashicons-admin-links',
		'forms'    => 'dashicons-feedback',
		'journeys' => 'dashicons-randomize',
	);
	$labels = _ww_stats_section_labels();
	$items  = '';
	foreach ( $labels as $tab => $label ) {
		$current = $tab === $active;
		$icon    = 'panel' === $variant ? '<span class="dashicons ' . esc_attr( $icons[ $tab ] ) . '" aria-hidden="true"></span>' : '';
		$items  .= '<li><a href="' . esc_url( _ww_stats_tab_url( $period, $tab ) ) . '"' . ( $current ? ' aria-current="page"' : '' ) . '>' . $icon . '<span>' . esc_html( $label ) . '</span></a></li>';
	}
	if ( 'panel' === $variant ) {
		return '<ul class="ww-stats-panel__nav">' . $items . '</ul>';
	}
	return '<details class="ww-stats-menu ww-stats-menu--section"><summary><span>' . esc_html__( 'Onderdeel', 'webwerckt-base' ) . '</span> <b>' . esc_html( $labels[ $active ] ?? '' ) . '</b></summary><ul>' . $items . '</ul></details>';
}

/**
 * Het Overzicht: kerncijfers, grafiek en blokken, met het blok Acties. Nu op de site staat in het zijpaneel.
 *
 * @param array<string,string> $period Uit _ww_stats_period().
 * @param string               $today  Vandaag, Y-m-d.
 */
function _ww_stats_render_overview( array $period, string $today ): void {
	$data   = _ww_stats_query( $period['from'], $period['to'], $today );
	$prev   = _ww_stats_query( $period['prev_from'], $period['prev_to'], $today );
	$totals = $data['totals'];
	$before = $prev['totals'];

	// 2. Vier kerncijfers. Verhoudingen worden vergeleken als gehele getallen (maal 1000).
	$per_visitor      = $totals['visitors'] > 0 ? $totals['views'] / $totals['visitors'] : 0.0;
	$prev_per_visitor = $before['visitors'] > 0 ? $before['views'] / $before['visitors'] : 0.0;
	$bounce           = $totals['visitors'] > 0 ? $totals['bounces'] / $totals['visitors'] : 0.0;
	$prev_bounce      = $before['visitors'] > 0 ? $before['bounces'] / $before['visitors'] : 0.0;

	// Kerncijfers en grafiek staan samen in één vak.
	echo '<section class="ww-stats-summary" aria-label="' . esc_attr__( 'Kerncijfers', 'webwerckt-base' ) . '">';
	echo '<div class="ww-stats-cards">';
	echo _ww_stats_card( __( 'Bezoekers', 'webwerckt-base' ), number_format_i18n( $totals['visitors'] ), _ww_stats_change( $totals['visitors'], $before['visitors'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_stats_card() escapet.
	echo _ww_stats_card( __( 'Weergaven', 'webwerckt-base' ), number_format_i18n( $totals['views'] ), _ww_stats_change( $totals['views'], $before['views'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_stats_card() escapet.
	echo _ww_stats_card( __( 'Weergaven per bezoeker', 'webwerckt-base' ), number_format_i18n( $per_visitor, 1 ), _ww_stats_change( (int) round( $per_visitor * 1000 ), (int) round( $prev_per_visitor * 1000 ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_stats_card() escapet.
	echo _ww_stats_card( __( 'Eén pagina', 'webwerckt-base' ), number_format_i18n( (int) round( $bounce * 100 ) ) . ' %', _ww_stats_change( (int) round( $bounce * 1000 ), (int) round( $prev_bounce * 1000 ) ), true, __( 'lager is beter', 'webwerckt-base' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_stats_card() escapet.
	echo '</div>';

	// 3. Grafiek: per dag, bij 12 maanden per maand, bij vandaag geen.
	if ( 'today' !== $period['range'] ) {
		$series = '12m' === $period['range'] ? _ww_stats_series_by_month( $data['series'] ) : $data['series'];
		echo '<div class="ww-stats-graph">';
		echo _ww_stats_chart_svg( $series ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_stats_chart_svg() escapet.
		echo '<p class="ww-stats-legend" aria-hidden="true"><span class="ww-stats-legend__line"></span>' . esc_html__( 'Weergaven', 'webwerckt-base' ) . ' <span class="ww-stats-legend__bar"></span>' . esc_html__( 'Bezoekers', 'webwerckt-base' ) . '</p>';
		echo _ww_stats_chart_table( $series ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_stats_chart_table() escapet.
		echo '</div>';
	}
	echo '</section>';

	// 4. Blokken: Pagina's en Herkomst breed, Apparaat, Land en Acties smal, Campagnes over de volle breedte. Het
	// balkje onder een naam is het aandeel: bij Pagina's en Herkomst ten opzichte van de grootste rij, bij Apparaat en
	// Land ten opzichte van alle bezoekers.
	$share  = static fn( int $part, int $whole ): int => $whole > 0 ? (int) round( $part / $whole * 100 ) : 0;
	$lists  = $data['lists'];
	$rows   = array();
	$shares = array();
	$top    = (int) max( array_merge( array( 0 ), array_column( $lists['page'] ?? array(), 'views' ) ) );
	foreach ( $lists['page'] ?? array() as $entry ) {
		$page     = _ww_stats_page_label( $entry['item'] );
		$name     = '' !== $page['url'] ? '<a href="' . esc_url( $page['url'] ) . '">' . esc_html( $page['label'] ) . '</a>' : esc_html( $page['label'] );
		$rows[]   = array( $name, esc_html( number_format_i18n( $entry['views'] ) ), esc_html( number_format_i18n( $entry['visitors'] ) ) );
		$shares[] = $share( $entry['views'], $top );
	}
	$blocks = _ww_stats_block(
		__( "Pagina's", 'webwerckt-base' ),
		array( __( 'Pagina', 'webwerckt-base' ), __( 'Weergaven', 'webwerckt-base' ), __( 'Bezoekers', 'webwerckt-base' ) ),
		$rows,
		array(
			'size'   => 'wide',
			'shares' => $shares,
		)
	);

	$rows   = array();
	$shares = array();
	$top    = (int) max( array_merge( array( 0 ), array_column( $lists['referrer'] ?? array(), 'visitors' ) ) );
	foreach ( $lists['referrer'] ?? array() as $entry ) {
		$rows[]   = array( esc_html( _ww_stats_referrer_label( $entry['item'] ) ), esc_html( number_format_i18n( $entry['visitors'] ) ) );
		$shares[] = $share( $entry['visitors'], $top );
	}
	$blocks .= _ww_stats_block(
		__( 'Herkomst', 'webwerckt-base' ),
		array( __( 'Bron', 'webwerckt-base' ), __( 'Bezoekers', 'webwerckt-base' ) ),
		$rows,
		array(
			'size'   => 'wide',
			'shares' => $shares,
		)
	);

	if ( array() !== ( $lists['campaign'] ?? array() ) ) {
		$rows = array();
		foreach ( $lists['campaign'] as $entry ) {
			$label  = '(overige)' === $entry['item'] ? __( 'Overige', 'webwerckt-base' ) : $entry['item'];
			$rows[] = array( esc_html( $label ), esc_html( number_format_i18n( $entry['visitors'] ) ) );
		}
		$blocks .= _ww_stats_block( __( 'Campagnes', 'webwerckt-base' ), array( __( 'Bron / medium / campagne', 'webwerckt-base' ), __( 'Bezoekers', 'webwerckt-base' ) ), $rows, array( 'size' => 'full' ) );
	}

	// Altijd drie regels, ook met 0 %.
	$devices = array_fill_keys( array( 'mobile', 'tablet', 'desktop' ), 0 );
	foreach ( $lists['device'] ?? array() as $entry ) {
		if ( isset( $devices[ $entry['item'] ] ) ) {
			$devices[ $entry['item'] ] = $entry['visitors'];
		}
	}
	$rows   = array();
	$shares = array();
	foreach ( $devices as $device => $visitors ) {
		$rows[]   = array( esc_html( _ww_stats_device_label( $device ) ), esc_html( _ww_stats_format_share( $visitors, $totals['visitors'] ) ) );
		$shares[] = $share( $visitors, $totals['visitors'] );
	}
	$blocks .= _ww_stats_block(
		__( 'Apparaat', 'webwerckt-base' ),
		array( __( 'Apparaat', 'webwerckt-base' ), __( 'Bezoekers', 'webwerckt-base' ) ),
		$rows,
		array(
			'size'   => 'narrow',
			'shares' => $shares,
		)
	);

	$rows   = array();
	$shares = array();
	foreach ( $lists['country'] ?? array() as $entry ) {
		$rows[]   = array( esc_html( _ww_stats_country_label( $entry['item'] ) ), esc_html( _ww_stats_format_share( $entry['visitors'], $totals['visitors'] ) ) );
		$shares[] = $share( $entry['visitors'], $totals['visitors'] );
	}
	$blocks .= _ww_stats_block(
		__( 'Land', 'webwerckt-base' ),
		array( __( 'Land', 'webwerckt-base' ), __( 'Bezoekers', 'webwerckt-base' ) ),
		$rows,
		array(
			'size'   => 'narrow',
			'shares' => $shares,
		)
	);

	// Acties: altijd tonen, ook met nullen.
	$actions = _ww_stats_action_counts( $lists );
	$rows    = array();
	foreach ( _ww_stats_action_rows() as $key => $row ) {
		$url    = _ww_stats_tab_url( $period, $row['tab'], '' !== $row['kind'] ? array( 'kind' => $row['kind'] ) : array() );
		$rows[] = array( '<a href="' . esc_url( $url ) . '">' . esc_html( $row['label'] ) . '</a>', esc_html( number_format_i18n( $actions[ $key ] ) ) );
	}
	$blocks .= _ww_stats_block( __( 'Acties', 'webwerckt-base' ), array( __( 'Actie', 'webwerckt-base' ), __( 'Aantal', 'webwerckt-base' ) ), $rows, array( 'size' => 'narrow' ) );

	echo '<div class="ww-stats-blocks">' . $blocks . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_stats_block() en de cellen zijn geëscapet.
}

/**
 * Verborgen velden voor de periodekeuze, zodat een andere periode op hetzelfde tabblad blijft met dezelfde filters:
 * tab (behalve bij Overzicht), bij Kliks een geldige kind, bij Paden sent, contact en entry zoals
 * _ww_stats_journey_filters() ze goedkeurt. De pagina (paged) gaat niet mee: een andere periode begint op 1.
 *
 * @param string              $tab   Actief tabblad, uit _ww_stats_admin_tab().
 * @param array<string,mixed> $query Uit _ww_stats_admin_query().
 */
function _ww_stats_period_fields( string $tab, array $query ): string {
	if ( 'overview' === $tab ) {
		return '';
	}
	$args = array( 'tab' => $tab );
	if ( 'clicks' === $tab && '' !== _ww_stats_click_kind( $query ) ) {
		$args['kind'] = _ww_stats_click_kind( $query );
	} elseif ( 'journeys' === $tab ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen lezen; de filters lezen $_GET zelf (zie _ww_stats_render_journeys()).
		$args += _ww_stats_journey_args( _ww_stats_journey_filters( wp_unslash( $_GET ) ) );
	}
	$html = '';
	foreach ( $args as $name => $value ) {
		$html .= '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '">';
	}
	return $html;
}

/**
 * De periodekeuze, op hetzelfde tabblad en met dezelfde filters. Twee formulieren: Enter in een datumveld mag niet de
 * eerste periodeknop (Vandaag) versturen. Twee vormen:
 * - bar: een knoppengroep in de kop, met "Aangepast…" als uitklapper met het eigen formulier (open bij een eigen
 *   periode);
 * - menu: een uitklapper voor mobiel, met de gekozen periode in de summary en de velden met een eigen id (-m).
 *
 * @param array<string,string> $period  Uit _ww_stats_period().
 * @param string               $today   Vandaag, Y-m-d.
 * @param string               $keep    Verborgen velden uit _ww_stats_period_fields().
 * @param string               $variant bar of menu.
 * @return string Geëscapete HTML.
 */
function _ww_stats_render_period( array $period, string $today, string $keep, string $variant ): string {
	$ranges = array(
		'today' => __( 'Vandaag', 'webwerckt-base' ),
		'7d'    => __( '7 dagen', 'webwerckt-base' ),
		'30d'   => __( '30 dagen', 'webwerckt-base' ),
		'12m'   => __( '12 maanden', 'webwerckt-base' ),
	);
	$custom = 'custom' === $period['range'];
	$suffix = 'menu' === $variant ? '-m' : '';
	$action = esc_url( admin_url( 'admin.php' ) );
	$page   = '<input type="hidden" name="page" value="' . esc_attr( WW_STATS_PAGE ) . '">';

	$buttons = '<form method="get" action="' . $action . '" class="ww-stats-ranges" role="group" aria-label="' . esc_attr__( 'Periode', 'webwerckt-base' ) . '">' . $page . $keep;
	foreach ( $ranges as $range => $label ) {
		$buttons .= '<button type="submit" name="range" value="' . esc_attr( $range ) . '" class="button" aria-pressed="' . ( $range === $period['range'] ? 'true' : 'false' ) . '">' . esc_html( $label ) . '</button>';
	}
	$buttons .= '</form>';

	$form  = '<form method="get" action="' . $action . '" class="ww-stats-custom">' . $page . $keep;
	$form .= '<label for="ww-stats-from' . $suffix . '">' . esc_html__( 'Van', 'webwerckt-base' ) . '</label> ';
	$form .= '<input type="date" id="ww-stats-from' . $suffix . '" name="from" value="' . esc_attr( $period['from'] ) . '" max="' . esc_attr( $today ) . '"> ';
	$form .= '<label for="ww-stats-to' . $suffix . '">' . esc_html__( 'Tot en met', 'webwerckt-base' ) . '</label> ';
	$form .= '<input type="date" id="ww-stats-to' . $suffix . '" name="to" value="' . esc_attr( $period['to'] ) . '" max="' . esc_attr( $today ) . '"> ';
	$form .= '<button type="submit" class="button">' . esc_html__( 'Toon periode', 'webwerckt-base' ) . '</button></form>';

	if ( 'menu' === $variant ) {
		$label = $custom ? __( 'Aangepast', 'webwerckt-base' ) : ( $ranges[ $period['range'] ] ?? '' );
		return '<details class="ww-stats-menu ww-stats-menu--period"><summary><span>' . esc_html__( 'Periode', 'webwerckt-base' ) . '</span> <b>' . esc_html( $label ) . '</b></summary>'
			. '<div class="ww-stats-menu__body">' . $buttons . $form . '</div></details>';
	}
	return '<div class="ww-stats-period">' . $buttons
		. '<details class="ww-stats-custom-toggle"' . ( $custom ? ' open' : '' ) . '><summary class="button">' . esc_html__( 'Aangepast…', 'webwerckt-base' ) . '</summary>' . $form . '</details></div>';
}

/**
 * Toont het scherm: links het zijpaneel (onderdelen, Nu op de site), rechts de kop met de periode, de inhoud van het
 * onderdeel en de voettekst. Op mobiel nemen kiezers (<details>) bovenaan de inhoud het zijpaneel over.
 */
function _ww_stats_admin_render(): void {
	if ( ! current_user_can( 'edit_others_pages' ) ) {
		wp_die( esc_html__( 'Je hebt geen rechten om de statistieken te bekijken.', 'webwerckt-base' ), 403 );
	}

	$mu_notice = _ww_stats_mu_plugin_ok() ? '' : '<div class="notice notice-warning inline"><p>' . esc_html__( 'De mu-plugin webwerckt-base-stats.php staat niet in wp-content/mu-plugins. Het thema zet hem daar zelf neer, maar dat lukte niet: geen schrijfrechten, of bestandswijzigingen staan uit (DISALLOW_FILE_MODS). Zonder die mu-plugin wordt er niet gemeten.', 'webwerckt-base' ) . '</p></div>';

	if ( ! _ww_stats_ready() ) {
		echo '<div class="wrap ww-stats"><h1>' . esc_html__( 'Statistieken', 'webwerckt-base' ) . '</h1>' . $mu_notice; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $mu_notice is hierboven geëscapet.
		echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'De statistieken zijn nog niet klaar voor gebruik. Open dit scherm opnieuw.', 'webwerckt-base' ) . '</p></div></div>';
		return;
	}

	$today  = (string) wp_date( 'Y-m-d' );
	$query  = _ww_stats_admin_query();
	$period = _ww_stats_period( $query, $today );
	_ww_stats_aggregate( $today );
	$tab    = _ww_stats_admin_tab( $query );
	$keep   = _ww_stats_period_fields( $tab, $query );
	$rt     = _ww_stats_realtime();

	echo '<div class="wrap ww-stats"><div class="ww-stats-layout">';

	// Zijpaneel: onderdelen en Nu op de site.
	echo '<nav class="ww-stats-panel" aria-label="' . esc_attr__( 'Onderdelen van de statistieken', 'webwerckt-base' ) . '">';
	echo '<p class="ww-stats-panel__title">' . esc_html__( 'Statistieken', 'webwerckt-base' ) . '</p><p class="ww-stats-panel__sub">' . esc_html__( 'Zonder cookies gemeten', 'webwerckt-base' ) . '</p>';
	echo _ww_stats_render_nav( $period, $tab, 'panel' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_stats_render_nav() escapet.
	echo _ww_stats_realtime_html( $rt, false ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_stats_realtime_html() escapet.
	echo '</nav>';

	// Hoofdkolom: kop met de naam van het onderdeel en de periode; daarna zet WordPress zijn meldingen neer.
	echo '<div class="ww-stats-main">';
	echo '<div class="ww-stats-head"><h1>' . esc_html( _ww_stats_section_labels()[ $tab ] ?? '' ) . '</h1>';

	echo _ww_stats_render_period( $period, $today, $keep, 'bar' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_stats_render_period() escapet.
	echo '</div><hr class="wp-header-end">';
	echo $mu_notice; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hierboven geëscapet.

	// Op mobiel: kiezers voor onderdeel en periode, en Nu op de site als één regel.
	echo '<div class="ww-stats-pickers">';
	echo _ww_stats_render_nav( $period, $tab, 'menu' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_stats_render_nav() escapet.
	echo _ww_stats_render_period( $period, $today, $keep, 'menu' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_stats_render_period() escapet.
	echo '</div>';
	echo _ww_stats_realtime_html( $rt, true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_stats_realtime_html() escapet.

	if ( ! _ww_stats_has_data() ) {
		echo '<div class="notice notice-info inline"><p>' . esc_html__( 'Nog geen bezoeken gemeten. Het tellen begint bij het eerste bezoek van iemand die niet is ingelogd.', 'webwerckt-base' ) . '</p></div>';
	} else {
		echo '<p class="ww-stats-range">' . esc_html(
			sprintf(
				/* translators: 1: eerste datum, 2: laatste datum. */
				__( '%1$s tot en met %2$s', 'webwerckt-base' ),
				_ww_stats_series_label( $period['from'] ),
				_ww_stats_series_label( $period['to'] )
			)
		) . '</p>';

		// _ww_stats_admin_tab() geeft alleen een tabblad dat er is; zonder render-functie (een tabblad dat nog niet is
		// gebouwd) is het al overview, en dan is ook Overzicht actief.
		$render = _ww_stats_tab_renderers()[ $tab ];
		if ( '' !== $render ) {
			$render( $period, $query );
		} else {
			_ww_stats_render_overview( $period, $today );
		}
	}

	// Voettekst.
	echo '<p class="ww-stats-footer description">' . esc_html__( 'Gemeten zonder cookies. Bezoekers zijn per dag geteld: wie op twee dagen komt, telt twee keer. Ingelogde gebruikers en bots tellen niet mee.', 'webwerckt-base' ) . '</p>';
	echo '</div></div></div>';
}

/**
 * Zet de widget Statistieken op het dashboard, met hetzelfde recht als het scherm.
 */
function _ww_stats_dashboard_widget(): void {
	if ( ! current_user_can( 'edit_others_pages' ) ) {
		return;
	}
	wp_add_dashboard_widget( WW_STATS_PAGE, __( 'Statistieken', 'webwerckt-base' ), '_ww_stats_dashboard_render' );
}
add_action( 'wp_dashboard_setup', '_ww_stats_dashboard_widget' );

/**
 * De widget: bezoekers en weergaven van de laatste 7 dagen met het verschil, een mini-grafiek en een link.
 */
function _ww_stats_dashboard_render(): void {
	if ( ! current_user_can( 'edit_others_pages' ) ) {
		return;
	}
	if ( ! _ww_stats_ready() ) {
		echo '<p>' . esc_html__( 'De statistieken zijn nog niet klaar voor gebruik.', 'webwerckt-base' ) . '</p>';
		return;
	}
	$today  = (string) wp_date( 'Y-m-d' );
	$period = _ww_stats_period( array( 'range' => '7d' ), $today );
	_ww_stats_aggregate( $today );
	$data   = _ww_stats_query( $period['from'], $period['to'], $today );
	$before = _ww_stats_query( $period['prev_from'], $period['prev_to'], $today )['totals'];
	$totals = $data['totals'];

	echo '<div class="ww-stats ww-stats-widget">';
	echo _ww_stats_realtime_html( _ww_stats_realtime(), true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_stats_realtime_html() escapet.
	echo '<p class="description">' . esc_html__( 'De laatste 7 dagen, vergeleken met de 7 dagen ervoor.', 'webwerckt-base' ) . '</p>';
	echo '<div class="ww-stats-cards">';
	echo _ww_stats_card( __( 'Bezoekers', 'webwerckt-base' ), number_format_i18n( $totals['visitors'] ), _ww_stats_change( $totals['visitors'], $before['visitors'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_stats_card() escapet.
	echo _ww_stats_card( __( 'Weergaven', 'webwerckt-base' ), number_format_i18n( $totals['views'] ), _ww_stats_change( $totals['views'], $before['views'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_stats_card() escapet.
	echo '</div>';
	echo _ww_stats_chart_svg( $data['series'], true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_stats_chart_svg() escapet.
	echo '<p><a href="' . esc_url( _ww_stats_admin_url() ) . '">' . esc_html__( 'Alle statistieken', 'webwerckt-base' ) . '</a></p>';
	echo '</div>';
}
