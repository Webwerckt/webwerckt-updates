<?php
/**
 * Standaarden en opschoning: theme supports, wp_head-rommel, emoji, blok-CSS, speculative loading, afbeeldingsformaten,
 * geen gebruikersnamen via ?author=, auteursarchieven, de inlogmelding of Wachtwoord vergeten, geen WordPress-versie
 * in generator-regels en ?ver=, en XML-RPC zonder inloggen.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// De bestandseditor in WordPress staat uit: elke wijziging loopt via Git.
if ( ! defined( 'DISALLOW_FILE_EDIT' ) ) {
	define( 'DISALLOW_FILE_EDIT', true );
}

/**
 * Theme supports.
 */
function _ww_setup_theme(): void {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support(
		'html5',
		array( 'search-form', 'gallery', 'caption', 'style', 'script' )
	);
}
add_action( 'after_setup_theme', '_ww_setup_theme' );

/**
 * Haalt rommel uit wp_head en zet emoji-scripts uit.
 */
function _ww_cleanup_head(): void {
	remove_action( 'wp_head', 'rsd_link' );
	remove_action( 'wp_head', 'wlwmanifest_link' );
	remove_action( 'wp_head', 'wp_generator' );
	remove_action( 'wp_head', 'wp_shortlink_wp_head' );
	remove_action( 'wp_head', 'rest_output_link_wp_head' );
	remove_action( 'template_redirect', 'rest_output_link_header', 11 );
	remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
	remove_action( 'template_redirect', 'wp_shortlink_header', 11 );

	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
	remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
	remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
	remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
	add_filter( 'emoji_svg_url', '__return_false' );
}
add_action( 'init', '_ww_cleanup_head' );

// Geen versie van WordPress in de head, de feeds (RSS, Atom) en de export: zo zoekt niemand gericht naar lekken van
// die versie. Dit filter dekt elke plek waar WordPress een generator-regel schrijft.
add_filter( 'the_generator', '__return_empty_string' );

/**
 * Vervangt de versie van WordPress in ?ver= van stylesheets en scripts (de standaardversie van alles uit wp-includes
 * en wp-admin, ook op het inlogscherm) door een gezouten hash ervan. De URL verandert nog steeds bij een update, zodat
 * de browsercache van een jaar (regel 124) de nieuwe bestanden ophaalt, maar de versie is er niet meer uit af te lezen.
 * Na _ww_asset_version(), dat bestanden uit het child-thema al de wijzigingsdatum geeft.
 *
 * @param mixed $src URL van de stylesheet of het script.
 * @return mixed
 */
function _ww_hide_core_version( $src ) {
	if ( ! is_string( $src ) || ! str_contains( $src, 'ver=' ) ) {
		return $src;
	}
	wp_parse_str( (string) wp_parse_url( $src, PHP_URL_QUERY ), $query );
	$version = get_bloginfo( 'version' );
	if ( _ww_data_to_string( $query['ver'] ?? '' ) !== $version ) {
		return $src;
	}
	return add_query_arg( 'ver', substr( wp_hash( 'ww-ver-' . $version ), 0, 8 ), $src );
}
add_filter( 'style_loader_src', '_ww_hide_core_version', 20 );
add_filter( 'script_loader_src', '_ww_hide_core_version', 20 );
add_filter( 'script_module_loader_src', '_ww_hide_core_version', 20 );

/**
 * Geen CSS van blokken en global styles op de frontend: de editor staat uit en het child-thema rendert geen blokken.
 * Voor WordPress 6.9 is dat de hele block-library; daarna nog een basisbestand, classic-theme-styles en de
 * inline CSS-variabelen van global styles, die WordPress in de footer klaarzet (prioriteit 1) en naar de head verplaatst.
 */
function _ww_dequeue_block_styles(): void {
	/**
	 * Laadt de CSS van blokken toch, voor een child-thema dat wel blokken toont.
	 *
	 * @param bool $load Standaard false.
	 */
	if ( apply_filters( 'ww_block_styles', false ) ) {
		return;
	}
	foreach ( array( 'wp-block-library', 'wp-block-library-theme', 'classic-theme-styles', 'global-styles', 'wp-global-styles-placeholder' ) as $handle ) {
		wp_dequeue_style( $handle );
	}
}
add_action( 'wp_enqueue_scripts', '_ww_dequeue_block_styles', 100 );
add_action( 'wp_footer', '_ww_dequeue_block_styles', 2 );

/**
 * Laat WordPress de global styles niet eens berekenen: dat leest de opgeslagen stijlen van het thema
 * (vier query's per pagina), ook als _ww_dequeue_block_styles() het resultaat daarna weghaalt.
 * Zonder theme.json leveren ook de lettertypen uit theme.json niets op, dus die hoeven niet gelezen.
 */
function _ww_skip_global_styles(): void {
	/** Dit filter staat beschreven bij _ww_dequeue_block_styles(). */
	if ( apply_filters( 'ww_block_styles', false ) ) {
		return;
	}
	remove_action( 'wp_enqueue_scripts', 'wp_enqueue_global_styles' );
	remove_action( 'wp_footer', 'wp_enqueue_global_styles', 1 );
	if ( ! wp_theme_has_theme_json() ) {
		remove_action( 'wp_head', 'wp_print_font_faces', 50 );
		remove_action( 'wp_head', 'wp_print_font_faces_from_style_variations', 50 );
	}
}
add_action( 'wp_head', '_ww_skip_global_styles', 0 );

/**
 * Registreert voor bezoekers geen blokken, blokpatronen, block bindings, iconen en lettertypecollecties: het
 * child-thema rendert geen blokken en de editor staat uit. Dat scheelt een groot deel van init (op de testsite
 * 10 tot 25 ms) en de twee transient-query's van de patronen in het thema. In de admin, de REST API en voor
 * ingelogde gebruikers blijft alles geregistreerd. Ook dit volgt het filter ww_block_styles.
 *
 * Op naam, zodat blokken die WordPress later toevoegt ook wegblijven.
 *
 * @param bool|null $visitor Of dit een bezoeker is; null bepaalt het met _ww_is_visitor_request().
 */
function _ww_skip_block_registration( ?bool $visitor = null ): void {
	/** Dit filter staat beschreven bij _ww_dequeue_block_styles(). */
	if ( apply_filters( 'ww_block_styles', false ) || ! ( $visitor ?? _ww_is_visitor_request() ) ) {
		return;
	}
	global $wp_filter;
	$pattern = '/^(register_block_core_|register_core_block_|register_legacy_post_comments_block$|wp_register_core_block_metadata_collection$|_register_block_bindings_|_register_(core|theme)_block_patterns|_wp_register_default_(icons|icon_collections|font_collections)$|WP_Block_Supports::init$)/';
	foreach ( $wp_filter['init']->callbacks ?? array() as $priority => $callbacks ) {
		foreach ( $callbacks as $callback ) {
			$function = $callback['function'];
			$name     = is_array( $function ) && is_string( $function[0] ?? null ) ? $function[0] . '::' . _ww_data_to_string( $function[1] ?? '' ) : $function;
			if ( is_string( $name ) && preg_match( $pattern, $name ) ) {
				remove_action( 'init', $function, $priority );
			}
		}
	}
}
// Zonder argumenten: do_action( 'init' ) geeft '' mee, en dat wordt false voor $visitor (dus nooit een bezoeker).
add_action( 'init', '_ww_skip_block_registration', -1, 0 );

/**
 * Speculative loading (WordPress 6.8+): de browser haalt een pagina al op zodra de muis even op een link staat,
 * in plaats van pas bij het klikken. De pagina komt meestal uit de LiteSpeed-cache, en prefetch voert geen
 * JavaScript uit, dus statistieken tellen niets dubbel. Staat het uit (null, zoals voor ingelogde gebruikers),
 * dan blijft het uit.
 *
 * @param mixed $config Instelling van WordPress.
 * @return mixed
 */
function _ww_speculation_rules( $config ) {
	if ( ! is_array( $config ) ) {
		return $config;
	}
	return array(
		'mode'      => 'prefetch',
		'eagerness' => 'moderate',
	);
}
add_filter( 'wp_speculation_rules_configuration', '_ww_speculation_rules' );

/**
 * Zet overbodige standaardformaten van WordPress uit; het child-thema registreert zijn eigen formaten.
 *
 * @param array<string,array<string,mixed>> $sizes
 * @return array<string,array<string,mixed>>
 */
function _ww_remove_default_image_sizes( array $sizes ): array {
	unset( $sizes['medium_large'], $sizes['1536x1536'], $sizes['2048x2048'] );
	return $sizes;
}
add_filter( 'intermediate_image_sizes_advanced', '_ww_remove_default_image_sizes' );

/**
 * Staan de auteursarchieven (/author/<naam>/) aan? Alleen als ze in zoekmachines mogen (Site-instellingen, SEO,
 * seo_index_author). Hun URL is de loginnaam (user_nicename), dus wie namen raadt, ziet aan een 200 of een 404 welke
 * bestaan.
 */
function _ww_author_archives_enabled(): bool {
	/**
	 * Zet de auteursarchieven aan of uit, los van de instelling Auteurspagina's in zoekmachines.
	 *
	 * @param bool $enabled Standaard de instelling seo_index_author.
	 */
	return (bool) apply_filters( 'ww_author_archives', _ww_data_to_bool( _ww_data_get_setting( 'seo_index_author' ) ) );
}

/**
 * Geen gebruikersnamen opvragen (beslissing 0027). Twee manieren worden een 404, voor iedereen:
 *
 * - ?author=: WordPress stuurt /?author=1 door naar /author/<gebruikersnaam>/, en zo loopt iemand alle gebruikers af;
 * - /author/<naam>/ (de queryvariabele author_name), ook de feed ervan, zolang de auteursarchieven uit staan
 *   (_ww_author_archives_enabled()): anders bevestigt een 200 dat een geraden loginnaam bestaat.
 *
 * Niet in het beheer: daar filtert ?author= de berichtenlijst.
 *
 * @param array<string,mixed> $query_vars Queryvariabelen van het verzoek.
 * @return array<string,mixed>
 */
function _ww_block_author_query( array $query_vars ): array {
	if ( is_admin() ) {
		return $query_vars;
	}
	if ( isset( $query_vars['author'] ) || ( isset( $query_vars['author_name'] ) && ! _ww_author_archives_enabled() ) ) {
		return array( 'error' => '404' );
	}
	return $query_vars;
}
add_filter( 'request', '_ww_block_author_query' );

/**
 * XML-RPC zonder de methodes die inloggen vragen (wp.getUsersBlogs, wp.newPost en de rest): bots gebruiken die om
 * wachtwoorden te raden, buiten het inlogscherm om. ManageWP werkt met zijn eigen worker-plugin en heeft het niet
 * nodig; de pingbacks staan al uit (inc/comments.php).
 *
 * @return bool
 */
function _ww_xmlrpc_enabled(): bool {
	/**
	 * Zet de XML-RPC-methodes met inloggen weer aan, bijvoorbeeld voor Jetpack of een app die XML-RPC gebruikt.
	 *
	 * @param bool $enabled Standaard false.
	 */
	return (bool) apply_filters( 'ww_xmlrpc', false );
}
add_filter( 'xmlrpc_enabled', '_ww_xmlrpc_enabled' );

// Foutcodes van WordPress die verraden of een gebruikersnaam of e-mailadres bestaat.
const WW_LOGIN_REVEALING_ERRORS = array( 'invalid_username', 'invalid_email', 'incorrect_password' );

/**
 * Eén melding bij een mislukte login, of de gebruikersnaam nu bestaat of niet. WordPress zegt anders "het wachtwoord
 * voor gebruikersnaam X klopt niet", en dan weet iemand welke namen bestaan. Ook voor een applicatiewachtwoord.
 * Andere fouten (een leeg veld, een geblokkeerde gebruiker) blijven zoals ze zijn.
 *
 * @param mixed $user Gebruiker, null of een fout van een eerdere controle.
 * @return mixed
 */
function _ww_generic_login_error( $user ) {
	if ( ! is_wp_error( $user ) || array() === array_intersect( $user->get_error_codes(), WW_LOGIN_REVEALING_ERRORS ) ) {
		return $user;
	}
	return new WP_Error( 'ww_invalid_login', __( '<strong>Fout:</strong> de gebruikersnaam of het wachtwoord klopt niet.', 'webwerckt-base' ) );
}
add_filter( 'authenticate', '_ww_generic_login_error', 100 );

/**
 * Verraadt Wachtwoord vergeten dat een account niet bestaat? WordPress meldt dan "er is geen account met die
 * gebruikersnaam of dat e-mailadres", en stuurt bij een bestaand account door naar "controleer je e-mail".
 * Alleen als er verder geen fout is (een leeg veld blijft een fout).
 *
 * @param WP_Error      $errors    Fouten tot nu toe.
 * @param WP_User|false $user_data Het account, of false als het niet bestaat.
 */
function _ww_lostpassword_reveals_unknown( WP_Error $errors, $user_data ): bool {
	return ! $user_data instanceof WP_User && array() === array_diff( $errors->get_error_codes(), array( 'invalid_email' ) );
}

/**
 * Geeft op wp-login.php bij een onbekend account hetzelfde antwoord als bij een bestaand account: door naar "controleer
 * je e-mail", net als wp-login.php zelf na een geslaagde aanvraag. Er gaat geen mail weg. Andere aanroepen van
 * retrieve_password() (de gebruikerslijst in het beheer, REST, WP-CLI) blijven een fout geven.
 *
 * @param WP_Error      $errors    Fouten tot nu toe.
 * @param WP_User|false $user_data Het account, of false als het niet bestaat.
 */
function _ww_lostpassword_hide_unknown( WP_Error $errors, $user_data ): void {
	if ( 'wp-login.php' !== ( $GLOBALS['pagenow'] ?? '' ) || ! _ww_lostpassword_reveals_unknown( $errors, $user_data ) ) {
		return;
	}
	// Precies zoals wp-login.php na een geslaagde aanvraag: elk verschil (opschonen, een filter) zou bij een bedachte
	// redirect_to weer laten zien of het account bestaat. wp_safe_redirect() schoont op en weigert andere hosts.
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput -- zie hierboven.
	$redirect_to = ! empty( $_REQUEST['redirect_to'] ) ? $_REQUEST['redirect_to'] : 'wp-login.php?checkemail=confirm';
	wp_safe_redirect( $redirect_to );
	exit;
}
add_action( 'lostpassword_post', '_ww_lostpassword_hide_unknown', 100, 2 );
