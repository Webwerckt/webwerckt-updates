<?php
/**
 * Paginacache: de sleutel en het serveren (beslissing 0028). Gedeeld door de mu-plugin en het thema.
 *
 * De mu-plugin webwerckt-base-page-cache.php laadt dit bestand vóór de plugins en het thema, en roept
 * _ww_page_cache_serve() aan. Daarom gebruikt dit bestand alleen WordPress zelf, niets uit de rest van het thema.
 * Mu-plugin en functions.php laden het allebei met require_once en hetzelfde pad (get_template_directory()),
 * dus het wordt één keer geladen.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Parameters die niet meetellen voor de sleutel; een * aan het eind is een voorvoegsel. Het thema houdt de
// gefilterde lijst bij in de optie WW_PAGE_CACHE_PARAMS_OPTION (filter ww_page_cache_ignored_params).
const WW_PAGE_CACHE_IGNORED_PARAMS = array( 'utm_*', 'gclid', 'gbraid', 'wbraid', 'fbclid', 'msclkid', 'mc_cid', 'mc_eid', '_ga', '_gl', 'ref' );
const WW_PAGE_CACHE_PARAMS_OPTION  = 'ww_page_cache_params';

// Hosts naast die van de site-URL (een domein per taal), bijgehouden door het thema (filter ww_page_cache_hosts).
const WW_PAGE_CACHE_HOSTS_OPTION = 'ww_page_cache_hosts';

// Cookies waarmee een bezoeker iets eigens ziet: ingelogd, een wachtwoord voor een bericht, een eigen reactie.
const WW_PAGE_CACHE_SKIP_COOKIES = array( 'wordpress_logged_in_', 'wp-postpass_', 'comment_author_' );

// Naam van de HTML naast meta.json. index.html kan de server ook zonder PHP sturen (inc/page-cache-static.php,
// beslissing 0029); page.html alleen PHP: een pad zonder slash aan het eind, of een pagina met headers die een statisch
// bestand niet meekrijgt (X-Robots-Tag, Link, Content-Language).
const WW_PAGE_CACHE_STATIC_FILE = 'index.html';
const WW_PAGE_CACHE_PHP_FILE    = 'page.html';

// Cacheplugins met een eigen paginacache: is er een actief, dan doet de cache van het thema niets.
const WW_PAGE_CACHE_OTHER_PLUGINS = array(
	'litespeed-cache/litespeed-cache.php',
	'wp-fastest-cache/wpFastestCache.php',
	'wp-rocket/wp-rocket.php',
	'w3-total-cache/w3-total-cache.php',
	'wp-super-cache/wp-cache.php',
	'cache-enabler/cache-enabler.php',
	'sg-cachepress/sg-cachepress.php',
	'breeze/breeze.php',
	'hummingbird-performance/wp-hummingbird.php',
	'comet-cache/comet-cache.php',
);

/**
 * Map van de cache: wp-content/cache/ww-pages.
 */
function _ww_page_cache_dir(): string {
	return WP_CONTENT_DIR . '/cache/ww-pages';
}

/**
 * Bestand met het moment van de laatste purge, naast de map: een pagina die is opgebouwd vóór dat moment is oud,
 * ook als hij na de purge nog werd geschreven, of als het hernoemen van de map mislukte.
 */
function _ww_page_cache_marker_file(): string {
	return _ww_page_cache_dir() . '.purged';
}

/**
 * Waarom de cache uit staat, of '' als niets hem tegenhoudt. Dit deel geldt ook voor de mu-plugin; het thema
 * voegt er in _ww_page_cache_status() de redenen aan toe die alleen het thema kent.
 */
function _ww_page_cache_off_reason(): string {
	if ( defined( 'WW_PAGE_CACHE' ) && ! WW_PAGE_CACHE ) {
		return 'constant';
	}
	// Alleen op productie, tenzij WW_PAGE_CACHE true is: op local en staging ziet de klant anders een oude versie.
	if ( ! defined( 'WW_PAGE_CACHE' ) && 'production' !== wp_get_environment_type() ) {
		return 'environment';
	}
	if ( ! function_exists( 'wp_start_template_enhancement_output_buffer' ) ) {
		return 'wordpress';
	}
	if ( '' !== _ww_page_cache_other_plugin() ) {
		return 'plugin';
	}
	if ( defined( 'WP_CACHE' ) && WP_CACHE && file_exists( WP_CONTENT_DIR . '/advanced-cache.php' ) ) {
		return 'advanced-cache';
	}
	return '';
}

/**
 * De actieve cacheplugin met een eigen paginacache (pad ten opzichte van de pluginmap), of ''.
 */
function _ww_page_cache_other_plugin(): string {
	$plugins = (array) get_option( 'active_plugins', array() );
	$network = is_multisite() ? array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) : array();
	foreach ( WW_PAGE_CACHE_OTHER_PLUGINS as $plugin ) {
		if ( in_array( $plugin, $plugins, true ) || in_array( $plugin, $network, true ) ) {
			return $plugin;
		}
	}
	return '';
}

/**
 * Parameters die niet meetellen voor de sleutel, zoals het thema ze voor het laatst opsloeg.
 *
 * @return string[]
 */
function _ww_page_cache_ignored_params(): array {
	$params = get_option( WW_PAGE_CACHE_PARAMS_OPTION );
	return is_array( $params ) ? array_values( array_filter( $params, 'is_string' ) ) : WW_PAGE_CACHE_IGNORED_PARAMS;
}

/**
 * Hosts (met poort als die afwijkt) waarvoor de cache geldt: die van de site-URL, live gelezen zodat een verhuizing
 * meteen klopt, plus de hosts die het thema opsloeg. Een andere Host-header maakt dan geen eigen map.
 *
 * @return string[]
 */
function _ww_page_cache_hosts(): array {
	$hosts = array( _ww_page_cache_url_host( (string) get_option( 'home' ) ) );
	$extra = get_option( WW_PAGE_CACHE_HOSTS_OPTION );
	foreach ( is_array( $extra ) ? $extra : array() as $host ) {
		if ( is_string( $host ) ) {
			$hosts[] = strtolower( $host );
		}
	}
	return array_values( array_unique( array_filter( $hosts ) ) );
}

/**
 * Host en poort van een URL, zoals ze in de Host-header staan: 'example.org' of 'example.org:8080'.
 */
function _ww_page_cache_url_host( string $url ): string {
	$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
	$port = wp_parse_url( $url, PHP_URL_PORT );
	return '' === $host ? '' : $host . ( is_int( $port ) ? ':' . $port : '' );
}

/**
 * Mag dit verzoek uit de cache komen of erin? GET of HEAD op index.php, buiten de admin, zonder cookies van een
 * ingelogde bezoeker. Los van de superglobals, zodat het te testen is.
 *
 * @param array<string,mixed> $server  $_SERVER.
 * @param array<string,mixed> $cookies $_COOKIE.
 */
function _ww_page_cache_request_ok( array $server, array $cookies ): bool {
	$method = strtoupper( is_string( $server['REQUEST_METHOD'] ?? null ) ? $server['REQUEST_METHOD'] : 'GET' );
	if ( 'GET' !== $method && 'HEAD' !== $method ) {
		return false;
	}
	$script = is_string( $server['SCRIPT_FILENAME'] ?? null ) ? $server['SCRIPT_FILENAME'] : '';
	if ( 'index.php' !== basename( str_replace( '\\', '/', $script ) ) ) {
		return false;
	}
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'WP_CLI' ) && WP_CLI ) || ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
		return false;
	}
	$prefixes = WW_PAGE_CACHE_SKIP_COOKIES;
	if ( defined( 'LOGGED_IN_COOKIE' ) ) {
		$prefixes[] = (string) LOGGED_IN_COOKIE;
	}
	foreach ( array_keys( $cookies ) as $name ) {
		foreach ( $prefixes as $prefix ) {
			if ( str_starts_with( (string) $name, $prefix ) ) {
				return false;
			}
		}
	}
	return true;
}

/**
 * Pad van een pagina in de cache, ten opzichte van _ww_page_cache_dir(): '{host}/{pad}', of null als de URL niet in de
 * cache mag. Een query-string met iets anders dan de genegeerde parameters, een vreemd teken, een segment dat met een
 * punt begint (`..`, `.htaccess`) of een pad dat niet canoniek is (hoofdletters, `%6f` voor `o`, `%C3` in plaats van
 * `%c3`), geeft null; zo komt een pad nooit buiten de map en heeft elke pagina hoogstens één bestand.
 *
 * @param string   $host    Host van het verzoek (HTTP_HOST).
 * @param string   $uri     REQUEST_URI.
 * @param string[] $ignored Parameters die niet meetellen; een * aan het eind is een voorvoegsel.
 */
function _ww_page_cache_key( string $host, string $uri, array $ignored ): ?string {
	$host = strtolower( $host );
	if ( ! preg_match( '/^[a-z0-9.-]+(:[0-9]{1,5})?$/', $host ) ) {
		return null;
	}

	$parts = explode( '?', $uri, 2 );
	$path  = $parts[0];
	if ( strlen( $path ) > 400 || ! preg_match( '#^/[A-Za-z0-9\-._~%/]*$#', $path ) || str_contains( $path, '//' ) ) {
		return null;
	}
	$segments = array_values( array_filter( explode( '/', $path ), static fn( string $segment ): bool => '' !== $segment ) );
	foreach ( $segments as $segment ) {
		// Alleen het canonieke pad, zoals WordPress de slug codeert: kleine letters, %-codes in kleine hex en nooit voor
		// een teken dat ook gewoon kan. WordPress geeft op /OVER-ONS/ of /%6fver-ons/ dezelfde pagina zonder redirect;
		// elk een eigen bestand zou de schijf laten vollopen (B3 van de audit). Zo'n variant komt niet uit de cache en
		// wordt niet bewaard, ook niet in de statische cache van .htaccess (beslissing 0029).
		if ( str_starts_with( $segment, '.' ) || strtolower( rawurlencode( rawurldecode( $segment ) ) ) !== $segment ) {
			return null;
		}
	}

	if ( isset( $parts[1] ) && '' !== $parts[1] ) {
		foreach ( explode( '&', $parts[1] ) as $pair ) {
			$name = rawurldecode( explode( '=', $pair, 2 )[0] );
			if ( '' !== $name && ! _ww_page_cache_param_ignored( $name, $ignored ) ) {
				return null;
			}
		}
	}

	return rtrim( str_replace( ':', '_', $host ) . '/' . implode( '/', $segments ), '/' );
}

/**
 * Telt deze parameter niet mee voor de sleutel?
 *
 * @param string[] $ignored Parameters; een * aan het eind is een voorvoegsel.
 */
function _ww_page_cache_param_ignored( string $name, array $ignored ): bool {
	foreach ( $ignored as $pattern ) {
		$is_prefix = str_ends_with( $pattern, '*' );
		if ( $is_prefix ? str_starts_with( $name, substr( $pattern, 0, -1 ) ) : $name === $pattern ) {
			return true;
		}
	}
	return false;
}

/**
 * Staat er een cronjob klaar die niet al draait? Dan niet uit de cache: WP-Cron start alleen als WordPress helemaal
 * laadt, dus anders blijven geplande berichten en dagelijkse taken liggen. Met een echte cron (DISABLE_WP_CRON)
 * speelt het niet.
 */
function _ww_page_cache_cron_due(): bool {
	if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) {
		return false;
	}
	$lock = (float) get_transient( 'doing_cron' );
	$timeout = defined( 'WP_CRON_LOCK_TIMEOUT' ) ? (int) constant( 'WP_CRON_LOCK_TIMEOUT' ) : MINUTE_IN_SECONDS;
	return _ww_page_cache_cron_waiting( get_option( 'cron' ), time(), $lock, $timeout );
}

/**
 * Staat er in de cron-optie een taak die al had moeten draaien, en draait de cron niet al? Zolang WordPress de cron
 * net heeft gestart (het slot doing_cron), komt de pagina wel uit de cache: anders mist iedereen de cache als de
 * cron niet kan starten (een staging achter een wachtwoord) of steeds korte taken heeft.
 *
 * @param mixed $crons De optie cron: tijdstip => taken, plus 'version'.
 * @param float $lock  Tijd van het slot doing_cron, of 0.
 */
function _ww_page_cache_cron_waiting( $crons, int $now, float $lock = 0.0, int $lock_timeout = 60 ): bool {
	if ( ! is_array( $crons ) || ( $lock > 0 && $lock > $now - $lock_timeout ) ) {
		return false;
	}
	foreach ( array_keys( $crons ) as $time ) {
		if ( is_int( $time ) && $time <= $now ) {
			return true;
		}
	}
	return false;
}

/**
 * De laatste purges, als microtime: 'all' (alles), per post type en per bericht (de pagina van dat bericht).
 *
 * @return array{all:float,types:array<string,float>,posts:array<int,float>}
 */
function _ww_page_cache_marker(): array {
	// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents, WordPress.PHP.NoSilencedErrors -- nog nooit geleegd is geen fout.
	$data  = json_decode( (string) @file_get_contents( _ww_page_cache_marker_file() ), true );
	$data  = is_array( $data ) ? $data : array();
	$types = array();
	foreach ( is_array( $data['types'] ?? null ) ? $data['types'] : array() as $type => $time ) {
		if ( is_string( $type ) && is_numeric( $time ) ) {
			$types[ $type ] = (float) $time;
		}
	}
	$posts = array();
	foreach ( is_array( $data['posts'] ?? null ) ? $data['posts'] : array() as $id => $time ) {
		if ( is_numeric( $id ) && is_numeric( $time ) ) {
			$posts[ (int) $id ] = (float) $time;
		}
	}
	return array(
		'all'   => is_numeric( $data['all'] ?? null ) ? (float) $data['all'] : 0.0,
		'types' => $types,
		'posts' => $posts,
	);
}

/**
 * Is een pagina die op $created werd opgebouwd, deze post types toont en (als losse pagina) bij dit bericht hoort,
 * oud door een latere purge?
 *
 * @param string[]                                                         $types   Post types die de pagina toont.
 * @param int                                                              $post_id Bericht van de pagina, of 0.
 * @param array{all:float,types:array<string,float>,posts:array<int,float>} $marker  De laatste purges.
 */
function _ww_page_cache_is_stale( float $created, array $types, int $post_id, array $marker ): bool {
	if ( $created <= $marker['all'] ) {
		return true;
	}
	if ( $post_id > 0 && isset( $marker['posts'][ $post_id ] ) && $created <= $marker['posts'][ $post_id ] ) {
		return true;
	}
	foreach ( $types as $type ) {
		if ( isset( $marker['types'][ $type ] ) && $created <= $marker['types'][ $type ] ) {
			return true;
		}
	}
	return false;
}

/**
 * Leest een pagina uit de cache: de HTML en de headers, of null als hij er niet (helemaal) is, verlopen of oud is,
 * of voor een ander pad werd bewaard (`/diensten` en `/diensten/` delen een map, maar alleen de canonieke URL komt
 * uit de cache; de andere krijgt van WordPress een redirect). Leest alles vóór er iets verstuurd wordt, zodat een
 * gelijktijdige purge nooit een halve pagina geeft.
 *
 * @return array{html:string,headers:string[]}|null
 */
function _ww_page_cache_lookup( string $key, string $path ): ?array {
	$dir = _ww_page_cache_dir() . '/' . $key;
	// phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- een ontbrekend bestand is een gewone misser.
	$meta = json_decode( (string) @file_get_contents( $dir . '/meta.json' ), true );
	if ( ! is_array( $meta ) || (int) ( $meta['expires'] ?? 0 ) <= time() || ( $meta['path'] ?? null ) !== $path ) {
		return null;
	}
	// phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- een ontbrekend bestand is een gewone misser.
	$html = @file_get_contents( $dir . '/' . _ww_page_cache_html_file( $meta ) );
	if ( false === $html || '' === $html ) {
		return null;
	}
	$types = array_values( array_filter( (array) ( $meta['post_types'] ?? array() ), 'is_string' ) );
	if ( _ww_page_cache_is_stale( (float) ( $meta['created'] ?? 0 ), $types, (int) ( $meta['post_id'] ?? 0 ), _ww_page_cache_marker() ) ) {
		return null;
	}
	return array(
		'html'    => $html,
		'headers' => array_values( array_filter( (array) ( $meta['headers'] ?? array() ), 'is_string' ) ),
	);
}

/**
 * Naam van de HTML die bij deze meta.json hoort. Een meta.json van vóór beslissing 0029 heeft geen 'file': index.html.
 *
 * @param array<mixed> $meta Inhoud van meta.json.
 */
function _ww_page_cache_html_file( array $meta ): string {
	return WW_PAGE_CACHE_PHP_FILE === ( $meta['file'] ?? null ) ? WW_PAGE_CACHE_PHP_FILE : WW_PAGE_CACHE_STATIC_FILE;
}

/**
 * Sleutel en pad van het huidige verzoek, of null als het niet uit de cache mag.
 *
 * @return array{key:string,path:string,host:string}|null
 */
function _ww_page_cache_current(): ?array {
	if ( ! _ww_page_cache_request_ok( $_SERVER, $_COOKIE ) ) {
		return null;
	}
	// Alleen op het schema van de site: http en https delen dezelfde sleutel.
	if ( is_ssl() !== ( 'https' === wp_parse_url( (string) get_option( 'home' ), PHP_URL_SCHEME ) ) ) {
		return null;
	}
	$host = isset( $_SERVER['HTTP_HOST'] ) && is_string( $_SERVER['HTTP_HOST'] ) ? strtolower( $_SERVER['HTTP_HOST'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- moet in _ww_page_cache_hosts() staan.
	$uri  = isset( $_SERVER['REQUEST_URI'] ) && is_string( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- _ww_page_cache_key() laat alleen veilige tekens toe.
	if ( ! in_array( $host, _ww_page_cache_hosts(), true ) ) {
		return null;
	}
	$key = _ww_page_cache_key( $host, $uri, _ww_page_cache_ignored_params() );
	if ( null === $key ) {
		return null;
	}
	return array(
		'key'  => $key,
		'path' => explode( '?', $uri, 2 )[0],
		'host' => $host,
	);
}

/**
 * Server-Timing-header met de tijd sinds het begin van het verzoek, in ms: te zien in DevTools (Network › Timing) en
 * met curl -I. Zo is te zien hoeveel van de TTFB PHP en WordPress zijn, los van netwerk en TLS.
 *
 * @param string $result 'HIT' of 'MISS'.
 */
function _ww_page_cache_timing_header( string $result ): string {
	$start = $_SERVER['REQUEST_TIME_FLOAT'] ?? null;
	$ms    = is_numeric( $start ) ? max( 0.0, ( microtime( true ) - (float) $start ) * 1000 ) : 0.0;
	return sprintf( 'Server-Timing: ww-cache;desc="%s";dur=%.1F', $result, $ms );
}

/**
 * Stuurt de pagina uit de cache en stopt, of doet niets: dan laadt WordPress gewoon.
 */
function _ww_page_cache_serve(): void {
	if ( '' !== _ww_page_cache_off_reason() || _ww_page_cache_cron_due() ) {
		return;
	}
	$current = _ww_page_cache_current();
	$hit     = null === $current ? null : _ww_page_cache_lookup( $current['key'], $current['path'] );
	if ( null === $hit || headers_sent() ) {
		return;
	}
	foreach ( $hit['headers'] as $header ) {
		header( $header );
	}
	header( 'X-WW-Cache: HIT' );
	header( _ww_page_cache_timing_header( 'HIT' ) );
	if ( 'HEAD' !== strtoupper( (string) ( $_SERVER['REQUEST_METHOD'] ?? 'GET' ) ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		echo $hit['html']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- de HTML die WordPress eerder zelf voor dit verzoek maakte.
	}
	exit;
}
