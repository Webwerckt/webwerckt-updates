<?php
/**
 * Overzicht voor de beheerder: welke post types, taxonomieën met termvelden en velden de configuratie (pods/*.json)
 * oplevert, uit welk bestand ze komen, welke Site-instellingen er zijn, wat bij het inlezen is overgeslagen en welke
 * velden het thema nergens kan bewerken. Alleen lezen; de velden zelf bewerk je op het bewerkscherm, bij de
 * Site-instellingen of op het scherm van een term.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const WW_FIELDS_PAGE = 'ww-fields';

/**
 * Voegt het overzicht toe als hoofditem, in het Webwerckt-blok (beslissing 0035). Alleen voor wie manage_options heeft.
 */
function _ww_fields_admin_menu(): void {
	add_menu_page(
		__( 'Velden', 'webwerckt-base' ),
		__( 'Velden', 'webwerckt-base' ),
		'manage_options',
		WW_FIELDS_PAGE,
		'_ww_fields_admin_render',
		'dashicons-database'
	);
}
add_action( 'admin_menu', '_ww_fields_admin_menu' );

/**
 * De velden van een groep voor het overzicht: editable (het scherm tekent een invoer) en elsewhere (de abilities en
 * Visueel bewerken bewerken het veld; niet voor termvelden).
 *
 * @param array<string,mixed> $group  Groep uit de configuratie.
 * @param string              $prefix Voorvoegsel van de optienaam (Site-instellingen), anders ''.
 * @param bool                $terms  Termvelden van een taxonomie.
 * @return array<int,array<string,mixed>>
 */
function _ww_fields_overview_fields( array $group, string $prefix = '', bool $terms = false ): array {
	$fields = array();
	foreach ( _ww_pods_valid_fields( $group ) as $field ) {
		$name     = _ww_data_to_string( $field['name'] ?? '' );
		$label    = _ww_data_to_string( $field['label'] ?? '' );
		$row      = array(
			'name'      => $name,
			'label'     => '' !== $label ? $label : $name,
			'type'      => _ww_data_to_string( $field['type'] ?? '' ),
			'editable'  => _ww_settings_field_supported( $field ),
			'elsewhere' => ! $terms && _ww_field_layer_supports( $field ),
		);
		$fields[] = '' !== $prefix ? $row + array( 'option' => $prefix . $name ) : $row;
	}
	return $fields;
}

/**
 * Bestanden per pod (`type:naam`), met hun herkomst: parent of child.
 *
 * @return array<string,array<int,array{file:string,origin:string}>>
 */
function _ww_fields_overview_files(): array {
	$child = _ww_has_child_theme() ? trailingslashit( get_stylesheet_directory() ) : '';
	$map   = array();
	foreach ( _ww_pods_config_files() as $file ) {
		$config = json_decode( (string) file_get_contents( $file ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- lokaal themabestand.
		if ( ! is_array( $config ) ) {
			continue;
		}
		$key           = _ww_data_to_string( $config['type'] ?? '' ) . ':' . _ww_data_to_string( $config['name'] ?? '' );
		$map[ $key ][] = array(
			'file'   => basename( $file ),
			'origin' => '' !== $child && str_starts_with( $file, $child ) ? 'child' : 'parent',
		);
	}
	return $map;
}

/**
 * De taxonomieën van een post type, met een link naar hun beheerscherm.
 *
 * @return array<int,array{name:string,label:string,url:string}>
 */
function _ww_fields_overview_taxonomies( string $post_type ): array {
	$list = array();
	foreach ( get_object_taxonomies( $post_type, 'objects' ) as $taxonomy ) {
		$list[] = array(
			'name'  => $taxonomy->name,
			'label' => $taxonomy->labels->name ?? $taxonomy->label,
			'url'   => add_query_arg(
				array(
					'taxonomy'  => $taxonomy->name,
					'post_type' => $post_type,
				),
				admin_url( 'edit-tags.php' )
			),
		);
	}
	return $list;
}

/**
 * De groepen van een pod voor het overzicht, met hun velden.
 *
 * @param array<string,mixed> $pod   Pod uit de configuratie.
 * @param bool                $terms Termvelden van een taxonomie.
 * @return array<int,array{name:string,label:string,template:string,fields:array<int,array<string,mixed>>}>
 */
function _ww_fields_overview_groups( array $pod, bool $terms = false ): array {
	$groups = array();
	foreach ( is_array( $pod['groups'] ?? null ) ? $pod['groups'] : array() as $group ) {
		if ( ! is_array( $group ) ) {
			continue;
		}
		$group_name = _ww_data_to_string( $group['name'] ?? '' );
		$bare       = (string) preg_replace( '/^' . preg_quote( _ww_child_prefix(), '/' ) . '/', '', $group_name );
		$label      = _ww_data_to_string( $group['label'] ?? '' );
		$groups[]   = array(
			'name'     => $group_name,
			'label'    => '' !== $label ? $label : $group_name,
			'template' => ! $terms && str_starts_with( $bare, 'template_' ) ? substr( $bare, strlen( 'template_' ) ) : '',
			'fields'   => _ww_fields_overview_fields( $group, '', $terms ),
		);
	}
	return $groups;
}

/**
 * De velden die het thema nergens kan bewerken (geen invoer op het scherm, en ook niet via de abilities of Visueel
 * bewerken), voor de meldingen bovenaan: hun waarde blijft staan, maar wijzigen kan alleen nog met code of WP-CLI.
 *
 * @param array<int,array<string,mixed>> $rows Rijen van post types en taxonomieën uit _ww_fields_overview().
 * @return array<int,array{file:string,field:string,type:string}>
 */
function _ww_fields_overview_uneditable( array $rows ): array {
	$list = array();
	foreach ( $rows as $row ) {
		$file = (string) ( $row['files'][0]['file'] ?? $row['name'] );
		foreach ( $row['groups'] as $group ) {
			foreach ( $group['fields'] as $field ) {
				if ( ! $field['editable'] && ! $field['elsewhere'] ) {
					$list[] = array(
						'file'  => $file,
						'field' => (string) $field['name'],
						'type'  => (string) $field['type'],
					);
				}
			}
		}
	}
	return $list;
}

/**
 * Het overzicht: post types met velden, taxonomieën met termvelden, de Site-instellingen per pagina en de velden die
 * het thema nergens kan bewerken.
 *
 * @return array{post_types:array<int,array<string,mixed>>,taxonomies:array<int,array<string,mixed>>,settings:array<int,array<string,mixed>>,uneditable:array<int,array{file:string,field:string,type:string}>}
 */
function _ww_fields_overview(): array {
	$files      = _ww_fields_overview_files();
	$post_types = array();
	$taxonomies = array();
	foreach ( _ww_pods_config() as $pod ) {
		$name = _ww_data_to_string( $pod['name'] ?? '' );
		if ( 'taxonomy' === ( $pod['type'] ?? '' ) ) {
			$groups = _ww_fields_overview_groups( $pod, true );
			if ( array() === array_filter( array_column( $groups, 'fields' ) ) ) {
				continue;
			}
			$object       = get_taxonomy( $name );
			$label        = _ww_data_to_string( $pod['label'] ?? '' );
			$taxonomies[] = array(
				'name'   => $name,
				'label'  => $object instanceof WP_Taxonomy ? (string) $object->label : ( '' !== $label ? $label : $name ),
				'url'    => add_query_arg( 'taxonomy', $name, admin_url( 'edit-tags.php' ) ),
				'files'  => $files[ 'taxonomy:' . $name ] ?? array(),
				'groups' => $groups,
			);
			continue;
		}
		if ( 'post_type' !== ( $pod['type'] ?? '' ) ) {
			continue;
		}
		$object = get_post_type_object( $name );
		$groups = _ww_fields_overview_groups( $pod );
		if ( array() === array_filter( array_column( $groups, 'fields' ) ) ) {
			continue;
		}

		$label        = _ww_data_to_string( $pod['label'] ?? '' );
		$post_types[] = array(
			'name'        => $name,
			'label'       => null !== $object ? $object->labels->name : ( '' !== $label ? $label : $name ),
			'public'      => null !== $object && (bool) $object->public,
			'has_archive' => null !== $object && (bool) $object->has_archive,
			'taxonomies'  => _ww_fields_overview_taxonomies( $name ),
			'files'       => $files[ 'post_type:' . $name ] ?? array(),
			'groups'      => $groups,
		);
	}

	$pages   = _ww_settings_pages();
	$by_page = array();
	$prefix  = _ww_settings_prefix();
	foreach ( _ww_settings_groups() as $group ) {
		$group_name = _ww_data_to_string( $group['name'] ?? '' );
		$label      = _ww_data_to_string( $group['label'] ?? '' );

		$by_page[ _ww_settings_group_page( $group, $pages ) ][] = array(
			'name'   => $group_name,
			'label'  => '' !== $label ? $label : $group_name,
			'fields' => _ww_fields_overview_fields( $group, $prefix ),
		);
	}
	$settings = array();
	foreach ( $pages as $slug => $page_label ) {
		if ( isset( $by_page[ $slug ] ) ) {
			$settings[] = array(
				'page'   => $slug,
				'label'  => $page_label,
				'groups' => $by_page[ $slug ],
			);
		}
	}

	$by_settings = array();
	foreach ( $settings as $page ) {
		$by_settings[] = array(
			'name'   => 'site_settings',
			'files'  => $files['settings:site_settings'] ?? array(),
			'groups' => $page['groups'],
		);
	}

	return array(
		'post_types' => $post_types,
		'taxonomies' => $taxonomies,
		'settings'   => $settings,
		'uneditable' => _ww_fields_overview_uneditable( array_merge( $post_types, $taxonomies, $by_settings ) ),
	);
}

/**
 * Een tabel met de groepen en velden.
 *
 * @param array<int,array<string,mixed>> $groups Groepen uit _ww_fields_overview().
 */
function _ww_fields_admin_table( array $groups ): void {
	?>
	<table class="widefat striped">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Groep', 'webwerckt-base' ); ?></th>
				<th><?php esc_html_e( 'Veld', 'webwerckt-base' ); ?></th>
				<th><?php esc_html_e( 'Naam', 'webwerckt-base' ); ?></th>
				<th><?php esc_html_e( 'Soort', 'webwerckt-base' ); ?></th>
				<th><?php esc_html_e( 'Bewerken in het scherm', 'webwerckt-base' ); ?></th>
			</tr>
		</thead>
		<tbody>
		<?php foreach ( $groups as $group ) : ?>
			<?php foreach ( $group['fields'] as $field ) : ?>
				<tr>
					<td>
						<?php echo esc_html( $group['label'] ); ?>
						<?php if ( ! empty( $group['template'] ) ) : ?>
							<br><span class="description">
								<?php
								/* translators: %s: paginatemplate */
								echo esc_html( sprintf( __( 'Template: %s', 'webwerckt-base' ), $group['template'] ) );
								?>
							</span>
						<?php endif; ?>
					</td>
					<td><?php echo esc_html( $field['label'] ); ?></td>
					<td><code><?php echo esc_html( $field['option'] ?? $field['name'] ); ?></code></td>
					<td><?php echo esc_html( $field['type'] ); ?></td>
					<td>
						<?php
						if ( $field['editable'] ) {
							esc_html_e( 'Ja', 'webwerckt-base' );
						} elseif ( $field['elsewhere'] ) {
							esc_html_e( 'Nee, via Visueel bewerken of de abilities', 'webwerckt-base' );
						} else {
							esc_html_e( 'Nee, het thema bewerkt dit veld niet', 'webwerckt-base' );
						}
						?>
					</td>
				</tr>
			<?php endforeach; ?>
		<?php endforeach; ?>
		</tbody>
	</table>
	<?php
}

/**
 * Tekent het overzicht. Alleen lezen.
 */
function _ww_fields_admin_render(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Je hebt geen toegang tot deze pagina.', 'webwerckt-base' ), '', array( 'response' => 403 ) );
	}

	$overview = _ww_fields_overview();
	$notices  = _ww_pods_config_notices();
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Velden', 'webwerckt-base' ); ?></h1>
		<p><?php esc_html_e( 'Dit overzicht komt uit de bestanden in de map pods van het thema en het child-thema. Het is alleen om te lezen.', 'webwerckt-base' ); ?></p>

		<?php if ( array() !== $notices || array() !== $overview['uneditable'] ) : ?>
			<div class="notice notice-warning inline">
				<p><strong><?php esc_html_e( 'Overgeslagen of afwijkend:', 'webwerckt-base' ); ?></strong></p>
				<ul>
					<?php foreach ( $notices as $notice ) : ?>
						<li><code><?php echo esc_html( $notice['file'] ); ?></code>: <?php echo esc_html( $notice['reason'] ); ?></li>
					<?php endforeach; ?>
					<?php foreach ( $overview['uneditable'] as $item ) : ?>
						<li>
							<code><?php echo esc_html( $item['file'] ); ?></code>: <code><?php echo esc_html( $item['field'] ); ?></code>
							<?php
							/* translators: %s: soort veld, bijvoorbeeld pick. */
							echo esc_html( sprintf( __( '(soort %s) kan het thema nergens bewerken; de waarde blijft staan.', 'webwerckt-base' ), $item['type'] ) );
							?>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		<?php endif; ?>

		<h2><?php esc_html_e( 'Post types', 'webwerckt-base' ); ?></h2>
		<?php if ( array() === $overview['post_types'] ) : ?>
			<p><?php esc_html_e( 'Er zijn geen post types met velden.', 'webwerckt-base' ); ?></p>
		<?php endif; ?>
		<?php foreach ( $overview['post_types'] as $post_type ) : ?>
			<h3><?php echo esc_html( $post_type['label'] ); ?> <code><?php echo esc_html( $post_type['name'] ); ?></code></h3>
			<p>
				<?php echo esc_html( $post_type['public'] ? __( 'Publiek', 'webwerckt-base' ) : __( 'Niet publiek', 'webwerckt-base' ) ); ?>
				<?php if ( $post_type['has_archive'] ) : ?>
					| <?php esc_html_e( 'Met archief', 'webwerckt-base' ); ?>
				<?php endif; ?>
				<?php if ( array() !== $post_type['files'] ) : ?>
					<br>
					<?php esc_html_e( 'Bestanden:', 'webwerckt-base' ); ?>
					<?php foreach ( $post_type['files'] as $index => $file ) : ?>
						<?php echo $index > 0 ? ', ' : ''; ?><code><?php echo esc_html( $file['file'] ); ?></code> (<?php echo esc_html( 'child' === $file['origin'] ? __( 'child-thema', 'webwerckt-base' ) : __( 'parent', 'webwerckt-base' ) ); ?>)
					<?php endforeach; ?>
				<?php endif; ?>
				<?php if ( array() !== $post_type['taxonomies'] ) : ?>
					<br>
					<?php esc_html_e( 'Taxonomieën:', 'webwerckt-base' ); ?>
					<?php foreach ( $post_type['taxonomies'] as $index => $taxonomy ) : ?>
						<?php echo $index > 0 ? ', ' : ''; ?><a href="<?php echo esc_url( $taxonomy['url'] ); ?>"><?php echo esc_html( $taxonomy['label'] ); ?></a>
					<?php endforeach; ?>
				<?php endif; ?>
			</p>
			<?php _ww_fields_admin_table( $post_type['groups'] ); ?>
		<?php endforeach; ?>

		<?php if ( array() !== $overview['taxonomies'] ) : ?>
			<h2><?php esc_html_e( 'Taxonomieën met termvelden', 'webwerckt-base' ); ?></h2>
			<?php foreach ( $overview['taxonomies'] as $taxonomy ) : ?>
				<h3><a href="<?php echo esc_url( $taxonomy['url'] ); ?>"><?php echo esc_html( $taxonomy['label'] ); ?></a> <code><?php echo esc_html( $taxonomy['name'] ); ?></code></h3>
				<?php if ( array() !== $taxonomy['files'] ) : ?>
					<p>
						<?php esc_html_e( 'Bestanden:', 'webwerckt-base' ); ?>
						<?php foreach ( $taxonomy['files'] as $index => $file ) : ?>
							<?php echo $index > 0 ? ', ' : ''; ?><code><?php echo esc_html( $file['file'] ); ?></code> (<?php echo esc_html( 'child' === $file['origin'] ? __( 'child-thema', 'webwerckt-base' ) : __( 'parent', 'webwerckt-base' ) ); ?>)
						<?php endforeach; ?>
					</p>
				<?php endif; ?>
				<?php _ww_fields_admin_table( $taxonomy['groups'] ); ?>
			<?php endforeach; ?>
		<?php endif; ?>

		<h2><?php esc_html_e( 'Site-instellingen', 'webwerckt-base' ); ?></h2>
		<?php foreach ( $overview['settings'] as $page ) : ?>
			<h3><?php echo esc_html( $page['label'] ); ?></h3>
			<?php _ww_fields_admin_table( $page['groups'] ); ?>
		<?php endforeach; ?>
	</div>
	<?php
}
