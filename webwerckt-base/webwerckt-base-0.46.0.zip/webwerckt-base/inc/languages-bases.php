<?php
/**
 * Meertalig afronding (beslissing 0044), onderdeel URL-basis: per extra taal een vertaalde basis voor archieven en
 * termarchieven (`/en/projects/` in plaats van `/en/projecten/`).
 *
 * De basissen staan in de optie ww_languages, per taal onder `bases`: post type- of taxonomienaam => vertaalde basis
 * (sanitize_title()). Leeg of ontbrekend: de echte basis. Dit bestand bevat welke objecten een basis hebben, het lezen,
 * de controle en het opslaan; de pagina Talen (inc/languages-admin.php) en de abilities get-languages en set-url-bases
 * (inc/abilities.php) gebruiken ze. Een basis van een post type of taxonomie die er niet meer is, blijft in de optie
 * staan en wordt genegeerd.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * De echte basis uit de rewrite-argumenten van een post type of taxonomie: één padsegment, of '' zonder eigen adres.
 * Een basis met een / (meer segmenten) kan niet vertaald worden: de routing vervangt alleen het eerste segment.
 *
 * @param mixed $rewrite Het argument rewrite van het object.
 */
function _ww_language_rewrite_base( mixed $rewrite ): string {
	if ( ! is_array( $rewrite ) || ! isset( $rewrite['slug'] ) || ! is_string( $rewrite['slug'] ) ) {
		return '';
	}
	$base = trim( $rewrite['slug'], '/' );
	return str_contains( $base, '/' ) ? '' : $base;
}

/**
 * De objecten met een vertaalbare basis: de vertaalbare post types met een eigen adres (publicly_queryable en een
 * rewrite.slug), en de vertaalbare taxonomieën met een eigen adres (ook in het beheer zichtbaar, dus niet post_format).
 * Niet post en page: berichten volgen de permalinkstructuur en pagina's hebben geen basis.
 *
 * @return array<string,array{type:'post_type'|'taxonomy',base:string,label:string}>
 */
function _ww_language_base_objects(): array {
	$objects = array();

	foreach ( _ww_translatable_post_types() as $name ) {
		$type = get_post_type_object( $name );
		if ( in_array( $name, array( 'post', 'page' ), true ) || ! $type instanceof WP_Post_Type || ! $type->publicly_queryable ) {
			continue;
		}
		$base = _ww_language_rewrite_base( $type->rewrite );
		if ( '' !== $base ) {
			$objects[ $name ] = array(
				'type'  => 'post_type',
				'base'  => $base,
				'label' => (string) $type->labels->name,
			);
		}
	}

	foreach ( _ww_translatable_taxonomies() as $name ) {
		$taxonomy = get_taxonomy( $name );
		if ( ! $taxonomy instanceof WP_Taxonomy || ! $taxonomy->publicly_queryable || ! $taxonomy->show_ui ) {
			continue;
		}
		$base = _ww_language_rewrite_base( $taxonomy->rewrite );
		if ( '' !== $base ) {
			$objects[ $name ] = array(
				'type'  => 'taxonomy',
				'base'  => $base,
				'label' => (string) $taxonomy->labels->name,
			);
		}
	}

	return $objects;
}

/**
 * De vertaalde basissen van een taal, zoals opgeslagen: naam => basis, alleen de ingevulde.
 *
 * @param string $lang Taalcode.
 * @return array<string,string>
 */
function _ww_language_bases( string $lang ): array {
	$language = _ww_language( $lang );
	return null !== $language && isset( $language['bases'] ) ? $language['bases'] : array();
}

/**
 * De pagina-slugs op het hoogste niveau in een taal, voor zover ze in de lijst staan. Een pagina zonder taalterm hoort
 * bij de standaardtaal.
 *
 * @param string   $lang  Taalcode.
 * @param string[] $slugs Slugs om te zoeken.
 * @return string[]
 */
function _ww_language_base_page_slugs( string $lang, array $slugs ): array {
	if ( array() === $slugs || ! taxonomy_exists( 'ww_language' ) ) {
		return array();
	}
	$pages = get_posts(
		array(
			'post_type'        => 'page',
			'post_status'      => array( 'publish', 'future', 'draft', 'pending', 'private' ),
			'post_parent'      => 0,
			'post_name__in'    => array_values( $slugs ),
			'tax_query'        => _ww_languages_tax_query( $lang ), // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- alleen bij opslaan en in het beheer.
			'posts_per_page'   => -1,
			'lang'             => '',
			'suppress_filters' => false,
		)
	);
	return array_values( array_unique( wp_list_pluck( $pages, 'post_name' ) ) );
}

/**
 * De botsingen van deze basissen in een taal: naam => reden, voor elke vertaalde basis die gelijk is aan een andere basis
 * in die taal (de vertaalde of de echte van een ander object, ook een afwijkende archiefslug), aan een taalcode, aan een gereserveerd pad van de kern
 * (WW_LANGUAGES_RESERVED_PATHS) of aan de slug van een pagina op het hoogste niveau in die taal. Namen die geen object
 * met een basis zijn, en een basis gelijk aan de eigen echte basis, worden overgeslagen.
 *
 * @param string               $lang  Taalcode.
 * @param array<string,string> $bases Naam => vertaalde basis (alle basissen van die taal).
 * @return array<string,string>
 */
function _ww_language_base_conflicts( string $lang, array $bases ): array {
	$objects = _ww_language_base_objects();
	$check   = array();
	foreach ( $bases as $name => $base ) {
		if ( isset( $objects[ $name ] ) && '' !== $base && $base !== $objects[ $name ]['base'] ) {
			$check[ $name ] = $base;
		}
	}
	if ( array() === $check ) {
		return array();
	}

	$pages     = _ww_language_base_page_slugs( $lang, array_values( $check ) );
	$conflicts = array();
	foreach ( $check as $name => $base ) {
		foreach ( $objects as $other => $object ) {
			if ( $other !== $name && ( $base === $object['base'] || $base === ( $check[ $other ] ?? '' ) || ( 'post_type' === $object['type'] && $base === _ww_language_base_archive( $other ) ) ) ) {
				/* translators: 1: URL-basis, 2: naam van een post type of taxonomie, zoals Projecten */
				$conflicts[ $name ] = sprintf( __( '"%1$s" is al de URL-basis van %2$s.', 'webwerckt-base' ), $base, $object['label'] );
				continue 2;
			}
		}
		if ( in_array( $base, _ww_language_codes(), true ) ) {
			/* translators: %s: URL-basis */
			$conflicts[ $name ] = sprintf( __( '"%s" is een taalcode.', 'webwerckt-base' ), $base );
		} elseif ( in_array( $base, WW_LANGUAGES_RESERVED_PATHS, true ) ) {
			/* translators: %s: URL-basis */
			$conflicts[ $name ] = sprintf( __( '"%s" is een vast adres van WordPress.', 'webwerckt-base' ), $base );
		} elseif ( in_array( $base, $pages, true ) ) {
			/* translators: %s: URL-basis */
			$conflicts[ $name ] = sprintf( __( '"%s" is de slug van een pagina op het hoogste niveau in deze taal.', 'webwerckt-base' ), $base );
		}
	}
	return $conflicts;
}

/**
 * Een botsing als tekst: per object "Projecten: reden".
 *
 * @param array<string,string> $conflicts Naam => reden, uit _ww_language_base_conflicts().
 */
function _ww_language_base_conflicts_label( array $conflicts ): string {
	$objects = _ww_language_base_objects();
	$parts   = array();
	foreach ( $conflicts as $name => $reason ) {
		$parts[] = ( $objects[ $name ]['label'] ?? $name ) . ': ' . $reason;
	}
	return implode( ' ', $parts );
}

/**
 * Slaat vertaalde basissen van een extra taal op. Alleen de meegegeven namen veranderen: een lege waarde wist de
 * vertaling, een basis gelijk aan de echte basis ook (dat is geen vertaling). Namen die geen object met een basis zijn,
 * worden overgeslagen. Daarna gelden voor alle basissen van de taal de controles van _ww_language_base_conflicts().
 *
 * Opslaan flusht de rewrite rules niet (die veranderen niet), maar leegt de hele paginacache (_ww_purge_all): de links
 * op elke pagina in die taal veranderen.
 *
 * @param string              $lang  Code van een extra taal.
 * @param array<string,mixed> $bases Naam => vertaalde basis.
 * @return true|WP_Error ww_languages_inactive, ww_languages_unknown, ww_language_default of ww_language_base_taken.
 */
function _ww_language_save_bases( string $lang, array $bases ): true|WP_Error {
	if ( ! _ww_languages_active() ) {
		return new WP_Error( 'ww_languages_inactive', __( 'Meertalig staat uit, of een vertaalplugin regelt de talen.', 'webwerckt-base' ) );
	}
	if ( null === _ww_language( $lang ) ) {
		/* translators: %s: taalcode */
		return new WP_Error( 'ww_languages_unknown', sprintf( __( 'De taal "%s" bestaat niet.', 'webwerckt-base' ), $lang ) );
	}
	if ( _ww_default_language() === $lang ) {
		return new WP_Error( 'ww_language_default', __( 'De standaardtaal heeft geen vertaalde URL-basis: zijn basis is de echte basis.', 'webwerckt-base' ) );
	}

	$objects = _ww_language_base_objects();
	$merged  = _ww_language_bases( $lang );
	foreach ( $bases as $name => $base ) {
		$name = sanitize_key( (string) $name );
		if ( ! isset( $objects[ $name ] ) ) {
			continue;
		}
		$base = is_string( $base ) ? sanitize_title( $base ) : '';
		if ( '' === $base || $base === $objects[ $name ]['base'] ) {
			unset( $merged[ $name ] );
		} else {
			$merged[ $name ] = $base;
		}
	}

	$conflicts = _ww_language_base_conflicts( $lang, $merged );
	if ( array() !== $conflicts ) {
		return new WP_Error(
			'ww_language_base_taken',
			/* translators: %s: de botsingen, zoals 'Projecten: "wp-json" is een vast adres van WordPress.' */
			sprintf( __( 'Deze URL-basis is al in gebruik. %s', 'webwerckt-base' ), _ww_language_base_conflicts_label( $conflicts ) ),
			array( 'conflicts' => $conflicts )
		);
	}

	$config = _ww_languages_config();
	foreach ( $config['languages'] as $index => $language ) {
		if ( $language['code'] === $lang ) {
			$config['languages'][ $index ]['bases'] = $merged;
		}
	}
	$clean = _ww_languages_sanitize( $config );
	if ( $clean instanceof WP_Error ) {
		return $clean;
	}
	update_option( 'ww_languages', $clean, true );
	do_action( '_ww_purge_all' );
	return true;
}

/**
 * De archiefslug van een post type als die afwijkt van zijn rewrite.slug (has_archive als string, één padsegment), of ''.
 *
 * @param string $name Naam van het post type.
 */
function _ww_language_base_archive( string $name ): string {
	$type = get_post_type_object( $name );
	if ( ! $type instanceof WP_Post_Type || ! is_string( $type->has_archive ) ) {
		return '';
	}
	$archive = trim( $type->has_archive, '/' );
	return str_contains( $archive, '/' ) || $archive === _ww_language_rewrite_base( $type->rewrite ) ? '' : $archive;
}

/**
 * De paren van echte en vertaalde basis in een taal, als pad direct na het voorvoegsel, zonder slash ervoor:
 * 'projecten' en 'projects'. Een object met with_front onder een permalinkstructuur met een front krijgt die front
 * ervoor ('blog/projecten'), net als in zijn rewrite rules; zonder with_front de root ('index.php' bij PATHINFO).
 *
 * Een post type met een archief onder een andere slug dan zijn rewrite.slug krijgt een tweede paar met archive true:
 * dat geldt alleen voor een archiefadres (het archief, een pagina of een feed ervan), zodat /projects/ het archief en
 * /projects/{slug}/ een bericht blijft. Leeg zonder module, in de standaardtaal, zonder vertaalde basissen en zonder
 * mooie permalinks. Een basis van een object dat er niet (meer) is, wordt genegeerd.
 *
 * @param string $lang Taalcode.
 * @return array<int,array{real:string,translated:string,archive:bool}>
 */
function _ww_language_base_pairs( string $lang ): array {
	global $wp_rewrite;
	if ( ! _ww_languages_active() || ! in_array( $lang, _ww_extra_language_codes(), true ) ) {
		return array();
	}
	$bases = _ww_language_bases( $lang );
	if ( array() === $bases || ! $wp_rewrite instanceof WP_Rewrite || ! $wp_rewrite->using_permalinks() ) {
		return array();
	}

	$objects = _ww_language_base_objects();
	$pairs   = array();
	foreach ( $bases as $name => $translated ) {
		if ( ! isset( $objects[ $name ] ) ) {
			continue;
		}
		$object = 'post_type' === $objects[ $name ]['type'] ? get_post_type_object( $name ) : get_taxonomy( $name );
		if ( ! $object instanceof WP_Post_Type && ! $object instanceof WP_Taxonomy ) {
			continue;
		}
		$front   = trim( is_array( $object->rewrite ) && ! empty( $object->rewrite['with_front'] ) ? $wp_rewrite->front : $wp_rewrite->root, '/' );
		$front   = '' === $front ? '' : $front . '/';
		$pairs[] = array(
			'real'       => $front . $objects[ $name ]['base'],
			'translated' => $front . $translated,
			'archive'    => false,
		);
		$archive = 'post_type' === $objects[ $name ]['type'] ? _ww_language_base_archive( $name ) : '';
		if ( '' !== $archive ) {
			$pairs[] = array(
				'real'       => $front . $archive,
				'translated' => $front . $translated,
				'archive'    => true,
			);
		}
	}
	return $pairs;
}

/**
 * Of het pad na een archiefbasis een archiefadres is, zoals in de rewrite rules van een post type-archief: niets, een
 * pagina (/page/2/) of een feed (/feed/, /feed/rss2/, /rss2/).
 *
 * @param string $rest Het pad na de basis, met slash ervoor of leeg.
 */
function _ww_language_base_is_archive_rest( string $rest ): bool {
	global $wp_rewrite;
	if ( ! $wp_rewrite instanceof WP_Rewrite ) {
		return '' === trim( $rest, '/' );
	}
	$feeds = implode( '|', array_map( static fn( mixed $feed ): string => preg_quote( (string) $feed, '#' ), (array) $wp_rewrite->feeds ) );
	$page  = preg_quote( $wp_rewrite->pagination_base, '#' );
	$base  = preg_quote( $wp_rewrite->feed_base, '#' );
	return 1 === preg_match( '#^(/' . $page . '/[0-9]+|(/' . $base . ')?/(' . $feeds . '))?/?$#', $rest );
}

/**
 * Vervangt de basis aan het begin van een pad: met $translate de echte door de vertaalde basis, anders andersom. Het
 * pad is wat na het pad van de site en het voorvoegsel komt, met een slash ervoor; een querystring en fragment mogen
 * erachter. Alleen hele segmenten: /projecten-oud/ heeft niet de basis projecten. Zonder paar blijft het pad staan.
 *
 * @param string $path      Pad, zoals '/projecten/brug/?a=1'.
 * @param string $lang      Taalcode.
 * @param bool   $translate Echte basis naar vertaalde basis (true) of terug (false).
 */
function _ww_language_base_replace( string $path, string $lang, bool $translate ): string {
	$pairs = _ww_language_base_pairs( $lang );
	if ( array() === $pairs || 1 !== preg_match( '#^/([^?\#]*)(.*)$#s', $path, $match ) ) {
		return $path;
	}
	$inner = $match[1];

	// Een archiefpaar eerst (het geldt alleen voor een archiefadres), daarna het langste pad.
	$candidates = array();
	foreach ( $pairs as $pair ) {
		$candidates[] = array(
			'from'    => $translate ? $pair['real'] : $pair['translated'],
			'to'      => $translate ? $pair['translated'] : $pair['real'],
			'archive' => $pair['archive'],
		);
	}
	usort(
		$candidates,
		static fn( array $a, array $b ): int => array( (int) $b['archive'], strlen( $b['from'] ) ) <=> array( (int) $a['archive'], strlen( $a['from'] ) )
	);

	foreach ( $candidates as $candidate ) {
		if ( $inner !== $candidate['from'] && ! str_starts_with( $inner, $candidate['from'] . '/' ) ) {
			continue;
		}
		$rest = substr( $inner, strlen( $candidate['from'] ) );
		if ( $candidate['archive'] && ! _ww_language_base_is_archive_rest( $rest ) ) {
			continue;
		}
		return '/' . $candidate['to'] . $rest . $match[2];
	}
	return $path;
}

/**
 * De routing: een vertaalde basis aan het begin van het pad (na het voorvoegsel) wordt de echte basis, zodat de
 * ongewijzigde rewrite rules het pad parsen. '/projects/brug/?a=1' wordt '/projecten/brug/?a=1'.
 *
 * @param string $path Pad na het pad van de site en het voorvoegsel, met slash ervoor.
 * @param string $lang Taalcode van het voorvoegsel.
 */
function _ww_language_base_unswap( string $path, string $lang ): string {
	return _ww_language_base_replace( $path, $lang, false );
}

/**
 * Deelt een adres op deze site op in het begin (host en pad van de site), de code van een extra taal direct daarna
 * ('' zonder voorvoegsel) en de rest. Null voor een adres op een andere host of een relatief adres. Dezelfde regels als
 * _ww_languages_relink().
 *
 * @param string $url Volledig adres.
 * @return array{0:string,1:string,2:string}|null
 */
function _ww_language_base_split_url( string $url ): ?array {
	$host = wp_parse_url( (string) get_option( 'home' ) );
	if ( ! is_array( $host ) || empty( $host['host'] ) ) {
		return null;
	}
	$authority = $host['host'] . ( isset( $host['port'] ) ? ':' . $host['port'] : '' );
	$pattern   = '#^((?:https?:)?//' . preg_quote( $authority, '#' ) . preg_quote( _ww_languages_home_path(), '#' ) . ')(?=[/?\#]|$)(.*)$#is';
	if ( 1 !== preg_match( $pattern, $url, $match ) ) {
		return null;
	}
	if ( 1 === preg_match( '#^/([^/?\#]+)(.*)$#s', $match[2], $segment ) && in_array( $segment[1], _ww_extra_language_codes(), true ) ) {
		return array( $match[1], $segment[1], $segment[2] );
	}
	return array( $match[1], '', $match[2] );
}

/**
 * De links: in een adres met het voorvoegsel van $lang wordt de echte basis direct na het voorvoegsel de vertaalde
 * basis. Een adres zonder dat voorvoegsel (de standaardtaal, een andere taal, een andere host) blijft staan.
 *
 * @param string $url  Volledig adres.
 * @param string $lang Taalcode.
 */
function _ww_language_base_swap( string $url, string $lang ): string {
	$split = _ww_language_base_split_url( $url );
	if ( null === $split || '' === $split[1] || $split[1] !== $lang ) {
		return $url;
	}
	return $split[0] . '/' . $lang . _ww_language_base_replace( $split[2], $lang, true );
}

/**
 * Zet een adres in een andere taal, met de basis: de vertaalde basis van de taal van het adres wordt de echte, het
 * voorvoegsel wisselt (_ww_languages_relink()) en de echte basis wordt de vertaalde van de nieuwe taal. Voor de
 * taalwisselaar en hreflang op een archief, waar het adres van het verzoek in elke taal nodig is.
 *
 * @param string $url  Volledig adres.
 * @param string $lang Taalcode.
 */
function _ww_language_base_relink( string $url, string $lang ): string {
	$split = _ww_language_base_split_url( $url );
	if ( null !== $split && '' !== $split[1] ) {
		$url = $split[0] . '/' . $split[1] . _ww_language_base_unswap( $split[2], $split[1] );
	}
	return _ww_language_base_swap( _ww_languages_relink( $url, $lang ), $lang );
}

/**
 * Filter post_type_link en post_type_archive_link (prioriteit 20, na het voorvoegsel van de kern): de vertaalde basis
 * van de taal van het voorvoegsel dat de link al heeft (de taal van het bericht, of bij een archief de huidige taal).
 *
 * @param mixed $link Adres.
 * @return mixed
 */
function _ww_language_base_link( mixed $link ): mixed {
	if ( ! is_string( $link ) || '' === $link ) {
		return $link;
	}
	$split = _ww_language_base_split_url( $link );
	return null === $split || '' === $split[1] ? $link : _ww_language_base_swap( $link, $split[1] );
}

/**
 * Filter term_link (prioriteit 20, na de kern en de vertaalde slug van 3b op 11): de vertaalde basis, zoals
 * _ww_language_base_link(). Niet zolang de termen ruw gevraagd worden (_ww_languages_terms_raw()): dan blijft de link
 * gewoon, zodat _ww_languages_term_archive_urls() hem per taal kan omzetten.
 *
 * @param mixed $link Adres.
 * @return mixed
 */
function _ww_language_base_term_link( mixed $link ): mixed {
	return _ww_languages_terms_raw() ? $link : _ww_language_base_link( $link );
}

/**
 * Of een redirectregel (inc/redirects.php) dit verzoek doorstuurt. Die regel gaat voor de 301 naar de vertaalde basis,
 * want de regels draaien op template_redirect pas na de 301's van de taalmodule.
 *
 * @param string $uri REQUEST_URI.
 */
function _ww_language_base_rule_exists( string $uri ): bool {
	if ( ! function_exists( '_ww_redirect_resolve' ) || ! _ww_redirect_is_frontend_request() ) {
		return false;
	}
	return null !== _ww_redirect_resolve( wp_unslash( $uri ) );
}

/**
 * Hangt de linkfilters op, alleen met de module aan (zie _ww_languages_boot()). De routing en de 301 zitten in de
 * hooks van de kern (inc/languages-routing.php).
 */
function _ww_languages_boot_bases(): void {
	add_filter( 'post_type_link', '_ww_language_base_link', 20 );
	add_filter( 'post_type_archive_link', '_ww_language_base_link', 20 );
	add_filter( 'term_link', '_ww_language_base_term_link', 20 );
}
