<?php
/**
 * Statistieken: de tabellen (beslissing 0038).
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// WW_STATS_DB_VERSION staat in stats-collect.php: het meetpunt leest hem ook, vóór het thema.
const WW_STATS_FLAG      = 'ww_stats_summarized_until';
const WW_STATS_MU_PLUGIN = 'webwerckt-base-stats.php';

/**
 * Legt de tabellen aan (of werkt ze bij) en bewaart de schemaversie. Geeft false als de tabellen er daarna nog niet
 * allemaal zijn (dan blijft de oude schemaversie staan).
 */
function _ww_stats_install(): bool {
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	$old_version = (string) get_option( 'ww_stats_db_version', '' );

	dbDelta(
		'CREATE TABLE ' . _ww_stats_hits_table() . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  day date NOT NULL,
  path varchar(255) NOT NULL DEFAULT '',
  referrer varchar(100) NOT NULL DEFAULT '',
  utm_source varchar(100) NOT NULL DEFAULT '',
  utm_medium varchar(100) NOT NULL DEFAULT '',
  utm_campaign varchar(100) NOT NULL DEFAULT '',
  device varchar(7) NOT NULL DEFAULT '',
  country char(2) NOT NULL DEFAULT '',
  visitor char(16) NOT NULL DEFAULT '',
  entry tinyint(1) NOT NULL DEFAULT 0,
  ts int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY  (id),
  KEY day_visitor (day,visitor),
  KEY day (day),
  KEY ts (ts)
) " . $wpdb->get_charset_collate() . ';'
	);
	dbDelta(
		'CREATE TABLE ' . _ww_stats_events_table() . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  day date NOT NULL,
  ts int(10) unsigned NOT NULL DEFAULT 0,
  visitor char(16) NOT NULL DEFAULT '',
  path varchar(255) NOT NULL DEFAULT '',
  type varchar(5) NOT NULL DEFAULT '',
  kind varchar(10) NOT NULL DEFAULT '',
  target varchar(191) NOT NULL DEFAULT '',
  label varchar(80) NOT NULL DEFAULT '',
  form_id bigint(20) unsigned NOT NULL DEFAULT 0,
  step smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY  (id),
  KEY day_visitor (day,visitor),
  KEY ts (ts)
) " . $wpdb->get_charset_collate() . ';'
	);
	dbDelta(
		'CREATE TABLE ' . _ww_stats_daily_table() . " (
  day date NOT NULL,
  kind varchar(10) NOT NULL DEFAULT '',
  item varchar(255) NOT NULL DEFAULT '',
  views int(10) unsigned NOT NULL DEFAULT 0,
  visitors int(10) unsigned NOT NULL DEFAULT 0,
  bounces int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY  (day,kind,item(191))
) " . $wpdb->get_charset_collate() . ';'
	);

	// Alleen als alle drie de tabellen er echt zijn, is het schema klaar. Een SELECT in plaats van SHOW TABLES: die laat tijdelijke tabellen (de testsuite) niet zien.
	$suppressed = $wpdb->suppress_errors( true );
	$complete   = false !== $wpdb->query( 'SELECT 1 FROM ' . _ww_stats_hits_table() . ' LIMIT 1' ) // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_stats_hits_table().
		&& false !== $wpdb->query( 'SELECT 1 FROM ' . _ww_stats_daily_table() . ' LIMIT 1' ) // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_stats_daily_table().
		&& false !== $wpdb->query( 'SELECT 1 FROM ' . _ww_stats_events_table() . ' LIMIT 1' ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_stats_events_table().
	$wpdb->suppress_errors( $suppressed );
	if ( ! $complete ) {
		return false;
	}

	// Migratie van schemaversie 1: het oude samenvatten, één keer, en dan de vlag.
	if ( '1' === $old_version || '' === _ww_stats_summarized_until() ) {
		_ww_stats_migrate( wp_date( 'Y-m-d' ) );
	}

	update_option( 'ww_stats_db_version', WW_STATS_DB_VERSION, true );
	wp_set_option_autoload( 'ww_stats_db_version', true );
	return true;
}

/**
 * Migratie naar de vlag: één keer het oude samenvatten (optellen, ruwe rijen wissen), dan de vlag.
 *
 * De vlag komt op gisteren, of op de dag vóór de oudste ruwe dag die het oude samenvatten liet staan (een dag die
 * mislukte). Die dag en de dagen erna worden dan door _ww_stats_aggregate() opnieuw opgebouwd, en tot dan live gelezen.
 *
 * @param string $today Vandaag (Y-m-d).
 */
function _ww_stats_migrate( string $today ): void {
	_ww_stats_aggregate_legacy( $today );
	$date   = new DateTimeImmutable( $today, wp_timezone() );
	$oldest = _ww_stats_raw_days( '', $date->modify( '-1 day' )->format( 'Y-m-d' ) );
	if ( null === $oldest ) {
		// Niet te lezen: niets aannemen, de oudste nog mogelijke ruwe dag (37 dagen) wordt dan opnieuw opgebouwd.
		$flag = $date->modify( '-38 days' )->format( 'Y-m-d' );
	} elseif ( array() !== $oldest ) {
		$flag = ( new DateTimeImmutable( $oldest[0], wp_timezone() ) )->modify( '-1 day' )->format( 'Y-m-d' );
	} else {
		$flag = $date->modify( '-1 day' )->format( 'Y-m-d' );
	}
	_ww_stats_set_summarized_until( $flag );
}

/**
 * De laatste datum (Y-m-d) waarvan de dagrijen kloppen, of een lege tekst als de vlag er niet is.
 */
function _ww_stats_summarized_until(): string {
	return (string) get_option( WW_STATS_FLAG, '' );
}

/**
 * Zet de vlag "samengevat tot en met" (autoload uit).
 *
 * @param string $day Datum, Y-m-d.
 */
function _ww_stats_set_summarized_until( string $day ): void {
	update_option( WW_STATS_FLAG, $day, false );
}

/**
 * Zet de vlag op $day als die later is dan de huidige vlag: de vlag gaat alleen vooruit.
 *
 * @param string $day Datum, Y-m-d.
 */
function _ww_stats_raise_summarized_until( string $day ): void {
	if ( $day > _ww_stats_summarized_until() ) {
		_ww_stats_set_summarized_until( $day );
	}
}

add_action(
	'admin_init',
	static function (): void {
		if ( get_option( 'ww_stats_db_version' ) !== WW_STATS_DB_VERSION ) {
			_ww_stats_install();
		}
	}
);
add_action(
	'after_switch_theme',
	static function (): void {
		_ww_stats_install();
	}
);

/**
 * Of de mu-plugin van het meetpunt in wp-content/mu-plugins staat. Zonder hem zou elke hit een volledige pagina van
 * WordPress laden.
 */
function _ww_stats_mu_plugin_ok(): bool {
	return is_readable( trailingslashit( WPMU_PLUGIN_DIR ) . WW_STATS_MU_PLUGIN );
}

/**
 * Of het beacon op deze pagina hoort: niet voor ingelogde gebruikers, niet in de admin, niet in Visueel bewerken, niet in
 * een voorbeeld, niet zonder de mu-plugin van het meetpunt, en niet als het filter ww_stats false geeft. Ingelogde
 * gebruikers krijgen nooit een gecachete pagina.
 */
function _ww_stats_enabled(): bool {
	if ( is_user_logged_in() || is_admin() || 0 !== _ww_editor_post_id() || is_preview() || ! _ww_stats_mu_plugin_ok() ) {
		return false;
	}
	return (bool) apply_filters( 'ww_stats', true );
}

/**
 * Laadt het beacon (footer, defer). De doel-URL staat als data-ww-stats op de tag, zodat de gecachete HTML volstaat.
 */
function _ww_stats_enqueue(): void {
	if ( ! _ww_stats_enabled() ) {
		return;
	}
	wp_enqueue_script(
		'ww-stats',
		_ww_asset_url( 'js/stats.js' ),
		array(),
		WW_BASE_VERSION,
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);
}
add_action( 'wp_enqueue_scripts', '_ww_stats_enqueue' );

/**
 * Zet data-ww-stats met het adres van het meetpunt op de scripttag van het beacon.
 *
 * @param string $tag    De scripttag.
 * @param string $handle Naam van het script.
 */
function _ww_stats_script_tag( string $tag, string $handle ): string {
	if ( 'ww-stats' !== $handle ) {
		return $tag;
	}
	return str_replace( '<script ', '<script data-ww-stats="' . esc_url( home_url( '/?ww_hit=1' ) ) . '" ', $tag );
}
add_filter( 'script_loader_tag', '_ww_stats_script_tag', 10, 2 );

const WW_STATS_CRON_HOOK = 'ww_stats_daily';
const WW_STATS_TOP       = 500;
const WW_STATS_LOCK      = 'ww_stats_aggregate_lock';
const WW_STATS_REBUILT   = 'ww_stats_rebuilt';

/**
 * De herkomst van een binnenkomst als één naam. Bekende diensten worden samengevoegd via een tabel met hostpatronen
 * (fnmatch), een lege host wordt direct en alle andere hosts blijven zoals ze zijn (zonder www.).
 *
 * @param string $host Verwijzerhost, zoals bewaard in ww_stats_hits.
 */
function _ww_stats_referrer_group( string $host ): string {
	$host = strtolower( trim( $host ) );
	if ( str_starts_with( $host, 'www.' ) ) {
		$host = substr( $host, 4 );
	}
	if ( '' === $host ) {
		return 'direct';
	}
	$patterns = array(
		'google'     => array( 'google.*', '*.google.*' ),
		'bing'       => array( 'bing.*', '*.bing.*' ),
		'duckduckgo' => array( 'duckduckgo.com', '*.duckduckgo.com' ),
		'ecosia'     => array( 'ecosia.org', '*.ecosia.org' ),
		'yahoo'      => array( 'yahoo.*', '*.yahoo.*' ),
		'facebook'   => array( 'facebook.com', 'l.facebook.com', 'm.facebook.com', '*.facebook.com' ),
		'instagram'  => array( 'instagram.com', '*.instagram.com' ),
		'linkedin'   => array( 'linkedin.com', '*.linkedin.com', 'lnkd.in' ),
		'x'          => array( 't.co', 'x.com', 'twitter.com', '*.twitter.com' ),
		'youtube'    => array( 'youtube.com', '*.youtube.com', 'youtu.be' ),
		'pinterest'  => array( 'pinterest.*', '*.pinterest.*' ),
	);
	foreach ( $patterns as $name => $list ) {
		foreach ( $list as $pattern ) {
			if ( fnmatch( $pattern, $host ) ) {
				return $name;
			}
		}
	}
	return $host;
}

/**
 * Houdt per soort de 500 sleutels met de meeste weergaven (bij gelijk aantal de sleutel oplopend) en telt de rest op
 * in één rij (overige).
 *
 * @param string                                      $kind  Soort.
 * @param array<string,array{views:int,visitors:int}> $items Sleutel naar tellingen.
 * @return list<array{kind:string,item:string,views:int,visitors:int,bounces:int}>
 */
function _ww_stats_top_rows( string $kind, array $items ): array {
	// De sleutel van dagrijen is hoogstens 191 tekens (primaire sleutel); langere sleutels worden afgekapt en samengevoegd.
	$capped = array();
	foreach ( $items as $key => $counts ) {
		$key                         = mb_substr( (string) $key, 0, 191 );
		$capped[ $key ]['views']     = ( $capped[ $key ]['views'] ?? 0 ) + $counts['views'];
		$capped[ $key ]['visitors']  = ( $capped[ $key ]['visitors'] ?? 0 ) + $counts['visitors'];
	}
	$items = $capped;
	$keys  = array_map( 'strval', array_keys( $items ) );
	usort(
		$keys,
		static function ( string $a, string $b ) use ( $items ): int {
			return ( $items[ $b ]['views'] <=> $items[ $a ]['views'] ) ?: strcmp( $a, $b );
		}
	);
	$rows = array();
	$rest = array(
		'views'    => 0,
		'visitors' => 0,
	);
	foreach ( $keys as $i => $key ) {
		if ( $i < WW_STATS_TOP ) {
			$rows[] = array(
				'kind'     => $kind,
				'item'     => $key,
				'views'    => $items[ $key ]['views'],
				'visitors' => $items[ $key ]['visitors'],
				'bounces'  => 0,
			);
		} else {
			$rest['views']    += $items[ $key ]['views'];
			$rest['visitors'] += $items[ $key ]['visitors'];
		}
	}
	if ( count( $keys ) > WW_STATS_TOP ) {
		$rows[] = array(
			'kind'     => $kind,
			'item'     => '(overige)',
			'views'    => $rest['views'],
			'visitors' => $rest['visitors'],
			'bounces'  => 0,
		);
	}
	return $rows;
}

/**
 * Of de laatste query van $wpdb faalde.
 */
function _ww_stats_db_failed(): bool {
	global $wpdb;
	return '' !== $wpdb->last_error;
}

/**
 * Leest rijen en geeft null als de query faalde (dan is lege uitkomst geen bewijs van "geen gegevens").
 *
 * @param string $sql Voorbereide SELECT.
 * @return list<array<string,mixed>>|null
 */
function _ww_stats_read( string $sql ): ?array {
	global $wpdb;
	$wpdb->last_error = '';
	$rows             = $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- al voorbereid door de aanroeper.
	if ( _ww_stats_db_failed() || ! is_array( $rows ) ) {
		return null;
	}
	return array_values( $rows );
}

/**
 * Rekent de ruwe weergaven en gebeurtenissen van één dag om naar dagrijen, met de top 500 en (overige) al toegepast.
 * Schrijft niets. Zie _ww_stats_summarize_hits(), _ww_stats_summarize_visits() en _ww_stats_summarize_events().
 *
 * @param string $day Datum, Y-m-d.
 * @return list<array{kind:string,item:string,views:int,visitors:int,bounces:int}>|null Null als een query faalde: dan mag er niets worden geschreven.
 */
function _ww_stats_summarize_day( string $day ): ?array {
	$rows = _ww_stats_summarize_hits( $day );
	if ( null === $rows ) {
		return null;
	}
	// Routes en uitstappen alleen als er weergaven zijn; een bezoek met alleen gebeurtenissen heeft er geen.
	if ( array() !== $rows ) {
		$visits = _ww_stats_summarize_visits( $day );
		if ( null === $visits ) {
			return null;
		}
		$rows = array_merge( $rows, $visits );
	}
	$events = _ww_stats_summarize_events( $day );
	if ( null === $events ) {
		return null;
	}
	return array_merge( $rows, $events );
}

/**
 * De dagrijen uit de ruwe weergaven van één dag. Leeg als er die dag geen weergaven zijn.
 *
 * - page: weergaven = treffers, bezoekers = unieke hashes op dat pad.
 * - referrer en campaign: alleen binnenkomsten (entry = 1); weergaven en bezoekers zijn allebei hun aantal. Campaign
 *   alleen met een utm_source, als bron / medium / campagne met - voor een ontbrekend deel.
 * - device en country: elke bezoeker telt voor de waarde van zijn binnenkomst; heeft hij die dag geen binnenkomst
 *   (een late treffer na een gedeeltelijke samenvatting), dan voor zijn eerste treffer. Een leeg land (onbekend) krijgt item ''.
 * - total: treffers, unieke hashes en bezoekers met precies één treffer (bounces).
 *
 * @param string $day Datum, Y-m-d.
 * @return list<array{kind:string,item:string,views:int,visitors:int,bounces:int}>|null Null als een query faalde.
 */
function _ww_stats_summarize_hits( string $day ): ?array {
	global $wpdb;
	$hits = _ww_stats_hits_table();
	$rows = array();
	$wpdb->last_error = '';

	$total = $wpdb->get_row( $wpdb->prepare( "SELECT COUNT(*) AS views, COUNT(DISTINCT visitor) AS visitors FROM {$hits} WHERE day = %s", $day ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_stats_hits_table().
	if ( ! is_array( $total ) || _ww_stats_db_failed() ) {
		return null;
	}
	if ( 0 === (int) $total['views'] ) {
		return array();
	}
	$bounces = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM ( SELECT visitor FROM {$hits} WHERE day = %s GROUP BY visitor HAVING COUNT(*) = 1 ) AS single", $day ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_stats_hits_table().
	if ( null === $bounces ) {
		return null;
	}
	$rows[]  = array(
		'kind'     => 'total',
		'item'     => '',
		'views'    => (int) $total['views'],
		'visitors' => (int) $total['visitors'],
		'bounces'  => (int) $bounces,
	);

	$items = array();
	$res = _ww_stats_read( $wpdb->prepare( "SELECT path AS item, COUNT(*) AS views, COUNT(DISTINCT visitor) AS visitors FROM {$hits} WHERE day = %s GROUP BY path", $day ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_stats_hits_table().
	if ( null === $res ) {
		return null;
	}
	foreach ( $res as $r ) {
		$items[ (string) $r['item'] ] = array(
			'views'    => (int) $r['views'],
			'visitors' => (int) $r['visitors'],
		);
	}
	$rows = array_merge( $rows, _ww_stats_top_rows( 'page', $items ) );

	$items = array();
	$res = _ww_stats_read( $wpdb->prepare( "SELECT referrer AS item, COUNT(*) AS n FROM {$hits} WHERE day = %s AND entry = 1 GROUP BY referrer", $day ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_stats_hits_table().
	if ( null === $res ) {
		return null;
	}
	foreach ( $res as $r ) {
		$group = _ww_stats_referrer_group( (string) $r['item'] );
		$n     = (int) $r['n'];

		$items[ $group ]['views']    = ( $items[ $group ]['views'] ?? 0 ) + $n;
		$items[ $group ]['visitors'] = ( $items[ $group ]['visitors'] ?? 0 ) + $n;
	}
	$rows = array_merge( $rows, _ww_stats_top_rows( 'referrer', $items ) );

	$items = array();
	$res = _ww_stats_read( $wpdb->prepare( "SELECT utm_source, utm_medium, utm_campaign, COUNT(*) AS n FROM {$hits} WHERE day = %s AND entry = 1 AND utm_source <> '' GROUP BY utm_source, utm_medium, utm_campaign", $day ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_stats_hits_table().
	if ( null === $res ) {
		return null;
	}
	foreach ( $res as $r ) {
		$key = $r['utm_source'] . ' / ' . ( '' !== $r['utm_medium'] ? $r['utm_medium'] : '-' ) . ' / ' . ( '' !== $r['utm_campaign'] ? $r['utm_campaign'] : '-' );
		$n   = (int) $r['n'];

		$items[ $key ]['views']    = ( $items[ $key ]['views'] ?? 0 ) + $n;
		$items[ $key ]['visitors'] = ( $items[ $key ]['visitors'] ?? 0 ) + $n;
	}
	$rows = array_merge( $rows, _ww_stats_top_rows( 'campaign', $items ) );

	// Per bezoeker de treffer waaraan hij wordt toegerekend: zijn binnenkomst, anders zijn eerste treffer.
	foreach ( array( 'device', 'country' ) as $column ) {
		$items = array();
		$res = _ww_stats_read( $wpdb->prepare( "SELECT h.{$column} AS item, COUNT(*) AS visitors, SUM(v.views) AS views FROM ( SELECT visitor, COALESCE( MIN( CASE WHEN entry = 1 THEN id END ), MIN(id) ) AS pick, COUNT(*) AS views FROM {$hits} WHERE day = %s GROUP BY visitor ) AS v INNER JOIN {$hits} AS h ON h.id = v.pick GROUP BY h.{$column}", $day ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabel- en kolomnaam vast in de code.
		if ( null === $res ) {
			return null;
		}
		foreach ( $res as $r ) {
			$items[ (string) $r['item'] ] = array(
				'views'    => (int) $r['views'],
				'visitors' => (int) $r['visitors'],
			);
		}
		$rows = array_merge( $rows, _ww_stats_top_rows( $column, $items ) );
	}
	return $rows;
}

/**
 * De dagrijen flow en exit uit de bezoeken van één dag (zie _ww_stats_each_visit_batch()).
 *
 * - flow: elke twee opeenvolgende weergaven binnen één bezoek met een ander pad, als "van → naar"; weergaven = aantal
 *   overgangen, bezoekers = unieke bezoekers. Gebeurtenissen tellen niet mee.
 * - exit: het pad van de laatste weergave van elk bezoek; weergaven = aantal bezoeken, bezoekers = unieke bezoekers.
 *
 * De dag wordt per portie van $batch bezoekers gelezen; elke bezoeker zit in precies één portie, dus de unieke
 * bezoekers per portie mogen worden opgeteld.
 *
 * @param string $day   Datum, Y-m-d.
 * @param int    $batch Bezoekers per portie.
 * @return list<array{kind:string,item:string,views:int,visitors:int,bounces:int}>|null Null als een query faalde.
 */
function _ww_stats_summarize_visits( string $day, int $batch = 500 ): ?array {
	$counts   = array(
		'flow' => array(),
		'exit' => array(),
	);
	$visitors = $counts;
	$ok       = _ww_stats_each_visit_batch(
		$day,
		$batch,
		static function ( array $visits ) use ( &$counts, &$visitors ): void {
			$who = array(
				'flow' => array(),
				'exit' => array(),
			);
			foreach ( $visits as $visit ) {
				$prev = null;
				foreach ( $visit['items'] as $item ) {
					if ( 'view' !== $item['type'] ) {
						continue;
					}
					if ( null !== $prev && $prev !== $item['path'] ) {
						$key = $prev . " \u{2192} " . $item['path'];

						$counts['flow'][ $key ]                   = ( $counts['flow'][ $key ] ?? 0 ) + 1;
						$who['flow'][ $key ][ $visit['visitor'] ] = true;
					}
					$prev = $item['path'];
				}
				if ( null !== $prev ) {
					$counts['exit'][ $prev ]                   = ( $counts['exit'][ $prev ] ?? 0 ) + 1;
					$who['exit'][ $prev ][ $visit['visitor'] ] = true;
				}
			}
			foreach ( $who as $kind => $list ) {
				foreach ( $list as $key => $set ) {
					$visitors[ $kind ][ $key ] = ( $visitors[ $kind ][ $key ] ?? 0 ) + count( $set );
				}
			}
		}
	);
	if ( ! $ok ) {
		return null;
	}
	$rows = array();
	foreach ( $counts as $kind => $list ) {
		$items = array();
		foreach ( $list as $key => $n ) {
			$items[ (string) $key ] = array(
				'views'    => $n,
				'visitors' => $visitors[ $kind ][ $key ],
			);
		}
		$rows = array_merge( $rows, _ww_stats_top_rows( $kind, $items ) );
	}
	return $rows;
}

/**
 * De dagrijen click en form uit de ruwe gebeurtenissen van één dag. Geteld met GROUP BY, zodat bezoekers uniek zijn.
 *
 * - click: soort|tekst|doel, bij knop knop|tekst|pad. Het doel wordt eerst ingekort, zodat de sleutel hoogstens 191
 *   tekens is en soort en tekst heel blijven.
 * - form: formId|view, formId|start, formId|sent of formId|step|n.
 *
 * @param string $day Datum, Y-m-d.
 * @return list<array{kind:string,item:string,views:int,visitors:int,bounces:int}>|null Null als een query faalde.
 */
function _ww_stats_summarize_events( string $day ): ?array {
	global $wpdb;
	$events = _ww_stats_events_table();

	$res = _ww_stats_read( $wpdb->prepare( "SELECT kind, label, CASE WHEN kind = 'knop' THEN path ELSE target END AS dest, COUNT(*) AS views, COUNT(DISTINCT visitor) AS visitors FROM {$events} WHERE day = %s AND type = 'click' GROUP BY kind, label, CASE WHEN kind = 'knop' THEN path ELSE target END", $day ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_stats_events_table().
	if ( null === $res ) {
		return null;
	}
	$items = array();
	foreach ( $res as $r ) {
		// Het doel heeft al geen | (_ww_stats_event_target()), het pad van een knop wel: de browser codeert | in een pad niet.
		$prefix = $r['kind'] . '|' . $r['label'] . '|';
		$dest   = str_replace( '|', '%7C', (string) $r['dest'] );
		$key    = $prefix . mb_substr( $dest, 0, max( 0, 191 - mb_strlen( $prefix ) ) );

		$items[ $key ]['views']    = ( $items[ $key ]['views'] ?? 0 ) + (int) $r['views'];
		$items[ $key ]['visitors'] = ( $items[ $key ]['visitors'] ?? 0 ) + (int) $r['visitors'];
	}
	$rows = _ww_stats_top_rows( 'click', $items );

	$res = _ww_stats_read( $wpdb->prepare( "SELECT form_id, kind, CASE WHEN kind = 'step' THEN step ELSE 0 END AS n, COUNT(*) AS views, COUNT(DISTINCT visitor) AS visitors FROM {$events} WHERE day = %s AND type = 'form' GROUP BY form_id, kind, CASE WHEN kind = 'step' THEN step ELSE 0 END", $day ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_stats_events_table().
	if ( null === $res ) {
		return null;
	}
	$items = array();
	foreach ( $res as $r ) {
		$key = 'step' === $r['kind'] ? $r['form_id'] . '|step|' . (int) $r['n'] : $r['form_id'] . '|' . $r['kind'];

		$items[ $key ]['views']    = ( $items[ $key ]['views'] ?? 0 ) + (int) $r['views'];
		$items[ $key ]['visitors'] = ( $items[ $key ]['visitors'] ?? 0 ) + (int) $r['visitors'];
	}
	return array_merge( $rows, _ww_stats_top_rows( 'form', $items ) );
}

/**
 * Vervangt de dagrijen van één dag: eerst alles van die dag wissen, dan invoegen (in blokken van 100 rijen). De
 * aanroeper draait dit in een transactie.
 *
 * Invoegen met ON DUPLICATE KEY UPDATE (optellen): na de DELETE kunnen alleen sleutels botsen die in PHP verschillen
 * maar volgens de collatie gelijk zijn (bv. /café/ en /cafe/). Die worden zo samengevoegd, zoals GROUP BY bij het lezen
 * ook doet, in plaats van dat de dag bij elke run terugdraait en de vlag blijft steken.
 *
 * @param string                                                                  $day  Datum, Y-m-d.
 * @param list<array{kind:string,item:string,views:int,visitors:int,bounces:int}> $rows Rijen.
 * @return bool False als een query faalde.
 */
function _ww_stats_replace_rows( string $day, array $rows ): bool {
	global $wpdb;
	$table = _ww_stats_daily_table();
	if ( false === $wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE day = %s", $day ) ) ) { // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_stats_daily_table().
		return false;
	}
	foreach ( array_chunk( $rows, 100 ) as $chunk ) {
		$values = array();
		foreach ( $chunk as $row ) {
			$values[] = $wpdb->prepare( '(%s, %s, %s, %d, %d, %d)', $day, $row['kind'], $row['item'], $row['views'], $row['visitors'], $row['bounces'] );
		}
		if ( false === $wpdb->query( "INSERT INTO {$table} (day, kind, item, views, visitors, bounces) VALUES " . implode( ', ', $values ) . ' ON DUPLICATE KEY UPDATE views = views + VALUES(views), visitors = visitors + VALUES(visitors), bounces = bounces + VALUES(bounces)' ) ) { // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_stats_daily_table(), waarden voorbereid.
			return false;
		}
	}
	return true;
}

/**
 * De datums (Y-m-d, oplopend) met ruwe weergaven of gebeurtenissen, na $after (niet meegerekend; '' = vanaf het
 * begin) tot en met $to.
 *
 * @param string $after Datum, Y-m-d, of ''.
 * @param string $to    Datum, Y-m-d.
 * @return list<string>|null Null als de query faalde.
 */
function _ww_stats_raw_days( string $after, string $to ): ?array {
	global $wpdb;
	$hits   = _ww_stats_hits_table();
	$events = _ww_stats_events_table();
	if ( '' === $after ) {
		$sql = $wpdb->prepare( "SELECT day FROM {$hits} WHERE day <= %s UNION SELECT day FROM {$events} WHERE day <= %s", $to, $to ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnamen uit de helpers.
	} else {
		$sql = $wpdb->prepare( "SELECT day FROM {$hits} WHERE day > %s AND day <= %s UNION SELECT day FROM {$events} WHERE day > %s AND day <= %s", $after, $to, $after, $to ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnamen uit de helpers.
	}
	$rows = _ww_stats_read( $sql );
	if ( null === $rows ) {
		return null;
	}
	$days = array_values( array_unique( array_map( static fn( array $r ): string => (string) $r['day'], $rows ) ) );
	sort( $days, SORT_STRING );
	return $days;
}

/**
 * Telt dagrijen op bij de bestaande rijen van dezelfde sleutel. Alleen voor _ww_stats_aggregate_legacy().
 *
 * Gekozen route: INSERT ... ON DUPLICATE KEY UPDATE (werkt ook met de SQLite-drop-in, zie de tests).
 *
 * @param string                                                                  $day  Datum, Y-m-d.
 * @param list<array{kind:string,item:string,views:int,visitors:int,bounces:int}> $rows Rijen.
 * @return bool False als een query faalde.
 */
function _ww_stats_store_rows( string $day, array $rows ): bool {
	global $wpdb;
	$table = _ww_stats_daily_table();
	foreach ( $rows as $row ) {
		$result = $wpdb->query( $wpdb->prepare( "INSERT INTO {$table} (day, kind, item, views, visitors, bounces) VALUES (%s, %s, %s, %d, %d, %d) ON DUPLICATE KEY UPDATE views = views + VALUES(views), visitors = visitors + VALUES(visitors), bounces = bounces + VALUES(bounces)", $day, $row['kind'], $row['item'], $row['views'], $row['visitors'], $row['bounces'] ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_stats_daily_table().
		if ( false === $result ) {
			return false;
		}
	}
	return true;
}

/**
 * Het oude samenvatten van beslissing 0038, alleen nog voor de migratie in _ww_stats_migrate().
 *
 * Wist eerst de salts van andere dagen, vat dan elke dag vóór vandaag samen waarvoor nog ruwe treffers staan, en ruimt
 * daarna op (ook als het samenvatten een fout gooit). Geeft het aantal samengevatte dagen terug.
 *
 * Per dag, in één transactie: de nieuwe rijen worden OPGETELD bij de bestaande dagrijen (niets wissen en opnieuw
 * invoegen) en de ruwe rijen van die dag verdwijnen. Een tweede run vindt dus niets meer en telt niets dubbel. Een
 * late treffer van een bezoeker die die dag al was samengevat, telt hem twee keer als bezoeker: een geaccepteerde
 * benadering. Een dag gaat terug (ROLLBACK) en komt de volgende keer opnieuw aan bod als een lezing of schrijfactie
 * faalt, of als de DELETE niet precies het aantal samengevatte treffers wist: dan draaide er gelijktijdig een andere run
 * of kwam er tussen lezen en wissen een treffer bij, die anders ongeteld zou verdwijnen.
 *
 * Alleen de migratie naar schemaversie 2 gebruikt deze variant nog.
 *
 * @param string $today Vandaag (Y-m-d).
 */
function _ww_stats_aggregate_legacy( string $today ): int {
	global $wpdb;
	$hits  = _ww_stats_hits_table();
	// Oude salts gaan ook weg als er vandaag nog geen hit kwam.
	_ww_stats_drop_old_salts( $today );
	$days  = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT day FROM {$hits} WHERE day < %s ORDER BY day ASC", $today ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_stats_hits_table().
	$done  = 0;
	try {
		foreach ( (array) $days as $day ) {
			$day = (string) $day;
			$wpdb->query( 'START TRANSACTION' );
			$rows = _ww_stats_summarize_day( $day );
			$ok   = null !== $rows && _ww_stats_store_rows( $day, $rows );
			if ( $ok ) {
				// Moet precies de gesommeerde treffers wissen: anders was er een gelijktijdige run of een late treffer.
				$expected = 0;
				foreach ( (array) $rows as $row ) {
					if ( 'total' === $row['kind'] ) {
						$expected = $row['views'];
					}
				}
				$deleted = $wpdb->query( $wpdb->prepare( "DELETE FROM {$hits} WHERE day = %s", $day ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_stats_hits_table().
				$ok      = $deleted === $expected;
			}
			if ( $ok ) {
				$wpdb->query( 'COMMIT' );
				++$done;
			} else {
				$wpdb->query( 'ROLLBACK' );
			}
		}
	} finally {
		// Pas na het samenvatten opruimen: een oude dag die nog niet was samengevat, telt zo toch mee.
		_ww_stats_cleanup( $today );
	}
	return $done;
}

/**
 * Neemt het applicatieslot van _ww_stats_aggregate(): een optie met het tijdstip waarop het slot verloopt (5 minuten).
 *
 * Zoals bij _ww_stats_salt() met INSERT IGNORE, want add_option() overschrijft bij een dubbele sleutel en is dus geen
 * slot. Staat er al een slot dat verlopen is, dan wordt het overgenomen met een vergelijkende UPDATE: van twee runs die
 * dat tegelijk proberen, wint er één. Alles direct in de database, buiten de optiecache.
 *
 * @return string|null De waarde van het eigen slot (nodig om het weer weg te halen), of null als een ander het heeft.
 */
function _ww_stats_aggregate_lock(): ?string {
	global $wpdb;
	$mine = (string) ( time() + 300 );
	if ( 1 === $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'off')", WW_STATS_LOCK, $mine ) ) ) {
		return $mine;
	}
	$held = $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", WW_STATS_LOCK ) );
	if ( null === $held || (int) $held >= time() ) {
		return null;
	}
	if ( 1 === $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = %s AND option_value = %s", $mine, WW_STATS_LOCK, $held ) ) ) {
		return $mine;
	}
	return null;
}

/**
 * Haalt het eigen slot weg. Alleen met de eigen waarde: heeft een ander het verlopen slot intussen overgenomen, dan
 * blijft dat van hem staan.
 *
 * @param string $mine Waarde uit _ww_stats_aggregate_lock().
 */
function _ww_stats_aggregate_unlock( string $mine ): void {
	global $wpdb;
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s", WW_STATS_LOCK, $mine ) );
	wp_cache_delete( WW_STATS_LOCK, 'options' );
	wp_cache_delete( 'notoptions', 'options' );
}

/**
 * De hoogste id van de ruwe weergaven en van de ruwe gebeurtenissen van één dag (0 zonder rijen), of null als een
 * query faalde.
 *
 * @param string $day Datum, Y-m-d.
 * @return array{0:int,1:int}|null
 */
function _ww_stats_max_ids( string $day ): ?array {
	global $wpdb;
	$ids = array();
	foreach ( array( _ww_stats_hits_table(), _ww_stats_events_table() ) as $table ) {
		$rows = _ww_stats_read( $wpdb->prepare( "SELECT MAX(id) AS id FROM {$table} WHERE day = %s", $day ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit de helpers.
		if ( null === $rows ) {
			return null;
		}
		$ids[] = (int) ( $rows[0]['id'] ?? 0 );
	}
	return array( $ids[0], $ids[1] );
}

/**
 * Bouwt de dagrijen opnieuw op uit de ruwe rijen, zet de vlag "samengevat" en ruimt daarna op (ook na een fout of
 * uitzondering). Geeft het aantal opgebouwde datums terug.
 *
 * - Slot: draait er al een run (het slot ww_stats_aggregate_lock is jonger dan 5 minuten), dan doet deze niets en geeft
 *   0. Zie _ww_stats_aggregate_lock().
 * - Welke datums: elke datum na de vlag en vóór vandaag met ruwe weergaven of gebeurtenissen, plus gisteren als die
 *   ruwe rijen heeft (een hit die zijn datum vlak voor middernacht kreeg maar pas na het samenvatten binnenkwam), oplopend.
 * - Een datum tot en met de vlag (dat kan alleen gisteren zijn) wordt overgeslagen als de hoogste id's van zijn ruwe
 *   weergaven en gebeurtenissen niet veranderd zijn sinds hij werd opgebouwd (de optie ww_stats_rebuilt, alleen voor
 *   gisteren). Zo bouwt niet elk bezoek aan het scherm of het dashboard gisteren opnieuw op, en telt een late hit toch.
 * - Per datum, in één transactie: de dagrijen van die datum wissen en opnieuw invoegen (_ww_stats_replace_rows()), dan
 *   de vlag op die datum als die later is. De ruwe rijen blijven staan; _ww_stats_cleanup() wist ze na 30 dagen.
 * - Twee keer draaien geeft hetzelfde; het slot houdt een gelijktijdige tweede run tegen.
 * - Bij een fout: ROLLBACK, de vlag blijft staan en de volgende datums komen de volgende keer aan bod.
 * - Lukte alles, dan gaat de vlag naar gisteren: datums zonder ruwe rijen hebben niets op te bouwen, en hun dagrijen
 *   (bijvoorbeeld van de migratie) kloppen.
 *
 * Het optellen bij bestaande dagrijen en de controle "DELETE wist precies zoveel treffers" gelden alleen nog voor
 * _ww_stats_aggregate_legacy().
 *
 * @param string|null $today Vandaag (Y-m-d); standaard de datum van de site.
 */
function _ww_stats_aggregate( ?string $today = null ): int {
	$lock = _ww_stats_aggregate_lock();
	if ( null === $lock ) {
		return 0;
	}
	try {
		return _ww_stats_aggregate_locked( $today ?? (string) wp_date( 'Y-m-d' ) );
	} finally {
		_ww_stats_aggregate_unlock( $lock );
	}
}

/**
 * Het werk van _ww_stats_aggregate(), met het slot in handen.
 *
 * @param string $today Vandaag (Y-m-d).
 */
function _ww_stats_aggregate_locked( string $today ): int {
	global $wpdb;
	$yesterday = ( new DateTimeImmutable( $today, wp_timezone() ) )->modify( '-1 day' );
	// Oude salts gaan ook weg als er vandaag nog geen hit kwam.
	_ww_stats_drop_old_salts( $today );
	$done = 0;
	try {
		// Na de vlag, en altijd gisteren: begin dan ten laatste bij eergisteren (niet meegerekend).
		$flag  = _ww_stats_summarized_until();
		$after = $yesterday->modify( '-1 day' )->format( 'Y-m-d' );
		$after = ( '' === $flag || $flag < $after ) ? $flag : $after;
		$days  = _ww_stats_raw_days( $after, $yesterday->format( 'Y-m-d' ) );
		if ( null === $days ) {
			return 0;
		}
		$rebuilt = get_option( WW_STATS_REBUILT, array() );
		$rebuilt = is_array( $rebuilt ) ? $rebuilt : array();
		foreach ( $days as $day ) {
			// Vóór het samenvatten gelezen: een hit die daarna nog binnenkomt, laat de volgende run opnieuw opbouwen.
			$max = _ww_stats_max_ids( $day );
			if ( null !== $max && '' !== $flag && $day <= $flag && ( $rebuilt[ $day ] ?? null ) === $max ) {
				continue;
			}
			$wpdb->query( 'START TRANSACTION' );
			$rows = _ww_stats_summarize_day( $day );
			if ( null === $rows || ! _ww_stats_replace_rows( $day, $rows ) || false === $wpdb->query( 'COMMIT' ) ) {
				$wpdb->query( 'ROLLBACK' );
				return $done;
			}
			++$done;
			_ww_stats_raise_summarized_until( $day );
			if ( null !== $max && $yesterday->format( 'Y-m-d' ) === $day ) {
				update_option( WW_STATS_REBUILT, array( $day => $max ), false );
			}
		}
		_ww_stats_raise_summarized_until( $yesterday->format( 'Y-m-d' ) );
	} catch ( Throwable $e ) {
		// Geen open transactie laten staan: anders draait het opruimen erbinnen.
		$wpdb->query( 'ROLLBACK' );
		throw $e;
	} finally {
		// Pas na het samenvatten opruimen.
		_ww_stats_cleanup( $today );
	}
	return $done;
}

/**
 * Ruimt op:
 *
 * - ruwe weergaven en gebeurtenissen met day <= vlag en ouder dan 30 dagen;
 * - ruwe rijen ouder dan 37 dagen altijd, ook als hun dag niet is samengevat (zo groeit de tabel niet als het
 *   samenvatten steeds mislukt);
 * - dagrijen ouder dan 25 maanden.
 *
 * @param string $today Vandaag, Y-m-d.
 */
function _ww_stats_cleanup( string $today ): void {
	global $wpdb;
	$date  = new DateTimeImmutable( $today, wp_timezone() );
	$flag  = _ww_stats_summarized_until();
	$day30 = $date->modify( '-30 days' )->format( 'Y-m-d' );
	$day37 = $date->modify( '-37 days' )->format( 'Y-m-d' );
	$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . _ww_stats_daily_table() . ' WHERE day < %s', $date->modify( '-25 months' )->format( 'Y-m-d' ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_stats_daily_table().
	foreach ( array( _ww_stats_hits_table(), _ww_stats_events_table() ) as $table ) {
		if ( '' !== $flag ) {
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE day <= %s AND day < %s", $flag, $day30 ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit de helpers.
		}
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE day < %s", $day37 ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit de helpers.
	}
}

/**
 * Callback van de dagelijkse cron. Staat de schemaversie nog niet goed (een uitrol zonder adminbezoek), dan eerst
 * installeren; lukt dat niet, dan niet samenvatten (de tabellen zijn er dan nog niet).
 */
function _ww_stats_cron(): void {
	if ( get_option( 'ww_stats_db_version' ) !== WW_STATS_DB_VERSION && ! _ww_stats_install() ) {
		return;
	}
	_ww_stats_aggregate();
}
add_action( WW_STATS_CRON_HOOK, '_ww_stats_cron' );

/**
 * Plant de dagelijkse samenvatting in bij een adminbezoek.
 */
function _ww_stats_schedule(): void {
	if ( ! wp_next_scheduled( WW_STATS_CRON_HOOK ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', WW_STATS_CRON_HOOK );
	}
}
add_action( 'admin_init', '_ww_stats_schedule' );

/**
 * Haalt de samenvatting weg bij een themawissel.
 */
function _ww_stats_unschedule(): void {
	wp_clear_scheduled_hook( WW_STATS_CRON_HOOK );
}
add_action( 'switch_theme', '_ww_stats_unschedule' );

/**
 * Geeft een bestaande datum Y-m-d terug als object, anders null.
 *
 * @param mixed $value Invoer, mogelijk geen tekenreeks.
 */
function _ww_stats_valid_day( $value ): ?DateTimeImmutable {
	if ( ! is_string( $value ) ) {
		return null;
	}
	$date = DateTimeImmutable::createFromFormat( '!Y-m-d', $value, wp_timezone() );
	return ( $date && $date->format( 'Y-m-d' ) === $value ) ? $date : null;
}

/**
 * Bepaalt de periode en de vergelijkingsperiode uit de queryvariabelen van het scherm.
 *
 * range=today|7d|30d|12m, of from en to (Y-m-d, from <= to, hoogstens 3 jaar, niet in de toekomst). Al het andere
 * wordt 30d. De vergelijkingsperiode is even lang en ligt er direct voor.
 *
 * @param array<string,mixed> $query Bijvoorbeeld $_GET; waarden kunnen van alles zijn.
 * @param string              $today Vandaag, Y-m-d.
 * @return array{from:string,to:string,prev_from:string,prev_to:string,range:string}
 */
function _ww_stats_period( array $query, string $today ): array {
	$end   = new DateTimeImmutable( $today, wp_timezone() );
	$range = '30d';
	$from  = $end->modify( '-29 days' );
	$to    = $end;

	$range_in = $query['range'] ?? null;
	$days     = array(
		'today' => 0,
		'7d'    => 6,
		'30d'   => 29,
		'12m'   => 364,
	);
	if ( is_string( $range_in ) && isset( $days[ $range_in ] ) ) {
		$range = $range_in;
		$from  = $end->modify( '-' . $days[ $range_in ] . ' days' );
	} else {
		$custom_from = _ww_stats_valid_day( $query['from'] ?? null );
		$custom_to   = _ww_stats_valid_day( $query['to'] ?? null );
		if (
			$custom_from && $custom_to
			&& $custom_from <= $custom_to
			&& $custom_to <= $end
			&& $custom_to < $custom_from->modify( '+3 years' )
		) {
			$range = 'custom';
			$from  = $custom_from;
			$to    = $custom_to;
		}
	}

	$length    = (int) $from->diff( $to )->days + 1;
	$prev_to   = $from->modify( '-1 day' );
	$prev_from = $prev_to->modify( '-' . ( $length - 1 ) . ' days' );
	return array(
		'from'      => $from->format( 'Y-m-d' ),
		'to'        => $to->format( 'Y-m-d' ),
		'prev_from' => $prev_from->format( 'Y-m-d' ),
		'prev_to'   => $prev_to->format( 'Y-m-d' ),
		'range'     => $range,
	);
}

/**
 * Verschil in procenten, afgerond. Null als er niets is om mee te vergelijken.
 */
function _ww_stats_change( int $current, int $previous ): ?int {
	if ( 0 === $previous ) {
		return null;
	}
	return (int) round( ( $current - $previous ) / $previous * 100 );
}

/**
 * Leest een periode: datums tot en met de vlag uit de dagtabel, latere datums live uit de ruwe rijen met
 * _ww_stats_summarize_day() (zonder te schrijven). Zo telt geen dag dubbel en is er geen gat.
 *
 * Een ruwe dag waarvan het berekenen faalt blijft buiten het resultaat; dan wordt er niets bewaard. Een periode die
 * voor vandaag eindigt staat 10 minuten in een transient. De lijsten click, form, flow en exit houden de top 500, de
 * andere de top 100.
 *
 * @param string      $from  Eerste dag, Y-m-d.
 * @param string      $to    Laatste dag, Y-m-d.
 * @param string|null $today Vandaag (Y-m-d); standaard de datum van de site.
 * @return array{totals:array{views:int,visitors:int,bounces:int},series:array<string,array{views:int,visitors:int}>,lists:array<string,list<array{item:string,views:int,visitors:int}>>}
 */
function _ww_stats_query( string $from, string $to, ?string $today = null ): array {
	global $wpdb;
	$today     = $today ?? wp_date( 'Y-m-d' );
	$cacheable = $to < $today;
	$key       = 'ww_stats_' . md5( "$from|$to" );
	if ( $cacheable ) {
		$cached = get_transient( $key );
		if ( is_array( $cached ) && isset( $cached['totals'], $cached['series'], $cached['lists'] ) ) {
			return $cached;
		}
	}

	$ok     = true;
	$totals = array(
		'views'    => 0,
		'visitors' => 0,
		'bounces'  => 0,
	);
	$series = array();
	$cursor = new DateTimeImmutable( $from, wp_timezone() );
	$last   = new DateTimeImmutable( $to, wp_timezone() );
	while ( $cursor <= $last ) {
		$series[ $cursor->format( 'Y-m-d' ) ] = array(
			'views'    => 0,
			'visitors' => 0,
		);
		$cursor = $cursor->modify( '+1 day' );
	}
	$sums  = array();
	$daily = _ww_stats_daily_table();
	$flag  = _ww_stats_summarized_until();

	// Tot en met de vlag uit de dagtabel; zonder vlag (of een vlag vóór de periode) niets.
	$daily_to   = $flag < $to ? $flag : $to;
	$total_rows = array();
	$item_rows  = array();
	if ( '' !== $flag && $from <= $flag ) {
		$total_rows = _ww_stats_read( $wpdb->prepare( "SELECT day, views, visitors, bounces FROM {$daily} WHERE kind = 'total' AND day BETWEEN %s AND %s", $from, $daily_to ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_stats_daily_table().
		$item_rows  = _ww_stats_read( $wpdb->prepare( "SELECT kind, item, SUM(views) AS views, SUM(visitors) AS visitors FROM {$daily} WHERE kind <> 'total' AND day BETWEEN %s AND %s GROUP BY kind, item", $from, $daily_to ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_stats_daily_table().
	}
	if ( null === $total_rows ) {
		$ok = false;
	}
	foreach ( (array) $total_rows as $row ) {
		$day = (string) $row['day'];
		if ( ! isset( $series[ $day ] ) ) {
			continue;
		}
		$series[ $day ]['views']    += (int) $row['views'];
		$series[ $day ]['visitors'] += (int) $row['visitors'];
		$totals['views']            += (int) $row['views'];
		$totals['visitors']         += (int) $row['visitors'];
		$totals['bounces']          += (int) $row['bounces'];
	}

	if ( null === $item_rows ) {
		$ok = false;
	}
	foreach ( (array) $item_rows as $row ) {
		$kind = (string) $row['kind'];
		$item = (string) $row['item'];
		$sums[ $kind ][ $item ] = array(
			'views'    => (int) $row['views'],
			'visitors' => (int) $row['visitors'],
		);
	}

	// Na de vlag live, alleen de datums die ruwe rijen hebben.
	$before   = ( new DateTimeImmutable( $from, wp_timezone() ) )->modify( '-1 day' )->format( 'Y-m-d' );
	$raw_days = $to > $flag ? _ww_stats_raw_days( ( '' === $flag || $flag < $before ) ? $before : $flag, $to ) : array();
	if ( null === $raw_days ) {
		$ok       = false;
		$raw_days = array();
	}
	foreach ( $raw_days as $day ) {
		$rows = _ww_stats_summarize_day( $day );
		if ( null === $rows ) {
			$ok = false; // Deze dag blijft buiten het resultaat, en er wordt niets bewaard.
			continue;
		}
		foreach ( $rows as $row ) {
			if ( 'total' === $row['kind'] ) {
				if ( isset( $series[ $day ] ) ) {
					$series[ $day ]['views']    += $row['views'];
					$series[ $day ]['visitors'] += $row['visitors'];
				}
				$totals['views']    += $row['views'];
				$totals['visitors'] += $row['visitors'];
				$totals['bounces']  += $row['bounces'];
				continue;
			}
			$sums[ $row['kind'] ][ $row['item'] ]['views']    = ( $sums[ $row['kind'] ][ $row['item'] ]['views'] ?? 0 ) + $row['views'];
			$sums[ $row['kind'] ][ $row['item'] ]['visitors'] = ( $sums[ $row['kind'] ][ $row['item'] ]['visitors'] ?? 0 ) + $row['visitors'];
		}
	}

	$lists = array();
	foreach ( $sums as $kind => $items ) {
		$list = array();
		foreach ( $items as $item => $sum ) {
			$list[] = array(
				'item'     => (string) $item,
				'views'    => $sum['views'],
				'visitors' => $sum['visitors'],
			);
		}
		// Land en apparaat tonen een deel van de bezoekers, dus daar telt het aantal bezoekers; de rest op weergaven.
		// Bij gelijk aantal het item oplopend, als tekst (strcmp): '10' en '9' zijn geen getallen.
		$by = in_array( $kind, array( 'country', 'device' ), true ) ? 'visitors' : 'views';
		usort(
			$list,
			static function ( array $a, array $b ) use ( $by ): int {
				return ( $b[ $by ] <=> $a[ $by ] ) ?: strcmp( $a['item'], $b['item'] );
			}
		);
		$lists[ (string) $kind ] = array_slice( $list, 0, in_array( $kind, array( 'click', 'form', 'flow', 'exit' ), true ) ? WW_STATS_TOP : 100 );
	}

	$result = array(
		'totals' => $totals,
		'series' => $series,
		'lists'  => $lists,
	);
	if ( $cacheable && $ok ) {
		set_transient( $key, $result, 10 * MINUTE_IN_SECONDS );
	}
	return $result;
}

/**
 * Verwijdert de tabellen, de schemaversie, de vlag, het slot, de optie ww_stats_rebuilt, de saltopties, de transients
 * en de geplande samenvatting.
 */
function _ww_stats_drop_tables(): void {
	global $wpdb;
	$wpdb->query( 'DROP TABLE IF EXISTS ' . _ww_stats_hits_table() ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.SchemaChange -- tabelnaam uit _ww_stats_hits_table().
	$wpdb->query( 'DROP TABLE IF EXISTS ' . _ww_stats_daily_table() ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.SchemaChange -- tabelnaam uit _ww_stats_daily_table().
	$wpdb->query( 'DROP TABLE IF EXISTS ' . _ww_stats_events_table() ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.SchemaChange -- tabelnaam uit _ww_stats_events_table().
	delete_option( 'ww_stats_db_version' );
	delete_option( WW_STATS_FLAG );
	delete_option( WW_STATS_REBUILT );
	delete_option( WW_STATS_LOCK );
	$salts = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like( 'ww_stats_salt_' ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	foreach ( (array) $salts as $name ) {
		delete_option( (string) $name );
	}
	$transients = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", $wpdb->esc_like( '_transient_ww_stats_' ) . '%', $wpdb->esc_like( '_transient_timeout_ww_stats_' ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	foreach ( (array) $transients as $name ) {
		delete_option( (string) $name );
	}
	wp_clear_scheduled_hook( WW_STATS_CRON_HOOK );
}

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	/**
	 * Commando's voor de statistieken van het thema.
	 */
	class WW_Stats_CLI_Command {

		/**
		 * Vat alle afgelopen dagen samen en ruimt op.
		 *
		 * ## EXAMPLES
		 *
		 *     wp ww stats aggregate
		 *
		 * @param array<int,string>    $args       Positionele argumenten.
		 * @param array<string,string> $assoc_args Benoemde argumenten.
		 */
		public function aggregate( $args, $assoc_args ): void {
			$days = _ww_stats_aggregate();
			WP_CLI::success( sprintf( '%d dag(en) samengevat.', $days ) );
		}

		/**
		 * Verwijdert de tabellen van de statistieken, de schemaversie, de vlag en de saltopties.
		 *
		 * ## OPTIONS
		 *
		 * [--yes]
		 * : Niet om bevestiging vragen.
		 *
		 * ## EXAMPLES
		 *
		 *     wp ww stats drop-tables --yes
		 *
		 * @subcommand drop-tables
		 *
		 * @param array<int,string>    $args       Positionele argumenten.
		 * @param array<string,string> $assoc_args Benoemde argumenten.
		 */
		public function drop_tables( $args, $assoc_args ): void {
			WP_CLI::confirm( 'Alle statistieken van deze site verwijderen? Dit kan niet ongedaan worden gemaakt.', $assoc_args );
			_ww_stats_drop_tables();
			WP_CLI::success( 'De tabellen ww_stats_hits, ww_stats_events en ww_stats_daily zijn verwijderd.' );
		}
	}
	WP_CLI::add_command( 'ww stats', 'WW_Stats_CLI_Command' );
}
