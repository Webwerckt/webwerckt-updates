<?php
/**
 * De 404-pagina: nooit in een paginacache, en suggesties voor wat de bezoeker zocht. Titel en tekst staan in de
 * Site-instellingen (notfound_title, notfound_text), net als de vaste pagina's die de 404 als suggestie toont
 * (notfound_pages). Het child-thema maakt de HTML in 404.php; een child-thema zonder 404.php en zonder eigen
 * index.php krijgt de kale versie uit de index.php van de parent.
 *
 * Noindex op de 404 staat in inc/integrations/seo.php. De gok van WordPress zelf (redirect_guess_404_permalink: een
 * 301 als er precies één bericht met die slug is) blijft aan.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Een 404 en zoekresultaten horen niet in een paginacache: een 404 zou anders als gewone pagina blijven hangen, en
 * zoekresultaten zijn er in ontelbare varianten.
 */
function _ww_not_cacheable_pages(): void {
	if ( is_404() ) {
		do_action( 'ww_cacheable', false, 'ww 404' );
	} elseif ( is_search() ) {
		do_action( 'ww_cacheable', false, 'ww search' );
	}
}
add_action( 'template_redirect', '_ww_not_cacheable_pages' );

/**
 * Het laatste deel van de opgevraagde URL als zoekwoorden: /diensten/dak-reparatie/ wordt "dak reparatie". Hoogstens
 * WW_SEARCH_MAX_LENGTH tekens, net als de zoekfunctie: een 404 komt nooit in de cache, en scanners vragen er veel op.
 */
function _ww_404_words(): string {
	global $wp;
	$path  = $wp instanceof WP ? (string) $wp->request : '';
	$words = str_replace( '-', ' ', sanitize_title( basename( $path ) ) );
	return trim( mb_substr( $words, 0, WW_SEARCH_MAX_LENGTH ) );
}

/**
 * Berichten die lijken op het laatste deel van de opgevraagde URL, de beste eerst. Dezelfde post types als de
 * zoekfunctie (inc/search.php), inclusief het filter ww_search_post_types.
 *
 * @return int[]
 */
function _ww_404_similar( int $limit ): array {
	$words = _ww_404_words();
	$types = _ww_search_post_types();
	if ( '' === $words || array() === $types ) {
		return array();
	}
	$query = new WP_Query(
		array(
			'post_type'              => $types,
			'post_status'            => 'publish',
			's'                      => $words,
			'orderby'                => 'relevance',
			'posts_per_page'         => $limit,
			'fields'                 => 'ids',
			'no_found_rows'          => true,
			'ignore_sticky_posts'    => true,
			'update_post_term_cache' => false,
		)
	);
	return array_map( 'intval', $query->posts );
}

/**
 * Suggesties voor een 404: eerst berichten die lijken op het laatste deel van de opgevraagde URL, daarna de vaste
 * pagina's uit de Site-instellingen (notfound_pages), tot er $limit zijn. Alleen gepubliceerde berichten, elk één keer.
 *
 *     <?php foreach ( ww_404_suggestions() as $id ) : ?>
 *         <li><a href="<?php echo esc_url( get_permalink( $id ) ); ?>"><?php echo esc_html( get_the_title( $id ) ); ?></a></li>
 *     <?php endforeach; ?>
 *
 * @param int $limit Hoeveel suggesties hoogstens.
 * @return int[]
 */
function ww_404_suggestions( int $limit = 3 ): array {
	if ( $limit <= 0 ) {
		return array();
	}
	$ids = array_merge( is_404() ? _ww_404_similar( $limit ) : array(), _ww_data_to_ids( _ww_data_get_setting( 'notfound_pages' ) ) );
	$ids = array_values( array_unique( $ids ) );
	_prime_post_caches( $ids );
	return array_slice( array_values( array_filter( $ids, '_ww_data_is_published' ) ), 0, $limit );
}
