<?php
/**
 * Kleine gedeelde hulpfuncties voor de andere onderdelen van de parent.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Statussen van berichten die een redacteur in een lijst wil zien: alles behalve prullenbak en automatische concepten.
const WW_EDITABLE_STATUSES = array( 'publish', 'future', 'draft', 'pending', 'private' );

/**
 * Hoofdquery van WordPress, of null buiten een request.
 */
function _ww_main_query(): ?WP_Query {
	$query = $GLOBALS['wp_query'] ?? null;
	return $query instanceof WP_Query ? $query : null;
}

/**
 * Tekst zonder HTML en zonder entiteiten, zoals een titel bedoeld is (&#8217; wordt ’).
 */
function _ww_plain_text( string $text ): string {
	return trim( html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
}

/**
 * De berichtenpagina (Instellingen → Lezen), of 0 als de site geen vaste voorpagina heeft of de pagina niet
 * gepubliceerd is. Breadcrumbs en schema gebruiken dezelfde pagina, zodat ze niet uit elkaar lopen.
 */
function _ww_posts_page_id(): int {
	$page = (int) get_option( 'page_for_posts' );
	return $page > 0 && 'page' === get_option( 'show_on_front' ) && _ww_data_is_published( $page ) ? $page : 0;
}

/**
 * Een sleutel uit de querystring ($_GET), gesaneerd met sanitize_key(), of '' als hij ontbreekt of geen tekst is.
 * Alleen om te lezen: wie er iets mee wijzigt, controleert zelf recht en nonce.
 */
function _ww_query_key( string $name ): string {
	$value = $_GET[ $name ] ?? ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput -- alleen lezen, gesaneerd hieronder.
	return is_string( $value ) ? sanitize_key( wp_unslash( $value ) ) : '';
}

/**
 * Is dit een webverzoek van een bezoeker die niet is ingelogd, buiten de admin en de REST API? Voor zo'n verzoek
 * hoeft WordPress niets te registreren dat alleen bij bewerken nodig is. Betrouwbaar vanaf init: dan is de gebruiker bekend.
 * De REST API telt nooit als bezoeker: een applicatiewachtwoord logt pas na init in.
 *
 * @param string $sapi Server-API van PHP; WP-CLI, cron via de commandoregel en de tests zijn nooit een bezoeker.
 */
function _ww_is_visitor_request( string $sapi = PHP_SAPI ): bool {
	if ( 'cli' === $sapi || is_admin() || wp_doing_ajax() || wp_doing_cron() || is_user_logged_in() ) {
		return false;
	}
	if ( ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) || isset( $_GET['rest_route'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return false;
	}
	$path = (string) wp_parse_url( _ww_data_to_string( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	return ! str_contains( $path . '/', '/' . trim( rest_get_url_prefix(), '/' ) . '/' );
}

/**
 * Pad van een bestand in een themamap bij zijn URL, of '' als de URL niet in die map ligt. Query en fragment tellen
 * niet mee. Of het bestand bestaat, controleert de aanroeper.
 *
 * @param string $url     URL van het bestand.
 * @param string $dir_url URL van de themamap, zonder slash aan het eind.
 * @param string $dir     Pad van de themamap.
 */
function _ww_theme_file( string $url, string $dir_url, string $dir ): string {
	$url = (string) strtok( $url, '?#' );
	return str_starts_with( $url, $dir_url . '/' ) ? $dir . substr( $url, strlen( $dir_url ) ) : '';
}

/**
 * Uitkomst van een eigen test in Site-status, met de badge "Prestaties" of een andere.
 *
 * @param string $test        Naam van de test.
 * @param string $label       Kop van de uitkomst.
 * @param string $status      'good', 'recommended' of 'critical'.
 * @param string $description HTML onder de kop, al ge-escaped.
 * @param string $badge       Label van de badge; standaard "Prestaties".
 * @return array<string,mixed>
 */
function _ww_health_result( string $test, string $label, string $status, string $description, string $badge = '' ): array {
	return array(
		'label'       => $label,
		'status'      => $status,
		'badge'       => array(
			'label' => '' === $badge ? __( 'Prestaties', 'webwerckt-base' ) : $badge,
			'color' => 'blue',
		),
		'description' => $description,
		'actions'     => '',
		'test'        => $test,
	);
}

/**
 * Laadt de uitgelichte afbeeldingen van een lijst berichten in één query, met hun meta (afmetingen, alt-tekst).
 * WordPress doet dat alleen in een lus met the_post(); kaarten gebruiken setup_postdata(), dus zonder dit kost
 * elke kaart met een afbeelding twee eigen query's.
 *
 * @param int[] $post_ids Bericht-ID's.
 */
function _ww_prime_thumbnails( array $post_ids ): void {
	if ( array() === $post_ids ) {
		return;
	}
	// Meestal al geladen door WP_Query of _prime_post_caches(); dan doet dit niets.
	update_meta_cache( 'post', $post_ids );
	$thumbnails = array_filter( array_map( static fn( int $id ): int => (int) get_post_thumbnail_id( $id ), $post_ids ) );
	_prime_post_caches( array_values( array_unique( $thumbnails ) ), false );
}

/**
 * data-ww-attributen, ge-escaped.
 *
 * @param array<string,string> $attrs Naam zonder 'data-ww-' => waarde.
 */
function _ww_html_attrs( array $attrs ): string {
	$out = array();
	foreach ( $attrs as $name => $value ) {
		$out[] = sprintf( 'data-ww-%s="%s"', sanitize_key( $name ), esc_attr( $value ) );
	}
	return implode( ' ', $out );
}

/**
 * URL van een bestand in assets/ van de parent.
 *
 * @param string $path Pad binnen assets/, bijvoorbeeld 'js/editor.js'.
 */
function _ww_asset_url( string $path ): string {
	return get_template_directory_uri() . '/assets/' . $path;
}

/**
 * Laadt een script uit assets/js/ als ES-module, met gedeelde modules als afhankelijkheid: 'rest' voor meer laden en
 * filteren, voor visueel bewerken 'editor-protocol' en de modules die de editor importeert.
 *
 * @param string          $name   Bestandsnaam zonder .js, bijvoorbeeld 'load-more'.
 * @param string|string[] $shared Bestandsnaam of bestandsnamen van de gedeelde modules, zonder .js.
 */
function _ww_enqueue_module( string $name, $shared = 'rest' ): void {
	$dependencies = array();
	foreach ( (array) $shared as $module ) {
		wp_register_script_module( 'ww-' . $module, _ww_asset_url( 'js/' . $module . '.js' ), array(), WW_BASE_VERSION );
		$dependencies[] = 'ww-' . $module;
	}
	wp_enqueue_script_module( 'ww-' . $name, _ww_asset_url( 'js/' . $name . '.js' ), $dependencies, WW_BASE_VERSION );
}

/**
 * wp_update_post() zoals "Bijwerken" in de admin: revisie, de kopie naar post_content (inc/content.php) en het legen
 * van de cache hangen eraan. Het template blijft staan: wp_update_post() geeft anders het huidige template mee, dat
 * voor de klant niet in de lijst staat (_ww_lock_templates()), en dan breekt WordPress het opslaan halverwege af,
 * na de update maar vóór save_post. Wie het template wél wijzigt, geeft page_template zelf mee.
 *
 * @param array<string,mixed> $update ID en de kolommen die veranderen, niet geslasht.
 * @return int|WP_Error Bericht-ID of fout.
 */
function _ww_update_post( array $update ) {
	return wp_update_post( wp_slash( $update + array( 'page_template' => '' ) ), true );
}

/**
 * Is dit een versie als 1.2.3, zoals in style.css, de update-informatie en WW_REQUIRES_BASE?
 */
function _ww_is_version( string $version ): bool {
	return 1 === preg_match( '/^\d+\.\d+\.\d+$/', $version );
}

/**
 * Maakt een concept met alleen een titel, voor de ability create-post en de editor. Een bericht met alleen een
 * titel hoort niet live te staan.
 *
 * @param string $post_type Post type, al gecontroleerd.
 * @param string $title     Titel, al gesaneerd en niet geslasht.
 * @return int|WP_Error Bericht-ID of fout.
 */
function _ww_create_draft( string $post_type, string $title ) {
	return wp_insert_post(
		wp_slash(
			array(
				'post_type'   => $post_type,
				'post_title'  => $title,
				'post_status' => 'draft',
			)
		),
		true
	);
}

/**
 * Meldt (met WP_DEBUG aan) dat een registratie te laat komt: na $hook heeft hij geen effect meer.
 * Zonder deze melding doet zo'n aanroep stil niets. Registraties uit het child-thema horen in after_setup_theme.
 *
 * @param string $function Naam van de publieke functie.
 * @param string $hook     Hook waarna de registratie niet meer meetelt.
 */
function _ww_warn_if_too_late( string $function, string $hook ): void {
	if ( did_action( $hook ) ) {
		_doing_it_wrong(
			esc_html( $function ),
			esc_html( sprintf( 'Roep %1$s() aan in de hook after_setup_theme; na %2$s heeft de registratie geen effect meer.', $function, $hook ) ),
			'0.2.0'
		);
	}
}
