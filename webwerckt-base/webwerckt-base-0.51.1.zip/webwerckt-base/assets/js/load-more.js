// Meer laden: progressive enhancement op een gewone link naar de volgende pagina.
// Zonder JavaScript (of bij een fout) werkt de knop als normale paginering.
// Pagina en filter staan in de data-attributen van de knop, zodat filter.js ze kan bijwerken.

import { announce, cardsEndpoint, fetchCards, listFor, navigate, parseCards, parseTax, sameOriginUrl } from 'ww-rest';

const SELECTOR = '[data-ww-load-more]';
// Het endpoint staat vast voor deze pagina: één keer lezen, niet per knop.
const ENDPOINT = cardsEndpoint();

function init(button) {
	const postType = button.dataset.wwLoadMore;
	const list = listFor(postType);
	const endpoint = ENDPOINT;
	if (!list || !endpoint) {
		return;
	}

	button.addEventListener('click', async (event) => {
		event.preventDefault();
		if (button.getAttribute('aria-busy') === 'true') {
			return;
		}
		button.setAttribute('aria-busy', 'true');

		const { wwPage: shownPage, wwTax: tax } = button.dataset;
		const page = (parseInt(shownPage, 10) || 1) + 1;
		try {
			const data = await fetchCards(endpoint, postType, page, parseTax(tax));
			// Intussen een ander filter gekozen: filter.js heeft de lijst al vervangen, deze kaarten horen er niet meer bij.
			if (button.dataset.wwTax !== tax || button.dataset.wwPage !== shownPage) {
				button.removeAttribute('aria-busy');
				return;
			}
			const cards = parseCards(data.html);
			const items = Array.from(cards.children);
			list.append(cards);
			button.dataset.wwPage = String(page);

			if (items.length > 0) {
				items[0].setAttribute('tabindex', '-1');
				items[0].focus();
				announce((button.dataset.wwAdded || '%d').replace('%d', String(items.length)));
			}

			const next = sameOriginUrl(data.next_url);
			if (next) {
				button.href = next;
			}
			button.hidden = !data.has_more;
			button.removeAttribute('aria-busy');
		} catch (error) {
			// Terugvallen op gewone paginering, alleen naar een pagina op dit domein.
			navigate(button.href);
		}
	});
}

document.querySelectorAll(SELECTOR).forEach(init);
