/**
 * Teller onder de SEO-titel en -beschrijving (inc/seo-admin.php, ADR 0024): telt tijdens het typen en zegt of de
 * lengte goed is; een leeg veld zonder homepagetekst ontbreekt. De grenzen en woorden komen uit PHP (window.wwSeo), zodat de teller hetzelfde oordeel geeft als
 * de kolom SEO en Site-status.
 *
 * De velden staan in het vak SEO van het bewerkscherm (inc/field-metaboxes.php) als ww_fields[{veld}]. De teller
 * wacht tot het veld er is en luistert op het document, zodat een later getekend veld gewoon meetelt.
 */
( () => {
	const config = window.wwSeo;
	if ( ! config ) {
		return;
	}

	const fields = { ww_seo_title: 'title', ww_seo_description: 'description' };
	const counters = {};

	const format = ( text, ...values ) => text.replace( /%(\d)\$[ds]/g, ( match, index ) => String( values[ index - 1 ] ) );
	const length = ( text ) => [ ...text.trim().replace( /\s+/g, ' ' ) ].length;
	const status = ( count, [ min, max ] ) => {
		if ( 0 === count ) {
			return 'missing';
		}
		if ( count < min ) {
			return 'short';
		}
		return count > max ? 'long' : 'good';
	};
	const input = ( field ) => document.querySelector( `[name="ww_fields[${ field }]"]` );
	const postTitle = () => document.querySelector( '#title' );

	const update = ( field ) => {
		const out = counters[ field ];
		const element = input( field );
		if ( ! out || ! element ) {
			return;
		}
		const kind = fields[ field ];
		const limits = config.limits[ kind ];
		const own = length( element.value );
		const title = postTitle();
		// De voorpagina valt terug op de Site-instellingen (config.home), zoals _ww_seo_post_report().
		const home = config.home ? length( config.home[ kind ] || '' ) : -1;
		// Leeg zonder homepagetekst is "ontbreekt", zoals in de kolom; wat WordPress er dan van maakt staat erbij,
		// zonder eigen oordeel.
		let result = 'missing';
		let text = 'title' === kind ? config.labels.missing : config.labels.fallbackText;
		if ( own > 0 ) {
			result = status( own, limits );
			text = format( config.labels.count, own, limits[ 1 ], config.labels[ result ] );
		} else if ( home > 0 ) {
			result = status( home, limits );
			text = format( config.labels.fallbackHome, home, config.labels[ result ] );
		} else if ( 'title' === kind && home < 0 && title && length( title.value ) > 0 ) {
			text = format( config.labels.fallback, length( title.value + config.suffix ) );
		}
		out.dataset.wwSeo = result;
		out.textContent = text;
	};

	const attach = () => {
		for ( const field of Object.keys( fields ) ) {
			const element = input( field );
			if ( counters[ field ]?.isConnected || ! element ) {
				continue;
			}
			const out = document.createElement( 'p' );
			out.className = 'ww-seo-count';
			out.setAttribute( 'aria-live', 'polite' );
			element.insertAdjacentElement( 'afterend', out );
			counters[ field ] = out;
			update( field );
		}
		return Object.keys( fields ).every( ( field ) => counters[ field ]?.isConnected );
	};

	document.addEventListener( 'input', ( event ) => {
		const name = event.target?.name ?? '';
		if ( 'post_title' === name ) {
			update( 'ww_seo_title' );
			return;
		}
		const field = name.replace( /^ww_fields\[(.*)\]$/, '$1' );
		if ( fields[ field ] ) {
			update( field );
		}
	} );

	if ( ! attach() ) {
		const observer = new MutationObserver( () => attach() && observer.disconnect() );
		observer.observe( document.body, { childList: true, subtree: true } );
		// Niet eindeloos kijken als een veld er nooit komt (bijvoorbeeld uitgezet in het scherm).
		setTimeout( () => observer.disconnect(), 15000 );
	}
} )();
