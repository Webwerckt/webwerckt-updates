/**
 * Het formulier op het scherm SEO (inc/seo-overview-admin-sections.php, _ww_seo_render_form()): het voorbeeld in
 * Google loopt mee tijdens het typen, en de afbeelding bij delen krijgt de mediakiezer van WordPress. Alleen gemak:
 * zonder dit script toont het voorbeeld de opgeslagen versie en is de afbeelding een getalveld met de bijlage-ID.
 *
 * De terugval bij een leeg veld (de titel van WordPress, het begin van de tekst) staat in data-attributen van het
 * voorbeeld; PHP rekent hem uit zoals de site dat doet (_ww_seo_preview()).
 */
( function () {
	'use strict';

	var form = document.querySelector( '.ww-seo-form' );
	if ( ! form ) {
		return;
	}

	/* Voorbeeld in Google. */

	var preview = form.querySelector( '.ww-seo-preview' );
	var title = form.querySelector( '[name="ww_fields[ww_seo_title]"]' );
	var description = form.querySelector( '[name="ww_fields[ww_seo_description]"]' );

	// Als _ww_plain_text(): zonder HTML en met enkele spaties. DOMParser voert niets uit en laadt niets.
	var parser = new DOMParser();
	function plain( text ) {
		return ( parser.parseFromString( text, 'text/html' ).body.textContent || '' ).replace( /\s+/g, ' ' ).trim();
	}

	// Als _ww_seo_trim(): hoogstens max tekens, op een woordgrens, met … erachter.
	function shorten( text, max ) {
		var chars = Array.from( text );
		if ( chars.length <= max ) {
			return text;
		}
		var cut = chars.slice( 0, max - 1 ).join( '' );
		var space = cut.lastIndexOf( ' ' );
		if ( space > max / 2 ) {
			cut = cut.slice( 0, space );
		}
		return cut.replace( /[\s,.;:–-]+$/, '' ) + '…';
	}

	function updatePreview() {
		var max = parseInt( preview.dataset.max, 10 ) || 155;
		var ownTitle = plain( title.value );
		var ownDescription = plain( description.value );
		preview.querySelector( '.ww-seo-preview__title' ).textContent = ownTitle || preview.dataset.fallbackTitle || '';
		preview.querySelector( '.ww-seo-preview__description' ).textContent = ownDescription ? shorten( ownDescription, max ) : preview.dataset.fallbackDescription || '';
	}

	if ( preview && title && description ) {
		title.addEventListener( 'input', updatePreview );
		description.addEventListener( 'input', updatePreview );
	}

	/* Afbeelding bij delen. */

	var box = form.querySelector( '.ww-seo-image' );
	if ( ! box || ! window.wp || ! window.wp.media ) {
		return;
	}
	var input = box.querySelector( '[name="ww_fields[ww_seo_image]"]' );
	var idRow = box.querySelector( '.ww-seo-image__id' );
	var buttons = box.querySelector( '.ww-seo-image__buttons' );
	var choose = box.querySelector( '.ww-seo-image__choose' );
	var remove = box.querySelector( '.ww-seo-image__remove' );
	var thumb = box.querySelector( '.ww-seo-image__preview' );
	if ( ! input || ! idRow || ! buttons || ! choose || ! remove || ! thumb ) {
		return;
	}

	// Het getalveld wordt een verborgen veld; de knoppen nemen het over. Het label wijst nu naar de knop.
	input.type = 'hidden';
	input.removeAttribute( 'id' );
	choose.id = 'ww-seo-image';
	idRow.hidden = true;
	buttons.hidden = false;

	function show( attachment ) {
		thumb.textContent = '';
		if ( attachment ) {
			var img = document.createElement( 'img' );
			img.src = attachment.sizes && attachment.sizes.medium ? attachment.sizes.medium.url : attachment.url;
			img.alt = '';
			thumb.appendChild( img );
		}
		input.value = attachment ? String( attachment.id ) : '';
		choose.textContent = attachment ? choose.dataset.other : choose.dataset.choose;
		remove.hidden = ! attachment;
	}

	var frame = null;
	choose.addEventListener( 'click', function () {
		if ( ! frame ) {
			frame = window.wp.media( { library: { type: 'image' }, multiple: false } );
			frame.on( 'select', function () {
				show( frame.state().get( 'selection' ).first().toJSON() );
				choose.focus();
			} );
		}
		frame.open();
	} );

	remove.addEventListener( 'click', function () {
		show( null );
		choose.focus();
	} );
} )();
