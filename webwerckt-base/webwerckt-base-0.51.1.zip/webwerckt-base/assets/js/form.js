/**
 * Formulieren: versturen zonder herladen (ww_form(), inc/forms-render.php en inc/forms-submit.php).
 *
 * Zonder dit script werkt het formulier gewoon: de server geeft dezelfde fouten en hetzelfde bedankbericht terug.
 * Met dit script gaat de POST via fetch (header X-WW-Form: 1, antwoord als JSON), en tonen we fouten en het
 * bericht met dezelfde markup als de server. De teksten staan in window.wwForm (PHP, vertaalbaar).
 */
( function () {
	'use strict';

	var texts = Object.assign(
		{
			summary: 'Controleer de gemarkeerde velden.',
			network: 'Versturen is niet gelukt. Controleer je verbinding en probeer het opnieuw.',
			required: 'Dit veld is verplicht.',
			tooBig: '%1$s is te groot (max. %2$d MB).',
			tooMany: 'Kies hoogstens %d bestanden.',
			badType: '%1$s is geen toegestaan bestand. Toegestaan: %2$s.',
			postTooBig: 'Je bestanden zijn samen te groot. Het maximum is %d MB.',
			stepStatus: 'Stap %1$d van %2$d',
			email: 'Vul een geldig e-mailadres in.',
			tooLong: 'Maximaal %d tekens.',
			number: 'Vul een getal in.',
			numberRange: 'Vul een getal in tussen %1$s en %2$s.',
			numberMin: 'Vul een getal in van minimaal %s.',
			numberMax: 'Vul een getal in van maximaal %s.',
		},
		( window.wwForm && window.wwForm.texts ) || {}
	);

	/**
	 * Het label van een veld zoals de bezoeker het ziet, zonder het sterretje.
	 */
	function labelOf( el ) {
		var wrap = el && el.closest( '.ww-form__field' );
		var label = wrap && wrap.querySelector( '.ww-form__label' );
		if ( ! label ) {
			return '';
		}
		var copy = label.cloneNode( true );
		copy.querySelectorAll( '.ww-form__required, input' ).forEach( function ( node ) {
			node.remove();
		} );
		return copy.textContent.trim();
	}

	/**
	 * Haalt de verwijzingen waarvoor drop( id ) waar is uit aria-describedby; blijft er niets over, dan gaat het attribuut weg.
	 */
	function dropDescribedBy( node, drop ) {
		var kept = ( node.getAttribute( 'aria-describedby' ) || '' )
			.split( /\s+/ )
			.filter( function ( id ) {
				return id && ! drop( id );
			} );
		if ( kept.length ) {
			node.setAttribute( 'aria-describedby', kept.join( ' ' ) );
		} else {
			node.removeAttribute( 'aria-describedby' );
		}
	}

	/**
	 * Wist alle fouten: klassen, aria-invalid, de foutverwijzing in aria-describedby en het overzicht.
	 */
	function clearErrors( form ) {
		form.querySelectorAll( '.ww-form__field--error' ).forEach( function ( node ) {
			node.classList.remove( 'ww-form__field--error' );
		} );
		form.querySelectorAll( '[aria-invalid]' ).forEach( function ( node ) {
			node.removeAttribute( 'aria-invalid' );
		} );
		form.querySelectorAll( '.ww-form__error' ).forEach( function ( node ) {
			node.textContent = '';
			node.hidden = true;
		} );
		form.querySelectorAll( '[aria-describedby]' ).forEach( function ( node ) {
			dropDescribedBy( node, function ( id ) {
				return /-error$/.test( id );
			} );
		} );
		var summary = form.querySelector( '.ww-form__errors' );
		if ( summary ) {
			summary.textContent = '';
			summary.hidden = true;
		}
	}

	/**
	 * Toont een fout bij een veld. Geeft het veld terug, of null als de pagina dat veld niet (meer) heeft.
	 */
	function showFieldError( form, key, message ) {
		var el = document.getElementById( form.id + '-' + key );
		var note = document.getElementById( form.id + '-' + key + '-error' );
		if ( ! el || ! form.contains( el ) || ! note ) {
			return null;
		}
		note.textContent = message;
		note.hidden = false;
		var wrap = el.closest( '.ww-form__field' );
		if ( wrap ) {
			wrap.classList.add( 'ww-form__field--error' );
		}
		// Bij een groep (fieldset) staat alleen aria-describedby op het element, net als in de HTML van de server.
		if ( 'FIELDSET' !== el.tagName ) {
			el.setAttribute( 'aria-invalid', 'true' );
		}
		var ids = ( el.getAttribute( 'aria-describedby' ) || '' ).split( /\s+/ ).filter( Boolean );
		if ( -1 === ids.indexOf( note.id ) ) {
			ids.push( note.id );
		}
		el.setAttribute( 'aria-describedby', ids.join( ' ' ) );
		return el;
	}

	/**
	 * Vult en toont het foutoverzicht en zet er de focus op.
	 *
	 * @param {HTMLFormElement}       form    Het formulier.
	 * @param {Object<string,string>} errors  Foutmelding per veldsleutel.
	 * @param {Object<string,string>} labels  Label per veldsleutel (voor een veld dat niet op de pagina staat).
	 * @param {string}                general Melding als er geen fouten per veld zijn (429, 500, netwerk).
	 */
	function showErrors( form, errors, labels, general ) {
		clearErrors( form );
		var list = document.createElement( 'ul' );
		var count = 0;
		Object.keys( errors || {} ).forEach( function ( key ) {
			var message = String( errors[ key ] );
			var item = document.createElement( 'li' );
			var el = showFieldError( form, key, message );
			var label = labels && labels[ key ] ? String( labels[ key ] ) : '';
			var name = ( el && labelOf( el ) ) || label;
			if ( el && name ) {
				var link = document.createElement( 'a' );
				link.href = '#' + el.id;
				link.textContent = name;
				item.appendChild( link );
				item.appendChild( document.createTextNode( ': ' + message ) );
			} else {
				// Zonder label (een fout die geen veld is) alleen de melding, net als zonder JavaScript.
				item.textContent = label ? label + ': ' + message : message;
			}
			list.appendChild( item );
			count++;
		} );
		if ( ! count ) {
			var only = document.createElement( 'li' );
			only.textContent = general || texts.summary;
			list.appendChild( only );
		}
		var summary = form.querySelector( '.ww-form__errors' );
		if ( ! summary ) {
			return;
		}
		summary.appendChild( list );
		summary.hidden = false;
		summary.focus();
	}

	/**
	 * Wat de browser zelf kan zien, als { sleutel: melding }: verplichte velden die leeg zijn (constraint API) en
	 * verplichte groepen (vinkjes of keuzerondjes) waarvan niets is gekozen. Met root alleen binnen dat deel van het
	 * formulier (een stap); de sleutel komt altijd uit het id van het formulier.
	 */
	function missingFields( form, root ) {
		var errors = {};
		( root || form ).querySelectorAll( '.ww-form__field--required' ).forEach( function ( wrap ) {
			// Een veld dat door een voorwaarde verborgen is, hoeft niet ingevuld.
			if ( wrap.hidden ) {
				return;
			}
			var group = wrap.querySelector( 'fieldset' );
			if ( group ) {
				if ( group.id && ! group.querySelector( 'input:checked' ) ) {
					errors[ group.id.slice( form.id.length + 1 ) ] = texts.required;
				}
				return;
			}
			var control = wrap.querySelector( 'input, select, textarea' );
			if ( control && control.id && control.validity && control.validity.valueMissing ) {
				errors[ control.id.slice( form.id.length + 1 ) ] = texts.required;
			}
		} );
		return errors;
	}

	/**
	 * De fout bij een getalveld, of '': dezelfde regels als _ww_form_number_parse() en de grenzen. De stap controleert
	 * alleen de server; die fout komt terug in het gewone antwoord.
	 */
	function numberError( control ) {
		var raw = control.value.replace( /\s+/g, '' );
		if ( '' === raw ) {
			return '';
		}
		if ( ! /^[+-]?(\d{0,12})(?:[.,](\d{0,6}))?$/.test( raw ) || /^[+-]?[.,]?$/.test( raw ) ) {
			return texts.number;
		}
		var value = parseFloat( raw.replace( ',', '.' ) );
		var min = control.getAttribute( 'data-ww-min' );
		var max = control.getAttribute( 'data-ww-max' );
		var lang = document.documentElement.lang || undefined;
		var show = function ( limit ) {
			return parseFloat( limit ).toLocaleString( lang, { maximumFractionDigits: 6 } );
		};
		var low = null !== min && value < parseFloat( min );
		var high = null !== max && value > parseFloat( max );
		if ( ( low || high ) && null !== min && null !== max ) {
			return fillText( texts.numberRange, [ show( min ), show( max ) ] );
		}
		if ( low ) {
			return fillText( texts.numberMin, [ show( min ) ] );
		}
		return high ? fillText( texts.numberMax, [ show( max ) ] ) : '';
	}

	/**
	 * Ongeldige invoer die de browser ziet, als { sleutel: melding }: een ongeldig e-mailadres (typeMismatch) en te
	 * veel tekens (tooLong). Met root alleen binnen dat deel van het formulier. Een verplichte fout gaat voor: de
	 * aanroeper zet missingFields() er als laatste overheen.
	 */
	function invalidFields( form, root ) {
		var errors = {};
		( root || form ).querySelectorAll( 'input, textarea' ).forEach( function ( control ) {
			if ( ! control.id || ! control.validity || control.disabled ) {
				return;
			}
			var key = control.id.slice( form.id.length + 1 );
			var number = control.hasAttribute( 'data-ww-number' ) ? numberError( control ) : '';
			if ( number ) {
				errors[ key ] = number;
			} else if ( 'email' === control.type && control.validity.typeMismatch ) {
				errors[ key ] = texts.email;
			} else if ( control.validity.tooLong ) {
				errors[ key ] = fillText( texts.tooLong, [ control.maxLength ] );
			}
		} );
		return errors;
	}

	/**
	 * Veilig doorsturen: alleen http(s).
	 */
	function redirect( url ) {
		try {
			var target = new URL( url, window.location.href );
			if ( 'http:' === target.protocol || 'https:' === target.protocol ) {
				window.location.assign( target.href );
				return true;
			}
		} catch ( e ) {
			// Ongeldige URL: behandeld als mislukt.
		}
		return false;
	}

	function setBusy( form, busy ) {
		var button = form.querySelector( '.ww-form__submit' );
		if ( ! button ) {
			return;
		}
		button.disabled = busy;
		if ( busy ) {
			button.setAttribute( 'aria-busy', 'true' );
		} else {
			button.removeAttribute( 'aria-busy' );
		}
	}

	/**
	 * Het post-ID van het formulier (uit input[name="ww_form"]), of 0. De formId in de events ww-form-submitted en ww-form-step.
	 */
	function formPostId( form ) {
		var input = form.querySelector( 'input[name="ww_form"]' );
		return input ? Number( input.value ) : 0;
	}

	function announce( form, type ) {
		form.dispatchEvent(
			new CustomEvent( 'ww-form-submitted', {
				bubbles: true,
				detail: { formId: formPostId( form ), type: type },
			} )
		);
	}

	function succeed( form, data ) {
		if ( 'redirect' === data.type && data.url ) {
			announce( form, 'redirect' );
			// Terug met de knop kan de pagina uit bfcache komen: dan moet het formulier weer werken.
			setBusy( form, false );
			if ( ! redirect( data.url ) ) {
				showErrors( form, {}, {}, texts.network );
			}
			return;
		}
		announce( form, 'message' );
		var box = document.createElement( 'div' );
		box.className = 'ww-form__success';
		box.setAttribute( 'role', 'status' );
		box.tabIndex = -1;
		// De server heeft het bericht met wp_kses_post() opgeschoond.
		box.innerHTML = String( data.message || '' );
		form.replaceWith( box );
		box.focus();
	}

	var MB = 1048576;
	var RECAPTCHA_TIMEOUT = 5000;
	var recaptchaLoading = null;

	/**
	 * Vult %s en %d in, zoals sprintf in PHP: genummerd (%1$s, %2$d) op hun plaats in values, ongenummerd in de
	 * volgorde waarin ze staan.
	 */
	function fillText( template, values ) {
		var i = 0;
		return String( template ).replace( /%(?:(\d+)\$)?[sd]/g, function ( match, position ) {
			var index = position ? parseInt( position, 10 ) - 1 : i++;
			var value = index >= 0 && index < values.length ? values[ index ] : '';
			return String( value );
		} );
	}

	/**
	 * De extensies uit het accept-attribuut (".pdf,.doc"), in kleine letters en zonder punt.
	 */
	function allowedExtensions( accept ) {
		return String( accept || '' )
			.split( ',' )
			.map( function ( ext ) {
				return ext.trim().replace( /^\./, '' ).toLowerCase();
			} )
			.filter( Boolean );
	}

	/**
	 * Controleert de gekozen bestanden van één veld, in dezelfde volgorde als de server: aantal, dan per bestand
	 * grootte en extensie. Geeft de eerste melding terug, of een lege tekst als alles klopt.
	 *
	 * @param {Array<{name: string, size: number}>}                         files  De gekozen bestanden.
	 * @param {{maxSize: number, maxFiles: number, extensions: string[]}} limits Grenzen uit de data-attributen (0 = geen grens).
	 */
	function checkFileList( files, limits ) {
		if ( limits.maxFiles > 0 && files.length > limits.maxFiles ) {
			return fillText( texts.tooMany, [ limits.maxFiles ] );
		}
		for ( var i = 0; i < files.length; i++ ) {
			var file = files[ i ];
			if ( limits.maxSize > 0 && file.size > limits.maxSize ) {
				return fillText( texts.tooBig, [ file.name, Math.max( 1, Math.floor( limits.maxSize / MB ) ) ] );
			}
			if ( limits.extensions.length ) {
				var dot = file.name.lastIndexOf( '.' );
				var ext = dot > -1 ? file.name.slice( dot + 1 ).toLowerCase() : '';
				if ( -1 === limits.extensions.indexOf( ext ) ) {
					return fillText( texts.badType, [ file.name, limits.extensions.join( ', ' ) ] );
				}
			}
		}
		return '';
	}

	/**
	 * Of de bestanden samen boven post_max_size komen (0 = niet controleren). Geeft de melding of een lege tekst.
	 */
	function checkPostSize( total, postMax ) {
		if ( postMax > 0 && total > postMax ) {
			return fillText( texts.postTooBig, [ Math.max( 1, Math.floor( postMax / MB ) ) ] );
		}
		return '';
	}

	function fileKey( form, input ) {
		return input.id ? input.id.slice( form.id.length + 1 ) : '';
	}

	/**
	 * De fout van één bestandsveld, of een lege tekst.
	 */
	function fileFieldError( input ) {
		var list = Array.prototype.map.call( input.files || [], function ( file ) {
			return { name: file.name, size: file.size };
		} );
		return checkFileList( list, {
			maxSize: parseInt( input.getAttribute( 'data-ww-max-size' ), 10 ) || 0,
			maxFiles: parseInt( input.getAttribute( 'data-ww-max-files' ), 10 ) || 0,
			extensions: allowedExtensions( input.getAttribute( 'accept' ) ),
		} );
	}

	/**
	 * Controleert alle bestandsvelden van het formulier (of met root alleen die in dat deel). Geeft
	 * { errors: { sleutel: melding }, post: melding }.
	 */
	function checkFiles( form, root ) {
		var errors = {};
		var total = 0;
		( root || form ).querySelectorAll( 'input[type="file"]' ).forEach( function ( input ) {
			// Een uitgeschakeld bestandsveld (verborgen door een voorwaarde) wordt niet verstuurd en telt niet mee.
			if ( input.disabled ) {
				return;
			}
			var key = fileKey( form, input );
			Array.prototype.forEach.call( input.files || [], function ( file ) {
				total += file.size;
			} );
			var message = key ? fileFieldError( input ) : '';
			if ( message ) {
				errors[ key ] = message;
			}
		} );
		return { errors: errors, post: checkPostSize( total, parseInt( form.getAttribute( 'data-ww-post-max' ), 10 ) || 0 ) };
	}

	/**
	 * Haalt de fout van één veld weg (bij een nieuwe keuze van een bestand), zonder de rest van het formulier aan te raken.
	 */
	function clearFieldError( input ) {
		var note = document.getElementById( input.id + '-error' );
		if ( note ) {
			note.textContent = '';
			note.hidden = true;
		}
		var wrap = input.closest( '.ww-form__field' );
		if ( wrap ) {
			wrap.classList.remove( 'ww-form__field--error' );
		}
		input.removeAttribute( 'aria-invalid' );
		dropDescribedBy( input, function ( id ) {
			return id === input.id + '-error';
		} );
	}

	/**
	 * Laadt reCAPTCHA v3 één keer per pagina, bij de eerste aanraking van een formulier of anders bij het versturen,
	 * met het badge verborgen (de tekst onder de knop staat er al, zie het filter ww_form_recaptcha_notice).
	 * Geeft een belofte terug die met true oplost als het script geladen is en met false als het mislukt (geblokkeerd).
	 */
	function loadRecaptcha( key ) {
		if ( recaptchaLoading ) {
			return recaptchaLoading;
		}
		if ( ! key ) {
			return Promise.resolve( false );
		}
		recaptchaLoading = new Promise( function ( resolve ) {
			var style = document.createElement( 'style' );
			style.textContent = '.grecaptcha-badge{visibility:hidden}';
			document.head.appendChild( style );
			var script = document.createElement( 'script' );
			script.onload = function () {
				resolve( true );
			};
			script.onerror = function () {
				resolve( false );
			};
			script.src = 'https://www.google.com/recaptcha/api.js?render=' + encodeURIComponent( key );
			script.async = true;
			document.head.appendChild( script );
		} );
		return recaptchaLoading;
	}

	/**
	 * De token voor dit versturen, of een lege tekst. Is het script er nog niet, dan wacht het (binnen dezelfde
	 * 5 seconden) op het laden. Zonder sleutel, bij een geblokkeerd script, een fout of na 5 seconden gaat het
	 * formulier zonder token weg (de server telt dat als "none").
	 */
	function recaptchaToken( key ) {
		if ( ! key ) {
			return Promise.resolve( '' );
		}
		return new Promise( function ( resolve ) {
			var timer = window.setTimeout( function () {
				resolve( '' );
			}, RECAPTCHA_TIMEOUT );
			function done( token ) {
				window.clearTimeout( timer );
				resolve( 'string' === typeof token ? token : '' );
			}
			function run() {
				var api = window.grecaptcha;
				if ( ! api || 'function' !== typeof api.ready ) {
					done( '' );
					return;
				}
				try {
					// execute bestaat soms pas als ready aanroept: Google laadt bij render=key een tweede script.
					api.ready( function () {
						try {
							api.execute( key, { action: 'ww_form' } ).then( done, function () {
								done( '' );
							} );
						} catch ( e ) {
							done( '' );
						}
					} );
				} catch ( e ) {
					done( '' );
				}
			}
			if ( window.grecaptcha && 'function' === typeof window.grecaptcha.ready ) {
				run();
				return;
			}
			loadRecaptcha( key ).then( function ( loaded ) {
				if ( loaded ) {
					run();
				} else {
					done( '' );
				}
			} );
		} );
	}

	function submit( form, event ) {
		event.preventDefault();
		var button = form.querySelector( '.ww-form__submit' );
		if ( button && button.disabled ) {
			return;
		}
		var missing = missingFields( form );
		var files = checkFiles( form );
		var errors = Object.assign( {}, invalidFields( form ), files.errors, missing );
		if ( Object.keys( errors ).length || files.post ) {
			if ( files.post && Object.keys( errors ).length ) {
				// De totaalmelding hoort bij geen enkel veld: een extra regel in het overzicht, naast de veldfouten.
				errors[ '' ] = files.post;
			}
			showErrors( form, errors, {}, files.post );
			stepToFirstError( form );
			return;
		}
		clearErrors( form );
		setBusy( form, true );

		recaptchaToken( form.getAttribute( 'data-ww-recaptcha' ) )
			.then( function ( token ) {
				var field = form.querySelector( 'input[name="ww_recaptcha"]' );
				if ( field ) {
					field.value = token;
				}
				return fetch( window.location.href, {
					method: 'POST',
					body: new FormData( form ),
					headers: { 'X-WW-Form': '1', Accept: 'application/json' },
					credentials: 'same-origin',
				} );
			} )
			.then( function ( response ) {
				return response.json().then( function ( data ) {
					return { status: response.status, data: data };
				} );
			} )
			.then( function ( result ) {
				var data = result.data;
				if ( ! data || 'object' !== typeof data ) {
					throw new Error( 'Geen JSON' );
				}
				if ( data.ok ) {
					succeed( form, data );
					return;
				}
				setBusy( form, false );
				showErrors( form, data.errors && 'object' === typeof data.errors ? data.errors : {}, data.labels || {}, data.message || texts.network );
				stepToFirstError( form );
			} )
			.catch( function () {
				setBusy( form, false );
				showErrors( form, {}, {}, texts.network );
			} );
	}

	/**
	 * Stappen: de toestand per formulier, alleen als het minstens twee .ww-form__step heeft.
	 *
	 * @type {WeakMap<HTMLFormElement, {steps: HTMLElement[], current: number, reached: number}>}
	 */
	var stepState = new WeakMap();

	/**
	 * De index van de stap met deze sleutel (data-ww-step), of -1.
	 */
	function stepIndexByKey( state, key ) {
		for ( var i = 0; i < state.steps.length; i++ ) {
			if ( state.steps[ i ].getAttribute( 'data-ww-step' ) === key ) {
				return i;
			}
		}
		return -1;
	}

	/**
	 * De indexen van de stappen met minstens een zichtbaar veld (niet verborgen door een voorwaarde). Zijn het er
	 * geen, dan telt alleen de huidige stap, zodat er altijd een stap is om te tonen.
	 */
	function activeSteps( state ) {
		var active = [];
		state.steps.forEach( function ( step, i ) {
			if ( step.querySelector( '.ww-form__field:not([hidden])' ) ) {
				active.push( i );
			}
		} );
		return active.length ? active : [ state.current ];
	}

	/**
	 * De dichtstbijzijnde actieve stap bij index: index zelf, anders de laatste actieve ervoor, anders de eerste erna.
	 */
	function nearestActive( state, index ) {
		var active = activeSteps( state );
		var found = active[ 0 ];
		active.forEach( function ( i ) {
			if ( i <= index ) {
				found = i;
			}
		} );
		return found;
	}

	/**
	 * Toont stap index en verbergt de rest; werkt de lijst, de statusregel en de knoppen bij. Met focus gaat de
	 * focus naar de kop van de stap. Zonder silent volgt het event ww-form-step.
	 */
	function showStep( form, index, focus, silent ) {
		var state = stepState.get( form );
		var active = activeSteps( state );
		var first = active[ 0 ];
		var last = active[ active.length - 1 ];
		state.current = index;
		state.steps.forEach( function ( step, i ) {
			step.hidden = i !== index;
			var prev = step.querySelector( '[data-ww-prev]' );
			var next = step.querySelector( '[data-ww-next]' );
			if ( prev ) {
				prev.hidden = first === i;
			}
			if ( next ) {
				next.hidden = last === i;
			}
		} );
		form.querySelectorAll( '.ww-form__progress-button' ).forEach( function ( button ) {
			var i = stepIndexByKey( state, button.getAttribute( 'data-ww-goto' ) );
			var item = button.closest( 'li' );
			if ( item ) {
				item.hidden = i >= 0 && -1 === active.indexOf( i );
			}
			button.disabled = i < 0 || i > state.reached;
			if ( i === index ) {
				button.setAttribute( 'aria-current', 'step' );
			} else {
				button.removeAttribute( 'aria-current' );
			}
		} );
		var status = form.querySelector( '.ww-form__step-status' );
		if ( status ) {
			// Alleen bij een andere tekst: de live region leest anders bij het laden de tekst voor die er al stond.
			var statusText = fillText( texts.stepStatus, [ Math.max( 1, active.indexOf( index ) + 1 ), active.length ] );
			if ( status.textContent !== statusText ) {
				status.textContent = statusText;
			}
		}
		var submitButton = form.querySelector( '.ww-form__submit' );
		if ( submitButton ) {
			submitButton.hidden = index !== last;
		}
		if ( focus ) {
			var title = state.steps[ index ].querySelector( '.ww-form__step-title' );
			if ( title ) {
				title.focus();
			}
		}
		if ( ! silent ) {
			form.dispatchEvent(
				new CustomEvent( 'ww-form-step', {
					bubbles: true,
					detail: { formId: formPostId( form ), step: state.steps[ index ].getAttribute( 'data-ww-step' ) || '', index: index },
				} )
			);
		}
	}

	/**
	 * Volgende: controleert alleen de velden van de huidige stap en gaat zonder fouten naar de volgende.
	 */
	function nextStep( form ) {
		var state = stepState.get( form );
		var step = state.steps[ state.current ];
		var active = activeSteps( state );
		var following = active.filter( function ( i ) {
			return i > state.current;
		} )[ 0 ];
		if ( undefined === following ) {
			return;
		}
		var errors = Object.assign( {}, invalidFields( form, step ), checkFiles( form, step ).errors, missingFields( form, step ) );
		if ( Object.keys( errors ).length ) {
			showErrors( form, errors, {}, '' );
			return;
		}
		clearErrors( form );
		state.reached = Math.max( state.reached, following );
		showStep( form, following, true );
	}

	/**
	 * De index van de eerste stap met een veldfout, of -1.
	 */
	function firstErrorStep( state ) {
		for ( var i = 0; i < state.steps.length; i++ ) {
			if ( state.steps[ i ].querySelector( '.ww-form__field--error' ) ) {
				return i;
			}
		}
		return -1;
	}

	/**
	 * Na fouten (van de server of de controle in de browser): naar de eerste stap met een veldfout; de focus blijft
	 * op het overzicht. Zonder zo'n stap (een algemene fout, of een sleutel die in geen stap staat) blijft de huidige
	 * stap staan.
	 */
	function stepToFirstError( form ) {
		var state = stepState.get( form );
		if ( ! state ) {
			return;
		}
		var i = firstErrorStep( state );
		if ( i < 0 ) {
			return;
		}
		state.reached = Math.max( state.reached, i );
		if ( i !== state.current ) {
			showStep( form, i, false );
		}
	}

	/**
	 * Zet de stappen aan: lijst, statusregel en navigatie zichtbaar, alleen de eerste stap open. Staan er al fouten
	 * van de server in de pagina (versturen zonder JavaScript), dan opent stil de eerste stap met een fout.
	 */
	function initSteps( form ) {
		var steps = Array.prototype.slice.call( form.querySelectorAll( '.ww-form__step' ) );
		if ( steps.length < 2 ) {
			return;
		}
		var state = { steps: steps, current: 0, reached: 0 };
		stepState.set( form, state );
		form.querySelectorAll( '.ww-form__progress, .ww-form__step-status, .ww-form__step-nav' ).forEach( function ( node ) {
			node.hidden = false;
		} );
		var start = Math.max( 0, firstErrorStep( state ) );
		state.reached = start;
		showStep( form, nearestActive( state, start ), false, true );
		// Een voorwaarde kan stappen laten verschijnen of verdwijnen: lijst, knoppen en statusregel volgen.
		form.addEventListener( 'ww-form-visibility', function () {
			showStep( form, nearestActive( state, state.current ), false, true );
		} );
		form.addEventListener( 'click', function ( event ) {
			var state = stepState.get( form );
			var button = event.target.closest && event.target.closest( '[data-ww-next], [data-ww-prev], [data-ww-goto]' );
			if ( ! button || ! form.contains( button ) ) {
				return;
			}
			if ( button.hasAttribute( 'data-ww-next' ) ) {
				nextStep( form );
				return;
			}
			var i = stepIndexByKey( state, button.getAttribute( 'data-ww-goto' ) );
			if ( button.hasAttribute( 'data-ww-prev' ) ) {
				i = -1;
				activeSteps( state ).forEach( function ( j ) {
					if ( j < state.current ) {
						i = j;
					}
				} );
			}
			if ( i >= 0 && i <= state.reached ) {
				showStep( form, i, true );
			}
		} );
	}

	function init( form ) {
		if ( form.dataset.wwFormReady ) {
			return;
		}
		form.dataset.wwFormReady = '1';
		form.noValidate = true;
		var recaptchaKey = form.getAttribute( 'data-ww-recaptcha' );
		if ( recaptchaKey ) {
			var load = function () {
				loadRecaptcha( recaptchaKey );
			};
			form.addEventListener( 'focusin', load );
			form.addEventListener( 'input', load );
		}
		// Een gekozen bestand meteen controleren; de melding staat dan bij het veld, zonder het overzicht.
		form.addEventListener( 'change', function ( event ) {
			var input = event.target;
			if ( ! input || 'INPUT' !== input.tagName || 'file' !== input.type || ! input.id ) {
				return;
			}
			clearFieldError( input );
			var message = fileFieldError( input );
			if ( message ) {
				showFieldError( form, fileKey( form, input ), message );
			}
		} );
		initSteps( form );
		// Een veld dat nu verborgen is, hoort niet meer in het foutenoverzicht.
		form.addEventListener( 'ww-form-visibility', function () {
			var summary = form.querySelector( '.ww-form__errors' );
			if ( ! summary || summary.hidden ) {
				return;
			}
			summary.querySelectorAll( 'li' ).forEach( function ( item ) {
				var link = item.querySelector( 'a[href^="#"]' );
				var target = link ? document.getElementById( link.getAttribute( 'href' ).slice( 1 ) ) : null;
				if ( target && target.closest( '.ww-form__field[hidden]' ) ) {
					item.parentNode.removeChild( item );
				}
			} );
			if ( ! summary.querySelector( 'li' ) ) {
				summary.textContent = '';
				summary.hidden = true;
			}
		} );
		form.addEventListener( 'submit', function ( event ) {
			// Enter in een veld van een stap die niet de laatste is: hetzelfde als Volgende, niets versturen.
			var state = stepState.get( form );
			if ( state && state.current < activeSteps( state ).pop() ) {
				event.preventDefault();
				nextStep( form );
				return;
			}
			submit( form, event );
		} );
		// Een link in het overzicht zet de focus op het veld (ook bij een groep, die zelf geen focus krijgt).
		form.addEventListener( 'click', function ( event ) {
			var link = event.target.closest && event.target.closest( '.ww-form__errors a[href^="#"]' );
			if ( ! link ) {
				return;
			}
			var target = document.getElementById( link.getAttribute( 'href' ).slice( 1 ) );
			if ( ! target || ! form.contains( target ) ) {
				return;
			}
			event.preventDefault();
			// Staat het veld in een verborgen stap, dan eerst die stap openen.
			var state = stepState.get( form );
			var step = target.closest( '.ww-form__step' );
			if ( state && step && step.hidden ) {
				var index = state.steps.indexOf( step );
				state.reached = Math.max( state.reached, index );
				showStep( form, index, false );
			}
			( 'FIELDSET' === target.tagName && target.querySelector( 'input' ) ? target.querySelector( 'input' ) : target ).focus();
		} );
	}

	function ready() {
		document.querySelectorAll( '[data-ww-form]' ).forEach( init );
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', ready );
	} else {
		ready();
	}
} )();
