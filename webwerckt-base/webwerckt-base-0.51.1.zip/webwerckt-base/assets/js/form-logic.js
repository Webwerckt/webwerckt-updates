// Formulieren: de regels van voorwaarden, puur (geen DOM). Een spiegel van inc/forms-number.php en
// inc/forms-conditions.php: wie hier iets wijzigt, wijzigt daar hetzelfde, en andersom.

// Leest een getal zoals een bezoeker het typt. Geeft het genormaliseerde getal ('12.5'), '' bij lege invoer en null
// bij ongeldige invoer. Hoogstens 12 cijfers vóór en 6 na het decimaalteken.
export function parseNumber(text) {
	const raw = String(text).replace(/\s+/gu, '');
	if (raw === '') {
		return '';
	}
	const m = /^([+-]?)(\d{0,12})(?:[.,](\d{0,6}))?$/.exec(raw);
	if (!m) {
		return null;
	}
	const whole = m[2].replace(/^0+/, '');
	const decimals = (m[3] ?? '').replace(/0+$/, '');
	if (m[2] === '' && (m[3] ?? '') === '') {
		return null;
	}
	const number = (whole === '' ? '0' : whole) + (decimals !== '' ? '.' + decimals : '');
	return m[1] === '-' && number !== '0' ? '-' + number : number;
}

function decimalsOf(number) {
	const dot = number.indexOf('.');
	return dot === -1 ? 0 : number.length - dot - 1;
}

// Een genormaliseerd getal als BigInt na vermenigvuldigen met 10^decimals.
function scaled(number, decimals) {
	const negative = number.startsWith('-');
	const [whole, fraction = ''] = number.replace(/^-/, '').split('.');
	const value = BigInt(whole + fraction.padEnd(decimals, '0'));
	return negative ? -value : value;
}

// Vergelijkt twee genormaliseerde getallen exact: -1, 0 of 1.
export function compareNumbers(a, b) {
	const decimals = Math.max(decimalsOf(a), decimalsOf(b));
	const x = scaled(a, decimals);
	const y = scaled(b, decimals);
	return x < y ? -1 : x > y ? 1 : 0;
}

// Klopt één regel voor de waarde van het bronveld (tekst of lijst teksten)? Een leeg bronveld voldoet aan is_not,
// not_contains en unchecked, en aan geen enkele getalvergelijking.
export function ruleMet(rule, value) {
	const op = String(rule.op ?? '');
	const wanted = String(rule.value ?? '');
	const text = typeof value === 'string';
	const list = Array.isArray(value);
	switch (op) {
		case 'is':
			return text && value === wanted;
		case 'is_not':
			return !text || value !== wanted;
		case 'contains':
			return list && value.includes(wanted);
		case 'not_contains':
			return !list || !value.includes(wanted);
		case 'checked':
			return value === '1';
		case 'unchecked':
			return value !== '1';
		case 'gt':
		case 'lt':
		case 'eq':
		case 'gte':
		case 'lte': {
			const number = text ? parseNumber(value) : null;
			if (number === null || number === '') {
				return false;
			}
			const order = compareNumbers(number, wanted);
			switch (op) {
				case 'gt':
					return order > 0;
				case 'lt':
					return order < 0;
				case 'eq':
					return order === 0;
				case 'gte':
					return order >= 0;
				default:
					return order <= 0;
			}
		}
	}
	return false;
}

// Is de voorwaarde vervuld? Alle regels bij 'all', minstens één bij 'any'. valueOf(sleutel) geeft de waarde van een
// veld; een ontbrekend veld telt als leeg.
export function conditionMet(condition, valueOf) {
	const any = condition.match === 'any';
	for (const rule of condition.rules ?? []) {
		if (ruleMet(rule, valueOf(rule.field ?? '')) === any) {
			return any;
		}
	}
	return !any;
}
