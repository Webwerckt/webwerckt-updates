// Formulieren: velden tonen en verbergen op basis van eerdere antwoorden (progressive enhancement). Zonder
// JavaScript staan alle velden open, elk met een hint wanneer het ingevuld moet worden.
// Een verborgen veld is disabled en dus leeg: zo telt het voor de velden erna als leeg (de keten), en gaat het niet mee.

import { conditionMet } from 'ww-form-logic';

const FIELD = '.ww-form__field[data-ww-condition]';

// De waarde van een veld: tekst, of een lijst bij meerdere keuzes. Geen (niet-disabled) invoer = ''.
function valueOf(form, key) {
	const single = `ww_fields[${key}]`;
	const multiple = `ww_fields[${key}][]`;
	const inputs = Array.from(form.elements).filter((el) => !el.disabled && (el.name === single || el.name === multiple));
	if (inputs.length === 0) {
		return '';
	}
	if (inputs[0].name === multiple) {
		return inputs.filter((el) => el.checked).map((el) => el.value);
	}
	const first = inputs[0];
	if (first.type === 'radio') {
		const chosen = inputs.find((el) => el.checked);
		return chosen ? chosen.value : '';
	}
	if (first.type === 'checkbox') {
		return first.checked ? '1' : '';
	}
	return first.value;
}

// Haalt de ids die aan de test voldoen uit aria-describedby; een lege lijst haalt het attribuut weg.
function dropDescribedBy(node, drop) {
	const ids = (node.getAttribute('aria-describedby') ?? '').split(/\s+/).filter((id) => id !== '' && !drop(id));
	if (ids.length > 0) {
		node.setAttribute('aria-describedby', ids.join(' '));
	} else {
		node.removeAttribute('aria-describedby');
	}
}

// Wist de fout bij een veld dat verdwijnt.
function clearError(wrap) {
	wrap.classList.remove('ww-form__field--error');
	for (const note of wrap.querySelectorAll('.ww-form__error')) {
		note.textContent = '';
		note.hidden = true;
	}
	for (const node of wrap.querySelectorAll('[aria-invalid]')) {
		node.removeAttribute('aria-invalid');
	}
	for (const node of wrap.querySelectorAll('[aria-describedby]')) {
		dropDescribedBy(node, (id) => id.endsWith('-error'));
	}
}

// Ook style.display: een child-thema dat .ww-form__field met flex of grid opmaakt, overschrijft anders [hidden].
function setVisible(wrap, visible) {
	wrap.hidden = !visible;
	wrap.style.display = visible ? '' : 'none';
	for (const control of wrap.querySelectorAll('input, select, textarea')) {
		control.disabled = !visible;
		if (control.hasAttribute('data-ww-required')) {
			control.required = visible;
		}
	}
	if (!visible) {
		clearError(wrap);
	}
}

// De hint hoort bij de variant zonder JavaScript: hier verbergen we hem en halen hem uit aria-describedby.
function hideHints(form) {
	for (const hint of form.querySelectorAll('.ww-form__condition')) {
		hint.hidden = true;
		if (hint.id === '') {
			continue;
		}
		for (const node of form.querySelectorAll('[aria-describedby]')) {
			dropDescribedBy(node, (id) => id === hint.id);
		}
	}
}

function update(form) {
	// Documentvolgorde: een bron staat altijd vóór het veld dat ervan afhangt.
	for (const wrap of form.querySelectorAll(FIELD)) {
		let condition;
		try {
			condition = JSON.parse(wrap.dataset.wwCondition);
		} catch {
			continue;
		}
		setVisible(wrap, conditionMet(condition, (key) => valueOf(form, key)));
	}
	form.dispatchEvent(new CustomEvent('ww-form-visibility', { bubbles: true }));
}

for (const form of document.querySelectorAll('form[data-ww-form]')) {
	if (form.querySelector(FIELD) === null) {
		continue;
	}
	hideHints(form);
	update(form);
	form.addEventListener('input', () => update(form));
	form.addEventListener('change', () => update(form));
	// Terug naar de pagina (bfcache) kan ingevulde waarden herstellen zonder input-events.
	window.addEventListener('pageshow', () => update(form));
}
