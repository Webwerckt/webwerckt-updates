<?php
/**
 * Tabel met het activiteitenlog op het scherm Activiteitenlog (inc/activity-admin.php). Wordt pas
 * geladen als dat scherm wordt getoond, na WP_List_Table.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Het activiteitenlog: tijd, wie, actie, wat en welke velden, met een kopje per dag. Alleen lezen.
 */
class WW_Activity_List_Table extends WP_List_Table {

	/**
	 * Volgnummer van de regel die wordt getekend, op deze pagina vanaf 0.
	 *
	 * @var int
	 */
	private int $row_index = 0;

	/**
	 * De filters van dit verzoek, één keer gelezen in prepare_items().
	 *
	 * @var array{actor:string,user:int,type:string,object:string,s:string,paged:int,period:int,entry:int}|null
	 */
	private ?array $args = null;

	/**
	 * Per regel (op object-id van PHP) de link naar het object en de veldgroepen, zodat een regel ze één keer uitrekent.
	 * De regel zelf staat erbij: zo blijft het object bestaan en kan zijn id niet naar een andere regel gaan.
	 *
	 * @var array<int,array{item:object,link:string,groups:array<string,list<array{key:string,label:string}>>}>
	 */
	private array $row_data = array();

	public function __construct() {
		parent::__construct(
			array(
				'singular' => 'activiteit',
				'plural'   => 'activiteiten',
				'ajax'     => false,
			)
		);
	}

	/**
	 * Het zoekvak: zoals dat van WordPress, maar met een hint in het veld dat er op titel wordt gezocht. Het label blijft
	 * voor schermlezers. Er is hier geen sortering, dus ook geen verborgen velden daarvoor.
	 *
	 * @param string $text     Label en knoptekst.
	 * @param string $input_id Voorvoegsel van het id van het veld.
	 */
	public function search_box( $text, $input_id ): void {
		if ( empty( $_REQUEST['s'] ) && ! $this->has_items() ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen lezen.
			return;
		}
		$input_id .= '-search-input';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen lezen.
		echo '<p class="search-box"><label class="screen-reader-text" for="' . esc_attr( $input_id ) . '">' . esc_html( $text ) . ':</label>'
			. '<input type="search" id="' . esc_attr( $input_id ) . '" name="s" value="' . esc_attr( _ww_data_to_string( wp_unslash( $_REQUEST['s'] ?? '' ) ) ) . '" placeholder="' . esc_attr__( 'Zoek op titel', 'webwerckt-base' ) . '" />';
		submit_button( $text, 'compact', '', false, array( 'id' => 'search-submit' ) );
		echo '</p>';
	}

	/**
	 * @return array<string,string>
	 */
	public function get_columns() {
		return array(
			'when'   => __( 'Tijd', 'webwerckt-base' ),
			'who'    => __( 'Wie', 'webwerckt-base' ),
			'action' => __( 'Actie', 'webwerckt-base' ),
			'what'   => __( 'Wat', 'webwerckt-base' ),
			'fields' => __( 'Gewijzigde velden', 'webwerckt-base' ),
		);
	}

	/**
	 * Zoekt, filtert en pagineert via _ww_activity_admin_list().
	 */
	public function prepare_items(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen lezen en filteren.
		$args           = _ww_activity_query_args( $_GET );
		$this->args     = $args;
		$this->row_data = array();
		$result         = _ww_activity_admin_list( $args );

		$this->_column_headers = array( $this->get_columns(), array(), array(), 'what' );
		$this->set_pagination_args(
			array(
				'total_items' => $result['total'],
				'per_page'    => WW_ACTIVITY_PER_PAGE,
			)
		);
		$this->items = $result['items'];

		// De berichten en bijlagen van de regels in één keer, in plaats van één query per regel voor de link.
		$ids = array();
		foreach ( $this->items as $item ) {
			$id = (int) ( $item->object_id ?? 0 );
			if ( $id > 0 && in_array( _ww_data_to_string( $item->object_type ?? '' ), array( 'post', 'attachment' ), true ) ) {
				$ids[ $id ] = $id;
			}
		}
		if ( array() !== $ids ) {
			_prime_post_caches( array_values( $ids ), false, true );
		}
	}

	/**
	 * De filters van dit verzoek: uit prepare_items(), of nu gelezen als die nog niet heeft gelopen.
	 *
	 * @return array{actor:string,user:int,type:string,object:string,s:string,paged:int,period:int,entry:int}
	 */
	private function args(): array {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen lezen en filteren.
		return $this->args ?? _ww_activity_query_args( $_GET );
	}

	/**
	 * De link naar het object en de veldgroepen van een regel, per regel één keer uitgerekend.
	 *
	 * @param object $item Regel.
	 * @return array{item:object,link:string,groups:array<string,list<array{key:string,label:string}>>}
	 */
	private function row_data( object $item ): array {
		$key = spl_object_id( $item );
		if ( ! isset( $this->row_data[ $key ] ) || $this->row_data[ $key ]['item'] !== $item ) {
			$this->row_data[ $key ] = array(
				'item'   => $item,
				'link'   => _ww_activity_object_link( $item ),
				'groups' => _ww_activity_field_groups( $item ),
			);
		}
		return $this->row_data[ $key ];
	}

	/**
	 * Tekst als er geen regels zijn.
	 */
	public function no_items(): void {
		esc_html_e( 'Er is nog geen activiteit.', 'webwerckt-base' );
	}

	/**
	 * De regels, met voor de eerste regel van elke dag (in de tijdzone van de site) een dagkopje.
	 */
	public function display_rows(): void {
		$this->row_index = 0;
		$last_day        = '';
		foreach ( $this->items as $item ) {
			$created = _ww_data_to_string( $item->created ?? '' );
			$time    = strtotime( $created . ' UTC' );
			$day     = false !== $time ? (string) wp_date( 'Y-m-d', $time ) : '';
			if ( $day !== $last_day ) {
				$last_day = $day;
				echo '<tr class="ww-activity-day"><th scope="colgroup" colspan="' . esc_attr( (string) $this->get_column_count() ) . '">' . _ww_activity_day_label( $created ) . '</th></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- geëscapete HTML.
			}
			$this->single_row( $item );
		}
	}

	/**
	 * Eén regel, met het volgnummer waar het script het detail bij zoekt.
	 *
	 * @param object $item Regel.
	 */
	public function single_row( $item ): void {
		echo '<tr class="ww-activity-row" data-ww-entry="' . esc_attr( (string) $this->row_index ) . '">';
		$this->single_row_columns( $item );
		echo '</tr>';
		++$this->row_index;
	}

	/**
	 * Per regel een template met het detail, voor het venster. Komt na de tabel (HTML, al geëscaped).
	 */
	public function entry_templates(): string {
		$args = $this->args();
		$html = '';
		// De aantallen van alle objecten in één query, niet één per regel.
		$counts = '' === $args['object'] ? _ww_activity_object_counts( $args, $this->items ) : null;
		foreach ( array_values( $this->items ) as $index => $item ) {
			$data  = $this->row_data( $item );
			$html .= '<template id="ww-activity-entry-' . esc_attr( (string) $index ) . '" data-title="' . esc_attr( _ww_activity_entry_title( $item ) ) . '">' . _ww_activity_entry_detail( $item, $args, $counts, $data['link'], $data['groups'] ) . '</template>';
		}
		return $html;
	}

	/**
	 * Het uur in de tijdzone van de site, met hoe lang geleden als title. De dag staat in het dagkopje.
	 *
	 * @param object $item Regel.
	 */
	protected function column_when( $item ): string {
		return _ww_activity_when_html( $item, true );
	}

	/**
	 * Een rondje of vierkantje, de naam (gelinkt als de gebruiker nog bestaat) en voor een agent of WP-CLI een tweede regel.
	 *
	 * @param object $item Regel.
	 */
	protected function column_who( $item ): string {
		return _ww_activity_who_html( $item );
	}

	/**
	 * Een gekleurd label: groen, geel, rood of neutraal.
	 *
	 * @param object $item Regel.
	 */
	protected function column_action( $item ): string {
		return $this->action_label_html( _ww_data_to_string( $item->action ) );
	}

	/**
	 * Het actielabel als span.
	 *
	 * @param string $action Actie van de regel.
	 */
	private function action_label_html( string $action ): string {
		$class = _ww_activity_action_class( $action );
		return '<span class="ww-activity-action' . ( '' !== $class ? ' ww-activity-action--' . esc_attr( $class ) : '' ) . '">' . esc_html( _ww_activity_action_label( $action ) ) . '</span>';
	}

	/**
	 * De titel, gelinkt naar het bewerkscherm als het object nog bestaat, met de soort eronder. Op mobiel staat er ook de
	 * rest van de regel.
	 *
	 * @param object $item Regel.
	 */
	protected function column_what( $item ): string {
		$title = _ww_data_to_string( $item->object_title );
		$title = '' !== $title ? $title : __( '(zonder titel)', 'webwerckt-base' );
		$data  = $this->row_data( $item );
		$link  = $data['link'];
		$type  = _ww_data_to_string( $item->object_type ?? '' );
		$label = _ww_activity_object_label( $item );
		$html  = '' !== $link ? '<a href="' . esc_url( $link ) . '">' . esc_html( $title ) . '</a>' : esc_html( $title );
		$gone  = '';
		if ( '' === $link && (int) ( $item->object_id ?? 0 ) > 0 && 'imported' !== _ww_data_to_string( $item->action ?? '' ) && in_array( $type, array( 'post', 'attachment', 'menu', 'settings', 'redirect' ), true ) ) {
			$gone = esc_html__( ' · bestaat niet meer', 'webwerckt-base' );
		}

		$count = count( _ww_activity_field_labels( $item, $data['groups'] ) );
		$time  = strtotime( _ww_data_to_string( $item->created ?? '' ) . ' UTC' );
		$meta  = sprintf(
			/* translators: 1: tijd (H:i), 2: wie, 3: aantal velden of "geen velden". */
			__( '%1$s · %2$s · %3$s', 'webwerckt-base' ),
			false !== $time ? wp_date( 'H:i', $time ) : '',
			_ww_activity_who_name( $item ),
			0 === $count
				? __( 'geen velden', 'webwerckt-base' )
				: sprintf(
					/* translators: %d: aantal gewijzigde velden. */
					_n( '%d veld', '%d velden', $count, 'webwerckt-base' ),
					$count
				)
		);

		return '<strong>' . $html . '</strong><br><span class="description">' . esc_html( $label ) . $gone . '</span>'
			. '<span class="ww-activity-meta">' . $this->action_label_html( _ww_data_to_string( $item->action ) ) . ' ' . esc_html( $label )
			. '<br>' . $this->entry_link( $item, '<span class="description">' . esc_html( $meta ) . '</span>', 'ww-activity-entry-link ww-activity-entry-link--meta' ) . '</span>';
	}

	/**
	 * De eerste drie veldlabels en een link naar het detail van de regel.
	 *
	 * @param object $item Regel.
	 */
	protected function column_fields( $item ): string {
		$labels = _ww_activity_field_labels( $item, $this->row_data( $item )['groups'] );
		$count  = count( $labels );
		if ( 0 === $count ) {
			$inner = '<span class="description">' . esc_html__( 'Geen velden', 'webwerckt-base' ) . '</span><span class="ww-activity-entry-hint">' . esc_html__( 'Details', 'webwerckt-base' ) . '</span>';
		} else {
			$inner = '<span class="ww-activity-entry-fields">' . esc_html( implode( ', ', array_slice( $labels, 0, 3 ) ) );
			if ( $count > 3 ) {
				$inner .= ' <span class="description">+' . esc_html( (string) ( $count - 3 ) ) . '</span>';
			}
			$inner .= '</span><span class="ww-activity-entry-hint">' . esc_html(
				$count > 3
					? sprintf(
						/* translators: %d: aantal gewijzigde velden. */
						__( 'Alle %d velden bekijken', 'webwerckt-base' ),
						$count
					)
					: __( 'Bekijken', 'webwerckt-base' )
			) . '</span>';
		}
		return $this->entry_link( $item, $inner, 'ww-activity-entry-link' );
	}

	/**
	 * Een link naar het detail van de regel (&entry={id}); met script opent hij het venster. Er zijn er twee per regel:
	 * de samenvatting in Gewijzigde velden (desktop) en de regel onder de titel (mobiel).
	 *
	 * @param object $item  Regel.
	 * @param string $inner Geëscapete HTML in de link.
	 * @param string $class Klassen van de link.
	 */
	private function entry_link( $item, string $inner, string $class ): string {
		$args = $this->args();
		return '<a class="' . esc_attr( $class ) . '" href="' . esc_url( _ww_activity_entry_url( $args, (int) ( $item->id ?? 0 ) ) ) . '" data-ww-entry="' . esc_attr( (string) $this->row_index ) . '" aria-haspopup="dialog">' . $inner . '</a>';
	}
}
