<?php
/**
 * Formulieren: PDF van een inzending. Dit bestand laadt Dompdf (meegeleverd in `lib/dompdf/`), controleert wat
 * Dompdf nodig heeft en regelt de mappen voor lettertypes en tijdelijke bestanden.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Welke PHP-extensies Dompdf nodig heeft maar de server niet heeft.
 *
 * @return list<string> Namen van ontbrekende extensies; leeg is in orde.
 */
function _ww_form_pdf_requirements(): array {
	$missing = array();
	foreach ( array( 'dom', 'mbstring', 'gd' ) as $extension ) {
		if ( ! extension_loaded( $extension ) ) {
			$missing[] = $extension;
		}
	}
	return $missing;
}

/**
 * Of `Dompdf\Dompdf` bestaat maar niet uit de eigen map `lib/dompdf` komt (bijvoorbeeld van een plugin), of dat geldt
 * voor de Composer-autoloader van het pakket.
 *
 * @param string $loader_class De klasse van de Composer-autoloader van het meegeleverde pakket (alleen een test geeft een andere).
 */
function _ww_form_pdf_foreign( string $loader_class = 'ComposerAutoloaderInit62c6e0ca6ebbd57c14f6d4c2976d1dd0' ): bool {
	// Een Composer-autoloader met dezelfde klassenaam uit een ander bestand (de naam hangt aan de inhoud van
	// composer.json van het pakket): opnieuw declareren is een fatale fout. Alleen die van het thema zelf is in orde.
	if ( class_exists( $loader_class, false ) ) {
		$loader = wp_normalize_path( (string) realpath( (string) ( new ReflectionClass( $loader_class ) )->getFileName() ) );
		$own    = wp_normalize_path( (string) realpath( __DIR__ . '/../lib/dompdf/vendor/composer/autoload_real.php' ) );
		if ( 0 !== strcasecmp( $loader, $own ) ) {
			return true;
		}
	}
	if ( ! class_exists( 'Dompdf\Dompdf', false ) ) {
		return false;
	}
	$file = (string) ( new ReflectionClass( \Dompdf\Dompdf::class ) )->getFileName();
	$dir  = realpath( __DIR__ . '/../lib/dompdf' );
	$own  = wp_normalize_path( false === $dir ? '' : $dir ) . '/';
	return 0 !== strncasecmp( wp_normalize_path( (string) realpath( $file ) ), $own, strlen( $own ) );
}

/**
 * Laadt Dompdf uit het thema, één keer.
 *
 * False als er extensies ontbreken, het bestand er niet is, of een andere Dompdf of Composer-autoloader van hetzelfde pakket al geladen is
 * (dan zou het thema met een onbekende versie werken, of crasht het declareren van de autoloader). Dat laatste komt in het foutlog.
 */
function _ww_form_pdf_load(): bool {
	if ( array() !== _ww_form_pdf_requirements() ) {
		return false;
	}
	if ( _ww_form_pdf_foreign() ) {
		static $logged = false;
		if ( ! $logged ) {
			$logged = true;
			error_log( 'Webwerckt Base: Dompdf is al geladen uit een andere map; de PDF van een formulier gebruikt de meegeleverde versie niet.' ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- bewust in het serverlog.
		}
		return false;
	}
	if ( class_exists( 'Dompdf\Dompdf', false ) ) {
		return true;
	}
	$autoload = dirname( __DIR__ ) . '/lib/dompdf/autoload.inc.php';
	if ( ! is_readable( $autoload ) ) {
		return false;
	}
	require_once $autoload;
	return class_exists( 'Dompdf\Dompdf' );
}

/**
 * De mappen voor Dompdf, onder de afgeschermde formulierenmap: `pdf-fonts` (lettertypecache) en `tmp`.
 *
 * Met `$create` worden ze aangemaakt, met een `index.php`; de `.htaccess` van de hoofdmap beschermt ze.
 *
 * @param bool $create Of de mappen aangemaakt moeten worden.
 * @return array{fonts:string, tmp:string} Lege waarden als de hoofdmap er niet is.
 */
function _ww_form_pdf_dirs( bool $create = false ): array {
	$base = _ww_form_files_base( $create );
	if ( '' === $base ) {
		return array(
			'fonts' => '',
			'tmp'   => '',
		);
	}
	$dirs = array(
		'fonts' => $base . '/pdf-fonts',
		'tmp'   => $base . '/tmp',
	);
	if ( $create ) {
		// phpcs:disable WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- de eigen, afgeschermde map.
		foreach ( $dirs as $dir ) {
			wp_mkdir_p( $dir );
			if ( is_dir( $dir ) && ! file_exists( $dir . '/index.php' ) ) {
				file_put_contents( $dir . '/index.php', "<?php // Stil.\n" );
			}
		}
		// phpcs:enable
	}
	return $dirs;
}

/**
 * Of minstens één gepubliceerd formulier een PDF maakt.
 */
function _ww_form_pdf_in_use(): bool {
	$ids = get_posts(
		array(
			'post_type'      => WW_FORM_POST_TYPE,
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'no_found_rows'  => true,
		)
	);
	foreach ( $ids as $id ) {
		$config = _ww_form_config( (int) $id );
		if ( null !== $config && ! empty( $config['pdf']['enabled'] ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Site Health: kan de server PDF's maken? Alleen als een gepubliceerd formulier dat wil.
 *
 * @return array<string,mixed>
 */
function _ww_form_pdf_health(): array {
	$label   = __( 'PDF van formulierinzendingen', 'webwerckt-base' );
	$missing = _ww_form_pdf_requirements();
	if ( array() !== $missing ) {
		/* translators: %s: namen van PHP-extensies. */
		$text = sprintf( __( 'Een formulier maakt een PDF, maar op deze server ontbreken PHP-extensies: %s. Vraag de host ze aan te zetten.', 'webwerckt-base' ), implode( ', ', $missing ) );
		return _ww_health_result( 'ww_form_pdf', $label, 'critical', '<p>' . esc_html( $text ) . '</p>', __( 'Formulieren', 'webwerckt-base' ) );
	}
	if ( _ww_form_pdf_foreign() ) {
		$text = __( 'Een formulier maakt een PDF, maar een plugin heeft al een andere Dompdf geladen. Het thema gebruikt dan geen eigen versie; zet die plugin uit of laat hem Dompdf niet meer laden.', 'webwerckt-base' );
		return _ww_health_result( 'ww_form_pdf', $label, 'critical', '<p>' . esc_html( $text ) . '</p>', __( 'Formulieren', 'webwerckt-base' ) );
	}
	return _ww_health_result( 'ww_form_pdf', $label, 'good', '<p>' . esc_html__( 'De server heeft alles wat nodig is om een PDF van een formulierinzending te maken.', 'webwerckt-base' ) . '</p>', __( 'Formulieren', 'webwerckt-base' ) );
}

/**
 * Meldt de test in Site-status aan, alleen als een gepubliceerd formulier een PDF maakt.
 *
 * @param array<string,array<string,mixed>> $tests Tests van WordPress.
 * @return array<string,array<string,mixed>>
 */
function _ww_form_pdf_health_test( array $tests ): array {
	if ( _ww_form_pdf_in_use() ) {
		$tests['direct']['ww_form_pdf'] = array(
			'label' => __( 'PDF van formulierinzendingen', 'webwerckt-base' ),
			'test'  => '_ww_form_pdf_health',
		);
	}
	return $tests;
}
add_filter( 'site_status_tests', '_ww_form_pdf_health_test' );

/**
 * De naam van een sjabloon: de regels van een veldsleutel (a-z, cijfers en _, begint met een letter, hoogstens 40
 * tekens). Met `\z` en niet `$`, zodat een regeleinde aan het eind niet meetelt.
 *
 * @param string $name Naam van het sjabloon.
 */
function _ww_form_pdf_template_name_ok( string $name ): bool {
	return 1 === preg_match( '/^[a-z][a-z0-9_]{0,39}\z/', $name );
}

/**
 * De map van het child-thema, of '' zonder child-thema (stylesheet = template).
 */
function _ww_form_pdf_child_dir(): string {
	$child = get_stylesheet_directory();
	return untrailingslashit( wp_normalize_path( $child ) ) === untrailingslashit( wp_normalize_path( get_template_directory() ) ) ? '' : $child;
}

/**
 * De map met PDF-sjablonen van het child-thema (`webwerckt/form-pdf`) als echt pad, of '' zonder child-thema of
 * zonder map. Het parent-thema levert nooit een sjabloon: er wordt niet met locate_template gezocht.
 */
function _ww_form_pdf_template_dir(): string {
	$child = _ww_form_pdf_child_dir();
	if ( '' === $child ) {
		return '';
	}
	$dir = realpath( $child . '/webwerckt/form-pdf' );
	return false !== $dir && is_dir( $dir ) ? untrailingslashit( wp_normalize_path( $dir ) ) : '';
}

/**
 * Het bestand van een PDF-sjabloon in het child-thema: `webwerckt/form-pdf/{naam}.php`.
 *
 * @param string $name Naam van het sjabloon.
 * @return string Absoluut pad, of '' als de naam niet deugt, er geen child-thema is of het bestand er niet (binnen
 *                de map) is.
 */
function _ww_form_pdf_template_file( string $name ): string {
	if ( ! _ww_form_pdf_template_name_ok( $name ) ) {
		return '';
	}
	$dir = _ww_form_pdf_template_dir();
	if ( '' === $dir ) {
		return '';
	}
	$file = realpath( $dir . '/' . $name . '.php' );
	if ( false === $file || ! is_file( $file ) ) {
		return '';
	}
	// Ook via een symbolische link mag het bestand niet buiten de map liggen.
	$file = wp_normalize_path( $file );
	$own  = $dir . '/';
	return 0 === strncasecmp( $file, $own, strlen( $own ) ) ? $file : '';
}

/**
 * De PDF-sjablonen van het child-thema: naam => label. Het label is de kop `Template Name:` in het bestand, anders
 * de naam. Leeg zonder child-thema.
 *
 * @return array<string,string>
 */
function _ww_form_pdf_templates(): array {
	$dir = _ww_form_pdf_template_dir();
	if ( '' === $dir ) {
		return array();
	}
	$templates = array();
	foreach ( (array) glob( $dir . '/*.php' ) as $path ) {
		$name = basename( (string) $path, '.php' );
		$file = _ww_form_pdf_template_file( $name );
		if ( '' === $file ) {
			continue;
		}
		$label              = trim( (string) get_file_data( $file, array( 'name' => 'Template Name' ) )['name'] );
		$templates[ $name ] = '' !== $label ? $label : $name;
	}
	ksort( $templates );
	return $templates;
}

/**
 * Het logo van de site als `data:`-URI: `custom_logo`, anders `site_logo` (zoals in inc/schema.php, maar zonder het
 * site-icoon, dat te klein is voor een kop). Een data-URI omdat uploads buiten de chroot van Dompdf ligt; ook SVG.
 *
 * @return string De data-URI, of '' zonder (leesbaar) logo.
 */
function _ww_form_pdf_logo(): string {
	$id = (int) get_theme_mod( 'custom_logo' ) ?: (int) get_option( 'site_logo' );
	if ( $id <= 0 ) {
		return '';
	}
	$file = (string) get_attached_file( $id );
	$mime = (string) get_post_mime_type( $id );
	if ( '' === $file || ! is_readable( $file ) || ! str_starts_with( $mime, 'image/' ) ) {
		return '';
	}
	// Een rasterafbeelding gaat verkleind mee: GD decodeert de volle resolutie, en dat kost geheugen dat een
	// front-endverzoek niet heeft. SVG blijft zoals hij is.
	if ( 'image/svg+xml' !== $mime ) {
		$file = _ww_form_pdf_logo_file( $id, $file );
		if ( '' === $file ) {
			return '';
		}
		$mime = (string) ( wp_check_filetype( $file )['type'] ?: $mime );
	}
	if ( filesize( $file ) > 5 * MB_IN_BYTES ) {
		return '';
	}
	$data = file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- lokaal bestand uit de mediabibliotheek.
	if ( false === $data || '' === $data ) {
		return '';
	}
	return 'data:' . $mime . ';base64,' . base64_encode( $data ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- een data-URI voor Dompdf.
}

/**
 * Het bestand van een rasterlogo voor de PDF: een tussenmaat die op schijf staat, anders het origineel als dat niet
 * meer dan 4 megapixel is.
 *
 * @param int    $id   Bijlage.
 * @param string $file Pad van het origineel.
 * @return string Pad, of '' als er niets verantwoords is.
 */
function _ww_form_pdf_logo_file( int $id, string $file ): string {
	foreach ( array( 'medium_large', 'large', 'medium' ) as $size ) {
		$sized = image_get_intermediate_size( $id, $size );
		if ( is_array( $sized ) && ! empty( $sized['file'] ) ) {
			$path = dirname( $file ) . '/' . $sized['file'];
			if ( is_readable( $path ) ) {
				return $path;
			}
		}
	}
	$info = wp_getimagesize( $file );
	if ( ! is_array( $info ) || $info[0] * $info[1] > 4000000 ) {
		return '';
	}
	return $file;
}

/**
 * Zet het geheugen- en tijdsbudget klaar voor het maken van een PDF: de beheerlimiet, ook op een front-endverzoek
 * (de inzending). Dompdf en GD hebben veel geheugen nodig en een fatale fout is geen Throwable.
 */
function _ww_form_pdf_prepare(): void {
	wp_raise_memory_limit( 'admin' );
}

/**
 * De gegevens voor een PDF-sjabloon: de array `$pdf` uit de spec (docs/specs/formulieren-pdf.md). De velden komen uit
 * een inzending (`_ww_form_entry_fields()`), zodat een latere download dezelfde labels en secties geeft. De velden
 * blijven in hun volgorde; een nieuwe sectie begint zodra de stap van een veld anders is dan die van het veld ervoor.
 * Zo krijgt elke stap een eigen sectie, ook als twee stappen (niet naast elkaar) dezelfde of geen titel hebben.
 * Velden zonder `step` (oudere inzendingen) komen samen in één sectie zonder titel. Een verborgen veld (`hidden`)
 * komt in geen sectie; in `values` staat het met zijn lege waarde, zodat een sjabloon elke sleutel kan lezen.
 *
 * @param int                                  $form_id  Formulier.
 * @param array<array-key,array<string,mixed>> $fields   Velden zoals in de inzending: sleutel => label, type, value, display, step.
 * @param int                                  $entry_id Inzending, 0 als er niet is opgeslagen.
 * @param string                               $page_url Pagina waarop is ingevuld.
 * @param string                               $date     Datum zoals {datum}.
 * @return array<string,mixed>
 */
function _ww_form_pdf_data( int $form_id, array $fields, int $entry_id, string $page_url, string $date ): array {
	$sections = array();
	$values   = array();
	foreach ( $fields as $key => $field ) {
		$key = (string) $key;
		if ( ! empty( $field['hidden'] ) ) {
			$values[ $key ] = $field['value'] ?? '';
			continue;
		}
		$title = _ww_form_string( $field['step'] ?? '' );
		$last  = array_key_last( $sections );
		if ( null === $last || $sections[ $last ]['title'] !== $title ) {
			$sections[] = array(
				'title'  => $title,
				'fields' => array(),
			);
			$last       = array_key_last( $sections );
		}
		$sections[ $last ]['fields'][] = array(
			'key'     => $key,
			'type'    => _ww_form_string( $field['type'] ?? '' ),
			'label'   => _ww_form_string( $field['label'] ?? '' ),
			'value'   => $field['value'] ?? '',
			'display' => _ww_form_string( $field['display'] ?? '' ),
		);
		$values[ $key ] = $field['value'] ?? '';
	}

	$pdf = array(
		'form'     => array(
			'id'    => $form_id,
			'title' => wp_specialchars_decode( (string) get_post_field( 'post_title', $form_id ), ENT_QUOTES ),
			'slug'  => (string) get_post_field( 'post_name', $form_id ),
		),
		'entry_id' => $entry_id,
		'date'     => $date,
		'page_url' => $page_url,
		'sections' => $sections,
		'values'   => $values,
		'site'     => array(
			'name' => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			'url'  => home_url( '/' ),
			'logo' => _ww_form_pdf_logo(),
		),
		'base'     => get_stylesheet_directory(),
	);

	/**
	 * Filtert de gegevens voor het PDF-sjabloon, bijvoorbeeld om een berekend totaal toe te voegen.
	 *
	 * @param array<string,mixed> $pdf      De gegevens.
	 * @param int                 $form_id  Formulier.
	 * @param int                 $entry_id Inzending, 0 als er niet is opgeslagen.
	 */
	$filtered = _ww_form_array( apply_filters( 'ww_form_pdf_data', $pdf, $form_id, $entry_id ) );
	return array() !== $filtered ? $filtered : $pdf;
}

/**
 * De HTML voor de PDF: het sjabloon uit het child-thema, of de ingebouwde standaardopmaak als er geen (bestaand)
 * sjabloon is. Een fout uit het sjabloon gaat door naar de aanroeper; de uitvoerbuffers zijn dan weer opgeruimd.
 *
 * @param array<string,mixed> $pdf      Gegevens uit _ww_form_pdf_data().
 * @param string              $template Naam van het sjabloon, '' voor de standaardopmaak.
 * @throws Throwable Uit het sjabloon.
 */
function _ww_form_pdf_html( array $pdf, string $template ): string {
	$file = '' !== $template ? _ww_form_pdf_template_file( $template ) : '';
	if ( '' === $file ) {
		return _ww_form_pdf_default_html( $pdf );
	}

	// Een eigen scope: in het sjabloon bestaat alleen $pdf. Het pad komt als extra, niet benoemd argument mee
	// (func_get_arg), zodat het geen variabele in het sjabloon wordt.
	$include = static function ( array $pdf ): void { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- $pdf is voor het sjabloon.
		include func_get_arg( 1 );
	};

	$level = ob_get_level();
	ob_start();
	try {
		( new ReflectionFunction( $include ) )->invoke( $pdf, $file );
		$html = '';
		while ( ob_get_level() > $level ) {
			$html = (string) ob_get_clean() . $html;
		}
		return $html;
	} catch ( Throwable $e ) {
		while ( ob_get_level() > $level ) {
			ob_end_clean();
		}
		throw $e;
	}
}

/**
 * Een Dompdf met de vaste instellingen: geen externe bestanden, geen PHP of JavaScript, alleen `file://` en
 * `data://`, en lezen alleen uit het child-thema, `lib/dompdf` en de lettertypemap. Papier en richting komen uit het
 * filter `ww_form_pdf_options` (alleen `paper` en `orientation`; de rest blijft vast).
 *
 * @param int $form_id Formulier, voor het filter.
 * @throws RuntimeException Als Dompdf niet te laden is of de mappen er niet zijn.
 */
function _ww_form_pdf_dompdf( int $form_id ): \Dompdf\Dompdf {
	if ( ! _ww_form_pdf_load() ) {
		throw new RuntimeException( 'Dompdf kon niet worden geladen.' );
	}
	$dirs = _ww_form_pdf_dirs( true );
	if ( '' === $dirs['fonts'] || '' === $dirs['tmp'] ) {
		throw new RuntimeException( 'De mappen voor de PDF ontbreken.' );
	}

	$chroot = array();
	if ( '' !== _ww_form_pdf_child_dir() ) {
		$chroot[] = get_stylesheet_directory();
	}
	$chroot[] = dirname( __DIR__ ) . '/lib/dompdf';
	$chroot[] = $dirs['fonts'];

	$options = new \Dompdf\Options();
	$options->setIsRemoteEnabled( false );
	$options->setIsPhpEnabled( false );
	$options->setIsJavascriptEnabled( false );
	$options->setAllowedProtocols( array( 'file://', 'data://' ) );
	$options->setChroot( $chroot );
	$options->setFontDir( $dirs['fonts'] );
	$options->setFontCache( $dirs['fonts'] );
	$options->setTempDir( $dirs['tmp'] );
	$options->setDefaultPaperSize( 'a4' );
	$options->setDefaultFont( 'DejaVu Sans' );

	/**
	 * Filtert het papier van de PDF. Alleen `paper` (een maat die Dompdf kent, zoals a4, a5 of letter) en
	 * `orientation` (portrait of landscape) tellen; andere sleutels worden genegeerd.
	 *
	 * @param array<string,mixed> $settings Papier en richting: `paper` en `orientation`.
	 * @param int                 $form_id  Formulier.
	 */
	$settings    = _ww_form_array(
		apply_filters(
		'ww_form_pdf_options',
			array(
				'paper'       => 'a4',
				'orientation' => 'portrait',
			),
			$form_id
		)
	);
	$paper       = strtolower( _ww_form_string( $settings['paper'] ?? '' ) );
	$paper       = isset( \Dompdf\Adapter\CPDF::$PAPER_SIZES[ $paper ] ) ? $paper : 'a4';
	$orientation = 'landscape' === _ww_form_string( $settings['orientation'] ?? '' ) ? 'landscape' : 'portrait';

	$dompdf = new \Dompdf\Dompdf( $options );
	$dompdf->setPaper( $paper, $orientation );

	// Het basispad: een relatieve URL in een sjabloon (bijvoorbeeld `webwerckt/form-pdf/fonts/x.ttf`) is relatief aan
	// het child-thema, niet aan de werkmap van PHP. Zonder child-thema is dat `lib/dompdf`. Het protocol is vast
	// `file://`; de chroot blijft gelden, ook voor `../`.
	$dompdf->setProtocol( 'file://' );
	$dompdf->setBasePath( trailingslashit( wp_normalize_path( '' !== _ww_form_pdf_child_dir() ? get_stylesheet_directory() : dirname( __DIR__ ) . '/lib/dompdf' ) ) );
	return $dompdf;
}

/**
 * Maakt een PDF van HTML, elke keer met een nieuwe Dompdf.
 *
 * @param string $html    HTML uit _ww_form_pdf_html().
 * @param int    $form_id Formulier, voor het filter ww_form_pdf_options.
 * @return string De PDF.
 * @throws RuntimeException Als Dompdf niet te laden is.
 */
function _ww_form_pdf_render( string $html, int $form_id ): string {
	$dompdf = _ww_form_pdf_dompdf( $form_id );
	$dompdf->loadHtml( $html, 'UTF-8' );
	$dompdf->render();
	return (string) $dompdf->output();
}

/**
 * De grens voor de PDF als bijlage: 10 MB, los van de bijlagengrens voor uploads.
 */
const WW_FORM_PDF_MAX_BYTES = 10 * MB_IN_BYTES;

/**
 * De grootste PDF die als bijlage meegaat, in bytes. Het filter `ww_form_pdf_max_bytes` kan hem aanpassen.
 */
function _ww_form_pdf_max_bytes(): int {
	return max( 0, (int) apply_filters( 'ww_form_pdf_max_bytes', WW_FORM_PDF_MAX_BYTES ) );
}

/**
 * De bestandsnaam van de PDF in de mail: de instelling `filename` met mailtags, bestandsveilig gemaakt, met `.pdf`.
 *
 * Leeg wordt `formulier`. Het filter `ww_form_pdf_filename` (naam zonder extensie, formulier, inzending) kan de naam
 * aanpassen; daarna wordt hij opnieuw bestandsveilig gemaakt, zodat een filter geen pad kan inbrengen.
 *
 * @param int                 $form_id  Formulier.
 * @param array<string,mixed> $config   Opgeschoonde configuratie.
 * @param array<string,string> $tags    Mailtags (ongeperkt).
 * @param int                 $entry_id Inzending, 0 als er niet is opgeslagen.
 */
function _ww_form_pdf_filename( int $form_id, array $config, array $tags, int $entry_id ): string {
	$template = _ww_form_string( _ww_form_array( $config['pdf'] ?? array() )['filename'] ?? '' );
	$name     = sanitize_file_name( _ww_form_mail_replace( $template, $tags, true ) );
	$name     = '' !== $name ? $name : 'formulier';
	$name     = sanitize_file_name( (string) apply_filters( 'ww_form_pdf_filename', $name, $form_id, $entry_id ) );
	return ( '' !== $name ? $name : 'formulier' ) . '.pdf';
}

/**
 * Maakt de PDF van een inzending voor de mail en zet hem als tijdelijk bestand in `tmp/` van de formulierenmap.
 *
 * Elke fout (sjabloon, Dompdf, schrijven) wordt afgevangen en gelogd, zonder ingevulde waarden: de mail gaat dan
 * zonder PDF uit. Is de PDF groter dan _ww_form_pdf_max_bytes(), dan wordt hij niet bewaard en is `too_large` waar.
 * De aanroeper gooit `path` weg na de mails.
 *
 * @param int                 $form_id  Formulier.
 * @param array<string,mixed> $config   Opgeschoonde configuratie.
 * @param array<string,mixed> $values   Waarden per veldsleutel.
 * @param string              $page_url Pagina waarop is ingevuld.
 * @param int                 $entry_id Inzending, 0 als er niet is opgeslagen.
 * @return array{path:string, name:string, error:string, too_large:bool}
 */
function _ww_form_pdf_for_mail( int $form_id, array $config, array $values, string $page_url, int $entry_id ): array {
	$result = array(
		'path'      => '',
		'name'      => '',
		'error'     => '',
		'too_large' => false,
	);
	try {
		_ww_form_pdf_prepare();
		$tags = _ww_form_mail_tags( $form_id, $config, $values, $page_url, false );
		$pdf  = _ww_form_pdf_data( $form_id, _ww_form_entry_fields( $config, $values, _ww_form_hidden_keys( $config, $values ) ), $entry_id, $page_url, $tags['datum'] );
		$html = _ww_form_pdf_html( $pdf, _ww_form_string( _ww_form_array( $config['pdf'] ?? array() )['template'] ?? '' ) );
		$bin  = _ww_form_pdf_render( $html, $form_id );
		if ( strlen( $bin ) > _ww_form_pdf_max_bytes() ) {
			$result['too_large'] = true;
			return $result;
		}

		// De naam eerst: een filter dat gooit geeft dan geen bestand zonder naam.
		$name = _ww_form_pdf_filename( $form_id, $config, $tags, $entry_id );
		$tmp  = _ww_form_pdf_dirs( true )['tmp'];
		if ( '' === $tmp || ! is_dir( $tmp ) ) {
			throw new RuntimeException( 'de map voor tijdelijke bestanden ontbreekt' );
		}
		$path = $tmp . '/' . wp_generate_password( 32, false ) . '.pdf';
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- de eigen, afgeschermde map.
		if ( false === file_put_contents( $path, $bin ) ) {
			throw new RuntimeException( 'de PDF kon niet worden geschreven' );
		}
		$result['name'] = $name;
		$result['path'] = $path;
	} catch ( Throwable $e ) {
		$result['error'] = '' !== $e->getMessage() ? $e->getMessage() : get_class( $e );
		error_log( sprintf( 'webwerckt-base: PDF van formulier %d (inzending %d) mislukt: %s', $form_id, $entry_id, $result['error'] ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- bedoelde melding in het PHP-logboek.
	}
	return $result;
}

/**
 * Gooit bestanden in `tmp/` weg die ouder zijn dan een uur. `index.php` blijft.
 */
function _ww_form_pdf_tmp_cleanup(): void {
	$tmp = _ww_form_pdf_dirs()['tmp'];
	if ( '' === $tmp || ! is_dir( $tmp ) ) {
		return;
	}
	$limit = time() - HOUR_IN_SECONDS;
	foreach ( glob( $tmp . '/*' ) ?: array() as $file ) {
		if ( is_file( $file ) && 'index.php' !== basename( $file ) && filemtime( $file ) < $limit ) {
			unlink( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink -- tijdelijk bestand in de eigen map.
		}
	}
}

/**
 * De locale van de taal van het formulier uit de taalinstellingen, of '' zonder Meertalig (of zonder bekende taal).
 *
 * Een inzending heeft geen eigen taal: het formulier bepaalt hem, zoals de kolom Taal in de inzendingenlijst.
 *
 * @param int $form_id Formulier.
 */
function _ww_form_pdf_locale( int $form_id ): string {
	$code = _ww_post_language( $form_id );
	if ( '' === $code ) {
		return '';
	}
	$language = _ww_language( $code );
	return null !== $language ? (string) $language['locale'] : '';
}

/**
 * De Content-Disposition voor een PDF: een ASCII-naam voor oude clients (accenten omgezet, rest `-`) en `filename*`
 * (RFC 5987) met de echte naam in UTF-8.
 *
 * @param string $type `attachment` of `inline`.
 * @param string $name Bestandsnaam, al bestandsveilig gemaakt.
 */
function _ww_form_pdf_disposition( string $type, string $name ): string {
	$ascii = (string) preg_replace( '/[^A-Za-z0-9._-]/', '-', remove_accents( $name ) );
	return $type . '; filename="' . $ascii . '"; filename*=UTF-8' . "''" . rawurlencode( $name );
}

/**
 * Maakt de PDF van een bewaarde inzending, met de headers voor een download. Er wordt niets bewaard of verstuurd.
 *
 * De velden, labels en stappen komen uit de inzending zelf (zoals ze waren bij het inzenden), de datum is de
 * aanmaakdatum van de inzending in de tijd van de site, in het formaat van {datum}. Is de taal van het formulier een
 * andere dan de huidige, dan wordt er tijdelijk naar die locale gewisseld; daarna gaat hij altijd terug.
 *
 * @param object $entry Inzending uit _ww_form_entry_get().
 * @return array{headers:array<string,string>, body:string}
 * @throws RuntimeException Als het formulier niet bestaat of geen PDF maakt, of Dompdf of het sjabloon faalt.
 */
function _ww_form_pdf_entry_response( object $entry ): array {
	$form_id  = (int) $entry->form_id;
	$entry_id = (int) $entry->id;
	$config   = _ww_form_config( $form_id );
	if ( null === $config || empty( $config['pdf']['enabled'] ) ) {
		throw new RuntimeException( 'dit formulier maakt geen PDF' );
	}

	_ww_form_pdf_prepare();
	$locale   = _ww_form_pdf_locale( $form_id );
	$switched = '' !== $locale && $locale !== determine_locale() && switch_to_locale( $locale );
	try {
		$fields = array();
		$values = array();
		foreach ( (array) $entry->fields as $key => $field ) {
			if ( is_array( $field ) ) {
				$fields[ (string) $key ] = $field;
				$values[ (string) $key ] = $field['value'] ?? '';
			}
		}
		$time = strtotime( (string) $entry->created . ' UTC' );
		$date = wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), false === $time ? null : $time );

		$page = (string) $entry->page_url;
		$tags = _ww_form_mail_tags( $form_id, $config, $values, $page, false );
		$tags['datum'] = $date;

		$pdf  = _ww_form_pdf_data( $form_id, $fields, $entry_id, $page, $date );
		$html = _ww_form_pdf_html( $pdf, _ww_form_string( _ww_form_array( $config['pdf'] )['template'] ?? '' ) );
		$body = _ww_form_pdf_render( $html, $form_id );
		$name = _ww_form_pdf_filename( $form_id, $config, $tags, $entry_id );
	} finally {
		if ( $switched ) {
			restore_previous_locale();
		}
	}

	return array(
		'headers' => array(
			'Content-Type'           => 'application/pdf',
			'Content-Disposition'    => _ww_form_pdf_disposition( 'attachment', $name ),
			'Content-Length'         => (string) strlen( $body ),
			'Cache-Control'          => 'no-store',
			'X-Content-Type-Options' => 'nosniff',
		),
		'body'    => $body,
	);
}

/**
 * Stuurt de PDF van een inzending als download. De aanroeper stopt daarna (`exit`). Bij een fout (sjabloon, Dompdf)
 * gaat het terug naar het scherm met een melding; in het logboek komt geen ingevulde waarde.
 *
 * @param object $entry Inzending uit _ww_form_entry_get().
 */
function _ww_form_pdf_entry_send( object $entry ): void {
	try {
		$response = _ww_form_pdf_entry_response( $entry );
	} catch ( Throwable $e ) {
		error_log( sprintf( 'webwerckt-base: PDF downloaden van inzending %d (formulier %d) mislukt: %s', (int) $entry->id, (int) $entry->form_id, '' !== $e->getMessage() ? $e->getMessage() : get_class( $e ) ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- bedoelde melding in het PHP-logboek.
		_ww_forms_entries_done( __( 'De PDF kon niet worden gemaakt. Kijk in het PHP-logboek of in het sjabloon van het child-thema.', 'webwerckt-base' ), 'error' );
		return;
	}
	nocache_headers();
	foreach ( $response['headers'] as $name => $value ) {
		header( $name . ': ' . $value );
	}
	echo $response['body']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- binaire PDF, geen markup.
}

/**
 * Of dit formulier een PDF maakt (de instelling `pdf.enabled`).
 *
 * @param int $form_id Formulier.
 */
function _ww_form_pdf_enabled( int $form_id ): bool {
	$config = _ww_form_config( $form_id );
	return null !== $config && ! empty( $config['pdf']['enabled'] );
}

/**
 * Voorbeeldwaarden voor de voorbeeld-PDF in de builder: per veld het label als waarde, bij een bestandsveld een
 * voorbeeldbestand. Het formaat is dat van _ww_form_entry_fields(), dus ook met de stap waar het veld onder valt.
 *
 * @param array<string,mixed> $config Opgeschoonde configuratie.
 * @return array<array-key,array<string,mixed>>
 */
function _ww_form_pdf_sample_fields( array $config ): array {
	$fields = _ww_form_entry_fields( $config, array() );
	foreach ( $fields as $key => $field ) {
		$text                    = 'file' === $field['type'] ? 'voorbeeld.pdf (12 KB)' : (string) $field['label'];
		$fields[ $key ]['value']   = $text;
		$fields[ $key ]['display'] = $text;
	}
	return $fields;
}

/**
 * Maakt de voorbeeld-PDF van een configuratie, met de headers om hem in het tabblad te tonen. Er wordt niets bewaard
 * of verstuurd.
 *
 * @param int                 $form_id Formulier.
 * @param array<string,mixed> $config  Opgeschoonde configuratie, ook als die nog niet is opgeslagen.
 * @return array{headers:array<string,string>, body:string}
 * @throws Throwable Uit het sjabloon of Dompdf.
 */
function _ww_form_pdf_preview_response( int $form_id, array $config ): array {
	_ww_form_pdf_prepare();
	$fields = _ww_form_pdf_sample_fields( $config );
	$values = array();
	foreach ( $fields as $key => $field ) {
		$values[ (string) $key ] = $field['value'];
	}
	$page = home_url( '/' );
	$tags = _ww_form_mail_tags( $form_id, $config, $values, $page, false );
	$pdf  = _ww_form_pdf_data( $form_id, $fields, 0, $page, $tags['datum'] );
	$html = _ww_form_pdf_html( $pdf, _ww_form_string( _ww_form_array( $config['pdf'] ?? array() )['template'] ?? '' ) );
	$body = _ww_form_pdf_render( $html, $form_id );
	$name = _ww_form_pdf_filename( $form_id, $config, $tags, 0 );

	return array(
		'headers' => array(
			'Content-Type'           => 'application/pdf',
			'Content-Disposition'    => _ww_form_pdf_disposition( 'inline', $name ),
			'Content-Length'         => (string) strlen( $body ),
			'Cache-Control'          => 'no-store',
			'X-Content-Type-Options' => 'nosniff',
		),
		'body'    => $body,
	);
}

/**
 * De voorbeeld-PDF van een formulier (`admin-post.php?action=ww_form_pdf_preview&form=ID&_wpnonce=…`).
 *
 * Vereist `edit_post` op het formulier en de nonce `ww_form_pdf_preview_{id}`. De builder stuurt de configuratie zoals
 * hij nu is als POST `config` (JSON); die gaat door ww_form_sanitize(), zodat niet-opgeslagen wijzigingen meedoen.
 * Zonder `config` geldt de opgeslagen configuratie.
 */
function _ww_form_pdf_preview(): void {
	// phpcs:disable WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput -- de nonce wordt hieronder gecontroleerd; alleen een getal en JSON voor ww_form_sanitize() worden gebruikt.
	$form_id = absint( _ww_data_to_string( wp_unslash( $_REQUEST['form'] ?? '' ) ) );
	$raw     = _ww_data_to_string( wp_unslash( $_POST['config'] ?? '' ) );
	// phpcs:enable
	if ( $form_id <= 0 || WW_FORM_POST_TYPE !== get_post_type( $form_id ) || ! current_user_can( 'edit_post', $form_id ) ) {
		wp_die( esc_html__( 'Je hebt geen rechten om de voorbeeld-PDF van dit formulier te maken.', 'webwerckt-base' ), 403 );
	}
	check_admin_referer( 'ww_form_pdf_preview_' . $form_id );

	$config  = null;
	$decoded = '' !== $raw ? json_decode( $raw, true ) : null;
	if ( is_array( $decoded ) ) {
		$config = ww_form_sanitize( $decoded )['config'];
	}
	$config = $config ?? _ww_form_config( $form_id );
	if ( null === $config ) {
		wp_die( esc_html__( 'Dit formulier bestaat niet meer.', 'webwerckt-base' ), 404 );
	}

	$missing = _ww_form_pdf_requirements();
	if ( array() !== $missing ) {
		/* translators: %s: namen van de ontbrekende PHP-extensies. */
		wp_die( esc_html( sprintf( __( 'PDF kan niet: de PHP-extensie(s) %s ontbreken.', 'webwerckt-base' ), implode( ', ', $missing ) ) ), 500 );
	}

	try {
		$response = _ww_form_pdf_preview_response( $form_id, $config );
	} catch ( Throwable $e ) {
		error_log( sprintf( 'webwerckt-base: voorbeeld-PDF van formulier %d mislukt: %s', $form_id, '' !== $e->getMessage() ? $e->getMessage() : get_class( $e ) ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- bedoelde melding in het PHP-logboek.
		wp_die( esc_html__( 'De voorbeeld-PDF kon niet worden gemaakt. Kijk in het PHP-logboek of in het sjabloon van het child-thema.', 'webwerckt-base' ), 500 );
	}
	nocache_headers();
	foreach ( $response['headers'] as $name => $value ) {
		header( $name . ': ' . $value );
	}
	echo $response['body']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- binaire PDF, geen markup.
	exit;
}
add_action( 'admin_post_ww_form_pdf_preview', '_ww_form_pdf_preview' );
