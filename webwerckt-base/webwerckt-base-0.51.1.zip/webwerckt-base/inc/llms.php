<?php
/**
 * llms.txt: een kort overzicht van de site voor AI-diensten. Dit bestand heeft de keuzes (modus, soorten pagina's);
 * de inhoud en het serveren komen in latere onderdelen.
 *
 * De velden staan in de Site-instellingen (groep seo_llms in pods/settings.json), maar op het scherm SEO en niet op
 * Site-instellingen zelf (de groepsvlag ww_screen, _ww_settings_group_page()).
 *
 * @package webwerckt-base
 */

defined( 'ABSPATH' ) || exit;

/*
 * Keuzes: welke soorten pagina's kunnen in llms.txt.
 */

/**
 * Soorten pagina's die in llms.txt kunnen: pagina, bericht en de eigen post types van de sitemap, alleen als ze
 * geregistreerd zijn (post type => meervoudslabel). Pagina eerst, de rest op label.
 *
 * Leest geen instellingen: dit draait binnen _ww_pods_config(), en een instelling lezen in een extra taal gaat via
 * _ww_setting_field() terug naar _ww_pods_config() (een lus).
 *
 * @return array<string,string>
 */
function _ww_llms_choices(): array {
	$types = array( 'page', 'post' );
	$names = array();
	foreach ( $types as $type ) {
		$object = get_post_type_object( $type );
		if ( null !== $object ) {
			$names[ $type ] = _ww_plain_text( (string) $object->labels->name );
		}
	}
	$choices = array();
	if ( _ww_seo_enabled() ) {
		foreach ( _ww_seo_sitemap_objects() as $name => $object ) {
			$names[ $name ] = _ww_plain_text( (string) $object->labels->name );
		}
	}
	if ( isset( $names['page'] ) ) {
		$choices['page'] = $names['page'];
		unset( $names['page'] );
	}
	asort( $names, SORT_NATURAL | SORT_FLAG_CASE );
	return $choices + $names;
}

/**
 * Post types die in de sitemap staan: dezelfde als WP_Sitemaps_Posts (publiek, bekijkbaar, zonder bijlage), met het
 * resultaat van _ww_seo_sitemap_post_types() (keuze in de Site-instellingen en het filter ww_sitemap_post_types).
 * Niet voor de veldconfig: dat leest instellingen.
 *
 * @return string[]
 */
function _ww_llms_sitemap_types(): array {
	$objects = array();
	foreach ( get_post_types( array( 'public' => true ), 'objects' ) as $name => $object ) {
		if ( 'attachment' !== $name && is_post_type_viewable( $object ) ) {
			$objects[ (string) $name ] = $object;
		}
	}
	$allowed = _ww_seo_sitemap_post_types( $objects );
	return is_array( $allowed ) ? array_map( 'strval', array_keys( $allowed ) ) : array();
}

/**
 * Het veld seo_llms_post_types (_ww_pods_add_llms_field() in inc/config.php). De keuzes hangen af van de
 * geregistreerde post types en staan daarom niet in pods/settings.json. null zonder keuzes.
 *
 * @param array<string,string> $choices Keuzes (_ww_llms_choices()).
 * @return array<string,mixed>|null
 */
function _ww_llms_field( array $choices ): ?array {
	if ( array() === $choices ) {
		return null;
	}
	$lines = array();
	foreach ( $choices as $name => $label ) {
		$lines[] = $name . '|' . $label;
	}
	return array(
		'name'              => 'seo_llms_post_types',
		'label'             => __( 'Welke soorten pagina\'s', 'webwerckt-base' ),
		'type'              => 'pick',
		'pick_object'       => 'custom-simple',
		'pick_custom'       => implode( "\n", $lines ),
		'pick_format_type'  => 'multi',
		'pick_format_multi' => 'checkbox',
		'description'       => __( 'Aangevinkt: die soort staat in llms.txt. Een nieuwe soort staat standaard uit.', 'webwerckt-base' ),
	);
}

/*
 * Instellingen lezen.
 */

/**
 * De modus van llms.txt: auto, on of off. Onbekend is auto.
 */
function _ww_llms_mode(): string {
	$mode = _ww_data_to_string( _ww_data_get_setting( 'seo_llms_mode' ) );
	return in_array( $mode, array( 'auto', 'on', 'off' ), true ) ? $mode : 'auto';
}

/**
 * Serveert het thema llms.txt? Niet naast een SEO-plugin of als het thema de SEO niet doet. Auto: zodra zoekmachines
 * de site mogen zien.
 */
function _ww_llms_enabled(): bool {
	if ( ! _ww_seo_enabled() ) {
		return false;
	}
	$mode = _ww_llms_mode();
	if ( 'auto' === $mode ) {
		return '1' === (string) get_option( 'blog_public' );
	}
	return 'on' === $mode;
}

/**
 * De gekozen post types uit de Site-instellingen. Niet via _ww_data_get_setting(): dat maakt van "" (alles
 * uitgevinkt) null. null (nooit opgeslagen) is alleen pagina's; "" is niets; tekst of lijst zijn de namen.
 *
 * @return string[]
 */
function _ww_llms_chosen_types(): array {
	$raw = get_option( _ww_settings_prefix() . 'seo_llms_post_types', null );
	if ( null === $raw || false === $raw ) {
		return array( 'page' );
	}
	$list = is_array( $raw ) ? $raw : preg_split( '/[\s,]+/', _ww_data_to_string( $raw ) );
	$out  = array();
	foreach ( is_array( $list ) ? $list : array() as $name ) {
		$name = sanitize_key( _ww_data_to_string( $name ) );
		if ( '' !== $name ) {
			$out[] = $name;
		}
	}
	return array_values( array_unique( $out ) );
}

/**
 * De post types in llms.txt: gekozen, en nog in de sitemap, in de volgorde van _ww_llms_choices().
 *
 * @return string[]
 */
function _ww_llms_post_types(): array {
	$chosen  = _ww_llms_chosen_types();
	$allowed = _ww_llms_sitemap_types();
	$out     = array();
	foreach ( array_keys( _ww_llms_choices() ) as $name ) {
		if ( in_array( $name, $chosen, true ) && in_array( $name, $allowed, true ) ) {
			$out[] = $name;
		}
	}
	return $out;
}

/*
 * Inhoud: de Markdown per taal.
 *
 * $lang is overal expliciet: '' is de standaardtaal (en de site zonder Meertalig), anders een extra taalcode. Ook in de
 * admin, waar het taalfilter van de voorkant niet draait.
 */

/**
 * Hoogstens zoveel links in llms.txt (het filter ww_llms_max_links is alleen voor tests).
 */
const WW_LLMS_MAX_LINKS = 500;

/**
 * Het aantal links waarboven de lijst wordt ingekort.
 */
function _ww_llms_max_links(): int {
	return max( 1, (int) apply_filters( 'ww_llms_max_links', WW_LLMS_MAX_LINKS ) );
}

/**
 * Een taalcode naar de afspraak van dit bestand: '' voor de standaardtaal (en zonder Meertalig of bij een onbekende
 * code), anders de code van een extra taal.
 */
function _ww_llms_normalize_language( string $lang ): string {
	return _ww_languages_active() && in_array( $lang, _ww_extra_language_codes(), true ) ? $lang : '';
}

/**
 * De taal voor de taalvoorwaarde van een query: '' wordt de code van de standaardtaal.
 */
function _ww_llms_query_language( string $lang ): string {
	return '' === $lang ? _ww_default_language() : $lang;
}

/**
 * Query-argumenten voor de pagina's van één post type: gepubliceerd, zonder wachtwoord, nieuwste eerst, met dezelfde
 * uitsluitingen als de sitemap (noindex, eigen canonical) en het vinkje ww_seo_llms_exclude. Eén bericht méér dan de
 * limiet, zodat te zien is of er is ingekort.
 *
 * @return array<string,mixed>
 */
function _ww_llms_query_args( string $post_type, string $lang ): array {
	$args = array(
		'post_type'              => $post_type,
		'post_status'            => 'publish',
		'has_password'           => false,
		'orderby'                => array(
			'date' => 'DESC',
			'ID'   => 'DESC',
		),
		'posts_per_page'         => _ww_llms_max_links() + 1,
		'no_found_rows'          => true,
		'ignore_sticky_posts'    => true,
		'meta_query'             => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_query_meta_query -- uitsluiting per pagina.
			'relation' => 'OR',
			array(
				'key'     => 'ww_seo_llms_exclude',
				'compare' => 'NOT EXISTS',
			),
			array(
				'key'     => 'ww_seo_llms_exclude',
				'value'   => array( '', '0' ),
				'compare' => 'IN',
			),
		),
	);
	$args = _ww_seo_sitemap_query_args( $args );
	$args = is_array( $args ) ? $args : array();
	if ( _ww_languages_active() && _ww_is_translatable( $post_type ) ) {
		$args['tax_query'] = _ww_languages_and_tax_query( array(), _ww_llms_query_language( $lang ) ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- de taal hoort bij llms.txt.
	}
	return $args;
}

/**
 * De vaste voorpagina in een taal: de ruwe page_on_front, in een extra taal de vertaling; 0 zonder vaste voorpagina.
 */
function _ww_llms_front_page_id( string $lang ): int {
	if ( 'page' !== get_option( 'show_on_front' ) ) {
		return 0;
	}
	$id = _ww_languages_raw_page_option( 'page_on_front' );
	if ( $id > 0 && '' !== $lang ) {
		return ww_translation_id( $id, $lang );
	}
	return $id;
}

/**
 * Titel, adres en beschrijving van een pagina. Titel: het SEO-veld, voor de voorpagina de titel uit de
 * Site-instellingen, anders de paginatitel. Beschrijving: het SEO-veld, voor de voorpagina de beschrijving uit de
 * Site-instellingen, anders het begin van de tekst; ingekort tot de goede lengte.
 *
 * @return array{title:string,url:string,description:string}
 */
function _ww_llms_entry( WP_Post $post, string $lang ): array {
	$front       = $post->ID === _ww_llms_front_page_id( $lang );
	$title       = _ww_seo_field( 'ww_seo_title', $post->ID );
	$description = _ww_seo_field( 'ww_seo_description', $post->ID );
	if ( '' === $title && $front ) {
		$title = _ww_plain_text( _ww_data_to_string( _ww_data_get_setting( 'seo_home_title', $lang ) ) );
	}
	if ( '' === $title ) {
		$title = _ww_plain_text( get_the_title( $post ) );
	}
	if ( '' === $description && $front ) {
		$description = _ww_plain_text( _ww_data_to_string( _ww_data_get_setting( 'seo_home_description', $lang ) ) );
	}
	if ( '' === $description ) {
		$description = _ww_seo_post_summary( $post->ID );
	}
	return array(
		'title'       => $title,
		'url'         => (string) get_permalink( $post ),
		'description' => _ww_seo_trim( $description, _ww_seo_length_limits()['description'][1] ),
	);
}

/**
 * De inleiding onder de sitenaam: seo_llms_intro, anders de beschrijving van de voorpagina uit de Site-instellingen,
 * anders de ondertitel van de taal.
 */
function _ww_llms_intro( string $lang ): string {
	$text = _ww_plain_text( _ww_data_to_string( _ww_data_get_setting( 'seo_llms_intro', $lang ) ) );
	return '' !== $text ? $text : _ww_llms_intro_fallback( $lang );
}

/**
 * De inleiding van een taal als die taal zelf geen inleiding heeft: in een extra taal eerst de inleiding van de
 * standaardtaal (een niet vertaalde instelling valt daarnaar terug), dan de homepagebeschrijving, dan de ondertitel.
 * Ook de tekst voor de placeholder van het invulveld.
 */
function _ww_llms_intro_fallback( string $lang ): string {
	$fields = '' === $lang ? array( 'seo_home_description' ) : array( 'seo_llms_intro', 'seo_home_description' );
	foreach ( $fields as $field ) {
		$text = _ww_plain_text( _ww_data_to_string( _ww_data_get_setting( $field, $lang ) ) );
		if ( '' !== $text ) {
			return $text;
		}
	}
	return _ww_plain_text( _ww_language_tagline( '' === $lang ? _ww_default_language() : $lang ) );
}

/**
 * Sorteert de pagina's van een sectie: bij pagina's de voorpagina eerst, dan menu_order en titel; bij andere soorten de
 * nieuwste eerst.
 *
 * @param list<WP_Post> $posts Berichten van één post type.
 * @return list<WP_Post>
 */
function _ww_llms_sort( array $posts, string $type, int $front ): array {
	if ( 'page' === $type ) {
		usort(
			$posts,
			static function ( WP_Post $a, WP_Post $b ) use ( $front ): int {
				$rank = ( $a->ID === $front ? 0 : 1 ) <=> ( $b->ID === $front ? 0 : 1 );
				if ( 0 === $rank ) {
					$rank = $a->menu_order <=> $b->menu_order;
				}
				return 0 !== $rank ? $rank : strnatcasecmp( $a->post_title, $b->post_title );
			}
		);
		return $posts;
	}
	usort( $posts, static fn( WP_Post $a, WP_Post $b ): int => array( $b->post_date, $b->ID ) <=> array( $a->post_date, $a->ID ) );
	return $posts;
}

/**
 * De pagina's per post type, in de volgorde van _ww_llms_post_types(). De limiet geldt voor het geheel: pagina's eerst
 * (zoveel als er passen, de voorpagina altijd erbij), daarna per volgend post type de nieuwste in wat er over is.
 * truncated is true zodra er iets is weggelaten.
 *
 * @return array{sections: array<string,list<array{title:string,url:string,description:string}>>, truncated: bool}
 */
function _ww_llms_sections( string $lang ): array {
	$remaining = _ww_llms_max_links();
	$front     = _ww_llms_front_page_id( $lang );
	$sections  = array();
	$truncated = false;
	foreach ( _ww_llms_post_types() as $type ) {
		$posts = array();
		foreach ( ( new WP_Query( _ww_llms_query_args( $type, $lang ) ) )->posts as $post ) {
			if ( $post instanceof WP_Post ) {
				$posts[] = $post;
			}
		}
		if ( count( $posts ) > $remaining ) {
			$truncated = true;
			$kept      = array_slice( $posts, 0, $remaining );
			if ( 'page' === $type && $front > 0 && $remaining > 0 && array() === array_filter( $kept, static fn( WP_Post $post ): bool => $post->ID === $front ) ) {
				$args                   = _ww_llms_query_args( 'page', $lang );
				$args['post__in']       = array( $front );
				$args['posts_per_page'] = 1;
				$found                  = ( new WP_Query( $args ) )->posts;
				if ( isset( $found[0] ) && $found[0] instanceof WP_Post ) {
					array_pop( $kept );
					$kept[] = $found[0];
				}
			}
			$posts = $kept;
		}
		if ( array() !== $posts ) {
			$remaining        -= count( $posts );
			$sections[ $type ] = array_map(
				static fn( WP_Post $post ): array => _ww_llms_entry( $post, $lang ),
				_ww_llms_sort( $posts, $type, $front )
			);
		}
	}
	return array(
		'sections'  => $sections,
		'truncated' => $truncated,
	);
}

/**
 * Tekst voor één regel Markdown: witruimte (ook regeleinden) samen tot één spatie. Als linktekst ook \, [ en ]
 * met een backslash ervoor, zodat de link op één regel blijft.
 */
function _ww_llms_text_line( string $text, bool $link = false ): string {
	$text = trim( (string) preg_replace( '/\s+/u', ' ', $text ) );
	return $link ? addcslashes( $text, '\\[]' ) : $text;
}

/**
 * Een adres voor tussen de haakjes van een Markdown-link: ( ) en witruimte als %28, %29 en %20.
 */
function _ww_llms_url( string $url ): string {
	return (string) preg_replace_callback(
		'/[()\s]/u',
		static fn( array $match ): string => '(' === $match[0] ? '%28' : ( ')' === $match[0] ? '%29' : '%20' ),
		$url
	);
}

/**
 * Het hele bestand voor een taal, als Markdown: sitenaam, inleiding en per post type een lijst met links.
 */
function _ww_llms_build( string $lang ): string {
	$blocks = array( '# ' . _ww_llms_text_line( _ww_plain_text( _ww_data_to_string( get_option( 'blogname', '' ) ) ) ) );
	$intro  = _ww_llms_text_line( _ww_llms_intro( $lang ) );
	if ( '' !== $intro ) {
		$blocks[] = '> ' . $intro;
	}
	$result  = _ww_llms_sections( $lang );
	$choices = _ww_llms_choices();
	foreach ( $result['sections'] as $type => $entries ) {
		$lines = array();
		foreach ( $entries as $entry ) {
			$line    = '- [' . _ww_llms_text_line( $entry['title'], true ) . '](' . _ww_llms_url( $entry['url'] ) . ')';
			$text    = _ww_llms_text_line( $entry['description'] );
			$lines[] = '' !== $text ? $line . ': ' . $text : $line;
		}
		$blocks[] = '## ' . _ww_llms_text_line( $choices[ $type ] ?? $type ) . "\n\n" . implode( "\n", $lines );
	}
	if ( $result['truncated'] ) {
		/* translators: %d: het aantal pagina's waartoe de lijst is ingekort */
		$blocks[] = sprintf( __( '_De lijst is ingekort tot de %d nieuwste pagina\'s._', 'webwerckt-base' ), _ww_llms_max_links() );
	}
	return implode( "\n\n", $blocks ) . "\n";
}
