<?php
/**
 * Het scherm Talen met zijpaneel: de controles per taal en de lijst met gangbare talen (beslissing 0054).
 *
 * @package webwerckt-base
 */

defined( 'ABSPATH' ) || exit;

/**
 * De controles van de taalmodule, per taal. De sleutel is een taalcode, of '' voor wat bij het Overzicht hoort
 * (een pagina die de standaardtaal verdringt). Het resultaat wordt per aanvraag bewaard.
 *
 * @param bool $reset Leegt de bewaarde lijst (voor tests).
 * @return array<string,list<array{key:string,short:string,message:string,type:string,field?:string,link?:string}>>
 */
function _ww_languages_admin_issues( bool $reset = false ): array {
	static $cache = null;
	if ( $reset ) {
		$cache = null;
	}
	if ( null !== $cache ) {
		return $cache;
	}

	$issues  = array();
	$config  = _ww_languages_config();
	$default = $config['default'];

	foreach ( _ww_languages_slug_conflict_pages() as $code => $page_id ) {
		$code = (string) $code;
		$issue = array(
			'key'     => 'slug',
			/* translators: %s: taalcode */
			'short'   => sprintf( __( 'Een pagina heeft de slug %s', 'webwerckt-base' ), $code ),
			/* translators: %s: taalcode */
			'message' => sprintf( __( 'Er is een pagina met de slug "%s". De taal gaat voor: die pagina is op dat adres niet meer bereikbaar. Geef de pagina een andere slug.', 'webwerckt-base' ), $code ),
			'type'    => 'warning',
		);
		$issue['link'] = add_query_arg(
			array(
				'post'   => $page_id,
				'action' => 'edit',
			),
			admin_url( 'post.php' )
		);
		$issues[ $code === $default ? '' : $code ][] = $issue;
	}

	foreach ( _ww_extra_language_codes() as $code ) {
		$language = _ww_language( $code );
		foreach ( _ww_language_base_conflicts( $code, _ww_language_bases( $code ) ) as $name => $reason ) {
			$issues[ $code ][] = array(
				'key'     => 'base',
				'short'   => __( 'URL-basis botst met een pagina', 'webwerckt-base' ),
				'message' => sprintf(
					/* translators: 1: naam van een post type of taxonomie, 2: naam van de taal, 3: de botsing */
					__( 'De URL-basis van %1$s in %2$s botst: %3$s Tot je een andere basis kiest, gaat de basis voor.', 'webwerckt-base' ),
					_ww_language_base_objects()[ $name ]['label'] ?? $name,
					null !== $language ? $language['name'] : $code,
					$reason
				),
				'type'    => 'warning',
				'field'   => (string) $name,
			);
		}
	}

	foreach ( $config['languages'] as $language ) {
		if ( $language['visible'] ) {
			continue;
		}
		$titles = array();
		foreach ( _ww_languages_menu_items_in( $language['code'] ) as $item_id ) {
			$item     = wp_setup_nav_menu_item( get_post( $item_id ) );
			$titles[] = isset( $item->title ) && '' !== (string) $item->title ? (string) $item->title : '#' . $item_id;
		}
		if ( array() !== $titles ) {
			$count                         = count( $titles );
			$issues[ $language['code'] ][] = array(
				'key'     => 'menu',
				'short'   => sprintf(
					/* translators: 1: aantal menu-items, 2: naam van de taal */
					_n( '%1$d menu-item wijst naar %2$s', '%1$d menu-items wijzen naar %2$s', $count, 'webwerckt-base' ),
					$count,
					$language['name']
				),
				'message' => sprintf(
					/* translators: 1: naam van de taal, 2: titels van menu-items */
					__( '%1$s is verborgen, maar deze menu-items wijzen naar inhoud in die taal: %2$s. Een bezoeker krijgt daar een 404.', 'webwerckt-base' ),
					$language['name'],
					implode( ', ', $titles )
				),
				'type'    => 'warning',
			);
		}
	}

	foreach ( _ww_languages_missing_mo() as $locale ) {
		foreach ( $config['languages'] as $language ) {
			if ( $language['locale'] !== $locale ) {
				continue;
			}
			$issues[ $language['code'] ][] = array(
				'key'     => 'mo',
				/* translators: %s: locale, zoals de_DE */
				'short'   => sprintf( __( 'Thema nog niet vertaald (%s)', 'webwerckt-base' ), $locale ),
				/* translators: %s: locale, zoals de_DE */
				'message' => sprintf( __( 'Het thema heeft nog geen vertaling voor %s. Knoppen en vaste teksten van het thema blijven daar Nederlands.', 'webwerckt-base' ), $locale ),
				'type'    => 'info',
			);
		}
	}

	$cache = $issues;
	return $cache;
}

/**
 * Het aantal controles dat aandacht vraagt, over alle talen en het Overzicht.
 */
function _ww_languages_admin_issue_count(): int {
	$count = 0;
	foreach ( _ww_languages_admin_issues() as $list ) {
		$count += count( $list );
	}
	return $count;
}

/**
 * De gangbare talen om met een klik toe te voegen. Filter: ww_language_presets.
 *
 * @return list<array{code:string,locale:string,name:string,label:string}>
 */
function _ww_languages_presets(): array {
	$presets = array(
		array(
			'code'   => 'en',
			'locale' => 'en_GB',
			'name'   => 'English',
			'label'  => __( 'Engels', 'webwerckt-base' ),
		),
		array(
			'code'   => 'en',
			'locale' => 'en_US',
			'name'   => 'English (US)',
			'label'  => __( 'Engels (VS)', 'webwerckt-base' ),
		),
		array(
			'code'   => 'de',
			'locale' => 'de_DE',
			'name'   => 'Deutsch',
			'label'  => __( 'Duits', 'webwerckt-base' ),
		),
		array(
			'code'   => 'fr',
			'locale' => 'fr_FR',
			'name'   => 'Français',
			'label'  => __( 'Frans', 'webwerckt-base' ),
		),
		array(
			'code'   => 'es',
			'locale' => 'es_ES',
			'name'   => 'Español',
			'label'  => __( 'Spaans', 'webwerckt-base' ),
		),
		array(
			'code'   => 'it',
			'locale' => 'it_IT',
			'name'   => 'Italiano',
			'label'  => __( 'Italiaans', 'webwerckt-base' ),
		),
		array(
			'code'   => 'fy',
			'locale' => 'fy',
			'name'   => 'Frysk',
			'label'  => __( 'Fries', 'webwerckt-base' ),
		),
		array(
			'code'   => 'pl',
			'locale' => 'pl_PL',
			'name'   => 'Polski',
			'label'  => __( 'Pools', 'webwerckt-base' ),
		),
		array(
			'code'   => 'da',
			'locale' => 'da_DK',
			'name'   => 'Dansk',
			'label'  => __( 'Deens', 'webwerckt-base' ),
		),
		array(
			'code'   => 'nl',
			'locale' => 'nl_NL',
			'name'   => 'Nederlands',
			'label'  => __( 'Nederlands', 'webwerckt-base' ),
		),
	);

	/**
	 * De gangbare talen op het scherm Talen.
	 *
	 * @param array<mixed> $presets Lijsten met code, locale, naam en Nederlands label.
	 */
	$filtered = apply_filters( 'ww_language_presets', $presets );

	// Een onvolledige taal uit het filter valt weg: keuzelijst, datalist en script rekenen op alle vier de velden.
	$clean = array();
	foreach ( (array) $filtered as $preset ) {
		if ( ! is_array( $preset ) ) {
			continue;
		}
		$entry = array();
		foreach ( array( 'code', 'locale', 'name', 'label' ) as $key ) {
			if ( ! isset( $preset[ $key ] ) || ! is_string( $preset[ $key ] ) || '' === trim( $preset[ $key ] ) ) {
				continue 2;
			}
			$entry[ $key ] = $preset[ $key ];
		}
		$clean[] = $entry;
	}
	return $clean;
}

/**
 * Het onderdeel van het scherm: '' voor het Overzicht, 'new' voor Taal toevoegen of de code van een extra taal. Komt
 * uit `language` (niet `lang`, dat is van Meertalig). Een onbekende code of de standaardtaal geeft het Overzicht.
 */
function _ww_languages_admin_section(): string {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen een keuze van het onderdeel, geen wijziging.
	$code = isset( $_GET['language'] ) ? sanitize_key( wp_unslash( $_GET['language'] ) ) : '';
	if ( 'new' === $code ) {
		return 'new';
	}
	return in_array( $code, _ww_extra_language_codes(), true ) ? $code : '';
}

/**
 * Stijl en script van het scherm, alleen daar. Met een vertaalplugin toont de pagina alleen een melding: dan niets,
 * want de stijl haalt de marge van #wpcontent weg voor het zijpaneel.
 *
 * @param string $hook Hook van het scherm.
 */
function _ww_languages_admin_assets( string $hook ): void {
	if ( 'toplevel_page_' . WW_LANGUAGES_PAGE !== $hook || _ww_languages_plugin_active() ) {
		return;
	}
	wp_enqueue_style( 'ww-languages-admin', _ww_asset_url( 'css/languages-admin.css' ), array(), WW_BASE_VERSION );
	wp_enqueue_script( 'ww-languages-admin', _ww_asset_url( 'js/languages-admin.js' ), array(), WW_BASE_VERSION, array( 'in_footer' => true ) );
	$data = array(
		'texts'   => _ww_languages_script_texts(),
		'presets' => _ww_languages_presets(),
		'codes'   => array_values( _ww_language_codes() ),
	);
	wp_add_inline_script( 'ww-languages-admin', 'window.wwLanguages = ' . wp_json_encode( $data ) . ';', 'before' );
}

/**
 * De teksten van het script, vertaald in PHP: het thema maakt geen vertaal-JSON voor scripts. Het script vult %s en
 * %1$s zelf in.
 *
 * @return array<string,string>
 */
function _ww_languages_script_texts(): array {
	return array(
		'quickEdit'    => __( 'Snel bewerken', 'webwerckt-base' ),
		'update'       => __( 'Bijwerken', 'webwerckt-base' ),
		'cancel'       => __( 'Annuleren', 'webwerckt-base' ),
		'keep'         => __( 'Toch houden', 'webwerckt-base' ),
		'removing'     => __( 'Wordt verwijderd', 'webwerckt-base' ),
		'unsaved'      => __( 'Niet-opgeslagen wijzigingen in de talen', 'webwerckt-base' ),
		'unsavedBox'   => __( 'Nog niet opgeslagen', 'webwerckt-base' ),
		'undo'         => __( 'Ongedaan maken', 'webwerckt-base' ),
		'save'         => __( 'Talen opslaan', 'webwerckt-base' ),
		'leaveTitle'        => __( 'Wijzigingen opslaan?', 'webwerckt-base' ),
		// Pagina van een taal: twee formulieren.
		'leaveText'         => __( 'Je hebt iets veranderd in de talen. Elk vak slaat apart op: Opslaan en verder bewaart alleen het eerste gewijzigde vak. Zonder opslaan ben je die wijzigingen kwijt.', 'webwerckt-base' ),
		// Overzicht en Taal toevoegen: één formulier.
		'leaveTextOverview' => __( 'Je hebt iets veranderd in de talen. Zonder opslaan ben je die wijzigingen kwijt.', 'webwerckt-base' ),
		'stay'              => __( 'Blijven', 'webwerckt-base' ),
		'discard'           => __( 'Niet opslaan', 'webwerckt-base' ),
		'saveGo'            => __( 'Opslaan en verder', 'webwerckt-base' ),
		'copied'            => __( 'Gekopieerd', 'webwerckt-base' ),
		'copy'              => __( 'Kopiëren', 'webwerckt-base' ),
		/* translators: 1: taalcode, 2: naam van de taal die die code al heeft */
		'codeTaken'         => __( 'De code %1$s is al in gebruik door %2$s.', 'webwerckt-base' ),
		'fillAll'           => __( 'Kies een taal, of vul naam, code en locale in.', 'webwerckt-base' ),
		'required'          => __( 'Vul dit veld in.', 'webwerckt-base' ),
		'newBadge'          => __( 'Nieuw', 'webwerckt-base' ),
		'startsHidden'      => __( 'Begint verborgen', 'webwerckt-base' ),
		/* translators: %s: taalcode */
		'address'           => __( 'Komt in het adres: /%s/', 'webwerckt-base' ),
		/* translators: %s: naam van de taal */
		'up'                => __( '%s omhoog', 'webwerckt-base' ),
		/* translators: %s: naam van de taal */
		'down'              => __( '%s omlaag', 'webwerckt-base' ),
	);
}

/**
 * Het aantal berichten in een taal, over alle vertaalbare post types.
 *
 * @param string $code Taalcode.
 */
function _ww_languages_screen_total( string $code ): int {
	return (int) array_sum( _ww_languages_screen_counts( $code ) );
}

/**
 * _ww_languages_post_counts(), één keer per taal per weergave: paneel, kiezer en rijen vragen het allemaal. Het scherm
 * leegt de lijst aan het begin van elke weergave. Niet voor de controle bij opslaan: die telt altijd opnieuw.
 *
 * @param string $code  Taalcode.
 * @param bool   $reset Leegt de lijst.
 * @return array<string,int>
 */
function _ww_languages_screen_counts( string $code, bool $reset = false ): array {
	static $counts = array();
	if ( $reset ) {
		$counts = array();
	}
	if ( '' === $code ) {
		return array();
	}
	if ( ! isset( $counts[ $code ] ) ) {
		$counts[ $code ] = taxonomy_exists( 'ww_language' ) ? _ww_languages_post_counts( $code ) : array();
	}
	return $counts[ $code ];
}

/**
 * Het blokje met de taalcode.
 *
 * @param string $code Taalcode.
 */
function _ww_languages_screen_code_badge( string $code ): string {
	return '<span class="ww-languages-code" aria-hidden="true">' . esc_html( $code ) . '</span>';
}

/**
 * De onderdelen van het scherm, voor paneel en kiezer: Overzicht en de extra talen met hun status.
 *
 * @param string $section Actief onderdeel.
 * @param string $variant panel of menu.
 * @return array{overview:string,languages:string} Geëscapete lijstitems.
 */
function _ww_languages_screen_items( string $section, string $variant ): array {
	$issues   = _ww_languages_admin_issues();
	$overview = '<li><a href="' . esc_url( _ww_languages_admin_url() ) . '"' . ( '' === $section ? ' aria-current="page"' : '' ) . '>'
		. ( 'panel' === $variant ? '<span class="dashicons dashicons-list-view" aria-hidden="true"></span>' : '' )
		. '<span class="ww-languages-nav__label">' . esc_html__( 'Overzicht', 'webwerckt-base' ) . '</span></a></li>';

	$items = '';
	foreach ( _ww_languages_config()['languages'] as $language ) {
		$code = $language['code'];
		if ( ! in_array( $code, _ww_extra_language_codes(), true ) ) {
			continue;
		}
		if ( $language['visible'] ) {
			$total  = _ww_languages_screen_total( $code );
			$status = sprintf(
				/* translators: %d: aantal stuks inhoud */
				_n( '%d stuk inhoud', '%d stuks inhoud', $total, 'webwerckt-base' ),
				$total
			);
		} else {
			$status = __( 'Verborgen', 'webwerckt-base' );
		}
		$dot    = isset( $issues[ $code ] )
			? '<span class="ww-languages-dot" aria-hidden="true"></span><span class="screen-reader-text">' . esc_html__( ', aandacht nodig', 'webwerckt-base' ) . '</span>'
			: '';
		$hidden = $language['visible'] ? '' : '<span class="dashicons dashicons-hidden ww-languages-hidden" aria-hidden="true"></span>';
		$items .= '<li><a href="' . esc_url( _ww_languages_admin_url( array( 'language' => $code ) ) ) . '"' . ( $code === $section ? ' aria-current="page"' : '' ) . '>'
			. _ww_languages_screen_code_badge( $code )
			. '<span class="ww-languages-nav__label">' . esc_html( $language['name'] ) . '<small>' . esc_html( $status ) . '</small></span>'
			. $dot . $hidden . '</a></li>';
	}
	return array(
		'overview'  => $overview,
		'languages' => $items,
	);
}

/**
 * Het zijpaneel: kop, Overzicht, de extra talen, Taal toevoegen, het kaartje Aandacht nodig en de voet.
 *
 * @param string $section Actief onderdeel.
 * @return string Geëscapete HTML.
 */
function _ww_languages_screen_panel( string $section ): string {
	$config  = _ww_languages_config();
	$default = _ww_language( $config['default'] );
	$count   = count( $config['languages'] );
	$items   = _ww_languages_screen_items( $section, 'panel' );

	$html  = '<nav class="ww-languages-panel" aria-label="' . esc_attr__( 'Onderdelen van Talen', 'webwerckt-base' ) . '">';
	$html .= '<p class="ww-languages-panel__title">' . esc_html__( 'Talen', 'webwerckt-base' ) . '</p>';
	$html .= '<p class="ww-languages-panel__sub">' . esc_html(
		sprintf(
			/* translators: 1: aantal talen, 2: naam van de standaardtaal */
			_n( '%1$d taal · standaard %2$s', '%1$d talen · standaard %2$s', $count, 'webwerckt-base' ),
			$count,
			null !== $default ? $default['name'] : $config['default']
		)
	) . '</p>';
	$html .= '<ul class="ww-languages-panel__nav">' . $items['overview'] . '</ul>';
	if ( '' !== $items['languages'] ) {
		$html .= '<hr class="ww-languages-panel__sep"><p class="ww-languages-panel__group">' . esc_html__( 'Per taal', 'webwerckt-base' ) . '</p>'
			. '<ul class="ww-languages-panel__nav">' . $items['languages'] . '</ul>';
	}
	$html .= '<ul class="ww-languages-panel__nav ww-languages-panel__add"><li><a href="' . esc_url( _ww_languages_admin_url( array( 'language' => 'new' ) ) ) . '"' . ( 'new' === $section ? ' aria-current="page"' : '' ) . '>'
		. '<span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span><span class="ww-languages-nav__label">' . esc_html__( 'Taal toevoegen', 'webwerckt-base' ) . '</span></a></li></ul>';
	$html .= _ww_languages_screen_card();
	$html .= '<p class="ww-languages-panel__foot"><span class="dashicons dashicons-info-outline" aria-hidden="true"></span><span>'
		. esc_html__( 'Vertalingen koppel je per pagina in de box Taal in de editor.', 'webwerckt-base' )
		. ' <a href="' . esc_url( admin_url( 'edit.php?post_type=page' ) ) . '">' . esc_html__( "Naar Pagina's", 'webwerckt-base' ) . '</a></span></p>';
	return $html . '</nav>';
}

/**
 * De kiezer Onderdeel voor mobiel, een uitklapper met dezelfde onderdelen als het paneel.
 *
 * @param string $section Actief onderdeel.
 * @return string Geëscapete HTML.
 */
function _ww_languages_screen_picker( string $section ): string {
	$items = _ww_languages_screen_items( $section, 'menu' );
	$label = __( 'Overzicht', 'webwerckt-base' );
	if ( 'new' === $section ) {
		$label = __( 'Taal toevoegen', 'webwerckt-base' );
	} elseif ( '' !== $section ) {
		$language = _ww_language( $section );
		$label    = null !== $language ? $language['name'] : $section;
	}
	$sep = '' !== $items['languages'] ? '<li class="ww-languages-menu__sep" aria-hidden="true"></li>' : '';
	return '<details class="ww-languages-menu"><summary><span>' . esc_html__( 'Onderdeel', 'webwerckt-base' ) . '</span> <b>' . esc_html( $label ) . '</b></summary>'
		. '<ul>' . $items['overview'] . $sep . $items['languages'] . '</ul></details>';
}

/**
 * Het kaartje Aandacht nodig: per controle een regel met een link naar het onderdeel, of Alles in orde.
 *
 * @return string Geëscapete HTML.
 */
function _ww_languages_screen_card(): string {
	$issues = _ww_languages_admin_issues();
	if ( array() === $issues ) {
		return '<div class="ww-languages-panel__card"><p><span class="dashicons dashicons-yes-alt ww-languages-ok" aria-hidden="true"></span><strong>'
			. esc_html__( 'Alles in orde', 'webwerckt-base' ) . '</strong></p></div>';
	}

	$items = '';
	foreach ( $issues as $code => $list ) {
		$code     = (string) $code;
		$language = _ww_language( '' === $code ? _ww_languages_config()['default'] : $code );
		$name     = null !== $language ? $language['name'] : $code;
		$url      = _ww_languages_admin_url( '' === $code ? array() : array( 'language' => $code ) );
		foreach ( $list as $issue ) {
			$items .= '<li><a href="' . esc_url( $url ) . '">' . esc_html( $name . ': ' . $issue['short'] ) . '</a></li>';
		}
	}
	return '<div class="ww-languages-panel__card"><p><span class="ww-languages-dot" aria-hidden="true"></span><strong>'
		. esc_html(
			sprintf(
				/* translators: %d: aantal waarschuwingen */
				__( 'Aandacht nodig (%d)', 'webwerckt-base' ),
				_ww_languages_admin_issue_count()
			)
		) . '</strong></p><ul>' . $items . '</ul></div>';
}

/**
 * Het scherm: zijpaneel, kiezer, meldingen en het onderdeel.
 */
function _ww_languages_screen_render(): void {
	_ww_languages_screen_counts( '', true );
	$section = _ww_languages_admin_section();

	echo '<div class="wrap ww-languages"><div class="ww-languages-layout">';
	echo _ww_languages_screen_panel( $section ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- geëscapet opgebouwd.
	echo '<div class="ww-languages-main">';
	// Op mobiel valt het paneel weg: het Overzicht toont het kaartje Aandacht nodig dan onder de kiezer.
	$card = '' === $section ? _ww_languages_screen_card() : '';
	echo '<div class="ww-languages-pickers">' . _ww_languages_screen_picker( $section ) . $card . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- idem.
	settings_errors( 'ww_languages' );
	if ( 'new' === $section ) {
		_ww_languages_screen_add();
	} elseif ( '' !== $section ) {
		_ww_languages_screen_language( $section );
	} else {
		_ww_languages_screen_overview();
	}
	echo '</div></div></div>';
}

/**
 * De rijen van het formulier Talen: na een geweigerde opslag de invoer, met de doorgestreepte, nieuwe en verplaatste
 * rijen in de volgorde van de POST (_ww_languages_admin_form()), anders de configuratie.
 *
 * @return array{default:string,rows:list<array{code:string,locale:string,name:string,visible:bool,remove:bool,new:bool}>}
 */
function _ww_languages_screen_rows(): array {
	$form   = _ww_languages_admin_form();
	$config = _ww_languages_config();
	$source = null !== $form && isset( $form['languages'] ) && is_array( $form['languages'] ) ? $form['languages'] : $config['languages'];

	$rows = array();
	foreach ( $source as $row ) {
		$row    = is_array( $row ) ? $row : array();
		$rows[] = array(
			'code'    => _ww_data_to_string( $row['code'] ?? '' ),
			'locale'  => _ww_data_to_string( $row['locale'] ?? '' ),
			'name'    => _ww_data_to_string( $row['name'] ?? '' ),
			'visible' => ! empty( $row['visible'] ),
			'remove'  => ! empty( $row['remove'] ),
			'new'     => ! empty( $row['new'] ),
		);
	}
	return array(
		'default' => null !== $form ? _ww_data_to_string( $form['default'] ?? '' ) : $config['default'],
		'rows'    => $rows,
	);
}

/**
 * Het begin van het formulier save: nonce en actie. Het Overzicht en Taal toevoegen delen het.
 *
 * @param array<string,string> $args  Queryvariabelen van het adres waar het formulier heen gaat.
 * @param bool                 $dirty Het formulier toont niet-opgeslagen invoer (na een geweigerde opslag): het script
 *                                    begint dan met wijzigingen.
 */
function _ww_languages_screen_form_open( array $args = array(), bool $dirty = false ): void {
	echo '<form method="post" class="ww-languages-form" action="' . esc_url( _ww_languages_admin_url( $args ) ) . '"' . ( $dirty ? ' data-ww-dirty="1"' : '' ) . '>';
	wp_nonce_field( 'ww_languages_save' );
	echo '<input type="hidden" name="ww_languages_action" value="save">';
}

/**
 * De lijst met gangbare locales voor het veld Locale.
 *
 * @return string Geëscapete HTML.
 */
function _ww_languages_screen_datalist(): string {
	$html = '<datalist id="ww-languages-locales">';
	$seen = array();
	foreach ( _ww_languages_presets() as $preset ) {
		$locale = _ww_data_to_string( $preset['locale'] );
		if ( '' === $locale || isset( $seen[ $locale ] ) ) {
			continue;
		}
		$seen[ $locale ] = true;
		$html           .= '<option value="' . esc_attr( $locale ) . '">' . esc_html( _ww_data_to_string( $preset['label'] ) . ' · ' . _ww_data_to_string( $preset['name'] ) ) . '</option>';
	}
	return $html . '</datalist>';
}

/**
 * Eén gelabeld veld van Snel bewerken of Taal toevoegen.
 *
 * @param string $id    Id van het veld.
 * @param string $label Zichtbaar label.
 * @param string $input Het geëscapete veld.
 * @param string $after Geëscapete HTML onder het veld.
 * @return string Geëscapete HTML.
 */
function _ww_languages_screen_field( string $id, string $label, string $input, string $after = '' ): string {
	return '<div class="ww-languages-field"><label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label>' . $input . $after . '</div>';
}

/**
 * De drie velden van een taal: naam, code en locale, in die volgorde.
 *
 * @param string              $key   Index van de rij in ww_rows, of new.
 * @param array<string,mixed> $row   code, locale, name.
 * @param string              $note  Geëscapete toelichting onder Code.
 * @param bool                $named Met de namen ww_rows[…]; zonder voor het venster Taal toevoegen, dat de rij new vult.
 * @return string Geëscapete HTML.
 */
function _ww_languages_screen_fields( string $key, array $row, string $note = '', bool $named = true ): string {
	$base    = 'ww-languages-' . $key;
	$prefix  = 'ww_rows[' . $key . ']';
	$note_id = $base . '-code-note';
	$name    = static fn( string $field ): string => $named ? ' name="' . esc_attr( $prefix . '[' . $field . ']' ) . '"' : '';

	$html  = _ww_languages_screen_field(
		$base . '-name',
		__( 'Naam in de taalkiezer', 'webwerckt-base' ),
		'<input type="text"' . $name( 'name' ) . ' value="' . esc_attr( _ww_data_to_string( $row['name'] ?? '' ) ) . '" maxlength="50" id="' . esc_attr( $base . '-name' ) . '" placeholder="English">'
	);
	$html .= _ww_languages_screen_field(
		$base . '-code',
		__( 'Code', 'webwerckt-base' ),
		'<input type="text"' . $name( 'code' ) . ' value="' . esc_attr( _ww_data_to_string( $row['code'] ?? '' ) ) . '" id="' . esc_attr( $base . '-code' ) . '" class="ww-languages-code-field" placeholder="en"' . ( '' !== $note ? ' aria-describedby="' . esc_attr( $note_id ) . '"' : '' ) . '>',
		'' !== $note ? '<p class="description" id="' . esc_attr( $note_id ) . '">' . $note . '</p>' : ''
	);
	$html .= _ww_languages_screen_field(
		$base . '-locale',
		__( 'Locale', 'webwerckt-base' ),
		'<input type="text"' . $name( 'locale' ) . ' value="' . esc_attr( _ww_data_to_string( $row['locale'] ?? '' ) ) . '" list="ww-languages-locales" id="' . esc_attr( $base . '-locale' ) . '" placeholder="en_GB">'
	);
	return $html;
}

/**
 * Een rij van de lijst Talen op de site: Taal (met badges, rij-acties en het blok Snel bewerken), Adres, Inhoud,
 * Zichtbaar en Volgorde. Alles werkt zonder script: de velden van Snel bewerken staan dan open, Verwijderen en de
 * pijltjes zijn knoppen van het formulier.
 *
 * @param int|string                                                                         $i       Index in ww_rows, of new voor het sjabloon van het script.
 * @param array{code:string,locale:string,name:string,visible:bool,remove:bool,new:bool}    $row     De rij.
 * @param int                                                                                $count   Aantal rijen.
 * @param string                                                                             $default Code van de standaardtaal.
 * @return string Geëscapete HTML.
 */
function _ww_languages_screen_row( int|string $i, array $row, int $count, string $default ): string {
	$code       = $row['code'];
	$name       = '' !== $row['name'] ? $row['name'] : $code;
	$is_default = ! $row['new'] && '' !== $code && $code === $default;
	$is_extra   = ! $row['new'] && in_array( $code, _ww_extra_language_codes(), true );
	$counts     = $row['new'] ? array() : _ww_languages_screen_counts( $code );
	$total      = (int) array_sum( $counts );
	$issues     = $row['new'] ? array() : ( _ww_languages_admin_issues()[ $code ] ?? array() );
	$prefix     = 'ww_rows[' . $i . ']';
	$qe_id      = 'ww-languages-qe-' . $i;

	$classes = 'ww-languages-row' . ( $row['remove'] ? ' is-removed' : '' ) . ( $row['new'] ? ' is-new' : '' );
	$html    = '<tr class="' . esc_attr( $classes ) . '" data-index="' . esc_attr( (string) $i ) . '" data-count="' . esc_attr( (string) $total ) . '" data-default="' . ( $is_default ? '1' : '0' ) . '">';

	// Taal.
	if ( $is_extra ) {
		$title = '<a href="' . esc_url( _ww_languages_admin_url( array( 'language' => $code ) ) ) . '">' . esc_html( $name ) . '</a>';
	} elseif ( $is_default ) {
		$title = '<a href="#' . esc_attr( $qe_id ) . '">' . esc_html( $name ) . '</a>';
	} else {
		$title = esc_html( $name );
	}
	$badges = '';
	if ( $is_default ) {
		$badges .= '<span class="ww-languages-badge">' . esc_html__( 'Standaard', 'webwerckt-base' ) . '</span>';
	}
	if ( $row['new'] ) {
		$badges .= '<span class="ww-languages-badge is-new">' . esc_html__( 'Nieuw', 'webwerckt-base' ) . '</span>';
	}
	if ( $row['remove'] ) {
		$badges .= '<span class="ww-languages-badge is-removed">' . esc_html__( 'Wordt verwijderd', 'webwerckt-base' ) . '</span>';
	}
	if ( array() !== $issues ) {
		$shorts  = implode( '; ', array_column( $issues, 'short' ) );
		$badges .= '<span class="ww-languages-badge is-warning" title="' . esc_attr( $shorts ) . '">' . esc_html(
			sprintf(
				/* translators: %d: aantal waarschuwingen */
				__( '%d × aandacht', 'webwerckt-base' ),
				count( $issues )
			)
		) . '<span class="screen-reader-text">: ' . esc_html( $shorts ) . '</span></span>';
	}

	$actions   = array();
	$actions[] = '<button type="button" class="button-link ww-languages-edit" aria-expanded="false" aria-controls="' . esc_attr( $qe_id ) . '" hidden>' . esc_html__( 'Snel bewerken', 'webwerckt-base' ) . '</button>';
	if ( $is_extra ) {
		$actions[] = '<a href="' . esc_url( _ww_languages_admin_url( array( 'language' => $code ) ) ) . '">' . esc_html__( 'Ondertitel en URL-basis', 'webwerckt-base' ) . '</a>';
	}
	if ( $row['remove'] ) {
		// Na een geweigerde opslag: de rij blijft doorgestreept; het vinkje uit is Toch houden.
		$actions[] = '<label class="ww-languages-remove-check"><input type="checkbox" name="' . esc_attr( $prefix . '[remove]' ) . '" value="1" checked> <span class="ww-languages-remove-label">' . esc_html__( 'Verwijderen', 'webwerckt-base' ) . '</span></label>';
	} elseif ( ! $is_default && 0 === $total ) {
		$actions[] = '<button type="submit" name="ww_remove" value="' . esc_attr( (string) $i ) . '" class="button-link ww-languages-remove">' . esc_html__( 'Verwijderen', 'webwerckt-base' ) . '<span class="screen-reader-text"> ' . esc_html( $name ) . '</span></button>';
	} elseif ( ! $is_default ) {
		$actions[] = '<span class="ww-languages-cannot" title="' . esc_attr(
			sprintf(
				/* translators: 1: naam van de taal, 2: aantal stuks inhoud */
				__( '%1$s heeft nog inhoud (%2$d stuks, ook concepten en prullenbak). Verberg de taal om hem uit te zetten.', 'webwerckt-base' ),
				$name,
				$total
			)
		) . '">' . esc_html__( 'Kan niet weg', 'webwerckt-base' ) . '</span>';
	}

	$note = '';
	if ( $total > 0 ) {
		$note = esc_html(
			sprintf(
				/* translators: %d: aantal stuks inhoud */
				__( 'Let op: een andere code is een ander adres voor %d stuks inhoud.', 'webwerckt-base' ),
				$total
			)
		);
	}

	$html .= '<td class="ww-languages-col-language">'
		. '<div class="ww-languages-title">' . _ww_languages_screen_code_badge( $code ) . '<strong>' . $title . '</strong>' . $badges . '</div>'
		. '<div class="ww-languages-locale">' . esc_html( $row['locale'] ) . '</div>'
		. '<div class="row-actions">' . implode( ' <span class="ww-languages-sep" aria-hidden="true">|</span> ', $actions ) . '</div>'
		. '<div class="ww-languages-qe" id="' . esc_attr( $qe_id ) . '">'
		. _ww_languages_screen_fields( (string) $i, $row, $note )
		. '<div class="ww-languages-qe__actions" hidden><button type="button" class="button ww-languages-qe-cancel">' . esc_html__( 'Annuleren', 'webwerckt-base' ) . '</button> '
		. '<button type="button" class="button button-primary ww-languages-qe-apply">' . esc_html__( 'Bijwerken', 'webwerckt-base' ) . '</button></div>'
		. '</div>'
		. '<input type="hidden" name="' . esc_attr( $prefix . '[order]' ) . '" value="' . esc_attr( (string) ( is_int( $i ) ? $i + 1 : $count ) ) . '">'
		. '</td>';

	// Adres.
	$html .= '<td class="ww-languages-col-address"><code>' . esc_html( $is_default ? '/' : '/' . $code . '/' ) . '</code></td>';

	// Inhoud.
	$links = array();
	foreach ( $counts as $type => $number ) {
		$object  = get_post_type_object( $type );
		$links[] = '<a href="' . esc_url(
			add_query_arg(
				array(
					'post_type' => $type,
					'ww_lang'   => $code,
				),
				admin_url( 'edit.php' )
			)
		) . '">' . esc_html( ( $object ? $object->labels->name : $type ) . ' (' . $number . ')' ) . '</a>';
	}
	$html .= '<td class="ww-languages-col-content"><span class="ww-languages-label">' . esc_html__( 'Inhoud:', 'webwerckt-base' ) . '</span> '
		. ( array() !== $links ? implode( '<br>', $links ) : '<span class="ww-languages-muted">' . esc_html__( 'Nog geen inhoud', 'webwerckt-base' ) . '</span>' ) . '</td>';

	// Zichtbaar.
	if ( $is_default ) {
		$html .= '<td class="ww-languages-col-visible"><input type="hidden" name="' . esc_attr( $prefix . '[visible]' ) . '" value="1">'
			. esc_html__( 'Altijd', 'webwerckt-base' ) . '<small>' . esc_html__( 'Standaardtaal', 'webwerckt-base' ) . '</small></td>';
	} elseif ( $row['new'] ) {
		// Een nieuwe taal begint verborgen: de rij new van het venster, of een nieuwe rij na een geweigerde opslag.
		$html .= '<td class="ww-languages-col-visible">' . esc_html__( 'Begint verborgen', 'webwerckt-base' )
			. '<small>' . esc_html__( 'Verborgen, alleen voor redacteuren', 'webwerckt-base' ) . '</small></td>';
	} else {
		$html .= '<td class="ww-languages-col-visible"><label><input type="checkbox" name="' . esc_attr( $prefix . '[visible]' ) . '" value="1"' . ( $row['visible'] ? ' checked' : '' ) . '> '
			. esc_html__( 'Zichtbaar voor bezoekers', 'webwerckt-base' ) . '</label>'
			. '<small>' . esc_html( $row['visible'] ? __( 'In de taalkiezer en zoekmachines', 'webwerckt-base' ) : __( 'Verborgen, alleen voor redacteuren', 'webwerckt-base' ) ) . '</small></td>';
	}

	// Volgorde.
	$html .= '<td class="ww-languages-col-order">'
		. '<button type="submit" name="ww_move" value="' . esc_attr( $i . ':-1' ) . '" class="button ww-languages-move" aria-label="' . esc_attr(
			/* translators: %s: naam van de taal */
			sprintf( __( '%s omhoog', 'webwerckt-base' ), $name )
		) . '"' . ( 0 === $i ? ' disabled' : '' ) . '><span class="dashicons dashicons-arrow-up-alt2" aria-hidden="true"></span></button>'
		. '<button type="submit" name="ww_move" value="' . esc_attr( $i . ':1' ) . '" class="button ww-languages-move" aria-label="' . esc_attr(
			/* translators: %s: naam van de taal */
			sprintf( __( '%s omlaag', 'webwerckt-base' ), $name )
		) . '"' . ( $count - 1 === $i ? ' disabled' : '' ) . '><span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span></button>'
		. '</td>';

	return $html . '</tr>';
}

/**
 * Het Overzicht: de kop met Taal toevoegen, een slug-botsing van de standaardtaal, en één formulier save met de lijst
 * Talen op de site, het vak Standaardtaal en Talen opslaan.
 */
function _ww_languages_screen_overview(): void {
	$data    = _ww_languages_screen_rows();
	$rows    = $data['rows'];
	$default = $data['default'];
	$count   = count( $rows );
	$locked  = _ww_languages_has_tagged_posts();
	$add_url = _ww_languages_admin_url( array( 'language' => 'new' ) );

	echo '<h1 class="wp-heading-inline">' . esc_html__( 'Talen', 'webwerckt-base' ) . '</h1> ';
	echo '<a href="' . esc_url( $add_url ) . '" class="page-title-action ww-languages-add">' . esc_html__( 'Taal toevoegen', 'webwerckt-base' ) . '</a>';
	echo '<hr class="wp-header-end">';

	foreach ( _ww_languages_admin_issues()[''] ?? array() as $issue ) {
		_ww_languages_admin_notice( 'warning', $issue['message'] );
	}

	echo '<p class="ww-languages-intro">' . esc_html__( 'De standaardtaal staat op de adressen zonder voorvoegsel; elke extra taal krijgt zijn code ervoor (/en/). Verbergen is de manier om een taal uit te zetten.', 'webwerckt-base' ) . '</p>';

	_ww_languages_screen_form_open( array(), null !== _ww_languages_admin_form() );
	// Enter in een veld verstuurt het formulier met de eerste knop: dit is gewoon opslaan, niet een pijltje of Verwijderen.
	echo '<button type="submit" class="ww-languages-default-submit" tabindex="-1">' . esc_html__( 'Talen opslaan', 'webwerckt-base' ) . '</button>';
	// Opslaan en verder (het venster bij wisselen) zet hier het gekozen onderdeel in.
	echo '<input type="hidden" name="ww_next" value="">';
	if ( $locked ) {
		echo '<input type="hidden" name="ww_default" value="' . esc_attr( _ww_languages_config()['default'] ) . '">';
	}

	echo '<div class="ww-languages-box">';
	echo '<div class="ww-languages-box__head"><h2>' . esc_html__( 'Talen op de site', 'webwerckt-base' ) . '</h2><span>' . esc_html__( 'Volgorde is de volgorde in de taalkiezer', 'webwerckt-base' ) . '</span></div>';
	echo '<table class="wp-list-table widefat striped ww-languages-list"><thead><tr>';
	echo '<th scope="col" class="ww-languages-col-language">' . esc_html__( 'Taal', 'webwerckt-base' ) . '</th>';
	echo '<th scope="col" class="ww-languages-col-address">' . esc_html__( 'Adres', 'webwerckt-base' ) . '</th>';
	echo '<th scope="col" class="ww-languages-col-content">' . esc_html__( 'Inhoud', 'webwerckt-base' ) . '</th>';
	echo '<th scope="col" class="ww-languages-col-visible">' . esc_html__( 'Zichtbaar', 'webwerckt-base' ) . '</th>';
	echo '<th scope="col" class="ww-languages-col-order">' . esc_html__( 'Volgorde', 'webwerckt-base' ) . '</th>';
	echo '</tr></thead><tbody>';
	foreach ( $rows as $i => $row ) {
		echo _ww_languages_screen_row( $i, $row, $count, $default ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- geëscapet opgebouwd.
	}
	echo '</tbody></table>';
	// De rij die het venster Taal toevoegen invult. Inhoud van een template doet niet mee in het formulier.
	$template_row = array(
		'code'    => '',
		'locale'  => '',
		'name'    => '',
		'visible' => false,
		'remove'  => false,
		'new'     => true,
	);
	echo '<template id="ww-languages-row-template">' . _ww_languages_screen_row( 'new', $template_row, $count + 1, $default ) . '</template>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- geëscapet opgebouwd.
	echo '<p class="description ww-languages-foot">' . esc_html__( 'Inhoud telt alle vertaalbare soorten in elke status, ook concepten en prullenbak.', 'webwerckt-base' ) . '</p>';
	if ( $count <= 1 ) {
		echo '<div class="ww-languages-empty"><span class="dashicons dashicons-translation" aria-hidden="true"></span>';
		echo '<p><strong>' . esc_html__( 'De site heeft nog één taal', 'webwerckt-base' ) . '</strong></p>';
		echo '<p>' . esc_html__( 'Een nieuwe taal begint verborgen: alleen redacteuren zien hem, zodat je hem eerst kunt vullen.', 'webwerckt-base' ) . '</p>';
		echo '<p><a href="' . esc_url( $add_url ) . '" class="button ww-languages-add">' . esc_html__( 'Taal toevoegen', 'webwerckt-base' ) . '</a></p></div>';
	}
	echo '</div>';

	echo '<div class="ww-languages-box">';
	echo '<div class="ww-languages-box__head"><h2>' . esc_html__( 'Standaardtaal', 'webwerckt-base' ) . '</h2></div>';
	echo '<table class="form-table" role="presentation"><tr><th scope="row"><label for="ww-languages-default">' . esc_html__( 'Standaardtaal', 'webwerckt-base' ) . '</label></th><td>';
	echo '<select name="ww_default" id="ww-languages-default"' . ( $locked ? ' disabled' : '' ) . '>';
	foreach ( $rows as $row ) {
		if ( $row['new'] || '' === $row['code'] ) {
			continue;
		}
		echo '<option value="' . esc_attr( $row['code'] ) . '"' . selected( $row['code'], $locked ? _ww_languages_config()['default'] : $default, false ) . '>' . esc_html( '' !== $row['name'] ? $row['name'] : $row['code'] ) . '</option>';
	}
	echo '</select>';
	if ( $locked ) {
		echo '<p class="ww-languages-locked"><span class="dashicons dashicons-lock" aria-hidden="true"></span><span>' . esc_html(
			sprintf(
				/* translators: %s: WP-CLI-commando */
				__( 'Er is al inhoud met een taal, dus de standaardtaal ligt vast. Wisselen kan alleen met WP-CLI: %s. Dat geeft de inhoud zonder taal eerst de oude standaardtaal.', 'webwerckt-base' ),
				'wp ww languages set-default <code>'
			)
		) . '</span></p>';
		echo '<p class="ww-languages-cli"><code>wp ww languages set-default &lt;code&gt;</code> <button type="button" class="button button-small ww-languages-copy" data-copy="wp ww languages set-default &lt;code&gt;" hidden>' . esc_html__( 'Kopiëren', 'webwerckt-base' ) . '</button></p>';
	} else {
		echo '<p class="description">' . esc_html__( 'Staat op de adressen zonder voorvoegsel. Kies hem voordat je inhoud een taal geeft: daarna ligt hij vast.', 'webwerckt-base' ) . '</p>';
	}
	echo '</td></tr></table></div>';

	echo _ww_languages_screen_datalist(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- geëscapet opgebouwd.
	echo _ww_languages_screen_add_template( $rows ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- geëscapet opgebouwd.
	submit_button( __( 'Talen opslaan', 'webwerckt-base' ) );
	echo '</form>';
}

/**
 * De keuzes van de keuzelijst Taal: de gangbare talen zonder de locales die er al zijn. Elke keuze draagt code, locale
 * en naam als data-attributen; het script vult daarmee de velden.
 *
 * @param list<array{code:string,locale:string,name:string,visible:bool,remove:bool,new:bool}> $rows De rijen van het formulier.
 * @return string Geëscapete HTML.
 */
function _ww_languages_screen_preset_options( array $rows ): string {
	$taken = array();
	foreach ( $rows as $row ) {
		if ( ! $row['new'] ) {
			$taken[] = $row['locale'];
		}
	}
	$options = '<option value="">' . esc_html__( '— Kies een taal —', 'webwerckt-base' ) . '</option>';
	foreach ( _ww_languages_presets() as $preset ) {
		$locale = _ww_data_to_string( $preset['locale'] );
		if ( '' === $locale || in_array( $locale, $taken, true ) ) {
			continue;
		}
		$options .= '<option value="' . esc_attr( $locale ) . '" data-code="' . esc_attr( _ww_data_to_string( $preset['code'] ) ) . '" data-locale="' . esc_attr( $locale ) . '" data-name="' . esc_attr( _ww_data_to_string( $preset['name'] ) ) . '">'
			. esc_html( _ww_data_to_string( $preset['label'] ) . ' · ' . _ww_data_to_string( $preset['name'] ) ) . '</option>';
	}
	return $options . '<option value="other">' . esc_html__( 'Andere taal…', 'webwerckt-base' ) . '</option>';
}

/**
 * Het venster Taal toevoegen voor het script: de keuzelijst Taal, een uitklapper met naam, code en locale (zonder
 * namen: het script zet de waarden in de rij new) en de uitleg. Zonder script blijft het een template.
 *
 * @param list<array{code:string,locale:string,name:string,visible:bool,remove:bool,new:bool}> $rows De rijen van het formulier.
 * @return string Geëscapete HTML.
 */
function _ww_languages_screen_add_template( array $rows ): string {
	/* translators: %s: taalcode */
	$note = esc_html( sprintf( __( 'Komt in het adres: /%s/', 'webwerckt-base' ), '…' ) );
	return '<template id="ww-languages-add-template">'
		. '<div class="ww-languages-modal" role="dialog" aria-modal="true" aria-labelledby="ww-languages-modal-title">'
		. '<div class="ww-languages-modal__box">'
		. '<h2 id="ww-languages-modal-title">' . esc_html__( 'Taal toevoegen', 'webwerckt-base' ) . '</h2>'
		. '<p class="ww-languages-error ww-languages-modal__error" id="ww-languages-modal-error" role="alert" hidden></p>'
		. '<div class="ww-languages-field"><label for="ww-languages-modal-preset">' . esc_html__( 'Taal', 'webwerckt-base' ) . '</label>'
		. '<select id="ww-languages-modal-preset" class="ww-languages-modal-preset">' . _ww_languages_screen_preset_options( $rows ) . '</select></div>'
		. '<details class="ww-languages-modal__details"><summary>' . esc_html__( 'Code, locale en naam aanpassen', 'webwerckt-base' ) . '</summary>'
		. '<div class="ww-languages-modal__fields">' . _ww_languages_screen_fields( 'dialog', array(), $note, false ) . '</div></details>'
		. '<p class="ww-languages-note"><span class="dashicons dashicons-hidden" aria-hidden="true"></span><span>' . esc_html__( 'Een nieuwe taal begint verborgen: alleen redacteuren zien hem, zodat je hem eerst kunt vullen.', 'webwerckt-base' ) . '</span></p>'
		. '<p class="ww-languages-modal__actions"><button type="button" class="button" data-ww-action="cancel">' . esc_html__( 'Annuleren', 'webwerckt-base' ) . '</button>'
		. '<button type="button" class="button button-primary" data-ww-action="add">' . esc_html__( 'Taal toevoegen', 'webwerckt-base' ) . '</button></p>'
		. '</div></div></template>';
}

/**
 * De verborgen rijen van het formulier save: de huidige configuratie, voor een knop die één ding verandert.
 *
 * @param list<array{code:string,locale:string,name:string,visible:bool,remove:bool,new:bool}> $rows         De rijen, zonder de nieuwe.
 * @param string                                                                               $make_visible Code die zichtbaar wordt, of ''.
 * @return string Geëscapete HTML.
 */
function _ww_languages_screen_hidden_rows( array $rows, string $make_visible = '' ): string {
	$html = '';
	foreach ( $rows as $i => $row ) {
		$prefix = 'ww_rows[' . $i . ']';
		$html  .= '<input type="hidden" name="' . esc_attr( $prefix . '[code]' ) . '" value="' . esc_attr( $row['code'] ) . '">';
		$html  .= '<input type="hidden" name="' . esc_attr( $prefix . '[locale]' ) . '" value="' . esc_attr( $row['locale'] ) . '">';
		$html  .= '<input type="hidden" name="' . esc_attr( $prefix . '[name]' ) . '" value="' . esc_attr( $row['name'] ) . '">';
		$html  .= '<input type="hidden" name="' . esc_attr( $prefix . '[order]' ) . '" value="' . esc_attr( (string) ( $i + 1 ) ) . '">';
		if ( $row['visible'] || ( '' !== $make_visible && $row['code'] === $make_visible ) ) {
			$html .= '<input type="hidden" name="' . esc_attr( $prefix . '[visible]' ) . '" value="1">';
		}
		if ( $row['remove'] ) {
			$html .= '<input type="hidden" name="' . esc_attr( $prefix . '[remove]' ) . '" value="1">';
		}
	}
	return $html;
}

/**
 * De Nederlandse naam van een taal voor "In het …": die uit de presets als de locale erin staat, anders de naam uit
 * de configuratie.
 *
 * @param array{code:string,locale:string,name:string,visible:bool}|null $language De taal.
 * @param string                                                          $code     Taalcode, als terugval.
 */
function _ww_languages_screen_dutch_name( ?array $language, string $code ): string {
	if ( null === $language ) {
		return $code;
	}
	foreach ( _ww_languages_presets() as $preset ) {
		if ( _ww_data_to_string( $preset['locale'] ) === $language['locale'] && '' !== _ww_data_to_string( $preset['label'] ) ) {
			return _ww_data_to_string( $preset['label'] );
		}
	}
	return '' !== $language['name'] ? $language['name'] : $code;
}

/**
 * De pagina van één extra taal: de kop met status, de meldingen van deze taal met een knop waar dat helpt, het vak
 * Inhoud, en de formulieren Ondertitel en URL-basis.
 *
 * @param string $code Taalcode.
 */
function _ww_languages_screen_language( string $code ): void {
	$language = _ww_language( $code );
	$name     = null !== $language ? $language['name'] : $code;
	$dutch    = _ww_languages_screen_dutch_name( $language, $code );
	$visible  = null !== $language && $language['visible'];
	$locale   = null !== $language ? $language['locale'] : '';
	$id       = sanitize_html_class( $code );
	$issues   = _ww_languages_admin_issues()[ $code ] ?? array();
	$config   = _ww_languages_config();

	echo '<h1 class="wp-heading-inline">' . _ww_languages_screen_code_badge( $code ) . ' ' . esc_html( $name ) . '</h1><hr class="wp-header-end">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- het blokje is geëscapet.

	echo '<p class="ww-languages-meta">';
	echo '<span class="ww-languages-meta__status"><span class="ww-languages-meta__dot' . ( $visible ? ' is-visible' : '' ) . '" aria-hidden="true"></span>'
		. esc_html( $visible ? __( 'Zichtbaar voor bezoekers', 'webwerckt-base' ) : __( 'Verborgen, alleen voor redacteuren', 'webwerckt-base' ) ) . '</span>';
	echo '<span>/' . esc_html( $code ) . '/</span>';
	if ( '' !== $locale ) {
		echo '<span>' . esc_html( $locale ) . '</span>';
	}
	if ( $visible ) {
		echo '<a href="' . esc_url( _ww_languages_home( $code ) ) . '">' . esc_html__( 'Bekijk op de site', 'webwerckt-base' ) . '</a>';
	} else {
		echo '<a href="' . esc_url( _ww_languages_admin_url() ) . '">' . esc_html__( 'Zichtbaar maken in het overzicht', 'webwerckt-base' ) . '</a>';
	}
	echo '</p>';

	foreach ( $issues as $issue ) {
		if ( 'base' === $issue['key'] ) {
			continue; // Staat bij het veld zelf.
		}
		echo '<div class="notice notice-' . esc_attr( 'info' === $issue['type'] ? 'info' : 'warning' ) . ' ww-languages-notice"><p>' . esc_html( $issue['message'] ) . '</p>';
		if ( 'menu' === $issue['key'] ) {
			$rows = array();
			foreach ( $config['languages'] as $row ) {
				$rows[] = array(
					'code'    => $row['code'],
					'locale'  => $row['locale'],
					'name'    => $row['name'],
					'visible' => $row['visible'],
					'remove'  => false,
					'new'     => false,
				);
			}
			echo '<div class="ww-languages-notice__actions"><a href="' . esc_url( admin_url( 'nav-menus.php' ) ) . '" class="button">' . esc_html__( 'Menu bewerken', 'webwerckt-base' ) . '</a>';
			_ww_languages_screen_form_open( array( 'language' => $code ) );
			echo _ww_languages_screen_hidden_rows( $rows, $code ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- geëscapet opgebouwd.
			echo '<input type="hidden" name="ww_default" value="' . esc_attr( $config['default'] ) . '">';
			echo '<input type="hidden" name="ww_next" value="' . esc_attr( $code ) . '">';
			/* translators: %s: naam van de taal */
			echo '<button type="submit" class="button button-primary">' . esc_html( sprintf( __( '%s zichtbaar maken', 'webwerckt-base' ), $name ) ) . '</button></form></div>';
		} elseif ( 'slug' === $issue['key'] && ! empty( $issue['link'] ) ) {
			echo '<div class="ww-languages-notice__actions"><a href="' . esc_url( $issue['link'] ) . '" class="button">' . esc_html__( 'Pagina bewerken', 'webwerckt-base' ) . '</a></div>';
		}
		echo '</div>';
	}

	// Vak Vertaald.
	$default       = _ww_default_language();
	$default_dutch = _ww_languages_screen_dutch_name( _ww_language( $default ), $default );
	$translated    = _ww_languages_translated_counts( $code );
	echo '<div class="ww-languages-box">';
	echo '<div class="ww-languages-box__head"><h2>' . esc_html__( 'Vertaald', 'webwerckt-base' ) . '</h2>';
	/* translators: %s: Nederlandse naam van de standaardtaal, zoals Nederlands */
	echo '<span>' . esc_html( sprintf( __( 'vanuit het %s', 'webwerckt-base' ), $default_dutch ) ) . '</span></div>';
	echo '<div class="ww-languages-box__body">';
	if ( array() === $translated ) {
		echo '<p>' . esc_html__( 'Nog geen inhoud in de standaardtaal.', 'webwerckt-base' ) . '</p>';
	} else {
		echo '<ul class="ww-languages-content">';
		foreach ( $translated as $type => $count ) {
			$object  = get_post_type_object( $type );
			$label   = $object ? $object->labels->name : $type;
			$pct     = (int) round( 100 * $count['translated'] / $count['total'] );
			$missing = $count['total'] - $count['translated'];
			echo '<li><span class="ww-languages-content__label">' . esc_html( $label ) . '</span>';
			echo '<span class="ww-languages-bar"><span style="width:' . (int) $pct . '%"></span></span>';
			/* translators: 1: aantal vertaald, 2: totaal */
			echo '<span class="ww-languages-content__count">' . esc_html( sprintf( __( '%1$d van %2$d', 'webwerckt-base' ), $count['translated'], $count['total'] ) ) . '</span>';
			if ( $missing > 0 ) {
				$url = add_query_arg(
					array(
						'post_type'       => $type,
						'ww_untranslated' => $code,
					),
					admin_url( 'edit.php' )
				);
				/* translators: %d: aantal berichten zonder vertaling */
				echo ' <a href="' . esc_url( $url ) . '">' . esc_html( sprintf( _n( '%d zonder vertaling', '%d zonder vertaling', $missing, 'webwerckt-base' ), $missing ) ) . '</a>';
			} else {
				echo ' <span class="ww-languages-content__done">' . esc_html__( 'alles vertaald', 'webwerckt-base' ) . '</span>';
			}
			echo '</li>';
		}
		echo '</ul>';
	}
	echo '</div></div>';

	// Vak Ondertitel.
	$tagline_id = 'ww-tagline-' . $id;
	echo '<form method="post" class="ww-languages-form ww-languages-box" data-ww-box="tagline" action="' . esc_url( _ww_languages_admin_url( array( 'language' => $code ) ) ) . '">';
	wp_nonce_field( 'ww_languages_tagline' );
	echo '<input type="hidden" name="ww_languages_action" value="save_tagline">';
	echo '<input type="hidden" name="ww_tagline_lang" value="' . esc_attr( $code ) . '">';
	echo '<input type="hidden" name="ww_next" value="' . esc_attr( $code ) . '">';
	echo '<div class="ww-languages-box__head"><h2>' . esc_html__( 'Ondertitel', 'webwerckt-base' ) . '</h2></div>';
	echo '<div class="ww-languages-box__body">';
	/* translators: %s: Nederlandse naam van de taal, zoals Engels */
	echo '<div class="ww-languages-field"><label for="' . esc_attr( $tagline_id ) . '">' . esc_html( sprintf( __( 'In het %s', 'webwerckt-base' ), $dutch ) ) . '</label>';
	echo '<input type="text" class="large-text" id="' . esc_attr( $tagline_id ) . '" name="ww_tagline" value="' . esc_attr( _ww_language_tagline( $code ) ) . '" placeholder="' . esc_attr( _ww_language_tagline( _ww_default_language() ) ) . '" aria-describedby="' . esc_attr( $tagline_id ) . '-note">';
	echo '<p class="description" id="' . esc_attr( $tagline_id ) . '-note">' . esc_html__( 'De ondertitel van de site in een extra taal: hij komt in de titel van de homepage en in de structured data. Leeg houdt de ondertitel van de standaardtaal.', 'webwerckt-base' ) . '</p></div>';
	submit_button( __( 'Ondertitel opslaan', 'webwerckt-base' ), 'secondary', 'submit-tagline-' . $code );
	echo '</div></form>';

	// Vak URL-basis.
	$objects = _ww_language_base_objects();
	if ( array() === $objects ) {
		return;
	}
	$posted    = _ww_languages_admin_bases_form();
	$values    = $posted[ $code ] ?? _ww_language_bases( $code );
	$conflicts = array();
	foreach ( $issues as $issue ) {
		if ( 'base' === $issue['key'] && isset( $issue['field'] ) ) {
			$conflicts[ $issue['field'] ] = $issue['message'];
		}
	}

	echo '<form method="post" class="ww-languages-form ww-languages-box" data-ww-box="bases" action="' . esc_url( _ww_languages_admin_url( array( 'language' => $code ) ) ) . '"' . ( isset( $posted[ $code ] ) ? ' data-ww-dirty="1"' : '' ) . '>';
	wp_nonce_field( 'ww_languages_bases' );
	echo '<input type="hidden" name="ww_languages_action" value="save_bases">';
	echo '<input type="hidden" name="ww_bases_lang" value="' . esc_attr( $code ) . '">';
	echo '<input type="hidden" name="ww_next" value="' . esc_attr( $code ) . '">';
	echo '<div class="ww-languages-box__head"><h2>' . esc_html__( 'URL-basis', 'webwerckt-base' ) . '</h2></div>';
	echo '<div class="ww-languages-box__body">';
	echo '<p>' . esc_html__( 'Het eerste deel van het adres van archieven en categorieën, vertaald per taal (/en/projects/ in plaats van /en/projecten/). Leeg houdt de basis van de standaardtaal. Een nieuwe basis verandert adressen die zoekmachines kennen: het oude adres stuurt door.', 'webwerckt-base' ) . '</p>';
	echo '<table class="widefat striped ww-languages-bases"><thead><tr>';
	echo '<th scope="col">' . esc_html__( 'Onderdeel', 'webwerckt-base' ) . '</th>';
	echo '<th scope="col">' . esc_html__( 'Standaard', 'webwerckt-base' ) . '</th>';
	/* translators: %s: Nederlandse naam van de taal, zoals Engels */
	echo '<th scope="col">' . esc_html( sprintf( __( 'In het %s', 'webwerckt-base' ), $dutch ) ) . '</th>';
	echo '</tr></thead><tbody>';
	foreach ( $objects as $key => $object ) {
		$key      = (string) $key;
		$field_id = 'ww-bases-' . $id . '-' . sanitize_html_class( $key );
		$error_id = $field_id . '-error';
		$conflict = $conflicts[ $key ] ?? '';
		$kind     = 'taxonomy' === $object['type'] ? __( 'taxonomie', 'webwerckt-base' ) : __( 'archief', 'webwerckt-base' );

		echo '<tr><th scope="row"><label for="' . esc_attr( $field_id ) . '">' . esc_html( $object['label'] ) . '</label><small>' . esc_html( $kind ) . '</small></th>';
		echo '<td data-label="' . esc_attr__( 'Standaard', 'webwerckt-base' ) . '"><code>' . esc_html( $object['base'] ) . '</code></td>';
		echo '<td><div class="ww-languages-affix' . ( '' !== $conflict ? ' is-conflict' : '' ) . '"><span>/' . esc_html( $code ) . '/</span>';
		echo '<input type="text" id="' . esc_attr( $field_id ) . '" name="' . esc_attr( 'ww_bases[' . $key . ']' ) . '" value="' . esc_attr( $values[ $key ] ?? '' ) . '" placeholder="' . esc_attr( $object['base'] ) . '"'
			. ( '' !== $conflict ? ' aria-invalid="true" aria-describedby="' . esc_attr( $error_id ) . '"' : '' ) . '></div>';
		if ( '' !== $conflict ) {
			echo '<p class="ww-languages-conflict" id="' . esc_attr( $error_id ) . '">' . esc_html( $conflict ) . '</p>';
		}
		echo '</td></tr>';
	}
	echo '</tbody></table>';
	submit_button( __( 'URL-basis opslaan', 'webwerckt-base' ), 'secondary', 'submit-bases-' . $code );
	echo '</div></form>';
}

/**
 * Taal toevoegen zonder script (&language=new): hetzelfde formulier save als het Overzicht, met alle bestaande rijen
 * verborgen meegestuurd en de rij new. Na opslaan gaat de redirect naar het Overzicht (ww_next leeg).
 */
function _ww_languages_screen_add(): void {
	$data    = _ww_languages_screen_rows();
	$new     = array();
	$current = array();
	foreach ( $data['rows'] as $row ) {
		if ( $row['new'] ) {
			$new = $row;
		} else {
			$current[] = $row;
		}
	}

	echo '<h1 class="wp-heading-inline">' . esc_html__( 'Taal toevoegen', 'webwerckt-base' ) . '</h1><hr class="wp-header-end">';

	_ww_languages_screen_form_open( array( 'language' => 'new' ), null !== _ww_languages_admin_form() );
	echo '<input type="hidden" name="ww_default" value="' . esc_attr( $data['default'] ) . '">';
	echo _ww_languages_screen_hidden_rows( $current ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- geëscapet opgebouwd.

	echo '<div class="ww-languages-box ww-languages-add-box">';
	echo '<div class="ww-languages-box__head"><h2>' . esc_html__( 'Taal toevoegen', 'webwerckt-base' ) . '</h2></div>';
	echo '<div class="ww-languages-box__body">';
	// De keuzelijst vult de velden alleen met script; het script haalt hidden weg.
	echo '<div class="ww-languages-field ww-languages-preset" hidden><label for="ww-languages-preset">' . esc_html__( 'Taal', 'webwerckt-base' ) . '</label>';
	echo '<select id="ww-languages-preset">' . _ww_languages_screen_preset_options( $current ) . '</select></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- geëscapet opgebouwd.
	echo _ww_languages_screen_fields( 'new', $new ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- geëscapet opgebouwd.
	echo '<p class="ww-languages-note"><span class="dashicons dashicons-hidden" aria-hidden="true"></span><span>' . esc_html__( 'Een nieuwe taal begint verborgen: alleen redacteuren zien hem, zodat je hem eerst kunt vullen.', 'webwerckt-base' ) . '</span></p>';
	echo '</div></div>';

	echo '<input type="hidden" name="ww_next" value="">';
	echo _ww_languages_screen_datalist(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- geëscapet opgebouwd.
	submit_button( __( 'Taal toevoegen', 'webwerckt-base' ) );
	echo '</form>';
}
