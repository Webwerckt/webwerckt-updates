<?php
/**
 * Structured data (ADR 0023): één JSON-LD-blok met een @graph in de head van elke pagina, uit de Site-instellingen
 * (inc/contact.php) en het breadcrumbpad (inc/breadcrumbs.php). De SEO-plugin levert geen schema meer; de koppeling
 * met The SEO Framework staat in inc/integrations/seo.php.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Soorten organisatie die de Site-instellingen kennen. De eerste is de standaard.
 */
const WW_ORGANIZATION_TYPES = array( 'LocalBusiness', 'ProfessionalService', 'Organization' );

/**
 * Naam van een plugin die zelf structured data zet, of ''. Het filter ww_schema_plugin vult hem in; de SEO-plugins
 * doen dat in inc/integrations/seo.php.
 */
function _ww_schema_plugin(): string {
	return _ww_data_to_string( apply_filters( 'ww_schema_plugin', '' ) );
}

/**
 * Levert de parent het schema? Niet als het filter ww_schema false geeft, en niet naast een andere plugin met
 * eigen schema (_ww_schema_plugin()): twee grafen naast elkaar is erger dan geen.
 */
function _ww_schema_enabled(): bool {
	return (bool) apply_filters( 'ww_schema', true ) && '' === _ww_schema_plugin();
}

/**
 * Een node zonder lege waarden ('', null, array()), ook niet dieper in de node.
 *
 * @param array<int|string,mixed> $node
 * @return array<int|string,mixed>
 */
function _ww_schema_clean( array $node ): array {
	$list = array_is_list( $node );
	foreach ( $node as $key => $value ) {
		if ( is_array( $value ) ) {
			$value = _ww_schema_clean( $value );
		}
		if ( in_array( $value, array( '', null, array() ), true ) ) {
			unset( $node[ $key ] );
		} else {
			$node[ $key ] = $value;
		}
	}
	return $list ? array_values( $node ) : $node;
}

/**
 * Een @id onder de homepage of een pagina: {url}#{naam}.
 */
function _ww_schema_id( string $url, string $name ): string {
	return $url . '#' . $name;
}

/**
 * Het adres van de site voor de organisatie en de site: één organisatie en één site, ook in een extra taal. Zonder
 * voorvoegsel van een taal, want home_url( '/' ) krijgt op /en/ het voorvoegsel (beslissing 0040).
 */
function _ww_schema_home(): string {
	return _ww_languages_home();
}

/**
 * De taal van de pagina voor inLanguage, als BCP 47-code: met de taalmodule de locale van de huidige taal, anders de
 * taal van de site.
 */
function _ww_schema_language(): string {
	$language = _ww_language( ww_current_language() );
	return null !== $language ? _ww_languages_bcp47( $language['locale'], $language['code'] ) : (string) get_bloginfo( 'language' );
}

/**
 * Soort organisatie uit de Site-instellingen, standaard LocalBusiness.
 */
function _ww_schema_organization_type(): string {
	$type = _ww_setting_string( 'organization_type' );
	return in_array( $type, WW_ORGANIZATION_TYPES, true ) ? $type : WW_ORGANIZATION_TYPES[0];
}

/**
 * Een afbeelding als ImageObject, of array() zonder afbeelding.
 *
 * @return array<string,mixed>
 */
function _ww_schema_image( int $attachment_id ): array {
	$image = $attachment_id > 0 ? wp_get_attachment_image_src( $attachment_id, 'full' ) : false;
	if ( ! is_array( $image ) ) {
		return array();
	}
	return array(
		'@type'  => 'ImageObject',
		'url'    => $image[0],
		'width'  => (int) $image[1],
		'height' => (int) $image[2],
	);
}

/**
 * Het adres als PostalAddress, of array() zonder straat, postcode en plaats.
 *
 * @return array<string,mixed>
 */
function _ww_schema_address(): array {
	$parts = _ww_address_parts();
	if ( array() === _ww_address_lines() ) {
		return array();
	}
	return array(
		'@type'           => 'PostalAddress',
		'streetAddress'   => $parts['street'],
		'postalCode'      => $parts['postal_code'],
		'addressLocality' => $parts['city'],
		'addressCountry'  => _ww_country(),
	);
}

/**
 * Openingstijden als OpeningHoursSpecification, één per blok. Middernacht aan het eind van de dag wordt 23:59,
 * zoals Google het vraagt.
 *
 * @return array<int,array<string,string>>
 */
function _ww_schema_opening_hours(): array {
	$out = array();
	// Niet ww_opening_hours(): die beperkt de cachetijd voor today, en het schema gebruikt today niet.
	foreach ( _ww_opening_hours_at( current_datetime() ) as $day ) {
		foreach ( $day['ranges'] as $range ) {
			$out[] = array(
				'@type'     => 'OpeningHoursSpecification',
				'dayOfWeek' => 'https://schema.org/' . ucfirst( $day['day'] ),
				'opens'     => $range['open'],
				'closes'    => '24:00' === $range['close'] ? '23:59' : $range['close'],
			);
		}
	}
	return $out;
}

/**
 * De URL's van de social-velden die echte URL's zijn.
 *
 * @return string[]
 */
function _ww_schema_same_as(): array {
	$urls = array();
	foreach ( array( 'facebook', 'instagram', 'linkedin' ) as $field ) {
		$url = esc_url_raw( _ww_setting_string( $field ), array( 'http', 'https' ) );
		if ( '' !== $url ) {
			$urls[] = $url;
		}
	}
	return $urls;
}

/**
 * Afbeelding voor het logo van de organisatie: het logo uit de Customizer of de site-editor als het thema dat
 * ondersteunt, anders het site-icoon (Instellingen › Algemeen), dat elke site heeft. Een logo als SVG in het
 * child-thema voegt het child toe met ww_schema_graph.
 */
function _ww_schema_logo_id(): int {
	return (int) get_theme_mod( 'custom_logo' ) ?: (int) get_option( 'site_logo' ) ?: (int) get_option( 'site_icon' );
}

/**
 * De organisatie achter de site. Adres en openingstijden alleen bij een type dat ze kent: openingstijden horen bij
 * een LocalBusiness (en ProfessionalService, een soort LocalBusiness).
 *
 * @return array<string,mixed>
 */
function _ww_schema_organization(): array {
	$type  = _ww_schema_organization_type();
	$home  = _ww_schema_home();
	$logo  = _ww_schema_logo_id();
	$node  = array(
		'@type'     => $type,
		'@id'       => _ww_schema_id( $home, 'organization' ),
		'name'      => _ww_plain_text( get_bloginfo( 'name' ) ),
		'url'       => $home,
		'logo'      => _ww_schema_image( $logo ),
		'telephone' => _ww_tel_number( _ww_setting_string( 'phone' ) ),
		'email'     => _ww_valid_email( _ww_setting_string( 'email' ) ),
		'address'   => _ww_schema_address(),
		'sameAs'    => _ww_schema_same_as(),
	);
	if ( 'Organization' !== $type ) {
		$node['image']                     = $node['logo'];
		$node['openingHoursSpecification'] = _ww_schema_opening_hours();
	}
	return $node;
}

/**
 * De site.
 *
 * @return array<string,mixed>
 */
function _ww_schema_website(): array {
	$home = _ww_schema_home();
	$node = array(
		'@type'      => 'WebSite',
		'@id'        => _ww_schema_id( $home, 'website' ),
		'url'        => $home,
		'name'       => _ww_plain_text( get_bloginfo( 'name' ) ),
		'inLanguage' => _ww_schema_language(),
		'publisher'  => array( '@id' => _ww_schema_id( $home, 'organization' ) ),
	);
	// De ondertitel van de site, in een extra taal die van die taal (beslissing 0044).
	$description = _ww_plain_text( get_bloginfo( 'description' ) );
	if ( '' !== $description ) {
		$node['description'] = $description;
	}
	return $node;
}

/**
 * URL van de huidige pagina, of '' als die er niet is (404).
 */
function _ww_schema_page_url(): string {
	$object = get_queried_object();
	$url    = '';
	if ( is_front_page() ) {
		$url = home_url( '/' );
	} elseif ( is_search() ) {
		$url = get_search_link();
	} elseif ( is_home() ) {
		$page = _ww_posts_page_id();
		$url  = $page > 0 ? get_permalink( $page ) : home_url( '/' );
	} elseif ( $object instanceof WP_Post ) {
		$url = get_permalink( $object );
	} elseif ( $object instanceof WP_Term ) {
		$url = get_term_link( $object );
	} elseif ( $object instanceof WP_Post_Type ) {
		$url = get_post_type_archive_link( $object->name );
	}
	return is_string( $url ) ? $url : '';
}

/**
 * Soort pagina: zoekresultaten, een overzicht, of een pagina met de soort uit haar box SEO (ww_seo_schema_type).
 * FAQPage alleen met gekoppelde vragen (_ww_schema_faq_questions()): een FAQPage zonder vragen keurt Google af.
 *
 * @param array<int,array<string,mixed>>|null $questions De vragen van de pagina als de aanroeper ze al heeft, anders null.
 */
function _ww_schema_page_type( ?array $questions = null ): string {
	if ( is_search() ) {
		return 'SearchResultsPage';
	}
	if ( ! is_singular() && ! is_front_page() ) {
		return 'CollectionPage';
	}
	$post_id = is_singular() ? (int) get_queried_object_id() : 0;
	$type    = $post_id > 0 && ! post_password_required( $post_id ) ? _ww_seo_schema_type( $post_id ) : 'WebPage';
	return 'FAQPage' === $type && array() === ( $questions ?? _ww_schema_faq_questions( $post_id ) ) ? 'WebPage' : $type;
}

/**
 * De vragen die een pagina toont, als Question-nodes: de gepubliceerde vragen uit haar relatievelden naar faq, in
 * hun volgorde. Het antwoord houdt alleen de HTML die Google toestaat.
 *
 * @return array<int,array<string,mixed>>
 */
function _ww_schema_faq_questions( int $post_id ): array {
	$ids = array();
	foreach ( _ww_pods_fields( (string) get_post_type( $post_id ), $post_id ) as $field ) {
		if ( 'pick' === ( $field['type'] ?? '' ) && 'faq' === ( $field['pick_val'] ?? '' ) ) {
			array_push( $ids, ..._ww_data_to_ids( _ww_data_get_stored( _ww_data_to_string( $field['name'] ?? '' ), $post_id ) ) );
		}
	}
	$ids   = array_unique( $ids );
	$prime = array_values( array_filter( array_map( 'intval', $ids ), static fn( int $id ): bool => $id > 0 ) );
	if ( array() !== $prime ) {
		// Vragen en hun velden in één keer laden, niet per vraag.
		_prime_post_caches( $prime, false, true );
	}
	$allowed   = array_fill_keys( array( 'p', 'br', 'ol', 'ul', 'li', 'strong', 'b', 'em', 'i' ), array() ) + array( 'a' => array( 'href' => true ) );
	$questions = array();
	foreach ( $ids as $id ) {
		// Eerst de goedkope controle, dan pas het antwoord opschonen.
		if ( 'faq' !== get_post_type( $id ) || ! _ww_data_is_published( $id ) ) {
			continue;
		}
		// Scripts en stijlen met inhoud en al weg, zodat er geen code als tekst achterblijft (net als in inc/content.php).
		$answer = (string) preg_replace( '@<(script|style)[^>]*?>.*?</\1>@si', '', _ww_data_to_string( _ww_data_get_stored( 'ww_answer', $id ) ) );
		$answer = trim( wp_kses( $answer, $allowed ) );
		if ( '' === $answer ) {
			continue;
		}
		$questions[] = array(
			'@type'          => 'Question',
			'name'           => _ww_plain_text( get_the_title( $id ) ),
			'acceptedAnswer' => array(
				'@type' => 'Answer',
				'text'  => $answer,
			),
		);
	}
	return $questions;
}

/**
 * Het breadcrumbpad als BreadcrumbList, of array() zonder pad (de homepage). De huidige pagina krijgt haar eigen URL.
 *
 * @param array<int,array{label:string,url:string}> $trail Pad van _ww_breadcrumb_trail().
 * @return array<string,mixed>
 */
function _ww_schema_breadcrumbs( string $url, array $trail ): array {
	$items = array();
	foreach ( $trail as $index => $crumb ) {
		$items[] = array(
			'@type'    => 'ListItem',
			'position' => $index + 1,
			'name'     => $crumb['label'],
			'item'     => '' === $crumb['url'] ? $url : $crumb['url'],
		);
	}
	if ( array() === $items ) {
		return array();
	}
	return array(
		'@type'           => 'BreadcrumbList',
		'@id'             => _ww_schema_id( $url, 'breadcrumb' ),
		'itemListElement' => $items,
	);
}

/**
 * De huidige pagina, met als naam de laatste stap van het pad (op de homepage de naam van de site). Beschrijving en
 * afbeelding komen uit de SEO van het thema (inc/seo.php), dus dezelfde als in de meta-tags. Van een bericht met
 * wachtwoord geen afbeelding en geen datums.
 *
 * @param array<int,array{label:string,url:string}> $trail Pad van _ww_breadcrumb_trail().
 * @return array<string,mixed>
 */
function _ww_schema_webpage( string $url, array $trail ): array {
	$post = is_singular() ? get_queried_object() : null;
	$open = $post instanceof WP_Post && ! post_password_required( $post );
	$last = array() === $trail ? array() : $trail[ count( $trail ) - 1 ];
	$name = is_front_page() ? get_bloginfo( 'name' ) : ( $last['label'] ?? '' );
	// De vragen één keer opbouwen, voor de soort pagina en voor mainEntity.
	$questions = null;
	if ( $post instanceof WP_Post ) {
		$questions = $open && 'FAQPage' === _ww_seo_schema_type( $post->ID ) ? _ww_schema_faq_questions( $post->ID ) : array();
	}
	$type = _ww_schema_page_type( $questions );
	return array(
		'@type'              => $type,
		'@id'                => _ww_schema_id( $url, 'webpage' ),
		'url'                => $url,
		'name'               => _ww_plain_text( $name ),
		'description'        => _ww_seo_enabled() ? _ww_seo_description() : '',
		'isPartOf'           => array( '@id' => _ww_schema_id( _ww_schema_home(), 'website' ) ),
		'inLanguage'         => _ww_schema_language(),
		'breadcrumb'         => array() === $trail ? array() : array( '@id' => _ww_schema_id( $url, 'breadcrumb' ) ),
		'primaryImageOfPage' => $open ? _ww_schema_image( _ww_seo_post_image_id( $post->ID ) ) : array(),
		'datePublished'      => $open ? (string) get_post_time( 'c', true, $post ) : '',
		'dateModified'       => $open ? (string) get_post_modified_time( 'c', true, $post ) : '',
		'mainEntity'         => 'FAQPage' === $type && $post instanceof WP_Post ? (array) $questions : array(),
	);
}

/**
 * Een blogbericht als BlogPosting, of array() als de pagina geen (open) bericht is.
 *
 * @return array<string,mixed>
 */
function _ww_schema_article( string $url ): array {
	$post = get_queried_object();
	if ( ! is_singular( 'post' ) || ! $post instanceof WP_Post || post_password_required( $post ) ) {
		return array();
	}
	$home = _ww_schema_home();
	return array(
		'@type'            => 'BlogPosting',
		'@id'              => _ww_schema_id( $url, 'article' ),
		'headline'         => _ww_plain_text( get_the_title( $post ) ),
		'datePublished'    => (string) get_post_time( 'c', true, $post ),
		'dateModified'     => (string) get_post_modified_time( 'c', true, $post ),
		'author'           => array(
			'@type' => 'Person',
			'name'  => _ww_plain_text( (string) get_the_author_meta( 'display_name', (int) $post->post_author ) ),
		),
		'publisher'        => array( '@id' => _ww_schema_id( $home, 'organization' ) ),
		'mainEntityOfPage' => array( '@id' => _ww_schema_id( $url, 'webpage' ) ),
		'image'            => _ww_schema_image( (int) get_post_thumbnail_id( $post ) ),
		'inLanguage'       => _ww_schema_language(),
	);
}

/**
 * De graph van de huidige pagina: organisatie en site altijd, daarna de pagina, haar breadcrumbs en een
 * blogbericht. Een 404 heeft geen pagina. Gaat door het filter ww_schema_graph (een lijst met nodes); lege waarden
 * zijn er daarna uit.
 *
 * @return array<int,array<string,mixed>>
 */
function _ww_schema_graph(): array {
	$graph = array( _ww_schema_organization(), _ww_schema_website() );
	$url   = _ww_schema_page_url();
	if ( '' !== $url && ! is_404() ) {
		$trail   = _ww_breadcrumb_trail();
		$graph[] = _ww_schema_webpage( $url, $trail );
		$graph[] = _ww_schema_breadcrumbs( $url, $trail );
		$graph[] = _ww_schema_article( $url );
	}

	$graph = apply_filters( 'ww_schema_graph', $graph );
	$nodes = array();
	foreach ( is_array( $graph ) ? $graph : array() as $node ) {
		$node = is_array( $node ) ? _ww_schema_clean( $node ) : array();
		if ( isset( $node['@type'] ) ) {
			$nodes[] = $node;
		}
	}
	return $nodes;
}

/**
 * De graph van de homepage (0) of van een bericht, buiten de pagina zelf (de ability webwerckt/get-schema). Zet
 * daarvoor even de hoofdquery van dat bericht, en daarna de vorige terug.
 *
 * @return array<int,array<string,mixed>>
 */
function _ww_schema_graph_for( int $post_id ): array {
	global $wp_query, $wp_the_query;

	$type = $post_id > 0 ? (string) get_post_type( $post_id ) : '';
	if ( 'page' === $type ) {
		$args = array( 'page_id' => $post_id );
	} elseif ( '' !== $type ) {
		$args = array(
			'p'         => $post_id,
			'post_type' => $type,
		);
	} else {
		$front = 'page' === get_option( 'show_on_front' ) ? (int) get_option( 'page_on_front' ) : 0;
		// Niet leeg: een WP_Query zonder argumenten zoekt niets en is dan ook geen homepage.
		$args = $front > 0 ? array( 'page_id' => $front ) : array( 'posts_per_page' => 1 );
	}

	$saved        = array( $wp_query, $wp_the_query );
	$wp_query     = new WP_Query( $args ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- tijdelijk, hieronder teruggezet.
	$wp_the_query = $wp_query; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- idem.
	try {
		return _ww_schema_graph();
	} finally {
		list( $wp_query, $wp_the_query ) = $saved; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- de vorige hoofdquery.
	}
}

/**
 * Het JSON-LD-blok, of '' zonder schema. `</script>` in een tekst kan het blok niet afbreken: < en > worden <
 * en >.
 */
function _ww_schema_html(): string {
	$graph = _ww_schema_enabled() ? _ww_schema_graph() : array();
	if ( array() === $graph ) {
		return '';
	}
	$json = wp_json_encode(
		array(
			'@context' => 'https://schema.org',
			'@graph'   => $graph,
		),
		JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP
	);
	return false === $json ? '' : '<script type="application/ld+json">' . $json . '</script>' . "\n";
}

/**
 * Zet het JSON-LD-blok in de head.
 */
function _ww_schema_print(): void {
	echo _ww_schema_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON met < > & als \u-codes.
}
add_action( 'wp_head', '_ww_schema_print', 20 );

/**
 * Wat er voor een volledige organisatie nog ontbreekt in de Site-instellingen.
 *
 * @return string[] Namen van de ontbrekende onderdelen.
 */
function _ww_schema_missing(): array {
	return array_values( _ww_schema_missing_map() );
}

/**
 * Wat de organisatie in het schema nog mist: schema-sleutel => label.
 *
 * @return array<string,string>
 */
function _ww_schema_missing_map(): array {
	$node    = _ww_schema_clean( _ww_schema_organization() );
	$missing = array(
		'address'   => __( 'adres (straat, postcode en plaats)', 'webwerckt-base' ),
		'telephone' => __( 'telefoonnummer', 'webwerckt-base' ),
		'logo'      => __( 'logo (het site-icoon onder Instellingen › Algemeen)', 'webwerckt-base' ),
	);
	if ( 'Organization' !== $node['@type'] ) {
		$missing['openingHoursSpecification'] = __( 'openingstijden', 'webwerckt-base' );
	}
	return array_diff_key( $missing, $node );
}

/**
 * Test in Site-status: levert het thema het schema, en is de organisatie volledig?
 *
 * @return array<string,mixed>
 */
function _ww_schema_health(): array {
	$badge  = __( 'SEO', 'webwerckt-base' );
	$plugin = _ww_schema_plugin();
	if ( '' !== $plugin ) {
		/* translators: %s: naam van de SEO-plugin. */
		$text = sprintf( __( '%s zet al structured data op de pagina. Het thema doet dat daarom niet; zet die plugin uit om het schema van het thema te gebruiken (beslissing 0023).', 'webwerckt-base' ), $plugin );
		return _ww_health_result( 'ww_schema', __( 'Structured data komt van een andere plugin', 'webwerckt-base' ), 'recommended', '<p>' . esc_html( $text ) . '</p>', $badge );
	}
	if ( ! _ww_schema_enabled() ) {
		return _ww_health_result( 'ww_schema', __( 'Structured data van het thema staat uit', 'webwerckt-base' ), 'recommended', '<p>' . esc_html__( 'Het filter ww_schema zet het schema van het thema uit.', 'webwerckt-base' ) . '</p>', $badge );
	}

	$type    = _ww_schema_organization_type();
	$missing = _ww_schema_missing();
	/* translators: %s: soort organisatie, bijvoorbeeld LocalBusiness. */
	$text = '<p>' . esc_html( sprintf( __( 'Het thema zet de organisatie als %s in de structured data van elke pagina.', 'webwerckt-base' ), $type ) ) . '</p>';
	if ( array() === $missing ) {
		return _ww_health_result( 'ww_schema', __( 'Structured data is volledig', 'webwerckt-base' ), 'good', $text, $badge );
	}
	/* translators: %s: ontbrekende onderdelen, gescheiden door komma's. */
	$text .= '<p>' . esc_html( sprintf( __( 'Vul in de Site-instellingen nog in: %s.', 'webwerckt-base' ), implode( ', ', $missing ) ) ) . '</p>';
	return _ww_health_result( 'ww_schema', __( 'Structured data mist gegevens van de organisatie', 'webwerckt-base' ), 'recommended', $text, $badge );
}

/**
 * Meldt de test in Site-status aan.
 *
 * @param array<string,array<string,mixed>> $tests Tests van WordPress.
 * @return array<string,array<string,mixed>>
 */
function _ww_schema_health_test( array $tests ): array {
	$tests['direct']['ww_schema'] = array(
		'label' => __( 'Structured data', 'webwerckt-base' ),
		'test'  => '_ww_schema_health',
	);
	return $tests;
}
add_filter( 'site_status_tests', '_ww_schema_health_test' );
