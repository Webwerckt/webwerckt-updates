<?php
/**
 * Standaard post types en taxonomieën. Het child-thema kiest welke het gebruikt:
 *
 *     add_action( 'after_setup_theme', function () {
 *         ww_use_post_types( 'project', 'service' );
 *     } );
 *
 * Een post type dat hier niet staat, registreert het child-thema zelf met register_post_type().
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Labels in het Nederlands voor een post type of taxonomie.
 *
 * @return array<string,string>
 */
function ww_post_type_labels( string $plural, string $singular ): array {
	return array(
		'name'          => $plural,
		'singular_name' => $singular,
		'menu_name'     => $plural,
		// Ook de naam van het archief in WordPress-menu's; zonder dit label wordt dat "Alle projecten".
		'archives'      => $plural,
		/* translators: %s: enkelvoud, bijvoorbeeld "Project". */
		'add_new_item'  => sprintf( __( '%s toevoegen', 'webwerckt-base' ), $singular ),
		/* translators: %s: enkelvoud, bijvoorbeeld "Project". */
		'edit_item'     => sprintf( __( '%s bewerken', 'webwerckt-base' ), $singular ),
		/* translators: %s: meervoud, bijvoorbeeld "Projecten". */
		'all_items'     => sprintf( __( 'Alle %s', 'webwerckt-base' ), strtolower( $plural ) ),
		/* translators: %s: meervoud, bijvoorbeeld "Projecten". */
		'search_items'  => sprintf( __( '%s zoeken', 'webwerckt-base' ), $plural ),
	);
}

/**
 * Argumenten voor een publiek post type met archief op een Nederlandse URL.
 *
 * @return array<string,mixed>
 */
function ww_public_post_type_args( string $plural, string $singular, string $slug, string $icon ): array {
	return array(
		'labels'       => ww_post_type_labels( $plural, $singular ),
		'public'       => true,
		'has_archive'  => $slug,
		'rewrite'      => array(
			'slug'       => $slug,
			'with_front' => false,
		),
		'menu_icon'    => $icon,
		'show_in_rest' => true,
		'supports'     => array( 'title', 'thumbnail', 'page-attributes', 'revisions' ),
	);
}

/**
 * Argumenten voor een post type zonder eigen pagina's, alleen te tonen via secties en relaties.
 *
 * @return array<string,mixed>
 */
function ww_block_post_type_args( string $plural, string $singular, string $icon ): array {
	return array(
		'labels'       => ww_post_type_labels( $plural, $singular ),
		'public'       => false,
		'show_ui'      => true,
		'show_in_rest' => true,
		'menu_icon'    => $icon,
		'supports'     => array( 'title', 'thumbnail', 'page-attributes', 'revisions' ),
	);
}

/**
 * Argumenten voor een taxonomie op een Nederlandse URL.
 *
 * @return array<string,mixed>
 */
function ww_taxonomy_args( string $plural, string $singular, string $slug, bool $hierarchical = true ): array {
	return array(
		'labels'            => ww_post_type_labels( $plural, $singular ),
		'hierarchical'      => $hierarchical,
		'show_admin_column' => true,
		'show_in_rest'      => true,
		'rewrite'           => array(
			'slug'       => $slug,
			'with_front' => false,
		),
	);
}

/**
 * Argumenten voor een taxonomie van een post type zonder eigen pagina's: te kiezen in het beheer en op te halen met
 * ww_terms() (om items te groeperen), maar zonder termarchieven op de frontend en dus niet in de sitemap.
 *
 * @return array<string,mixed>
 */
function _ww_block_taxonomy_args( string $plural, string $singular, bool $hierarchical = true ): array {
	return array(
		'labels'             => ww_post_type_labels( $plural, $singular ),
		'hierarchical'       => $hierarchical,
		'public'             => true,
		'publicly_queryable' => false,
		'show_admin_column'  => true,
		'show_in_rest'       => true,
		'rewrite'            => false,
	);
}

/**
 * Alle standaard post types met hun taxonomieën.
 *
 * @return array<string,array{args:array<string,mixed>,taxonomies:array<string,array<string,mixed>>}>
 */
function _ww_post_type_definitions(): array {
	return array(
		'project'     => array(
			'args'       => ww_public_post_type_args( __( 'Projecten', 'webwerckt-base' ), __( 'Project', 'webwerckt-base' ), 'projecten', 'dashicons-portfolio' ),
			'taxonomies' => array(
				'project_category' => ww_taxonomy_args( __( 'Projectcategorieën', 'webwerckt-base' ), __( 'Projectcategorie', 'webwerckt-base' ), 'projecten-categorie' ),
			),
		),
		'faq'         => array(
			// Vragen staan alleen via een relatie of sectie op een pagina; een losse pagina per vraag is dun (ADR 0024).
			'args'       => ww_block_post_type_args( __( 'Veelgestelde vragen', 'webwerckt-base' ), __( 'Vraag', 'webwerckt-base' ), 'dashicons-editor-help' ),
			'taxonomies' => array(
				'faq_category' => _ww_block_taxonomy_args( __( 'FAQ-categorieën', 'webwerckt-base' ), __( 'FAQ-categorie', 'webwerckt-base' ) ),
				'faq_tag'      => _ww_block_taxonomy_args( __( 'FAQ-tags', 'webwerckt-base' ), __( 'FAQ-tag', 'webwerckt-base' ), false ),
			),
		),
		'service'     => array(
			'args'       => ww_public_post_type_args( __( 'Diensten', 'webwerckt-base' ), __( 'Dienst', 'webwerckt-base' ), 'diensten', 'dashicons-hammer' ),
			'taxonomies' => array(),
		),
		'review'      => array(
			'args'       => ww_block_post_type_args( __( 'Reviews', 'webwerckt-base' ), __( 'Review', 'webwerckt-base' ), 'dashicons-star-filled' ),
			'taxonomies' => array(),
		),
		'team_member' => array(
			'args'       => ww_block_post_type_args( __( 'Teamleden', 'webwerckt-base' ), __( 'Teamlid', 'webwerckt-base' ), 'dashicons-groups' ),
			'taxonomies' => array(),
		),
	);
}

/**
 * Register van gekozen post types. Alleen ww_use_post_types() schrijft hierin.
 *
 * @param string[] $add Post types om toe te voegen; leeg leest alleen.
 * @return string[]
 */
function _ww_post_type_registry( array $add = array() ): array {
	static $used = array();

	$used = array_values( array_unique( array_merge( $used, $add ) ) );
	return $used;
}

/**
 * Zet standaard post types aan voor deze site.
 *
 * @param string ...$post_types Bijvoorbeeld 'project', 'faq'.
 */
function ww_use_post_types( string ...$post_types ): void {
	_ww_warn_if_too_late( __FUNCTION__, 'init' );
	_ww_post_type_registry( $post_types );
}

/**
 * Standaard post types die het child-thema heeft aangezet; onbekende namen vallen weg.
 *
 * Labels zijn vertaalbaar en worden daarom pas na after_setup_theme opgebouwd, niet in ww_use_post_types().
 *
 * @return string[]
 */
function _ww_used_post_types(): array {
	// De namen hangen niet van de taal af; alleen de labels. Eén keer opbouwen is dus genoeg.
	static $known = null;
	$known      ??= array_keys( _ww_post_type_definitions() );
	return array_values( array_intersect( _ww_post_type_registry(), $known ) );
}

/**
 * De argumenten van de gekozen post types en hun taxonomieën, zoals de parent ze vastlegt (zonder default_bases):
 * naam => argumenten. Alles wat hierin staat, registreert de parent.
 *
 * @return array<string,array<string,mixed>>
 */
function _ww_post_type_parent_objects(): array {
	$definitions = _ww_post_type_definitions();
	$objects     = array();
	foreach ( _ww_used_post_types() as $post_type ) {
		$objects[ $post_type ] = $definitions[ $post_type ]['args'];
		foreach ( $definitions[ $post_type ]['taxonomies'] as $taxonomy => $args ) {
			$objects[ $taxonomy ] = $args;
		}
	}
	return $objects;
}

/**
 * De eigen URL-basis (rewrite.slug, één padsegment) van de gekozen post types en hun taxonomieën, zoals de parent ze
 * vastlegt, zonder default_bases: naam => basis. Een object zonder eigen adres of met een basis van meer segmenten
 * staat er niet in. Voor set-default (inc/languages-cli.php): alleen deze objecten krijgen de basis van een nieuwe
 * standaardtaal.
 *
 * @return array<string,string>
 */
function _ww_post_type_parent_bases(): array {
	$bases = array();
	foreach ( _ww_post_type_parent_objects() as $name => $args ) {
		$slug = is_array( $args['rewrite'] ?? null ) && is_string( $args['rewrite']['slug'] ?? null ) ? trim( $args['rewrite']['slug'], '/' ) : '';
		if ( '' !== $slug && ! str_contains( $slug, '/' ) ) {
			$bases[ $name ] = $slug;
		}
	}
	return $bases;
}

/**
 * De argumenten van een post type of taxonomie van de parent met de basis van de standaardtaal: na een set-default
 * staat die in ww_languages onder default_bases (beslissing 0044). Ook has_archive volgt als dat dezelfde slug was.
 * Leest de optie ook met Meertalig uit: de site blijft dan in de standaardtaal, met zijn eigen basis.
 *
 * @param string              $name Naam van het post type of de taxonomie.
 * @param array<string,mixed> $args Argumenten uit _ww_post_type_definitions().
 * @return array<string,mixed>
 */
function _ww_post_type_default_base( string $name, array $args ): array {
	$base = _ww_languages_config()['default_bases'][ $name ] ?? '';
	if ( '' === $base || ! is_array( $args['rewrite'] ?? null ) || ! is_string( $args['rewrite']['slug'] ?? null ) ) {
		return $args;
	}
	if ( ( $args['has_archive'] ?? null ) === $args['rewrite']['slug'] ) {
		$args['has_archive'] = $base;
	}
	$args['rewrite']['slug'] = $base;
	return $args;
}

/**
 * Registreert de gekozen post types en hun taxonomieën, met de basis van de standaardtaal (_ww_post_type_default_base()).
 */
function _ww_register_post_types(): void {
	$definitions = _ww_post_type_definitions();
	foreach ( _ww_used_post_types() as $post_type ) {
		register_post_type( $post_type, _ww_post_type_default_base( $post_type, $definitions[ $post_type ]['args'] ) );
		foreach ( $definitions[ $post_type ]['taxonomies'] as $taxonomy => $args ) {
			register_taxonomy( $taxonomy, $post_type, _ww_post_type_default_base( $taxonomy, $args ) );
		}
	}
}

/**
 * Registreert de gekozen post types en hun taxonomieën opnieuw, na een nieuwe basis van de standaardtaal (set-default):
 * eerst weg, met hun rewrite rules, dan weer erbij. unregister_post_type() maakt elke taxonomie los van het post type,
 * ook die van anderen (ww_language, een taxonomie van het child-thema); die worden daarna weer gekoppeld. Daarna kan er
 * geflusht worden.
 */
function _ww_reregister_post_types(): void {
	$definitions = _ww_post_type_definitions();
	$attached    = array();
	foreach ( _ww_used_post_types() as $post_type ) {
		$attached[ $post_type ] = get_object_taxonomies( $post_type );
		foreach ( array_keys( $definitions[ $post_type ]['taxonomies'] ) as $taxonomy ) {
			if ( taxonomy_exists( $taxonomy ) ) {
				unregister_taxonomy( $taxonomy );
			}
		}
		if ( post_type_exists( $post_type ) ) {
			unregister_post_type( $post_type );
		}
	}
	_ww_register_post_types();
	foreach ( $attached as $post_type => $taxonomies ) {
		foreach ( $taxonomies as $taxonomy ) {
			if ( taxonomy_exists( $taxonomy ) && ! is_object_in_taxonomy( $post_type, $taxonomy ) ) {
				register_taxonomy_for_object_type( $taxonomy, $post_type );
			}
		}
	}
}
// Vroeg, zodat wat daarna de veldconfiguratie per post type leest (zoals de revisievelden) de post types al kent.
add_action( 'init', '_ww_register_post_types', 5 );
