<?php
/**
 * Activiteitenlog: het scherm Activiteitenlog (een hoofditem), alleen lezen en alleen voor beheerders (beslissing 0033).
 *
 * De tabel met de regels staat in WW_Activity_List_Table. Filteren gaat via GET, zonder nonce: er wordt niets
 * veranderd. Er is geen knop om te verwijderen of te legen; het log ruimt zichzelf op.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const WW_ACTIVITY_PAGE     = 'ww-activity';
const WW_ACTIVITY_PER_PAGE = 50;

/**
 * Voegt Activiteitenlog toe als hoofditem, in het Webwerckt-blok (beslissing 0035).
 */
function _ww_activity_admin_menu(): void {
	add_menu_page(
		__( 'Activiteitenlog', 'webwerckt-base' ),
		__( 'Activiteitenlog', 'webwerckt-base' ),
		'manage_options',
		WW_ACTIVITY_PAGE,
		'_ww_activity_admin_render',
		'dashicons-backup'
	);
}
add_action( 'admin_menu', '_ww_activity_admin_menu' );

/**
 * URL van het scherm, eventueel met extra queryvariabelen.
 *
 * @param array<string,string> $args Queryvariabelen.
 */
function _ww_activity_admin_url( array $args = array() ): string {
	return add_query_arg( array_map( 'rawurlencode', array( 'page' => WW_ACTIVITY_PAGE ) + $args ), admin_url( 'admin.php' ) );
}

/**
 * Het vertaalde label van een actie; een onbekende actie blijft zoals hij is.
 *
 * @param string $action created, duplicated, updated, published, unpublished, trashed, restored, deleted, uploaded of imported.
 */
function _ww_activity_action_label( string $action ): string {
	$labels = array(
		'created'     => __( 'Aangemaakt', 'webwerckt-base' ),
		'duplicated'  => __( 'Gedupliceerd', 'webwerckt-base' ),
		'updated'     => __( 'Bijgewerkt', 'webwerckt-base' ),
		'published'   => __( 'Gepubliceerd', 'webwerckt-base' ),
		'unpublished' => __( 'Offline gehaald', 'webwerckt-base' ),
		'trashed'     => __( 'Naar prullenbak', 'webwerckt-base' ),
		'restored'    => __( 'Teruggezet', 'webwerckt-base' ),
		'deleted'     => __( 'Verwijderd', 'webwerckt-base' ),
		'uploaded'    => __( 'Geüpload', 'webwerckt-base' ),
		'imported'    => __( 'Geïmporteerd', 'webwerckt-base' ),
	);
	return $labels[ $action ] ?? $action;
}

/**
 * De soorten object, met hun label in de filterlijst.
 *
 * @return array<string,string>
 */
function _ww_activity_type_labels(): array {
	return array(
		'post'       => __( 'Berichten en pagina\'s', 'webwerckt-base' ),
		'attachment' => __( 'Media', 'webwerckt-base' ),
		'menu'       => __( 'Menu\'s', 'webwerckt-base' ),
		'settings'   => __( 'Site-instellingen', 'webwerckt-base' ),
		'option'     => __( 'Instellingen', 'webwerckt-base' ),
		'redirect'   => __( 'Redirects', 'webwerckt-base' ),
		'bulk'       => __( 'Overig', 'webwerckt-base' ),
	);
}

/**
 * Het label van het object van een regel: het post type, Media, Menu, Site-instellingen: pagina, Instelling: optie,
 * Redirect of Overig.
 *
 * @param object $row Regel uit de tabel.
 */
function _ww_activity_object_label( object $row ): string {
	$type    = _ww_data_to_string( $row->object_type ?? '' );
	$subtype = _ww_data_to_string( $row->object_subtype ?? '' );
	switch ( $type ) {
		case 'post':
			$object = '' !== $subtype ? get_post_type_object( $subtype ) : null;
			if ( null !== $object && '' !== (string) $object->labels->singular_name ) {
				return (string) $object->labels->singular_name;
			}
			return '' !== $subtype ? $subtype : __( 'Overig', 'webwerckt-base' );
		case 'attachment':
			return __( 'Media', 'webwerckt-base' );
		case 'menu':
			return __( 'Menu', 'webwerckt-base' );
		case 'settings':
			if ( WW_SEO_SCREEN === $subtype ) {
				return __( 'SEO: llms.txt', 'webwerckt-base' );
			}
			$pages = _ww_settings_pages();
			return sprintf(
				/* translators: %s: naam van de pagina met site-instellingen. */
				__( 'Site-instellingen: %s', 'webwerckt-base' ),
				$pages[ $subtype ] ?? $subtype
			);
		case 'option':
			return sprintf(
				/* translators: %s: naam van de optie. */
				__( 'Instelling: %s', 'webwerckt-base' ),
				$subtype
			);
		case 'redirect':
			return __( 'Redirect', 'webwerckt-base' );
	}
	return __( 'Overig', 'webwerckt-base' );
}

/**
 * Datum en tijd in de tijdzone van de site, met hoe lang geleden als title (HTML, al geëscaped).
 *
 * @param object $row       Regel uit de tabel.
 * @param bool   $time_only Alleen het uur (H:i), voor de tabel met dagkopjes.
 */
function _ww_activity_when_html( object $row, bool $time_only = false ): string {
	$time = strtotime( _ww_data_to_string( $row->created ?? '' ) . ' UTC' );
	if ( false === $time ) {
		return '&mdash;';
	}
	$ago = sprintf(
		/* translators: %s: tijdsduur, zoals 5 minuten. */
		__( '%s geleden', 'webwerckt-base' ),
		human_time_diff( $time )
	);
	return '<span title="' . esc_attr( $ago ) . '">' . esc_html( wp_date( $time_only ? 'H:i' : 'j M Y H:i', $time ) ) . '</span>';
}

/**
 * De naam van wie een regel deed, als gewone tekst: de gebruiker, de agent of WP-CLI.
 *
 * @param object $row Regel uit de tabel.
 */
function _ww_activity_who_name( object $row ): string {
	$actor = _ww_data_to_string( $row->actor ?? '' );
	if ( 'cli' === $actor ) {
		return __( 'WP-CLI', 'webwerckt-base' );
	}
	if ( 'agent' === $actor ) {
		$agent = _ww_data_to_string( $row->agent ?? '' );
		return '' !== $agent ? $agent : __( 'Agent', 'webwerckt-base' );
	}
	return _ww_data_to_string( $row->user_name ?? '' );
}

/**
 * Wie een regel deed, met een rondje of vierkantje (HTML, al geëscaped): een mens met de eerste letter en de naam
 * (gelinkt als de gebruiker nog bestaat), een agent met het label Agent en "via {gebruiker}", WP-CLI met
 * "opdrachtregel".
 *
 * @param object $row     Regel uit de tabel.
 * @param bool   $compact Zonder de grijze tweede regel.
 */
function _ww_activity_who_html( object $row, bool $compact = false ): string {
	$actor = _ww_data_to_string( $row->actor ?? '' );
	$user  = _ww_data_to_string( $row->user_name ?? '' );
	$name  = _ww_activity_who_name( $row );
	if ( '' === $name ) {
		return '&mdash;';
	}

	$sub  = '';
	$link = '';
	if ( 'agent' === $actor ) {
		$icon  = '<span class="dashicons dashicons-superhero-alt" aria-hidden="true"></span>';
		$badge = ' <span class="ww-activity-agent">' . esc_html__( 'Agent', 'webwerckt-base' ) . '</span>';
		if ( '' !== $user ) {
			$sub = sprintf(
				/* translators: %s: naam van de gebruiker met wiens applicatiewachtwoord de agent werkt. */
				__( 'via %s', 'webwerckt-base' ),
				$user
			);
		}
	} elseif ( 'cli' === $actor ) {
		$icon  = '<span class="dashicons dashicons-editor-code" aria-hidden="true"></span>';
		$badge = '';
		$sub   = __( 'opdrachtregel', 'webwerckt-base' );
	} else {
		$actor   = 'human';
		$icon    = '<span aria-hidden="true">' . esc_html( mb_strtoupper( mb_substr( $name, 0, 1 ) ) ) . '</span>';
		$badge   = '';
		$user_id = (int) ( $row->user_id ?? 0 );
		$link    = $user_id > 0 && false !== get_userdata( $user_id ) ? get_edit_user_link( $user_id ) : '';
	}

	$name_html = esc_html( $name );
	if ( '' !== $link ) {
		$name_html = '<a href="' . esc_url( $link ) . '">' . $name_html . '</a>';
	}
	$html = '<span class="ww-activity-who"><span class="ww-activity-avatar ww-activity-avatar--' . esc_attr( $actor ) . '">' . $icon . '</span><span class="ww-activity-who-text"><span class="ww-activity-who-name">' . $name_html . '</span>' . $badge;
	if ( ! $compact && '' !== $sub ) {
		$html .= '<br><span class="description">' . esc_html( $sub ) . '</span>';
	}
	return $html . '</span></span>';
}

/**
 * Maakt de filters uit het verzoek schoon: actor alleen human, agent of cli, type alleen een bekende soort, object
 * als soort:id, een gebruiker als getal, een pagina vanaf 1, een periode van 1, 7 of 30 dagen (anders 30) en een
 * los id voor het detail van één regel.
 *
 * @param array<mixed> $get Queryvariabelen, bijvoorbeeld $_GET.
 * @return array{actor:string,user:int,type:string,object:string,s:string,paged:int,period:int,entry:int}
 */
function _ww_activity_query_args( array $get ): array {
	$types  = implode( '|', array_keys( _ww_activity_type_labels() ) );
	$actor  = sanitize_key( _ww_data_to_string( $get['actor'] ?? '' ) );
	$type   = sanitize_key( _ww_data_to_string( $get['type'] ?? '' ) );
	$obj    = trim( _ww_data_to_string( wp_unslash( $get['object'] ?? '' ) ) );
	$period = absint( _ww_data_to_string( $get['period'] ?? '' ) );

	return array(
		'actor'  => in_array( $actor, array( 'human', 'agent', 'cli' ), true ) ? $actor : '',
		'user'   => absint( _ww_data_to_string( $get['user'] ?? '' ) ),
		'type'   => in_array( $type, explode( '|', $types ), true ) ? $type : '',
		'object' => 1 === preg_match( '/^(' . $types . '):\d+$/', $obj ) ? $obj : '',
		's'      => trim( sanitize_text_field( _ww_data_to_string( wp_unslash( $get['s'] ?? '' ) ) ) ),
		'paged'  => max( 1, absint( _ww_data_to_string( $get['paged'] ?? '' ) ) ),
		'period' => in_array( $period, array( 1, 7, 30 ), true ) ? $period : 30,
		'entry'  => absint( _ww_data_to_string( $get['entry'] ?? '' ) ),
	);
}

/**
 * Het begin van een periode als UTC-tijd: middernacht in de tijdzone van de site, $days - 1 dagen geleden. De tabel
 * bewaart UTC.
 *
 * @param int $days Aantal dagen, met vandaag erbij (1 is alleen vandaag).
 * @return string Y-m-d H:i:s in UTC.
 */
function _ww_activity_period_start( int $days ): string {
	$start = new DateTimeImmutable( 'today', wp_timezone() );
	$start = $start->modify( '-' . max( 0, $days - 1 ) . ' days' );
	return $start->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
}

/**
 * Het aantal dagen dat het log regels bewaart, zoals de opruiming het gebruikt (filter ww_activity_retention_days).
 */
function _ww_activity_admin_retention_days(): int {
	return max( 1, (int) apply_filters( 'ww_activity_retention_days', 30 ) );
}

/**
 * De WHERE-tekst en de waarden voor de filters van nu en de periode. Periode 30 (de breedste) voegt geen datum toe.
 *
 * @param array{actor:string,user:int,type:string,object:string,s:string,paged:int,period:int,entry:int} $args Uit _ww_activity_query_args().
 * @param list<string>                                                                                   $skip Filters die niet meetellen: actor en/of type.
 * @return array{0:string,1:list<mixed>} De tekst (leeg of met " WHERE …") en de waarden.
 */
function _ww_activity_admin_where( array $args, array $skip = array() ): array {
	global $wpdb;
	$where  = array();
	$values = array();
	if ( '' !== $args['actor'] && ! in_array( 'actor', $skip, true ) ) {
		$where[]  = 'actor = %s';
		$values[] = $args['actor'];
	}
	if ( $args['user'] > 0 ) {
		$where[]  = 'user_id = %d';
		$values[] = $args['user'];
	}
	if ( '' !== $args['type'] && ! in_array( 'type', $skip, true ) ) {
		$where[]  = 'object_type = %s';
		$values[] = $args['type'];
	}
	if ( '' !== $args['object'] ) {
		list( $object_type, $object_id ) = explode( ':', $args['object'] );
		$where[]                         = '(object_type = %s AND object_id = %d)';
		$values[]                        = $object_type;
		$values[]                        = (int) $object_id;
	}
	if ( '' !== $args['s'] ) {
		$where[]  = 'object_title LIKE %s';
		$values[] = '%' . $wpdb->esc_like( $args['s'] ) . '%';
	}
	// 30 dagen is de standaard en de breedste periode: de opruiming bepaalt wat te oud is, niet het filter.
	if ( $args['period'] < 30 ) {
		$where[]  = 'created >= %s';
		$values[] = _ww_activity_period_start( $args['period'] );
	}

	return array( array() !== $where ? ' WHERE ' . implode( ' AND ', $where ) : '', $values );
}

/**
 * De regels voor de tabel: gefilterd, nieuwste eerst, een pagina. Zonder tabel komt er niets terug.
 *
 * @param array{actor:string,user:int,type:string,object:string,s:string,paged:int,period:int,entry:int} $args Uit _ww_activity_query_args().
 * @return array{items:list<object>,total:int}
 */
function _ww_activity_admin_list( array $args ): array {
	global $wpdb;
	if ( ! _ww_activity_ready() ) {
		return array(
			'items' => array(),
			'total' => 0,
		);
	}
	$table = _ww_activity_table();

	list( $sql_where, $values ) = _ww_activity_admin_where( $args );
	$offset                     = ( $args['paged'] - 1 ) * WW_ACTIVITY_PER_PAGE;

	$count_sql = "SELECT COUNT(*) FROM $table$sql_where";
	$total     = (int) $wpdb->get_var( array() === $values ? $count_sql : $wpdb->prepare( $count_sql, $values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- tabelnaam uit _ww_activity_table(), de voorwaarden zijn vaste teksten met placeholders.

	$list_sql = "SELECT * FROM $table$sql_where ORDER BY id DESC LIMIT %d OFFSET %d";
	$items    = $wpdb->get_results( $wpdb->prepare( $list_sql, array_merge( $values, array( WW_ACTIVITY_PER_PAGE, $offset ) ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- tabelnaam uit _ww_activity_table(), de voorwaarden zijn vaste teksten met placeholders.

	return array(
		'items' => array_values( array_filter( (array) $items, 'is_object' ) ),
		'total' => $total,
	);
}

/**
 * Aantallen per wie en per soort voor het zijpaneel. Elk telt de andere filters mee (gebruiker, titel, object,
 * periode) maar niet zichzelf, zodat het aantal klopt met de lijst als je die keuze maakt. Sleutel '' is het totaal.
 * Elke bekende actor en soort komt erin, ook bij 0.
 *
 * @param array{actor:string,user:int,type:string,object:string,s:string,paged:int,period:int,entry:int} $args Uit _ww_activity_query_args().
 * @return array{actor:array<string,int>,type:array<string,int>}
 */
function _ww_activity_admin_counts( array $args ): array {
	global $wpdb;
	$counts = array(
		'actor' => array( '' => 0 ),
		'type'  => array( '' => 0 ),
	);
	foreach ( array( 'human', 'agent', 'cli' ) as $actor ) {
		$counts['actor'][ $actor ] = 0;
	}
	foreach ( array_keys( _ww_activity_type_labels() ) as $type ) {
		$counts['type'][ $type ] = 0;
	}
	if ( ! _ww_activity_ready() ) {
		return $counts;
	}
	$table = _ww_activity_table();

	foreach ( array(
		'actor' => 'actor',
		'type'  => 'object_type',
	) as $key => $column ) {
		list( $sql_where, $values ) = _ww_activity_admin_where( $args, array( $key ) );
		$sql                        = "SELECT $column AS k, COUNT(*) AS n FROM $table$sql_where GROUP BY $column";
		$rows                       = $wpdb->get_results( array() === $values ? $sql : $wpdb->prepare( $sql, $values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- tabel en kolom zijn vaste teksten in deze functie, de voorwaarden hebben placeholders.
		foreach ( (array) $rows as $row ) {
			if ( ! is_object( $row ) ) {
				continue;
			}
			$n                   = (int) $row->n;
			$counts[ $key ][''] += $n;
			$name                = (string) $row->k;
			if ( isset( $counts[ $key ][ $name ] ) ) {
				$counts[ $key ][ $name ] = $n;
			}
		}
	}
	return $counts;
}

/**
 * Per object van de regels (soort:id) het aantal regels in de periode van nu, zonder andere filters: wat de link
 * "Alle activiteit van dit item" laat zien. Eén query voor de hele pagina, met dezelfde voorwaarden als
 * _ww_activity_entry_detail() voor één object gebruikt.
 *
 * @param array{actor:string,user:int,type:string,object:string,s:string,paged:int,period:int,entry:int} $args Uit _ww_activity_query_args().
 * @param array<object>                                                                                  $rows Regels uit de tabel.
 * @return array<string,int> Soort:id naar aantal; objecten zonder regels ontbreken.
 */
function _ww_activity_object_counts( array $args, array $rows ): array {
	global $wpdb;
	$ids   = array();
	$types = array();
	foreach ( $rows as $row ) {
		$id = (int) ( $row->object_id ?? 0 );
		if ( $id > 0 ) {
			$ids[ $id ]     = $id;
			$type           = _ww_data_to_string( $row->object_type ?? '' );
			$types[ $type ] = $type;
		}
	}
	if ( array() === $ids || ! _ww_activity_ready() ) {
		return array();
	}

	$link_args                  = array_merge( _ww_activity_query_args( array() ), array( 'period' => $args['period'] ) );
	list( $sql_where, $values ) = _ww_activity_admin_where( $link_args );
	// Soort én id, zodat de index object (object_type, object_id) gebruikt kan worden.
	$sql_where .= ( '' === $sql_where ? ' WHERE ' : ' AND ' )
		. 'object_type IN (' . implode( ',', array_fill( 0, count( $types ), '%s' ) ) . ')'
		. ' AND object_id IN (' . implode( ',', array_fill( 0, count( $ids ), '%d' ) ) . ')';
	$sql        = 'SELECT object_type, object_id, COUNT(*) AS n FROM ' . _ww_activity_table() . $sql_where . ' GROUP BY object_type, object_id';
	$result     = $wpdb->get_results( $wpdb->prepare( $sql, array_merge( $values, array_values( $types ), array_values( $ids ) ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- tabelnaam uit _ww_activity_table(), de voorwaarden zijn vaste teksten met placeholders.

	$counts = array();
	foreach ( (array) $result as $row ) {
		if ( is_object( $row ) ) {
			$counts[ (string) $row->object_type . ':' . (int) $row->object_id ] = (int) $row->n;
		}
	}
	return $counts;
}

/**
 * Eén regel uit het log, of null als hij niet bestaat.
 *
 * @param int $id Id van de regel.
 */
function _ww_activity_admin_get( int $id ): ?object {
	global $wpdb;
	if ( $id < 1 || ! _ww_activity_ready() ) {
		return null;
	}
	$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . _ww_activity_table() . ' WHERE id = %d', $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_activity_table().
	return is_object( $row ) ? $row : null;
}

/**
 * De samenvatting van vandaag (in de tijdzone van de site) voor het kaartje in het zijpaneel.
 *
 * @return array{count:int,agents:int,last:string} Aantal regels, daarvan door een agent, en het laatste tijdstip als H:i (of '').
 */
function _ww_activity_today_summary(): array {
	global $wpdb;
	$summary = array(
		'count'  => 0,
		'agents' => 0,
		'last'   => '',
	);
	if ( ! _ww_activity_ready() ) {
		return $summary;
	}
	$row = $wpdb->get_row( $wpdb->prepare( 'SELECT COUNT(*) AS n, SUM(CASE WHEN actor = %s THEN 1 ELSE 0 END) AS agents, MAX(created) AS last FROM ' . _ww_activity_table() . ' WHERE created >= %s', 'agent', _ww_activity_period_start( 1 ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_activity_table().
	if ( ! is_object( $row ) ) {
		return $summary;
	}
	$summary['count']  = (int) $row->n;
	$summary['agents'] = (int) $row->agents;
	if ( is_string( $row->last ) && '' !== $row->last ) {
		$last            = new DateTimeImmutable( $row->last, new DateTimeZone( 'UTC' ) );
		$summary['last'] = $last->setTimezone( wp_timezone() )->format( 'H:i' );
	}
	return $summary;
}

/**
 * De gebruikers die in het log voorkomen, voor het filter.
 *
 * @return array<int,string> Gebruikers-id naar naam.
 */
function _ww_activity_admin_users(): array {
	global $wpdb;
	if ( ! _ww_activity_ready() ) {
		return array();
	}
	$rows  = $wpdb->get_results( 'SELECT user_id, MAX(user_name) AS user_name FROM ' . _ww_activity_table() . ' WHERE user_id > 0 GROUP BY user_id ORDER BY user_name ASC' ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_activity_table(), geen invoer.
	$users = array();
	foreach ( (array) $rows as $row ) {
		if ( is_object( $row ) ) {
			$users[ (int) $row->user_id ] = (string) $row->user_name;
		}
	}
	return $users;
}

/**
 * Een link naar het bewerkscherm van het object van een regel, of '' als er geen is of het object niet meer bestaat.
 *
 * @param object $row Regel uit de tabel.
 */
function _ww_activity_object_link( object $row ): string {
	$type    = _ww_data_to_string( $row->object_type ?? '' );
	$subtype = _ww_data_to_string( $row->object_subtype ?? '' );
	$id      = (int) ( $row->object_id ?? 0 );

	switch ( $type ) {
		case 'post':
		case 'attachment':
			if ( $id > 0 && $id === (int) get_post_field( 'ID', $id ) && 'trash' !== get_post_status( $id ) ) {
				return (string) get_edit_post_link( $id, 'raw' );
			}
			return '';
		case 'menu':
			return $id > 0 && term_exists( $id, 'nav_menu' ) ? admin_url( 'nav-menus.php?action=edit&menu=' . $id ) : '';
		case 'settings':
			if ( WW_SEO_SCREEN === $subtype ) {
				// De velden van llms.txt horen bij het scherm SEO, niet bij een pagina van de Site-instellingen.
				return _ww_seo_enabled() && current_user_can( WW_SETTINGS_CAP ) ? _ww_seo_admin_url( array( 'tab' => 'llms' ) ) : '';
			}
			$pages = _ww_settings_visible_pages();
			if ( ! isset( $pages[ $subtype ] ) ) {
				return '';
			}
			return _ww_settings_url( $subtype );
		case 'redirect':
			if ( $id > 0 && null !== _ww_redirects_admin_get( $id ) ) {
				return _ww_redirects_admin_url(
					array(
						'tab'  => 'redirects',
						'edit' => (string) $id,
					)
				) . '#ww-source';
			}
			return '';
	}
	return '';
}

/**
 * Laadt de stijl, alleen op dit scherm, en het script voor het venster alleen bij de lijst (niet bij het detail van
 * één regel). Zonder script opent de link van een regel het detail op een eigen pagina.
 *
 * @param string $hook Admin-scherm.
 */
function _ww_activity_admin_assets( string $hook ): void {
	if ( 'toplevel_page_' . WW_ACTIVITY_PAGE !== $hook ) {
		return;
	}
	wp_enqueue_style( 'ww-activity-admin', _ww_asset_url( 'css/activity-admin.css' ), array(), WW_BASE_VERSION );
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen lezen.
	$entry = _ww_activity_query_args( $_GET )['entry'];
	// Een entry dat niet bestaat geeft de gewone lijst, en die heeft het script wel nodig.
	if ( 0 === $entry || null === _ww_activity_admin_get( $entry ) ) {
		wp_enqueue_script(
			'ww-activity-entries',
			_ww_asset_url( 'js/activity-entries.js' ),
			array(),
			WW_BASE_VERSION,
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
	}
}
add_action( 'admin_enqueue_scripts', '_ww_activity_admin_assets' );

/**
 * De verborgen velden van een filterformulier: de pagina en de filters die het formulier zelf niet toont.
 *
 * @param array{actor:string,user:int,type:string,object:string,s:string,paged:int,period:int,entry:int} $args Uit _ww_activity_query_args().
 * @param list<string>                                                                                   $keys Welke filters mee moeten.
 * @return string Geëscapete HTML.
 */
function _ww_activity_hidden_fields( array $args, array $keys ): string {
	$html = '<input type="hidden" name="page" value="' . esc_attr( WW_ACTIVITY_PAGE ) . '">';
	foreach ( $keys as $key ) {
		$value = (string) ( $args[ $key ] ?? '' );
		if ( '' === $value || ( 'period' === $key && '30' === $value ) ) {
			continue;
		}
		$html .= '<input type="hidden" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '">';
	}
	return $html;
}

/**
 * De keuzelijst met gebruikers.
 *
 * @param int                    $user  Gekozen gebruiker.
 * @param string                 $id    Id van de keuzelijst.
 * @param array<int,string>|null $users Uitkomst van _ww_activity_admin_users(), of null om ze zelf te lezen.
 * @return string Geëscapete HTML.
 */
function _ww_activity_user_select( int $user, string $id, ?array $users = null ): string {
	$html = '<select name="user" id="' . esc_attr( $id ) . '" aria-label="' . esc_attr__( 'Gebruiker', 'webwerckt-base' ) . '">';
	$html .= '<option value="">' . esc_html__( 'Alle gebruikers', 'webwerckt-base' ) . '</option>';
	foreach ( $users ?? _ww_activity_admin_users() as $user_id => $name ) {
		$html .= '<option value="' . esc_attr( (string) $user_id ) . '"' . selected( $user, $user_id, false ) . '>' . esc_html( $name ) . '</option>';
	}
	return $html . '</select>';
}

/**
 * Toont het scherm: het zijpaneel en de lijst, of het detail van één regel (entry, de weergave zonder JavaScript).
 */
function _ww_activity_admin_render(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Je hebt geen rechten om het activiteitenlog te bekijken.', 'webwerckt-base' ), 403 );
	}
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
	require_once __DIR__ . '/class-ww-activity-list-table.php';

	if ( ! _ww_activity_ready() ) {
		echo '<div class="wrap">';
		echo '<h1 class="wp-heading-inline">' . esc_html__( 'Activiteitenlog', 'webwerckt-base' ) . '</h1>';
		echo '<hr class="wp-header-end">';
		echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'Het activiteitenlog is nog niet klaar voor gebruik. Open dit scherm opnieuw.', 'webwerckt-base' ) . '</p></div>';
		echo '</div>';
		return;
	}

	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen lezen en filteren.
	$args   = _ww_activity_query_args( $_GET );
	$counts = _ww_activity_admin_counts( $args );
	$entry  = _ww_activity_admin_get( $args['entry'] ); // Een id dat niet bestaat geeft de gewone lijst.

	echo '<div class="wrap ww-activity"><div class="ww-activity-layout">';
	echo _ww_activity_render_panel( $args, $counts ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_activity_render_panel() escapet.
	echo '<div class="ww-activity-main">';
	echo '<div class="ww-activity-pickers">' . _ww_activity_render_nav( 'actor', $args, $counts, 'menu' ) . _ww_activity_render_nav( 'type', $args, $counts, 'menu' ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_activity_render_nav() escapet.

	if ( null !== $entry ) {
		echo '<p class="ww-activity-back"><a href="' . esc_url( _ww_activity_filter_url( $args ) ) . '">← ' . esc_html__( 'Terug naar het log', 'webwerckt-base' ) . '</a></p>';
		echo '<h1>' . esc_html( _ww_activity_entry_title( $entry ) ) . '</h1>';
		echo '<hr class="wp-header-end">';
		echo '<div class="ww-activity-entry">' . _ww_activity_entry_detail( $entry, $args ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_activity_entry_detail() escapet.
		echo '</div></div></div>';
		return;
	}

	$table = new WW_Activity_List_Table();
	$table->prepare_items();

	if ( '' !== $args['object'] ) {
		$title = sprintf(
			/* translators: %s: titel van het item. */
			__( 'Activiteit van %s', 'webwerckt-base' ),
			_ww_activity_object_summary( $args['object'] )['title']
		);
	} else {
		$titles = array(
			''      => __( 'Alle activiteit', 'webwerckt-base' ),
			'human' => __( 'Door mensen', 'webwerckt-base' ),
			'agent' => __( 'Door agents', 'webwerckt-base' ),
			'cli'   => __( 'Via WP-CLI', 'webwerckt-base' ),
		);
		$title  = $titles[ $args['actor'] ] ?? $titles[''];
	}

	echo '<div class="ww-activity-head"><h1 class="wp-heading-inline">' . esc_html( $title ) . '</h1>' . _ww_activity_render_period( $args, 'panel' ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_activity_render_period() escapet.
	echo '<p class="ww-activity-range">' . esc_html( _ww_activity_range_text( $args['period'] ) ) . '</p>';
	echo '<hr class="wp-header-end">';

	// De gebruikers één keer lezen: de twee keuzelijsten en het filterlabel gebruiken dezelfde lijst.
	$users = _ww_activity_admin_users();

	// De tabelbalk: gebruiker en Filter links, het zoekvak rechts.
	echo '<form method="get" class="ww-activity-toolbar">';
	echo _ww_activity_hidden_fields( $args, array( 'actor', 'type', 'object', 'period' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_activity_hidden_fields() escapet.
	echo '<div class="ww-activity-toolbar__user">' . _ww_activity_user_select( $args['user'], 'ww-activity-user', $users ) . ' '; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_activity_user_select() escapet.
	submit_button( __( 'Filter', 'webwerckt-base' ), 'secondary', '', false );
	echo '</div>';
	$table->search_box( __( 'Zoeken', 'webwerckt-base' ), 'ww-activity' );
	echo '</form>';

	// Mobiel: gebruiker en periode in een uitklapper. Een eigen formulier, want twee keuzelijsten "user" in één
	// formulier sturen allebei hun waarde mee en de laatste wint.
	echo '<details class="ww-activity-filters"><summary class="button">' . esc_html__( 'Filters', 'webwerckt-base' ) . '</summary>';
	echo '<form method="get" class="ww-activity-filters__body">';
	echo _ww_activity_hidden_fields( $args, array( 'actor', 'type', 'object', 's', 'period' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_activity_hidden_fields() escapet.
	echo '<label for="ww-activity-user-mobile">' . esc_html__( 'Gebruiker', 'webwerckt-base' ) . '</label>' . _ww_activity_user_select( $args['user'], 'ww-activity-user-mobile', $users ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_activity_user_select() escapet.
	echo '<span class="ww-activity-filters__label">' . esc_html__( 'Periode', 'webwerckt-base' ) . '</span>' . _ww_activity_render_period( $args, 'menu' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_activity_render_period() escapet.
	submit_button( __( 'Filter', 'webwerckt-base' ), 'secondary', '', false );
	echo '</form></details>';

	echo _ww_activity_render_chips( $args, $users ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_activity_render_chips() escapet.

	// WP_List_Table bouwt de bladerlinks en het verborgen veld _wp_http_referer uit REQUEST_URI. Zet daar even de
	// schone URL neer, zodat rommel uit het verzoek niet in de pagina terugkomt.
	// De bladerlinks halen het paginanummer zelf uit het verzoek.
	$request_uri            = $_SERVER['REQUEST_URI'] ?? null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- wordt alleen teruggezet.
	$_SERVER['REQUEST_URI'] = wp_make_link_relative( _ww_activity_filter_url( $args ) );
	try {
		$table->display();
	} finally {
		if ( null === $request_uri ) {
			unset( $_SERVER['REQUEST_URI'] );
		} else {
			$_SERVER['REQUEST_URI'] = $request_uri;
		}
	}

	echo $table->entry_templates(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- entry_templates() escapet.
	echo _ww_activity_entry_dialog(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_activity_entry_dialog() escapet.
	echo '</div></div></div>';
}

/**
 * Zet de metabox "Laatste activiteit" op het bewerkscherm van een gelogd post type, alleen voor beheerders.
 *
 * @param string $post_type Post type van het bewerkscherm.
 */
function _ww_activity_add_metabox( string $post_type ): void {
	if ( ! current_user_can( 'manage_options' ) || ! post_type_exists( $post_type ) || ! _ww_activity_post_type_logged( $post_type ) ) {
		return;
	}
	add_meta_box( 'ww-activity', __( 'Laatste activiteit', 'webwerckt-base' ), '_ww_activity_render_metabox', $post_type, 'side', 'low' );
}
add_action( 'add_meta_boxes', '_ww_activity_add_metabox' );

/**
 * De laatste vijf regels van dit bericht, met een link naar de hele lijst voor dit object.
 *
 * @param WP_Post $post Bericht dat wordt bewerkt.
 */
function _ww_activity_render_metabox( WP_Post $post ): void {
	global $wpdb;
	$rows = array();
	if ( _ww_activity_ready() ) {
		$rows = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . _ww_activity_table() . " WHERE object_type = 'post' AND object_id = %d ORDER BY id DESC LIMIT 5", $post->ID ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_activity_table().
	}
	$rows = array_values( array_filter( $rows, 'is_object' ) );

	if ( array() === $rows ) {
		echo '<p>' . esc_html(
			sprintf(
				/* translators: %d: aantal dagen dat het log regels bewaart. */
				_n( 'Nog geen activiteit in de laatste %d dag.', 'Nog geen activiteit in de laatste %d dagen.', _ww_activity_admin_retention_days(), 'webwerckt-base' ),
				_ww_activity_admin_retention_days()
			)
		) . '</p>';
		return;
	}

	echo '<ul>';
	foreach ( $rows as $row ) {
		$fields = array_slice( _ww_activity_field_labels( $row ), 0, 3 );
		// Gewone tekst: de stijl van het log wordt op dit scherm niet geladen.
		$who = _ww_activity_who_name( $row );
		if ( 'agent' === _ww_data_to_string( $row->actor ?? '' ) ) {
			$who = sprintf(
				/* translators: %s: naam van de agent. */
				__( 'Agent: %s', 'webwerckt-base' ),
				$who
			);
		}
		echo '<li>' . _ww_activity_when_html( $row ) . '<br>' . esc_html( '' !== $who ? $who : '—' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_activity_when_html() geeft geëscapete HTML.
		echo '<br><strong>' . esc_html( _ww_activity_action_label( _ww_data_to_string( $row->action ) ) ) . '</strong>';
		if ( array() !== $fields ) {
			echo ': ' . esc_html( implode( ', ', $fields ) );
		}
		echo '</li>';
	}
	echo '</ul>';
	echo '<p><a href="' . esc_url( _ww_activity_admin_url( array( 'object' => 'post:' . $post->ID ) ) ) . '">' . esc_html__( 'Alle activiteit van deze pagina', 'webwerckt-base' ) . '</a></p>';
}
