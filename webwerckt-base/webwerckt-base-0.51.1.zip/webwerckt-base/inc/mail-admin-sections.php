<?php
/**
 * Mail: de router van het scherm (beslissing 0047).
 *
 * Het scherm heeft twee onderdelen, Logboek en Instellingen (?tab=settings), op één menupagina. Het logboek heeft naast
 * de lijst ook een detail (&id=). De acties zelf staan in inc/mail-admin.php.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * De weergave van dit verzoek: log, detail of settings. Een onbekende tab is het logboek.
 */
function _ww_mail_admin_view(): string {
	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- alleen een weergave kiezen.
	$tab = isset( $_GET['tab'] ) ? _ww_data_to_string( wp_unslash( $_GET['tab'] ) ) : '';
	if ( 'settings' === $tab ) {
		return 'settings';
	}
	$id = isset( $_GET['id'] ) ? absint( _ww_data_to_string( wp_unslash( $_GET['id'] ) ) ) : 0;
	// phpcs:enable
	return '' === $tab && $id > 0 ? 'detail' : 'log';
}

/**
 * De onderdelen van het scherm, op slug.
 *
 * @return array<string,string>
 */
function _ww_mail_admin_sections(): array {
	return array(
		'log'      => __( 'Logboek', 'webwerckt-base' ),
		'settings' => __( 'Instellingen', 'webwerckt-base' ),
	);
}

/**
 * Per onleesbaar geheim (van alle aansluitingen) de melding dat het opnieuw moet worden ingevoerd.
 *
 * @return list<string>
 */
function _ww_mail_unreadable_secrets(): array {
	$texts = array();
	foreach ( _ww_mail_transports() as $id => $transport ) {
		foreach ( _ww_mail_secret_fields( $transport ) as $name => $field ) {
			if ( 'unreadable' === _ww_mail_secret_state( $id, $name, _ww_mail_field_constant( $field ) ) ) {
				$texts[] = sprintf(
					/* translators: 1: naam van de aansluiting, 2: naam van het veld. */
					__( '%1$s: %2$s moet opnieuw worden ingevoerd (de sleutels van de site zijn veranderd).', 'webwerckt-base' ),
					$transport->label(),
					_ww_data_to_string( $field['label'] ?? $name )
				);
			}
		}
	}
	return $texts;
}

/**
 * Het eerste probleem met de geheimen van één aansluiting: een geheim dat onleesbaar is, anders een verplicht geheim
 * dat leeg is. Velden met een gezette constante tellen niet.
 *
 * @param string $id Id van de aansluiting.
 * @return array{0:string,1:string} [ 'unreadable'|'missing'|'', label van het veld ].
 */
function _ww_mail_secret_problem( string $id ): array {
	$transport = _ww_mail_transports()[ $id ] ?? null;
	if ( null === $transport ) {
		return array( '', '' );
	}
	$missing = '';
	foreach ( _ww_mail_secret_fields( $transport ) as $name => $field ) {
		$state = _ww_mail_secret_state( $id, $name, _ww_mail_field_constant( $field ) );
		$label = _ww_data_to_string( $field['label'] ?? $name );
		if ( 'unreadable' === $state ) {
			return array( 'unreadable', $label );
		}
		if ( '' === $missing && 'empty' === $state && ! empty( $field['required'] ) ) {
			$missing = $label;
		}
	}
	return '' !== $missing ? array( 'missing', $missing ) : array( '', '' );
}

/**
 * De stip en de tekst voor bovenaan het paneel, op volgorde van urgentie.
 *
 * @return array{0:string,1:string} [ 'ok'|'bad'|'none', label ].
 */
function _ww_mail_panel_status(): array {
	if ( '' !== _ww_mail_foreign_mailer() ) {
		return array( 'none', __( 'WP Mail SMTP verstuurt de mail', 'webwerckt-base' ) );
	}
	$id        = sanitize_key( _ww_mail_transport_id() );
	$transport = _ww_mail_transport();
	if ( '' !== $id && null === $transport ) {
		/* translators: %s: id van de aansluiting. */
		return array( 'bad', sprintf( __( 'Aansluiting %s is niet beschikbaar', 'webwerckt-base' ), $id ) );
	}
	if ( null !== $transport ) {
		list( $problem, $field ) = _ww_mail_secret_problem( $id );
		if ( 'unreadable' === $problem ) {
			/* translators: %s: naam van de aansluiting. */
			return array( 'bad', sprintf( __( '%s: gegevens opnieuw invoeren', 'webwerckt-base' ), $transport->label() ) );
		}
		if ( 'missing' === $problem ) {
			/* translators: 1: naam van de aansluiting, 2: naam van het veld. */
			return array( 'bad', sprintf( __( '%1$s: %2$s ontbreekt', 'webwerckt-base' ), $transport->label(), $field ) );
		}
	}
	$failed = _ww_mail_log_ready() ? _ww_mail_failed_unseen()['count'] : 0;
	if ( $failed > 0 ) {
		/* translators: %d: aantal mails. */
		return array( 'bad', sprintf( _n( '%d mail niet verstuurd', '%d mails niet verstuurd', $failed, 'webwerckt-base' ), $failed ) );
	}
	if ( null === $transport ) {
		return array( 'none', __( 'Verstuurt via de server', 'webwerckt-base' ) );
	}
	if ( null !== _ww_mail_constant( 'WW_MAIL_TRANSPORT' ) ) {
		/* translators: %s: naam van de aansluiting, vastgezet in wp-config.php. */
		return array( 'ok', sprintf( __( 'Verstuurt via %s (wp-config.php)', 'webwerckt-base' ), $transport->label() ) );
	}
	/* translators: %s: naam van de aansluiting. */
	return array( 'ok', sprintf( __( 'Verstuurt via %s', 'webwerckt-base' ), $transport->label() ) );
}

/**
 * De stip en de tekst over de aansluiting.
 *
 * @return string Geëscapete HTML.
 */
function _ww_mail_render_status(): string {
	list( $dot, $label ) = _ww_mail_panel_status();
	return '<span class="ww-mail-dot ww-mail-dot--' . esc_attr( $dot ) . '" aria-hidden="true"></span>' . esc_html( $label );
}

/**
 * De tellers achter de onderdelen: bij het logboek de mislukte (ongeziene) mails of anders alle mails, bij de
 * instellingen een uitroepteken als er een geheim onleesbaar is. Eén keer per scherm, voor het zijpaneel en het menu.
 *
 * @return array<string,string> Geëscapete HTML per onderdeel.
 */
function _ww_mail_nav_counts(): array {
	$failed = _ww_mail_log_ready() ? _ww_mail_failed_unseen()['count'] : 0;
	return array(
		'log'      => $failed > 0
			? '<span class="ww-mail-count ww-mail-count--bad">' . esc_html( number_format_i18n( $failed ) ) . '</span>'
			: '<span class="ww-mail-count">' . esc_html( number_format_i18n( _ww_mail_log_counts()['all'] ) ) . '</span>',
		'settings' => array() !== _ww_mail_unreadable_secrets() ? '<span class="ww-mail-count ww-mail-count--warn">!</span>' : '',
	);
}

/**
 * De onderdelen als lijst met links; het actieve krijgt aria-current. Twee vormen: panel (in het zijpaneel, met een
 * Dashicon) en menu (een uitklapper voor mobiel, met het actieve onderdeel in de summary).
 *
 * @param string                    $active  Actief onderdeel (log of settings).
 * @param string                    $variant panel of menu.
 * @param array<string,string>|null $counts  Tellers uit _ww_mail_nav_counts() als de aanroeper ze al heeft, anders null.
 * @return string Geëscapete HTML.
 */
function _ww_mail_render_nav( string $active, string $variant, ?array $counts = null ): string {
	$icons  = array(
		'log'      => 'dashicons-list-view',
		'settings' => 'dashicons-admin-generic',
	);
	$labels = _ww_mail_admin_sections();
	$counts = $counts ?? _ww_mail_nav_counts();
	$items  = '';
	foreach ( $labels as $slug => $label ) {
		$url    = 'log' === $slug ? _ww_mail_log_url() : _ww_mail_settings_url();
		$count  = $counts[ $slug ] ?? '';
		$icon   = 'panel' === $variant ? '<span class="dashicons ' . esc_attr( $icons[ $slug ] ) . '" aria-hidden="true"></span>' : '';
		$items .= '<li><a href="' . esc_url( $url ) . '"' . ( $slug === $active ? ' aria-current="page"' : '' ) . '>' . $icon . '<span class="ww-mail-nav__label">' . esc_html( $label ) . '</span>' . $count . '</a></li>';
	}
	if ( 'panel' === $variant ) {
		return '<ul class="ww-mail-panel__nav">' . $items . '</ul>';
	}
	return '<details class="ww-mail-menu"><summary><span>' . esc_html__( 'Onderdeel', 'webwerckt-base' ) . '</span> <b>' . esc_html( $labels[ $active ] ?? '' ) . '</b></summary><ul>' . $items . '</ul></details>';
}

/**
 * Het kaartje in het paneel: de laatste mail, of dat er nog geen is, met de link naar de testmail.
 *
 * @return string Geëscapete HTML.
 */
function _ww_mail_render_panel_card(): string {
	$latest = _ww_mail_log_latest();
	$link   = '<p><a href="' . esc_url( _ww_mail_settings_url() . '#ww-mail-test' ) . '">' . esc_html__( 'Testmail versturen', 'webwerckt-base' ) . '</a></p>';
	if ( null === $latest ) {
		return '<div class="ww-mail-panel__card"><p><strong>' . esc_html__( 'Nog geen mail verstuurd', 'webwerckt-base' ) . '</strong></p>' . $link . '</div>';
	}
	$date = _ww_mail_log_date( _ww_data_to_string( $latest->created ?? '' ) );
	if ( 'failed' === ( $latest->status ?? '' ) ) {
		/* translators: %s: datum en tijd. */
		$line = '<p class="ww-mail-panel__bad">' . esc_html( sprintf( __( '%s mislukt', 'webwerckt-base' ), $date ) ) . '</p>';
	} else {
		/* translators: %s: datum en tijd. */
		$line = '<p><span class="ww-mail-dot ww-mail-dot--ok" aria-hidden="true"></span>' . esc_html( sprintf( __( '%s verstuurd', 'webwerckt-base' ), $date ) ) . '</p>';
	}
	return '<div class="ww-mail-panel__card"><p><strong>' . esc_html__( 'Laatste mail', 'webwerckt-base' ) . '</strong></p>' . $line . $link . '</div>';
}

/**
 * De meldingen boven een weergave: een vreemde mailer, en per onleesbaar geheim de vraag de gegevens opnieuw in te
 * voeren. Op Instellingen (settings) alleen de vreemde mailer, en zonder link: je staat er al.
 *
 * @param string $where log, detail of settings.
 * @return string Geëscapete HTML.
 */
function _ww_mail_admin_notices( string $where ): string {
	$html = '';
	if ( '' !== _ww_mail_foreign_mailer() ) {
		$link  = 'settings' === $where ? '' : ' <a href="' . esc_url( _ww_mail_settings_url() ) . '">' . esc_html__( 'Naar de instellingen', 'webwerckt-base' ) . '</a>';
		$html .= '<div class="notice notice-warning inline"><p><strong>' . esc_html__( 'WP Mail SMTP verstuurt nu de mail.', 'webwerckt-base' ) . '</strong> ' . esc_html__( 'De aansluiting en de afzender doen niets zolang die plugin aan staat.', 'webwerckt-base' ) . $link . '</p></div>';
	}
	if ( 'settings' === $where ) {
		return $html;
	}
	foreach ( _ww_mail_unreadable_secrets() as $text ) {
		$html .= '<div class="notice notice-error inline"><p>' . esc_html( $text ) . ' <a href="' . esc_url( _ww_mail_settings_url() ) . '">' . esc_html__( 'Gegevens invoeren', 'webwerckt-base' ) . '</a></p></div>';
	}
	return $html;
}

/**
 * Het logboek: kop, meldingen, weergaven met zoekveld en de tabel met bulkacties, als string.
 *
 * @return string Geëscapete HTML.
 */
function _ww_mail_render_log(): string {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
	require_once __DIR__ . '/class-ww-mail-log-list-table.php';

	ob_start();
	echo '<h1 class="wp-heading-inline">' . esc_html__( 'Logboek', 'webwerckt-base' ) . '</h1>';
	echo '<hr class="wp-header-end">';
	settings_errors( 'ww_mail_log' );
	echo _ww_mail_admin_notices( 'log' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_mail_admin_notices() escapet.
	if ( ! _ww_mail_log_ready() ) {
		echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'Het logboek is nog niet klaar voor gebruik. Open dit scherm opnieuw.', 'webwerckt-base' ) . '</p></div>';
		return (string) ob_get_clean();
	}

	$table = new WW_Mail_Log_List_Table();
	$table->prepare_items();
	$status = $table->get_status_filter();
	$keep   = array_filter(
		array(
			'status' => $status,
			's'      => $table->get_search_term(),
		),
		static fn( string $value ): bool => '' !== $value
	);

	echo '<p>' . esc_html__( 'Het logboek houdt 30 dagen bij. Bijlagen zelf worden niet bewaard, alleen hun naam.', 'webwerckt-base' ) . '</p>';

	echo '<form method="get" class="ww-mail-views-row">';
	echo '<input type="hidden" name="page" value="' . esc_attr( WW_MAIL_LOG_PAGE ) . '">';
	if ( '' !== $status ) {
		echo '<input type="hidden" name="status" value="' . esc_attr( $status ) . '">';
	}
	$table->views();
	$table->search_box( __( 'Zoeken', 'webwerckt-base' ), 'ww-mail-log' );
	echo '</form>';

	echo '<form method="post" action="' . esc_url( _ww_mail_log_url( $keep ) ) . '">';
	$table->display();
	// Na de tabel, zodat de nonce van de tabel zelf (bulk-…, veldnaam _wpnonce) niet in de weg zit: elke actie heeft een eigen veld.
	foreach ( array( 'bulk-resend', 'bulk-delete' ) as $action ) {
		wp_nonce_field( 'ww_mail_log_' . $action, '_ww_nonce_' . $action, false );
	}
	echo '</form>';
	return (string) ob_get_clean();
}

/**
 * Verstuurd of Mislukt, als chip.
 *
 * @param string $status sent of failed.
 * @return string Geëscapete HTML.
 */
function _ww_mail_status_chip( string $status ): string {
	if ( 'sent' === $status ) {
		return '<span class="ww-mail-chip ww-mail-chip--good">' . esc_html__( 'Verstuurd', 'webwerckt-base' ) . '</span>';
	}
	return '<span class="ww-mail-chip ww-mail-chip--bad">' . esc_html__( 'Mislukt', 'webwerckt-base' ) . '</span>';
}

/**
 * De bladerknoppen van het detail: Nieuwer en Ouder, als link of, aan de rand van het logboek, uitgeschakeld.
 *
 * @param int $id Id van de regel.
 * @return string Geëscapete HTML.
 */
function _ww_mail_render_pager( int $id ): string {
	$neighbors = _ww_mail_log_neighbors( $id );
	$buttons   = array(
		'newer' => __( '‹ Nieuwer', 'webwerckt-base' ),
		'older' => __( 'Ouder ›', 'webwerckt-base' ),
	);
	$html      = '<div class="ww-mail-pager">';
	foreach ( $buttons as $key => $label ) {
		if ( $neighbors[ $key ] > 0 ) {
			$html .= '<a class="button" href="' . esc_url( _ww_mail_log_url( array( 'id' => (string) $neighbors[ $key ] ) ) ) . '">' . esc_html( $label ) . '</a>';
		} else {
			$html .= '<span class="button disabled" aria-disabled="true">' . esc_html( $label ) . '</span>';
		}
	}
	return $html . '</div>';
}

/**
 * De adresregels van het bericht (Van, Aan, CC, BCC, Antwoord naar, Onderwerp); alleen de gevulde.
 *
 * @param object $row Gedecodeerde regel.
 * @return string Geëscapete HTML.
 */
function _ww_mail_render_envelope( object $row ): string {
	$list   = static fn( array $addresses ): string => implode( ', ', array_filter( $addresses, 'is_string' ) );
	$fields = array(
		array( __( 'Van', 'webwerckt-base' ), (string) $row->headers['from'] ),
		array( __( 'Aan', 'webwerckt-base' ), $list( $row->recipients['to'] ) ),
		array( __( 'CC', 'webwerckt-base' ), $list( $row->recipients['cc'] ) ),
		array( __( 'BCC', 'webwerckt-base' ), $list( $row->recipients['bcc'] ) ),
		array( __( 'Antwoord naar', 'webwerckt-base' ), $list( $row->headers['reply_to'] ) ),
		array( __( 'Onderwerp', 'webwerckt-base' ), (string) $row->subject ),
	);
	$html   = '<dl class="ww-mail-envelope">';
	foreach ( $fields as $field ) {
		if ( '' !== $field[1] ) {
			$html .= '<dt>' . esc_html( $field[0] ) . '</dt><dd>' . esc_html( $field[1] ) . '</dd>';
		}
	}
	return $html . '</dl>';
}

/**
 * De zijkolom van het detail: Acties (opnieuw versturen met uitleg, verwijderen met bevestiging) en Technische gegevens.
 *
 * @param object $row Gedecodeerde regel.
 * @return string Geëscapete HTML.
 */
function _ww_mail_render_detail_side( object $row ): string {
	$id          = (int) $row->id;
	$failed      = 'sent' !== $row->status;
	$attachments = array_values( array_filter( (array) $row->attachments, 'is_string' ) );
	$to          = implode( ', ', array_filter( $row->recipients['to'], 'is_string' ) );
	$from        = _ww_mail_from_address();
	$from        = '' !== $from ? $from : _ww_mail_wordpress_from();

	$explain = sprintf(
		/* translators: 1: recipients of the original mail, 2: the From address of now. */
		__( 'Gaat opnieuw naar %1$s, vanaf het Van-adres van nu (%2$s). De nieuwe mail komt als eigen regel in het logboek.', 'webwerckt-base' ),
		'' !== $to ? $to : '—',
		$from
	);
	if ( array() !== $attachments ) {
		$explain .= ' ' . __( 'Bijlagen gaan niet mee.', 'webwerckt-base' );
	}

	$html  = '<aside class="ww-mail-detail__side">';
	$html .= '<section class="postbox"><h2 class="hndle">' . esc_html__( 'Acties', 'webwerckt-base' ) . '</h2><div class="inside">';
	$html .= '<p><a class="button' . ( $failed ? ' button-primary' : '' ) . '" href="' . esc_url( _ww_mail_log_action_url( 'resend', array( 'id' => (string) $id ) ) ) . '">' . esc_html__( 'Opnieuw versturen', 'webwerckt-base' ) . '</a></p>';
	$html .= '<p class="description">' . esc_html( $explain ) . '</p>';
	$html .= '<details class="ww-mail-confirm"><summary class="button ww-mail-button-delete">' . esc_html__( 'Verwijderen', 'webwerckt-base' ) . '</summary>';
	$html .= '<p>' . esc_html__( 'Deze regel definitief verwijderen? Dit kan niet ongedaan worden gemaakt.', 'webwerckt-base' ) . '</p>';
	$html .= '<p><a class="button ww-mail-button-delete" href="' . esc_url( _ww_mail_log_action_url( 'delete', array( 'id' => (string) $id ) ) ) . '">' . esc_html__( 'Verwijderen', 'webwerckt-base' ) . '</a></p>';
	$html .= '</details></div></section>';

	$origin       = (int) $row->resent_of;
	$origin_row   = $origin > 0 ? _ww_mail_log_get( $origin ) : null;
	$origin_label = '';
	if ( $origin > 0 ) {
		if ( null !== $origin_row ) {
			/* translators: %s: date and time of the original mail. */
			$text         = sprintf( __( 'Mail van %s', 'webwerckt-base' ), _ww_mail_log_date( (string) $origin_row->created ) );
			$origin_label = '<a href="' . esc_url( _ww_mail_log_url( array( 'id' => (string) $origin ) ) ) . '">' . esc_html( $text ) . '</a>';
		} else {
			$origin_label = esc_html__( 'Een verwijderde mail', 'webwerckt-base' );
		}
	}
	$content_type = (string) $row->headers['content_type'];
	$provider_id  = (string) $row->provider_id;
	$dash         = '&mdash;';

	$html .= '<section class="postbox"><h2 class="hndle">' . esc_html__( 'Technische gegevens', 'webwerckt-base' ) . '</h2><div class="inside"><dl class="ww-mail-tech">';
	$html .= '<dt>' . esc_html__( 'Opmaak', 'webwerckt-base' ) . '</dt><dd>' . ( '' !== $content_type ? esc_html( $content_type ) : $dash ) . '</dd>';
	$html .= '<dt>' . esc_html__( 'Id bij de aansluiting', 'webwerckt-base' ) . '</dt><dd>' . ( '' !== $provider_id ? '<code>' . esc_html( $provider_id ) . '</code>' : $dash ) . '</dd>';
	if ( '' !== $origin_label ) {
		$html .= '<dt>' . esc_html__( 'Opnieuw verstuurd van', 'webwerckt-base' ) . '</dt><dd>' . $origin_label . '</dd>';
	}
	$html .= '</dl></div></section></aside>';
	return $html;
}

/**
 * Het detail van één regel, of de melding dat hij niet bestaat, als string: terug-link, kop met bladeren, meldingen,
 * het bericht en de zijkolom. Alles uit de log wordt ge-escaped; de tekst staat in een <pre>.
 *
 * @param int $id Id van de regel.
 * @return string Geëscapete HTML.
 */
function _ww_mail_render_detail( int $id ): string {
	$html = '<p class="ww-mail-back"><a href="' . esc_url( _ww_mail_log_url() ) . '">' . esc_html__( '← Terug naar het logboek', 'webwerckt-base' ) . '</a></p>';
	if ( ! _ww_mail_log_ready() ) {
		return $html . '<div class="notice notice-warning inline"><p>' . esc_html__( 'Het logboek is nog niet klaar voor gebruik. Open dit scherm opnieuw.', 'webwerckt-base' ) . '</p></div>';
	}
	$row = _ww_mail_log_get( $id );
	if ( null === $row ) {
		return $html . '<h1 class="wp-heading-inline">' . esc_html__( 'Logboek', 'webwerckt-base' ) . '</h1><hr class="wp-header-end"><div class="notice notice-error inline"><p>' . esc_html__( 'Deze regel bestaat niet (meer).', 'webwerckt-base' ) . '</p></div>';
	}
	$id          = (int) $row->id;
	$subject     = '' !== (string) $row->subject ? (string) $row->subject : __( '(geen onderwerp)', 'webwerckt-base' );
	$message     = (string) $row->message;
	$attachments = array_values( array_filter( (array) $row->attachments, 'is_string' ) );

	$html .= '<div class="ww-mail-detail-head"><h1>' . esc_html( $subject ) . '</h1>' . _ww_mail_render_pager( $id ) . '</div><hr class="wp-header-end">';
	$html .= '<p class="ww-mail-meta">' . _ww_mail_status_chip( (string) $row->status ) . ' <span>' . esc_html( _ww_mail_log_date( (string) $row->created ) ) . '</span> <span>' . esc_html(
		/* translators: %s: name of the connection the mail went through. */
		sprintf( __( 'via %s', 'webwerckt-base' ), _ww_mail_log_transport_label( (string) $row->transport ) )
	) . '</span></p>';

	$html .= _ww_mail_admin_notices( 'detail' );
	if ( 'sent' !== $row->status ) {
		$error = (string) $row->error;
		$html .= '<div class="notice notice-error inline"><p><strong>' . esc_html__( 'Niet verstuurd.', 'webwerckt-base' ) . '</strong> ' . ( '' !== $error ? esc_html( $error ) . ' ' : '' )
			. sprintf(
				/* translators: %s: link to the settings, labelled Instellingen. */
				esc_html__( 'Controleer de aansluiting bij %s en verstuur de mail daarna opnieuw.', 'webwerckt-base' ),
				'<a href="' . esc_url( _ww_mail_settings_url() ) . '">' . esc_html__( 'Instellingen', 'webwerckt-base' ) . '</a>'
			) . '</p></div>';
	}

	$html .= '<div class="ww-mail-detail"><div class="ww-mail-detail__main"><section class="postbox"><h2 class="hndle">' . esc_html__( 'Bericht', 'webwerckt-base' ) . '</h2><div class="inside">';
	$html .= _ww_mail_render_envelope( $row );
	$html .= '<pre class="ww-mail-body">' . ( '' !== $message ? esc_html( $message ) : '&mdash;' ) . '</pre>';
	if ( array() !== $attachments ) {
		$html .= '<p class="ww-mail-attachments">';
		foreach ( $attachments as $name ) {
			$html .= '<span class="ww-mail-chip">' . esc_html( $name ) . '</span> ';
		}
		$html .= '<span class="description">' . esc_html__( 'Alleen de naam is bewaard.', 'webwerckt-base' ) . '</span></p>';
	}
	$html .= '</div></section></div>';
	$html .= _ww_mail_render_detail_side( $row );
	return $html . '</div>';
}

/**
 * De gekozen weergave zonder paneel, als string. De router (_ww_mail_admin_view) beslist; hier wordt niets herlezen
 * behalve het id van het detail.
 *
 * @param string $view log, detail of settings.
 */
function _ww_mail_admin_render_view( string $view ): string {
	if ( 'settings' === $view ) {
		ob_start();
		_ww_mail_render_settings();
		return (string) ob_get_clean();
	}
	if ( 'detail' === $view ) {
		$id = isset( $_GET['id'] ) ? absint( _ww_data_to_string( wp_unslash( $_GET['id'] ) ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen een regel bekijken.
		return _ww_mail_render_detail( $id );
	}
	return _ww_mail_render_log();
}

/**
 * De callback van de menupagina: het zijpaneel en de gekozen weergave.
 */
function _ww_mail_admin_render(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Je hebt geen rechten om Mail te beheren.', 'webwerckt-base' ), 403 );
	}
	$view    = _ww_mail_admin_view();
	$section = 'settings' === $view ? 'settings' : 'log';

	// De weergave eerst: de tabellen lezen hun query vóór de kop er staat, en zo staat alles in één volgorde.
	$content = _ww_mail_admin_render_view( $view );

	echo '<div class="wrap ww-mail"><div class="ww-mail-layout">';

	echo '<nav class="ww-mail-panel" aria-label="' . esc_attr__( 'Onderdelen van Mail', 'webwerckt-base' ) . '">';
	echo '<p class="ww-mail-panel__title">' . esc_html__( 'Mail', 'webwerckt-base' ) . '</p>';
	// Status en tellers één keer: het zijpaneel en de kop voor mobiel tonen hetzelfde.
	$status = _ww_mail_render_status();
	$counts = _ww_mail_nav_counts();

	echo '<p class="ww-mail-panel__status">' . $status . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_mail_render_status() escapet.
	echo _ww_mail_render_nav( $section, 'panel', $counts ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_mail_render_nav() escapet.
	echo _ww_mail_render_panel_card(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_mail_render_panel_card() escapet.
	echo '<p class="ww-mail-panel__foot"><span class="dashicons dashicons-info-outline" aria-hidden="true"></span><span>' . esc_html__( 'Het logboek bewaart 30 dagen: adressen, onderwerp, tekst en de namen van bijlagen.', 'webwerckt-base' ) . '</span></p>';
	echo '</nav>';

	echo '<div class="ww-mail-main">';
	echo '<div class="ww-mail-pickers">' . _ww_mail_render_nav( $section, 'menu', $counts ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_mail_render_nav() escapet.
	echo '<p class="ww-mail-status-line">' . $status . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_mail_render_status() escapet.
	echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- de weergaven escapen zelf.
	echo '</div>';

	echo '</div></div>';
}

/**
 * Laadt de stijl van het scherm, alleen op de menupagina Mail.
 *
 * @param string $hook Hook van het scherm.
 */
function _ww_mail_admin_assets( string $hook ): void {
	if ( 'toplevel_page_' . WW_MAIL_LOG_PAGE !== $hook ) {
		return;
	}
	wp_enqueue_style( 'ww-mail-admin', _ww_asset_url( 'css/mail-admin.css' ), array(), WW_BASE_VERSION );
	if ( 'settings' === _ww_mail_admin_view() ) {
		wp_enqueue_script( 'ww-mail-admin', _ww_asset_url( 'js/mail-admin.js' ), array(), WW_BASE_VERSION, array( 'in_footer' => true ) );
	}
}
add_action( 'admin_enqueue_scripts', '_ww_mail_admin_assets' );
