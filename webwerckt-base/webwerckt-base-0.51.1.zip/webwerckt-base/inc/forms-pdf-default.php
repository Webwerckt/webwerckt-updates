<?php
/**
 * Formulieren: de ingebouwde standaardopmaak van de PDF. Geen sjabloonbestand en niet te overschrijven; hij wordt
 * gebruikt als het formulier geen sjabloon heeft of het sjabloon uit het child-thema ontbreekt. Hij laat ook zien hoe
 * een sjabloon moet ontsnappen: alle tekst uit `$pdf` gaat door _ww_form_pdf_text() (of esc_html() in een eigen
 * sjabloon).
 *
 * Dompdf kent geen flex of grid; de opmaak gebruikt alleen tabellen.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tekst als HTML-tekst, met alle entiteiten opnieuw ontsnapt. Anders dan esc_html() laat dit een ingetypte `&lt;`
 * niet staan (die zou in de PDF als `<` verschijnen), zodat de PDF precies toont wat er is ingevuld.
 *
 * @param string $text Tekst, bijvoorbeeld een antwoord van de bezoeker.
 */
function _ww_form_pdf_text( string $text ): string {
	return htmlspecialchars( $text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8', true );
}

/**
 * De HTML van de standaard-PDF: logo (als dat er is), de naam van het formulier, de datum, per sectie een kop en een
 * tabel met label en antwoord, en een voettekst met de naam van de site en het paginanummer.
 *
 * @param array<string,mixed> $pdf Gegevens uit _ww_form_pdf_data().
 */
function _ww_form_pdf_default_html( array $pdf ): string {
	$form  = _ww_form_array( $pdf['form'] ?? array() );
	$site  = _ww_form_array( $pdf['site'] ?? array() );
	$logo  = _ww_form_string( $site['logo'] ?? '' );
	$title = _ww_form_string( $form['title'] ?? '' );
	$date  = _ww_form_string( $pdf['date'] ?? '' );

	$css = '@page { margin: 18mm 16mm 22mm 16mm; }'
		. 'body { font-family: "DejaVu Sans", sans-serif; font-size: 10pt; color: #222; line-height: 1.4; }'
		. '.kop { width: 100%; border-collapse: collapse; margin-bottom: 8mm; }'
		. '.kop td { vertical-align: bottom; padding: 0; }'
		. '.logo { max-height: 18mm; max-width: 60mm; }'
		. 'h1 { font-size: 16pt; margin: 0 0 1mm 0; }'
		. '.datum { color: #666; font-size: 9pt; }'
		. 'h2 { font-size: 12pt; margin: 6mm 0 2mm 0; }'
		. '.velden { width: 100%; border-collapse: collapse; }'
		. '.velden th, .velden td { text-align: left; vertical-align: top; padding: 1.5mm 2mm; border-bottom: 0.2mm solid #ddd; }'
		. '.velden th { width: 35%; font-weight: bold; }'
		. '.voet { position: fixed; left: 0; right: 0; bottom: -14mm; height: 8mm; font-size: 8pt; color: #666; }'
		. '.voet table { width: 100%; border-collapse: collapse; }'
		. '.voet td { padding: 0; }'
		. '.pagina { text-align: right; }'
		. '.paginanummer:after { content: counter(page); }';

	$html  = '<!DOCTYPE html><html><head><meta charset="utf-8"><title>' . _ww_form_pdf_text( $title ) . '</title>';
	$html .= '<style>' . $css . '</style></head><body>';

	// De voettekst staat vooraan, zodat Dompdf hem op elke pagina zet.
	$html .= '<div class="voet"><table><tr>';
	$html .= '<td>' . _ww_form_pdf_text( _ww_form_string( $site['name'] ?? '' ) ) . '</td>';
	$html .= '<td class="pagina">' . esc_html__( 'Pagina', 'webwerckt-base' ) . ' <span class="paginanummer"></span></td>';
	$html .= '</tr></table></div>';

	$html .= '<table class="kop"><tr><td>';
	$html .= '<h1>' . _ww_form_pdf_text( $title ) . '</h1>';
	if ( '' !== $date ) {
		$html .= '<div class="datum">' . _ww_form_pdf_text( $date ) . '</div>';
	}
	$html .= '</td>';
	if ( str_starts_with( $logo, 'data:image/' ) ) {
		$html .= '<td style="text-align: right;"><img class="logo" src="' . esc_attr( $logo ) . '" alt=""></td>';
	}
	$html .= '</tr></table>';

	foreach ( _ww_form_array( $pdf['sections'] ?? array() ) as $section ) {
		$section = _ww_form_array( $section );
		$heading = _ww_form_string( $section['title'] ?? '' );
		if ( '' !== $heading ) {
			$html .= '<h2>' . _ww_form_pdf_text( $heading ) . '</h2>';
		}
		$html .= '<table class="velden">';
		foreach ( _ww_form_array( $section['fields'] ?? array() ) as $field ) {
			$field  = _ww_form_array( $field );
			$html  .= '<tr><th>' . _ww_form_pdf_text( _ww_form_string( $field['label'] ?? '' ) ) . '</th>';
			$html  .= '<td>' . nl2br( _ww_form_pdf_text( _ww_form_string( $field['display'] ?? '' ) ) ) . '</td></tr>';
		}
		$html .= '</table>';
	}

	return $html . '</body></html>';
}
