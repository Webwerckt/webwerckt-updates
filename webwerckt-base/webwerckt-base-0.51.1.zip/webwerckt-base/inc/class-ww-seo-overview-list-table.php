<?php
/**
 * Tabel met de pagina's op het scherm SEO (inc/seo-overview-admin.php). Wordt pas geladen als dat scherm wordt getoond,
 * na WP_List_Table.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * De pagina's van het overzicht: titel (naar het formulier), soort, taal, meldingen en laatst gewijzigd. Filteren gaat
 * met een gewoon GET-formulier, zonder script.
 */
class WW_Seo_Overview_List_Table extends WP_List_Table {

	/**
	 * Alle rijen van het overzicht, ongefilterd.
	 *
	 * @var list<array<string,mixed>>
	 */
	private array $all_rows;

	/**
	 * De filters van de lijst.
	 *
	 * @var array{view:string,type:string,issue:string,lang:string,orderby:string,order:string,paged:string}
	 */
	private array $args;

	/**
	 * Titel per pagina, voor de link bij een dubbele titel of beschrijving.
	 *
	 * @var array<int,string>
	 */
	private array $titles = array();

	/**
	 * @param list<array<string,mixed>> $rows Rijen van _ww_seo_overview_rows().
	 * @param array<mixed>              $args Filters (_ww_seo_list_args()).
	 */
	public function __construct( array $rows, array $args ) {
		parent::__construct(
			array(
				'singular' => 'ww-seo-page',
				'plural'   => 'ww-seo-pages',
				'ajax'     => false,
				'screen'   => 'toplevel_page_' . WW_SEO_SCREEN,
			)
		);
		$this->all_rows = $rows;
		$this->args     = _ww_seo_clean_list_args( $args );
		foreach ( $rows as $row ) {
			$this->titles[ (int) $row['id'] ] = (string) $row['title'];
		}
	}

	/**
	 * @return array<string,string>
	 */
	public function get_columns() {
		$columns = array(
			'title' => __( 'Pagina', 'webwerckt-base' ),
			'type'  => __( 'Soort', 'webwerckt-base' ),
		);
		if ( _ww_languages_active() ) {
			$columns['language'] = __( 'Taal', 'webwerckt-base' );
		}
		return $columns + array(
			'issues'   => __( 'Meldingen', 'webwerckt-base' ),
			'modified' => __( 'Gewijzigd', 'webwerckt-base' ),
		);
	}

	/**
	 * Standaard staat de lijst op aantal meldingen, de meeste eerst.
	 *
	 * @return array<string,array<int,mixed>>
	 */
	protected function get_sortable_columns() {
		return array(
			'title'    => array( 'title', false ),
			'type'     => array( 'type', false ),
			'issues'   => array( 'issues', true, '', '', 'desc' ),
			'modified' => array( 'modified', true ),
		);
	}

	/**
	 * Filtert, sorteert en neemt de pagina van de lijst.
	 */
	public function prepare_items(): void {
		$rows  = _ww_seo_filtered_rows( $this->args, $this->all_rows );
		$total = count( $rows );
		$pages = max( 1, (int) ceil( $total / WW_SEO_PER_PAGE ) );
		$paged = min( $pages, max( 1, (int) $this->args['paged'] ) );

		$this->_column_headers = array( $this->get_columns(), array(), $this->get_sortable_columns(), 'title' );
		$this->set_pagination_args(
			array(
				'total_items' => $total,
				'per_page'    => WW_SEO_PER_PAGE,
			)
		);
		$this->items = array_slice( $rows, ( $paged - 1 ) * WW_SEO_PER_PAGE, WW_SEO_PER_PAGE );
	}

	/**
	 * Tekst als er geen pagina's zijn.
	 */
	public function no_items(): void {
		esc_html_e( "Geen pagina's gevonden.", 'webwerckt-base' );
	}

	/**
	 * De weergaven Alle, Met melding en In orde, met hun aantal binnen de gekozen filters.
	 *
	 * @return array<string,string>
	 */
	protected function get_views() {
		$rows   = _ww_seo_rows_matching( $this->all_rows, $this->args );
		$issues = count( array_filter( $rows, static fn( array $row ): bool => array() !== $row['issues'] ) );
		$views  = array(
			'all'    => array( __( 'Alle', 'webwerckt-base' ), count( $rows ) ),
			'issues' => array( __( 'Met melding', 'webwerckt-base' ), $issues ),
			'ok'     => array( __( 'In orde', 'webwerckt-base' ), count( $rows ) - $issues ),
		);
		$links  = array();
		foreach ( $views as $view => $data ) {
			$query          = _ww_seo_list_query(
				array(
					'view'  => $view,
					'paged' => '1',
				) + $this->args
			);
			$current        = $view === $this->args['view'];
			$links[ $view ] = '<a href="' . esc_url( _ww_seo_admin_url( $query ) ) . '"' . ( $current ? ' class="current" aria-current="page"' : '' ) . '>' . esc_html( $data[0] ) . ' <span class="count">(' . esc_html( number_format_i18n( $data[1] ) ) . ')</span></a>';
		}
		return $links;
	}

	/**
	 * Zonder bulkacties en zonder nonce: de tabel staat alleen in een GET-formulier voor het paginanummer.
	 *
	 * @param string $which top of bottom.
	 */
	protected function display_tablenav( $which ): void {
		if ( 'bottom' === $which && ! $this->has_items() ) {
			return;
		}
		echo '<div class="tablenav ' . esc_attr( $which ) . '">';
		$this->extra_tablenav( $which );
		$this->pagination( $which );
		echo '<br class="clear"></div>';
	}

	/**
	 * De filters Soort, Melding en Taal (alleen met Meertalig) als keuzelijsten met de knop Filteren.
	 *
	 * @param string $which top of bottom.
	 */
	protected function extra_tablenav( $which ): void {
		if ( 'top' !== $which ) {
			return;
		}
		$types = array();
		foreach ( _ww_seo_admin_post_types() as $type ) {
			$object         = get_post_type_object( $type );
			$types[ $type ] = $object instanceof WP_Post_Type ? (string) $object->labels->name : $type;
		}
		$languages = array();
		if ( _ww_languages_active() ) {
			foreach ( _ww_languages_config()['languages'] as $language ) {
				$languages[ $language['code'] ] = $language['name'];
			}
		}

		// De keuzelijsten en de knop horen bij het formulier ww-seo-filter buiten de tabel (_ww_seo_render_list()): dat
		// houdt de weergave en de sortering, en een nieuwe filter begint op pagina 1.
		echo '<div class="alignleft actions ww-seo-filters">';
		echo $this->select( 'type', __( 'Soort', 'webwerckt-base' ), __( 'Alle soorten', 'webwerckt-base' ), $types ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- select() escapet.
		echo $this->select( 'issue', __( 'Melding', 'webwerckt-base' ), __( 'Alle meldingen', 'webwerckt-base' ), _ww_seo_issue_labels() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- select() escapet.
		if ( array() !== $languages ) {
			echo $this->select( 'lang', __( 'Taal', 'webwerckt-base' ), __( 'Alle talen', 'webwerckt-base' ), $languages ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- select() escapet.
		}
		echo '<button type="submit" class="button" form="ww-seo-filter">' . esc_html__( 'Filteren', 'webwerckt-base' ) . '</button>';
		echo '</div>';
	}

	/**
	 * Een keuzelijst met een label voor schermlezers.
	 *
	 * @param string               $name    Naam van het veld.
	 * @param string               $label   Label.
	 * @param string               $all     De keuze zonder filter.
	 * @param array<string,string> $options Waarde => tekst.
	 * @return string Geëscapete HTML.
	 */
	private function select( string $name, string $label, string $all, array $options ): string {
		$id   = 'ww-seo-filter-' . $name;
		$html = '<label class="screen-reader-text" for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label>';
		$html .= '<select id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" form="ww-seo-filter"><option value="">' . esc_html( $all ) . '</option>';
		foreach ( $options as $value => $text ) {
			$html .= '<option value="' . esc_attr( (string) $value ) . '"' . selected( $this->args[ $name ], (string) $value, false ) . '>' . esc_html( $text ) . '</option>';
		}
		return $html . '</select>';
	}

	/**
	 * Link naar het formulier van een pagina, met de filters van de lijst.
	 *
	 * @param int $id Post-ID.
	 */
	private function form_url( int $id ): string {
		return _ww_seo_form_url( $id, $this->args );
	}

	/**
	 * De titel als link naar het formulier.
	 *
	 * @param array<string,mixed> $item Rij.
	 */
	protected function column_title( $item ): string {
		return '<strong><a class="row-title" href="' . esc_url( $this->form_url( (int) $item['id'] ) ) . '">' . esc_html( _ww_seo_plain_title( (string) $item['title'] ) ) . '</a></strong>';
	}

	/**
	 * De rij-actie Bekijken onder de titel. Hier en niet in column_title(), anders zet WordPress de uitklapknop voor
	 * mobiel er twee keer.
	 *
	 * @param array<string,mixed> $item        Rij.
	 * @param string              $column_name Kolom.
	 * @param string              $primary     Hoofdkolom.
	 */
	protected function handle_row_actions( $item, $column_name, $primary ): string {
		if ( $primary !== $column_name ) {
			return '';
		}
		$actions = array();
		$link    = get_permalink( (int) $item['id'] );
		if ( is_string( $link ) && '' !== $link ) {
			$actions['view'] = '<a href="' . esc_url( $link ) . '" target="_blank" rel="noopener">' . esc_html__( 'Bekijken', 'webwerckt-base' ) . '<span class="screen-reader-text"> ' . esc_html__( '(opent in een nieuw tabblad)', 'webwerckt-base' ) . '</span></a>';
		}
		return $this->row_actions( $actions );
	}

	/**
	 * Het post type, enkelvoud.
	 *
	 * @param array<string,mixed> $item Rij.
	 */
	protected function column_type( $item ): string {
		$object = get_post_type_object( (string) $item['type'] );
		return esc_html( $object instanceof WP_Post_Type ? (string) $object->labels->singular_name : (string) $item['type'] );
	}

	/**
	 * De taal, met de naam uit de instellingen van Meertalig.
	 *
	 * @param array<string,mixed> $item Rij.
	 */
	protected function column_language( $item ): string {
		$language = _ww_language( (string) $item['language'] );
		return esc_html( null === $language ? (string) $item['language'] : $language['name'] );
	}

	/**
	 * De meldingen als labels (_ww_seo_render_issue_labels(), ook in het formulier).
	 *
	 * @param array<string,mixed> $item Rij.
	 */
	protected function column_issues( $item ): string {
		return _ww_seo_render_issue_labels( $item, $this->titles, $this->args );
	}

	/**
	 * De datum van de laatste wijziging.
	 *
	 * @param array<string,mixed> $item Rij.
	 */
	protected function column_modified( $item ): string {
		return esc_html( (string) mysql2date( (string) get_option( 'date_format' ), (string) $item['modified'] ) );
	}
}
