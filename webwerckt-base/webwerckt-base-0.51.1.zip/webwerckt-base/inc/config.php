<?php
/**
 * De veldconfiguratie van parent en child-thema: de JSON-bestanden in pods/, in het formaat van Pods. Dit is kern,
 * geen integratie: de frontend (inc/data.php, inc/helpers.php), de abilities en Visueel bewerken lezen hieruit,
 * zonder Pods. Het thema registreert niets bij Pods; opslaan doet inc/field-store.php.
 *
 * Elk bestand beschrijft één pod met zijn groepen en velden. De parent levert de Site-instellingen,
 * de tekstpagina, de blogberichten en de velden van de gekozen standaard post types; het child-thema zet zijn eigen
 * bestanden in pods/. Pods leest zelf alleen pods.json, en een tweede bestand voor dezelfde pod vervangt
 * daar de eerste. Daarom voegt de parent alle bestanden per pod samen; het child-thema kan daarbij alleen
 * aanvullen (_ww_pods_merge()). Het formaat blijft dat van Pods, ook nu het thema Pods niet meer gebruikt (0055).
 *
 * Alle groepen en velden uit het child-thema beginnen met `child_` (_ww_child_prefix()); andere slaat de parent over.
 *
 * Veldgroepen met een naam `template_{naam}` (in het child-thema `child_template_{naam}`) verschijnen alleen
 * bij dat paginatemplate: `child_template_home` bij page-home.php, `template_default` bij het standaardtemplate.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Is dit een bestandsnaam die Pods zelf inleest (pods.json, pods-groups.json)? Die slaat de parent over.
 */
function _ww_pods_is_reserved_file( string $file ): bool {
	return 1 === preg_match( '/^pods(-[a-z]+)?\.(json|yml)$/', basename( $file ) );
}

/**
 * Configuratiebestanden in laadvolgorde: eerst de parent, dan het child-thema.
 *
 * @return string[]
 */
function _ww_pods_config_files(): array {
	$parent = get_template_directory() . '/pods/';
	$files  = array( $parent . 'settings.json', $parent . 'page.json', $parent . 'post.json' );
	foreach ( _ww_used_post_types() as $post_type ) {
		$files[] = $parent . $post_type . '.json';
	}

	if ( _ww_has_child_theme() ) {
		$files = array_merge( $files, glob( get_stylesheet_directory() . '/pods/*.json' ) ?: array() );
	}

	return array_values(
		array_filter(
			$files,
			static fn( string $file ): bool => is_readable( $file ) && ! _ww_pods_is_reserved_file( $file )
		)
	);
}

/**
 * Voegt pod-configuraties samen per type en naam. Een later bestand vult alleen aan, het vervangt nooit:
 *
 * - instellingen van de pod (zoals het label) die er al zijn, blijven staan; nieuwe komen erbij;
 * - een groep met een naam die de pod al heeft, wordt overgeslagen;
 * - een veld met een naam die de pod al heeft (in welke groep ook), wordt overgeslagen.
 *
 * Omdat de parent eerst laadt, kan het child-thema zo geen velden of groepen van de parent vervangen,
 * alleen een eigen groep (een extra box) toevoegen. Velden staan altijd in een groep.
 *
 * @param array<int|string,mixed> $configs Gedecodeerde bestanden, met het bestandspad als sleutel.
 * @return array<int,array<string,mixed>>
 */
function _ww_pods_merge( array $configs ): array {
	$pods = array();
	foreach ( $configs as $source => $config ) {
		$type = is_array( $config ) ? _ww_data_to_string( $config['type'] ?? '' ) : '';
		$name = is_array( $config ) ? _ww_data_to_string( $config['name'] ?? '' ) : '';
		if ( '' === $type || '' === $name ) {
			continue;
		}

		$key    = $type . ':' . $name;
		$groups = is_array( $config['groups'] ?? null ) ? $config['groups'] : array();
		if ( isset( $config['fields'] ) ) {
			_ww_pods_skipped( (string) $source, 'velden staan altijd in een groep; losse velden van pod ' . $name . ' zijn overgeslagen' );
		}
		unset( $config['groups'], $config['fields'] );

		$pods[ $key ] = ( $pods[ $key ] ?? array( 'groups' => array() ) ) + $config;
		foreach ( array_filter( $groups, 'is_array' ) as $group ) {
			$group = _ww_pods_new_group( $pods[ $key ], $group, (string) $source );
			if ( null !== $group ) {
				$pods[ $key ]['groups'][] = $group;
			}
		}
	}
	return array_values( $pods );
}

/**
 * De groep zonder velden die de pod al heeft, of null als de pod de groep al heeft (of hij geen naam heeft).
 *
 * @param array<string,mixed> $pod    Pod tot nu toe.
 * @param array<string,mixed> $group  Nieuwe groep.
 * @param string              $source Bestand, voor de melding.
 * @return array<string,mixed>|null
 */
function _ww_pods_new_group( array $pod, array $group, string $source ): ?array {
	$name = _ww_data_to_string( $group['name'] ?? '' );
	if ( '' === $name ) {
		return null;
	}
	if ( in_array( $name, array_column( $pod['groups'], 'name' ), true ) ) {
		_ww_pods_skipped( $source, sprintf( 'groep %s bestaat al in pod %s', $name, $pod['name'] ) );
		return null;
	}

	$taken  = _ww_pods_field_names( $pod );
	$fields = array();
	foreach ( _ww_pods_valid_fields( $group ) as $field ) {
		$field_name = _ww_data_to_string( $field['name'] ?? '' );
		if ( in_array( $field_name, $taken, true ) ) {
			_ww_pods_skipped( $source, sprintf( 'veld %s bestaat al in pod %s', $field_name, $pod['name'] ) );
			continue;
		}
		$taken[]  = $field_name;
		$fields[] = $field;
	}

	$group['fields'] = $fields;
	return $group;
}

/**
 * Namen van alle velden in de groepen van een pod.
 *
 * @param array<string,mixed> $pod
 * @return string[]
 */
function _ww_pods_field_names( array $pod ): array {
	return array_map( static fn( array $field ): string => _ww_data_to_string( $field['name'] ?? '' ), _ww_pods_groups_fields( $pod['groups'] ) );
}

/**
 * Alle velden van deze groepen achter elkaar, in hun volgorde. De groepen komen uit _ww_pods_config(), dus elke
 * groep heeft een lijst fields.
 *
 * @param array<int,array<string,mixed>> $groups
 * @return array<int,array<string,mixed>>
 */
function _ww_pods_groups_fields( array $groups ): array {
	return array_merge( ...array_column( $groups, 'fields' ) );
}

/**
 * De velden van een groep uit een configuratiebestand: alleen als het een lijst is, en alleen de velden die een
 * array zijn. Een bestand is invoer van het child-thema en kan alles bevatten.
 *
 * @param array<string,mixed> $group
 * @return array<int|string,array<string,mixed>>
 */
function _ww_pods_valid_fields( array $group ): array {
	return is_array( $group['fields'] ?? null ) ? array_filter( $group['fields'], 'is_array' ) : array();
}

/**
 * De meldingen die _ww_pods_config() tijdens het samenvoegen verzamelt, voor het overzicht van de beheerder.
 *
 * @param array<int,array{file:string,reason:string}>|null $set Met een waarde: vervang de lijst.
 * @return array<int,array{file:string,reason:string}>
 */
function _ww_pods_notices_buffer( ?array $set = null ): array {
	static $buffer = array();
	if ( null !== $set ) {
		$buffer = $set;
	}
	return $buffer;
}

/**
 * Onthoudt dat een deel van een configuratiebestand is overgeslagen of afwijkt.
 */
function _ww_pods_notice( string $source, string $reason ): void {
	$notice = array(
		'file'   => basename( $source ),
		'reason' => $reason,
	);
	$all    = _ww_pods_notices_buffer();
	if ( ! in_array( $notice, $all, true ) ) {
		$all[] = $notice;
		_ww_pods_notices_buffer( $all );
	}
}

/**
 * Alles wat bij het samenvoegen van de configuratie is overgeslagen of gemeld, plus bestanden met ongeldige JSON,
 * voor de huidige configuratie. Leest de configuratie zo nodig eerst in.
 *
 * @return array<int,array{file:string,reason:string}>
 */
function _ww_pods_config_notices(): array {
	_ww_pods_config();
	return _ww_pods_notices_store()[ _ww_pods_config_key() ] ?? array();
}

/**
 * De meldingen per sleutel van de configuratie (_ww_pods_config_key()).
 *
 * @param string|null                                      $key Met een sleutel en lijst: bewaar die.
 * @param array<int,array{file:string,reason:string}>|null $set Lijst bij die sleutel.
 * @return array<string,array<int,array{file:string,reason:string}>>
 */
function _ww_pods_notices_store( ?string $key = null, ?array $set = null ): array {
	static $store = array();
	if ( null !== $key && null !== $set ) {
		$store[ $key ] = $set;
	}
	return $store;
}

/**
 * Meldt (met WP_DEBUG aan) dat een deel van een configuratiebestand is overgeslagen.
 */
function _ww_pods_skipped( string $source, string $reason ): void {
	_ww_pods_notice( $source, $reason );
	_doing_it_wrong(
		'_ww_pods_merge',
		esc_html( sprintf( 'Pods-configuratie %s: %s. Een later bestand kan alleen aanvullen, niet vervangen.', basename( $source ), $reason ) ),
		'0.1.0'
	);
}

/**
 * Is er een child-thema? Niet is_child_theme(): die leest globals die alleen bij het laden van WordPress worden gezet,
 * en ziet zo het filter stylesheet_directory niet waarmee de tests een child-thema nabootsen.
 */
function _ww_has_child_theme(): bool {
	return get_stylesheet_directory() !== get_template_directory();
}

/**
 * Begint deze naam met het child-voorvoegsel?
 */
function _ww_has_child_prefix( string $name ): bool {
	return str_starts_with( $name, _ww_child_prefix() ) && strlen( $name ) > strlen( _ww_child_prefix() );
}

/**
 * Configuratie uit het child-thema zonder groepen en velden die niet met `child_` beginnen.
 *
 * @param mixed  $config Gedecodeerd bestand.
 * @param string $source Bestand, voor de melding.
 * @return mixed
 */
function _ww_pods_child_config( $config, string $source ) {
	if ( ! is_array( $config ) || ! is_array( $config['groups'] ?? null ) ) {
		return $config;
	}

	$groups = array();
	foreach ( array_filter( $config['groups'], 'is_array' ) as $group ) {
		$name = _ww_data_to_string( $group['name'] ?? '' );
		if ( ! _ww_has_child_prefix( $name ) ) {
			_ww_pods_skipped( $source, sprintf( 'groep %s begint niet met %s', $name, _ww_child_prefix() ) );
			continue;
		}

		$fields = array();
		foreach ( _ww_pods_valid_fields( $group ) as $field ) {
			$field_name = _ww_data_to_string( $field['name'] ?? '' );
			if ( _ww_has_child_prefix( $field_name ) ) {
				$fields[] = $field;
			} else {
				_ww_pods_skipped( $source, sprintf( 'veld %s begint niet met %s', $field_name, _ww_child_prefix() ) );
			}
		}
		$group['fields'] = $fields;
		_ww_pods_check_sections( $group, $source );
		$groups[] = $group;
	}

	$config['groups'] = $groups;
	return $config;
}

/**
 * Meldt (met WP_DEBUG aan) dat een child-thema de regel voor secties niet volgt. Verandert niets.
 */
function _ww_pods_warn( string $source, string $reason ): void {
	_ww_pods_notice( $source, $reason );
	_doing_it_wrong(
		'_ww_pods_child_config',
		esc_html( sprintf( 'Pods-configuratie %s: %s.', basename( $source ), $reason ) ),
		'0.18.0'
	);
}

/**
 * Controleert of een templategroep één sectie bevat. De visuele bewerker toont één groep per menu-item, dus
 * paginavelden horen in een groep per sectie: child_template_{template}_{sectie}, met velden child_{sectie}_*.
 *
 * @param array<string,mixed> $group  Groep, met alleen goedgekeurde velden.
 * @param string              $source Bestand, voor de melding.
 */
function _ww_pods_check_sections( array $group, string $source ): void {
	$name = _ww_data_to_string( $group['name'] ?? '' );
	$bare = (string) preg_replace( '/^' . preg_quote( _ww_child_prefix(), '/' ) . '/', '', $name );
	if ( ! str_starts_with( $bare, 'template_' ) ) {
		return;
	}

	$rest   = substr( $bare, strlen( 'template_' ) );
	$fields = array_map(
		static fn( array $field ): string => _ww_data_to_string( $field['name'] ?? '' ),
		_ww_pods_valid_fields( $group )
	);

	if ( str_contains( $rest, '_' ) ) {
		$section = substr( $rest, (int) strpos( $rest, '_' ) + 1 );
		$expect  = _ww_child_prefix() . $section;
		foreach ( $fields as $field ) {
			// Zoals de visuele bewerker: child_{sectie} zelf (een relatie) of child_{sectie}_*.
			if ( $field !== $expect && ! str_starts_with( $field, $expect . '_' ) ) {
				_ww_pods_warn( $source, sprintf( 'veld %s hoort niet bij sectie %s van groep %s', $field, $section, $name ) );
			}
		}
		return;
	}

	$sections = array();
	foreach ( $fields as $field ) {
		if ( 1 === preg_match( '/^' . preg_quote( _ww_child_prefix(), '/' ) . '(.+)_enabled$/', $field, $match ) ) {
			$sections[] = $match[1];
		}
	}
	$sections = array_values( array_unique( $sections ) );
	if ( count( $sections ) >= 2 ) {
		_ww_pods_warn(
			$source,
			sprintf(
				'groep %1$s heeft velden van de secties %2$s; verdeel ze in een groep per sectie (%3$stemplate_%4$s_{sectie})',
				$name,
				implode( ', ', $sections ),
				_ww_child_prefix(),
				$rest
			)
		);
	}
}

/**
 * De sleutel van de cache van _ww_pods_config(): alles waar de samengevoegde configuratie van afhangt. De lijst met
 * bestanden verandert met de gekozen post types; de SEO-groep hangt af van welke post types al publiek geregistreerd
 * zijn en of het thema de SEO doet. Ook voor caches die van die configuratie zijn afgeleid (_ww_setting_field()).
 */
function _ww_pods_config_key(): string {
	$seo     = _ww_seo_enabled() ? _ww_seo_post_types() : array();
	// Alleen de namen: de labels opbouwen (_ww_seo_sitemap_choices()) is hier niet nodig.
	$sitemap = _ww_seo_enabled() ? array_keys( _ww_seo_sitemap_objects() ) : array();
	return implode( '|', _ww_pods_config_files() ) . '#' . implode( ',', $seo ) . '#' . implode( ',', $sitemap );
}

/**
 * Alle pods uit de configuratiebestanden, samengevoegd. Bestanden van het child-thema houden alleen
 * groepen en velden met het child-voorvoegsel.
 *
 * @return array<int,array<string,mixed>>
 */
function _ww_pods_config(): array {
	// Eén keer per request inlezen, per sleutel (_ww_pods_config_key()).
	static $cache = array();

	$key = _ww_pods_config_key();
	if ( isset( $cache[ $key ] ) ) {
		return $cache[ $key ];
	}

	_ww_pods_notices_buffer( array() );
	$files   = _ww_pods_config_files();
	$seo     = _ww_seo_enabled() ? _ww_seo_post_types() : array();
	$sitemap = _ww_seo_enabled() ? _ww_seo_sitemap_choices() : array();

	$child   = _ww_has_child_theme() ? trailingslashit( get_stylesheet_directory() ) : '';
	$configs = array();
	foreach ( $files as $file ) {
		$config = json_decode( (string) file_get_contents( $file ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- lokaal themabestand.
		if ( ! is_array( $config ) ) {
			// Zonder deze melding verdwijnen alle velden van het bestand stil.
			_ww_pods_notice( $file, sprintf( 'is geen geldige JSON (%s) en is overgeslagen', json_last_error_msg() ) );
			_doing_it_wrong( '_ww_pods_config', esc_html( sprintf( 'Pods-configuratie %s is geen geldige JSON (%s) en is overgeslagen.', basename( $file ), json_last_error_msg() ) ), '0.18.0' );
			continue;
		}
		$configs[ $file ] = '' !== $child && str_starts_with( $file, $child ) ? _ww_pods_child_config( $config, $file ) : $config;
	}
	$cache[ $key ] = _ww_pods_lock_code_fields( _ww_pods_allow_shortcodes( _ww_pods_add_llms_field( _ww_pods_add_sitemap_field( _ww_pods_add_seo_group( _ww_pods_merge( $configs ), $seo ), $sitemap ), _ww_llms_choices() ) ) );
	_ww_pods_notices_store( $key, _ww_pods_notices_buffer() );
	return $cache[ $key ];
}

/**
 * Elk veld van het type code (scripts die ongewijzigd in de pagina komen) is alleen voor wie manage_options heeft,
 * ook als het configuratiebestand unfiltered_html of niets noemt. Op een gewone site heeft de Redacteur
 * unfiltered_html, en code in de head van elke pagina draait ook in de browser van de beheerder (B1 van de
 * security-audit van 2026-11-15, beslissing 0025). Het bewerkscherm, de Site-instellingen, Visueel bewerken en de
 * abilities schermen het veld daarmee af (_ww_field_restricted()).
 *
 * @param array<int,array<string,mixed>> $pods Samengevoegde pods.
 * @return array<int,array<string,mixed>>
 */
function _ww_pods_lock_code_fields( array $pods ): array {
	foreach ( $pods as $index => $pod ) {
		foreach ( $pod['groups'] ?? array() as $group_index => $group ) {
			foreach ( _ww_pods_valid_fields( $group ) as $field_index => $field ) {
				if ( 'code' === ( $field['type'] ?? '' ) ) {
					$pods[ $index ]['groups'][ $group_index ]['fields'][ $field_index ]['restrict_capability'] = 1;
					$pods[ $index ]['groups'][ $group_index ]['fields'][ $field_index ]['capability_allowed']  = 'manage_options';
				}
			}
		}
	}
	return $pods;
}

/**
 * Laat elk WYSIWYG-veld shortcodes bewaren, tenzij het bestand zelf `wysiwyg_allow_shortcode` zet. De opslaglaag
 * haalt shortcodes bij het opslaan weg als die optie uit staat (zoals Pods), terwijl ww_text() ze juist uitvoert,
 * bijvoorbeeld [ww_form] in de tekst van een pagina. De shortcodes van Pods zelf ([pods], [pods-form]) doen niets
 * (_ww_pods_block_shortcodes() in inc/helpers.php).
 *
 * @param array<int,array<string,mixed>> $pods Samengevoegde pods.
 * @return array<int,array<string,mixed>>
 */
function _ww_pods_allow_shortcodes( array $pods ): array {
	foreach ( $pods as $index => $pod ) {
		foreach ( $pod['groups'] ?? array() as $group_index => $group ) {
			foreach ( _ww_pods_valid_fields( $group ) as $field_index => $field ) {
				if ( 'wysiwyg' === ( $field['type'] ?? '' ) && ! array_key_exists( 'wysiwyg_allow_shortcode', $field ) ) {
					$pods[ $index ]['groups'][ $group_index ]['fields'][ $field_index ]['wysiwyg_allow_shortcode'] = 1;
				}
			}
		}
	}
	return $pods;
}

/**
 * Zet het veld seo_sitemap_exclude (_ww_seo_sitemap_field()) als laatste veld in de groep seo van de
 * Site-instellingen. Zonder keuzes (geen eigen post types, of de SEO van het thema staat uit) geen veld.
 *
 * @param array<int,array<string,mixed>> $pods    Samengevoegde pods.
 * @param array<string,string>           $choices Post types die uit de sitemap kunnen (naam => label).
 * @return array<int,array<string,mixed>>
 */
function _ww_pods_add_sitemap_field( array $pods, array $choices ): array {
	$field = _ww_seo_sitemap_field( $choices );
	if ( null === $field ) {
		return $pods;
	}
	foreach ( $pods as $index => $pod ) {
		if ( 'settings' !== ( $pod['type'] ?? '' ) || 'site_settings' !== ( $pod['name'] ?? '' ) ) {
			continue;
		}
		foreach ( $pod['groups'] as $group_index => $group ) {
			if ( 'seo' === ( $group['name'] ?? '' ) ) {
				$pods[ $index ]['groups'][ $group_index ]['fields'][] = $field;
			}
		}
	}
	return $pods;
}

/**
 * Zet het veld seo_llms_post_types (_ww_llms_field()) als laatste veld in de groep seo_llms van de Site-instellingen.
 * Zonder keuzes geen veld.
 *
 * @param array<int,array<string,mixed>> $pods    Samengevoegde pods.
 * @param array<string,string>           $choices Post types die in llms.txt kunnen (naam => label).
 * @return array<int,array<string,mixed>>
 */
function _ww_pods_add_llms_field( array $pods, array $choices ): array {
	$field = _ww_llms_field( $choices );
	if ( null === $field ) {
		return $pods;
	}
	foreach ( $pods as $index => $pod ) {
		if ( 'settings' !== ( $pod['type'] ?? '' ) || 'site_settings' !== ( $pod['name'] ?? '' ) ) {
			continue;
		}
		foreach ( $pod['groups'] as $group_index => $group ) {
			if ( 'seo_llms' === ( $group['name'] ?? '' ) ) {
				$pods[ $index ]['groups'][ $group_index ]['fields'][] = $field;
			}
		}
	}
	return $pods;
}

/**
 * Zet de groep SEO van de parent (_ww_seo_group()) als laatste groep bij elke pod van een post type met eigen
 * pagina's. Een post type zonder configuratiebestand krijgt geen pod, en dus ook geen SEO-velden.
 *
 * @param array<int,array<string,mixed>> $pods       Samengevoegde pods.
 * @param string[]                       $post_types Post types met SEO-velden.
 * @return array<int,array<string,mixed>>
 */
function _ww_pods_add_seo_group( array $pods, array $post_types ): array {
	foreach ( $pods as $index => $pod ) {
		if ( 'post_type' === ( $pod['type'] ?? '' ) && in_array( $pod['name'] ?? '', $post_types, true ) ) {
			$pods[ $index ] = array( 'groups' => array_merge( $pod['groups'], array( _ww_seo_group() ) ) ) + $pod;
		}
	}
	return $pods;
}

/**
 * Naam van de veldgroep voor het paginatemplate van een bericht: page-home.php wordt `template_home`,
 * het standaardtemplate (ook bij een nieuw bericht) `template_default`.
 */
function _ww_template_group_name( int $post_id ): string {
	$file = $post_id > 0 ? (string) get_page_template_slug( $post_id ) : '';
	$slug = '' === $file ? 'default' : (string) preg_replace( '/^page-/', '', basename( $file, '.php' ) );
	return 'template_' . sanitize_key( $slug );
}

/**
 * Toont van de template-groepen alleen die van het gekozen template. Andere groepen blijven staan.
 *
 * Het bewerkscherm bewaart alleen velden uit de getoonde groepen (inc/field-metaboxes.php, zoals Pods). Wie het
 * template wijzigt, slaat eerst op en vult daarna de nieuwe velden.
 *
 * @param mixed           $groups Groepen uit de configuratie (arrays of objecten met ArrayAccess).
 * @param string          $type   Pod-type.
 * @param string          $name   Podnaam.
 * @param int|string|null $id     Bericht-ID.
 * @return mixed
 */
function _ww_pods_template_groups( $groups, $type, $name, $id ) {
	if ( 'post_type' !== $type || ! is_array( $groups ) ) {
		return $groups;
	}

	// Zonder ID (zo riep Pods het aan bij het maken van de metaboxen) is het bericht het globale $post.
	$current = _ww_template_group_name( (int) $id ?: (int) get_the_ID() );
	return array_filter(
		$groups,
		static function ( $group ) use ( $current ): bool {
			// Groepen uit het child-thema heten child_template_{naam}.
			$template = (string) preg_replace( '/^' . preg_quote( _ww_child_prefix(), '/' ) . '/', '', (string) ( $group['name'] ?? '' ) );
			return ! str_starts_with( $template, 'template_' ) || _ww_pods_template_matches( $template, $current );
		}
	);
}

/**
 * Hoort deze templategroep bij het gekozen template? Een groep kan een achtervoegsel per sectie hebben:
 * template_home_hero hoort bij template_home, template_homepage niet.
 *
 * @param string $group   Groepnaam zonder child-voorvoegsel (template_home_hero).
 * @param string $current Groepnaam van het template (_ww_template_group_name(): template_home).
 */
function _ww_pods_template_matches( string $group, string $current ): bool {
	return $group === $current || str_starts_with( $group, $current . '_' );
}

/**
 * Label en naam van een groep, om bij haar velden te zetten: `group` (het label, of de naam als er geen label is)
 * en `group_name`.
 *
 * @param array<string,mixed> $group
 * @return array{group:string,group_name:string}
 */
function _ww_pods_group_info( array $group ): array {
	$name = _ww_data_to_string( $group['name'] ?? '' );
	return array(
		'group'      => _ww_data_to_string( $group['label'] ?? $name ),
		'group_name' => $name,
	);
}

/**
 * Velden van een post type uit de configuratiebestanden, in de volgorde van de bestanden. De bestanden zijn
 * de bron, dus dit werkt ook zonder actieve Pods. Met een bericht-ID alleen de velden die bij dat bericht
 * op het scherm staan: van de template-groepen alleen die van zijn paginatemplate.
 *
 * Elk veld krijgt het label van zijn groep als `group` en de naam van die groep als `group_name`.
 *
 * @param int $post_id Bericht-ID; 0 geeft de velden van alle groepen.
 * @return array<int,array<string,mixed>>
 */
function _ww_pods_fields( string $post_type, int $post_id = 0 ): array {
	$fields = array();
	foreach ( _ww_pods_config() as $pod ) {
		if ( 'post_type' !== ( $pod['type'] ?? '' ) || $post_type !== ( $pod['name'] ?? '' ) ) {
			continue;
		}
		$groups = $post_id > 0 ? _ww_pods_template_groups( $pod['groups'], 'post_type', $post_type, $post_id ) : $pod['groups'];
		foreach ( $groups as $group ) {
			foreach ( $group['fields'] as $field ) {
				$fields[] = _ww_pods_group_info( $group ) + $field;
			}
		}
	}
	return $fields;
}

/**
 * Termvelden van een taxonomie (een pod met type taxonomy) uit de configuratiebestanden, in de volgorde van de
 * bestanden. Pods tekende ze op de schermen Nieuwe term en Term bewerken; nu doet het thema dat
 * (inc/field-terms.php). Elk veld krijgt het label van zijn groep als `group` en de naam van die groep als `group_name`.
 *
 * @return array<int,array<string,mixed>>
 */
function _ww_pods_taxonomy_fields( string $taxonomy ): array {
	$fields = array();
	foreach ( _ww_pods_config() as $pod ) {
		if ( 'taxonomy' !== ( $pod['type'] ?? '' ) || $taxonomy !== ( $pod['name'] ?? '' ) ) {
			continue;
		}
		foreach ( $pod['groups'] as $group ) {
			foreach ( $group['fields'] as $field ) {
				$fields[] = _ww_pods_group_info( $group ) + $field;
			}
		}
	}
	return $fields;
}

/**
 * De taxonomieën met termvelden in de configuratie.
 *
 * @return string[]
 */
function _ww_pods_taxonomies(): array {
	$names = array();
	foreach ( _ww_pods_config() as $pod ) {
		if ( 'taxonomy' === ( $pod['type'] ?? '' ) && array() !== _ww_pods_groups_fields( $pod['groups'] ) ) {
			$names[] = _ww_data_to_string( $pod['name'] ?? '' );
		}
	}
	return array_values( array_unique( array_filter( $names ) ) );
}

/**
 * Velden van de Site-instellingen uit de configuratiebestanden, ook zonder actieve Pods. Elk veld krijgt
 * de naam van zijn instellingen-pod als `pod`, het label van zijn groep als `group` en de naam van die groep als `group_name`.
 *
 * @return array<int,array<string,mixed>>
 */
function _ww_pods_setting_fields(): array {
	$fields = array();
	foreach ( _ww_pods_config() as $pod ) {
		if ( 'settings' !== ( $pod['type'] ?? '' ) ) {
			continue;
		}
		foreach ( $pod['groups'] as $group ) {
			$info = _ww_pods_group_info( $group );
			foreach ( $group['fields'] as $field ) {
				$fields[] = array( 'pod' => $pod['name'] ) + $info + $field;
			}
		}
	}
	return $fields;
}

/**
 * Veldnamen van een post type die in revisies passen (enkelvoudige waarden).
 *
 * @return string[]
 */
function _ww_pods_revision_fields( string $post_type ): array {
	$simple = array( 'text', 'paragraph', 'wysiwyg', 'code', 'number', 'currency', 'date', 'datetime', 'time', 'boolean', 'color', 'website', 'email', 'phone' );
	$names  = array();
	foreach ( _ww_pods_fields( $post_type ) as $field ) {
		$type = _ww_data_to_string( $field['type'] ?? '' );
		if ( in_array( $type, $simple, true ) || ( 'file' === $type && 'single' === ( $field['file_format_type'] ?? 'single' ) ) ) {
			$names[] = _ww_data_to_string( $field['name'] ?? '' );
		}
	}
	return array_values( array_filter( $names ) );
}
