<?php
/**
 * Formulieren: voorwaarden op velden (spec formulieren-voorwaarden-berekening, deel 2).
 *
 * Een veld kan een voorwaarde hebben: een lijst regels over eerdere velden, die allemaal (all) of minstens één (any)
 * moeten kloppen om het veld te tonen. Dit bestand schoont de voorwaarde op bij het opslaan van de configuratie.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * De toegestane vergelijkingen voor een opgeschoond bronveld.
 *
 * @param array<string,mixed> $source Opgeschoond veld.
 * @return list<string> Lege lijst als het type geen bron voor een voorwaarde kan zijn.
 */
function _ww_form_condition_ops( array $source ): array {
	switch ( $source['type'] ?? '' ) {
		case 'select':
			return array( 'is', 'is_not' );
		case 'choice':
			return ! empty( $source['multiple'] ) ? array( 'contains', 'not_contains' ) : array( 'is', 'is_not' );
		case 'checkbox':
			return array( 'checked', 'unchecked' );
		case 'number':
			return array( 'gt', 'lt', 'eq', 'gte', 'lte' );
	}
	return array();
}

/**
 * Schoont de voorwaarde van een veld op.
 *
 * @param mixed                          $raw      Ingestuurde voorwaarde.
 * @param array<int,array<string,mixed>> $earlier  De opgeschoonde velden vóór dit veld.
 * @param string                         $label    Label van het veld, voor de waarschuwingen.
 * @param list<string>                   $warnings Waarschuwingen (wordt aangevuld).
 * @return array{match: string, rules: list<array{field: string, op: string, value: string}>}|null Null als er geen geldige regel overblijft.
 */
function _ww_form_sanitize_condition( $raw, array $earlier, string $label, array &$warnings ): ?array {
	if ( ! is_array( $raw ) ) {
		return null;
	}
	$input = isset( $raw['rules'] ) && is_array( $raw['rules'] ) ? array_values( $raw['rules'] ) : array();
	if ( ! $input ) {
		return null;
	}

	$by_key = array();
	foreach ( $earlier as $source ) {
		$by_key[ $source['key'] ] = $source;
	}

	if ( count( $input ) > 10 ) {
		$warnings[] = sprintf(
			/* translators: %s: label van het veld. */
			__( 'Bij het veld %s staan meer dan 10 regels; de rest is weggelaten.', 'webwerckt-base' ),
			$label
		);
		$input = array_slice( $input, 0, 10 );
	}

	$rules   = array();
	$dropped = false;
	foreach ( $input as $rule ) {
		$clean = _ww_form_sanitize_condition_rule( $rule, $by_key );
		if ( null === $clean ) {
			$dropped = true;
		} else {
			$rules[] = $clean;
		}
	}

	if ( ! $rules ) {
		$warnings[] = sprintf(
			/* translators: %s: label van het veld. */
			__( 'Bij het veld %s is de voorwaarde weggelaten: geen regel wijst naar een eerder keuze-, vink- of getalveld of past daarbij. Het veld is nu altijd zichtbaar.', 'webwerckt-base' ),
			$label
		);
		return null;
	}
	if ( $dropped ) {
		$warnings[] = sprintf(
			/* translators: %s: label van het veld. */
			__( 'Bij het veld %s zijn regels van de voorwaarde weggelaten: ze wijzen niet naar een eerder keuze-, vink- of getalveld, of passen daar niet bij.', 'webwerckt-base' ),
			$label
		);
	}

	return array(
		'match' => ( is_string( $raw['match'] ?? null ) && 'any' === $raw['match'] ) ? 'any' : 'all',
		'rules' => $rules,
	);
}

/**
 * Schoont één regel van een voorwaarde op.
 *
 * @param mixed                             $rule   Ingestuurde regel.
 * @param array<string,array<string,mixed>> $by_key Eerdere velden, op sleutel.
 * @return array{field: string, op: string, value: string}|null Null als de regel niet klopt.
 */
function _ww_form_sanitize_condition_rule( $rule, array $by_key ): ?array {
	if ( ! is_array( $rule ) || ! is_string( $rule['field'] ?? null ) || ! is_string( $rule['op'] ?? null ) || ! isset( $by_key[ $rule['field'] ] ) ) {
		return null;
	}
	$source = $by_key[ $rule['field'] ];
	if ( ! in_array( $rule['op'], _ww_form_condition_ops( $source ), true ) ) {
		return null;
	}

	$value = '';
	switch ( $source['type'] ) {
		case 'checkbox':
			break;
		case 'number':
			$given = $rule['value'] ?? null;
			if ( is_float( $given ) ) {
				$given = _ww_form_number_float_text( $given );
			}
			$value = is_string( $given ) || is_int( $given ) ? _ww_form_number_parse( (string) $given ) : null;
			if ( null === $value || '' === $value ) {
				return null;
			}
			break;
		default:
			$value   = is_string( $rule['value'] ?? null ) ? $rule['value'] : '';
			$allowed = array_column( _ww_form_array( $source['options'] ?? array() ), 'value' );
			if ( ! in_array( $value, $allowed, true ) ) {
				return null;
			}
	}

	return array(
		'field' => $source['key'],
		'op'    => $rule['op'],
		'value' => $value,
	);
}

/**
 * Klopt één regel van een voorwaarde voor de waarde van het bronveld?
 *
 * Een leeg bronveld ('' of een lege lijst) voldoet aan is_not, not_contains en unchecked, en aan geen enkele
 * getalvergelijking. Dit is dé uitvoerder; de JavaScript van het formulier doet precies hetzelfde.
 *
 * @param array<string,mixed> $rule  Regel: op en value.
 * @param mixed               $value Waarde van het bronveld: tekst of lijst teksten.
 */
function _ww_form_rule_met( array $rule, $value ): bool {
	$op     = (string) ( $rule['op'] ?? '' );
	$wanted = (string) ( $rule['value'] ?? '' );

	switch ( $op ) {
		case 'is':
			return is_string( $value ) && $value === $wanted;
		case 'is_not':
			return ! is_string( $value ) || $value !== $wanted;
		case 'contains':
			return is_array( $value ) && in_array( $wanted, $value, true );
		case 'not_contains':
			return ! is_array( $value ) || ! in_array( $wanted, $value, true );
		case 'checked':
			return '1' === $value;
		case 'unchecked':
			return '1' !== $value;
		case 'gt':
		case 'lt':
		case 'eq':
		case 'gte':
		case 'lte':
			$number = is_string( $value ) ? _ww_form_number_parse( $value ) : null;
			if ( null === $number || '' === $number ) {
				return false;
			}
			$order = _ww_form_number_compare( $number, $wanted );
			switch ( $op ) {
				case 'gt':
					return $order > 0;
				case 'lt':
					return $order < 0;
				case 'eq':
					return 0 === $order;
				case 'gte':
					return $order >= 0;
				default:
					return $order <= 0;
			}
	}
	return false;
}

/**
 * Is de voorwaarde van een veld vervuld? Alle regels bij 'all', minstens één bij 'any'.
 *
 * @param array<string,mixed> $condition Opgeschoonde voorwaarde.
 * @param array<string,mixed> $values    Waarden per veldsleutel; een ontbrekend veld telt als leeg.
 */
function _ww_form_condition_met( array $condition, array $values ): bool {
	$any = 'any' === ( $condition['match'] ?? 'all' );
	foreach ( _ww_form_array( $condition['rules'] ?? array() ) as $rule ) {
		$met = _ww_form_rule_met( _ww_form_array( $rule ), $values[ $rule['field'] ?? '' ] ?? '' );
		if ( $any === $met ) {
			return $any;
		}
	}
	return ! $any;
}

/**
 * De waarde van een verborgen veld: een lege lijst bij een keuzeveld met meerdere keuzes en bij een bestandsveld, anders ''.
 *
 * @param array<string,mixed> $field Opgeschoond veld.
 * @return string|array<empty>
 */
function _ww_form_empty_value( array $field ) {
	if ( 'file' === ( $field['type'] ?? '' ) || ( 'choice' === ( $field['type'] ?? '' ) && ! empty( $field['multiple'] ) ) ) {
		return array();
	}
	return '';
}

/**
 * De sleutels van de velden die verborgen zijn, in de volgorde van het formulier. Een verborgen veld telt als leeg voor
 * de velden die erna komen, zodat een keten van voorwaarden klopt.
 *
 * @param array<string,mixed> $config Opgeschoonde configuratie.
 * @param array<string,mixed> $values Waarden per veldsleutel.
 * @return list<string>
 */
function _ww_form_hidden_keys( array $config, array $values ): array {
	$hidden = array();
	foreach ( _ww_form_array( $config['fields'] ?? array() ) as $field ) {
		if ( empty( $field['condition'] ) || _ww_form_condition_met( $field['condition'], $values ) ) {
			continue;
		}
		$key            = (string) $field['key'];
		$values[ $key ] = _ww_form_empty_value( $field );
		$hidden[]       = $key;
	}
	return $hidden;
}

/**
 * Heeft het formulier minstens één veld met een voorwaarde? Alleen dan laadt het script voor de voorwaarden.
 *
 * @param array<string,mixed> $config Opgeschoonde configuratie.
 */
function _ww_form_has_conditions( array $config ): bool {
	foreach ( _ww_form_array( $config['fields'] ?? array() ) as $field ) {
		if ( ! empty( _ww_form_array( $field )['condition'] ) ) {
			return true;
		}
	}
	return false;
}

/**
 * De hint bij een veld met een voorwaarde, als platte tekst: wanneer het veld ingevuld moet worden. Zonder JavaScript
 * staat het veld altijd open; de hint zegt dan waarvoor het bedoeld is. Leeg als geen regel een tekst geeft.
 *
 * @param array<string,mixed> $condition Opgeschoonde voorwaarde.
 * @param array<int,mixed>    $fields    Alle opgeschoonde velden, voor de labels en de optielabels.
 */
function _ww_form_condition_hint( array $condition, array $fields ): string {
	$by_key = array();
	foreach ( $fields as $field ) {
		$field                                      = _ww_form_array( $field );
		$by_key[ (string) ( $field['key'] ?? '' ) ] = $field;
	}
	$any   = 'any' === ( $condition['match'] ?? 'all' );
	$parts = '';
	foreach ( _ww_form_array( $condition['rules'] ?? array() ) as $rule ) {
		$rule  = _ww_form_array( $rule );
		$field = _ww_form_array( $by_key[ (string) ( $rule['field'] ?? '' ) ] ?? array() );
		$op    = (string) ( $rule['op'] ?? '' );
		$label = wp_strip_all_tags( _ww_form_string( $field['label'] ?? '' ) );
		$value = _ww_form_string( $rule['value'] ?? '' );
		foreach ( _ww_form_array( $field['options'] ?? array() ) as $option ) {
			$option = _ww_form_array( $option );
			if ( ( $option['value'] ?? null ) === $value ) {
				$value = wp_strip_all_tags( _ww_form_string( $option['label'] ?? '' ) );
				break;
			}
		}
		if ( in_array( $op, array( 'gt', 'lt', 'eq', 'gte', 'lte' ), true ) ) {
			$value = _ww_form_number_label( (float) $value );
		}
		switch ( $op ) {
			case 'is':
				/* translators: 1: label van het veld, 2: optie */
				$text = __( 'je bij %1$s “%2$s” koos', 'webwerckt-base' );
				break;
			case 'is_not':
				/* translators: 1: label van het veld, 2: optie */
				$text = __( 'je bij %1$s niet “%2$s” koos', 'webwerckt-base' );
				break;
			case 'contains':
				/* translators: 1: label van het veld, 2: optie */
				$text = __( 'je bij %1$s “%2$s” aankruiste', 'webwerckt-base' );
				break;
			case 'not_contains':
				/* translators: 1: label van het veld, 2: optie */
				$text = __( 'je bij %1$s “%2$s” niet aankruiste', 'webwerckt-base' );
				break;
			case 'checked':
				/* translators: 1: label van het veld */
				$text = __( 'je “%1$s” aanvinkte', 'webwerckt-base' );
				break;
			case 'unchecked':
				/* translators: 1: label van het veld */
				$text = __( 'je “%1$s” niet aanvinkte', 'webwerckt-base' );
				break;
			case 'gt':
				/* translators: 1: label van het veld, 2: getal */
				$text = __( 'je bij %1$s meer dan %2$s invulde', 'webwerckt-base' );
				break;
			case 'lt':
				/* translators: 1: label van het veld, 2: getal */
				$text = __( 'je bij %1$s minder dan %2$s invulde', 'webwerckt-base' );
				break;
			case 'eq':
				/* translators: 1: label van het veld, 2: getal */
				$text = __( 'je bij %1$s %2$s invulde', 'webwerckt-base' );
				break;
			case 'gte':
				/* translators: 1: label van het veld, 2: getal */
				$text = __( 'je bij %1$s minstens %2$s invulde', 'webwerckt-base' );
				break;
			case 'lte':
				/* translators: 1: label van het veld, 2: getal */
				$text = __( 'je bij %1$s hoogstens %2$s invulde', 'webwerckt-base' );
				break;
			default:
				continue 2;
		}
		$text = sprintf( $text, $label, $value );
		if ( '' === $parts ) {
			$parts = $text;
		} elseif ( $any ) {
			/* translators: 1: eerdere regels, 2: volgende regel. */
			$parts = sprintf( __( '%1$s of %2$s', 'webwerckt-base' ), $parts, $text );
		} else {
			/* translators: 1: eerdere regels, 2: volgende regel. */
			$parts = sprintf( __( '%1$s en %2$s', 'webwerckt-base' ), $parts, $text );
		}
	}
	if ( '' === $parts ) {
		return '';
	}
	/* translators: %s: de regels. */
	return sprintf( __( 'Alleen invullen als %s.', 'webwerckt-base' ), $parts );
}
