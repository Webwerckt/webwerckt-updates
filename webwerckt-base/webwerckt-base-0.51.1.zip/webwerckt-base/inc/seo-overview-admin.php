<?php
/**
 * SEO-overzicht (spec seo-overzicht-llms): het scherm SEO, een hoofditem in het blok Webwerckt voor wie andermans
 * pagina's mag bewerken (de Redacteur). Alleen als de SEO van het thema aan staat (_ww_seo_enabled()).
 *
 * Dit bestand heeft het menu, de stijl, de URL's, de filters van de lijst en de gegevens van Techniek. Het zijpaneel en
 * de weergaven staan in inc/seo-overview-admin-sections.php, de tabel in inc/class-ww-seo-overview-list-table.php. De
 * meldingen per pagina komen uit inc/seo-overview.php.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const WW_SEO_SCREEN   = 'ww-seo';
const WW_SEO_PER_PAGE = 50;

/**
 * Voegt SEO toe als hoofditem, in het Webwerckt-blok (_ww_admin_menu_groups()). Naast een SEO-plugin niet.
 */
function _ww_seo_overview_admin_menu(): void {
	if ( ! _ww_seo_enabled() ) {
		return;
	}
	add_menu_page(
		__( 'SEO', 'webwerckt-base' ),
		__( 'SEO', 'webwerckt-base' ),
		'edit_others_pages',
		WW_SEO_SCREEN,
		'_ww_seo_admin_render',
		'dashicons-search'
	);
}
add_action( 'admin_menu', '_ww_seo_overview_admin_menu' );

/**
 * Laadt de stijl, alleen op dit scherm.
 *
 * @param string $hook Admin-scherm.
 */
function _ww_seo_overview_admin_assets( $hook ): void {
	if ( 'toplevel_page_' . WW_SEO_SCREEN !== $hook || ! _ww_seo_enabled() ) {
		return;
	}
	wp_enqueue_style( 'ww-seo-overview-admin', _ww_asset_url( 'css/seo-overview-admin.css' ), array(), WW_BASE_VERSION );
	if ( 'form' !== _ww_seo_admin_view() ) {
		return;
	}
	// Het formulier: de teller van het bewerkscherm, de mediakiezer en het voorbeeld in Google.
	_ww_seo_admin_counter_script( _ww_seo_admin_edit_id() );
	wp_enqueue_media();
	wp_enqueue_script( 'ww-seo-overview-admin', _ww_asset_url( 'js/seo-overview-admin.js' ), array(), WW_BASE_VERSION, array( 'in_footer' => true ) );
}
add_action( 'admin_enqueue_scripts', '_ww_seo_overview_admin_assets' );

/**
 * De velden van het formulier, in deze volgorde. Dezelfde meta als de groep SEO op het bewerkscherm.
 */
const WW_SEO_FORM_FIELDS = array( 'ww_seo_title', 'ww_seo_description', 'ww_seo_image', 'ww_seo_llms_exclude' );

/**
 * Mag de huidige gebruiker deze pagina op het scherm SEO bewerken? Een bericht van een SEO-post type, niet in de
 * prullenbak, met edit_post.
 */
function _ww_seo_can_edit( int $post_id ): bool {
	$post = $post_id > 0 ? get_post( $post_id ) : null;
	return $post instanceof WP_Post
		&& ! in_array( $post->post_status, array( 'trash', 'auto-draft', 'inherit' ), true )
		&& in_array( $post->post_type, _ww_seo_admin_post_types(), true )
		&& current_user_can( 'edit_post', $post_id );
}

/**
 * Slaat de SEO-velden van één pagina op: alleen de meta, via de opslaglaag van de eigen velden (0055), zonder
 * wp_update_post(). De datum laatst gewijzigd blijft staan en er komt geen revisie. Een veld dat niet in $input staat
 * of ongewijzigd is, blijft ongemoeid. Daarna de paginacache van die pagina legen. Het activiteitenlog ziet de meta.
 *
 * @param array<string,mixed> $input Veldnaam => waarde (zonder slashes), alleen de velden van WW_SEO_FORM_FIELDS.
 * @return true|WP_Error
 */
function _ww_seo_save( int $post_id, array $input ) {
	if ( ! _ww_seo_can_edit( $post_id ) ) {
		return new WP_Error( 'ww_seo_forbidden', __( 'Deze pagina kun je hier niet bewerken.', 'webwerckt-base' ) );
	}
	$post    = get_post( $post_id );
	$type    = $post instanceof WP_Post ? $post->post_type : '';
	$fields  = array_column( _ww_pods_fields( $type ), null, 'name' );
	$data    = array();
	$invalid = array();
	foreach ( WW_SEO_FORM_FIELDS as $name ) {
		if ( ! array_key_exists( $name, $input ) || ! isset( $fields[ $name ] ) ) {
			continue;
		}
		$field = $fields[ $name ];
		// Geen _ww_fields_drop_gone(): een verkeerd getypte bijlage-ID (zonder script) wordt een fout, niet stil leeg.
		$value = $input[ $name ];
		if ( 'ww_seo_llms_exclude' === $name ) {
			// Een vinkje: alleen "1" is aan; het verborgen veld "0" ervoor zorgt dat uitvinken ook opslaat.
			$value = '1' === $value ? '1' : '0';
		}
		// Ongewijzigd blijft ongemoeid: geen lege rij en geen regel in het activiteitenlog bij elke "Opslaan en volgende".
		if ( _ww_field_box_unchanged( $field, _ww_field_box_value( $post_id, $field ), $value ) ) {
			continue;
		}
		$clean = _ww_fields_input_value( $field, $value );
		if ( is_wp_error( $clean ) ) {
			$invalid[] = _ww_data_to_string( $field['label'] ?? $name ) . ': ' . $clean->get_error_message();
			continue;
		}
		$data[ $name ] = $clean;
	}
	if ( array() !== $invalid ) {
		// Alles of niets: een geweigerd veld houdt de rest ook tegen, zodat het formulier klopt met wat er staat.
		return new WP_Error( 'ww_seo_invalid', implode( ' ', $invalid ) );
	}
	if ( array() === $data ) {
		return true;
	}
	$error = _ww_fields_save( $type, $post_id, $data );
	if ( $error instanceof WP_Error ) {
		return $error;
	}
	_ww_cache_purge_post( $post_id );
	return true;
}

/**
 * De pagina na $current in de gefilterde lijst, of 0 aan het eind of als $current er niet in staat. Pagina's in $skip
 * (al bezocht met "Opslaan en volgende") slaat hij over: met de standaardsortering op aantal meldingen zakt een
 * opgeslagen pagina naar onderen en zou hij anders nog een keer langskomen.
 *
 * @param array<mixed>                   $args Filters (_ww_seo_list_args()).
 * @param list<int>                      $skip Pagina's om over te slaan.
 * @param list<array<string,mixed>>|null $rows Rijen van _ww_seo_overview_rows(), als die er al zijn.
 */
function _ww_seo_next_id( int $current, array $args, array $skip = array(), ?array $rows = null ): int {
	$ids = array_map( 'intval', array_column( _ww_seo_filtered_rows( $args, $rows ), 'id' ) );
	$pos = array_search( $current, $ids, true );
	if ( false === $pos ) {
		return 0;
	}
	foreach ( array_slice( $ids, $pos + 1 ) as $id ) {
		if ( ! in_array( $id, $skip, true ) ) {
			return $id;
		}
	}
	return 0;
}

/**
 * De volgende pagina na het opslaan. $planned is de volgende zoals het formulier hem bij het tonen uitrekende; staat
 * hij nog in de lijst, dan die. Anders (bijvoorbeeld een dubbele titel die door dit opslaan verdween) de eerste pagina
 * erna, in de volgorde van vóór het opslaan, die nog in de lijst staat. Nooit de opgeslagen of een bezochte pagina.
 * 0: alles doorlopen.
 *
 * @param list<int> $before De ID's van de gefilterde lijst vóór het opslaan.
 * @param list<int> $now    De ID's van de gefilterde lijst na het opslaan.
 * @param list<int> $seen   Bezochte pagina's, met de opgeslagen pagina.
 */
function _ww_seo_next_after_save( array $before, array $now, int $planned, array $seen ): int {
	if ( $planned < 1 ) {
		return 0;
	}
	$start = array_search( $planned, $before, true );
	$tail  = false === $start ? array( $planned ) : array_slice( $before, $start );
	foreach ( $tail as $id ) {
		if ( ! in_array( $id, $seen, true ) && in_array( $id, $now, true ) ) {
			return $id;
		}
	}
	return 0;
}

/**
 * De bezochte pagina's uit een kommalijst (het veld ww_seo_seen of de queryvariabele seen).
 *
 * @param mixed $raw Kommalijst met ID's.
 * @return list<int>
 */
function _ww_seo_seen_ids( $raw ): array {
	$ids = array_map( 'absint', explode( ',', _ww_data_to_string( $raw ) ) );
	return array_values( array_unique( array_filter( $ids, static fn( int $id ): bool => $id > 0 ) ) );
}

/**
 * De bezochte pagina's die nog in de gefilterde lijst staan. Alleen die kunnen nog eens als volgende langskomen; zo
 * groeit de lijst in de URL niet mee met elke pagina die uit het filter valt.
 *
 * @param list<int> $seen Bezochte pagina's.
 * @param list<int> $ids  De ID's van de gefilterde lijst.
 * @return list<int>
 */
function _ww_seo_seen_in_list( array $seen, array $ids ): array {
	return array_values( array_intersect( array_values( array_unique( $seen ) ), $ids ) );
}

/**
 * URL van het formulier van een pagina, met de filters van de lijst en eventueel de bezochte pagina's.
 *
 * @param array<mixed> $args Filters (_ww_seo_list_args()).
 * @param list<int>    $seen Bezochte pagina's.
 */
function _ww_seo_form_url( int $post_id, array $args, array $seen = array() ): string {
	return _ww_seo_admin_url( _ww_seo_form_query( $post_id, $args, $seen ) );
}

/**
 * De queryvariabelen van het formulier van een pagina.
 *
 * @param array<mixed> $args Filters (_ww_seo_list_args()).
 * @param list<int>    $seen Bezochte pagina's.
 * @return array<string,string>
 */
function _ww_seo_form_query( int $post_id, array $args, array $seen = array() ): array {
	$query = array(
		'tab'  => 'overzicht',
		'edit' => (string) $post_id,
	) + _ww_seo_list_query( _ww_seo_clean_list_args( $args ) );
	if ( array() !== $seen ) {
		$query['seen'] = implode( ',', $seen );
	}
	return $query;
}

/**
 * Meldt iets op het scherm en stuurt door (de melding reist mee in een transient, zoals bij options.php en Redirects).
 *
 * @param string               $message Tekst.
 * @param string               $type    success of error.
 * @param array<string,string> $args    Queryvariabelen voor de URL.
 */
function _ww_seo_admin_done( string $message, string $type, array $args ): void {
	add_settings_error( 'ww_seo', 'ww_seo_' . $type, esc_html( $message ), $type );
	set_transient( 'settings_errors', get_settings_errors(), 30 );
	if ( wp_safe_redirect( _ww_seo_admin_url( $args + array( 'settings-updated' => 'true' ) ) ) ) {
		exit;
	}
}

/**
 * Slaat het formulier op (admin_init): ww_seo_action=save met de nonce ww_seo_save_{id}. De knop ww_seo_submit=save
 * gaat terug naar hetzelfde formulier, next naar de volgende pagina in de gefilterde lijst of, aan het eind, naar de
 * lijst met "Alles doorlopen". De filters staan in de URL van het formulier ($_GET).
 */
function _ww_seo_admin_handle(): void {
	// phpcs:disable WordPress.Security.NonceVerification.Missing -- de nonce wordt hieronder gecontroleerd.
	$action = isset( $_POST['ww_seo_action'] ) ? sanitize_key( _ww_data_to_string( wp_unslash( $_POST['ww_seo_action'] ) ) ) : '';
	if ( 'llms_save' === $action ) {
		_ww_llms_admin_handle();
		return;
	}
	if ( 'save' !== $action ) {
		return;
	}
	if ( ! _ww_seo_enabled() || ! current_user_can( 'edit_others_pages' ) ) {
		wp_die( esc_html__( 'Je hebt geen rechten om de SEO van pagina\'s te bewerken.', 'webwerckt-base' ), 403 );
	}
	$id = isset( $_POST['ww_seo_id'] ) ? absint( _ww_data_to_string( wp_unslash( $_POST['ww_seo_id'] ) ) ) : 0;
	check_admin_referer( 'ww_seo_save_' . $id );

	// Elke waarde gaat door _ww_seo_save() (de controle van de eigen velden).
	$posted  = isset( $_POST['ww_fields'] ) && is_array( $_POST['ww_fields'] ) ? wp_unslash( $_POST['ww_fields'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
	$input   = array_map( '_ww_data_to_string', array_intersect_key( $posted, array_flip( WW_SEO_FORM_FIELDS ) ) );
	$next    = 'next' === ( isset( $_POST['ww_seo_submit'] ) ? _ww_data_to_string( wp_unslash( $_POST['ww_seo_submit'] ) ) : '' );
	$planned = isset( $_POST['ww_seo_next'] ) ? absint( _ww_data_to_string( wp_unslash( $_POST['ww_seo_next'] ) ) ) : 0;
	$seen    = _ww_seo_seen_ids( isset( $_POST['ww_seo_seen'] ) ? wp_unslash( $_POST['ww_seo_seen'] ) : '' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- _ww_seo_seen_ids() houdt alleen getallen over.
	// phpcs:enable WordPress.Security.NonceVerification.Missing
	$args   = _ww_seo_list_args();
	$before = array_map( 'intval', array_column( _ww_seo_filtered_rows( $args ), 'id' ) );
	// Terug naar hetzelfde formulier: de geplande volgende reist mee (?next=), anders rekent het formulier hem na het
	// opslaan opnieuw uit, en dan is een opgeslagen pagina misschien al uit de lijst of naar onderen gezakt.
	// De bezochte pagina's gaan alleen mee zolang ze in de lijst staan (_ww_seo_seen_in_list()).
	$stay = static fn( int $planned, array $ids ): array => _ww_seo_form_query( $id, $args, _ww_seo_seen_in_list( $seen, $ids ) ) + array( 'next' => (string) $planned );

	$result = _ww_seo_save( $id, $input );
	if ( $result instanceof WP_Error ) {
		_ww_seo_admin_done( $result->get_error_message(), 'error', $stay( $planned, $before ) );
		return;
	}
	$now = array_map( 'intval', array_column( _ww_seo_filtered_rows( $args ), 'id' ) );
	if ( ! $next ) {
		$keep = _ww_seo_next_after_save( $before, $now, $planned, array_merge( $seen, array( $id ) ) );
		_ww_seo_admin_done( __( 'Opgeslagen.', 'webwerckt-base' ), 'success', $stay( $keep, $now ) );
		return;
	}

	$seen   = _ww_seo_seen_in_list( array_merge( $seen, array( $id ) ), $now );
	$target = _ww_seo_next_after_save( $before, $now, $planned, $seen );
	if ( 0 === $target ) {
		_ww_seo_admin_done( __( 'Opgeslagen. Alles doorlopen: er zijn geen pagina\'s meer in deze lijst.', 'webwerckt-base' ), 'success', _ww_seo_list_query( $args ) );
		return;
	}
	_ww_seo_admin_done( __( 'Opgeslagen.', 'webwerckt-base' ), 'success', _ww_seo_form_query( $target, $args, $seen ) );
}
add_action( 'admin_init', '_ww_seo_admin_handle' );

/**
 * Slaat de keuzes voor llms.txt op: de velden van het onderdeel llms.txt, alleen voor wie de Site-instellingen
 * mag bewerken (WW_SETTINGS_CAP). Een veld van een ander onderdeel in $posted wordt genegeerd. De inleiding per extra
 * taal staat in $posted['ww_llms_intro'][ taalcode ]; een onbekende taalcode, of een veld dat geweigerd wordt, houdt
 * alles tegen: dan wordt niets bewaard.
 *
 * @param array<string,mixed> $posted Veldnaam => waarde (zonder slashes), plus ww_llms_intro.
 */
function _ww_llms_admin_save( array $posted ): ?WP_Error {
	if ( ! current_user_can( WW_SETTINGS_CAP ) ) {
		return new WP_Error( 'ww_llms_forbidden', __( 'Je mag llms.txt niet bewerken.', 'webwerckt-base' ) );
	}
	$fields = array_intersect_key( _ww_fields_for_settings(), array_flip( array( 'seo_llms_mode', 'seo_llms_intro', 'seo_llms_post_types' ) ) );
	$data   = _ww_fields_input( array_intersect_key( $posted, $fields ), $fields );
	if ( is_wp_error( $data ) ) {
		return $data;
	}

	// Eerst alle talen controleren, dan pas bewaren.
	$translations = array();
	$raw          = is_array( $posted['ww_llms_intro'] ?? null ) ? $posted['ww_llms_intro'] : array();
	foreach ( $raw as $code => $text ) {
		$code = (string) $code;
		if ( '' === $code || _ww_settings_edit_language( $code ) !== $code ) {
			return new WP_Error( 'ww_llms_language', __( 'Onbekende taal: de inleiding is niet bewaard.', 'webwerckt-base' ) );
		}
		$clean = isset( $fields['seo_llms_intro'] ) ? _ww_fields_input( array( 'seo_llms_intro' => $text ), $fields ) : array();
		if ( is_wp_error( $clean ) ) {
			return $clean;
		}
		$translations[ $code ] = $clean;
	}

	if ( array() !== $data ) {
		$error = _ww_fields_save_settings( $data, $fields );
		if ( null !== $error ) {
			return $error;
		}
	}
	foreach ( $translations as $code => $clean ) {
		if ( array() === $clean ) {
			continue;
		}
		$error = _ww_settings_save_translation( $clean, $code );
		if ( null !== $error ) {
			return $error;
		}
	}
	return null;
}

/**
 * Verwerkt ww_seo_action=llms_save (admin_init): rechten, nonce ww_llms_save, bewaren en terug naar het onderdeel.
 */
function _ww_llms_admin_handle(): void {
	if ( ! _ww_seo_enabled() || ! current_user_can( WW_SETTINGS_CAP ) ) {
		wp_die( esc_html__( 'Je hebt geen rechten om llms.txt te bewerken.', 'webwerckt-base' ), 403 );
	}
	check_admin_referer( 'ww_llms_save' );
	// phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- nonce hierboven; _ww_llms_admin_save() controleert elke waarde.
	$posted = isset( $_POST['ww_fields'] ) && is_array( $_POST['ww_fields'] ) ? wp_unslash( $_POST['ww_fields'] ) : array();
	$intro  = isset( $_POST['ww_llms_intro'] ) && is_array( $_POST['ww_llms_intro'] ) ? wp_unslash( $_POST['ww_llms_intro'] ) : array();
	// phpcs:enable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
	// Niets aangevinkt stuurt niets mee: dat is een lege lijst, geen ongewijzigd veld.
	if ( isset( _ww_fields_for_settings()['seo_llms_post_types'] ) && ! isset( $posted['seo_llms_post_types'] ) ) {
		$posted['seo_llms_post_types'] = array();
	}
	if ( array() !== $intro ) {
		$posted['ww_llms_intro'] = $intro;
	}
	$error = _ww_llms_admin_save( $posted );
	if ( $error instanceof WP_Error ) {
		_ww_seo_admin_done( $error->get_error_message(), 'error', array( 'tab' => 'llms' ) );
		return;
	}
	_ww_seo_admin_done( __( 'Opgeslagen.', 'webwerckt-base' ), 'success', array( 'tab' => 'llms' ) );
}

/**
 * Het voorbeeld in Google voor één pagina, zoals de site titel en beschrijving maakt (_ww_seo_document_title(),
 * _ww_seo_description() in inc/seo.php), maar voor een bericht-ID in plaats van de huidige pagina. Een eigen titel
 * vervangt de hele titel; zonder eigen titel de titel van WordPress (pagina en sitenaam; bij de voorpagina de
 * homepagetitel uit de Site-instellingen, anders sitenaam en ondertitel). De terugval staat apart, voor het script.
 *
 * @return array{title:string,description:string,url:string,fallback_title:string,fallback_description:string,max:int}
 */
function _ww_seo_preview( int $post_id ): array {
	$max       = _ww_seo_length_limits()['description'][1];
	$home_title = _ww_seo_front_page_setting( $post_id, 'seo_home_title' );
	$front     = null !== $home_title;
	$own      = static fn( string $field ): string => _ww_plain_text( _ww_data_to_string( _ww_data_get_stored( $field, $post_id ) ) );
	$separator = ' ' . _ww_data_to_string( _ww_seo_title_separator( '-' ) ) . ' ';
	$site      = _ww_plain_text( get_bloginfo( 'name' ) );
	$tagline   = _ww_plain_text( get_bloginfo( 'description' ) );

	$title       = _ww_plain_text( get_the_title( $post_id ) );
	$description = _ww_seo_post_summary( $post_id );
	if ( $front ) {
		$title       = '' !== $home_title ? $home_title : $site . ( '' !== $tagline ? $separator . $tagline : '' );
		$home        = (string) _ww_seo_front_page_setting( $post_id, 'seo_home_description' );
		$description = '' !== $home ? $home : ( '' !== $description ? $description : $tagline );
	} else {
		$title .= $separator . $site;
	}
	$description = _ww_seo_trim( $description, $max );
	$link        = get_permalink( $post_id );

	return array(
		'title'                => '' !== $own( 'ww_seo_title' ) ? $own( 'ww_seo_title' ) : $title,
		'description'          => '' !== $own( 'ww_seo_description' ) ? _ww_seo_trim( $own( 'ww_seo_description' ), $max ) : $description,
		'url'                  => is_string( $link ) ? $link : '',
		'fallback_title'       => $title,
		'fallback_description' => $description,
		'max'                  => $max,
	);
}

/**
 * URL van het scherm, eventueel met extra queryvariabelen.
 *
 * @param array<string,string> $args Queryvariabelen.
 */
function _ww_seo_admin_url( array $args = array() ): string {
	// Zelf coderen: add_query_arg() codeert de nieuwe waarden niet.
	return add_query_arg( array_map( 'rawurlencode', array( 'page' => WW_SEO_SCREEN ) + $args ), admin_url( 'admin.php' ) );
}

/**
 * De standaardwaarden van de filters van de lijst. Het post type heet in de URL type, niet post_type: met post_type
 * zet WordPress in admin.php $typenow, en dan zoekt het het scherm onder edit.php?post_type=….
 *
 * @return array{view:string,type:string,issue:string,lang:string,orderby:string,order:string,paged:string}
 */
function _ww_seo_list_defaults(): array {
	return array(
		'view'    => 'all',
		'type'    => '',
		'issue'   => '',
		'lang'    => '',
		'orderby' => 'issues',
		'order'   => 'desc',
		'paged'   => '1',
	);
}

/**
 * Maakt filters schoon: alleen bekende waarden, de rest wordt de standaard.
 *
 * @param array<mixed> $raw Filters, bijvoorbeeld uit $_GET.
 * @return array{view:string,type:string,issue:string,lang:string,orderby:string,order:string,paged:string}
 */
function _ww_seo_clean_list_args( array $raw ): array {
	$args = _ww_seo_list_defaults();
	$get  = static fn( string $key ): string => sanitize_key( _ww_data_to_string( $raw[ $key ] ?? '' ) );

	if ( in_array( $get( 'view' ), array( 'issues', 'ok' ), true ) ) {
		$args['view'] = $get( 'view' );
	}
	if ( in_array( $get( 'type' ), _ww_seo_admin_post_types(), true ) ) {
		$args['type'] = $get( 'type' );
	}
	if ( array_key_exists( $get( 'issue' ), _ww_seo_issue_labels() ) ) {
		$args['issue'] = $get( 'issue' );
	}
	if ( _ww_languages_active() && in_array( $get( 'lang' ), _ww_language_codes(), true ) ) {
		$args['lang'] = $get( 'lang' );
	}
	if ( in_array( $get( 'orderby' ), array( 'title', 'type', 'modified', 'issues' ), true ) ) {
		$args['orderby'] = $get( 'orderby' );
	}
	if ( 'asc' === $get( 'order' ) ) {
		$args['order'] = 'asc';
	}
	$paged = absint( _ww_data_to_string( $raw['paged'] ?? '' ) );
	if ( $paged > 1 ) {
		$args['paged'] = (string) $paged;
	}
	return $args;
}

/**
 * De filters van de lijst zoals hij nu getoond wordt, uit $_GET.
 *
 * @return array{view:string,type:string,issue:string,lang:string,orderby:string,order:string,paged:string}
 */
function _ww_seo_list_args(): array {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen filteren en sorteren; elke waarde komt uit een vaste lijst.
	return _ww_seo_clean_list_args( wp_unslash( $_GET ) );
}

/**
 * De filters voor een URL: zonder de standaardwaarden, zodat de links kort blijven.
 *
 * @param array<string,string> $args Filters (_ww_seo_list_args()).
 * @return array<string,string>
 */
function _ww_seo_list_query( array $args ): array {
	$defaults = _ww_seo_list_defaults();
	$value    = static fn( string $key ): string => $args[ $key ] ?? $defaults[ $key ];
	// Sortering als paar: de kolomkoppen van WordPress lezen een ontbrekende order als asc, niet als onze desc.
	$sorted = $value( 'orderby' ) !== $defaults['orderby'] || $value( 'order' ) !== $defaults['order'];
	$query  = array();
	foreach ( $defaults as $key => $default ) {
		if ( $value( $key ) !== $default || ( $sorted && in_array( $key, array( 'orderby', 'order' ), true ) ) ) {
			$query[ $key ] = $value( $key );
		}
	}
	return $query;
}

/**
 * Past de filters toe, maar niet de weergave (Alle, Met melding, In orde): post type, melding en taal.
 *
 * @param list<array<string,mixed>>                                                                     $rows Rijen van _ww_seo_overview_rows().
 * @param array{view:string,type:string,issue:string,lang:string,orderby:string,order:string,paged:string} $args Schone filters.
 * @return list<array<string,mixed>>
 */
function _ww_seo_rows_matching( array $rows, array $args ): array {
	return array_values(
		array_filter(
			$rows,
			static function ( array $row ) use ( $args ): bool {
				if ( '' !== $args['type'] && $row['type'] !== $args['type'] ) {
					return false;
				}
				if ( '' !== $args['issue'] && ! in_array( $args['issue'], $row['issues'], true ) ) {
					return false;
				}
				return '' === $args['lang'] || $row['language'] === $args['lang'];
			}
		)
	);
}

/**
 * De rijen van het overzicht, gefilterd en gesorteerd volgens de filters, zonder paginering. Bij gelijke waarde blijft
 * de volgorde van _ww_seo_overview_rows() (laatst gewijzigd eerst), zodat "volgende" altijd dezelfde pagina is.
 *
 * @param array<mixed>                   $args Filters (_ww_seo_list_args()); ontbrekende of onbekende waarden worden de standaard.
 * @param list<array<string,mixed>>|null $rows Rijen van _ww_seo_overview_rows(), als die er al zijn.
 * @return list<array<string,mixed>>
 */
function _ww_seo_filtered_rows( array $args, ?array $rows = null ): array {
	$args = _ww_seo_clean_list_args( $args );
	$rows = _ww_seo_rows_matching( $rows ?? _ww_seo_overview_rows()['rows'], $args );
	if ( 'all' !== $args['view'] ) {
		$want = 'issues' === $args['view'];
		$rows = array_values( array_filter( $rows, static fn( array $row ): bool => ( array() !== $row['issues'] ) === $want ) );
	}

	$key = array(
		'title'    => static fn( array $a, array $b ): int => strnatcasecmp( wp_strip_all_tags( $a['title'] ), wp_strip_all_tags( $b['title'] ) ),
		'type'     => static fn( array $a, array $b ): int => strcmp( $a['type'], $b['type'] ),
		'modified' => static fn( array $a, array $b ): int => strcmp( $a['modified'], $b['modified'] ),
		'issues'   => static fn( array $a, array $b ): int => count( $a['issues'] ) <=> count( $b['issues'] ),
	)[ $args['orderby'] ];
	$sign = 'desc' === $args['order'] ? -1 : 1;
	// usort is stabiel (PHP 8): bij gelijke waarde blijft de volgorde van de query.
	usort( $rows, static fn( array $a, array $b ): int => $sign * $key( $a, $b ) );
	return $rows;
}

/**
 * Wat er op siteniveau aan de SEO mist, voor Techniek. Gewone tekst, nog niet geëscapet.
 *
 * @return list<string>
 */
function _ww_seo_tech_site(): array {
	$messages = array();
	if ( '0' === (string) get_option( 'blog_public', '1' ) ) {
		$messages[] = __( 'Zoekmachines ontmoedigen staat aan', 'webwerckt-base' );
	}
	if ( ww_setting_image_id( 'seo_image' ) < 1 ) {
		$messages[] = __( 'Geen standaard-afbeelding bij delen', 'webwerckt-base' );
	}

	// De eigen velden van de voorpagina gaan voor de Site-instellingen (_ww_seo_post_report()).
	$front = 'page' === get_option( 'show_on_front' ) ? (int) get_option( 'page_on_front' ) : 0;
	$own   = static fn( string $field ): string => $front > 0 ? _ww_plain_text( _ww_data_to_string( _ww_data_get_stored( $field, $front ) ) ) : '';
	// De instelling zoals de voorpagina hem toont (_ww_seo_front_page_setting()); zonder voorpagina in de standaardtaal.
	$home = static fn( string $setting ): string => _ww_seo_front_page_setting( $front, $setting ) ?? _ww_plain_text( _ww_setting_string( $setting ) );
	if ( '' === $home( 'seo_home_title' ) && '' === $own( 'ww_seo_title' ) ) {
		$messages[] = __( 'Geen homepagetitel', 'webwerckt-base' );
	}
	if ( '' === $home( 'seo_home_description' ) && '' === $own( 'ww_seo_description' ) ) {
		$messages[] = __( 'Geen homepagebeschrijving', 'webwerckt-base' );
	}

	foreach ( _ww_seo_sitemap_excluded() as $type ) {
		$object     = get_post_type_object( $type );
		$messages[] = sprintf(
			/* translators: %s: naam van een post type, meervoud. */
			__( '%s staat niet in de sitemap', 'webwerckt-base' ),
			$object instanceof WP_Post_Type ? _ww_plain_text( (string) $object->labels->name ) : $type
		);
	}
	return $messages;
}

/**
 * De gepubliceerde pagina's van de SEO-post types die niet in het overzicht staan: op noindex, met een canonical naar
 * elders of met een wachtwoord. Noindex en canonical met dezelfde voorwaarden als _ww_seo_sitemap_query_args(), het
 * omgekeerde van wat het overzicht toont, zodat geen pagina tussen wal en schip valt. Op titel.
 *
 * @return array{noindex: list<int>, canonical: list<int>, password: list<int>}
 */
function _ww_seo_tech_pages(): array {
	$out   = array(
		'noindex'   => array(),
		'canonical' => array(),
		'password'  => array(),
	);
	$types = _ww_seo_admin_post_types();
	if ( array() === $types ) {
		return $out;
	}
	$base  = array(
		'post_type'           => $types,
		'post_status'         => 'publish',
		'fields'              => 'ids',
		'posts_per_page'      => _ww_seo_overview_limit(),
		'orderby'             => 'title',
		'order'               => 'ASC',
		'no_found_rows'       => true,
		'ignore_sticky_posts' => true,
	);
	$extra = array(
		'noindex'   => array(
			'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_query_meta_query -- alleen op het scherm SEO.
				array(
					'key'     => 'ww_seo_noindex',
					'value'   => array( '', '0' ),
					'compare' => 'NOT IN',
				),
			),
		),
		'canonical' => array(
			'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_query_meta_query -- alleen op het scherm SEO.
				array(
					'key'     => 'ww_seo_canonical',
					'value'   => '',
					'compare' => '!=',
				),
			),
		),
		'password'  => array( 'has_password' => true ),
	);
	foreach ( $extra as $kind => $args ) {
		$out[ $kind ] = array_values( array_map( 'intval', get_posts( $args + $base ) ) );
	}
	return $out;
}

/**
 * Een link "Alle meldingen" onder de berichtenlijst van een post type met de groep SEO, naar het scherm SEO.
 *
 * @param string $which top of bottom.
 */
function _ww_seo_posts_list_link( $which ): void {
	if ( 'bottom' !== $which || ! current_user_can( 'edit_others_pages' ) ) {
		return;
	}
	$screen = get_current_screen();
	if ( ! $screen instanceof WP_Screen || ! in_array( $screen->post_type, _ww_seo_admin_post_types(), true ) ) {
		return;
	}
	echo '<div class="alignleft actions"><a href="' . esc_url( _ww_seo_admin_url() ) . '">' . esc_html__( 'Alle meldingen', 'webwerckt-base' ) . '</a></div>';
}
add_action( 'manage_posts_extra_tablenav', '_ww_seo_posts_list_link' );
