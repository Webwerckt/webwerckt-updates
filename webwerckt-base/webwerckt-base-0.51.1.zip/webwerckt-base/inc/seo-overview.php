<?php
/**
 * SEO-overzicht (ADR 0024, spec seo-overzicht-llms): de gegevens voor het scherm SEO. Dit bestand rekent de meldingen
 * per pagina uit (lengte, afbeelding, dubbele titels en beschrijvingen, afbeeldingen zonder alt-tekst) en bevat geen
 * HTML. Het oordeel over titel en beschrijving komt uit _ww_seo_post_report().
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Het hoogste aantal pagina's dat het overzicht berekent; daarboven telt het de laatst gewijzigde.
 */
const WW_SEO_OVERVIEW_LIMIT = 1000;

/**
 * Het hoogste aantal pagina's van het overzicht: WW_SEO_OVERVIEW_LIMIT, of wat het filter ww_seo_overview_limit ervan maakt.
 */
function _ww_seo_overview_limit(): int {
	return max( 1, (int) apply_filters( 'ww_seo_overview_limit', WW_SEO_OVERVIEW_LIMIT ) );
}

/**
 * De pagina's die in Google horen: gepubliceerd, zonder wachtwoord, niet op noindex en zonder canonical naar elders, van
 * de post types met de groep SEO (ook die uit de sitemap zijn gehaald). Nieuwste wijziging eerst. Meta en uitgelichte
 * afbeeldingen zijn voorgeladen.
 *
 * @return array{posts: list<WP_Post>, truncated: bool}
 */
function _ww_seo_overview_posts(): array {
	$types = _ww_seo_admin_post_types();
	if ( array() === $types ) {
		return array(
			'posts'     => array(),
			'truncated' => false,
		);
	}
	$limit = _ww_seo_overview_limit();
	$args  = _ww_seo_sitemap_query_args(
		array(
			'post_type'              => $types,
			'post_status'            => 'publish',
			'has_password'           => false,
			'orderby'                => array(
				'modified' => 'DESC',
				'ID'       => 'DESC',
			),
			'posts_per_page'         => $limit + 1,
			'no_found_rows'          => true,
			'ignore_sticky_posts'    => true,
			'update_post_meta_cache' => true,
			'update_post_term_cache' => true,
		)
	);
	$query = new WP_Query( $args );
	$found = array_values( array_filter( $query->posts, static fn( $post ): bool => $post instanceof WP_Post ) );

	// Noindex en canonical filtert de query al, net als de sitemap (_ww_seo_sitemap_query_args()).
	$truncated = count( $found ) > $limit;
	$posts     = array_slice( $found, 0, $limit );

	$thumbnails = array();
	foreach ( $posts as $post ) {
		$thumbnails[] = (int) get_post_thumbnail_id( $post->ID );
	}
	_ww_seo_prime_attachments( $thumbnails );

	return array(
		'posts'     => $posts,
		'truncated' => $truncated,
	);
}

/**
 * Laadt bijlagen en hun meta in één keer in de cache.
 *
 * @param int[] $ids Bijlage-ID's.
 */
function _ww_seo_prime_attachments( array $ids ): void {
	$ids = array_values( array_unique( array_filter( array_map( 'intval', $ids ) ) ) );
	if ( array() === $ids ) {
		return;
	}
	_prime_post_caches( $ids, false, false );
	update_meta_cache( 'post', $ids );
}

/**
 * Een SEO-waarde om te vergelijken: één spatie tussen woorden, geen spaties aan de randen, kleine letters.
 */
function _ww_seo_compare_key( string $value ): string {
	return mb_strtolower( trim( (string) preg_replace( '/\s+/u', ' ', $value ) ) );
}

/**
 * Dubbele eigen SEO-titels en -beschrijvingen binnen dezelfde taal (zonder Meertalig is dat één groep). Lege waarden en
 * terugvallen tellen niet.
 *
 * @param list<WP_Post> $posts De pagina's van het overzicht.
 * @return array{title: array<int,int>, description: array<int,int>} Per post-ID de ID van de eerste andere pagina met dezelfde waarde.
 */
function _ww_seo_duplicates( array $posts ): array {
	$out = array(
		'title'       => array(),
		'description' => array(),
	);
	foreach ( array(
		'title'       => 'ww_seo_title',
		'description' => 'ww_seo_description',
	) as $kind => $field ) {
		$groups = array();
		foreach ( $posts as $post ) {
			$key = _ww_seo_compare_key( _ww_data_to_string( _ww_data_get_stored( $field, $post->ID ) ) );
			if ( '' !== $key ) {
				$groups[ _ww_post_language( $post->ID ) . "\n" . $key ][] = $post->ID;
			}
		}
		foreach ( $groups as $ids ) {
			if ( count( $ids ) < 2 ) {
				continue;
			}
			foreach ( $ids as $id ) {
				$out[ $kind ][ $id ] = $ids[0] !== $id ? $ids[0] : $ids[1];
			}
		}
	}
	return $out;
}

/**
 * De afbeeldingen van een pagina: de uitgelichte afbeelding, de waarden van de fotovelden van het post type en de
 * wp-image-klassen in de tekst. Elke bijlage één keer.
 *
 * @return int[]
 */
function _ww_seo_post_image_ids( WP_Post $post ): array {
	$ids = array( (int) get_post_thumbnail_id( $post->ID ) );
	foreach ( _ww_pods_fields( $post->post_type ) as $field ) {
		$name = _ww_data_to_string( $field['name'] ?? '' );
		if ( '' !== $name && 'file' === ( $field['type'] ?? '' ) && 'images' === ( $field['file_type'] ?? '' ) ) {
			$ids = array_merge( $ids, _ww_data_to_ids( _ww_data_get_stored( $name, $post->ID ) ) );
		}
	}
	if ( preg_match_all( '/wp-image-(\d+)/', $post->post_content, $found ) ) {
		$ids = array_merge( $ids, array_map( 'intval', $found[1] ) );
	}
	return array_values( array_unique( array_filter( array_map( 'intval', $ids ) ) ) );
}

/**
 * Per pagina het aantal afbeeldingen zonder alt-tekst. Pagina's zonder zulke afbeeldingen staan er niet in.
 *
 * @param list<WP_Post> $posts De pagina's van het overzicht.
 * @return array<int,int>
 */
function _ww_seo_images_without_alt( array $posts ): array {
	$per_post = array();
	$all      = array();
	foreach ( $posts as $post ) {
		$per_post[ $post->ID ] = _ww_seo_post_image_ids( $post );
		$all                   = array_merge( $all, $per_post[ $post->ID ] );
	}
	_ww_seo_prime_attachments( $all );
	// Wat na het voorladen niet in de cache staat, bestaat niet (een wp-image-klasse van een verwijderde bijlage):
	// get_post() zou daar per ID opnieuw de database voor vragen.
	$known = array_filter( wp_cache_get_multiple( array_values( array_unique( $all ) ), 'posts' ) );

	$out = array();
	foreach ( $per_post as $post_id => $ids ) {
		$count = 0;
		foreach ( $ids as $id ) {
			if ( isset( $known[ $id ] ) && 'attachment' === get_post_type( $id ) && '' === trim( _ww_data_to_string( get_post_meta( $id, '_wp_attachment_image_alt', true ) ) ) ) {
				++$count;
			}
		}
		if ( $count > 0 ) {
			$out[ $post_id ] = $count;
		}
	}
	return $out;
}

/**
 * De meldingen van één pagina, als codes.
 *
 * @param WP_Post                                                      $post       De pagina.
 * @param array{title?: array<int,int>, description?: array<int,int>} $duplicates Uitkomst van _ww_seo_duplicates().
 * @param array<int,int>                                               $no_alt     Uitkomst van _ww_seo_images_without_alt().
 * @return list<string>
 */
function _ww_seo_issues( WP_Post $post, array $duplicates, array $no_alt ): array {
	$report = _ww_seo_post_report( $post->ID );
	$issues = array();
	foreach ( array( 'title', 'description' ) as $kind ) {
		if ( 'good' !== $report[ $kind ] ) {
			$issues[] = $kind . '_' . $report[ $kind ];
		}
	}
	if ( 'good' !== $report['image'] ) {
		$issues[] = 'image_missing';
	}
	foreach ( array( 'title', 'description' ) as $kind ) {
		if ( isset( $duplicates[ $kind ][ $post->ID ] ) ) {
			$issues[] = $kind . '_duplicate';
		}
	}
	if ( ! empty( $no_alt[ $post->ID ] ) ) {
		$issues[] = 'alt_missing';
	}
	return $issues;
}

/**
 * De teksten van de meldingscodes.
 *
 * @return array<string,string>
 */
function _ww_seo_issue_labels(): array {
	return array(
		'title_missing'         => __( 'Titel ontbreekt', 'webwerckt-base' ),
		'title_short'           => __( 'Titel te kort', 'webwerckt-base' ),
		'title_long'            => __( 'Titel te lang', 'webwerckt-base' ),
		'description_missing'   => __( 'Beschrijving ontbreekt', 'webwerckt-base' ),
		'description_short'     => __( 'Beschrijving te kort', 'webwerckt-base' ),
		'description_long'      => __( 'Beschrijving te lang', 'webwerckt-base' ),
		'image_missing'         => __( 'Geen afbeelding', 'webwerckt-base' ),
		'title_duplicate'       => __( 'Titel dubbel', 'webwerckt-base' ),
		'description_duplicate' => __( 'Beschrijving dubbel', 'webwerckt-base' ),
		'alt_missing'           => __( 'Afbeeldingen zonder alt-tekst', 'webwerckt-base' ),
	);
}

/**
 * De rijen van het overzicht: per pagina de gegevens en de meldingen.
 *
 * @return array{rows: list<array{id:int,title:string,type:string,language:string,modified:string,issues:list<string>,duplicate_of:array{title?:int,description?:int},no_alt:int}>, truncated: bool}
 */
function _ww_seo_overview_rows(): array {
	$result     = _ww_seo_overview_posts();
	$duplicates = _ww_seo_duplicates( $result['posts'] );
	$no_alt     = _ww_seo_images_without_alt( $result['posts'] );
	$rows       = array();
	foreach ( $result['posts'] as $post ) {
		$duplicate_of = array();
		foreach ( array( 'title', 'description' ) as $kind ) {
			if ( isset( $duplicates[ $kind ][ $post->ID ] ) ) {
				$duplicate_of[ $kind ] = $duplicates[ $kind ][ $post->ID ];
			}
		}
		$rows[] = array(
			'id'           => $post->ID,
			'title'        => get_the_title( $post ),
			'type'         => $post->post_type,
			'language'     => _ww_post_language( $post->ID ),
			'modified'     => $post->post_modified,
			'issues'       => _ww_seo_issues( $post, $duplicates, $no_alt ),
			'duplicate_of' => $duplicate_of,
			'no_alt'       => $no_alt[ $post->ID ] ?? 0,
		);
	}
	return array(
		'rows'      => $rows,
		'truncated' => $result['truncated'],
	);
}
