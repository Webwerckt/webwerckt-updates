<?php
/**
 * SEO-basis (ADR 0024): titel, beschrijving, canonical, robots, Open Graph en de sitemap, met de filters van WordPress
 * en de velden uit de configuratie: per pagina de groep SEO (_ww_seo_group()), voor de site de groep SEO in de Site-instellingen.
 * De structured data staat in inc/schema.php, de tellers en de kolom in de admin in inc/seo-admin.php.
 *
 * Is er een SEO-plugin actief (The SEO Framework, Yoast, Rank Math, SEOPress, All in One SEO; inc/integrations/seo.php
 * meldt hem via ww_seo_plugin), dan doet het thema niets van dit alles en verbergt het de velden. Zo staat elke tag er
 * hooguit één keer. Alleen noindex op de 404 en de zoekresultaten blijft, zonder The SEO Framework via wp_robots.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Scheidingstekens die de Site-instellingen kennen. De eerste is de standaard.
 */
const WW_SEO_SEPARATORS = array(
	'ndash'  => '–',
	'hyphen' => '-',
	'pipe'   => '|',
	'middot' => '·',
	'bullet' => '•',
);

/**
 * Soorten pagina voor het schema (de @type van de node WebPage). De eerste is de standaard.
 */
const WW_SEO_SCHEMA_TYPES = array( 'WebPage', 'AboutPage', 'ContactPage', 'FAQPage' );

/*
 * Aan of uit, en welke velden.
 */

/**
 * Naam van een actieve SEO-plugin, of ''. Het filter ww_seo_plugin vult hem in (inc/integrations/seo.php).
 */
function _ww_seo_plugin(): string {
	return _ww_data_to_string( apply_filters( 'ww_seo_plugin', '' ) );
}

/**
 * Doet het thema de SEO? Niet als het filter ww_seo false geeft, en niet naast een SEO-plugin.
 */
function _ww_seo_enabled(): bool {
	return (bool) apply_filters( 'ww_seo', true ) && '' === _ww_seo_plugin();
}

/**
 * Is dit een SEO-veld van de parent?
 */
function _ww_seo_is_field( string $name ): bool {
	return str_starts_with( $name, 'ww_seo_' );
}

/**
 * Post types met eigen pagina's, die de groep SEO krijgen als ze een pod hebben. Bijlagen niet.
 *
 * @return string[]
 */
function _ww_seo_post_types(): array {
	$types = array();
	foreach ( get_post_types() as $type ) {
		if ( 'attachment' !== $type && is_post_type_viewable( $type ) ) {
			$types[] = (string) $type;
		}
	}
	return $types;
}

/**
 * De groep SEO voor elk post type met eigen pagina's (_ww_pods_add_seo_group() in inc/config.php).
 *
 * @return array<string,mixed>
 */
function _ww_seo_group(): array {
	return array(
		'name'        => 'seo',
		'label'       => __( 'SEO', 'webwerckt-base' ),
		'description' => __( 'Hoe deze pagina in Google en bij delen verschijnt. Alles is optioneel.', 'webwerckt-base' ),
		'fields'      => array(
			array(
				'name'        => 'ww_seo_title',
				'label'       => __( 'Titel in Google', 'webwerckt-base' ),
				'type'        => 'text',
				'description' => __( 'Leeg: de titel van de pagina met de naam van de site erachter.', 'webwerckt-base' ),
			),
			array(
				'name'        => 'ww_seo_description',
				'label'       => __( 'Beschrijving in Google', 'webwerckt-base' ),
				'type'        => 'paragraph',
				'description' => __( 'Leeg: het begin van de tekst van de pagina.', 'webwerckt-base' ),
			),
			array(
				'name'             => 'ww_seo_image',
				'label'            => __( 'Afbeelding bij delen', 'webwerckt-base' ),
				'type'             => 'file',
				'file_format_type' => 'single',
				'file_type'        => 'images',
				'file_uploader'    => 'attachment',
				'description'      => __( 'Leeg: de uitgelichte afbeelding, anders die uit de Site-instellingen.', 'webwerckt-base' ),
			),
			array(
				'name'               => 'ww_seo_schema_type',
				'label'              => __( 'Soort pagina voor zoekmachines', 'webwerckt-base' ),
				'type'               => 'pick',
				'pick_object'        => 'custom-simple',
				'pick_custom'        => _ww_seo_schema_type_options(),
				'pick_format_type'   => 'single',
				'pick_format_single' => 'dropdown',
				'default_value'      => 'WebPage',
				'description'        => __( 'Voor de structured data. Veelgestelde vragen: alleen op de pagina die de vragen toont, en dan met de gekoppelde vragen.', 'webwerckt-base' ),
			),
			array(
				'name'        => 'ww_seo_canonical',
				'label'       => __( 'Canonieke URL', 'webwerckt-base' ),
				'type'        => 'website',
				'description' => __( 'Alleen invullen als deze pagina een kopie is van een andere pagina. Leeg: het eigen adres.', 'webwerckt-base' ),
			),
			array(
				'name'              => 'ww_seo_noindex',
				'label'             => __( 'Verbergen voor zoekmachines', 'webwerckt-base' ),
				'type'              => 'boolean',
				'boolean_yes_label' => __( 'Ja, noindex', 'webwerckt-base' ),
				'default_value'     => '0',
				'description'       => __( 'De pagina blijft bereikbaar, maar komt niet in Google en niet in de sitemap.', 'webwerckt-base' ),
			),
			array(
				'name'              => 'ww_seo_llms_exclude',
				'label'             => __( 'Niet in llms.txt', 'webwerckt-base' ),
				'type'              => 'boolean',
				'boolean_yes_label' => __( 'Ja, weglaten', 'webwerckt-base' ),
				'default_value'     => '0',
				'description'       => __( 'Alleen uit llms.txt (voor AI-diensten), niet uit Google. Uit Google haal je een pagina met Verbergen voor zoekmachines.', 'webwerckt-base' ),
			),
		),
	);
}

/**
 * De keuzes van het veld ww_seo_schema_type in het formaat van Pods: een regel per keuze, `waarde|label`.
 */
function _ww_seo_schema_type_options(): string {
	$labels = array(
		'WebPage'     => __( 'Gewone pagina', 'webwerckt-base' ),
		'AboutPage'   => __( 'Over ons', 'webwerckt-base' ),
		'ContactPage' => __( 'Contact', 'webwerckt-base' ),
		'FAQPage'     => __( 'Veelgestelde vragen', 'webwerckt-base' ),
	);
	$lines  = array();
	foreach ( WW_SEO_SCHEMA_TYPES as $type ) {
		$lines[] = $type . '|' . $labels[ $type ];
	}
	return implode( "\n", $lines );
}

/**
 * De gekozen soort pagina van een bericht, of WebPage.
 */
function _ww_seo_schema_type( int $post_id ): string {
	$type = _ww_data_to_string( _ww_data_get_stored( 'ww_seo_schema_type', $post_id ) );
	return in_array( $type, WW_SEO_SCHEMA_TYPES, true ) ? $type : WW_SEO_SCHEMA_TYPES[0];
}

/*
 * Lengte van titel en beschrijving: één oordeel voor de teller, de kolom, Site-status en de abilities.
 */

/**
 * Goede lengte in tekens: [minimum, maximum] voor title en description. Filter ww_seo_length_limits.
 *
 * @return array{title:array{0:int,1:int},description:array{0:int,1:int}}
 */
function _ww_seo_length_limits(): array {
	$default = array(
		'title'       => array( 30, 60 ),
		'description' => array( 70, 155 ),
	);
	$limits  = apply_filters( 'ww_seo_length_limits', $default );
	$out     = $default;
	foreach ( array_keys( $default ) as $kind ) {
		$pair = is_array( $limits ) && is_array( $limits[ $kind ] ?? null ) ? array_values( $limits[ $kind ] ) : array();
		if ( isset( $pair[0], $pair[1] ) && is_numeric( $pair[0] ) && is_numeric( $pair[1] ) && (int) $pair[0] <= (int) $pair[1] ) {
			$out[ $kind ] = array( max( 0, (int) $pair[0] ), (int) $pair[1] );
		}
	}
	return $out;
}

/**
 * Oordeel over de lengte: missing (leeg), short, long of good.
 *
 * @param string $kind title of description.
 */
function _ww_seo_length_status( string $kind, string $text ): string {
	$limits = _ww_seo_length_limits();
	$range  = $limits[ 'title' === $kind ? 'title' : 'description' ];
	$length = mb_strlen( _ww_plain_text( $text ) );
	if ( 0 === $length ) {
		return 'missing';
	}
	if ( $length < $range[0] ) {
		return 'short';
	}
	return $length > $range[1] ? 'long' : 'good';
}

/*
 * Waarden voor de huidige pagina.
 */

/**
 * Het bericht achter de huidige pagina: het bericht zelf, de vaste voorpagina of de berichtenpagina; 0 bij een overzicht.
 */
function _ww_seo_post_id(): int {
	if ( is_singular() ) {
		return (int) get_queried_object_id();
	}
	return is_home() && ! is_front_page() ? _ww_posts_page_id() : 0;
}

/**
 * Een eigen SEO-veld van een bericht als tekst. Bij een bericht met wachtwoord leeg, net als zijn andere velden.
 */
function _ww_seo_field( string $field, int $post_id ): string {
	return $post_id > 0 ? _ww_plain_text( _ww_data_to_string( _ww_data_get( $field, $post_id ) ) ) : '';
}

/**
 * Tekst ingekort tot hoogstens $max tekens, op een woordgrens, met … erachter.
 */
function _ww_seo_trim( string $text, int $max ): string {
	$text = trim( (string) preg_replace( '/\s+/u', ' ', $text ) );
	if ( mb_strlen( $text ) <= $max ) {
		return $text;
	}
	$cut   = mb_substr( $text, 0, $max - 1 );
	$space = mb_strrpos( $cut, ' ' );
	$cut   = false !== $space && $space > $max / 2 ? mb_substr( $cut, 0, $space ) : $cut;
	return rtrim( $cut, " \t,.;:–-" ) . '…';
}

/**
 * De eigen titel van de huidige pagina, zonder sitenaam erachter: het veld van het bericht, op de homepage anders de
 * titel uit de Site-instellingen. '' als er geen is; dan maakt WordPress de titel. Filter ww_seo_title.
 */
function _ww_seo_own_title(): string {
	$title = _ww_seo_field( 'ww_seo_title', _ww_seo_post_id() );
	if ( '' === $title && is_front_page() ) {
		$title = _ww_plain_text( _ww_setting_string( 'seo_home_title' ) );
	}
	return _ww_plain_text( _ww_data_to_string( apply_filters( 'ww_seo_title', $title ) ) );
}

/**
 * Het begin van de tekst van een bericht: het excerpt, anders post_content (de kopie van de velden, ADR 0008).
 */
function _ww_seo_post_summary( int $post_id ): string {
	$post = get_post( $post_id );
	if ( ! $post instanceof WP_Post || post_password_required( $post ) ) {
		return '';
	}
	$text = '' !== trim( $post->post_excerpt ) ? $post->post_excerpt : strip_shortcodes( $post->post_content );
	return _ww_plain_text( $text );
}

/**
 * De beschrijving van de huidige pagina, of ''. Volgorde: het eigen veld, op de homepage de beschrijving uit de
 * Site-instellingen, het begin van de tekst, en bij een overzicht de beschrijving van de term of het post type.
 */
function _ww_seo_description(): string {
	if ( is_404() || is_search() ) {
		return '';
	}
	$post_id = _ww_seo_post_id();
	$text    = _ww_seo_field( 'ww_seo_description', $post_id );
	if ( '' === $text && is_front_page() ) {
		$text = _ww_plain_text( _ww_setting_string( 'seo_home_description' ) );
	}
	if ( '' === $text && $post_id > 0 ) {
		$text = _ww_seo_post_summary( $post_id );
	}
	if ( '' === $text && is_front_page() ) {
		$text = _ww_plain_text( get_bloginfo( 'description' ) );
	}
	$object = get_queried_object();
	if ( '' === $text && $object instanceof WP_Term ) {
		$text = _ww_plain_text( $object->description );
	}
	if ( '' === $text && $object instanceof WP_Post_Type ) {
		$text = _ww_plain_text( $object->description );
	}
	return (string) apply_filters( 'ww_seo_description', _ww_seo_trim( $text, _ww_seo_length_limits()['description'][1] ) );
}

/**
 * De eigen afbeelding van een bericht: het SEO-veld, anders de uitgelichte afbeelding. 0 zonder, of bij een
 * bericht met wachtwoord.
 */
function _ww_seo_post_image_id( int $post_id ): int {
	if ( $post_id <= 0 || post_password_required( $post_id ) ) {
		return 0;
	}
	return _ww_data_to_attachment_id( _ww_data_get( 'ww_seo_image', $post_id ) ) ?: (int) get_post_thumbnail_id( $post_id );
}

/**
 * De afbeelding bij delen: die van het bericht, anders die uit de Site-instellingen, anders het logo.
 */
function _ww_seo_image_id(): int {
	$image = _ww_seo_post_image_id( _ww_seo_post_id() ) ?: ww_setting_image_id( 'seo_image' ) ?: _ww_schema_logo_id();
	return (int) apply_filters( 'ww_seo_image', $image );
}

/**
 * Staat noindex aan in het SEO-veld van dit bericht? Ook bij een wachtwoord: dat verandert niets aan de vindbaarheid.
 */
function _ww_seo_post_noindex( int $post_id ): bool {
	return _ww_data_to_bool( _ww_data_get_stored( 'ww_seo_noindex', $post_id ) );
}

/**
 * De eigen canonical-URL van een bericht, of ''.
 */
function _ww_seo_post_canonical( int $post_id ): string {
	return esc_url_raw( _ww_data_to_string( _ww_data_get_stored( 'ww_seo_canonical', $post_id ) ), array( 'http', 'https' ) );
}

/**
 * Hoort de huidige pagina niet in zoekmachines: een 404 of zoekresultaten?
 */
function _ww_is_noindex_page(): bool {
	return is_404() || is_search();
}

/**
 * Hoort de huidige pagina niet in zoekmachines, volgens de SEO van het thema? Naast de 404 en de zoekresultaten:
 * een bericht met noindex, een bijlage, en auteurs- en datumarchieven als die in de Site-instellingen uit staan.
 */
function _ww_seo_is_noindex(): bool {
	$post_id = _ww_seo_post_id();
	if ( _ww_is_noindex_page() || is_attachment() || ( $post_id > 0 && _ww_seo_post_noindex( $post_id ) ) ) {
		return true;
	}
	if ( is_author() ) {
		return ! _ww_data_to_bool( _ww_data_get_setting( 'seo_index_author' ) );
	}
	if ( is_date() ) {
		return ! _ww_data_to_bool( _ww_data_get_setting( 'seo_index_date' ) );
	}
	return false;
}

/**
 * De canonical-URL van een overzicht (homepage met berichten, berichtenpagina, archief van een post type, term), met
 * de paginanummering: /page/2/ wijst naar zichzelf. '' bij andere pagina's; losse berichten doet WordPress zelf.
 */
function _ww_seo_archive_canonical(): string {
	if ( is_singular() || _ww_seo_is_noindex() || ! ( is_home() || is_post_type_archive() || is_category() || is_tag() || is_tax() ) ) {
		return '';
	}
	$url  = _ww_schema_page_url();
	$page = (int) get_query_var( 'paged' );
	if ( '' === $url || $page < 2 ) {
		return $url;
	}
	global $wp_rewrite;
	if ( $wp_rewrite instanceof WP_Rewrite && $wp_rewrite->using_permalinks() ) {
		return user_trailingslashit( trailingslashit( $url ) . $wp_rewrite->pagination_base . '/' . $page, 'paged' );
	}
	return add_query_arg( 'paged', $page, $url );
}

/**
 * De URL van de huidige pagina voor delen: de canonical, anders de URL van de pagina.
 */
function _ww_seo_current_url(): string {
	$post_id = is_singular() ? (int) get_queried_object_id() : 0;
	$url     = $post_id > 0 ? wp_get_canonical_url( $post_id ) : _ww_seo_archive_canonical();
	return is_string( $url ) && '' !== $url ? $url : _ww_schema_page_url();
}

/**
 * De titel bij delen, zonder sitenaam: de eigen titel, op de homepage de naam van de site, anders de titel van het
 * bericht of van de pagina.
 */
function _ww_seo_social_title(): string {
	$title = _ww_seo_own_title();
	if ( '' === $title && is_front_page() ) {
		$title = _ww_plain_text( get_bloginfo( 'name' ) );
	}
	$post_id = _ww_seo_post_id();
	if ( '' === $title && $post_id > 0 ) {
		$title = _ww_plain_text( get_the_title( $post_id ) );
	}
	return '' !== $title ? $title : _ww_plain_text( wp_get_document_title() );
}

/*
 * Uitvoer.
 */

/**
 * De eigen titel vervangt de hele titel van WordPress. Een titel die een ander filter al heeft gezet, blijft staan.
 *
 * @param mixed $title Titel tot nu toe, standaard ''.
 * @return mixed
 */
function _ww_seo_document_title( $title ) {
	if ( '' !== _ww_data_to_string( $title ) || ! _ww_seo_enabled() ) {
		return $title;
	}
	$own = _ww_seo_own_title();
	// wp_get_document_title() escapet een titel van dit filter niet zelf.
	return '' === $own ? $title : esc_html( wptexturize( $own ) );
}
add_filter( 'pre_get_document_title', '_ww_seo_document_title', 20 );

/**
 * Het scheidingsteken uit de Site-instellingen.
 *
 * @param mixed $separator Scheidingsteken van WordPress.
 * @return mixed
 */
function _ww_seo_title_separator( $separator ) {
	if ( ! _ww_seo_enabled() ) {
		return $separator;
	}
	return WW_SEO_SEPARATORS[ _ww_setting_string( 'seo_separator' ) ] ?? WW_SEO_SEPARATORS['ndash'];
}
add_filter( 'document_title_separator', '_ww_seo_title_separator' );

/**
 * De meta description in de head.
 */
function _ww_seo_print_description(): void {
	$description = _ww_seo_enabled() ? _ww_seo_description() : '';
	if ( '' !== $description ) {
		printf( '<meta name="description" content="%s" />' . "\n", esc_attr( $description ) );
	}
}
add_action( 'wp_head', '_ww_seo_print_description', 2 );

/**
 * Canonical van een los bericht: de eigen URL uit het SEO-veld, en geen canonical bij noindex.
 *
 * @param mixed $url  Canonical van WordPress.
 * @param mixed $post Bericht.
 * @return mixed
 */
function _ww_seo_canonical_url( $url, $post ) {
	if ( ! _ww_seo_enabled() || ! $post instanceof WP_Post ) {
		return $url;
	}
	if ( _ww_seo_post_noindex( $post->ID ) ) {
		return false;
	}
	$own = _ww_seo_post_canonical( $post->ID );
	return '' !== $own ? $own : $url;
}
add_filter( 'get_canonical_url', '_ww_seo_canonical_url', 10, 2 );

/**
 * Canonical van een overzicht. WordPress zet er zelf alleen een bij losse berichten (rel_canonical()).
 */
function _ww_seo_print_archive_canonical(): void {
	$url = _ww_seo_enabled() ? _ww_seo_archive_canonical() : '';
	if ( '' !== $url ) {
		printf( '<link rel="canonical" href="%s" />' . "\n", esc_url( $url ) );
	}
}
add_action( 'wp_head', '_ww_seo_print_archive_canonical', 10 );

/**
 * Robots van WordPress: noindex op de 404 en de zoekresultaten (ook naast een andere SEO-plugin, behalve The SEO
 * Framework, die zelf een robots-tag zet; inc/integrations/seo.php), en de regels van _ww_seo_is_noindex().
 *
 * @param mixed $robots Robots van WordPress.
 * @return mixed
 */
function _ww_seo_robots( $robots ) {
	if ( ! is_array( $robots ) ) {
		return $robots;
	}
	if ( ( ! _ww_tsf_active() && _ww_is_noindex_page() ) || ( _ww_seo_enabled() && _ww_seo_is_noindex() ) ) {
		$robots['noindex'] = true;
	}
	return $robots;
}
add_filter( 'wp_robots', '_ww_seo_robots' );

/**
 * De tags voor Open Graph en Twitter van de huidige pagina, of array() op de 404 en de zoekresultaten.
 *
 * @return array<int,array{0:string,1:string,2:string}> Attribuut (property of name), naam, inhoud.
 */
function _ww_seo_social_tags(): array {
	if ( _ww_is_noindex_page() ) {
		return array();
	}
	$tags = array(
		array( 'property', 'og:locale', get_locale() ),
		array( 'property', 'og:type', is_singular( 'post' ) ? 'article' : 'website' ),
		array( 'property', 'og:title', _ww_seo_social_title() ),
		array( 'property', 'og:description', _ww_seo_description() ),
		array( 'property', 'og:url', _ww_seo_current_url() ),
		array( 'property', 'og:site_name', _ww_plain_text( get_bloginfo( 'name' ) ) ),
	);
	$image_id = _ww_seo_image_id();
	$image    = $image_id > 0 ? wp_get_attachment_image_src( $image_id, 'large' ) : false;
	if ( is_array( $image ) ) {
		$tags[] = array( 'property', 'og:image', (string) $image[0] );
		$tags[] = array( 'property', 'og:image:width', (string) (int) $image[1] );
		$tags[] = array( 'property', 'og:image:height', (string) (int) $image[2] );
		$tags[] = array( 'property', 'og:image:alt', _ww_plain_text( (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true ) ) );
	}
	$tags[] = array( 'name', 'twitter:card', is_array( $image ) ? 'summary_large_image' : 'summary' );

	// Filter ww_seo_social_tags: dezelfde lijst (attribuut, naam, inhoud), vóór lege waarden eruit gaan. De taalmodule
	// zet hier og:locale:alternate bij. Wat geen drie strings is, gaat eruit.
	$tags = apply_filters( 'ww_seo_social_tags', $tags );
	$tags = is_array( $tags ) ? $tags : array();
	return array_values(
		array_filter(
			$tags,
			static fn( $tag ): bool => is_array( $tag ) && isset( $tag[0], $tag[1], $tag[2] ) && is_string( $tag[0] ) && is_string( $tag[1] ) && is_string( $tag[2] ) && '' !== $tag[2]
		)
	);
}

/**
 * Open Graph en Twitter in de head.
 */
function _ww_seo_print_social(): void {
	if ( ! _ww_seo_enabled() ) {
		return;
	}
	foreach ( _ww_seo_social_tags() as $tag ) {
		$content = in_array( $tag[1], array( 'og:url', 'og:image' ), true ) ? esc_url( $tag[2] ) : esc_attr( $tag[2] );
		printf( '<meta %s="%s" content="%s" />' . "\n", esc_attr( $tag[0] ), esc_attr( $tag[1] ), $content ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hierboven ge-escaped.
	}
}
add_action( 'wp_head', '_ww_seo_print_social', 5 );

/*
 * Sitemap: die van WordPress (wp-sitemap.xml; /sitemap.xml stuurt WordPress zelf door).
 */

/**
 * Geen lijst met gebruikers in de sitemap: die toont gebruikersnamen.
 *
 * @param mixed  $provider Provider van WordPress.
 * @param string $name     Naam: posts, taxonomies of users.
 * @return mixed
 */
function _ww_seo_sitemap_provider( $provider, $name ) {
	return _ww_seo_enabled() && 'users' === $name ? false : $provider;
}
add_filter( 'wp_sitemaps_add_provider', '_ww_seo_sitemap_provider', 10, 2 );

/**
 * Eigen post types die in de sitemap kunnen staan, voor het veld seo_sitemap_exclude (naam => label): dezelfde als
 * WP_Sitemaps_Posts::get_object_subtypes(), zonder bericht en pagina. Die blijven er altijd in.
 *
 * @return array<string,string>
 */
function _ww_seo_sitemap_choices(): array {
	$choices = array();
	foreach ( _ww_seo_sitemap_objects() as $name => $object ) {
		$choices[ $name ] = _ww_plain_text( (string) $object->labels->name );
	}
	return $choices;
}

/**
 * De post types achter _ww_seo_sitemap_choices(), zonder labels; ook voor de cachesleutel van de veldconfig.
 *
 * @return array<string,WP_Post_Type>
 */
function _ww_seo_sitemap_objects(): array {
	$objects = array();
	foreach ( get_post_types( array( 'public' => true ), 'objects' ) as $name => $object ) {
		if ( ! $object->_builtin && is_post_type_viewable( $object ) ) {
			$objects[ (string) $name ] = $object;
		}
	}
	return $objects;
}

/**
 * Het veld seo_sitemap_exclude in de Site-instellingen › SEO (_ww_pods_add_sitemap_field() in inc/config.php). De
 * keuzes hangen af van de geregistreerde post types en staan daarom niet in pods/settings.json. null zonder keuzes.
 *
 * @param array<string,string> $choices Keuzes (_ww_seo_sitemap_choices()).
 * @return array<string,mixed>|null
 */
function _ww_seo_sitemap_field( array $choices ): ?array {
	if ( array() === $choices ) {
		return null;
	}
	$lines = array();
	foreach ( $choices as $name => $label ) {
		$lines[] = $name . '|' . $label;
	}
	return array(
		'name'              => 'seo_sitemap_exclude',
		'label'             => __( 'Niet in de sitemap', 'webwerckt-base' ),
		'type'              => 'pick',
		'pick_object'       => 'custom-simple',
		'pick_custom'       => implode( "\n", $lines ),
		'pick_format_type'  => 'multi',
		'pick_format_multi' => 'checkbox',
		'description'       => __( 'Aangevinkt: die soort pagina\'s staat niet in /sitemap.xml. Niet aangevinkt, en elke nieuwe soort: wel. Pagina\'s en berichten staan er altijd in. De pagina\'s blijven bereikbaar; verbergen voor Google doe je per pagina in de box SEO.', 'webwerckt-base' ),
	);
}

/**
 * Post types die in de Site-instellingen uit de sitemap zijn gehaald. Pods bewaart de keuzes als lijst; een losse
 * tekst (één keuze, of gescheiden door komma's) telt ook. Bericht en pagina nooit.
 *
 * @return string[]
 */
function _ww_seo_sitemap_excluded(): array {
	$raw  = _ww_data_get_setting( 'seo_sitemap_exclude' );
	$list = is_array( $raw ) ? $raw : preg_split( '/[\s,]+/', _ww_data_to_string( $raw ) );
	$out  = array();
	foreach ( is_array( $list ) ? $list : array() as $name ) {
		$name = sanitize_key( _ww_data_to_string( $name ) );
		if ( '' !== $name && ! in_array( $name, array( 'post', 'page' ), true ) ) {
			$out[] = $name;
		}
	}
	return array_values( array_unique( $out ) );
}

/**
 * Post types in de sitemap: zonder die uit de Site-instellingen (seo_sitemap_exclude), daarna het filter
 * ww_sitemap_post_types (naam => WP_Post_Type), zodat een child-thema het laatste woord heeft.
 *
 * @param mixed $post_types Post types van WordPress.
 * @return mixed
 */
function _ww_seo_sitemap_post_types( $post_types ) {
	if ( ! _ww_seo_enabled() ) {
		return $post_types;
	}
	if ( is_array( $post_types ) ) {
		$post_types = array_diff_key( $post_types, array_flip( _ww_seo_sitemap_excluded() ) );
	}
	return apply_filters( 'ww_sitemap_post_types', $post_types );
}
add_filter( 'wp_sitemaps_post_types', '_ww_seo_sitemap_post_types' );

/**
 * Berichten met noindex of een eigen canonical (een kopie van een andere pagina) niet in de sitemap. Een canonical
 * gelijk aan het eigen adres bewaart het thema niet (_ww_seo_clean_canonical()), dus elke ingevulde telt.
 *
 * @param mixed $args Query-argumenten van WordPress.
 * @return mixed
 */
function _ww_seo_sitemap_query_args( $args ) {
	if ( ! _ww_seo_enabled() || ! is_array( $args ) ) {
		return $args;
	}
	$clauses = array(
		'relation' => 'AND',
		array(
			'relation' => 'OR',
			array(
				'key'     => 'ww_seo_noindex',
				'compare' => 'NOT EXISTS',
			),
			array(
				'key'     => 'ww_seo_noindex',
				'value'   => array( '', '0' ),
				'compare' => 'IN',
			),
		),
		array(
			'relation' => 'OR',
			array(
				'key'     => 'ww_seo_canonical',
				'compare' => 'NOT EXISTS',
			),
			array(
				'key'     => 'ww_seo_canonical',
				'value'   => '',
				'compare' => '=',
			),
		),
	);
	if ( isset( $args['meta_query'] ) && is_array( $args['meta_query'] ) && array() !== $args['meta_query'] ) {
		$clauses = array(
			'relation' => 'AND',
			$args['meta_query'],
			$clauses,
		);
	}
	$args['meta_query'] = $clauses; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_query_meta_query -- alleen de sitemap.
	return $args;
}
add_filter( 'wp_sitemaps_posts_query_args', '_ww_seo_sitemap_query_args' );

/**
 * Een canonical gelijk aan het eigen adres is geen kopie: die haalt het thema na het opslaan weg, zodat de pagina in
 * de sitemap blijft.
 *
 * @param int $post_id Bericht-ID.
 */
function _ww_seo_clean_canonical( $post_id ): void {
	$post_id = (int) $post_id;
	$own     = _ww_seo_post_canonical( $post_id );
	$url     = get_permalink( $post_id );
	if ( '' !== $own && is_string( $url ) && untrailingslashit( $own ) === untrailingslashit( $url ) ) {
		delete_post_meta( $post_id, 'ww_seo_canonical' );
	}
}
add_action( 'wp_after_insert_post', '_ww_seo_clean_canonical', 6 );
