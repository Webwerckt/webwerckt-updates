<?php
/**
 * Afbeeldingen: de onderdelen van het scherm Afbeeldingen (inc/images-admin.php). Het zijpaneel met de navigatie en
 * het kaartje, de kiezer voor mobiel, de meldingen, en de inhoud van Overzicht, Wachtrij, Overgeslagen en
 * Instellingen. Alles geeft geëscapete HTML terug; het scherm zet het in elkaar. Zelfde opbouw als Pagina cache
 * (inc/page-cache-admin-sections.php), met een eigen voorvoegsel: er is geen gedeeld paneel (beslissing 0051).
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * De onderdelen van het scherm, in volgorde: tab ⇒ label in de navigatie.
 *
 * @return array<string,string>
 */
function _ww_images_admin_sections(): array {
	return array(
		'overview' => __( 'Overzicht', 'webwerckt-base' ),
		'queue'    => __( 'Wachtrij', 'webwerckt-base' ),
		'problems' => __( 'Overgeslagen', 'webwerckt-base' ),
		'settings' => __( 'Instellingen', 'webwerckt-base' ),
	);
}

/**
 * De kop van een onderdeel. Overgeslagen heet voluit "Overgeslagen en mislukt".
 *
 * @param string $tab Onderdeel.
 */
function _ww_images_admin_title( string $tab ): string {
	if ( 'problems' === $tab ) {
		return __( 'Overgeslagen en mislukt', 'webwerckt-base' );
	}
	$sections = _ww_images_admin_sections();
	return $sections[ $tab ] ?? $sections['overview'];
}

/**
 * Het gekozen onderdeel uit ?tab=, of overview als dat ontbreekt of onbekend is.
 */
function _ww_images_admin_tab(): string {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen lezen, tegen de lijst gehouden.
	$tab = isset( $_GET['tab'] ) && is_string( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : '';
	return array_key_exists( $tab, _ww_images_admin_sections() ) ? $tab : 'overview';
}

/**
 * De gevraagde bevestiging: 'redo' of 'wipe', alleen op Instellingen. Anders ''.
 *
 * @param string $tab Gekozen onderdeel.
 */
function _ww_images_admin_confirm( string $tab ): string {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen lezen, tegen de lijst gehouden; de actie zelf heeft een nonce.
	$confirm = isset( $_GET['confirm'] ) && is_string( $_GET['confirm'] ) ? sanitize_key( wp_unslash( $_GET['confirm'] ) ) : '';
	return 'settings' === $tab && in_array( $confirm, array( 'redo', 'wipe' ), true ) ? $confirm : '';
}

/**
 * Een verborgen nonceveld zonder id, zodat meerdere formulieren op één scherm geen dubbele id's geven.
 *
 * @param string $action Naam van de nonce.
 */
function _ww_images_nonce_input( string $action ): string {
	return '<input type="hidden" name="_wpnonce" value="' . esc_attr( wp_create_nonce( $action ) ) . '">';
}

/**
 * Een formulier met één knop voor een actie via admin-post.php.
 *
 * @param string $action   Actie, zoals ww_images_run_now; ook de naam van de nonce.
 * @param string $label    Tekst op de knop.
 * @param bool   $disabled Knop uitgeschakeld.
 * @param string $class    Klassen van de knop.
 */
function _ww_images_action_form( string $action, string $label, bool $disabled = false, string $class = 'button' ): string {
	return '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="ww-images-form">'
		. '<input type="hidden" name="action" value="' . esc_attr( $action ) . '">'
		. _ww_images_nonce_input( $action )
		. '<button type="submit" class="' . esc_attr( $class ) . '"' . ( $disabled ? ' disabled' : '' ) . '>' . esc_html( $label ) . '</button>'
		. '</form>';
}

/**
 * Hoeveel afbeeldingen de bibliotheek heeft (de soorten die de optimaliseerder kent).
 */
function _ww_images_total(): int {
	$args = _ww_images_queue_args( 1 );
	unset( $args['meta_query'] );
	$args['no_found_rows'] = false;
	return ( new WP_Query( $args ) )->found_posts;
}

/**
 * De aantallen voor het paneel en Overzicht: alles, in de wachtrij, bij Overgeslagen, en daarvan mislukt.
 *
 * @return array{total:int,queue:int,problems:int,failed:int}
 */
function _ww_images_admin_counts(): array {
	$buckets = _ww_images_problem_buckets();
	return array(
		'total'    => _ww_images_total(),
		'queue'    => _ww_images_count( 'queue' ),
		'problems' => _ww_images_problem_ids( 'all', 0, 0, $buckets )['total'],
		'failed'   => count( $buckets['failed'] ),
	);
}

/**
 * De status bovenin het paneel: groen Actief, geel als de wachtrij achterloopt (dezelfde regel als Site-status), rood
 * als de optimaliseerder uit staat, de server niets kan of er geen formaat gekozen is.
 *
 * @param int|null $queue Aantal in de wachtrij, als dat al bekend is.
 * @return array{class:string,label:string} class is '', 'warn' of 'off'.
 */
function _ww_images_admin_status( ?int $queue = null ): array {
	if ( ! _ww_images_enabled() ) {
		return array(
			'class' => 'off',
			'label' => __( 'Staat uit', 'webwerckt-base' ),
		);
	}
	if ( array() === _ww_images_server_formats() ) {
		return array(
			'class' => 'off',
			'label' => class_exists( 'Imagick' ) ? __( 'Kan niet: geen AVIF of WebP op deze server', 'webwerckt-base' ) : __( 'Kan niet: Imagick ontbreekt', 'webwerckt-base' ),
		);
	}
	if ( array() === _ww_images_formats() ) {
		return array(
			'class' => 'off',
			'label' => __( 'Staat uit: geen formaat gekozen', 'webwerckt-base' ),
		);
	}
	if ( _ww_images_behind( $queue ?? _ww_images_count( 'queue' ) ) ) {
		return array(
			'class' => 'warn',
			'label' => __( 'Wachtrij loopt achter', 'webwerckt-base' ),
		);
	}
	return array(
		'class' => '',
		'label' => __( 'Actief', 'webwerckt-base' ),
	);
}

/**
 * De status als stip met tekst.
 *
 * @param array{class:string,label:string} $status Uitkomst van _ww_images_admin_status().
 */
function _ww_images_status_html( array $status ): string {
	$class = '' !== $status['class'] ? ' ww-images-dot--' . $status['class'] : '';
	return '<span class="ww-images-dot' . esc_attr( $class ) . '" aria-hidden="true"></span>' . esc_html( $status['label'] );
}

/**
 * Het aantal achter een onderdeel, of '' (Overzicht en Instellingen hebben er geen).
 *
 * @param string                                             $tab    Onderdeel.
 * @param array{total:int,queue:int,problems:int,failed:int} $counts Aantallen.
 */
function _ww_images_nav_count( string $tab, array $counts ): string {
	if ( ! in_array( $tab, array( 'queue', 'problems' ), true ) ) {
		return '';
	}
	$warn = 'problems' === $tab && $counts['failed'] > 0;
	return '<span class="ww-images-count' . ( $warn ? ' ww-images-count--warn' : '' ) . '">' . esc_html( number_format_i18n( $counts[ $tab ] ) ) . '</span>';
}

/**
 * De navigatie langs de onderdelen: als lijst in het paneel, of als kiezer voor mobiel.
 *
 * @param string                                             $active  Gekozen onderdeel.
 * @param array{total:int,queue:int,problems:int,failed:int} $counts  Aantallen.
 * @param string                                             $variant 'panel' of 'menu'.
 */
function _ww_images_render_nav( string $active, array $counts, string $variant ): string {
	$sections = _ww_images_admin_sections();
	$icons    = array(
		'overview' => 'dashicons-chart-bar',
		'queue'    => 'dashicons-list-view',
		'problems' => 'dashicons-warning',
		'settings' => 'dashicons-admin-generic',
	);
	$items    = '';
	foreach ( $sections as $tab => $label ) {
		$icon   = 'panel' === $variant ? '<span class="dashicons ' . esc_attr( $icons[ $tab ] ) . '" aria-hidden="true"></span>' : '';
		$items .= '<li><a href="' . esc_url( _ww_images_admin_url( array( 'tab' => $tab ) ) ) . '"' . ( $tab === $active ? ' aria-current="page"' : '' ) . '>'
			. $icon . '<span class="ww-images-nav__label">' . esc_html( $label ) . '</span>' . _ww_images_nav_count( $tab, $counts ) . '</a></li>';
	}
	if ( 'panel' === $variant ) {
		return '<ul class="ww-images-panel__nav">' . $items . '</ul>';
	}
	return '<details class="ww-images-menu"><summary><span>' . esc_html__( 'Onderdeel', 'webwerckt-base' ) . '</span> <b>' . esc_html( $sections[ $active ] ?? $sections['overview'] ) . '</b></summary><ul>' . $items . '</ul></details>';
}

/**
 * Wanneer de laatste run was, zoals "5 minuten geleden", of "nog nooit".
 */
function _ww_images_last_run_text(): string {
	$last = (int) get_option( 'ww_images_last_run', 0 );
	if ( $last <= 0 ) {
		return __( 'nog nooit', 'webwerckt-base' );
	}
	/* translators: %s: tijdsduur, zoals 5 minuten. */
	return sprintf( __( '%s geleden', 'webwerckt-base' ), human_time_diff( $last ) );
}

/**
 * Of de site een eigen cron heeft (DISABLE_WP_CRON met een taak op de server) in plaats van WordPress-cron.
 */
function _ww_images_own_cron(): bool {
	return defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON;
}

/**
 * Wanneer de volgende run is: "over 3 minuten", of bij WordPress-cron zonder tijd in de toekomst "bij het volgende
 * bezoek".
 */
function _ww_images_next_run_text(): string {
	$next = (int) wp_next_scheduled( WW_IMAGES_RUN_HOOK );
	if ( $next > time() ) {
		/* translators: %s: tijdsduur, zoals 3 minuten. */
		return sprintf( __( 'over %s', 'webwerckt-base' ), human_time_diff( time(), $next ) );
	}
	if ( 0 === $next ) {
		return __( 'niet gepland', 'webwerckt-base' );
	}
	return _ww_images_own_cron() ? __( 'bij de volgende cron', 'webwerckt-base' ) : __( 'bij het volgende bezoek', 'webwerckt-base' );
}

/**
 * Een voortgangsbalk van 6 px: blauw, of groen als alles klaar is.
 *
 * @param int $done  Klaar.
 * @param int $total Totaal.
 */
function _ww_images_bar( int $done, int $total ): string {
	$pct      = $total > 0 ? (int) min( 100, round( $done / $total * 100 ) ) : 0;
	$complete = $total > 0 && $done >= $total;
	return '<div class="ww-images-bar' . ( $complete ? ' is-done' : '' ) . '" aria-hidden="true"><span style="width:' . esc_attr( (string) $pct ) . '%"></span></div>';
}

/**
 * Een vak met een kop, of zonder kop als $title leeg is.
 *
 * @param string $title Kop, of ''.
 * @param string $inner Geëscapete inhoud.
 * @param string $extra Grijze tekst rechts in de kop, of ''.
 * @param string $class Extra klasse, of ''.
 */
function _ww_images_box( string $title, string $inner, string $extra = '', string $class = '' ): string {
	$head = '';
	if ( '' !== $title ) {
		$head = '<h2><span>' . esc_html( $title ) . '</span>' . ( '' !== $extra ? ' <small>' . esc_html( $extra ) . '</small>' : '' ) . '</h2>';
	}
	return '<section class="ww-images-box' . ( '' !== $class ? ' ' . esc_attr( $class ) : '' ) . '">' . $head . $inner . '</section>';
}

/**
 * De naam van een formaat: AVIF of WebP.
 *
 * @param string $format 'avif' of 'webp'.
 */
function _ww_images_format_name( string $format ): string {
	return 'webp' === $format ? 'WebP' : strtoupper( $format );
}

/**
 * Hoeveel procent kleiner, afgerond. 0 als er niets te vergelijken is.
 *
 * @param int $before Bytes vóór.
 * @param int $after  Bytes na.
 */
function _ww_images_pct_smaller( int $before, int $after ): int {
	return $before > 0 && $after < $before ? (int) round( 100 * ( $before - $after ) / $before ) : 0;
}

/**
 * De versie van ImageMagick, zoals "7.1.1-29", of '' zonder Imagick.
 */
function _ww_images_imagick_version(): string {
	if ( ! class_exists( 'Imagick' ) ) {
		return '';
	}
	$version = (string) Imagick::getVersion()['versionString'];
	return preg_match( '/ImageMagick\s+(\S+)/', $version, $match ) ? $match[1] : $version;
}

/**
 * Het kaartje in het paneel: hoeveel afbeeldingen verwerkt zijn, met een balk, de laatste en volgende run en de soort
 * cron.
 *
 * @param array{total:int,queue:int,problems:int,failed:int} $counts Aantallen.
 */
function _ww_images_render_panel_card( array $counts ): string {
	if ( ! _ww_images_enabled() ) {
		return '<div class="ww-images-panel__card"><strong>' . esc_html__( 'Optimaliseerder uit', 'webwerckt-base' ) . '</strong>'
			. '<p>' . esc_html__( 'Bezoekers krijgen de originele bestanden.', 'webwerckt-base' ) . '</p></div>';
	}
	$done = max( 0, $counts['total'] - $counts['queue'] );
	return '<div class="ww-images-panel__card"><strong>' . esc_html(
		sprintf(
			/* translators: 1: aantal verwerkt, 2: aantal afbeeldingen. */
			__( '%1$s van %2$s verwerkt', 'webwerckt-base' ),
			number_format_i18n( $done ),
			number_format_i18n( $counts['total'] )
		)
	) . '</strong>'
		. _ww_images_bar( $done, $counts['total'] )
		. '<dl>'
		. '<dt>' . esc_html__( 'Laatste run', 'webwerckt-base' ) . '</dt><dd>' . esc_html( _ww_images_last_run_text() ) . '</dd>'
		. '<dt>' . esc_html__( 'Volgende', 'webwerckt-base' ) . '</dt><dd>' . esc_html( _ww_images_next_run_text() ) . '</dd>'
		. '<dt>' . esc_html__( 'Cron', 'webwerckt-base' ) . '</dt><dd>' . esc_html( _ww_images_own_cron() ? __( 'Eigen cron', 'webwerckt-base' ) : __( 'WordPress', 'webwerckt-base' ) ) . '</dd>'
		. '</dl></div>';
}

/**
 * Een melding met de klassen van WordPress.
 *
 * @param string $type        success, warning, info of error.
 * @param string $html        Geëscapete inhoud.
 * @param bool   $dismissible Wegklikbaar.
 */
function _ww_images_notice( string $type, string $html, bool $dismissible = false ): string {
	return '<div class="notice notice-' . esc_attr( $type ) . ( $dismissible ? ' is-dismissible' : '' ) . '"><p>' . $html . '</p></div>';
}

/**
 * De melding na een actie, uit ?ww_done= (run:{n}, busy, retry:{id}, redo, wipe, wipe_locked, wiping). Een onbekende waarde geeft
 * niets.
 *
 * @param int $queue Aantal in de wachtrij nu (na de run): alleen dan "De rest volgt".
 */
function _ww_images_done_notice( int $queue = 0 ): string {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen een melding tonen.
	$done = isset( $_GET['ww_done'] ) && is_string( $_GET['ww_done'] ) ? sanitize_text_field( wp_unslash( $_GET['ww_done'] ) ) : '';
	list( $kind, $arg ) = array_pad( explode( ':', $done, 2 ), 2, '' );
	switch ( $kind ) {
		case 'run':
			if ( ! ctype_digit( $arg ) ) {
				return '';
			}
			$count = (int) $arg;
			$text  = sprintf(
				/* translators: %s: aantal afbeeldingen. */
				_n( 'Run klaar: %s afbeelding verwerkt.', 'Run klaar: %s afbeeldingen verwerkt.', $count, 'webwerckt-base' ),
				number_format_i18n( $count )
			);
			if ( $queue > 0 ) {
				$text .= ' ' . __( 'De rest volgt in de volgende runs.', 'webwerckt-base' );
			}
			return _ww_images_notice( 'success', esc_html( $text ), true );
		case 'busy':
			return _ww_images_notice( 'warning', esc_html__( 'Er loopt al een run. Probeer het over een minuut opnieuw.', 'webwerckt-base' ), true );
		case 'retry':
			$id    = absint( $arg );
			$title = $id > 0 && 'attachment' === get_post_type( $id ) ? get_the_title( $id ) : '';
			$text  = '' !== $title
				/* translators: %s: titel van de afbeelding. */
				? sprintf( __( '%s staat weer in de wachtrij.', 'webwerckt-base' ), $title )
				: __( 'De afbeelding staat weer in de wachtrij.', 'webwerckt-base' );
			return _ww_images_notice( 'success', esc_html( $text ), true );
		case 'redo':
			return _ww_images_notice( 'success', esc_html__( 'Alle afbeeldingen staan in de wachtrij. Bezoekers houden de huidige versies tot de nieuwe klaar zijn.', 'webwerckt-base' ), true );
		case 'wipe':
			return _ww_images_notice( 'success', esc_html__( 'De versies worden verwijderd en Moderne formaten staat uit. Bezoekers krijgen de originele bestanden.', 'webwerckt-base' ), true );
		case 'wipe_locked':
			return _ww_images_notice( 'warning', esc_html__( 'Versies verwijderen kan niet: het child-thema of een plugin houdt Moderne formaten aan (filter ww_image_variants), dus het thema zou alles meteen opnieuw maken. Er is niets verwijderd.', 'webwerckt-base' ), true );
		case 'wiping':
			return _ww_images_notice( 'warning', esc_html__( 'Alles opnieuw maken kan niet terwijl de versies verwijderd worden. Probeer het opnieuw als dat klaar is.', 'webwerckt-base' ), true );
	}
	return '';
}

/**
 * Alle meldingen boven de inhoud: de uitkomst van een actie of van opslaan, het verwijderen dat loopt, "loopt achter"
 * (Overzicht en Wachtrij) en een server zonder AVIF (Overzicht en Instellingen).
 *
 * @param string                                             $tab    Gekozen onderdeel.
 * @param array{total:int,queue:int,problems:int,failed:int} $counts Aantallen.
 */
function _ww_images_admin_notices( string $tab, array $counts ): string {
	$html = _ww_images_done_notice( $counts['queue'] );

	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen een melding tonen; options.php stuurt dit terug.
	if ( 'settings' === $tab && isset( $_GET['settings-updated'] ) ) {
		// Alleen hier lezen: de functie haalt de melding weg.
		if ( _ww_images_quality_changed() ) {
			$html .= _ww_images_notice(
				'success',
				esc_html__( 'Instellingen opgeslagen. De nieuwe kwaliteit geldt voor nieuwe versies.', 'webwerckt-base' )
					. ' <a href="' . esc_url(
						_ww_images_admin_url(
							array(
								'tab'     => 'settings',
								'confirm' => 'redo',
							)
						)
					) . '#ww-images-maintenance">' . esc_html__( 'Bestaande afbeeldingen opnieuw maken', 'webwerckt-base' ) . '</a>',
				true
			);
		} else {
			$html .= _ww_images_notice( 'success', esc_html__( 'Instellingen opgeslagen.', 'webwerckt-base' ), true );
		}
	}

	if ( _ww_images_wiping() ) {
		$wipe   = get_option( WW_IMAGES_WIPE );
		$done   = is_array( $wipe ) ? (int) ( $wipe['done'] ?? 0 ) : 0;
		$html  .= _ww_images_notice(
			'info',
			esc_html(
				sprintf(
					/* translators: 1: aantal afbeeldingen gedaan, 2: aantal afbeeldingen. */
					__( 'De versies worden verwijderd: %1$s van %2$s afbeeldingen gedaan. Bezoekers krijgen intussen de originele bestanden. Alles opnieuw maken kan weer als dit klaar is.', 'webwerckt-base' ),
					number_format_i18n( min( $done, $counts['total'] ) ),
					number_format_i18n( $counts['total'] )
				)
			)
		);
	}

	$server = _ww_images_server_formats();
	if ( in_array( $tab, array( 'overview', 'queue' ), true ) && _ww_images_enabled() && array() !== $server && _ww_images_behind( $counts['queue'] ) ) {
		$text = '<strong>' . esc_html__( 'De optimaliseerder heeft al meer dan een uur niet gedraaid.', 'webwerckt-base' ) . '</strong> ';
		if ( ! _ww_images_own_cron() ) {
			$text .= esc_html__( 'WordPress-cron draait alleen als er bezoek is. Een echte cron op de server houdt de wachtrij ook op een stille site kort.', 'webwerckt-base' ) . ' ';
		}
		$text .= '<a href="' . esc_url( admin_url( 'site-health.php' ) ) . '">' . esc_html__( 'Bekijk Site-gezondheid', 'webwerckt-base' ) . '</a>';
		$html .= _ww_images_notice( 'warning', $text );
	}

	if ( in_array( $tab, array( 'overview', 'settings' ), true ) && ! in_array( 'avif', $server, true ) ) {
		$text  = array() === $server
			? __( 'Deze server kan geen AVIF of WebP maken: Imagick ontbreekt of kan deze formaten niet schrijven. Bezoekers krijgen de originele bestanden.', 'webwerckt-base' )
			: __( 'Deze server kan geen AVIF maken (ImageMagick zonder AVIF). Het thema maakt alleen WebP. Komt AVIF later beschikbaar, dan gaat de bibliotheek vanzelf opnieuw door de wachtrij.', 'webwerckt-base' );
		$html .= _ww_images_notice( 'info', esc_html( $text ) );
	}
	return $html;
}

/**
 * Overzicht: het vak met de kerncijfers en de knoppen, dan Per formaat, Per soort bestand en Grootste winst, en
 * onderaan wanneer de telling was.
 *
 * @param array{total:int,queue:int,problems:int,failed:int}|null $counts Aantallen, of null om ze op te halen.
 */
function _ww_images_render_overview( ?array $counts = null ): string {
	$counts = $counts ?? _ww_images_admin_counts();
	$totals = _ww_images_totals();
	return _ww_images_overview_summary( $counts, $totals )
		. '<div class="ww-images-blocks">'
		. _ww_images_overview_formats( $totals )
		. _ww_images_overview_mime( $totals )
		. _ww_images_overview_top( $totals )
		. '</div>'
		. _ww_images_overview_stamp( $totals );
}

/**
 * Of de knop "Nu een run starten" iets kan doen, met dezelfde voorwaarden als _ww_images_run(): er wordt verwijderd,
 * er is om een nieuwe telling gevraagd (na Alles opnieuw maken), of de optimaliseerder kan werken en er staat iets in
 * de wachtrij of de telling is aan de beurt (nog geen telling, of ouder dan een uur).
 *
 * @param int $queue Aantal in de wachtrij.
 */
function _ww_images_can_run( int $queue ): bool {
	if ( _ww_images_wiping() || _ww_images_count_pending() ) {
		return true;
	}
	return _ww_images_enabled() && array() !== _ww_images_formats() && ( $queue > 0 || _ww_images_count_due() );
}

/**
 * Het vak met de kerncijfers Verwerkt, Kleiner geworden en Formaten, met de knoppen eronder.
 *
 * @param array{total:int,queue:int,problems:int,failed:int} $counts Aantallen.
 * @param array<string,mixed>|null                           $totals De telling, of null.
 */
function _ww_images_overview_summary( array $counts, ?array $totals ): string {
	$done = max( 0, $counts['total'] - $counts['queue'] );

	$processed = '<div class="ww-images-kpi"><span class="ww-images-kpi__label">' . esc_html__( 'Verwerkt', 'webwerckt-base' ) . '</span>'
		. '<span class="ww-images-kpi__value">' . esc_html( number_format_i18n( $done ) ) . ' <small>' . esc_html(
			sprintf(
				/* translators: %s: aantal afbeeldingen. */
				_n( 'van %s afbeelding', 'van %s afbeeldingen', $counts['total'], 'webwerckt-base' ),
				number_format_i18n( $counts['total'] )
			)
		) . '</small></span>'
		. _ww_images_bar( $done, $counts['total'] )
		. '<span class="ww-images-kpi__sub">' . esc_html(
			0 === $counts['queue']
				? __( 'Alles is verwerkt.', 'webwerckt-base' )
				: sprintf(
					/* translators: %s: aantal afbeeldingen. */
					_n( '%s afbeelding in de wachtrij', '%s afbeeldingen in de wachtrij', $counts['queue'], 'webwerckt-base' ),
					number_format_i18n( $counts['queue'] )
				)
		) . '</span></div>';

	if ( null === $totals ) {
		$value = __( 'Wordt geteld', 'webwerckt-base' );
		$sub   = __( 'De eerste telling loopt tijdens de volgende runs.', 'webwerckt-base' );
	} else {
		$before = (int) ( $totals['before'] ?? 0 );
		$after  = (int) ( $totals['after'] ?? 0 );
		/* translators: %d: percentage. */
		$value = sprintf( __( '%d%%', 'webwerckt-base' ), _ww_images_pct_smaller( $before, $after ) );
		$sub   = sprintf(
			/* translators: 1: grootte vóór, 2: grootte na, zoals 708 MB. */
			__( 'Van %1$s naar %2$s, als elke browser het kleinste formaat neemt', 'webwerckt-base' ),
			size_format( $before ) ?: '0 B',
			size_format( $after ) ?: '0 B'
		);
	}
	$smaller = '<div class="ww-images-kpi"><span class="ww-images-kpi__label">' . esc_html__( 'Kleiner geworden', 'webwerckt-base' ) . '</span>'
		. '<span class="ww-images-kpi__value">' . esc_html( $value ) . '</span>'
		. '<span class="ww-images-kpi__sub">' . esc_html( $sub ) . '</span></div>';

	$formats = _ww_images_enabled() ? _ww_images_formats() : array();
	$quality = array();
	foreach ( $formats as $format ) {
		$quality[] = _ww_images_format_name( $format ) . ' ' . _ww_images_quality( $format );
	}
	$names = array() !== $formats ? implode( ' + ', array_map( '_ww_images_format_name', $formats ) ) : __( 'Geen', 'webwerckt-base' );
	$sub   = array() !== $quality
		/* translators: %s: kwaliteit per formaat, zoals "AVIF 60, WebP 80". */
		? esc_html( sprintf( __( 'Kwaliteit %s', 'webwerckt-base' ), implode( ', ', $quality ) ) ) . ' · '
		: esc_html__( 'Bezoekers krijgen de originele bestanden.', 'webwerckt-base' ) . ' ';
	$sub  .= '<a href="' . esc_url( _ww_images_admin_url( array( 'tab' => 'settings' ) ) ) . '">' . esc_html__( 'Wijzigen', 'webwerckt-base' ) . '</a>';
	$kinds = '<div class="ww-images-kpi"><span class="ww-images-kpi__label">' . esc_html__( 'Formaten', 'webwerckt-base' ) . '</span>'
		. '<span class="ww-images-kpi__value">' . esc_html( $names ) . '</span>'
		. '<span class="ww-images-kpi__sub">' . $sub . '</span></div>';

	$foot = _ww_images_action_form( 'ww_images_run_now', __( 'Nu een run starten', 'webwerckt-base' ), ! _ww_images_can_run( $counts['queue'] ) )
		. '<a class="button" href="' . esc_url( admin_url( 'upload.php?mode=list' ) ) . '">' . esc_html__( 'Bekijk in de mediabibliotheek', 'webwerckt-base' ) . '</a>'
		. '<span class="ww-images-summary__hint">' . esc_html__( 'Elke afbeelding heeft daar ook een kolom Optimalisatie.', 'webwerckt-base' ) . '</span>';

	return '<section class="ww-images-box ww-images-summary"><div class="ww-images-kpis">' . $processed . $smaller . $kinds . '</div>'
		. '<div class="ww-images-summary__foot">' . $foot . '</div></section>';
}

/**
 * Een gestapelde balk met gemaakt, niet kleiner, overgeslagen, mislukt en nog te doen.
 *
 * @param array<string,int> $buckets Aantallen per stand (ok, none, skip, failed, todo).
 */
function _ww_images_split( array $buckets ): string {
	$parts = array(
		'ok'     => __( 'gemaakt', 'webwerckt-base' ),
		'none'   => __( 'niet kleiner', 'webwerckt-base' ),
		'skip'   => __( 'overgeslagen', 'webwerckt-base' ),
		'failed' => __( 'mislukt', 'webwerckt-base' ),
		'todo'   => __( 'nog te doen', 'webwerckt-base' ),
	);
	$total = array_sum( array_map( 'intval', array_intersect_key( $buckets, $parts ) ) );
	$bars  = '';
	$label = array();
	foreach ( $parts as $key => $text ) {
		$number  = (int) ( $buckets[ $key ] ?? 0 );
		$label[] = number_format_i18n( $number ) . ' ' . $text;
		if ( $total > 0 && $number > 0 ) {
			$bars .= '<i class="ww-images-split__' . esc_attr( $key ) . '" style="width:' . esc_attr( number_format( $number / $total * 100, 2, '.', '' ) ) . '%"></i>';
		}
	}
	return '<span class="ww-images-split" role="img" aria-label="' . esc_attr( implode( ', ', $label ) ) . '">' . $bars . '</span>';
}

/**
 * Het blok Per formaat, in bestanden: een gestapelde balk per formaat met een legenda, en de kolommen Gemaakt, Niet
 * kleiner en Mislukt. Een formaat dat de server niet kan, staat er grijs bij.
 *
 * @param array<string,mixed>|null $totals De telling, of null.
 */
function _ww_images_overview_formats( ?array $totals ): string {
	$server = _ww_images_server_formats();
	$rows   = '';
	foreach ( WW_IMAGES_FORMATS as $format ) {
		$name = esc_html( _ww_images_format_name( $format ) );
		if ( ! in_array( $format, $server, true ) ) {
			$rows .= '<tr class="is-unavailable"><th scope="row">' . $name . '</th><td colspan="4">' . esc_html__( 'Niet beschikbaar op deze server', 'webwerckt-base' ) . '</td></tr>';
			continue;
		}
		if ( null === $totals ) {
			$rows .= '<tr><th scope="row">' . $name . '</th><td colspan="4">' . esc_html__( 'Wordt geteld', 'webwerckt-base' ) . '</td></tr>';
			continue;
		}
		$buckets = is_array( $totals['formats'][ $format ] ?? null ) ? $totals['formats'][ $format ] : array();
		$rows   .= '<tr><th scope="row">' . $name . '</th><td>' . _ww_images_split( $buckets ) . '</td>'
			. '<td class="ww-images-num">' . esc_html( number_format_i18n( (int) ( $buckets['ok'] ?? 0 ) ) ) . '</td>'
			. '<td class="ww-images-num hide-m">' . esc_html( number_format_i18n( (int) ( $buckets['none'] ?? 0 ) ) ) . '</td>'
			. '<td class="ww-images-num hide-m">' . esc_html( number_format_i18n( (int) ( $buckets['failed'] ?? 0 ) ) ) . '</td></tr>';
	}
	$legend = '';
	foreach (
		array(
			'ok'     => __( 'Gemaakt', 'webwerckt-base' ),
			'none'   => __( 'Niet kleiner, origineel gebruikt', 'webwerckt-base' ),
			'skip'   => __( 'Overgeslagen', 'webwerckt-base' ),
			'failed' => __( 'Mislukt', 'webwerckt-base' ),
			'todo'   => __( 'Nog te doen', 'webwerckt-base' ),
		) as $key => $text
	) {
		$legend .= '<span><i class="ww-images-split__' . esc_attr( $key ) . '"></i>' . esc_html( $text ) . '</span>';
	}
	$table = '<table class="ww-images-table"><thead><tr>'
		. '<th scope="col">' . esc_html__( 'Formaat', 'webwerckt-base' ) . '</th>'
		. '<th scope="col" class="ww-images-table__split">' . esc_html__( 'Verdeling', 'webwerckt-base' ) . '</th>'
		. '<th scope="col" class="ww-images-num">' . esc_html__( 'Gemaakt', 'webwerckt-base' ) . '</th>'
		. '<th scope="col" class="ww-images-num hide-m">' . esc_html__( 'Niet kleiner', 'webwerckt-base' ) . '</th>'
		. '<th scope="col" class="ww-images-num hide-m">' . esc_html__( 'Mislukt', 'webwerckt-base' ) . '</th>'
		. '</tr></thead><tbody>' . $rows . '</tbody></table>'
		. '<div class="ww-images-legend" aria-hidden="true">' . $legend . '</div>';
	return _ww_images_box( __( 'Per formaat', 'webwerckt-base' ), $table, __( 'in bestanden: elk formaat van WordPress telt apart', 'webwerckt-base' ), 'ww-images-box--wide' );
}

/**
 * Het blok Per soort bestand: JPEG, PNG, GIF en WebP met het aantal afbeeldingen en hoeveel kleiner.
 *
 * @param array<string,mixed>|null $totals De telling, of null.
 */
function _ww_images_overview_mime( ?array $totals ): string {
	if ( null === $totals ) {
		return _ww_images_box( __( 'Per soort bestand', 'webwerckt-base' ), '<p class="ww-images-empty">' . esc_html__( 'Wordt geteld', 'webwerckt-base' ) . '</p>' );
	}
	$kinds = array(
		'image/jpeg' => array( 'JPEG', '' ),
		'image/png'  => array( 'PNG', '' ),
		'image/gif'  => array( 'GIF', __( 'geanimeerde GIF\'s blijven zoals ze zijn', 'webwerckt-base' ) ),
		'image/webp' => array( 'WebP', __( 'krijgt alleen AVIF', 'webwerckt-base' ) ),
	);
	$mime  = is_array( $totals['mime'] ?? null ) ? $totals['mime'] : array();
	$rows  = '';
	foreach ( $kinds as $type => list( $name, $note ) ) {
		if ( ! isset( $mime[ $type ] ) ) {
			continue;
		}
		$one   = $mime[ $type ];
		$pct   = _ww_images_pct_smaller( (int) ( $one['before'] ?? 0 ), (int) ( $one['after'] ?? 0 ) );
		$rows .= '<tr><th scope="row">' . esc_html( $name ) . ( '' !== $note ? '<span class="ww-images-path">' . esc_html( $note ) . '</span>' : '' ) . '</th>'
			. '<td class="ww-images-num">' . esc_html( number_format_i18n( (int) ( $one['images'] ?? 0 ) ) ) . '</td>'
			/* translators: %d: percentage. */
			. '<td class="ww-images-num' . ( $pct > 0 ? ' is-good' : '' ) . '">' . esc_html( $pct > 0 ? sprintf( __( '−%d%%', 'webwerckt-base' ), $pct ) : '0%' ) . '</td></tr>';
	}
	if ( '' === $rows ) {
		return _ww_images_box( __( 'Per soort bestand', 'webwerckt-base' ), '<p class="ww-images-empty">' . esc_html__( 'Nog geen afbeeldingen geteld.', 'webwerckt-base' ) . '</p>' );
	}
	$table = '<table class="ww-images-table"><thead><tr>'
		. '<th scope="col">' . esc_html__( 'Geüpload als', 'webwerckt-base' ) . '</th>'
		. '<th scope="col" class="ww-images-num">' . esc_html__( 'Afbeeldingen', 'webwerckt-base' ) . '</th>'
		. '<th scope="col" class="ww-images-num">' . esc_html__( 'Kleiner', 'webwerckt-base' ) . '</th>'
		. '</tr></thead><tbody>' . $rows . '</tbody></table>';
	return _ww_images_box( __( 'Per soort bestand', 'webwerckt-base' ), $table );
}

/**
 * Het blok Grootste winst: de vijf afbeeldingen met de meeste bytes bespaard op het hoofdbestand.
 *
 * @param array<string,mixed>|null $totals De telling, of null.
 */
function _ww_images_overview_top( ?array $totals ): string {
	$title = __( 'Grootste winst', 'webwerckt-base' );
	$extra = __( 'hoofdbestand', 'webwerckt-base' );
	if ( null === $totals ) {
		return _ww_images_box( $title, '<p class="ww-images-empty">' . esc_html__( 'Wordt geteld', 'webwerckt-base' ) . '</p>', $extra );
	}
	$top = is_array( $totals['top'] ?? null ) ? $totals['top'] : array();
	// De bijlagen en hun meta in één keer, niet per regel.
	$ids = array();
	foreach ( $top as $item ) {
		$id = (int) ( $item['id'] ?? 0 );
		if ( $id > 0 ) {
			$ids[ $id ] = $id;
		}
	}
	if ( array() !== $ids ) {
		_prime_post_caches( array_values( $ids ), false, true );
	}
	$rows = '';
	foreach ( $top as $item ) {
		$id = (int) ( $item['id'] ?? 0 );
		if ( $id <= 0 || 'attachment' !== get_post_type( $id ) ) {
			continue;
		}
		$before = (int) ( $item['before'] ?? 0 );
		$after  = (int) ( $item['after'] ?? 0 );
		$file   = wp_basename( (string) get_post_meta( $id, '_wp_attached_file', true ) );
		$name   = get_the_title( $id );
		$name   = '' !== $name ? $name : $file;
		$edit   = get_edit_post_link( $id );
		$label  = $edit ? '<a href="' . esc_url( $edit ) . '"><strong>' . esc_html( $name ) . '</strong></a>' : '<strong>' . esc_html( $name ) . '</strong>';
		$rows  .= '<tr><td><div class="ww-images-cell">' . wp_get_attachment_image( $id, array( 40, 40 ), true, array( 'class' => 'ww-images-thumb' ) )
			. '<div>' . $label . '<span class="ww-images-path">' . esc_html( $file ) . '</span></div></div></td>'
			. '<td class="ww-images-num hide-m">' . esc_html( size_format( $before ) ?: '0 B' ) . '</td>'
			. '<td class="ww-images-num">' . esc_html( size_format( $after ) ?: '0 B' )
			/* translators: %d: percentage. */
			. ' <span class="ww-images-chip">' . esc_html( sprintf( __( '−%d%%', 'webwerckt-base' ), _ww_images_pct_smaller( $before, $after ) ) ) . '</span></td></tr>';
	}
	if ( '' === $rows ) {
		return _ww_images_box( $title, '<p class="ww-images-empty">' . esc_html__( 'Nog geen kleinere versies.', 'webwerckt-base' ) . '</p>', $extra );
	}
	$table = '<table class="ww-images-table"><thead><tr>'
		. '<th scope="col">' . esc_html__( 'Afbeelding', 'webwerckt-base' ) . '</th>'
		. '<th scope="col" class="ww-images-num hide-m">' . esc_html__( 'Origineel', 'webwerckt-base' ) . '</th>'
		. '<th scope="col" class="ww-images-num">' . esc_html__( 'Kleinste versie', 'webwerckt-base' ) . '</th>'
		. '</tr></thead><tbody>' . $rows . '</tbody></table>';
	return _ww_images_box( $title, $table, $extra );
}

/**
 * De regel onder de vakken: wanneer de telling was, dat de cijfers opnieuw geteld worden (na Alles opnieuw maken), of
 * dat de eerste telling nog loopt.
 *
 * @param array<string,mixed>|null $totals De telling, of null.
 */
function _ww_images_overview_stamp( ?array $totals ): string {
	$at = null === $totals ? 0 : (int) ( $totals['counted_at'] ?? 0 );
	if ( null === $totals ) {
		$text = __( 'Wordt geteld: de cijfers verschijnen na de eerste telling, tijdens de volgende runs.', 'webwerckt-base' );
	} elseif ( $at <= 0 ) {
		$text = __( 'Deze cijfers zijn van de vorige telling; ze worden opnieuw geteld tijdens de volgende runs.', 'webwerckt-base' );
	} elseif ( wp_date( 'Y-m-d', $at ) === wp_date( 'Y-m-d' ) ) {
		/* translators: %s: tijd, zoals 14:05. */
		$text = sprintf( __( 'Bijgewerkt om %s.', 'webwerckt-base' ), wp_date( (string) get_option( 'time_format' ), $at ) );
	} else {
		$text = sprintf(
			/* translators: 1: datum, 2: tijd. */
			__( 'Bijgewerkt op %1$s om %2$s.', 'webwerckt-base' ),
			wp_date( (string) get_option( 'date_format' ), $at ),
			wp_date( (string) get_option( 'time_format' ), $at )
		);
	}
	return '<p class="ww-images-desc">' . esc_html( $text ) . ' ' . esc_html__( 'Kleiner geworden telt per bestand het kleinste formaat tegen het origineel. Het thema telt dit tijdens de runs, zodat deze pagina snel blijft.', 'webwerckt-base' ) . '</p>';
}

/**
 * De knop rechts naast de kop van een onderdeel: "Nu een run starten" op Wachtrij.
 *
 * @param string                                             $tab    Onderdeel.
 * @param array{total:int,queue:int,problems:int,failed:int} $counts Aantallen.
 */
function _ww_images_title_action( string $tab, array $counts ): string {
	if ( 'queue' !== $tab ) {
		return '';
	}
	return _ww_images_action_form( 'ww_images_run_now', __( 'Nu een run starten', 'webwerckt-base' ), ! _ww_images_can_run( $counts['queue'] ) );
}

/**
 * Wachtrij: een zin uitleg en de tabel.
 */
function _ww_images_render_queue(): string {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
	require_once __DIR__ . '/class-ww-images-queue-list-table.php';
	$table = new WW_Images_Queue_List_Table();
	$table->prepare_items();
	ob_start();
	echo '<p class="ww-images-lead">' . esc_html(
		sprintf(
			/* translators: %s: aantal seconden. */
			__( 'Elke vijf minuten werkt het thema af wat in %s seconden past, nieuwste eerst. Tot dan krijgen bezoekers het origineel.', 'webwerckt-base' ),
			number_format_i18n( _ww_images_budget() )
		)
	) . '</p>';
	$table->display();
	return (string) ob_get_clean();
}

/**
 * Overgeslagen en mislukt: een zin uitleg, de weergaven en de tabel.
 */
function _ww_images_render_problems(): string {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
	require_once __DIR__ . '/class-ww-images-skip-list-table.php';
	$table = new WW_Images_Skip_List_Table();
	$table->prepare_items();
	ob_start();
	echo '<p class="ww-images-lead">' . esc_html__( 'Voor deze afbeeldingen maakt het thema geen of niet alle versies. Bezoekers krijgen dan het origineel: er gaat niets kapot, het is alleen niet zo klein als het kan.', 'webwerckt-base' ) . '</p>';
	$table->views();
	$table->display();
	echo '<p class="ww-images-desc">' . esc_html__( 'Niet kleiner telt hier niet mee: dan was de versie groter dan het origineel en gebruikt het thema terecht het origineel.', 'webwerckt-base' ) . '</p>';
	return (string) ob_get_clean();
}

/**
 * De regel onder een veld dat een filter op slot zet.
 *
 * @param string $filter Naam van het filter.
 */
function _ww_images_lock_note( string $filter ): string {
	return '<p class="ww-images-locked"><span class="dashicons dashicons-lock" aria-hidden="true"></span><span>' . sprintf(
		/* translators: %s: naam van het filter. */
		esc_html__( 'Vastgezet door het child-thema of een plugin (filter %s)', 'webwerckt-base' ),
		'<code>' . esc_html( $filter ) . '</code>'
	) . '</span></p>';
}

/**
 * Instellingen: het formulier, de vakken Vast in het thema en Server, en Onderhoud.
 *
 * @param array{total:int,queue:int,problems:int,failed:int}|null $counts Aantallen, of null om ze op te halen.
 */
function _ww_images_render_settings( ?array $counts = null ): string {
	$counts = $counts ?? _ww_images_admin_counts();
	return _ww_images_settings_form()
		. '<div class="ww-images-blocks">' . _ww_images_settings_fixed() . _ww_images_settings_server() . '</div>'
		. _ww_images_settings_maintenance( $counts, _ww_images_admin_confirm( 'settings' ) );
}

/**
 * Het formulier met de instellingen, via options.php. Een veld dat een filter op slot zet, is uitgeschakeld en toont de
 * waarde van het filter. Een uitgeschakeld vinkje wordt niet verstuurd; voor een formaat dat de server niet kan, gaat de
 * bewaarde keuze daarom als verborgen veld mee.
 */
function _ww_images_settings_form(): string {
	$settings = _ww_images_settings();
	$server   = _ww_images_server_formats();
	$filters  = _ww_images_locked_filters();
	$locked   = array_map( '_ww_images_locked', $filters );
	$name     = WW_IMAGES_SETTINGS;
	$defaults = _ww_images_default_settings();
	$version  = _ww_images_imagick_version();

	// Moderne formaten.
	$on      = $locked['enabled'] ? _ww_images_enabled() : $settings['enabled'];
	$enabled = '<tr><th scope="row">' . esc_html__( 'Moderne formaten', 'webwerckt-base' ) . '</th><td><fieldset>'
		. '<legend class="screen-reader-text"><span>' . esc_html__( 'Moderne formaten', 'webwerckt-base' ) . '</span></legend>'
		. '<label for="ww-images-enabled"><input type="checkbox" id="ww-images-enabled" name="' . esc_attr( $name ) . '[enabled]" value="1"' . checked( $on, true, false ) . disabled( $locked['enabled'], true, false ) . '> '
		. esc_html__( 'AVIF- en WebP-versies maken en aan bezoekers geven', 'webwerckt-base' ) . '</label>'
		. ( $locked['enabled'] ? _ww_images_lock_note( $filters['enabled'] ) : '' )
		. '<p class="description">' . esc_html__( 'Uit: bezoekers krijgen weer de originele bestanden en de wachtrij stopt. De gemaakte versies blijven op de server staan; verwijderen kan onder Onderhoud.', 'webwerckt-base' ) . '</p>'
		. '</fieldset></td></tr>';

	// Formaten.
	$chosen = $locked['formats'] ? _ww_images_formats() : $settings['formats'];
	$notes  = array(
		'avif' => __( 'kleinst, kost de server meer tijd', 'webwerckt-base' ),
		'webp' => __( 'snel te maken, werkt in elke browser van nu', 'webwerckt-base' ),
	);
	$boxes  = '';
	foreach ( WW_IMAGES_FORMATS as $format ) {
		$can    = in_array( $format, $server, true );
		$boxes .= '<label for="ww-images-' . esc_attr( $format ) . '"><input type="checkbox" id="ww-images-' . esc_attr( $format ) . '" name="' . esc_attr( $name ) . '[formats][]" value="' . esc_attr( $format ) . '"'
			. checked( $can && in_array( $format, $chosen, true ), true, false ) . disabled( $locked['formats'] || ! $can, true, false ) . '> '
			. esc_html( _ww_images_format_name( $format ) ) . ' <small>' . esc_html( $notes[ $format ] ) . '</small></label>';
		if ( ! $can ) {
			if ( ! $locked['formats'] && in_array( $format, $settings['formats'], true ) ) {
				$boxes .= '<input type="hidden" name="' . esc_attr( $name ) . '[formats][]" value="' . esc_attr( $format ) . '">';
			}
			$why    = '' !== $version
				/* translators: 1: versie van ImageMagick, 2: formaat. */
				? sprintf( __( 'Kan niet op deze server: ImageMagick %1$s maakt geen %2$s.', 'webwerckt-base' ), $version, _ww_images_format_name( $format ) )
				: __( 'Kan niet op deze server: Imagick ontbreekt.', 'webwerckt-base' );
			$boxes .= '<p class="ww-images-unavailable">' . esc_html( $why ) . '</p>';
		}
	}
	$formats = '<tr><th scope="row">' . esc_html__( 'Formaten', 'webwerckt-base' ) . '</th><td><fieldset>'
		. '<legend class="screen-reader-text"><span>' . esc_html__( 'Formaten', 'webwerckt-base' ) . '</span></legend>'
		. $boxes
		. ( $locked['formats'] ? _ww_images_lock_note( $filters['formats'] ) : '' )
		. '<p class="description">' . esc_html__( 'Zet je een formaat erbij, dan gaat de hele bibliotheek opnieuw door de wachtrij; wat al klaar is, wordt overgeslagen. Haal je er een weg, dan krijgen bezoekers dat formaat niet meer, maar de bestanden blijven staan.', 'webwerckt-base' ) . '</p>'
		. '</fieldset></td></tr>';

	// Kwaliteit: schuif en getal. Alleen het getal heeft een naam; de schuif zet het getal (en andersom) zonder eigen script.
	$rows = '';
	foreach ( WW_IMAGES_FORMATS as $format ) {
		$value = $locked['quality'] ? _ww_images_quality( $format ) : (int) $settings['quality'][ $format ];
		$off   = disabled( $locked['quality'] || ! in_array( $format, $server, true ), true, false );
		$label = _ww_images_format_name( $format );
		$rows .= '<div class="ww-images-quality">'
			. '<label for="ww-images-quality-' . esc_attr( $format ) . '">' . esc_html( $label ) . '</label>'
			/* translators: %s: formaat, zoals AVIF. */
			. '<input type="range" min="1" max="100" value="' . esc_attr( (string) $value ) . '" aria-label="' . esc_attr( sprintf( __( 'Kwaliteit %s', 'webwerckt-base' ), $label ) ) . '" oninput="this.nextElementSibling.value=this.value"' . $off . '>'
			. '<input type="number" class="small-text" id="ww-images-quality-' . esc_attr( $format ) . '" name="' . esc_attr( $name ) . '[quality][' . esc_attr( $format ) . ']" min="1" max="100" value="' . esc_attr( (string) $value ) . '" oninput="this.previousElementSibling.value=this.value"' . $off . '>'
			/* translators: %d: standaardkwaliteit. */
			. '<span class="ww-images-quality__default">' . esc_html( sprintf( __( 'standaard %d', 'webwerckt-base' ), $defaults['quality'][ $format ] ) ) . '</span>'
			. '</div>';
	}
	$quality = '<tr><th scope="row">' . esc_html__( 'Kwaliteit', 'webwerckt-base' ) . '</th><td>'
		. $rows
		. ( $locked['quality'] ? _ww_images_lock_note( $filters['quality'] ) : '' )
		. '<p class="description">' . esc_html__( 'Hoger is scherper maar groter. AVIF 60 ziet er ongeveer uit als WebP 80. Geldt voor nieuwe versies; bestaande blijven zoals ze zijn tot je ze opnieuw maakt onder Onderhoud.', 'webwerckt-base' ) . '</p>'
		. '</td></tr>';

	// Tijd per run.
	$seconds = $locked['budget'] ? _ww_images_budget() : $settings['budget'];
	$choices = WW_IMAGES_BUDGETS;
	if ( ! in_array( $seconds, $choices, true ) ) {
		$choices[] = $seconds;
		sort( $choices );
	}
	$options = '';
	foreach ( $choices as $choice ) {
		$text     = sprintf(
			/* translators: %d: aantal seconden. */
			_n( '%d seconde', '%d seconden', $choice, 'webwerckt-base' ),
			$choice
		);
		$text     = WW_IMAGES_BUDGET === $choice ? sprintf( /* translators: %s: aantal seconden. */ __( '%s (standaard)', 'webwerckt-base' ), $text ) : $text;
		$options .= '<option value="' . esc_attr( (string) $choice ) . '"' . selected( $seconds, $choice, false ) . '>' . esc_html( $text ) . '</option>';
	}
	$limit  = (int) ini_get( 'max_execution_time' );
	$limit  = $limit > 0
		/* translators: %d: aantal seconden. */
		? sprintf( __( 'op deze server %d seconden', 'webwerckt-base' ), $limit )
		: __( 'op deze server is er geen limiet', 'webwerckt-base' );
	$budget = '<tr><th scope="row"><label for="ww-images-budget">' . esc_html__( 'Tijd per run', 'webwerckt-base' ) . '</label></th><td>'
		. '<select id="ww-images-budget" name="' . esc_attr( $name ) . '[budget]"' . disabled( $locked['budget'], true, false ) . '>' . $options . '</select>'
		. ( $locked['budget'] ? _ww_images_lock_note( $filters['budget'] ) : '' )
		. '<p class="description">' . esc_html(
			sprintf(
				/* translators: %s: de tijdslimiet, zoals "op deze server 60 seconden". */
				__( 'Elke vijf minuten start een run. Langer gaat sneller door de wachtrij, maar moet ruim onder de tijdslimiet van PHP blijven (%s).', 'webwerckt-base' ),
				$limit
			)
		) . '</p>'
		. '</td></tr>';

	// Zoals settings_fields(), maar met een nonce zonder id (meer formulieren op dit scherm) en terug naar Instellingen.
	return '<form method="post" action="' . esc_url( admin_url( 'options.php' ) ) . '" class="ww-images-settings-form">'
		. '<input type="hidden" name="option_page" value="ww_images">'
		. '<input type="hidden" name="action" value="update">'
		. _ww_images_nonce_input( 'ww_images-options' )
		. '<input type="hidden" name="_wp_http_referer" value="' . esc_attr( wp_make_link_relative( _ww_images_admin_url( array( 'tab' => 'settings' ) ) ) ) . '">'
		. '<section class="ww-images-box ww-images-settings"><table class="form-table" role="presentation"><tbody>'
		. $enabled . $formats . $quality . $budget
		. '</tbody></table></section>'
		. '<p class="submit"><button type="submit" class="button button-primary">' . esc_html__( 'Wijzigingen opslaan', 'webwerckt-base' ) . '</button></p>'
		. '</form>';
}

/**
 * Een lijst met feiten (term en waarde, met eventueel een grijze regel eronder).
 *
 * @param array<int,array{0:string,1:string,2?:string}> $facts Term, waarde (geëscapet) en uitleg (geëscapet).
 */
function _ww_images_facts( array $facts ): string {
	$html = '';
	foreach ( $facts as $fact ) {
		$html .= '<dt>' . esc_html( $fact[0] ) . '</dt><dd>' . $fact[1] . ( isset( $fact[2] ) && '' !== $fact[2] ? '<small>' . $fact[2] . '</small>' : '' ) . '</dd>';
	}
	return '<dl class="ww-images-facts">' . $html . '</dl>';
}

/**
 * Het vak Vast in het thema: wat niet in te stellen is.
 */
function _ww_images_settings_fixed(): string {
	return _ww_images_box(
		__( 'Vast in het thema', 'webwerckt-base' ),
		_ww_images_facts(
			array(
				array(
					__( 'Grootste afbeelding', 'webwerckt-base' ),
					/* translators: %s: aantal megapixel. */
					esc_html( sprintf( __( '%s megapixel', 'webwerckt-base' ), number_format_i18n( WW_IMAGES_MAX_PIXELS / 1000000 ) ) ),
					esc_html__( 'Groter wordt overgeslagen, om het geheugen van de server te sparen.', 'webwerckt-base' ),
				),
				array(
					__( 'Pogingen', 'webwerckt-base' ),
					/* translators: %d: aantal pogingen. */
					esc_html( sprintf( __( '%d per bestand', 'webwerckt-base' ), WW_IMAGES_MAX_TRIES ) ),
					esc_html__( 'Daarna overgeslagen; Opnieuw proberen zet de teller terug.', 'webwerckt-base' ),
				),
				array(
					__( 'Geheugen voor ImageMagick', 'webwerckt-base' ),
					/* translators: %s: hoeveelheid geheugen, zoals 256 MB. */
					esc_html( sprintf( __( '%s, 1 thread', 'webwerckt-base' ), size_format( WW_IMAGES_MEMORY ) ) ),
				),
				array( __( 'Interval', 'webwerckt-base' ), esc_html__( 'Elke 5 minuten', 'webwerckt-base' ) ),
				array( __( 'Metadata', 'webwerckt-base' ), esc_html__( 'EXIF en GPS eruit, kleurprofiel blijft', 'webwerckt-base' ) ),
			)
		)
	);
}

/**
 * Het vak Server: ImageMagick, wat hij kan maken, de soort cron en de laatste run.
 */
function _ww_images_settings_server(): string {
	$version = _ww_images_imagick_version();
	$server  = _ww_images_server_formats();
	$cron    = _ww_images_own_cron()
		? array( __( 'Cron', 'webwerckt-base' ), esc_html__( 'Eigen cron op de server', 'webwerckt-base' ) )
		: array(
			__( 'Cron', 'webwerckt-base' ),
			esc_html__( 'WordPress-cron', 'webwerckt-base' ),
			esc_html__( 'Draait alleen bij bezoek.', 'webwerckt-base' ) . ' <a href="' . esc_url( 'https://developer.wordpress.org/plugins/cron/hooking-wp-cron-into-the-system-task-scheduler/' ) . '" target="_blank" rel="noopener">' . esc_html__( 'Zo stel je een echte cron in', 'webwerckt-base' ) . '</a>',
		);
	return _ww_images_box(
		__( 'Server', 'webwerckt-base' ),
		_ww_images_facts(
			array(
				array( __( 'ImageMagick', 'webwerckt-base' ), esc_html( '' !== $version ? $version : __( 'Niet beschikbaar', 'webwerckt-base' ) ) ),
				array( __( 'Kan maken', 'webwerckt-base' ), esc_html( array() !== $server ? implode( ', ', array_map( '_ww_images_format_name', $server ) ) : __( 'Niets', 'webwerckt-base' ) ) ),
				$cron,
				array( __( 'Laatste run', 'webwerckt-base' ), esc_html( _ww_images_last_run_text() ) ),
			)
		) . '<a class="ww-images-more" href="' . esc_url( admin_url( 'site-health.php' ) ) . '">' . esc_html__( 'Alles in Site-gezondheid', 'webwerckt-base' ) . '</a>'
	);
}

/**
 * Het vak Onderhoud: Alles opnieuw maken en Versies verwijderen, elk met een bevestiging in de pagina (?confirm=, zonder
 * script). Zolang er verwijderd wordt, zijn beide knoppen uitgeschakeld. Houdt een filter de optimaliseerder aan, dan
 * kan verwijderen niet (de cron zou alles opnieuw maken): die knop is dan uitgeschakeld, met de regel van het slot.
 *
 * @param array{total:int,queue:int,problems:int,failed:int} $counts  Aantallen.
 * @param string                                             $confirm 'redo', 'wipe' of ''.
 */
function _ww_images_settings_maintenance( array $counts, string $confirm ): string {
	$wiping = _ww_images_wiping();
	$cancel = '<a href="' . esc_url( _ww_images_admin_url( array( 'tab' => 'settings' ) ) ) . '">' . esc_html__( 'Annuleren', 'webwerckt-base' ) . '</a>';
	$locked = _ww_images_wipe_locked();
	$button = static function ( string $label, string $which, string $class, bool $off = false ) use ( $wiping ): string {
		if ( $wiping || $off ) {
			return '<button type="button" class="' . esc_attr( $class ) . '" disabled>' . esc_html( $label ) . '</button>';
		}
		$url = _ww_images_admin_url(
			array(
				'tab'     => 'settings',
				'confirm' => $which,
			)
		);
		return '<a class="' . esc_attr( $class ) . '" href="' . esc_url( $url ) . '#ww-images-maintenance">' . esc_html( $label ) . '</a>';
	};

	$redo = '<div class="ww-images-maint__row"><div><strong>' . esc_html__( 'Alles opnieuw maken', 'webwerckt-base' ) . '</strong>'
		. '<span>' . esc_html__( 'Maakt elke versie opnieuw met de huidige kwaliteit. Nodig na het wijzigen van de kwaliteit. Bezoekers houden de huidige versies tot de nieuwe klaar zijn.', 'webwerckt-base' ) . '</span></div>'
		. $button( __( 'Alles opnieuw maken', 'webwerckt-base' ), 'redo', 'button' ) . '</div>';
	if ( 'redo' === $confirm && ! $wiping ) {
		$redo .= '<div class="ww-images-confirm" role="group"><p>' . esc_html(
			sprintf(
				/* translators: %s: aantal afbeeldingen. */
				_n( 'De %s afbeelding gaat terug in de wachtrij. Tot die klaar is, krijgen bezoekers de huidige versies.', 'Alle %s afbeeldingen gaan terug in de wachtrij. Tot ze klaar zijn, krijgen bezoekers de huidige versies.', $counts['total'], 'webwerckt-base' ),
				number_format_i18n( $counts['total'] )
			)
		) . '</p>' . _ww_images_action_form( 'ww_images_redo', __( 'Ja, opnieuw maken', 'webwerckt-base' ), false, 'button button-primary' ) . $cancel . '</div>';
	}

	$wipe = '<div class="ww-images-maint__row"><div><strong>' . esc_html__( 'Versies verwijderen', 'webwerckt-base' ) . '</strong>'
		. '<span>' . esc_html__( 'Verwijdert alle AVIF- en WebP-bestanden. De originelen blijven staan. Moderne formaten gaat daarbij uit, anders maakt het thema ze opnieuw.', 'webwerckt-base' ) . '</span>'
		. ( $locked ? _ww_images_lock_note( 'ww_image_variants' ) : '' ) . '</div>'
		. $button( __( 'Versies verwijderen', 'webwerckt-base' ), 'wipe', 'button ww-images-delete', $locked ) . '</div>';
	if ( 'wipe' === $confirm && ! $wiping && ! $locked ) {
		$totals = _ww_images_totals();
		$what   = null !== $totals
			? sprintf(
				/* translators: 1: aantal bestanden, zoals "1.234 bestanden", 2: grootte, zoals 296 MB. */
				__( '%1$s (%2$s)', 'webwerckt-base' ),
				sprintf(
					/* translators: %s: aantal bestanden. */
					_n( '%s bestand', '%s bestanden', (int) ( $totals['files'] ?? 0 ), 'webwerckt-base' ),
					number_format_i18n( (int) ( $totals['files'] ?? 0 ) )
				),
				size_format( (int) ( $totals['files_bytes'] ?? 0 ) ) ?: '0 B'
			)
			: __( 'alle AVIF- en WebP-bestanden (het aantal wordt nog geteld)', 'webwerckt-base' );
		$wipe  .= '<div class="ww-images-confirm" role="group"><p>' . esc_html(
			sprintf(
				/* translators: %s: wat er verwijderd wordt, zoals "1.234 bestanden (296 MB)". */
				__( 'Dit verwijdert %s van de server en kan niet ongedaan worden gemaakt. Opnieuw maken kan wel, maar kost uren.', 'webwerckt-base' ),
				$what
			)
		) . '</p>' . _ww_images_action_form( 'ww_images_wipe', __( 'Ja, verwijderen', 'webwerckt-base' ), false, 'button ww-images-delete' ) . $cancel . '</div>';
	}

	return '<section class="ww-images-box ww-images-maint" id="ww-images-maintenance"><h2><span>' . esc_html__( 'Onderhoud', 'webwerckt-base' ) . '</span></h2>' . $redo . $wipe . '</section>';
}
