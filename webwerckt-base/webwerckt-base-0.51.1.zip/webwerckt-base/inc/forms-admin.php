<?php
/**
 * Formulieren in het beheer (beslissing 0032): het menu Inzendingen onder Formulieren, de lijst met inzendingen, het
 * detail, de bulkacties en de CSV-export.
 *
 * Elke actie komt binnen op admin_init met ww_entries_action, een nonce (ww_form_entries_{actie}) en het recht
 * edit_others_pages, en stuurt daarna terug naar de lijst met een melding. Wat de bezoeker invulde is nooit
 * vertrouwd: het detail en de lijst escapen elke waarde, en de CSV zet een apostrof voor cellen die een
 * spreadsheet als formule zou lezen. Labels en waarden komen uit de inzending zelf (het moment van inzenden), niet uit
 * het formulier zoals het nu is.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const WW_FORM_ENTRIES_SCREEN   = 'ww-form-entries';
const WW_FORM_ENTRIES_PER_PAGE = 50;
const WW_FORM_ENTRIES_ACTIONS  = array( 'delete', 'bulk-delete', 'mark-read', 'mark-unread', 'not-spam', 'export', 'pdf' );

/**
 * Registreert Inzendingen onder Formulieren. Het zijpaneel haalt het weer uit het submenu en zet het bolletje met
 * nieuwe inzendingen achter Formulieren (inc/forms-panel.php); de pagina blijft bereikbaar.
 */
function _ww_forms_admin_menu(): void {
	$title = __( 'Inzendingen', 'webwerckt-base' );
	add_submenu_page(
		'edit.php?post_type=' . WW_FORM_POST_TYPE,
		$title,
		$title,
		'edit_others_pages',
		WW_FORM_ENTRIES_SCREEN,
		'_ww_forms_entries_render'
	);
}
add_action( 'admin_menu', '_ww_forms_admin_menu' );

/**
 * URL van het scherm, eventueel met extra queryvariabelen.
 *
 * @param array<string,string> $args Queryvariabelen.
 */
function _ww_forms_entries_url( array $args = array() ): string {
	$args = array( 'post_type' => WW_FORM_POST_TYPE, 'page' => WW_FORM_ENTRIES_SCREEN ) + $args;
	return add_query_arg( array_map( 'rawurlencode', $args ), admin_url( 'edit.php' ) );
}

/**
 * Een link naar een actie met een nonce.
 *
 * @param string               $action Actie uit WW_FORM_ENTRIES_ACTIONS.
 * @param array<string,string> $args   Extra queryvariabelen.
 */
function _ww_forms_entries_action_url( string $action, array $args = array() ): string {
	return wp_nonce_url( _ww_forms_entries_url( array( 'ww_entries_action' => $action ) + $args ), 'ww_form_entries_' . $action );
}

/**
 * Een waarde uit het verzoek als tekst, zonder slashes.
 *
 * @param array<mixed> $source $_POST of $_GET.
 * @param string       $key    Veldnaam.
 */
function _ww_forms_entries_param( array $source, string $key ): string {
	return trim( _ww_data_to_string( wp_unslash( $source[ $key ] ?? '' ) ) );
}

/**
 * Maakt van een celwaarde iets dat een spreadsheet niet als formule leest: begint hij met =, +, -, @, tab of CR,
 * dan komt er een apostrof voor.
 *
 * @param string $value Celwaarde.
 */
function _ww_form_csv_cell( string $value ): string {
	return 1 === preg_match( '/^[=+\-@\t\r]/', $value ) ? "'" . $value : $value;
}

/**
 * De CSV van de inzendingen van één formulier: UTF-8 met BOM, scheidingsteken ;, de kolommen Datum, de huidige velden
 * van het formulier (label), Pagina en Status. Een cel per veld is de tekst zoals die bij het inzenden bewaard werd;
 * heeft een inzending dat veld niet, dan is de cel leeg. Nieuwste eerst, net als de lijst. Met Meertalig actief
 * (beslissing 0043) de inzendingen van de vertaalgroep die de gebruiker mag bewerken, met de kolom Taal na Datum.
 *
 * @param int $form_id Formulier.
 */
function _ww_form_entries_csv( int $form_id ): string {
	$config    = _ww_form_config( $form_id );
	$fields    = is_array( $config ) ? (array) $config['fields'] : array();
	$languages = _ww_languages_active();
	$filter    = _ww_form_entries_form_filter( $form_id );

	$header = array( __( 'Datum', 'webwerckt-base' ) );
	if ( $languages ) {
		$header[] = __( 'Taal', 'webwerckt-base' );
	}
	$keys   = array();
	foreach ( $fields as $field ) {
		$header[] = _ww_form_mail_plain( _ww_data_to_string( $field['label'] ?? '' ) );
		$keys[]   = _ww_data_to_string( $field['key'] ?? '' );
	}
	$header[] = __( 'Pagina', 'webwerckt-base' );
	$header[] = __( 'Status', 'webwerckt-base' );

	$handle = fopen( 'php://temp', 'r+' );
	if ( false === $handle ) {
		return '';
	}
	fputcsv( $handle, array_map( '_ww_form_csv_cell', $header ), ';', '"', '' );

	$page = 1;
	do {
		$result = _ww_form_entries_query(
			$filter + array(
				'page'     => $page,
				'per_page' => 500,
			)
		);
		foreach ( $result['items'] as $entry ) {
			$row = array( wp_date( 'Y-m-d H:i', strtotime( $entry->created . ' UTC' ) ?: 0 ) );
			if ( $languages ) {
				$row[] = _ww_post_language( (int) $entry->form_id );
			}
			foreach ( $keys as $key ) {
				$stored = $entry->fields[ $key ] ?? '';
				// Een getal zonder eenheid en met een punt, zodat een spreadsheet ermee kan rekenen.
				$row[] = is_array( $stored ) && 'number' === ( $stored['type'] ?? '' ) ? _ww_data_to_string( $stored['value'] ?? '' ) : _ww_form_entry_field_text( $stored );
			}
			$row[] = (string) $entry->page_url;
			$row[] = 'new' === $entry->status ? __( 'Nieuw', 'webwerckt-base' ) : __( 'Gelezen', 'webwerckt-base' );
			fputcsv( $handle, array_map( '_ww_form_csv_cell', $row ), ';', '"', '' );
		}
		++$page;
	} while ( count( $result['items'] ) === 500 );

	rewind( $handle );
	$csv = (string) stream_get_contents( $handle );
	fclose( $handle );
	return "\xEF\xBB\xBF" . $csv;
}

/**
 * Stuurt de export: headers (als die nog kunnen) en de CSV.
 *
 * @param int $form_id Formulier.
 */
function _ww_form_entries_export_send( int $form_id ): void {
	$post = get_post( $form_id );
	$slug = sanitize_title( $post instanceof WP_Post && '' !== $post->post_name ? $post->post_name : (string) get_the_title( $form_id ) );
	if ( ! headers_sent() ) {
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=inzendingen-' . ( '' !== $slug ? $slug : (string) $form_id ) . '-' . wp_date( 'Y-m-d' ) . '.csv' );
	}
	echo _ww_form_entries_csv( $form_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSV, geen HTML.
}

/**
 * De oorspronkelijke bestandsnamen van een bestandsveld, gescheiden door `, ` (uit `value`; `display` heeft de grootte
 * erbij). Leeg als het veld geen bestanden heeft.
 *
 * @param array<mixed> $field Opgeslagen veld van de inzending.
 */
function _ww_form_entry_file_names( array $field ): string {
	return _ww_form_file_names( $field['value'] ?? null );
}

/**
 * De tekst van een opgeslagen veld voor lijst en CSV: bij een bestandsveld de namen, anders de bewaarde tekst.
 *
 * @param mixed $field Opgeslagen veld van de inzending.
 */
function _ww_form_entry_field_text( $field ): string {
	if ( ! is_array( $field ) ) {
		return '';
	}
	return 'file' === ( $field['type'] ?? '' ) ? _ww_form_entry_file_names( $field ) : _ww_data_to_string( $field['display'] ?? '' );
}

/**
 * De uitkomst van de reCAPTCHA-controle als tekst; leeg als er geen controle was (`off`).
 *
 * @param string $result pass, none, spam of off.
 */
function _ww_form_recaptcha_label( string $result ): string {
	switch ( $result ) {
		case 'pass':
			return __( 'Gecontroleerd', 'webwerckt-base' );
		case 'none':
			return __( 'Niet gecontroleerd', 'webwerckt-base' );
		case 'spam':
			return __( 'Spam', 'webwerckt-base' );
		default:
			return '';
	}
}

/**
 * De samenvatting voor de lijst: de tekst van de eerste twee velden, samen hoogstens 80 tekens.
 *
 * @param array<string,mixed> $fields Opgeslagen velden van de inzending.
 */
function _ww_form_entries_summary( array $fields ): string {
	$parts = array();
	foreach ( array_slice( $fields, 0, 2 ) as $field ) {
		$text = trim( (string) preg_replace( '/\s+/u', ' ', _ww_form_entry_field_text( $field ) ) );
		if ( '' !== $text ) {
			$parts[] = $text;
		}
	}
	$summary = implode( ', ', $parts );
	return mb_strlen( $summary ) > 80 ? mb_substr( $summary, 0, 79 ) . '…' : $summary;
}

/**
 * Elk formulier voor de keuzelijst: ID => titel. Elke taalversie apart (met Meertalig met de taalcode erachter), elke
 * status behalve auto-draft.
 *
 * @return array<int,string>
 */
function _ww_forms_entries_form_options(): array {
	$statuses = array_values( array_diff( get_post_stati(), array( 'auto-draft' ) ) );
	$posts    = get_posts(
		array(
			'post_type'              => WW_FORM_POST_TYPE,
			'post_status'            => $statuses,
			'numberposts'            => -1,
			'orderby'                => 'title',
			'order'                  => 'ASC',
			'suppress_filters'       => true,
			'update_post_meta_cache' => false,
		)
	);
	$options   = array();
	$languages = _ww_languages_active();
	foreach ( $posts as $post ) {
		$title = '' !== $post->post_title ? $post->post_title : __( '(zonder titel)', 'webwerckt-base' );
		if ( $languages ) {
			// Een vertaling heeft vaak dezelfde titel: de taalcode erachter (0043).
			$title .= ' (' . _ww_post_language( (int) $post->ID ) . ')';
		}
		if ( 'publish' !== $post->post_status ) {
			$object = get_post_status_object( $post->post_status );
			$title .= ' (' . ( $object ? $object->label : $post->post_status ) . ')';
		}
		$options[ (int) $post->ID ] = $title;
	}
	return $options;
}

/**
 * Meldt iets op het scherm en stuurt terug naar de lijst (de melding reist mee in een transient, zoals bij options.php),
 * met de filters van het verzoek (_ww_forms_entries_view_args()): de links en het formulier van de tabel geven ze mee
 * in de query.
 *
 * @param string $message Tekst.
 * @param string $type    success, error, warning of info.
 */
function _ww_forms_entries_done( string $message, string $type = 'success' ): void {
	add_settings_error( 'ww_form_entries', 'ww_form_entries_' . $type, esc_html( $message ), $type );
	set_transient( 'settings_errors', get_settings_errors(), 30 );

	if ( wp_safe_redirect( _ww_forms_entries_url( array( 'settings-updated' => 'true' ) + _ww_forms_entries_view_args() ) ) ) {
		exit;
	}
}

/**
 * De inzendingen die een actie raakt: ids[] uit het formulier van de tabel, of id uit de link.
 *
 * @return int[]
 */
function _ww_forms_entries_ids(): array {
	// phpcs:disable WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput -- de nonce is gecontroleerd in _ww_forms_entries_handle(); alleen getallen worden gebruikt.
	$raw = isset( $_POST['ids'] ) && is_array( $_POST['ids'] ) ? wp_unslash( $_POST['ids'] ) : array();
	$ids = array_map( static fn( $value ): int => absint( _ww_data_to_string( $value ) ), $raw );
	$one = absint( _ww_forms_entries_param( $_GET, 'id' ) );
	// phpcs:enable
	if ( $one > 0 ) {
		$ids[] = $one;
	}
	return array_values( array_unique( array_filter( $ids ) ) );
}

/**
 * Voert de actie uit het verzoek uit (admin_init). Zie WW_FORM_ENTRIES_ACTIONS.
 */
function _ww_forms_entries_handle(): void {
	// phpcs:disable WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput -- de nonce wordt hieronder per actie gecontroleerd.
	$action = isset( $_REQUEST['ww_entries_action'] ) ? sanitize_key( _ww_data_to_string( wp_unslash( $_REQUEST['ww_entries_action'] ) ) ) : '';
	if ( '' === $action && ! wp_doing_ajax() && isset( $_REQUEST['page'] ) && WW_FORM_ENTRIES_SCREEN === _ww_data_to_string( wp_unslash( $_REQUEST['page'] ) ) ) {
		// Het keuzelijstje boven en onder de tabel stuurt zijn keuze als action en action2, alleen op dit scherm.
		foreach ( array( 'action', 'action2' ) as $key ) {
			$chosen = isset( $_REQUEST[ $key ] ) ? sanitize_key( _ww_data_to_string( wp_unslash( $_REQUEST[ $key ] ) ) ) : '';
			if ( in_array( $chosen, array( 'bulk-delete', 'mark-read', 'mark-unread', 'not-spam' ), true ) ) {
				$action = $chosen;
				break;
			}
		}
	}
	// phpcs:enable
	if ( ! in_array( $action, WW_FORM_ENTRIES_ACTIONS, true ) ) {
		return;
	}

	if ( ! current_user_can( 'edit_others_pages' ) ) {
		wp_die( esc_html__( 'Je hebt geen rechten om inzendingen te beheren.', 'webwerckt-base' ), 403 );
	}
	// De tabel heeft vier bulkacties en één keuzelijstje: elke actie heeft daarom een eigen nonce-veld.
	$nonce_arg = isset( $_REQUEST[ '_ww_nonce_' . $action ] ) ? '_ww_nonce_' . $action : '_wpnonce'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen de naam van het veld; de nonce zelf wordt hieronder gecontroleerd.
	check_admin_referer( 'ww_form_entries_' . $action, $nonce_arg );

	if ( 'export' === $action ) {
		$form_id = absint( _ww_forms_entries_param( $_GET, 'form_id' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- nonce gecontroleerd.
		if ( $form_id <= 0 || WW_FORM_POST_TYPE !== get_post_type( $form_id ) ) {
			_ww_forms_entries_done( __( 'Kies eerst een formulier om te exporteren.', 'webwerckt-base' ), 'error' );
			return;
		}
		_ww_form_entries_export_send( $form_id );
		exit;
	}

	if ( 'pdf' === $action ) {
		$entry = _ww_form_entry_get( absint( _ww_forms_entries_param( $_GET, 'id' ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- nonce gecontroleerd.
		if ( null === $entry ) {
			_ww_forms_entries_done( __( 'Deze inzending bestaat niet (meer).', 'webwerckt-base' ), 'error' );
			return;
		}
		_ww_form_pdf_entry_send( $entry );
		exit;
	}

	$ids = _ww_forms_entries_ids();
	if ( array() === $ids ) {
		_ww_forms_entries_done( __( 'Er is geen inzending gekozen.', 'webwerckt-base' ), 'warning' );
		return;
	}

	switch ( $action ) {
		case 'delete':
		case 'bulk-delete':
			$count = _ww_form_entries_delete( $ids );
			_ww_forms_entries_done(
				sprintf(
					/* translators: %d: aantal inzendingen. */
					_n( '%d inzending verwijderd.', '%d inzendingen verwijderd.', $count, 'webwerckt-base' ),
					$count
				)
			);
			return;

		case 'mark-read':
			$count = _ww_form_entries_set_status( $ids, 'read' );
			_ww_forms_entries_done(
				sprintf(
					/* translators: %d: aantal inzendingen. */
					_n( '%d inzending gemarkeerd als gelezen.', '%d inzendingen gemarkeerd als gelezen.', $count, 'webwerckt-base' ),
					$count
				)
			);
			return;

		case 'not-spam':
			// Alleen de status; de kolom recaptcha blijft spam, en er gaan geen mails uit.
			$count = _ww_form_entries_set_status( $ids, 'new' );
			_ww_forms_entries_done(
				sprintf(
					/* translators: %d: aantal inzendingen. */
					_n( '%d inzending teruggezet als geen spam.', '%d inzendingen teruggezet als geen spam.', $count, 'webwerckt-base' ),
					$count
				)
			);
			return;

		case 'mark-unread':
			$count = _ww_form_entries_set_status( $ids, 'new' );
			_ww_forms_entries_done(
				sprintf(
					/* translators: %d: aantal inzendingen. */
					_n( '%d inzending gemarkeerd als ongelezen.', '%d inzendingen gemarkeerd als ongelezen.', $count, 'webwerckt-base' ),
					$count
				)
			);
			return;
	}
}
add_action( 'admin_init', '_ww_forms_entries_handle' );

/**
 * Datum en tijd in de tijdzone van de site, uit een UTC-tijd van de database.
 *
 * @param string $utc Tijd als Y-m-d H:i:s in UTC.
 */
function _ww_forms_entries_date( string $utc ): string {
	$time = strtotime( $utc . ' UTC' );
	return false === $time ? '' : wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $time );
}

/**
 * De mailstatus als leesbare regels ("Melding: Verstuurd"), of een leeg lijstje.
 *
 * @param string $status Bewaarde status, zoals notify:sent,confirm:failed.
 * @return string[]
 */
function _ww_forms_entries_mail_lines( string $status ): array {
	$mails  = array(
		'notify'  => __( 'Melding', 'webwerckt-base' ),
		'confirm' => __( 'Bevestiging', 'webwerckt-base' ),
	);
	$states = array(
		'sent'   => __( 'Verstuurd', 'webwerckt-base' ),
		'failed' => __( 'Mislukt', 'webwerckt-base' ),
		'off'    => __( 'Uit', 'webwerckt-base' ),
	);
	$lines  = array();
	foreach ( explode( ',', $status ) as $part ) {
		$pair = explode( ':', $part, 2 );
		if ( 2 === count( $pair ) ) {
			$lines[] = ( $mails[ $pair[0] ] ?? $pair[0] ) . ': ' . ( $states[ $pair[1] ] ?? $pair[1] );
		}
	}
	return $lines;
}

/**
 * Toont het scherm: de lijst, of het detail bij ?entry=<id> (dat de inzending als gelezen markeert).
 */
function _ww_forms_entries_render(): void {
	if ( ! current_user_can( 'edit_others_pages' ) ) {
		wp_die( esc_html__( 'Je hebt geen rechten om inzendingen te bekijken.', 'webwerckt-base' ), 403 );
	}
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
	require_once __DIR__ . '/class-ww-form-entries-list-table.php';

	$entry_id = isset( $_GET['entry'] ) ? absint( _ww_data_to_string( wp_unslash( $_GET['entry'] ) ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen een inzending bekijken.

	echo '<div class="wrap">';
	echo _ww_forms_render_picker( 'entries' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_forms_render_picker() escapet.
	echo '<h1 class="wp-heading-inline">' . esc_html__( 'Inzendingen', 'webwerckt-base' ) . '</h1>';
	echo '<hr class="wp-header-end">';
	settings_errors( 'ww_form_entries' );

	if ( $entry_id > 0 ) {
		_ww_forms_entries_render_detail( $entry_id );
	} else {
		_ww_forms_entries_render_list();
	}
	echo '</div>';
}

/**
 * De lijst: filters en zoekveld (GET), de tabel met bulkacties (POST).
 */
function _ww_forms_entries_render_list(): void {
	$table = new WW_Form_Entries_List_Table();
	$table->prepare_items();
	$form_id = $table->get_form_id();
	$status  = $table->get_status_filter();

	$table->views();
	echo '<form method="get">';
	echo '<input type="hidden" name="post_type" value="' . esc_attr( WW_FORM_POST_TYPE ) . '">';
	echo '<input type="hidden" name="page" value="' . esc_attr( WW_FORM_ENTRIES_SCREEN ) . '">';
	echo '<select name="form_id" aria-label="' . esc_attr__( 'Formulier', 'webwerckt-base' ) . '">';
	echo '<option value="">' . esc_html__( 'Alle formulieren', 'webwerckt-base' ) . '</option>';
	foreach ( _ww_forms_entries_form_options() as $id => $title ) {
		echo '<option value="' . esc_attr( (string) $id ) . '"' . selected( $form_id, $id, false ) . '>' . esc_html( $title ) . '</option>';
	}
	echo '</select> ';
	if ( '' !== $status ) {
		echo '<input type="hidden" name="status" value="' . esc_attr( $status ) . '">';
	}
	submit_button( __( 'Filter', 'webwerckt-base' ), 'secondary', '', false );
	$table->search_box( __( 'Zoek in inzendingen', 'webwerckt-base' ), 'ww-form-entries' );
	echo '</form>';

	$keep = array();
	foreach ( array(
		'form_id' => $form_id > 0 ? (string) $form_id : '',
		'status'  => $status,
		's'       => $table->get_search_term(),
	) as $key => $value ) {
		if ( '' !== $value ) {
			$keep[ $key ] = $value;
		}
	}
	echo '<form method="post" action="' . esc_url( _ww_forms_entries_url( $keep ) ) . '">';
	$table->display();
	// Na de tabel, zodat de nonce van de tabel zelf (bulk-…, veldnaam _wpnonce) niet in de weg zit: elke actie heeft een eigen veld.
	foreach ( array( 'bulk-delete', 'mark-read', 'mark-unread', 'not-spam' ) as $action ) {
		wp_nonce_field( 'ww_form_entries_' . $action, '_ww_nonce_' . $action, false );
	}
	echo '</form>';
}

/**
 * De cel van een bestandsveld in het detail: per bestand een downloadlink met de oorspronkelijke naam, de grootte en het
 * type. Bij een spaminzending staat er dat de bestanden niet bewaard worden; zonder bestanden een streepje.
 *
 * @param object       $entry Inzending.
 * @param string       $key   Veldsleutel.
 * @param array<mixed> $field Opgeslagen veld.
 */
function _ww_forms_entries_file_cell( object $entry, string $key, array $field ): string {
	$lines = array();
	foreach ( is_array( $field['value'] ?? null ) ? array_values( $field['value'] ) : array() as $n => $file ) {
		if ( ! is_array( $file ) ) {
			continue;
		}
		$size    = (string) size_format( absint( _ww_data_to_string( $file['size'] ?? 0 ) ) );
		$lines[] = '<a href="' . esc_url( _ww_form_file_url( (int) $entry->id, $key, $n ) ) . '">' . esc_html( _ww_data_to_string( $file['name'] ?? '' ) ) . '</a> (' . esc_html( $size ) . ', ' . esc_html( _ww_data_to_string( $file['mime'] ?? '' ) ) . ')';
	}
	$html = implode( '<br>', $lines );
	if ( 'spam' === $entry->recaptcha ) {
		$note = esc_html__( 'Bestanden van een spaminzending worden niet bewaard.', 'webwerckt-base' );
		$html = '' === $html ? $note : $html . '<br>' . $note;
	}
	return '' === $html ? '&mdash;' : $html;
}

/**
 * De filters van het verzoek (form_id, status, s) die een link naar een inzending meeneemt.
 *
 * @return array<string,string>
 */
function _ww_forms_entries_view_args(): array {
	$keep = array();
	foreach ( array(
		'form_id' => (string) absint( _ww_forms_entries_param( $_GET, 'form_id' ) ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen filteren.
		'status'  => sanitize_key( _ww_forms_entries_param( $_GET, 'status' ) ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen filteren.
		's'       => _ww_form_clean_input( _ww_forms_entries_param( $_GET, 's' ) ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen zoeken.
	) as $key => $value ) {
		if ( '' === $value || '0' === $value ) {
			continue;
		}
		if ( 'status' === $key && ! in_array( $value, array( 'new', 'read', 'spam' ), true ) ) {
			continue;
		}
		$keep[ $key ] = $value;
	}
	return $keep;
}

/**
 * De links Vorige en Volgende boven het detail: de inzending ervoor (nieuwer) en erna (ouder) binnen dezelfde filters.
 * Aan het eind van de lijst staat een uitgeschakelde aanduiding met aria-disabled.
 *
 * @param int                  $id   Inzending.
 * @param array<string,string> $keep Filters uit _ww_forms_entries_view_args().
 */
function _ww_forms_entries_render_neighbours( int $id, array $keep ): string {
	$filter = _ww_form_entries_form_filter( (int) ( $keep['form_id'] ?? 0 ) ) + array(
		'status' => $keep['status'] ?? '',
		'search' => $keep['s'] ?? '',
	);
	$near  = _ww_form_entry_neighbours( $id, $filter );
	$parts = array();
	foreach ( array(
		'prev' => '&lsaquo; ' . esc_html__( 'Vorige', 'webwerckt-base' ),
		'next' => esc_html__( 'Volgende', 'webwerckt-base' ) . ' &rsaquo;',
	) as $dir => $label ) {
		$parts[] = $near[ $dir ] > 0
			? '<a class="button" href="' . esc_url( _ww_forms_entries_url( array( 'entry' => (string) $near[ $dir ] ) + $keep ) ) . '">' . $label . '</a>'
			: '<span class="button disabled" aria-disabled="true">' . $label . '</span>';
	}
	return '<p class="ww-entry-neighbours">' . implode( ' ', $parts ) . '</p>';
}

/**
 * Het detail van één inzending: alle opgeslagen velden met label en tekst, de pagina, de mailstatus en de knoppen.
 * Openen markeert de inzending als gelezen.
 *
 * @param int $id Inzending.
 */
function _ww_forms_entries_render_detail( int $id ): void {
	$back  = '<p><a href="' . esc_url( _ww_forms_entries_url( _ww_forms_entries_view_args() ) ) . '">&larr; ' . esc_html__( 'Terug naar de inzendingen', 'webwerckt-base' ) . '</a></p>';
	$entry = _ww_form_entry_get( $id );
	if ( null === $entry ) {
		echo $back; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hierboven geescaped.
		echo '<div class="notice notice-error inline"><p>' . esc_html__( 'Deze inzending bestaat niet (meer).', 'webwerckt-base' ) . '</p></div>';
		return;
	}
	if ( 'new' === $entry->status ) {
		_ww_form_entries_set_status( array( $id ), 'read' );
	}

	$form_id = (int) $entry->form_id;
	$title   = (string) get_the_title( $form_id );
	$keep    = _ww_forms_entries_view_args();
	$confirm = 'delete' === _ww_forms_entries_param( $_GET, 'confirm' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen de bevestiging tonen; verwijderen vraagt zijn eigen nonce.
	$reply   = '';
	foreach ( $entry->fields as $field ) {
		$text = is_array( $field ) ? _ww_data_to_string( $field['display'] ?? '' ) : '';
		if ( is_array( $field ) && 'line' === ( $field['type'] ?? '' ) && is_email( $text ) ) {
			$reply = $text;
			break;
		}
	}

	echo $back; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hierboven geescaped.
	echo _ww_forms_entries_render_neighbours( $id, $keep ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- geescaped in _ww_forms_entries_render_neighbours().
	if ( $confirm ) {
		echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'Deze inzending definitief verwijderen? Dit kan niet ongedaan worden.', 'webwerckt-base' ) . '</p><p>';
		echo '<a class="button button-primary" href="' . esc_url( _ww_forms_entries_action_url( 'delete', array( 'id' => (string) $id ) + $keep ) ) . '">' . esc_html__( 'Ja, verwijderen', 'webwerckt-base' ) . '</a> ';
		echo '<a class="button" href="' . esc_url( _ww_forms_entries_url( array( 'entry' => (string) $id ) + $keep ) ) . '">' . esc_html__( 'Annuleren', 'webwerckt-base' ) . '</a>';
		echo '</p></div>';
	}
	echo '<table class="form-table" role="presentation"><tbody>';
	echo '<tr><th scope="row">' . esc_html__( 'Datum', 'webwerckt-base' ) . '</th><td>' . esc_html( _ww_forms_entries_date( (string) $entry->created ) ) . '</td></tr>';
	echo '<tr><th scope="row">' . esc_html__( 'Formulier', 'webwerckt-base' ) . '</th><td>' . esc_html( '' !== $title ? $title : '—' ) . '</td></tr>';
	foreach ( $entry->fields as $key => $field ) {
		if ( ! is_array( $field ) ) {
			continue;
		}
		$label = _ww_data_to_string( $field['label'] ?? '' );
		if ( 'file' === ( $field['type'] ?? '' ) ) {
			echo '<tr><th scope="row">' . esc_html( $label ) . '</th><td>' . _ww_forms_entries_file_cell( $entry, (string) $key, $field ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- geescaped in _ww_forms_entries_file_cell().
			continue;
		}
		$text = _ww_data_to_string( $field['display'] ?? '' );
		echo '<tr><th scope="row">' . esc_html( $label ) . '</th><td>' . ( '' === $text ? '&mdash;' : nl2br( esc_html( $text ) ) ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- esc_html, daarna alleen <br>.
	}
	$page = (string) $entry->page_url;
	echo '<tr><th scope="row">' . esc_html__( 'Pagina', 'webwerckt-base' ) . '</th><td>' . ( '' === $page ? '&mdash;' : '<a href="' . esc_url( $page ) . '">' . esc_html( $page ) . '</a>' ) . '</td></tr>';
	$check = _ww_form_recaptcha_label( (string) $entry->recaptcha );
	echo '<tr><th scope="row">' . esc_html__( 'Controle', 'webwerckt-base' ) . '</th><td>' . ( '' === $check ? '&mdash;' : esc_html( $check ) ) . '</td></tr>';
	$mail = _ww_forms_entries_mail_lines( (string) $entry->mail_status );
	echo '<tr><th scope="row">' . esc_html__( 'Mail', 'webwerckt-base' ) . '</th><td>' . ( array() === $mail ? '&mdash;' : esc_html( implode( ', ', $mail ) ) ) . '</td></tr>';
	echo '</tbody></table>';

	echo '<p class="submit">';
	if ( '' !== $reply ) {
		echo '<a class="button button-primary" href="' . esc_url( 'mailto:' . $reply, array( 'mailto' ) ) . '">' . esc_html__( 'Beantwoorden', 'webwerckt-base' ) . '</a> ';
	}
	if ( _ww_form_pdf_enabled( $form_id ) ) {
		echo '<a class="button" href="' . esc_url( _ww_forms_entries_action_url( 'pdf', array( 'id' => (string) $id ) ) ) . '">' . esc_html__( 'PDF downloaden', 'webwerckt-base' ) . '</a> ';
	}
	echo '<a class="button" href="' . esc_url( _ww_forms_entries_action_url( 'mark-unread', array( 'id' => (string) $id ) + $keep ) ) . '">' . esc_html__( 'Markeren als ongelezen', 'webwerckt-base' ) . '</a> ';
	echo '<a class="button button-link-delete" href="' . esc_url( _ww_forms_entries_url( array( 'entry' => (string) $id, 'confirm' => 'delete' ) + $keep ) ) . '">' . esc_html__( 'Verwijderen', 'webwerckt-base' ) . '</a>';
	echo '</p>';
}

/**
 * Of verwijderen van een formulier definitief is: zonder prullenbak (EMPTY_TRASH_DAYS 0) slaat WordPress die over, en
 * gaan de inzendingen en bestanden mee (_ww_form_entries_on_delete_post()). Het interne filter is er voor de tests.
 */
function _ww_forms_trash_is_permanent(): bool {
	return (bool) apply_filters( '_ww_forms_trash_is_permanent', ! EMPTY_TRASH_DAYS );
}

/**
 * De vraag voor het definitief verwijderen van een formulier met inzendingen: hoeveel er mee verdwijnen. Leeg zonder
 * inzendingen. Gedeeld door de rij-actie hieronder en het paneel op het bewerkscherm.
 *
 * @param int $form_id Formulier.
 */
function _ww_forms_delete_entries_message( int $form_id ): string {
	$count = _ww_form_entries_count( $form_id );
	if ( $count <= 0 ) {
		return '';
	}
	return sprintf(
		/* translators: %d: aantal inzendingen. */
		_n( 'Dit formulier heeft %d inzending; die worden ook verwijderd.', 'Dit formulier heeft %d inzendingen; die worden ook verwijderd.', $count, 'webwerckt-base' ),
		$count
	);
}

/**
 * Het onclick-attribuut dat een vraag stelt voor een link: return confirm(…), geëscapet voor een attribuut.
 *
 * @param string $message Vraag.
 */
function _ww_forms_confirm_attr( string $message ): string {
	return ' onclick="' . esc_attr( 'return confirm(' . wp_json_encode( $message ) . ');' ) . '"';
}

/**
 * De bevestiging bij "Definitief verwijderen" in de lijst noemt het aantal inzendingen dat mee verdwijnt
 * (before_delete_post ruimt ze op): in de prullenbak, en zonder prullenbak (_ww_forms_trash_is_permanent()) ook
 * daarbuiten.
 *
 * @param mixed $actions Acties onder de rij.
 * @param mixed $post    De rij.
 * @return mixed
 */
function _ww_forms_trash_row_actions( $actions, $post = null ) {
	if ( ! is_array( $actions ) || ! isset( $actions['delete'] ) || ! $post instanceof WP_Post || WW_FORM_POST_TYPE !== $post->post_type ) {
		return $actions;
	}
	if ( 'trash' !== $post->post_status && ! _ww_forms_trash_is_permanent() ) {
		return $actions;
	}
	$message = _ww_forms_delete_entries_message( (int) $post->ID );
	if ( '' === $message ) {
		return $actions;
	}
	$link = (string) $actions['delete'];

	$actions['delete'] = preg_replace( '/^<a /', '<a' . _ww_forms_confirm_attr( $message ) . ' ', $link, 1 ) ?? $link;
	return $actions;
}
add_filter( 'post_row_actions', '_ww_forms_trash_row_actions', 10, 2 );
