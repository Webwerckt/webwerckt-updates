<?php
/**
 * SEO-overzicht: het zijpaneel, de weergaven en hun inhoud (spec seo-overzicht-llms).
 *
 * Het scherm heeft de onderdelen Overzicht (iedereen met toegang) en Techniek (alleen met manage_options) in een eigen
 * zijpaneel naast het WordPress-menu; op mobiel neemt een uitklapper het paneel over, zoals bij Redirects (0046).
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * De onderdelen van het scherm, op slug (?tab=). llms.txt voor wie de Site-instellingen mag bewerken, Techniek alleen
 * voor de beheerder.
 *
 * @return array<string,string>
 */
function _ww_seo_admin_sections(): array {
	$sections = array( 'overzicht' => __( 'Overzicht', 'webwerckt-base' ) );
	if ( current_user_can( WW_SETTINGS_CAP ) ) {
		$sections['llms'] = __( 'llms.txt', 'webwerckt-base' );
	}
	if ( current_user_can( 'manage_options' ) ) {
		$sections['techniek'] = __( 'Techniek', 'webwerckt-base' );
	}
	return $sections;
}

/**
 * De weergave van dit verzoek: list, form, llms of techniek. Techniek zonder manage_options, llms zonder
 * WW_SETTINGS_CAP, en elke onbekende tab, is de lijst; het formulier alleen voor een pagina die je hier mag bewerken (_ww_seo_can_edit()).
 */
function _ww_seo_admin_view(): string {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen een weergave kiezen.
	$tab = isset( $_GET['tab'] ) ? _ww_data_to_string( wp_unslash( $_GET['tab'] ) ) : '';
	if ( 'techniek' === $tab && isset( _ww_seo_admin_sections()['techniek'] ) ) {
		return 'techniek';
	}
	if ( 'llms' === $tab && isset( _ww_seo_admin_sections()['llms'] ) ) {
		return 'llms';
	}
	$edit = _ww_seo_admin_edit_id();
	return $edit > 0 && _ww_seo_can_edit( $edit ) ? 'form' : 'list';
}

/**
 * De pagina die het verzoek wil bewerken (?edit=), of 0.
 */
function _ww_seo_admin_edit_id(): int {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen een weergave kiezen; rechten in _ww_seo_can_edit().
	return isset( $_GET['edit'] ) ? absint( _ww_data_to_string( wp_unslash( $_GET['edit'] ) ) ) : 0;
}

/**
 * De volgende pagina voor het formulier. Na Opslaan staat de geplande volgende in de URL (?next=): 0 is het einde, een
 * ID geldt als hij nog in de gefilterde lijst staat en niet bezocht of de pagina zelf is. Zonder (of met een ongeldige)
 * rekent het formulier hem uit (_ww_seo_next_id()).
 *
 * @param array<mixed>              $args Filters (_ww_seo_list_args()).
 * @param list<int>                 $seen Bezochte pagina's.
 * @param list<array<string,mixed>> $rows Rijen van _ww_seo_overview_rows().
 */
function _ww_seo_admin_planned_next( int $post_id, array $args, array $seen, array $rows ): int {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen een voorstel; hieronder gecontroleerd.
	$raw = isset( $_GET['next'] ) ? _ww_data_to_string( wp_unslash( $_GET['next'] ) ) : null;
	if ( null !== $raw ) {
		$planned = absint( $raw );
		if ( 0 === $planned ) {
			return 0;
		}
		$ids = array_map( 'intval', array_column( _ww_seo_filtered_rows( $args, $rows ), 'id' ) );
		if ( $planned !== $post_id && ! in_array( $planned, $seen, true ) && in_array( $planned, $ids, true ) ) {
			return $planned;
		}
	}
	return _ww_seo_next_id( $post_id, $args, $seen, $rows );
}

/**
 * De bezochte pagina's van "Opslaan en volgende" uit de URL (?seen=).
 *
 * @return list<int>
 */
function _ww_seo_admin_seen(): array {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- alleen getallen, om over te slaan.
	return _ww_seo_seen_ids( isset( $_GET['seen'] ) ? wp_unslash( $_GET['seen'] ) : '' );
}

/**
 * De samenvatting bovenaan het paneel: "24 pagina's, 18 in orde, 6 met een melding".
 *
 * @param list<array<string,mixed>> $rows Rijen van _ww_seo_overview_rows().
 */
function _ww_seo_admin_summary( array $rows ): string {
	$total  = count( $rows );
	$issues = count( array_filter( $rows, static fn( array $row ): bool => array() !== $row['issues'] ) );
	$ok     = $total - $issues;
	return implode(
		', ',
		array(
			/* translators: %s: aantal pagina's. */
			sprintf( _n( '%s pagina', "%s pagina's", $total, 'webwerckt-base' ), number_format_i18n( $total ) ),
			/* translators: %s: aantal pagina's zonder melding. */
			sprintf( _n( '%s in orde', '%s in orde', $ok, 'webwerckt-base' ), number_format_i18n( $ok ) ),
			/* translators: %s: aantal pagina's met een melding. */
			sprintf( _n( '%s met een melding', '%s met een melding', $issues, 'webwerckt-base' ), number_format_i18n( $issues ) ),
		)
	);
}

/**
 * De onderdelen als lijst met links; het actieve krijgt aria-current. Twee vormen: panel (in het zijpaneel, met een
 * Dashicon) en menu (een uitklapper voor mobiel, met het actieve onderdeel in de summary).
 *
 * @param string          $active  Actief onderdeel (overzicht, llms of techniek).
 * @param array<string,int> $counts  Aantal per onderdeel; bij techniek een waarschuwing als het meer dan 0 is.
 * @param string          $variant panel of menu.
 * @return string Geëscapete HTML.
 */
function _ww_seo_render_nav( string $active, array $counts, string $variant ): string {
	$icons  = array(
		'overzicht' => 'dashicons-list-view',
		'llms'      => 'dashicons-media-text',
		'techniek'  => 'dashicons-admin-tools',
	);
	$labels = _ww_seo_admin_sections();
	$items  = '';
	foreach ( $labels as $slug => $label ) {
		$url    = _ww_seo_admin_url( 'overzicht' === $slug ? array() : array( 'tab' => $slug ) );
		$number = $counts[ $slug ] ?? 0;
		$warn   = 'techniek' === $slug && $number > 0;
		// llms.txt heeft niets te tellen.
		$count  = 'llms' === $slug ? '' : '<span class="ww-seo-nav__count' . ( $warn ? ' ww-seo-nav__count--warn' : '' ) . '">' . esc_html( number_format_i18n( $number ) ) . '</span>';
		$icon   = 'panel' === $variant ? '<span class="dashicons ' . esc_attr( $icons[ $slug ] ?? 'dashicons-admin-generic' ) . '" aria-hidden="true"></span>' : '';
		$items .= '<li><a href="' . esc_url( $url ) . '"' . ( $slug === $active ? ' aria-current="page"' : '' ) . '>' . $icon . '<span class="ww-seo-nav__label">' . esc_html( $label ) . '</span>' . $count . '</a></li>';
	}
	if ( 'panel' === $variant ) {
		return '<ul class="ww-seo-panel__nav">' . $items . '</ul>';
	}
	return '<details class="ww-seo-menu"><summary><span>' . esc_html__( 'Onderdeel', 'webwerckt-base' ) . '</span> <b>' . esc_html( $labels[ $active ] ?? '' ) . '</b></summary><ul>' . $items . '</ul></details>';
}

/**
 * De weergave Overzicht: de weergaven, de filters en de tabel.
 *
 * @param list<array<string,mixed>> $rows Rijen van _ww_seo_overview_rows().
 */
function _ww_seo_render_list( array $rows ): string {
	$args  = _ww_seo_list_args();
	$table = new WW_Seo_Overview_List_Table( $rows, $args );
	$table->prepare_items();
	$query = _ww_seo_list_query( $args );
	ob_start();
	$table->views();

	// Twee GET-formulieren, zonder script. De filters in de tabelkop horen via form="ww-seo-filter" bij het eerste: dat
	// houdt de weergave en de sortering, en begint op pagina 1. Het tweede om de tabel houdt alle filters, zodat het
	// paginanummer werkt.
	echo '<form id="ww-seo-filter" method="get">' . _ww_seo_hidden_field( 'page', WW_SEO_SCREEN ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_seo_hidden_field() escapet.
	foreach ( array_intersect_key( $query, array_flip( array( 'view', 'orderby', 'order' ) ) ) as $key => $value ) {
		echo _ww_seo_hidden_field( $key, $value ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_seo_hidden_field() escapet.
	}
	echo '</form>';

	echo '<form method="get" class="ww-seo-table-form">' . _ww_seo_hidden_field( 'page', WW_SEO_SCREEN ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_seo_hidden_field() escapet.
	foreach ( array_diff_key( $query, array( 'paged' => true ) ) as $key => $value ) {
		echo _ww_seo_hidden_field( $key, $value ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_seo_hidden_field() escapet.
	}
	$table->display();
	echo '</form>';
	return (string) ob_get_clean();
}

/**
 * Een verborgen veld.
 *
 * @return string Geëscapete HTML.
 */
function _ww_seo_hidden_field( string $name, string $value ): string {
	return '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '">';
}

/**
 * De meldingen van een pagina als labels: rood als iets ontbreekt, oranje voor de rest; zonder meldingen groen
 * "In orde". Een dubbele titel of beschrijving linkt naar het formulier van de andere pagina. Voor de tabel en het
 * formulier.
 *
 * @param array<string,mixed> $item   Rij van _ww_seo_overview_rows().
 * @param array<int,string>   $titles Titel per pagina, voor de link bij een dubbele titel of beschrijving.
 * @param array<mixed>        $args   Filters van de lijst, voor die link.
 * @return string Geëscapete HTML.
 */
function _ww_seo_render_issue_labels( array $item, array $titles, array $args ): string {
	$issues = is_array( $item['issues'] ?? null ) ? $item['issues'] : array();
	if ( array() === $issues ) {
		return '<span class="ww-seo-label ww-seo-label--good">' . esc_html__( 'In orde', 'webwerckt-base' ) . '</span>';
	}
	$labels = _ww_seo_issue_labels();
	$html   = '';
	foreach ( $issues as $code ) {
		$code  = _ww_data_to_string( $code );
		$level = in_array( $code, array( 'title_missing', 'description_missing', 'image_missing' ), true ) ? 'bad' : 'warn';
		$kind  = 'title_duplicate' === $code ? 'title' : ( 'description_duplicate' === $code ? 'description' : '' );
		if ( '' !== $kind && isset( $item['duplicate_of'][ $kind ] ) ) {
			$other = (int) $item['duplicate_of'][ $kind ];
			$link  = '<a href="' . esc_url( _ww_seo_form_url( $other, $args ) ) . '">' . esc_html( _ww_seo_plain_title( $titles[ $other ] ?? get_the_title( $other ) ) ) . '</a>';
			$text  = sprintf(
				'title' === $kind
					/* translators: %s: link naar de andere pagina. */
					? esc_html__( 'Titel dubbel met %s', 'webwerckt-base' )
					/* translators: %s: link naar de andere pagina. */
					: esc_html__( 'Beschrijving dubbel met %s', 'webwerckt-base' ),
				$link
			);
		} elseif ( 'alt_missing' === $code ) {
			$count = (int) ( $item['no_alt'] ?? 0 );
			$text  = esc_html(
				sprintf(
					/* translators: %s: aantal afbeeldingen. */
					_n( '%s afbeelding zonder alt-tekst', '%s afbeeldingen zonder alt-tekst', $count, 'webwerckt-base' ),
					number_format_i18n( $count )
				)
			);
		} else {
			$text = esc_html( $labels[ $code ] ?? $code );
		}
		$html .= '<span class="ww-seo-label ww-seo-label--' . $level . '">' . $text . '</span> ';
	}
	return '<span class="ww-seo-labels">' . trim( $html ) . '</span>';
}

/**
 * Een titel om te tonen: zonder HTML, en nooit leeg.
 *
 * @param string $title Titel van de pagina.
 */
function _ww_seo_plain_title( string $title ): string {
	$title = trim( wp_strip_all_tags( $title ) );
	return '' === $title ? __( '(geen titel)', 'webwerckt-base' ) : $title;
}

/**
 * Het adres zoals Google het boven een zoekresultaat zet: zonder https:// en met › tussen de delen.
 */
function _ww_seo_preview_url( string $url ): string {
	$parts = wp_parse_url( $url );
	if ( ! is_array( $parts ) || empty( $parts['host'] ) ) {
		return $url;
	}
	$path = array_filter( explode( '/', (string) ( $parts['path'] ?? '' ) ), static fn( string $part ): bool => '' !== $part );
	return implode( ' › ', array_merge( array( (string) $parts['host'] ), array_map( 'rawurldecode', $path ) ) );
}

/**
 * De terugval uit de Site-instellingen onder titel of beschrijving van de voorpagina, of ''.
 *
 * @param int    $post_id De voorpagina (of met Meertalig een vertaling ervan).
 * @param string $setting seo_home_title of seo_home_description.
 * @return string Geëscapete HTML.
 */
function _ww_seo_render_home_fallback( int $post_id, string $setting ): string {
	$text = (string) _ww_seo_front_page_setting( $post_id, $setting );
	if ( '' === $text ) {
		return '';
	}
	return '<p class="description ww-seo-fallback">' . esc_html(
		sprintf(
			/* translators: %s: titel of beschrijving uit de Site-instellingen. */
			__( 'Leeg: “%s” uit de Site-instellingen.', 'webwerckt-base' ),
			$text
		)
	) . '</p>';
}

/**
 * Het formulier van één pagina: terug naar de lijst, het adres en de meldingen, de drie velden, het voorbeeld in
 * Google en de knoppen. Werkt zonder script; assets/js/seo-overview-admin.js laat het voorbeeld meelopen en maakt van
 * de afbeelding een mediakiezer, assets/js/seo-admin.js zet de teller onder titel en beschrijving.
 *
 * De volgende pagina ("Opslaan en volgende") rekent het formulier hier uit, vóór het opslaan, en stuurt hem mee
 * (ww_seo_next), met de al bezochte pagina's (ww_seo_seen).
 *
 * @param list<array<string,mixed>> $rows Rijen van _ww_seo_overview_rows().
 * @return string Geëscapete HTML.
 */
function _ww_seo_render_form( int $post_id, array $rows ): string {
	$args    = _ww_seo_list_args();
	$seen    = _ww_seo_seen_in_list( _ww_seo_admin_seen(), array_map( 'intval', array_column( _ww_seo_filtered_rows( $args, $rows ), 'id' ) ) );
	$next    = _ww_seo_admin_planned_next( $post_id, $args, $seen, $rows );
	$preview = _ww_seo_preview( $post_id );
	$post    = get_post( $post_id );
	$front   = null !== _ww_seo_front_page_setting( $post_id, 'seo_home_title' );
	$value   = static fn( string $field ): string => _ww_data_to_string( _ww_data_get_stored( $field, $post_id ) );
	$titles  = array();
	$row     = null;
	foreach ( $rows as $candidate ) {
		$titles[ (int) $candidate['id'] ] = _ww_data_to_string( $candidate['title'] );
		if ( (int) $candidate['id'] === $post_id ) {
			$row = $candidate;
		}
	}

	$html = '<p class="ww-seo-back"><a href="' . esc_url( _ww_seo_admin_url( _ww_seo_list_query( $args ) ) ) . '">← ' . esc_html__( "Alle pagina's", 'webwerckt-base' ) . '</a></p>';
	if ( '' !== $preview['url'] ) {
		$html .= '<p class="ww-seo-page-url"><a href="' . esc_url( $preview['url'] ) . '" target="_blank" rel="noopener">' . esc_html( $preview['url'] ) . '<span class="screen-reader-text"> ' . esc_html__( '(opent in een nieuw tabblad)', 'webwerckt-base' ) . '</span></a></p>';
	}
	if ( null !== $row ) {
		$html .= '<div class="ww-seo-page-issues">' . _ww_seo_render_issue_labels( $row, $titles, $args ) . '</div>';
	}

	$html .= '<form method="post" class="ww-seo-form" action="' . esc_url( _ww_seo_form_url( $post_id, $args ) ) . '">';
	$html .= _ww_seo_hidden_field( 'ww_seo_action', 'save' );
	$html .= _ww_seo_hidden_field( 'ww_seo_id', (string) $post_id );
	$html .= _ww_seo_hidden_field( 'ww_seo_next', (string) $next );
	$html .= _ww_seo_hidden_field( 'ww_seo_seen', implode( ',', $seen ) );
	$html .= wp_nonce_field( 'ww_seo_save_' . $post_id, '_wpnonce', true, false );
	if ( ! $front && $post instanceof WP_Post ) {
		// De teller (seo-admin.js) leest de paginatitel uit #title, zoals op het bewerkscherm. Zonder naam: gaat niet mee.
		$html .= '<input type="hidden" id="title" value="' . esc_attr( _ww_plain_text( get_the_title( $post ) ) ) . '">';
	}
	$html .= '<div class="ww-seo-box"><table class="form-table" role="presentation"><tbody>';

	// Titel in Google.
	$html .= '<tr><th scope="row"><label for="ww-seo-title">' . esc_html__( 'Titel in Google', 'webwerckt-base' ) . '</label></th><td>';
	$html .= '<input type="text" id="ww-seo-title" name="ww_fields[ww_seo_title]" class="large-text" value="' . esc_attr( $value( 'ww_seo_title' ) ) . '">';
	// De voorpagina valt terug op de Site-instellingen, anders (zoals WordPress) op de sitenaam met de ondertitel.
	$fallback = $front ? _ww_seo_render_home_fallback( $post_id, 'seo_home_title' ) : '';
	if ( '' === $fallback ) {
		$fallback = '<p class="description">' . ( $front
			? esc_html__( 'Leeg: de naam van de site met de ondertitel.', 'webwerckt-base' )
			: esc_html__( 'Leeg: de titel van de pagina met de naam van de site erachter.', 'webwerckt-base' ) ) . '</p>';
	}
	$html .= $fallback;
	$html .= '</td></tr>';

	// Beschrijving in Google.
	$html .= '<tr><th scope="row"><label for="ww-seo-description">' . esc_html__( 'Beschrijving in Google', 'webwerckt-base' ) . '</label></th><td>';
	$html .= '<textarea id="ww-seo-description" name="ww_fields[ww_seo_description]" class="large-text" rows="3">' . esc_textarea( $value( 'ww_seo_description' ) ) . '</textarea>';
	$fallback = $front ? _ww_seo_render_home_fallback( $post_id, 'seo_home_description' ) : '';
	$html    .= '' !== $fallback ? $fallback : '<p class="description">' . esc_html__( 'Leeg: het begin van de tekst van de pagina.', 'webwerckt-base' ) . '</p>';
	$html .= '</td></tr>';

	// Afbeelding bij delen: zonder script een getalveld met de bijlage-ID, met script de mediakiezer.
	$image  = _ww_data_to_attachment_id( _ww_data_get_stored( 'ww_seo_image', $post_id ) );
	$thumb  = $image > 0 ? wp_get_attachment_image( $image, 'medium', false, array( 'alt' => '' ) ) : '';
	$html  .= '<tr><th scope="row"><label for="ww-seo-image">' . esc_html__( 'Afbeelding bij delen', 'webwerckt-base' ) . '</label></th><td><div class="ww-seo-image">';
	$html  .= '<div class="ww-seo-image__preview">' . $thumb . '</div>';
	$html  .= '<p class="ww-seo-image__id"><input type="number" min="0" step="1" id="ww-seo-image" name="ww_fields[ww_seo_image]" class="small-text" value="' . esc_attr( $image > 0 ? (string) $image : '' ) . '"> ';
	$html  .= '<span class="description">' . esc_html__( 'Het nummer (ID) van de afbeelding in de mediabibliotheek.', 'webwerckt-base' ) . '</span></p>';
	$html  .= '<p class="ww-seo-image__buttons" hidden><button type="button" class="button ww-seo-image__choose" data-choose="' . esc_attr__( 'Afbeelding kiezen', 'webwerckt-base' ) . '" data-other="' . esc_attr__( 'Andere afbeelding kiezen', 'webwerckt-base' ) . '">' . esc_html( $image > 0 ? __( 'Andere afbeelding kiezen', 'webwerckt-base' ) : __( 'Afbeelding kiezen', 'webwerckt-base' ) ) . '</button> ';
	$html  .= '<button type="button" class="button-link button-link-delete ww-seo-image__remove"' . ( $image > 0 ? '' : ' hidden' ) . '>' . esc_html__( 'Verwijderen', 'webwerckt-base' ) . '</button></p>';
	$html  .= '<p class="description">' . esc_html__( 'Leeg: de uitgelichte afbeelding, anders die uit de Site-instellingen.', 'webwerckt-base' ) . '</p>';
	$html  .= '</div></td></tr>';

	// Niet in llms.txt: alleen als het post type het veld heeft. Het verborgen veld "0" ervoor zorgt dat uitvinken ook opslaat.
	if ( isset( array_column( _ww_pods_fields( $post instanceof WP_Post ? $post->post_type : '' ), null, 'name' )['ww_seo_llms_exclude'] ) ) {
		$html .= '<tr><th scope="row">' . esc_html__( 'Niet in llms.txt', 'webwerckt-base' ) . '</th><td>';
		$html .= '<input type="hidden" name="ww_fields[ww_seo_llms_exclude]" value="0">';
		$html .= '<label for="ww-seo-llms-exclude"><input type="checkbox" id="ww-seo-llms-exclude" name="ww_fields[ww_seo_llms_exclude]" value="1"' . checked( _ww_data_to_bool( _ww_data_get_stored( 'ww_seo_llms_exclude', $post_id ) ), true, false ) . '> ' . esc_html__( 'Ja, weglaten', 'webwerckt-base' ) . '</label>';
		$html .= '<p class="description">' . esc_html__( 'Alleen uit llms.txt (voor AI-diensten), niet uit Google. Uit Google haal je een pagina met Verbergen voor zoekmachines.', 'webwerckt-base' ) . '</p>';
		$html .= '</td></tr>';
	}

	// Voorbeeld in Google: zonder script de opgeslagen versie; met script loopt het mee tijdens het typen.
	$html .= '<tr><th scope="row">' . esc_html__( 'Voorbeeld in Google', 'webwerckt-base' ) . '</th><td>';
	$html .= '<div class="ww-seo-preview" data-fallback-title="' . esc_attr( $preview['fallback_title'] ) . '" data-fallback-description="' . esc_attr( $preview['fallback_description'] ) . '" data-max="' . esc_attr( (string) $preview['max'] ) . '">';
	$html .= '<span class="ww-seo-preview__url">' . esc_html( _ww_seo_preview_url( $preview['url'] ) ) . '</span>';
	$html .= '<span class="ww-seo-preview__title">' . esc_html( $preview['title'] ) . '</span>';
	$html .= '<span class="ww-seo-preview__description">' . esc_html( $preview['description'] ) . '</span>';
	$html .= '</div>';
	$html .= '<p class="description">' . esc_html__( 'Ongeveer zoals de pagina in de zoekresultaten verschijnt. Google kan een lange titel of beschrijving inkorten of zelf een andere kiezen.', 'webwerckt-base' ) . '</p>';
	$html .= '</td></tr>';
	$html .= '</tbody></table></div>';

	// De eerste knop is die van Enter: gewoon opslaan.
	$page  = $post instanceof WP_Post && _ww_editor_can_edit( $post ) ? _ww_editor_url( $post_id ) : (string) get_edit_post_link( $post_id, 'raw' );
	$html .= '<p class="submit ww-seo-buttons">';
	$html .= '<button type="submit" name="ww_seo_submit" value="save" class="button">' . esc_html__( 'Opslaan', 'webwerckt-base' ) . '</button> ';
	$html .= '<button type="submit" name="ww_seo_submit" value="next" class="button button-primary">' . esc_html__( 'Opslaan en volgende', 'webwerckt-base' ) . '</button> ';
	if ( '' !== $page ) {
		$html .= '<a class="button-link ww-seo-buttons__page" href="' . esc_url( $page ) . '">' . esc_html__( 'Naar de pagina', 'webwerckt-base' ) . '</a>';
	}
	$html .= '</p>';
	$html .= '</form>';
	return $html;
}

/**
 * Een korte tabel met pagina's voor Techniek, met een link naar het bewerkscherm. Leeg: "Niets gevonden."
 *
 * @param list<int> $ids       Post-ID's.
 * @param bool      $canonical Ook de canonical-URL tonen.
 * @return string Geëscapete HTML.
 */
function _ww_seo_render_tech_table( array $ids, bool $canonical = false ): string {
	if ( array() === $ids ) {
		return '<p class="ww-seo-muted">' . esc_html__( 'Niets gevonden.', 'webwerckt-base' ) . '</p>';
	}
	$html  = '<table class="widefat striped ww-seo-tech-table"><thead><tr><th scope="col">' . esc_html__( 'Pagina', 'webwerckt-base' ) . '</th><th scope="col">' . esc_html__( 'Soort', 'webwerckt-base' ) . '</th>';
	$html .= $canonical ? '<th scope="col">' . esc_html__( 'Canonical', 'webwerckt-base' ) . '</th>' : '';
	$html .= '</tr></thead><tbody>';
	foreach ( $ids as $id ) {
		$title  = trim( wp_strip_all_tags( get_the_title( $id ) ) );
		$title  = '' === $title ? __( '(geen titel)', 'webwerckt-base' ) : $title;
		$edit   = get_edit_post_link( $id, 'raw' );
		$object = get_post_type_object( (string) get_post_type( $id ) );
		$html  .= '<tr><td>' . ( null === $edit || '' === $edit ? esc_html( $title ) : '<a href="' . esc_url( $edit ) . '">' . esc_html( $title ) . '</a>' ) . '</td>';
		$html  .= '<td>' . esc_html( $object instanceof WP_Post_Type ? (string) $object->labels->singular_name : '' ) . '</td>';
		if ( $canonical ) {
			$html .= '<td><code>' . esc_html( _ww_data_to_string( _ww_data_get_stored( 'ww_seo_canonical', $id ) ) ) . '</code></td>';
		}
		$html .= '</tr>';
	}
	return $html . '</tbody></table>';
}

/**
 * De weergave Techniek: wat er op siteniveau mist, en de pagina's die niet in het overzicht staan.
 *
 * @param list<string>                                                      $site  Uit _ww_seo_tech_site().
 * @param array{noindex: list<int>, canonical: list<int>, password: list<int>} $pages Uit _ww_seo_tech_pages().
 */
function _ww_seo_render_tech( array $site, array $pages ): string {
	$all = array_values( array_unique( array_merge( $pages['noindex'], $pages['canonical'], $pages['password'] ) ) );
	if ( array() !== $all ) {
		_prime_post_caches( $all, false, true );
	}

	$html  = '<p class="ww-seo-intro">' . esc_html__( 'Instellingen en pagina\'s die bepalen of Google de site ziet. Dit deel is alleen voor de beheerder.', 'webwerckt-base' ) . '</p>';
	$html .= '<h2>' . esc_html__( 'Site', 'webwerckt-base' ) . '</h2>';
	if ( array() === $site ) {
		$html .= '<p class="ww-seo-muted">' . esc_html__( 'Niets gevonden.', 'webwerckt-base' ) . '</p>';
	} else {
		$html .= '<ul class="ww-seo-tech-list">';
		foreach ( $site as $message ) {
			$html .= '<li><span class="ww-seo-label ww-seo-label--warn">' . esc_html( $message ) . '</span></li>';
		}
		$html .= '</ul>';
	}

	$parts = array(
		'noindex'   => array( __( 'Verborgen voor zoekmachines (noindex)', 'webwerckt-base' ), __( 'Deze pagina\'s staan niet in Google. Klopt dat niet, zet dan op het bewerkscherm in de box SEO het vinkje uit.', 'webwerckt-base' ) ),
		'canonical' => array( __( 'Canonical naar een andere pagina', 'webwerckt-base' ), __( 'Deze pagina\'s zeggen tegen Google dat een andere pagina het origineel is. Google toont dan die andere pagina.', 'webwerckt-base' ) ),
		'password'  => array( __( 'Met een wachtwoord', 'webwerckt-base' ), __( 'Google kan de tekst van deze pagina\'s niet lezen.', 'webwerckt-base' ) ),
	);
	foreach ( $parts as $kind => $part ) {
		$html .= '<h2>' . esc_html( $part[0] ) . '</h2><p class="ww-seo-muted">' . esc_html( $part[1] ) . '</p>';
		$html .= _ww_seo_render_tech_table( $pages[ $kind ], 'canonical' === $kind );
	}
	return $html;
}

/**
 * De stand van llms.txt in woorden, voor achter de keuzerondjes.
 */
function _ww_seo_llms_state(): string {
	if ( _ww_llms_enabled() ) {
		return __( 'llms.txt staat nu aan.', 'webwerckt-base' );
	}
	if ( 'auto' === _ww_llms_mode() && '1' !== (string) get_option( 'blog_public', '1' ) ) {
		return __( 'llms.txt staat nu uit, want zoekmachines worden ontmoedigd.', 'webwerckt-base' );
	}
	return __( 'llms.txt staat nu uit.', 'webwerckt-base' );
}

/**
 * De weergave llms.txt: de stand, de inleiding, de soorten pagina's en daaronder de adressen en een voorbeeld.
 * Werkt zonder script; het formulier gaat naar ww_seo_action=llms_save.
 *
 * @return string Geëscapete HTML.
 */
function _ww_seo_render_llms(): string {
	$html  = '<p class="ww-seo-intro">' . esc_html__( 'Een samenvatting van je site voor AI-diensten zoals ChatGPT. Hij bevat alleen pagina\'s die ook in Google horen.', 'webwerckt-base' ) . '</p>';
	$html .= '<form method="post" class="ww-seo-form" action="' . esc_url( _ww_seo_admin_url( array( 'tab' => 'llms' ) ) ) . '">';
	$html .= _ww_seo_hidden_field( 'ww_seo_action', 'llms_save' );
	$html .= wp_nonce_field( 'ww_llms_save', '_wpnonce', true, false );
	$html .= '<div class="ww-seo-box"><table class="form-table" role="presentation"><tbody>';

	// Stand.
	$mode    = _ww_llms_mode();
	$options = array(
		'auto' => __( 'Automatisch: aan zodra zoekmachines de site mogen zien', 'webwerckt-base' ),
		'on'   => __( 'Aan', 'webwerckt-base' ),
		'off'  => __( 'Uit', 'webwerckt-base' ),
	);
	$html   .= '<tr><th scope="row">' . esc_html__( 'Stand', 'webwerckt-base' ) . '</th><td><fieldset><legend class="screen-reader-text">' . esc_html__( 'Stand van llms.txt', 'webwerckt-base' ) . '</legend>';
	foreach ( $options as $value => $label ) {
		$html .= '<label><input type="radio" name="ww_fields[seo_llms_mode]" value="' . esc_attr( $value ) . '"' . checked( $mode, $value, false ) . '> ' . esc_html( $label ) . '</label><br>';
	}
	$html .= '</fieldset><p class="description">' . esc_html( _ww_seo_llms_state() ) . '</p></td></tr>';

	// Inleiding, met Meertalig ook per extra taal.
	$fallback = _ww_llms_intro_fallback( '' );
	$html .= '<tr><th scope="row"><label for="ww-llms-intro">' . esc_html__( 'Inleiding', 'webwerckt-base' ) . '</label></th><td>';
	$html .= '<textarea id="ww-llms-intro" name="ww_fields[seo_llms_intro]" class="large-text" rows="3" maxlength="500" placeholder="' . esc_attr( $fallback ) . '">' . esc_textarea( _ww_data_to_string( _ww_data_get_setting( 'seo_llms_intro' ) ) ) . '</textarea>';
	$html .= '<p class="description">' . esc_html__( 'Een of twee zinnen over de site. Leeg: de homepagebeschrijving uit de Site-instellingen, anders de ondertitel.', 'webwerckt-base' ) . '</p>';
	if ( _ww_languages_active() ) {
		foreach ( _ww_visible_language_codes() as $code ) {
			$language = _ww_language( $code );
			$name     = null !== $language ? $language['name'] : $code;
			$label    = sprintf(
				/* translators: %s: naam van de taal. */
				__( 'Inleiding in %s', 'webwerckt-base' ),
				$name
			);
			$html    .= '<p><label for="ww-llms-intro-' . esc_attr( $code ) . '">' . esc_html( $label ) . '</label><br>';
			$html    .= '<textarea id="ww-llms-intro-' . esc_attr( $code ) . '" name="ww_llms_intro[' . esc_attr( $code ) . ']" class="large-text" rows="3" maxlength="500" placeholder="' . esc_attr( _ww_llms_intro_fallback( $code ) ) . '">' . esc_textarea( _ww_data_to_string( _ww_settings_translation( $code )['seo_llms_intro'] ?? '' ) ) . '</textarea></p>';
		}
	}
	$html .= '</td></tr>';

	// Soorten pagina's. Een soort buiten de sitemap is uitgegrijsd; een opgeslagen vinkje blijft bewaard.
	$choices = _ww_llms_choices();
	if ( array() !== $choices ) {
		$chosen  = _ww_llms_chosen_types();
		$allowed = _ww_llms_sitemap_types();
		$html   .= '<tr><th scope="row">' . esc_html__( 'Welke soorten pagina\'s', 'webwerckt-base' ) . '</th><td><fieldset><legend class="screen-reader-text">' . esc_html__( 'Welke soorten pagina\'s', 'webwerckt-base' ) . '</legend>';
		foreach ( $choices as $type => $label ) {
			$on    = in_array( $type, $chosen, true );
			$off   = ! in_array( $type, $allowed, true );
			$html .= '<label><input type="checkbox" name="ww_fields[seo_llms_post_types][]" value="' . esc_attr( $type ) . '"' . checked( $on, true, false ) . disabled( $off, true, false ) . '> ' . esc_html( $label );
			$html .= $off ? ' <span class="description">(' . esc_html__( 'staat niet in de sitemap', 'webwerckt-base' ) . ')</span>' : '';
			$html .= '</label><br>';
			if ( $off && $on ) {
				$html .= '<input type="hidden" name="ww_fields[seo_llms_post_types][]" value="' . esc_attr( $type ) . '">';
			}
		}
		$html .= '</fieldset><p class="description">' . esc_html__( 'Aangevinkt: die soort staat in llms.txt. Een nieuwe soort staat standaard uit.', 'webwerckt-base' ) . '</p></td></tr>';
	}
	$html .= '</tbody></table></div>';
	$html .= '<p class="submit"><button type="submit" class="button button-primary">' . esc_html__( 'Opslaan', 'webwerckt-base' ) . '</button></p></form>';

	// Adressen en voorbeeld.
	$html .= '<h2>' . esc_html__( 'Adres', 'webwerckt-base' ) . '</h2><ul>';
	foreach ( _ww_llms_urls() as $code => $url ) {
		$language = '' !== $code ? _ww_language( $code ) : null;
		$html    .= '<li>' . ( null !== $language ? esc_html( $language['name'] ) . ': ' : '' ) . '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener"><code>' . esc_html( $url ) . '</code><span class="screen-reader-text"> ' . esc_html__( '(opent in een nieuw tabblad)', 'webwerckt-base' ) . '</span></a></li>';
	}
	$html .= '</ul><h2>' . esc_html__( 'Voorbeeld', 'webwerckt-base' ) . '</h2>';
	if ( _ww_llms_enabled() ) {
		$lines = explode( "\n", _ww_llms_build( '' ) );
		$shown = implode( "\n", array_slice( $lines, 0, 15 ) ) . ( count( $lines ) > 15 ? "\n…" : '' );
		$html .= '<p class="ww-seo-muted">' . esc_html__( 'De eerste regels van llms.txt in de standaardtaal.', 'webwerckt-base' ) . '</p>';
		$html .= '<pre class="ww-seo-llms-preview">' . esc_html( $shown ) . '</pre>';
	} else {
		$html .= '<p class="ww-seo-muted">' . esc_html__( 'llms.txt staat uit.', 'webwerckt-base' ) . '</p>';
	}
	return $html;
}

/**
 * Toont het scherm: het zijpaneel en de gekozen weergave.
 */
function _ww_seo_admin_render(): void {
	if ( ! _ww_seo_enabled() || ! current_user_can( 'edit_others_pages' ) ) {
		return;
	}
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
	require_once __DIR__ . '/class-ww-seo-overview-list-table.php';

	$view    = _ww_seo_admin_view();
	$section = in_array( $view, array( 'llms', 'techniek' ), true ) ? $view : 'overzicht';
	$edit    = _ww_seo_admin_edit_id();
	if ( 'list' === $view && $edit > 0 ) {
		add_settings_error( 'ww_seo', 'ww_seo_edit', __( 'Deze pagina kun je hier niet bewerken.', 'webwerckt-base' ) );
	}
	// Eén keer rekenen: het paneel, de weergaven en de tabel gebruiken dezelfde rijen.
	$overview = _ww_seo_overview_rows();
	$summary  = _ww_seo_admin_summary( $overview['rows'] );
	$counts   = array( 'overzicht' => count( $overview['rows'] ) );
	$site     = array();
	$pages    = array(
		'noindex'   => array(),
		'canonical' => array(),
		'password'  => array(),
	);
	if ( isset( _ww_seo_admin_sections()['techniek'] ) ) {
		$site                = _ww_seo_tech_site();
		$pages               = _ww_seo_tech_pages();
		$counts['techniek']  = count( $site ) + count( array_unique( array_merge( $pages['noindex'], $pages['canonical'], $pages['password'] ) ) );
	}

	// De weergave eerst, zoals bij Redirects.
	$title = _ww_seo_admin_sections()[ $section ];
	if ( 'techniek' === $view ) {
		$content = _ww_seo_render_tech( $site, $pages );
	} elseif ( 'llms' === $view ) {
		$content = _ww_seo_render_llms();
	} elseif ( 'form' === $view ) {
		$content = _ww_seo_render_form( $edit, $overview['rows'] );
		$title   = _ww_seo_plain_title( get_the_title( $edit ) );
	} else {
		$content = _ww_seo_render_list( $overview['rows'] );
	}

	echo '<div class="wrap ww-seo"><div class="ww-seo-layout">';

	echo '<nav class="ww-seo-panel" aria-label="' . esc_attr__( 'Onderdelen van SEO', 'webwerckt-base' ) . '">';
	echo '<p class="ww-seo-panel__title">' . esc_html__( 'SEO', 'webwerckt-base' ) . '</p>';
	echo '<p class="ww-seo-panel__status">' . esc_html( $summary ) . '</p>';
	echo _ww_seo_render_nav( $section, $counts, 'panel' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_seo_render_nav() escapet.
	$foot = esc_html__( 'Alleen pagina\'s die in Google horen. Pagina\'s die verborgen zijn voor zoekmachines staan niet in het overzicht.', 'webwerckt-base' );
	if ( isset( _ww_seo_admin_sections()['techniek'] ) ) {
		$foot .= ' ' . sprintf(
			/* translators: %s: link naar Techniek. */
			esc_html__( 'Je vindt ze onder %s.', 'webwerckt-base' ),
			'<a href="' . esc_url( _ww_seo_admin_url( array( 'tab' => 'techniek' ) ) ) . '">' . esc_html__( 'Techniek', 'webwerckt-base' ) . '</a>'
		);
	}
	echo '<p class="ww-seo-panel__foot"><span class="dashicons dashicons-info-outline" aria-hidden="true"></span><span>' . $foot . '</span></p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hierboven geëscapet.
	echo '</nav>';

	echo '<div class="ww-seo-main">';
	echo '<h1 class="wp-heading-inline">' . esc_html( $title ) . '</h1>';
	echo '<hr class="wp-header-end">';
	settings_errors( 'ww_seo' );
	echo '<div class="ww-seo-pickers">' . _ww_seo_render_nav( $section, $counts, 'menu' ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_seo_render_nav() escapet.
	echo '<p class="ww-seo-status-line">' . esc_html( $summary ) . '</p>';
	if ( $overview['truncated'] ) {
		echo '<div class="notice notice-warning inline"><p>' . esc_html(
			sprintf(
				/* translators: %s: hoogste aantal pagina's. */
				__( "Deze site heeft meer dan %s pagina's. Het overzicht toont de laatst gewijzigde.", 'webwerckt-base' ),
				number_format_i18n( _ww_seo_overview_limit() )
			)
		) . '</p></div>';
	}
	echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- de weergaven escapen zelf.
	echo '</div>';

	echo '</div></div>';
}
