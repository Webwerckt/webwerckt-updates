<?php
/**
 * Tabel met de inzendingen op het scherm Formulieren > Inzendingen (inc/forms-admin.php). Wordt pas geladen als dat
 * scherm wordt getoond, na WP_List_Table.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * De inzendingen: datum (link naar het detail), formulier, samenvatting, pagina en de mailstatus. Een nieuwe
 * inzending is vetgedrukt. Met Meertalig actief (beslissing 0043) toont een gekozen formulier de inzendingen van zijn
 * vertaalgroep (_ww_form_group_ids()), met de kolom Taal.
 */
class WW_Form_Entries_List_Table extends WP_List_Table {

	/**
	 * Per formulier of het een PDF maakt, onthouden voor de rijen van deze lijst.
	 *
	 * @var array<int,bool>
	 */
	private array $pdf_enabled = array();

	public function __construct() {
		parent::__construct(
			array(
				'singular' => 'entry',
				'plural'   => 'entries',
				'ajax'     => false,
			)
		);
	}

	/**
	 * Het formulier waarop gefilterd wordt, of 0.
	 */
	public function get_form_id(): int {
		return isset( $_GET['form_id'] ) ? absint( _ww_data_to_string( wp_unslash( $_GET['form_id'] ) ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen filteren.
	}

	/**
	 * De filter op formulieren voor _ww_form_entries_query(): de vertaalgroep van het gekozen formulier (met Meertalig
	 * actief), anders het formulier zelf.
	 *
	 * @return array{form_ids?:int[],form_id?:int}
	 */
	private function form_filter(): array {
		return _ww_form_entries_form_filter( $this->get_form_id() );
	}

	/**
	 * De statusfilter: new, read, spam of ''.
	 */
	public function get_status_filter(): string {
		$status = isset( $_GET['status'] ) ? sanitize_key( _ww_data_to_string( wp_unslash( $_GET['status'] ) ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen filteren.
		return in_array( $status, array( 'new', 'read', 'spam' ), true ) ? $status : '';
	}

	/**
	 * De zoekterm, of ''.
	 */
	public function get_search_term(): string {
		return isset( $_GET['s'] ) ? _ww_form_clean_input( _ww_data_to_string( wp_unslash( $_GET['s'] ) ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen zoeken; zelfde opschoning als de opgeslagen waarden.
	}

	/**
	 * @return array<string,string>
	 */
	public function get_columns() {
		$columns = array(
			'cb'        => '<input type="checkbox">',
			'created'   => __( 'Datum', 'webwerckt-base' ),
			'form'      => __( 'Formulier', 'webwerckt-base' ),
			'summary'   => __( 'Samenvatting', 'webwerckt-base' ),
			'page'      => __( 'Pagina', 'webwerckt-base' ),
			'mail'      => __( 'Mail', 'webwerckt-base' ),
			'recaptcha' => __( 'Controle', 'webwerckt-base' ),
		);
		if ( _ww_languages_active() ) {
			$columns = array_slice( $columns, 0, 3, true ) + array( 'language' => __( 'Taal', 'webwerckt-base' ) ) + array_slice( $columns, 3, null, true );
		}
		return $columns;
	}

	/**
	 * De filterlinks Alle (zonder spam), Nieuw, Gelezen en Spam, elk met het aantal binnen het gekozen formulier.
	 *
	 * @return array<string,string>
	 */
	protected function get_views() {
		$form_id = $this->get_form_id();
		$current = $this->get_status_filter();
		$labels  = array(
			''     => __( 'Alle', 'webwerckt-base' ),
			'new'  => __( 'Nieuw', 'webwerckt-base' ),
			'read' => __( 'Gelezen', 'webwerckt-base' ),
			'spam' => __( 'Spam', 'webwerckt-base' ),
		);
		$counts  = _ww_form_entries_status_counts( $this->form_filter() );
		$views   = array();
		foreach ( $labels as $status => $label ) {
			$count = $counts[ $status ];
			$args  = array();
			if ( $form_id > 0 ) {
				$args['form_id'] = (string) $form_id;
			}
			if ( '' !== $status ) {
				$args['status'] = $status;
			}
			$views[ '' === $status ? 'all' : $status ] = sprintf(
				'<a href="%s"%s>%s <span class="count">(%s)</span></a>',
				esc_url( _ww_forms_entries_url( $args ) ),
				$current === $status ? ' class="current" aria-current="page"' : '',
				esc_html( $label ),
				esc_html( number_format_i18n( $count ) )
			);
		}
		return $views;
	}

	/**
	 * @return array<string,string>
	 */
	protected function get_bulk_actions() {
		if ( 'spam' === $this->get_status_filter() ) {
			return array(
				'not-spam'    => __( 'Geen spam', 'webwerckt-base' ),
				'bulk-delete' => __( 'Verwijderen', 'webwerckt-base' ),
			);
		}
		return array(
			'bulk-delete' => __( 'Verwijderen', 'webwerckt-base' ),
			'mark-read'   => __( 'Markeren als gelezen', 'webwerckt-base' ),
			'mark-unread' => __( 'Markeren als ongelezen', 'webwerckt-base' ),
		);
	}

	/**
	 * Zoekt, filtert en pagineert via _ww_form_entries_query().
	 */
	public function prepare_items(): void {
		$result = _ww_form_entries_query(
			$this->form_filter() + array(
				'status'   => $this->get_status_filter(),
				'search'   => $this->get_search_term(),
				'page'     => $this->get_pagenum(),
				'per_page' => WW_FORM_ENTRIES_PER_PAGE,
			)
		);

		$this->_column_headers = array( $this->get_columns(), array(), array(), 'created' );
		$this->set_pagination_args(
			array(
				'total_items' => $result['total'],
				'per_page'    => WW_FORM_ENTRIES_PER_PAGE,
			)
		);
		$this->items = $result['items'];
	}

	/**
	 * Tekst als er geen inzendingen zijn.
	 */
	public function no_items(): void {
		esc_html_e( 'Er zijn geen inzendingen.', 'webwerckt-base' );
	}

	/**
	 * Boven de tabel: de export van het gekozen formulier (alleen als er op een formulier gefilterd is).
	 *
	 * @param string $which top of bottom.
	 */
	protected function extra_tablenav( $which ): void {
		$form_id = $this->get_form_id();
		if ( 'top' !== $which || $form_id <= 0 ) {
			return;
		}
		echo '<div class="alignleft actions"><a class="button" href="' . esc_url( _ww_forms_entries_action_url( 'export', array( 'form_id' => (string) $form_id ) ) ) . '">' . esc_html__( 'Exporteer als CSV', 'webwerckt-base' ) . '</a></div>';
	}

	/**
	 * Selectievakje voor de bulkactie.
	 *
	 * @param object $item Inzending.
	 */
	protected function column_cb( $item ): string {
		return '<input type="checkbox" name="ids[]" value="' . esc_attr( (string) $item->id ) . '">';
	}

	/**
	 * De datum als link naar het detail (vet bij een nieuwe inzending), met de actie Verwijderen eronder. De links nemen
	 * de filters mee (formulier, status, zoekterm), zodat Vorige, Volgende, Terug en de melding na verwijderen in
	 * dezelfde selectie blijven.
	 *
	 * @param object $item Inzending.
	 */
	protected function column_created( $item ): string {
		$keep   = _ww_forms_entries_view_args();
		$detail = esc_url( _ww_forms_entries_url( array( 'entry' => (string) $item->id ) + $keep ) );
		$link   = '<a href="' . $detail . '">' . esc_html( _ww_forms_entries_date( (string) $item->created ) ) . '</a>';
		if ( 'new' === $item->status ) {
			$link = '<strong>' . $link . '</strong>';
		}
		$actions = array(
			'view'   => '<a href="' . $detail . '">' . esc_html__( 'Bekijken', 'webwerckt-base' ) . '</a>',
			'delete' => '<a href="' . esc_url( _ww_forms_entries_action_url( 'delete', array( 'id' => (string) $item->id ) + $keep ) ) . '" onclick="' . esc_attr( 'return confirm(' . wp_json_encode( __( 'Deze inzending definitief verwijderen?', 'webwerckt-base' ) ) . ');' ) . '">' . esc_html__( 'Verwijderen', 'webwerckt-base' ) . '</a>',
		);
		$form_id = (int) $item->form_id;
		if ( ! isset( $this->pdf_enabled[ $form_id ] ) ) {
			$this->pdf_enabled[ $form_id ] = _ww_form_pdf_enabled( $form_id );
		}
		if ( $this->pdf_enabled[ $form_id ] ) {
			$pdf     = array( 'pdf' => '<a href="' . esc_url( _ww_forms_entries_action_url( 'pdf', array( 'id' => (string) $item->id ) + $keep ) ) . '">' . esc_html__( 'PDF downloaden', 'webwerckt-base' ) . '</a>' );
			$actions = array_slice( $actions, 0, 1, true ) + $pdf + array_slice( $actions, 1, null, true );
		}
		return $link . $this->row_actions( $actions );
	}

	/**
	 * De titel van het formulier waarop is ingezonden.
	 *
	 * @param object $item Inzending.
	 */
	protected function column_form( $item ): string {
		$title = (string) get_the_title( (int) $item->form_id );
		return '' === $title ? '&mdash;' : esc_html( $title );
	}

	/**
	 * De taal van het formulier waarop is ingezonden (de taalcode, zoals de kolom Taal in de berichtenlijst).
	 *
	 * @param object $item Inzending.
	 */
	protected function column_language( $item ): string {
		$lang = _ww_post_language( (int) $item->form_id );
		return '' === $lang ? '&mdash;' : esc_html( $lang );
	}

	/**
	 * De tekst van de eerste twee velden, hoogstens 80 tekens.
	 *
	 * @param object $item Inzending.
	 */
	protected function column_summary( $item ): string {
		$summary = _ww_form_entries_summary( (array) $item->fields );
		return '' === $summary ? '&mdash;' : esc_html( $summary );
	}

	/**
	 * De pagina waarop is ingevuld.
	 *
	 * @param object $item Inzending.
	 */
	protected function column_page( $item ): string {
		$url = (string) $item->page_url;
		return '' === $url ? '&mdash;' : '<a href="' . esc_url( $url ) . '">' . esc_html( $url ) . '</a>';
	}

	/**
	 * De uitkomst van de reCAPTCHA-controle; een streepje als er geen controle was.
	 *
	 * @param object $item Inzending.
	 */
	protected function column_recaptcha( $item ): string {
		$label = _ww_form_recaptcha_label( (string) $item->recaptcha );
		return '' === $label ? '&mdash;' : esc_html( $label );
	}

	/**
	 * Een waarschuwing als een mail mislukte, anders of de mail ging.
	 *
	 * @param object $item Inzending.
	 */
	protected function column_mail( $item ): string {
		$status = (string) $item->mail_status;
		if ( str_contains( $status, 'failed' ) ) {
			return '<span style="color:#b32d2e"><span class="dashicons dashicons-warning" aria-hidden="true"></span> ' . esc_html__( 'Mislukt', 'webwerckt-base' ) . '</span>';
		}
		return str_contains( $status, 'sent' ) ? esc_html__( 'Verstuurd', 'webwerckt-base' ) : '&mdash;';
	}
}
