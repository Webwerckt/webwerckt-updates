<?php
/**
 * Inzendingen van formulieren (beslissing 0032): tabel, opslaan, opvragen, tellen en opruimen.
 *
 * Eén eigen tabel {prefix}ww_form_entries. Het schema wordt bij admin_init en na een themawissel aangelegd, net als bij
 * redirects; aan de voorkant controleert het thema alleen de optie ww_forms_db_version, nooit de database zelf. Tijden
 * staan in UTC. Een dagelijkse cron ruimt inzendingen op volgens de bewaartermijn van elk formulier.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const WW_FORMS_DB_VERSION          = '2';
const WW_FORM_ENTRIES_CLEANUP_HOOK = 'ww_form_entries_cleanup';
const WW_FORM_ENTRIES_NEW_TRANSIENT = 'ww_form_entries_new';

/**
 * Naam van de tabel met inzendingen.
 */
function _ww_form_entries_table(): string {
	global $wpdb;
	return $wpdb->prefix . 'ww_form_entries';
}

/**
 * Legt de tabel aan (of werkt hem bij) en bewaart de schemaversie.
 */
function _ww_forms_install(): void {
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';

	dbDelta(
		'CREATE TABLE ' . _ww_form_entries_table() . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  form_id bigint(20) unsigned NOT NULL,
  created datetime NOT NULL,
  fields longtext NOT NULL,
  page_url varchar(2048) NOT NULL DEFAULT '',
  status varchar(10) NOT NULL DEFAULT 'new',
  mail_status varchar(40) NOT NULL DEFAULT '',
  recaptcha varchar(10) NOT NULL DEFAULT 'off',
  PRIMARY KEY  (id),
  KEY form_id (form_id),
  KEY created (created),
  KEY form_created (form_id,created)
) " . $wpdb->get_charset_collate() . ';'
	);

	// Alleen als de tabel er echt is, is het schema klaar. Een SELECT in plaats van SHOW TABLES: die laat tijdelijke tabellen (de testsuite) niet zien.
	$suppressed = $wpdb->suppress_errors( true );
	$complete   = false !== $wpdb->query( 'SELECT 1 FROM ' . _ww_form_entries_table() . ' LIMIT 1' ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_form_entries_table().
	$wpdb->suppress_errors( $suppressed );
	if ( ! $complete ) {
		return;
	}
	// De kolom van schema 2 moet er ook echt zijn (een ALTER kan mislukken, bijvoorbeeld zonder rechten).
	$suppressed = $wpdb->suppress_errors( true );
	$columns    = false !== $wpdb->query( 'SELECT recaptcha FROM ' . _ww_form_entries_table() . ' LIMIT 0' ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_form_entries_table().
	$wpdb->suppress_errors( $suppressed );
	if ( ! $columns ) {
		error_log( 'webwerckt-base: de kolom recaptcha ontbreekt in ' . _ww_form_entries_table() . '; het schema van de inzendingen is niet bijgewerkt.' ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		return;
	}

	update_option( 'ww_forms_db_version', WW_FORMS_DB_VERSION, true );
	wp_set_option_autoload( 'ww_forms_db_version', true );
}

/**
 * Is de tabel aangelegd voor deze schemaversie? Leest alleen de optie.
 */
function _ww_forms_ready(): bool {
	return WW_FORMS_DB_VERSION === (string) get_option( 'ww_forms_db_version' );
}

add_action(
	'admin_init',
	static function (): void {
		if ( ! _ww_forms_ready() ) {
			_ww_forms_install();
		}
	}
);
add_action( 'after_switch_theme', '_ww_forms_install' );

/**
 * Werkt een bestaande, oudere tabel bij op de eerste gewone aanvraag na een update, zodat opslaan niet wacht tot er
 * iemand in het beheer komt. Een verse installatie (optie leeg) blijft op admin_init en after_switch_theme.
 */
function _ww_forms_maybe_upgrade(): void {
	$version = (string) get_option( 'ww_forms_db_version' );
	if ( '' !== $version && WW_FORMS_DB_VERSION !== $version ) {
		_ww_forms_install();
	}
}
add_action( 'init', '_ww_forms_maybe_upgrade' );

/**
 * Na elke wijziging van inzendingen: het aantal nieuwe (transient) en de aantallen per formulier (objectcache) weg.
 */
function _ww_form_entries_changed(): void {
	delete_transient( WW_FORM_ENTRIES_NEW_TRANSIENT );
	wp_cache_delete( 'counts_by_form', 'ww_forms_list' );
}

/**
 * Bewaart een inzending en geeft het ID terug, of 0 als de tabel ontbreekt of het opslaan mislukt.
 *
 * @param int                                                                                   $form_id   Het formulier (de taalversie waarop is ingezonden).
 * @param array<string,array{label:string,type:string,value:mixed,display:string,step?:string,hidden?:true}> $fields    Velden in de volgorde van het formulier.
 * @param string                                                                                $page_url  Pagina waarop is ingevuld, zonder query-string.
 * @param string                                                                                $status    Alleen new of spam; anders new.
 * @param string                                                                                $recaptcha Uitkomst van reCAPTCHA: pass, spam, none of off; anders off.
 */
function _ww_form_entry_insert( int $form_id, array $fields, string $page_url, string $status = 'new', string $recaptcha = 'off' ): int {
	global $wpdb;
	$status    = in_array( $status, array( 'new', 'spam' ), true ) ? $status : 'new';
	$recaptcha = in_array( $recaptcha, array( 'pass', 'spam', 'none', 'off' ), true ) ? $recaptcha : 'off';
	if ( ! _ww_forms_ready() ) {
		return 0;
	}
	$json = wp_json_encode( $fields, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
	if ( false === $json ) {
		return 0;
	}
	$inserted = $wpdb->insert(
		_ww_form_entries_table(),
		array(
			'form_id'     => $form_id,
			'created'     => gmdate( 'Y-m-d H:i:s' ),
			'fields'      => $json,
			'page_url'    => substr( $page_url, 0, 2048 ),
			'status'      => $status,
			'mail_status' => '',
			'recaptcha'   => $recaptcha,
		),
		array( '%d', '%s', '%s', '%s', '%s', '%s', '%s' )
	);
	if ( ! $inserted ) {
		return 0;
	}
	_ww_form_entries_changed();
	return (int) $wpdb->insert_id;
}

/**
 * Schrijft de velden van een inzending opnieuw (zelfde JSON-vlaggen als bij het opslaan). Geeft false als dat niet lukt.
 *
 * @param int                                                                                   $id     Inzending.
 * @param array<string,array{label:string,type:string,value:mixed,display:string,step?:string,hidden?:true}> $fields Velden in de volgorde van het formulier.
 */
function _ww_form_entry_update_fields( int $id, array $fields ): bool {
	global $wpdb;
	if ( $id < 1 || ! _ww_forms_ready() ) {
		return false;
	}
	$json = wp_json_encode( $fields, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
	if ( false === $json ) {
		return false;
	}
	return false !== $wpdb->update( _ww_form_entries_table(), array( 'fields' => $json ), array( 'id' => $id ), array( '%s' ), array( '%d' ) );
}

/**
 * Bewaart per mail wat er gebeurde: array( 'notify' => 'sent', 'confirm' => 'off' ) wordt notify:sent,confirm:off.
 *
 * @param int                  $id     Inzending.
 * @param array<string,string> $status Per mail sent, failed of off.
 */
function _ww_form_entry_set_mail_status( int $id, array $status ): void {
	global $wpdb;
	if ( ! _ww_forms_ready() ) {
		return;
	}
	$parts = array();
	foreach ( $status as $mail => $state ) {
		$parts[] = $mail . ':' . $state;
	}
	$wpdb->update( _ww_form_entries_table(), array( 'mail_status' => substr( implode( ',', $parts ), 0, 40 ) ), array( 'id' => $id ), array( '%s' ), array( '%d' ) );
}

/**
 * Zet de JSON-kolom van een rij om naar een array.
 *
 * @param object $row Rij uit de tabel.
 */
function _ww_form_entry_decode( object $row ): object {
	$decoded     = json_decode( (string) $row->fields, true );
	$row->fields = is_array( $decoded ) ? $decoded : array();
	return $row;
}

/**
 * Eén inzending, met de velden als array, of null.
 */
function _ww_form_entry_get( int $id ): ?object {
	global $wpdb;
	if ( ! _ww_forms_ready() ) {
		return null;
	}
	$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . _ww_form_entries_table() . ' WHERE id = %d', $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_form_entries_table().
	return $row ? _ww_form_entry_decode( $row ) : null;
}

/**
 * Het deel van de WHERE-voorwaarde voor de formulieren (form_ids gaat voor form_id), zonder status of zoekterm.
 *
 * @param array{form_id?:int,form_ids?:int[]} $args Filters.
 * @return array{0:list<string>,1:array<int,int|string>} Voorwaarden (altijd minstens 1=1) en de waarden voor prepare().
 */
function _ww_form_entries_form_where( array $args ): array {
	$where    = array( '1=1' );
	$values   = array();
	$form_ids = array_values( array_unique( array_filter( array_map( 'absint', (array) ( $args['form_ids'] ?? array() ) ) ) ) );
	if ( array() !== $form_ids ) {
		$where[] = 'form_id IN (' . implode( ',', array_fill( 0, count( $form_ids ), '%d' ) ) . ')';
		$values  = array_merge( $values, $form_ids );
	} elseif ( ! empty( $args['form_id'] ) ) {
		$where[]  = 'form_id = %d';
		$values[] = (int) $args['form_id'];
	}
	return array( $where, $values );
}

/**
 * De WHERE-voorwaarde en de waarden voor de filters van _ww_form_entries_query() en _ww_form_entry_neighbours().
 *
 * @param array{form_id?:int,form_ids?:int[],status?:string,search?:string} $args Filters.
 * @return array{0:string,1:array<int,int|string>} Voorwaarde (altijd gevuld) en de waarden voor prepare().
 */
function _ww_form_entries_where( array $args ): array {
	global $wpdb;
	[ $where, $values ] = _ww_form_entries_form_where( $args );
	if ( ! empty( $args['status'] ) ) {
		$where[]  = 'status = %s';
		$values[] = (string) $args['status'];
	} else {
		$where[] = "status <> 'spam'";
	}
	if ( isset( $args['search'] ) && '' !== (string) $args['search'] ) {
		$where[]  = 'fields LIKE %s';
		$values[] = '%' . $wpdb->esc_like( (string) $args['search'] ) . '%';
	}
	return array( implode( ' AND ', $where ), $values );
}

/**
 * De filter op formulieren voor _ww_form_entries_query() en _ww_form_entry_neighbours(): de vertaalgroep van het
 * gekozen formulier (met Meertalig actief), anders het formulier zelf.
 *
 * @param int $form_id Gekozen formulier, 0 voor alle.
 * @return array{form_ids?:int[],form_id?:int}
 */
function _ww_form_entries_form_filter( int $form_id ): array {
	if ( $form_id > 0 && _ww_languages_active() ) {
		return array( 'form_ids' => _ww_form_group_ids( $form_id ) );
	}
	return array( 'form_id' => $form_id );
}

/**
 * Inzendingen opvragen, nieuwste eerst.
 *
 * Zonder status komt alles behalve spam; spam alleen met status spam. Met form_ids (een vertaalgroep, beslissing 0043)
 * de inzendingen van al die formulieren; form_ids gaat voor form_id.
 *
 * @param array{form_id?:int,form_ids?:int[],status?:string,search?:string,page?:int,per_page?:int} $args Filters; per_page 1 tot 500.
 * @return array{items: object[], total: int}
 */
function _ww_form_entries_query( array $args ): array {
	global $wpdb;
	$empty = array(
		'items' => array(),
		'total' => 0,
	);
	if ( ! _ww_forms_ready() ) {
		return $empty;
	}
	$table    = _ww_form_entries_table();
	$per_page = max( 1, min( 500, (int) ( $args['per_page'] ?? 20 ) ) );
	$page     = max( 1, (int) ( $args['page'] ?? 1 ) );

	[ $clause, $values ] = _ww_form_entries_where( $args );

	$count_sql = "SELECT COUNT(*) FROM $table WHERE $clause";
	$total     = (int) ( $values ? $wpdb->get_var( $wpdb->prepare( $count_sql, $values ) ) : $wpdb->get_var( $count_sql ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- tabelnaam uit _ww_form_entries_table(), waarden via prepare.

	$list_values = array_merge( $values, array( $per_page, ( $page - 1 ) * $per_page ) );
	$rows        = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table WHERE $clause ORDER BY created DESC, id DESC LIMIT %d OFFSET %d", $list_values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- tabelnaam uit _ww_form_entries_table(), waarden via prepare.

	return array(
		'items' => array_map( '_ww_form_entry_decode', is_array( $rows ) ? $rows : array() ),
		'total' => $total,
	);
}

/**
 * Aantal inzendingen per status binnen de formulieren van de filter (zoals _ww_form_entries_query(), zonder zoekterm),
 * in één query. '' is alles behalve spam.
 *
 * @param array{form_id?:int,form_ids?:int[]} $args Filters.
 * @return array{'':int,new:int,read:int,spam:int}
 */
function _ww_form_entries_status_counts( array $args ): array {
	global $wpdb;
	$counts = array(
		''     => 0,
		'new'  => 0,
		'read' => 0,
		'spam' => 0,
	);
	if ( ! _ww_forms_ready() ) {
		return $counts;
	}
	[ $where, $values ] = _ww_form_entries_form_where( $args );

	$clause = implode( ' AND ', $where );
	$sql    = 'SELECT status, COUNT(*) AS total FROM ' . _ww_form_entries_table() . " WHERE $clause GROUP BY status";
	$rows   = $values ? $wpdb->get_results( $wpdb->prepare( $sql, $values ) ) : $wpdb->get_results( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- tabelnaam uit _ww_form_entries_table(), waarden via prepare.
	foreach ( is_array( $rows ) ? $rows : array() as $row ) {
		$status = (string) $row->status;
		$total  = (int) $row->total;
		if ( isset( $counts[ $status ] ) && '' !== $status ) {
			$counts[ $status ] += $total;
		}
		if ( 'spam' !== $status ) {
			$counts[''] += $total;
		}
	}
	return $counts;
}

/**
 * De buren van een inzending in de lijst (nieuwste eerst) binnen dezelfde filters: "prev" is de nieuwere, "next" de
 * oudere. Gelijke tijden volgen de id. Werkt ook als de inzending zelf niet meer onder het filter valt (zoals een
 * inzending die door het openen van gelezen is geworden). 0 betekent: geen buur.
 *
 * @param int                                                                $id   Inzending.
 * @param array{form_id?:int,form_ids?:int[],status?:string,search?:string} $args Filters, zoals _ww_form_entries_query().
 * @return array{prev:int,next:int}
 */
function _ww_form_entry_neighbours( int $id, array $args ): array {
	global $wpdb;
	$none = array(
		'prev' => 0,
		'next' => 0,
	);
	if ( ! _ww_forms_ready() ) {
		return $none;
	}
	$table   = _ww_form_entries_table();
	$created = $wpdb->get_var( $wpdb->prepare( "SELECT created FROM $table WHERE id = %d", $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_form_entries_table().
	if ( ! is_string( $created ) ) {
		return $none;
	}
	[ $clause, $values ] = _ww_form_entries_where( $args );

	$next = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $table WHERE $clause AND ( created < %s OR ( created = %s AND id < %d ) ) ORDER BY created DESC, id DESC LIMIT 1", array_merge( $values, array( $created, $created, $id ) ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- tabelnaam uit _ww_form_entries_table(), waarden via prepare.
	$prev = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $table WHERE $clause AND ( created > %s OR ( created = %s AND id > %d ) ) ORDER BY created ASC, id ASC LIMIT 1", array_merge( $values, array( $created, $created, $id ) ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- tabelnaam uit _ww_form_entries_table(), waarden via prepare.
	return array(
		'prev' => (int) $prev,
		'next' => (int) $next,
	);
}

/**
 * Zet de status (new, read of spam) van inzendingen. Geeft het aantal gewijzigde rijen terug.
 *
 * @param int[] $ids    Inzendingen.
 * @param string $status new, read of spam.
 */
function _ww_form_entries_set_status( array $ids, string $status ): int {
	global $wpdb;
	$ids = array_values( array_filter( array_map( 'absint', $ids ) ) );
	if ( ! $ids || ! _ww_forms_ready() || ! in_array( $status, array( 'new', 'read', 'spam' ), true ) ) {
		return 0;
	}
	$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
	$changed      = $wpdb->query( $wpdb->prepare( 'UPDATE ' . _ww_form_entries_table() . " SET status = %s WHERE id IN ($placeholders)", array_merge( array( $status ), $ids ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- tabelnaam uit _ww_form_entries_table(), placeholders voor de ID's.
	_ww_form_entries_changed();
	return (int) $changed;
}

/**
 * Verwijdert inzendingen. Geeft het aantal verwijderde rijen terug.
 *
 * @param int[] $ids Inzendingen.
 */
function _ww_form_entries_delete( array $ids ): int {
	global $wpdb;
	$ids = array_values( array_filter( array_map( 'absint', $ids ) ) );
	if ( ! $ids || ! _ww_forms_ready() ) {
		return 0;
	}
	// Eerst de bestanden, zolang de rijen nog zeggen bij welk formulier ze horen.
	_ww_form_delete_entry_files( $ids );
	$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
	$deleted      = $wpdb->query( $wpdb->prepare( 'DELETE FROM ' . _ww_form_entries_table() . " WHERE id IN ($placeholders)", $ids ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- tabelnaam uit _ww_form_entries_table(), placeholders voor de ID's.
	_ww_form_entries_changed();
	return (int) $deleted;
}

/**
 * Aantal inzendingen van één formulier.
 */
function _ww_form_entries_count( int $form_id ): int {
	global $wpdb;
	if ( ! _ww_forms_ready() ) {
		return 0;
	}
	return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . _ww_form_entries_table() . ' WHERE form_id = %d', $form_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_form_entries_table().
}

/**
 * Aantal inzendingen per formulier, zonder spam: alles en alleen de nieuwe. Eén query per verzoek (niet-blijvende
 * objectcache, geleegd bij elke wijziging van inzendingen). Zonder tabel een leeg array.
 *
 * @return array<int,array{all:int,new:int}>
 */
function _ww_form_entries_counts_by_form(): array {
	global $wpdb;
	if ( ! _ww_forms_ready() ) {
		return array();
	}
	$found  = false;
	$cached = wp_cache_get( 'counts_by_form', 'ww_forms_list', false, $found );
	if ( $found && is_array( $cached ) ) {
		return $cached;
	}
	$rows   = $wpdb->get_results( "SELECT form_id, COUNT(*) AS total, SUM(CASE WHEN status = 'new' THEN 1 ELSE 0 END) AS fresh FROM " . _ww_form_entries_table() . " WHERE status <> 'spam' GROUP BY form_id" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_form_entries_table(), geen invoer.
	$counts = array();
	foreach ( is_array( $rows ) ? $rows : array() as $row ) {
		$counts[ (int) $row->form_id ] = array(
			'all' => (int) $row->total,
			'new' => (int) $row->fresh,
		);
	}
	wp_cache_set( 'counts_by_form', $counts, 'ww_forms_list' );
	return $counts;
}

/**
 * Aantal nieuwe inzendingen over alle formulieren (voor het menu), bewaard in een transient dat bij elke wijziging
 * wordt geleegd.
 */
function _ww_form_entries_count_new(): int {
	global $wpdb;
	if ( ! _ww_forms_ready() ) {
		return 0;
	}
	$cached = get_transient( WW_FORM_ENTRIES_NEW_TRANSIENT );
	if ( false !== $cached ) {
		return (int) $cached;
	}
	$count = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . _ww_form_entries_table() . ' WHERE status = %s', 'new' ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_form_entries_table().
	set_transient( WW_FORM_ENTRIES_NEW_TRANSIENT, $count, DAY_IN_SECONDS );
	return $count;
}

/**
 * Na hoeveel dagen spam wordt verwijderd: het filter ww_form_spam_retention_days, 1 tot 365, standaard 30.
 */
function _ww_form_spam_retention_days(): int {
	return max( 1, min( 365, (int) apply_filters( 'ww_form_spam_retention_days', 30 ) ) );
}

/**
 * Verwijdert alle inzendingen die aan een voorwaarde voldoen, in porties van 500, via `_ww_form_entries_delete()` zodat
 * ook de bestanden meegaan.
 *
 * Een portie die niets verwijdert (de rijen gaan niet weg) stopt de lus: anders zou hij eindeloos draaien.
 *
 * @param string $where Een al voorbereide WHERE-voorwaarde (zonder het woord WHERE).
 */
function _ww_form_entries_delete_matching( string $where ): void {
	global $wpdb;
	$table = _ww_form_entries_table();
	do {
		$ids = $wpdb->get_col( "SELECT id FROM $table WHERE $where ORDER BY id ASC LIMIT 500" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_form_entries_table(), voorwaarde is al voorbereid.
		if ( ! is_array( $ids ) || ! $ids ) {
			return;
		}
		$deleted = _ww_form_entries_delete( array_map( 'intval', $ids ) );
	} while ( $deleted > 0 && count( $ids ) >= 500 );
}

/**
 * Ruimt op: per bestaand formulier (elke status, ook prullenbak) inzendingen ouder dan zijn eigen bewaartermijn, spam
 * na de spamtermijn en alle inzendingen van een formulier dat niet meer bestaat; daarna achtergebleven mappen met
 * bestanden. Bestanden gaan mee met hun inzending. Tijdelijke PDF-bestanden in `tmp/` van ouder dan een uur gaan ook weg
 * (achtergebleven als het weggooien na de mails mislukte).
 */
function _ww_form_entries_cleanup(): void {
	global $wpdb;
	if ( ! _ww_forms_ready() ) {
		return;
	}
	$found = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_type = %s", WW_FORM_POST_TYPE ) );
	// Mislukt het opvragen van de formulieren, dan is "geen formulieren" geen waarheid: niets verwijderen.
	if ( ! is_array( $found ) || '' !== $wpdb->last_error ) {
		return;
	}
	$form_ids = array_map( 'intval', $found );
	// Posts en metadata van alle formulieren in één keer, niet per formulier in _ww_form_config().
	$prime = array_values( array_unique( array_filter( $form_ids, static fn( int $id ): bool => $id > 0 ) ) );
	if ( $prime ) {
		_prime_post_caches( $prime, false, true );
	}

	foreach ( $form_ids as $form_id ) {
		$config = _ww_form_config( $form_id );
		if ( null === $config ) {
			continue;
		}
		$months = max( 1, (int) ( $config['storage']['retention_months'] ?? 12 ) );
		$cutoff = ( new DateTimeImmutable( 'now', new DateTimeZone( 'UTC' ) ) )->modify( "-{$months} months" )->format( 'Y-m-d H:i:s' );
		_ww_form_entries_delete_matching( $wpdb->prepare( 'form_id = %d AND created < %s', $form_id, $cutoff ) );
	}

	// Spam gaat sneller weg dan gewone inzendingen, ongeacht het formulier.
	$spam_cutoff = gmdate( 'Y-m-d H:i:s', time() - _ww_form_spam_retention_days() * DAY_IN_SECONDS );
	_ww_form_entries_delete_matching( $wpdb->prepare( "status = 'spam' AND created < %s", $spam_cutoff ) );

	if ( $form_ids ) {
		$placeholders = implode( ',', array_fill( 0, count( $form_ids ), '%d' ) );
		_ww_form_entries_delete_matching( $wpdb->prepare( "form_id NOT IN ($placeholders)", $form_ids ) ); // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- placeholders voor de ID's.
	} else {
		_ww_form_entries_delete_matching( '1 = 1' ); // Geen enkel formulier bestaat meer.
	}
	_ww_form_entries_changed();
	_ww_form_files_cleanup_orphans( 200 );
	_ww_form_pdf_tmp_cleanup();
}
add_action( WW_FORM_ENTRIES_CLEANUP_HOOK, '_ww_form_entries_cleanup' );

/**
 * Plant de dagelijkse opruiming in bij een adminbezoek.
 */
function _ww_form_entries_schedule(): void {
	if ( ! wp_next_scheduled( WW_FORM_ENTRIES_CLEANUP_HOOK ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', WW_FORM_ENTRIES_CLEANUP_HOOK );
	}
}
add_action( 'admin_init', '_ww_form_entries_schedule' );

/**
 * Haalt de opruiming weg bij een themawissel.
 */
function _ww_form_entries_unschedule(): void {
	wp_clear_scheduled_hook( WW_FORM_ENTRIES_CLEANUP_HOOK );
}
add_action( 'switch_theme', '_ww_form_entries_unschedule' );

/**
 * Bij definitief verwijderen van een formulier gaan zijn inzendingen mee. De prullenbak doet dat niet.
 *
 * @param int $post_id Post die wordt verwijderd.
 */
function _ww_form_entries_on_delete_post( $post_id ): void {
	global $wpdb;
	if ( WW_FORM_POST_TYPE !== get_post_type( $post_id ) || ! _ww_forms_ready() ) {
		return;
	}
	$form_id = (int) $post_id;
	// De bestanden van alle inzendingen staan onder {base}/{form_id}; die map gaat hieronder in zijn geheel weg.
	$wpdb->delete( _ww_form_entries_table(), array( 'form_id' => $form_id ), array( '%d' ) );
	$base = _ww_form_files_base();
	if ( '' !== $base ) {
		_ww_form_delete_dir( $base . '/' . $form_id );
	}
	_ww_form_entries_changed();
}
add_action( 'before_delete_post', '_ww_form_entries_on_delete_post' );

/**
 * Verwijdert de tabel, de schemaversie en de geplande opruiming: voor wie het thema voorgoed van een site haalt.
 */
function _ww_forms_drop_tables(): void {
	global $wpdb;
	$wpdb->query( 'DROP TABLE IF EXISTS ' . _ww_form_entries_table() ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.SchemaChange -- tabelnaam uit _ww_form_entries_table().
	delete_option( 'ww_forms_db_version' );
	_ww_form_entries_changed();
	wp_clear_scheduled_hook( WW_FORM_ENTRIES_CLEANUP_HOOK );
	// De hele map met bestanden en de optie die zijn naam bewaart.
	$base = _ww_form_files_base();
	if ( '' !== $base ) {
		_ww_form_delete_dir( $base );
	}
	delete_option( WW_FORMS_OPT_UPLOAD_DIR );
}

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	/**
	 * Commando's voor de formulieren van het thema.
	 */
	class WW_Forms_CLI_Command {

		/**
		 * Verwijdert de tabel met inzendingen, de schemaversie en de geplande opruiming.
		 *
		 * ## OPTIONS
		 *
		 * [--yes]
		 * : Niet om bevestiging vragen.
		 *
		 * ## EXAMPLES
		 *
		 *     wp ww forms drop-tables --yes
		 *
		 * @subcommand drop-tables
		 *
		 * @param array<int,string>    $args       Positionele argumenten.
		 * @param array<string,string> $assoc_args Benoemde argumenten.
		 */
		public function drop_tables( $args, $assoc_args ): void {
			WP_CLI::confirm( 'Alle inzendingen van formulieren op deze site verwijderen? Dit kan niet ongedaan worden gemaakt.', $assoc_args );
			_ww_forms_drop_tables();
			WP_CLI::success( 'De tabel ww_form_entries is verwijderd.' );
		}
	}
	WP_CLI::add_command( 'ww forms', 'WW_Forms_CLI_Command' );
}

/*
 * Privacy (AVG): de exporter en de eraser van WordPress zoeken inzendingen op e-mailadres.
 */

/**
 * Een stap van 100 inzendingen waarin het adres voorkomt, op ID oplopend, zodat nieuwe inzendingen geen pagina's
 * verschuiven. LIKE op de JSON-kolom met esc_like(): _ en % kunnen in een adres staan.
 *
 * @return object[] Rijen met de velden als array.
 */
function _ww_form_privacy_candidates( string $email, int $offset = 0, int $after_id = 0 ): array {
	global $wpdb;
	if ( ! _ww_forms_ready() ) {
		return array();
	}
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . _ww_form_entries_table() . ' WHERE fields LIKE %s AND id > %d ORDER BY id ASC LIMIT 100 OFFSET %d', '%' . $wpdb->esc_like( $email ) . '%', $after_id, $offset ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_form_entries_table().
	return array_map( '_ww_form_entry_decode', is_array( $rows ) ? $rows : array() );
}

/**
 * Staat het adres (hoofdletters genegeerd) als waarde in een veld van type line van deze inzending?
 */
function _ww_form_privacy_matches( object $entry, string $email ): bool {
	foreach ( (array) $entry->fields as $field ) {
		if ( ! is_array( $field ) || 'line' !== ( $field['type'] ?? '' ) || ! is_string( $field['value'] ?? null ) ) {
			continue;
		}
		$value = trim( $field['value'] );
		if ( is_email( $value ) && strtolower( $value ) === $email ) {
			return true;
		}
	}
	return false;
}

/**
 * Exporter voor de privacytools: de inzendingen van dit adres, 100 per stap.
 *
 * @return array{data: list<array<string,mixed>>, done: bool}
 */
function _ww_form_privacy_exporter( string $email, int $page = 1 ): array {
	$email = strtolower( trim( $email ) );
	$page  = max( 1, $page );
	$rows  = '' === $email ? array() : _ww_form_privacy_candidates( $email, ( $page - 1 ) * 100 );
	$data  = array();
	foreach ( $rows as $entry ) {
		if ( ! _ww_form_privacy_matches( $entry, $email ) ) {
			continue;
		}
		$items = array(
			array(
				'name'  => __( 'Datum', 'webwerckt-base' ),
				'value' => get_date_from_gmt( (string) $entry->created, 'Y-m-d H:i' ),
			),
			array(
				'name'  => __( 'Formulier', 'webwerckt-base' ),
				'value' => get_the_title( (int) $entry->form_id ),
			),
			array(
				'name'  => __( 'Pagina', 'webwerckt-base' ),
				'value' => (string) $entry->page_url,
			),
		);
		foreach ( (array) $entry->fields as $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}
			// Een bestandsveld: alleen de namen met grootte (`display`), nooit de opgeslagen metadata.
			$shown   = 'file' === ( $field['type'] ?? '' ) ? ( $field['display'] ?? '' ) : ( $field['display'] ?? ( $field['value'] ?? '' ) );
			$items[] = array(
				'name'  => _ww_form_string( $field['label'] ?? '' ),
				'value' => _ww_form_string( $shown ),
			);
		}
		$data[] = array(
			'group_id'    => 'ww-form-entries',
			'group_label' => __( 'Formulierinzendingen', 'webwerckt-base' ),
			'item_id'     => 'ww-form-entry-' . (int) $entry->id,
			'data'        => $items,
		);
	}
	return array(
		'data' => $data,
		'done' => count( $rows ) < 100,
	);
}

/**
 * Eraser voor de privacytools: verwijdert de inzendingen van dit adres helemaal.
 *
 * Wissen verschuift de posities in de resultaten, dus werkt één aanroep alle stappen van 100 af (met het laatste ID
 * als beginpunt in plaats van een offset) en meldt dan klaar: er wordt niets overgeslagen.
 *
 * @return array{items_removed: bool, items_retained: bool, messages: list<string>, done: bool}
 */
function _ww_form_privacy_eraser( string $email, int $page = 1 ): array {
	$email   = strtolower( trim( $email ) );
	$removed = 0;
	$last    = 0;
	while ( '' !== $email ) {
		$rows = _ww_form_privacy_candidates( $email, 0, $last );
		$ids  = array();
		foreach ( $rows as $entry ) {
			$last = max( $last, (int) $entry->id );
			if ( _ww_form_privacy_matches( $entry, $email ) ) {
				$ids[] = (int) $entry->id;
			}
		}
		$removed += _ww_form_entries_delete( $ids );
		if ( count( $rows ) < 100 ) {
			break;
		}
	}
	return array(
		'items_removed'  => $removed > 0,
		'items_retained' => false,
		'messages'       => array(),
		'done'           => true,
	);
}

add_filter(
	'wp_privacy_personal_data_exporters',
	static function ( $exporters ) {
		$exporters                         = is_array( $exporters ) ? $exporters : array();
		$exporters['webwerckt-base-forms'] = array(
			'exporter_friendly_name' => __( 'Formulierinzendingen', 'webwerckt-base' ),
			'callback'               => '_ww_form_privacy_exporter',
		);
		return $exporters;
	}
);
add_filter(
	'wp_privacy_personal_data_erasers',
	static function ( $erasers ) {
		$erasers                         = is_array( $erasers ) ? $erasers : array();
		$erasers['webwerckt-base-forms'] = array(
			'eraser_friendly_name' => __( 'Formulierinzendingen', 'webwerckt-base' ),
			'callback'             => '_ww_form_privacy_eraser',
		);
		return $erasers;
	}
);
