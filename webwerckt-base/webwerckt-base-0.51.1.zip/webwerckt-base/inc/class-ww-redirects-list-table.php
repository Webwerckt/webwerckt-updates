<?php
/**
 * Tabel met de redirects op het scherm Redirects (inc/redirects-admin.php). Wordt pas geladen als dat
 * scherm wordt getoond, na WP_List_Table.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * De redirects: oude en nieuwe URL met de acties Bewerken, Testen en Verwijderen, soort, gebruik en herkomst.
 */
class WW_Redirects_List_Table extends WP_List_Table {

	public function __construct() {
		parent::__construct(
			array(
				'singular' => 'redirect',
				'plural'   => 'redirects',
				'ajax'     => false,
			)
		);
	}

	/**
	 * @return array<string,string>
	 */
	public function get_columns() {
		return array(
			'cb'       => '<input type="checkbox">',
			'source'   => __( 'Oude URL → nieuwe URL', 'webwerckt-base' ),
			'status'   => __( 'Soort', 'webwerckt-base' ),
			'hits'     => __( 'Gebruikt', 'webwerckt-base' ),
			'last_hit' => __( 'Laatst gebruikt', 'webwerckt-base' ),
			'origin'   => __( 'Herkomst', 'webwerckt-base' ),
		);
	}

	/**
	 * De gekozen herkomst (?origin=), of '' voor alles.
	 */
	public static function current_origin(): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen filteren.
		$origin = isset( $_GET['origin'] ) ? sanitize_key( _ww_data_to_string( wp_unslash( $_GET['origin'] ) ) ) : '';
		return in_array( $origin, array( 'manual', 'import', 'slug' ), true ) ? $origin : '';
	}

	/**
	 * Het id uit ?delete= als die regel op deze pagina van de lijst staat, anders 0.
	 */
	public function confirm_id(): int {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen een bevestiging tonen; verwijderen gaat via een formulier met nonce.
		$id = isset( $_GET['delete'] ) ? absint( _ww_data_to_string( wp_unslash( $_GET['delete'] ) ) ) : 0;
		if ( $id < 1 ) {
			return 0;
		}
		foreach ( (array) $this->items as $item ) {
			if ( (int) $item->id === $id ) {
				return $id;
			}
		}
		return 0;
	}

	/**
	 * De weergaven boven de tabel: Alle, Handmatig, Import en Gewijzigde URL, met hun aantal.
	 *
	 * @return array<string,string>
	 */
	protected function get_views() {
		$counts  = _ww_redirects_admin_counts();
		$current = self::current_origin();
		$views   = array(
			''       => array( __( 'Alle', 'webwerckt-base' ), $counts['total'] ),
			'manual' => array( __( 'Handmatig', 'webwerckt-base' ), $counts['manual'] ),
			'import' => array( __( 'Import', 'webwerckt-base' ), $counts['import'] ),
			'slug'   => array( __( 'Gewijzigde URL', 'webwerckt-base' ), $counts['slug'] ),
		);
		$links   = array();
		foreach ( $views as $origin => $view ) {
			$url = _ww_redirects_admin_url( '' === $origin ? array() : array( 'origin' => $origin ) );
			$key = '' === $origin ? 'all' : $origin;

			$links[ $key ] = '<a href="' . esc_url( $url ) . '"' . ( $origin === $current ? ' class="current" aria-current="page"' : '' ) . '>' . esc_html( $view[0] ) . ' <span class="count">(' . esc_html( number_format_i18n( $view[1] ) ) . ')</span></a>';
		}
		return $links;
	}

	/**
	 * @return array<string,array{0:string,1:bool}>
	 */
	protected function get_sortable_columns() {
		return array(
			'source'   => array( 'source', false ),
			'hits'     => array( 'hits', true ),
			'last_hit' => array( 'last_hit', true ),
		);
	}

	/**
	 * @return array<string,string>
	 */
	protected function get_bulk_actions() {
		return array( 'bulk-delete' => __( 'Verwijderen', 'webwerckt-base' ) );
	}

	/**
	 * Zoekt, filtert, sorteert en pagineert via _ww_redirects_admin_list().
	 */
	public function prepare_items(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- alleen zoeken, filteren en sorteren.
		$search  = isset( $_GET['s'] ) ? sanitize_text_field( _ww_data_to_string( wp_unslash( $_GET['s'] ) ) ) : '';
		$origin  = self::current_origin();
		$orderby = isset( $_GET['orderby'] ) ? sanitize_key( _ww_data_to_string( $_GET['orderby'] ) ) : 'source';
		$order   = isset( $_GET['order'] ) ? sanitize_key( _ww_data_to_string( $_GET['order'] ) ) : 'asc';
		// phpcs:enable
		$result = _ww_redirects_admin_list( $search, $origin, $orderby, $order, $this->get_pagenum() );

		$this->_column_headers = array( $this->get_columns(), array(), $this->get_sortable_columns(), 'source' );
		$this->set_pagination_args(
			array(
				'total_items' => $result['total'],
				'per_page'    => WW_REDIRECTS_PER_PAGE,
			)
		);
		$this->items = $result['items'];

		// De waarschuwingen per rij (_ww_redirects_warnings) lezen twee transients; die komen in één query uit de database.
		if ( array() !== $this->items && ! wp_using_ext_object_cache() ) {
			$options = array();
			foreach ( $this->items as $item ) {
				foreach ( array( 'ww_redirect_warn_', 'ww_redirect_warn_posts_' ) as $prefix ) {
					$options[] = '_transient_' . $prefix . (int) $item->id;
					$options[] = '_transient_timeout_' . $prefix . (int) $item->id;
				}
			}
			wp_prime_option_caches( $options );
		}
	}

	/**
	 * Tekst als er geen regels zijn.
	 */
	public function no_items(): void {
		esc_html_e( 'Er zijn geen redirects.', 'webwerckt-base' );
	}

	/**
	 * Selectievakje voor de bulkactie.
	 *
	 * @param object $item Regel.
	 */
	protected function column_cb( $item ): string {
		return '<input type="checkbox" name="ids[]" value="' . esc_attr( (string) $item->id ) . '">';
	}

	/**
	 * Een rij, of op de plek van ?delete= de vraag of de regel weg mag. Het formulier zelf staat na de tabel
	 * (_ww_redirects_render_list): de tabel staat al in het bulkformulier, en een formulier in een formulier laat de
	 * browser weg.
	 *
	 * @param object $item Regel.
	 */
	public function single_row( $item ): void {
		if ( (int) $item->id !== $this->confirm_id() ) {
			parent::single_row( $item );
			return;
		}
		$hits     = (int) $item->hits;
		$question = sprintf(
			/* translators: %s: de oude URL. */
			esc_html__( '%s verwijderen? Bezoekers van deze URL zien daarna weer "niet gevonden".', 'webwerckt-base' ),
			'<strong>' . esc_html( (string) $item->source ) . '</strong>'
		);
		if ( $hits > 0 ) {
			$question .= ' ' . esc_html(
				sprintf(
					/* translators: %s: aantal keer. */
					_n( 'Hij is %s keer gebruikt.', 'Hij is %s keer gebruikt.', $hits, 'webwerckt-base' ),
					number_format_i18n( $hits )
				)
			);
		}
		echo '<tr class="ww-redirects-confirm-row"><td colspan="' . esc_attr( (string) $this->get_column_count() ) . '" class="column-primary">';
		echo '<p>' . $question . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hierboven geëscapet.
		echo '<p><button type="submit" form="ww-redirects-delete" class="button button-primary">' . esc_html__( 'Ja, verwijderen', 'webwerckt-base' ) . '</button> ';
		echo '<a class="button-link" href="' . esc_url( _ww_redirects_admin_url( _ww_redirects_list_args() ) ) . '">' . esc_html__( 'Annuleren', 'webwerckt-base' ) . '</a></p>';
		echo '</td></tr>';
	}

	/**
	 * De oude URL als link naar Bewerken, de nieuwe URL eronder, de waarschuwingen, en de rij-acties.
	 *
	 * @param object $item Regel.
	 */
	protected function column_source( $item ): string {
		$edit    = _ww_redirects_admin_url(
			array(
				'tab'  => 'redirects',
				'edit' => (string) $item->id,
			)
		);
		$delete  = _ww_redirects_admin_url( array( 'delete' => (string) $item->id ) + _ww_redirects_list_args() );
		$actions = array(
			'edit'   => '<a href="' . esc_url( $edit ) . '">' . esc_html__( 'Bewerken', 'webwerckt-base' ) . '</a>',
			'test'   => '<a href="' . esc_url( home_url( (string) $item->source ) ) . '" target="_blank" rel="noopener">' . esc_html__( 'Testen', 'webwerckt-base' ) . '<span class="screen-reader-text"> ' . esc_html__( '(opent in een nieuw tabblad)', 'webwerckt-base' ) . '</span></a>',
			'delete' => '<a class="submitdelete" href="' . esc_url( $delete ) . '">' . esc_html__( 'Verwijderen', 'webwerckt-base' ) . '</a>',
		);

		$target = '' === (string) $item->target
			? '<em class="ww-redirects-gone">' . esc_html__( 'geen doel, de pagina is weg', 'webwerckt-base' ) . '</em>'
			: '<span class="ww-redirects-target">' . esc_html( (string) $item->target ) . '</span>';

		$html  = '<strong><a class="row-title" href="' . esc_url( $edit ) . '">' . esc_html( (string) $item->source ) . '</a></strong>';
		$html .= '<div class="ww-redirects-to"><span class="dashicons dashicons-arrow-right-alt" aria-hidden="true"></span><span class="screen-reader-text">' . esc_html__( 'naar', 'webwerckt-base' ) . ' </span>' . $target . '</div>';
		foreach ( _ww_redirects_warnings( $item ) as $warning ) {
			$html .= '<div class="ww-redirects-warning">' . esc_html( $warning ) . '</div>';
		}
		return $html . $this->row_actions( $actions );
	}

	/**
	 * De soort als label (301, 302 of 410), met "en alles eronder" bij een voorvoegsel.
	 *
	 * @param object $item Regel.
	 */
	protected function column_status( $item ): string {
		$status = (int) $item->status;
		$labels = array(
			301 => __( 'Permanent (301)', 'webwerckt-base' ),
			302 => __( 'Tijdelijk (302)', 'webwerckt-base' ),
			410 => __( 'Verwijderd (410)', 'webwerckt-base' ),
		);
		$html   = '<span class="ww-redirects-kind ww-redirects-kind--' . esc_attr( (string) $status ) . '">' . esc_html( $labels[ $status ] ?? (string) $status ) . '</span>';
		if ( 'prefix' === $item->match_type ) {
			$html .= '<span class="ww-redirects-below">' . esc_html__( 'en alles eronder', 'webwerckt-base' ) . '</span>';
		}
		return $html;
	}

	/**
	 * De herkomst, bij een gewijzigde URL met een link naar het bericht.
	 *
	 * @param object $item Regel.
	 */
	protected function column_origin( $item ): string {
		if ( 'slug' === $item->origin ) {
			$label = esc_html__( 'Gewijzigde URL', 'webwerckt-base' );
			$link  = (int) $item->post_id > 0 ? get_edit_post_link( (int) $item->post_id ) : null;
			return null === $link || '' === $link ? $label : '<a href="' . esc_url( $link ) . '">' . $label . '</a>';
		}
		return esc_html( 'import' === $item->origin ? __( 'Import', 'webwerckt-base' ) : __( 'Handmatig', 'webwerckt-base' ) );
	}

	/**
	 * Hoe vaak de regel is gebruikt.
	 *
	 * @param object $item Regel.
	 */
	protected function column_hits( $item ): string {
		$hits = (int) $item->hits;
		if ( 0 === $hits ) {
			return esc_html__( 'nog niet', 'webwerckt-base' );
		}
		return esc_html(
			sprintf(
				/* translators: %s: aantal keer. */
				_n( '%s keer', '%s keer', $hits, 'webwerckt-base' ),
				number_format_i18n( $hits )
			)
		);
	}

	/**
	 * Hoe lang geleden de regel voor het laatst werd gebruikt.
	 *
	 * @param object $item Regel.
	 */
	protected function column_last_hit( $item ): string {
		if ( empty( $item->last_hit ) ) {
			return '&mdash;';
		}
		$time = strtotime( $item->last_hit . ' UTC' );
		if ( false === $time ) {
			return '&mdash;';
		}
		return esc_html(
			sprintf(
				/* translators: %s: tijdsduur, zoals 5 minuten. */
				__( '%s geleden', 'webwerckt-base' ),
				human_time_diff( $time )
			)
		);
	}
}
