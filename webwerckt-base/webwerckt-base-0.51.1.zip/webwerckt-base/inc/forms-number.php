<?php
/**
 * Formulieren: het getalveld (spec formulieren-voorwaarden-berekening, deel 1).
 *
 * Een getal komt als tekst binnen, met een komma of een punt als decimaalteken. Genormaliseerd is het een string met
 * een punt, zonder duizendtallen, voorloopnullen of plusteken. Hoogstens 12 cijfers vóór en 6 na het decimaalteken,
 * zodat de stapcontrole met hele getallen altijd in een PHP-int past.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Leest een getal zoals een bezoeker of redacteur het typt.
 *
 * @param string $raw Invoer.
 * @return string|null Het genormaliseerde getal, '' bij lege invoer, null bij ongeldige invoer.
 */
function _ww_form_number_parse( string $raw ): ?string {
	$raw = preg_replace( '/\s+/u', '', $raw );
	if ( null === $raw || '' === $raw ) {
		return '';
	}
	if ( ! preg_match( '/^([+-]?)(\d{0,12})(?:[.,](\d{0,6}))?$/', $raw, $m ) ) {
		return null;
	}
	$int      = ltrim( $m[2], '0' );
	$decimals = rtrim( $m[3] ?? '', '0' );
	if ( '' === $m[2] && '' === ( $m[3] ?? '' ) ) {
		return null;
	}
	$number = ( '' === $int ? '0' : $int ) . ( '' !== $decimals ? '.' . $decimals : '' );
	return ( '-' === $m[1] && '0' !== $number ) ? '-' . $number : $number;
}

/**
 * Een float als tekst met zoveel decimalen als een double betrouwbaar bewaart: samen hoogstens 15 cijfers, waarvan
 * hoogstens 6 na de punt. Niet (string): dat geeft 1.0E-6 voor kleine getallen.
 *
 * @param float $value Getal.
 */
function _ww_form_number_float_text( float $value ): string {
	$int      = strlen( (string) abs( (int) $value ) );
	$decimals = min( 6, max( 0, 15 - $int ) );
	$text     = number_format( $value, $decimals, '.', '' );
	return false !== strpos( $text, '.' ) ? rtrim( rtrim( $text, '0' ), '.' ) : $text;
}

/**
 * Of een genormaliseerd getal exact als float te bewaren is: hoogstens 15 cijfers vóór en na de punt samen.
 *
 * @param string $number Genormaliseerd getal.
 */
function _ww_form_number_fits_float( string $number ): bool {
	return strlen( str_replace( array( '-', '.' ), '', $number ) ) <= 15;
}

/**
 * Een instelling van een getalveld (min, max, step) uit de configuratie: tekst van de builder of een getal uit de
 * opgeslagen configuratie. Null als hij leeg is, geen getal, of te lang om exact als float te bewaren.
 *
 * @param mixed $value Invoer.
 */
function _ww_form_number_setting( $value ): ?float {
	if ( is_int( $value ) ) {
		$value = (string) $value;
	} elseif ( is_float( $value ) ) {
		$value = _ww_form_number_float_text( $value );
	}
	$number = _ww_form_number_parse( _ww_form_string( $value ) );
	if ( null === $number || '' === $number || ! _ww_form_number_fits_float( $number ) ) {
		return null;
	}
	return (float) $number;
}

/**
 * Of een ingevulde instelling (min, max of step) niet bruikbaar is: niet leeg, maar geen getal, te lang, of een
 * stap van 0 of minder.
 *
 * @param mixed $value Invoer.
 * @param bool  $step  Of het de stapgrootte is.
 */
function _ww_form_number_setting_invalid( $value, bool $step = false ): bool {
	if ( null === $value || '' === trim( _ww_form_string( $value ) ) ) {
		return false;
	}
	$number = _ww_form_number_setting( $value );
	return null === $number || ( $step && $number <= 0 );
}

/**
 * Het aantal cijfers na de punt van een genormaliseerd getal.
 *
 * @param string $number Genormaliseerd getal.
 */
function _ww_form_number_decimals( string $number ): int {
	$dot = strpos( $number, '.' );
	return false === $dot ? 0 : strlen( $number ) - $dot - 1;
}

/**
 * Een genormaliseerd getal als heel getal na vermenigvuldigen met 10^decimals, zonder zwevende komma.
 *
 * @param string $number   Genormaliseerd getal (hoogstens 6 decimalen).
 * @param int    $decimals Aantal decimalen om op te schalen (hoogstens 6).
 */
function _ww_form_number_scaled( string $number, int $decimals ): int {
	$negative = '-' === substr( $number, 0, 1 );
	$parts    = explode( '.', ltrim( $number, '-' ) );
	$digits   = $parts[0] . str_pad( $parts[1] ?? '', $decimals, '0' );
	$value    = (int) $digits;
	return $negative ? -$value : $value;
}

/**
 * Vergelijkt twee genormaliseerde getallen exact, zonder zwevende komma.
 *
 * @param string $a Genormaliseerd getal.
 * @param string $b Genormaliseerd getal.
 * @return int -1, 0 of 1.
 */
function _ww_form_number_compare( string $a, string $b ): int {
	$decimals = max( _ww_form_number_decimals( $a ), _ww_form_number_decimals( $b ) );
	return _ww_form_number_scaled( $a, $decimals ) <=> _ww_form_number_scaled( $b, $decimals );
}

/**
 * Een instelling (float uit de configuratie) als genormaliseerd getal.
 *
 * @param float $value Instelling.
 */
function _ww_form_number_from_float( float $value ): string {
	return (string) _ww_form_number_parse( _ww_form_number_float_text( $value ) );
}

/**
 * Of een getal past bij de stap van het veld, geteld vanaf het minimum (of 0 zonder minimum).
 *
 * @param string              $value Genormaliseerd getal.
 * @param array<string,mixed> $field Opgeschoond getalveld.
 */
function _ww_form_number_fits_step( string $value, array $field ): bool {
	$step     = _ww_form_number_from_float( (float) ( $field['step'] ?? 1 ) );
	$base     = null !== ( $field['min'] ?? null ) ? _ww_form_number_from_float( (float) $field['min'] ) : '0';
	$decimals = max( _ww_form_number_decimals( $step ), _ww_form_number_decimals( $base ), _ww_form_number_decimals( $value ) );
	$step_int = _ww_form_number_scaled( $step, $decimals );
	if ( $step_int <= 0 ) {
		return true;
	}
	return 0 === ( _ww_form_number_scaled( $value, $decimals ) - _ww_form_number_scaled( $base, $decimals ) ) % $step_int;
}

/**
 * Een getal in de notatie van de taal, met de eenheid erachter (harde spatie).
 *
 * @param string              $value Genormaliseerd getal.
 * @param array<string,mixed> $field Opgeschoond getalveld.
 */
function _ww_form_number_format( string $value, array $field ): string {
	$text = number_format_i18n( (float) $value, _ww_form_number_decimals( $value ) );
	$unit = _ww_form_string( $field['unit'] ?? '' );
	return '' !== $unit ? $text . "\u{00A0}" . $unit : $text;
}

/**
 * Een grens of stap voor in een foutmelding: in de notatie van de taal, zonder overbodige nullen.
 *
 * @param float $value Instelling.
 */
function _ww_form_number_label( float $value ): string {
	$number = _ww_form_number_from_float( $value );
	return number_format_i18n( (float) $number, _ww_form_number_decimals( $number ) );
}

/**
 * Controleert de invoer van een getalveld.
 *
 * @param array<string,mixed> $field Opgeschoond getalveld.
 * @param mixed               $raw   Ingestuurde waarde.
 * @return array{0: string, 1: string} De waarde (genormaliseerd, of de opgeschoonde invoer bij een fout) en de fout.
 */
function _ww_form_number_validate( array $field, $raw ): array {
	$invalid = __( 'Vul een getal in.', 'webwerckt-base' );
	$text    = _ww_form_input_string( $raw );
	if ( null === $text ) {
		return array( '', $invalid );
	}
	$text   = _ww_form_clean_input( $text );
	$number = _ww_form_number_parse( $text );
	if ( '' === $number ) {
		return array( '', '' );
	}
	if ( null === $number ) {
		return array( mb_substr( $text, 0, 30 ), $invalid );
	}
	$min = $field['min'] ?? null;
	$max = $field['max'] ?? null;
	$out = ( null !== $min && (float) $number < $min ) || ( null !== $max && (float) $number > $max );
	if ( $out && null !== $min && null !== $max ) {
		/* translators: 1: minimum, 2: maximum. */
		return array( $text, sprintf( __( 'Vul een getal in tussen %1$s en %2$s.', 'webwerckt-base' ), _ww_form_number_label( (float) $min ), _ww_form_number_label( (float) $max ) ) );
	}
	if ( $out && null !== $min ) {
		/* translators: %s: minimum. */
		return array( $text, sprintf( __( 'Vul een getal in van minimaal %s.', 'webwerckt-base' ), _ww_form_number_label( (float) $min ) ) );
	}
	if ( $out ) {
		/* translators: %s: maximum. */
		return array( $text, sprintf( __( 'Vul een getal in van maximaal %s.', 'webwerckt-base' ), _ww_form_number_label( (float) $max ) ) );
	}
	if ( ! _ww_form_number_fits_step( $number, $field ) ) {
		/* translators: %s: stapgrootte. */
		return array( $text, sprintf( __( 'Vul een getal in met stappen van %s.', 'webwerckt-base' ), _ww_form_number_label( (float) ( $field['step'] ?? 1 ) ) ) );
	}
	return array( $number, '' );
}
