<?php
/**
 * Statistieken: de pure hulpfuncties van het meetpunt (beslissing 0038).
 *
 * Alleen functies, geen hooks en geen thema-functies behalve die uit path-ignore.php: dit bestand wordt ook door de
 * mu-plugin geladen, vóór het thema. Er wordt niets over de bezoeker bewaard.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/path-ignore.php';

/**
 * Schemaversie van de tabellen. Hier en niet in stats.php: het meetpunt draait vóór het thema en moet weten of de
 * kolom ts en de tabel met gebeurtenissen er al zijn (_ww_stats_install() maakt ze pas bij het eerste adminbezoek of
 * de eerste cron).
 */
const WW_STATS_DB_VERSION = '2';

/**
 * Naam van de tabel met ruwe treffers.
 */
function _ww_stats_hits_table(): string {
	global $wpdb;
	return $wpdb->prefix . 'ww_stats_hits';
}

/**
 * Naam van de tabel met dagtotalen.
 */
function _ww_stats_daily_table(): string {
	global $wpdb;
	return $wpdb->prefix . 'ww_stats_daily';
}

/**
 * Naam van de tabel met ruwe gebeurtenissen (kliks en formulieren).
 */
function _ww_stats_events_table(): string {
	global $wpdb;
	return $wpdb->prefix . 'ww_stats_events';
}

/**
 * Normaliseert een pad voor de statistieken, of geeft null als het pad niet telt.
 *
 * Alleen het pad (zonder query-string), in kleine letters, met een slash aan het eind tenzij het laatste deel een
 * punt heeft. Bots en statische bestanden (zoals bij het 404-logboek) en de REST API tellen niet. Hoogstens 255 tekens.
 *
 * @param string $path Pad of URL.
 */
function _ww_stats_path( string $path ): ?string {
	$parsed = wp_parse_url( trim( $path ), PHP_URL_PATH );
	$path   = strtolower( is_string( $parsed ) ? $parsed : '' );
	$path = (string) preg_replace( '#/{2,}#', '/', '/' . $path );

	$last = substr( $path, (int) strrpos( $path, '/' ) + 1 );
	if ( '' !== $last && ! str_contains( $last, '.' ) ) {
		$path .= '/';
	}

	if ( _ww_404_log_ignored( $path ) || str_starts_with( $path, '/wp-json' ) ) {
		return null;
	}

	return substr( $path, 0, 255 );
}

/**
 * Geeft de host van een verwijzer zonder www., of een lege tekst bij een eigen of ongeldige host.
 *
 * @param string   $url       Verwijzer-URL.
 * @param string[] $own_hosts Hosts van de site zelf.
 */
function _ww_stats_referrer_host( string $url, array $own_hosts ): string {
	$host = wp_parse_url( trim( $url ), PHP_URL_HOST );
	if ( ! is_string( $host ) || '' === $host ) {
		return '';
	}

	$host = strtolower( $host );
	$bare = (string) preg_replace( '#^www\.#', '', $host );
	foreach ( $own_hosts as $own ) {
		$own = strtolower( (string) $own );
		if ( $host === $own || $bare === preg_replace( '#^www\.#', '', $own ) ) {
			return '';
		}
	}

	return mb_substr( $bare, 0, 100 );
}

/**
 * Maakt een korte waarde (zoals een utm-parameter) schoon: getrimd, kleine letters, hoogstens 100 tekens.
 *
 * @param string $value Waarde.
 */
function _ww_stats_text( string $value ): string {
	return mb_substr( mb_strtolower( trim( $value ) ), 0, 100 );
}

/**
 * Apparaatsoort uit de schermbreedte: onder 768 mobile, onder 1024 tablet, anders desktop (ook zonder breedte).
 *
 * @param mixed $width Schermbreedte in pixels.
 */
function _ww_stats_device( $width ): string {
	if ( ! is_numeric( $width ) ) {
		return 'desktop';
	}
	if ( $width < 768 ) {
		return 'mobile';
	}
	return $width < 1024 ? 'tablet' : 'desktop';
}

/**
 * Landcode (ISO) uit de tijdzone van de browser, of een lege tekst als die onbekend is.
 *
 * Alleen letters, cijfers en _+-/ (hoogstens 64 tekens) worden bekeken: een nulbyte of ander vreemd teken laat
 * DateTimeZone een Error gooien in plaats van een Exception.
 *
 * @param string $tz Tijdzone zoals Europe/Amsterdam.
 */
function _ww_stats_country( string $tz ): string {
	if ( 1 !== preg_match( '#^[A-Za-z0-9_+\-/]{1,64}$#D', $tz ) ) {
		return '';
	}

	$legacy = array(
		'Europe/Kiev'          => 'UA',
		'Europe/Kyiv'          => 'UA',
		'Europe/Uzhgorod'      => 'UA',
		'Europe/Zaporozhye'    => 'UA',
		'Asia/Calcutta'        => 'IN',
		'Asia/Saigon'          => 'VN',
		'Asia/Katmandu'        => 'NP',
		'Asia/Rangoon'         => 'MM',
		'America/Buenos_Aires' => 'AR',
		'Atlantic/Faeroe'      => 'FO',
	);
	if ( isset( $legacy[ $tz ] ) ) {
		return $legacy[ $tz ];
	}

	try {
		// getLocation() geeft false (of '??') voor zones zonder land, zoals UTC; de PHPDoc zegt dat niet.
		/** @var array<string, mixed>|false $location */
		$location = ( new DateTimeZone( $tz ) )->getLocation();
	} catch ( Throwable $e ) {
		return '';
	}

	$code = '';
	if ( is_array( $location ) && isset( $location['country_code'] ) ) {
		$code = (string) $location['country_code'];
	}
	return ( 2 === strlen( $code ) && '??' !== $code ) ? $code : '';
}

/**
 * Is deze user agent een bot, een monitor of een script? Een lege user agent telt als bot.
 *
 * @param string $ua User agent.
 */
function _ww_stats_is_bot( string $ua ): bool {
	if ( '' === trim( $ua ) ) {
		return true;
	}
	return 1 === preg_match( '/bot|crawl|spider|slurp|preview|monitor|headless|lighthouse|pingdom|uptime|curl|wget|python|java/i', $ua );
}

/**
 * Hosts die bij de site horen: die van home_url() en site_url(), elk met en zonder www., plus WW_STATS_HOSTS.
 *
 * Een constante en geen filter: het thema is nog niet geladen als de mu-plugin draait.
 *
 * @return string[]
 */
function _ww_stats_hosts(): array {
	$hosts = array();
	foreach ( array( home_url(), site_url() ) as $url ) {
		$host = wp_parse_url( $url, PHP_URL_HOST );
		if ( is_string( $host ) && '' !== $host ) {
			$hosts[] = strtolower( $host );
		}
	}
	if ( defined( 'WW_STATS_HOSTS' ) && is_string( WW_STATS_HOSTS ) ) {
		foreach ( explode( ',', WW_STATS_HOSTS ) as $host ) {
			$host = strtolower( trim( $host ) );
			if ( '' !== $host ) {
				$hosts[] = $host;
			}
		}
	}

	$all = array();
	foreach ( $hosts as $host ) {
		$bare  = (string) preg_replace( '#^www\.#', '', $host );
		$all[] = $bare;
		$all[] = 'www.' . $bare;
	}
	return array_values( array_unique( $all ) );
}

/**
 * Hoort het verzoek bij een eigen host? Alleen de host van Origin telt, of zonder Origin die van Referer.
 *
 * @param array<string,mixed> $server Het $_SERVER-achtige verzoek.
 * @param string[]            $hosts  Eigen hosts.
 */
function _ww_stats_origin_ok( array $server, array $hosts ): bool {
	$source = '';
	if ( isset( $server['HTTP_ORIGIN'] ) && is_string( $server['HTTP_ORIGIN'] ) && '' !== $server['HTTP_ORIGIN'] ) {
		$source = $server['HTTP_ORIGIN'];
	} elseif ( isset( $server['HTTP_REFERER'] ) && is_string( $server['HTTP_REFERER'] ) ) {
		$source = $server['HTTP_REFERER'];
	}

	$host = wp_parse_url( $source, PHP_URL_HOST );
	return is_string( $host ) && '' !== $host && in_array( strtolower( $host ), $hosts, true );
}

/**
 * Het IP-adres van de bezoeker, alleen om te hashen. Een header (zoals HTTP_CF_CONNECTING_IP) telt alleen als de
 * constante WW_STATS_IP_HEADER (of de tweede parameter) die noemt; dan het eerste adres ervan. Bij X-Forwarded-For
 * zet de bezoeker dat eerste adres zelf, dus een header met één waarde van de CDN is beter.
 *
 * @param array<string,mixed> $server Het $_SERVER-achtige verzoek.
 * @param string|null         $header Sleutel van de header; standaard de constante.
 */
function _ww_stats_ip( array $server, ?string $header = null ): string {
	if ( null === $header && defined( 'WW_STATS_IP_HEADER' ) && is_string( WW_STATS_IP_HEADER ) ) {
		$header = WW_STATS_IP_HEADER;
	}
	if ( is_string( $header ) && '' !== $header && isset( $server[ $header ] ) && is_string( $server[ $header ] ) ) {
		$first = trim( explode( ',', $server[ $header ] )[0] );
		if ( '' !== $first ) {
			return $first;
		}
	}
	return isset( $server['REMOTE_ADDR'] ) && is_string( $server['REMOTE_ADDR'] ) ? $server['REMOTE_ADDR'] : '';
}

/**
 * De salt van een dag (Y-m-d): 64 hextekens, één keer gemaakt. De salts van andere dagen worden gewist.
 *
 * @param string $day Datum als Y-m-d.
 */
function _ww_stats_salt( string $day ): string {
	global $wpdb;
	$name = 'ww_stats_salt_' . str_replace( '-', '', $day );

	$salt = get_option( $name );
	if ( is_string( $salt ) && '' !== $salt ) {
		return $salt;
	}

	// INSERT IGNORE is atomisch: bij twee gelijktijdige eerste hits wint de eerste insert en de ander leest die waarde.
	// (add_option() overschrijft bij een dubbele sleutel, dus daar zou de tweede de salt van de eerste vervangen.)
	$wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'off')", $name, bin2hex( random_bytes( 32 ) ) ) );
	// De eerste get_option() zette de naam in notoptions; de INSERT gaat buiten de cache om.
	wp_cache_delete( 'notoptions', 'options' );
	_ww_stats_drop_old_salts( $day );

	$salt = get_option( $name );
	return is_string( $salt ) ? $salt : '';
}

/**
 * Wist de salts van alle dagen behalve deze (Y-m-d) en leegt de optiecache ervan. alloptions en notoptions alleen als
 * er iets is gewist: anders verandert er niets en hoeft een persistente objectcache alloptions niet opnieuw te laden.
 *
 * @param string $day Datum als Y-m-d waarvan de salt blijft.
 */
function _ww_stats_drop_old_salts( string $day ): void {
	global $wpdb;
	$name = 'ww_stats_salt_' . str_replace( '-', '', $day );
	$like = $wpdb->esc_like( 'ww_stats_salt_' ) . '%';
	$old  = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s AND option_name <> %s", $like, $name ) );
	if ( $old ) {
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s AND option_name <> %s", $like, $name ) );
		foreach ( $old as $old_name ) {
			wp_cache_delete( (string) $old_name, 'options' );
		}
		wp_cache_delete( 'alloptions', 'options' );
		wp_cache_delete( 'notoptions', 'options' );
	}
	wp_cache_delete( $name, 'options' );
}

/**
 * Het plafond voor ruwe treffers per dag (alle bezoekers samen): de parameter als die groter dan 0 is, anders de
 * constante WW_STATS_MAX_HITS_PER_DAY als die een geheel getal groter dan 0 is, anders 50000.
 *
 * @param int|null $max Plafond; standaard de constante of 50000.
 */
function _ww_stats_max_hits( ?int $max = null ): int {
	return _ww_stats_cap( $max, 'WW_STATS_MAX_HITS_PER_DAY', 50000 );
}

/**
 * Een plafond: $max als die groter dan 0 is, anders de constante als die een geheel getal groter dan 0 is, anders $default.
 *
 * @param int|null $max      Plafond van de aanroeper.
 * @param string   $constant Naam van de constante.
 * @param int      $default  Standaardwaarde.
 */
function _ww_stats_cap( ?int $max, string $constant, int $default ): int {
	if ( null !== $max && $max > 0 ) {
		return $max;
	}
	if ( defined( $constant ) ) {
		$value = constant( $constant );
		if ( is_int( $value ) && $value > 0 ) {
			return $value;
		}
	}
	return $default;
}

/**
 * Is dit een verzoek op de voorkant (index.php)? Niet bij wp-login.php, admin-ajax.php, wp-cron.php, xmlrpc.php of de
 * admin. Los van de superglobals, zodat het te testen is.
 *
 * @param array<string,mixed> $server Het $_SERVER-achtige verzoek.
 */
function _ww_stats_front_request( array $server ): bool {
	$script = is_string( $server['SCRIPT_FILENAME'] ?? null ) ? $server['SCRIPT_FILENAME'] : '';
	if ( 'index.php' !== basename( str_replace( '\\', '/', $script ) ) ) {
		return false;
	}
	return ! ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) );
}

/**
 * De bezoekershash van vandaag: de eerste 16 tekens van sha256( salt|ip|ua|host ). Het IP en de user agent worden niet bewaard.
 *
 * @param string $salt Salt van de dag.
 * @param string $ip   IP-adres.
 * @param string $ua   User agent.
 * @param string $host Host van het verzoek.
 */
function _ww_stats_visitor( string $salt, string $ip, string $ua, string $host ): string {
	return substr( hash( 'sha256', $salt . '|' . $ip . '|' . $ua . '|' . $host ), 0, 16 );
}

/**
 * Het plafond voor ruwe gebeurtenissen per dag (alle bezoekers samen): de parameter als die groter dan 0 is, anders de
 * constante WW_STATS_MAX_EVENTS_PER_DAY als die een geheel getal groter dan 0 is, anders 100000.
 *
 * @param int|null $max Plafond; standaard de constante of 100000.
 */
function _ww_stats_max_events( ?int $max = null ): int {
	return _ww_stats_cap( $max, 'WW_STATS_MAX_EVENTS_PER_DAY', 100000 );
}

/**
 * Hoeveel rijen een tabel met ruwe rijen (treffers of gebeurtenissen) op een dag heeft: van deze bezoeker en in totaal.
 * Eén query; bij een databasefout allebei 0, zoals eerder met twee losse tellingen.
 *
 * @param string $table   Tabelnaam uit _ww_stats_hits_table() of _ww_stats_events_table().
 * @param string $day     Datum als Y-m-d.
 * @param string $visitor Bezoekershash.
 * @return array{visitor:int, day:int}
 */
function _ww_stats_day_counts( string $table, string $day, string $visitor ): array {
	global $wpdb;
	$row = $wpdb->get_row( $wpdb->prepare( "SELECT COUNT(*) AS day_count, SUM(CASE WHEN visitor = %s THEN 1 ELSE 0 END) AS visitor_count FROM {$table} WHERE day = %s", $visitor, $day ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam van de aanroeper, uit een helper.
	return array(
		'visitor' => (int) ( $row['visitor_count'] ?? 0 ),
		'day'     => (int) ( $row['day_count'] ?? 0 ),
	);
}

/**
 * Rondt een tijdstip naar beneden af op de minuut (Unix-tijd, UTC).
 *
 * @param int $now Tijdstip.
 */
function _ww_stats_minute( int $now ): int {
	return $now - $now % 60;
}

/**
 * Maakt het doel van een klik schoon: alles vanaf de eerste ? of # weg, | wordt %7C, kleine letters, getrimd,
 * hoogstens 191 tekens. Zo blijft er geen token of persoonlijke waarde uit een URL over.
 *
 * @param string $target Doel (pad of URL).
 */
function _ww_stats_event_target( string $target ): string {
	$target = substr( $target, 0, strcspn( $target, '?#' ) );
	$target = str_replace( '|', '%7C', $target );
	return mb_substr( trim( mb_strtolower( $target ) ), 0, 191 );
}

/**
 * Maakt de tekst van een klik schoon: | wordt /, witruimte (ook nieuwe regels) wordt één spatie, getrimd, hoogstens 80 tekens.
 *
 * @param string $label Tekst van de knop of link.
 */
function _ww_stats_event_label( string $label ): string {
	$label = str_replace( '|', '/', $label );
	$label = (string) preg_replace( '/\s+/u', ' ', $label );
	return mb_substr( trim( $label ), 0, 80 );
}

/**
 * Verwerkt één gebeurtenis (klik of formulier) en schrijft hem weg. Geeft ok, path, event (ongeldig), limit (300 van deze
 * bezoeker vandaag), full (het plafond van de dag is bereikt) of db (de insert mislukte). Eén INSERT, na één telling.
 *
 * @param array<string,mixed> $data        De gedecodeerde body; het pad (p) wordt hier genormaliseerd.
 * @param string              $day         Datum als Y-m-d.
 * @param int                 $ts          Tijdstip, afgerond op de minuut.
 * @param string              $visitor     Bezoekershash.
 * @param int|null            $max_per_day Plafond voor gebeurtenissen per dag; standaard _ww_stats_max_events().
 * @param string|null         $path        Het al genormaliseerde pad (uit _ww_stats_path()); null om p hier te normaliseren.
 */
function _ww_stats_record_event( array $data, string $day, int $ts, string $visitor, ?int $max_per_day = null, ?string $path = null ): string {
	global $wpdb;

	$text = static function ( string $key ) use ( $data ): string {
		return isset( $data[ $key ] ) && is_string( $data[ $key ] ) ? $data[ $key ] : '';
	};

	$path = $path ?? _ww_stats_path( $text( 'p' ) );
	if ( null === $path ) {
		return 'path';
	}

	$type    = $data['e'] ?? null;
	$form_id = 0;
	$step    = 0;
	$target  = '';
	$label   = '';
	if ( 'c' === $type ) {
		$kind = $text( 'k' );
		if ( ! in_array( $kind, array( 'tel', 'mailto', 'download', 'extern', 'intern', 'knop' ), true ) ) {
			return 'event';
		}
		$type   = 'click';
		$target = _ww_stats_event_target( $text( 't' ) );
		$label  = _ww_stats_event_label( $text( 'l' ) );
	} elseif ( 'f' === $type ) {
		$kind = $text( 's' );
		if ( ! in_array( $kind, array( 'view', 'start', 'step', 'sent' ), true ) ) {
			return 'event';
		}
		$raw_form = $data['f'] ?? null;
		if ( ! is_numeric( $raw_form ) || (int) $raw_form <= 0 ) {
			return 'event';
		}
		$type    = 'form';
		$form_id = (int) $raw_form;
		$raw_n   = $data['n'] ?? null;
		if ( is_int( $raw_n ) && $raw_n >= 0 && $raw_n <= 50 ) {
			$step = $raw_n;
		}
	} else {
		return 'event';
	}

	$table  = _ww_stats_events_table();
	$counts = _ww_stats_day_counts( $table, $day, $visitor );
	if ( $counts['visitor'] >= 300 ) {
		return 'limit';
	}
	if ( $counts['day'] >= _ww_stats_max_events( $max_per_day ) ) {
		return 'full';
	}

	$inserted = $wpdb->insert(
		$table,
		array(
			'day'     => $day,
			'ts'      => $ts,
			'visitor' => $visitor,
			'path'    => $path,
			'type'    => $type,
			'kind'    => $kind,
			'target'  => $target,
			'label'   => $label,
			'form_id' => $form_id,
			'step'    => $step,
		),
		array( '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d' )
	);

	return false === $inserted ? 'db' : 'ok';
}

/**
 * Verwerkt één treffer en schrijft hem weg. Een body met e is een gebeurtenis (zie _ww_stats_record_event()). Geeft ok,
 * method, origin, size, json, bot, path, event (ongeldige gebeurtenis, of het schema is nog niet bijgewerkt), limit (200 weergaven of 300 gebeurtenissen van deze
 * bezoeker vandaag), full (het plafond van de dag is bereikt) of db (de insert mislukte); alleen bij ok komt er een rij.
 *
 * Zonder headers en zonder exit, zodat het te testen is. Draait dit vanuit de mu-plugin, dan zijn filters op
 * ww_404_log_ignore van het thema of plugins nog niet geregistreerd: dan gelden alleen de standaardpatronen.
 *
 * @param array<string,mixed> $server      Het $_SERVER-achtige verzoek.
 * @param string              $body        De body (hoogstens 2049 bytes gelezen).
 * @param int                 $now         Tijdstip.
 * @param int|null            $max_per_day Plafond voor ruwe treffers per dag; standaard _ww_stats_max_hits().
 * @param int|null            $max_events  Plafond voor gebeurtenissen per dag; standaard _ww_stats_max_events().
 */
function _ww_stats_record( array $server, string $body, int $now, ?int $max_per_day = null, ?int $max_events = null ): string {
	global $wpdb;

	if ( ! isset( $server['REQUEST_METHOD'] ) || 'POST' !== $server['REQUEST_METHOD'] ) {
		return 'method';
	}
	if ( strlen( $body ) > 2048 ) {
		return 'size';
	}
	$data = json_decode( $body, true );
	if ( ! is_array( $data ) ) {
		return 'json';
	}
	$hosts = _ww_stats_hosts();
	if ( ! _ww_stats_origin_ok( $server, $hosts ) ) {
		return 'origin';
	}
	$ua = isset( $server['HTTP_USER_AGENT'] ) && is_string( $server['HTTP_USER_AGENT'] ) ? $server['HTTP_USER_AGENT'] : '';
	if ( _ww_stats_is_bot( $ua ) ) {
		return 'bot';
	}

	$text = static function ( string $key ) use ( $data ): string {
		return isset( $data[ $key ] ) && is_string( $data[ $key ] ) ? $data[ $key ] : '';
	};

	$path = _ww_stats_path( $text( 'p' ) );
	if ( null === $path ) {
		return 'path';
	}

	$day     = wp_date( 'Y-m-d', $now );
	$day     = is_string( $day ) ? $day : gmdate( 'Y-m-d', $now );
	$host    = isset( $server['HTTP_HOST'] ) && is_string( $server['HTTP_HOST'] ) ? $server['HTTP_HOST'] : '';
	$visitor = _ww_stats_visitor( _ww_stats_salt( $day ), _ww_stats_ip( $server ), $ua, $host );
	$ts      = _ww_stats_minute( $now );

	// Na een uitrol en vóór _ww_stats_install() (eerste adminbezoek of cron) is het schema nog oud: geen kolom ts en geen
	// tabel met gebeurtenissen. De weergave telt dan zonder ts, een gebeurtenis wordt geweigerd.
	$schema_ok = WW_STATS_DB_VERSION === get_option( 'ww_stats_db_version' );

	if ( isset( $data['e'] ) ) {
		return $schema_ok ? _ww_stats_record_event( $data, $day, $ts, $visitor, $max_events, $path ) : 'event';
	}

	$table  = _ww_stats_hits_table();
	$counts = _ww_stats_day_counts( $table, $day, $visitor );
	if ( $counts['visitor'] >= 200 ) {
		return 'limit';
	}
	// Plafond voor alle bezoekers samen: een script met een nieuwe user agent per verzoek omzeilt de grens per bezoeker.
	if ( $counts['day'] >= _ww_stats_max_hits( $max_per_day ) ) {
		return 'full';
	}

	$entry   = 0 === $counts['visitor'];
	$row     = array(
		'day'          => $day,
		'path'         => $path,
		'referrer'     => $entry ? _ww_stats_referrer_host( $text( 'r' ), $hosts ) : '',
		'utm_source'   => $entry ? _ww_stats_text( $text( 'us' ) ) : '',
		'utm_medium'   => $entry ? _ww_stats_text( $text( 'um' ) ) : '',
		'utm_campaign' => $entry ? _ww_stats_text( $text( 'uc' ) ) : '',
		'device'       => _ww_stats_device( $data['w'] ?? null ),
		'country'      => _ww_stats_country( $text( 'tz' ) ),
		'visitor'      => $visitor,
		'entry'        => $entry ? 1 : 0,
	);
	$formats = array( '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d' );
	if ( $schema_ok ) {
		$row['ts'] = $ts;
		$formats[] = '%d';
	}
	$inserted = $wpdb->insert( $table, $row, $formats );

	return false === $inserted ? 'db' : 'ok';
}

/**
 * Het meetpunt: alleen bij de queryvariabele ww_hit op de voorkant (index.php). Verwerkt de treffer, antwoordt altijd
 * 204 zonder opslag in de browser en stopt. Andere verzoeken gaan gewoon door.
 */
function _ww_stats_collect(): void {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- anoniem meetpunt zonder formulier; de Origin-controle staat in _ww_stats_record().
	if ( ! isset( $_GET['ww_hit'] ) || ! _ww_stats_front_request( $_SERVER ) ) {
		return;
	}

	// Eerst de status en de header: een melding of databasefout tijdens het werk mag het antwoord niet meer veranderen.
	http_response_code( 204 );
	header( 'Cache-Control: no-store' );

	// Uitvoer van het werk (zoals een melding bij WP_DEBUG_DISPLAY) wordt weggegooid: een 204 heeft geen body.
	// Ook een Error of Exception tijdens het werk verandert het antwoord niet: de treffer telt dan gewoon niet.
	ob_start();
	try {
		$body = (string) file_get_contents( 'php://input', false, null, 0, 2049 );
		_ww_stats_record( $_SERVER, $body, time() );
	} catch ( Throwable $e ) {
		unset( $e );
	} finally {
		ob_end_clean();
	}
	exit;
}
