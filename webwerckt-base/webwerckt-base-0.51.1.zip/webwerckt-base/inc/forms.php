<?php
/**
 * Formulieren door het thema (beslissing 0032): het post type ww_form, de configuratie en ww_form_sanitize().
 *
 * Een formulier is een niet-openbaar post type. De titel is de naam (en {formulier} in de mail), de slug is wat
 * ww_form( 'contact' ) gebruikt. De velden, mails, het vervolg na versturen en de opslag staan in één configuratie in
 * de meta _ww_form, als PHP-array (geen JSON-string) en altijd via ww_form_sanitize(). Weergave, inzendingen, mail,
 * verwerking en beheer staan in de andere inc/forms-*.php-bestanden.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const WW_FORM_POST_TYPE = 'ww_form';
const WW_FORM_META      = '_ww_form';

/**
 * Registreert het post type ww_form: geen eigen URL, niet in zoekresultaten of sitemaps, niet in de REST API.
 * Rechten als bij pagina's, dus een Redacteur (edit_others_pages) beheert formulieren.
 */
function _ww_form_register_post_type(): void {
	register_post_type(
		WW_FORM_POST_TYPE,
		array(
			'labels'              => array_merge(
				ww_post_type_labels( __( 'Formulieren', 'webwerckt-base' ), __( 'Formulier', 'webwerckt-base' ) ),
				array( 'add_new_item' => __( 'Nieuw formulier', 'webwerckt-base' ) )
			),
			'public'              => false,
			'publicly_queryable'  => false,
			'query_var'           => false,
			'rewrite'             => false,
			'exclude_from_search' => true,
			'show_in_rest'        => false,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_nav_menus'   => false,
			'menu_icon'           => 'dashicons-feedback',
			'capability_type'     => 'page',
			'map_meta_cap'        => true,
			'supports'            => array( 'title', 'revisions' ),
		)
	);
}
add_action( 'init', '_ww_form_register_post_type' );

/**
 * De configuratie gaat mee in revisies, zodat terugzetten ook de velden terugzet.
 *
 * @param mixed  $keys      Meta-sleutels die in revisies meegaan (een lijst).
 * @param string $post_type Post type.
 * @return mixed
 */
function _ww_form_revision_meta_keys( $keys, $post_type = '' ) {
	if ( WW_FORM_POST_TYPE === $post_type && is_array( $keys ) && ! in_array( WW_FORM_META, $keys, true ) ) {
		$keys[] = WW_FORM_META;
	}
	return $keys;
}
add_filter( 'wp_post_revision_meta_keys', '_ww_form_revision_meta_keys', 10, 2 );

/**
 * Tags die er altijd zijn, naast de veldsleutels. Ook gereserveerd als sleutel.
 *
 * @return list<string>
 */
function _ww_form_builtin_tags(): array {
	return array( 'alle_velden', 'formulier', 'site', 'datum', 'pagina' );
}

/**
 * Lege standaardconfiguratie: versie 1, geen velden, de standaardmails, een bedankbericht en opslag aan.
 *
 * @return array<string,mixed>
 */
function _ww_form_default_config(): array {
	return array(
		'version'      => 1,
		'fields'       => array(),
		'steps'        => array(),
		'recaptcha'    => true,
		'submit_label' => __( 'Versturen', 'webwerckt-base' ),
		'mail'         => array(
			'notify'  => array(
				'enabled'        => true,
				'to'             => '',
				/* translators: {formulier} is een mailtag en blijft zo staan. */
				'subject'        => __( 'Nieuwe inzending: {formulier}', 'webwerckt-base' ),
				/* translators: {pagina} en {datum} zijn mailtags en blijven zo staan. */
				'body'           => "{alle_velden}\n\n" . __( 'Verstuurd vanaf {pagina} op {datum}.', 'webwerckt-base' ),
				'reply_to_field' => '',
			),
			'confirm' => array(
				'enabled'  => false,
				'to_field' => '',
				'subject'  => __( 'Bedankt voor je bericht', 'webwerckt-base' ),
				/* translators: {site} is een mailtag en blijft zo staan. */
				'body'     => __( 'Bedankt voor je bericht aan {site}. We nemen zo snel mogelijk contact met je op.', 'webwerckt-base' ),
			),
		),
		'after'        => array(
			'type'    => 'message',
			'message' => __( 'Bedankt, we nemen snel contact op.', 'webwerckt-base' ),
			'page_id' => 0,
			'url'     => '',
		),
		'storage'      => array(
			'store'            => true,
			'retention_months' => 12,
		),
		'pdf'          => array(
			'enabled'        => false,
			'template'       => '',
			'filename'       => '{formulier}-{datum}',
			'attach_notify'  => true,
			'attach_confirm' => false,
		),
	);
}

/**
 * Maakt een veldsleutel (of optiewaarde) uit een label: kleine letters, a-z0-9_, hoogstens 40 tekens, beginnend met
 * een letter. Leeg of onbruikbaar wordt de terugval (standaard "veld"). Bezet of gereserveerd ({alle_velden} en de andere vaste tags) krijgt
 * _2, _3. Een sleutel begint nooit met ww_; dat voorvoegsel valt weg.
 *
 * Een geldige sleutel die nog vrij is, komt ongewijzigd terug; zo blijft een sleutel gelijk als het label wijzigt.
 *
 * @param string   $label Label of bestaande sleutel.
 * @param string[] $taken    Sleutels die al bestaan.
 * @param string   $fallback Sleutel als het label leeg of onbruikbaar is.
 */
function _ww_form_key( string $label, array $taken, string $fallback = 'veld' ): string {
	$base = strtolower( remove_accents( $label ) );
	$base = trim( (string) preg_replace( '/[^a-z0-9]+/', '_', $base ), '_' );
	do {
		$before = $base;
		$base   = (string) preg_replace( '/^[^a-z]+/', '', $base );
		$base   = (string) preg_replace( '/^ww(_|$)/', '', $base );
	} while ( $before !== $base );
	$base = rtrim( substr( $base, 0, 40 ), '_' );
	if ( '' === $base ) {
		$base = $fallback;
	}

	$reserved = _ww_form_builtin_tags();
	$key      = $base;
	for ( $n = 2; in_array( $key, $taken, true ) || in_array( $key, $reserved, true ); $n++ ) {
		$suffix = '_' . $n;
		$key    = rtrim( substr( $base, 0, 40 - strlen( $suffix ) ), '_' ) . $suffix;
	}
	return $key;
}

/**
 * Een tekstwaarde uit de invoer: een array of object telt als leeg, zodat het opschonen geen PHP-fout geeft.
 *
 * @param mixed $value Invoer.
 */
function _ww_form_string( $value ): string {
	return is_scalar( $value ) ? (string) $value : '';
}

/**
 * Hoeveel tekens een tekstregel mag hebben: 30 voor een telefoonnummer, anders 255.
 *
 * @param string $input Het type invoer van de regel (text, email, tel, ...).
 */
function _ww_form_line_max( string $input ): int {
	return 'tel' === $input ? 30 : 255;
}

/**
 * Platte tekst op één regel, ingekort.
 *
 * @param mixed $value Invoer.
 * @param int   $max   Hoogstens zoveel tekens.
 */
function _ww_form_text( $value, int $max ): string {
	return mb_substr( sanitize_text_field( _ww_form_string( $value ) ), 0, $max );
}

/**
 * HTML met alleen de toegestane tags, ingekort. Na het inkorten nog eens door wp_kses, zodat een afgebroken tag
 * geen halve HTML achterlaat.
 *
 * @param mixed                                $value   Invoer.
 * @param array<string,array<string,bool>>     $allowed Toegestane tags voor wp_kses.
 * @param int                                  $max     Hoogstens zoveel tekens.
 */
function _ww_form_kses( $value, array $allowed, int $max ): string {
	$html = trim( wp_kses( _ww_form_string( $value ), $allowed ) );
	if ( mb_strlen( $html ) > $max ) {
		$html = force_balance_tags( wp_kses( mb_substr( $html, 0, $max ), $allowed ) );
	}
	return $html;
}

/**
 * Een getal begrensd tussen min en max; geen getal wordt de standaard.
 *
 * @param mixed $value   Invoer.
 * @param int   $min     Ondergrens.
 * @param int   $max     Bovengrens.
 * @param int   $default Standaard.
 */
function _ww_form_int( $value, int $min, int $max, int $default ): int {
	if ( ! is_numeric( $value ) ) {
		return $default;
	}
	return max( $min, min( $max, (int) $value ) );
}

/**
 * Een ja/nee-waarde; "false" en "0" zijn nee.
 *
 * @param mixed $value   Invoer.
 * @param bool  $default Standaard als er niets is.
 */
function _ww_form_bool( $value, bool $default ): bool {
	if ( null === $value ) {
		return $default;
	}
	return is_scalar( $value ) && rest_sanitize_boolean( $value );
}

/**
 * Een array uit de invoer, of een lege array.
 *
 * @param mixed $value Invoer.
 * @return array<mixed>
 */
function _ww_form_array( $value ): array {
	return is_array( $value ) ? $value : array();
}

/**
 * Schoont één veld op; null als het type onbekend is.
 *
 * @param array<mixed> $field Invoer.
 * @param string[]     $taken Sleutels die al bestaan; de sleutel van dit veld komt erbij.
 * @return array<string,mixed>|null
 */
function _ww_form_sanitize_field( array $field, array &$taken ): ?array {
	$type = _ww_form_string( $field['type'] ?? '' );
	if ( ! in_array( $type, array( 'line', 'text', 'number', 'checkbox', 'select', 'choice', 'file' ), true ) ) {
		return null;
	}

	if ( 'checkbox' === $type ) {
		$label = _ww_form_kses(
			$field['label'] ?? '',
			array(
				'a'      => array( 'href' => true ),
				'strong' => array(),
				'em'     => array(),
			),
			200
		);
	} else {
		$label = _ww_form_text( $field['label'] ?? '', 200 );
	}

	$key     = _ww_form_string( $field['key'] ?? '' );
	$key     = _ww_form_key( '' !== $key ? $key : wp_strip_all_tags( $label ), $taken );
	$taken[] = $key;

	$clean = array(
		'key'      => $key,
		'type'     => $type,
		'label'    => $label,
		'required' => _ww_form_bool( $field['required'] ?? null, false ),
		'help'     => _ww_form_text( $field['help'] ?? '', 500 ),
	);

	switch ( $type ) {
		case 'line':
			$input                = _ww_form_string( $field['input'] ?? '' );
			$clean['placeholder'] = _ww_form_text( $field['placeholder'] ?? '', 200 );
			$clean['input']       = in_array( $input, array( 'text', 'email', 'tel' ), true ) ? $input : 'text';
			break;
		case 'number':
			$step                 = _ww_form_number_setting( $field['step'] ?? null );
			$clean['placeholder'] = _ww_form_text( $field['placeholder'] ?? '', 200 );
			$clean['min']         = _ww_form_number_setting( $field['min'] ?? null );
			$clean['max']         = _ww_form_number_setting( $field['max'] ?? null );
			$clean['step']        = null !== $step && $step > 0 ? $step : 1.0;
			$clean['unit']        = _ww_form_text( $field['unit'] ?? '', 20 );
			break;
		case 'text':
			$clean['placeholder'] = _ww_form_text( $field['placeholder'] ?? '', 200 );
			$clean['max_length']  = _ww_form_int( $field['max_length'] ?? null, 1, 20000, 5000 );
			break;
		case 'select':
			$clean['empty_option'] = _ww_form_text( $field['empty_option'] ?? '', 200 );
			$clean['options']      = _ww_form_sanitize_options( $field['options'] ?? array() );
			break;
		case 'choice':
			$clean['multiple'] = _ww_form_bool( $field['multiple'] ?? null, false );
			$clean['options']  = _ww_form_sanitize_options( $field['options'] ?? array() );
			break;
		case 'file':
			$accept = array_map( 'strval', array_filter( _ww_form_array( $field['accept'] ?? array() ), 'is_scalar' ) );
			$accept = array_values( array_intersect( array_keys( _ww_form_file_groups() ), $accept ) );

			$clean['accept']      = $accept ? $accept : array( 'documents' );
			$clean['max_size_mb'] = min( _ww_form_file_max_mb(), _ww_form_int( $field['max_size_mb'] ?? null, 1, 20, 5 ) );
			$clean['max_files']   = _ww_form_int( $field['max_files'] ?? null, 1, 5, 1 );
			break;
	}
	return $clean;
}

/**
 * De groepen bestandstypen voor een uploadveld: sleutel => label en extensies. Na het filter ww_form_file_groups
 * (voor een child-thema) valt elke extensie weg die WordPress niet kent (get_allowed_mime_types()) of die gevaarlijk
 * is: svg, svgz, html, htm, php*, phtml, js en exe. Een groep zonder extensies valt weg.
 *
 * @return array<string,array{label: string, ext: list<string>}>
 */
function _ww_form_file_groups(): array {
	$groups = array(
		'documents'    => array(
			'label' => __( 'Documenten', 'webwerckt-base' ),
			'ext'   => array( 'pdf', 'doc', 'docx', 'odt' ),
		),
		'images'       => array(
			'label' => __( 'Afbeeldingen', 'webwerckt-base' ),
			'ext'   => array( 'jpg', 'jpeg', 'png', 'webp', 'heic' ),
		),
		'spreadsheets' => array(
			'label' => __( 'Spreadsheets', 'webwerckt-base' ),
			'ext'   => array( 'xls', 'xlsx', 'ods', 'csv' ),
		),
	);

	/**
	 * Filtert de groepen bestandstypen van een uploadveld. Gevaarlijke en onbekende extensies, en extensies die niet
	 * 2 tot 5 letters of cijfers lang zijn, worden daarna alsnog verwijderd.
	 *
	 * @param array<mixed> $groups Sleutel => array( label => string, ext => lijst extensies ).
	 */
	$groups = apply_filters( 'ww_form_file_groups', $groups );

	$known = _ww_form_allowed_mimes();
	$clean = array();
	foreach ( $groups as $key => $group ) {
		if ( ! is_string( $key ) || '' === $key || ! is_array( $group ) ) {
			continue;
		}
		$exts = array();
		foreach ( _ww_form_array( $group['ext'] ?? array() ) as $ext ) {
			$ext = strtolower( ltrim( _ww_form_string( $ext ), '.' ) );
			// 2 tot 5 tekens: de download en de bijlage vinden alleen namen als `{32 hex}.{ext}` met zo'n extensie.
			if ( 1 !== preg_match( '/^[a-z0-9]{2,5}$/', $ext ) || isset( $exts[ $ext ] ) || ! isset( $known[ $ext ] ) ) {
				continue;
			}
			if ( str_starts_with( $ext, 'php' ) || in_array( $ext, array( 'svg', 'svgz', 'html', 'htm', 'phtml', 'js', 'exe' ), true ) ) {
				continue;
			}
			$exts[ $ext ] = $ext;
		}
		if ( $exts ) {
			$clean[ $key ] = array(
				'label' => _ww_form_string( $group['label'] ?? $key ),
				'ext'   => array_values( $exts ),
			);
		}
	}
	return $clean;
}

/**
 * Alle extensies uit get_allowed_mime_types(), los en in kleine letters, met hun mimetype.
 *
 * @return array<string,string> Extensie => mimetype.
 */
function _ww_form_allowed_mimes(): array {
	$allowed = array();
	foreach ( get_allowed_mime_types() as $pattern => $mime ) {
		foreach ( explode( '|', (string) $pattern ) as $ext ) {
			$allowed[ strtolower( $ext ) ] = $mime;
		}
	}
	return $allowed;
}

/**
 * De extensies met hun mimetype voor de groepen van een uploadveld, uit get_allowed_mime_types(); de input voor
 * wp_check_filetype_and_ext().
 *
 * @param array<string,mixed> $field Opgeschoond bestandsveld.
 * @return array<string,string> Extensie => mimetype.
 */
function _ww_form_file_mimes( array $field ): array {
	$groups  = _ww_form_file_groups();
	$allowed = _ww_form_allowed_mimes();
	$mimes   = array();
	foreach ( _ww_form_array( $field['accept'] ?? array() ) as $group ) {
		foreach ( $groups[ $group ]['ext'] ?? array() as $ext ) {
			if ( isset( $allowed[ $ext ] ) ) {
				$mimes[ $ext ] = $allowed[ $ext ];
			}
		}
	}
	return $mimes;
}

/**
 * De grootste toegestane bestandsgrootte van de server in hele MB (naar beneden afgerond, minstens 1).
 */
function _ww_form_file_max_mb(): int {
	return max( 1, (int) floor( wp_max_upload_size() / MB_IN_BYTES ) );
}

/**
 * Heeft de configuratie een bestandsveld?
 *
 * @param array<string,mixed> $config Configuratie.
 */
function _ww_form_has_file_field( array $config ): bool {
	foreach ( _ww_form_array( $config['fields'] ?? array() ) as $field ) {
		if ( is_array( $field ) && 'file' === ( $field['type'] ?? '' ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Schoont de opties van een keuzeveld op: hoogstens 100, elk met een unieke value (regels van een sleutel) en een
 * label. Een optie zonder label en value valt weg.
 *
 * @param mixed $options Invoer.
 * @return list<array{value: string, label: string}>
 */
function _ww_form_sanitize_options( $options ): array {
	$clean  = array();
	$values = array();
	foreach ( _ww_form_array( $options ) as $option ) {
		if ( count( $clean ) >= 100 ) {
			break;
		}
		if ( ! is_array( $option ) ) {
			continue;
		}
		$label = _ww_form_text( $option['label'] ?? '', 200 );
		$value = _ww_form_string( $option['value'] ?? '' );
		if ( '' === $label && '' === $value ) {
			continue;
		}
		$value    = _ww_form_key( '' !== $value ? $value : $label, $values );
		$values[] = $value;
		$clean[]  = array(
			'value' => $value,
			'label' => '' !== $label ? $label : $value,
		);
	}
	return $clean;
}

/**
 * Schoont de stappen op (regels 1-7 van de spec): `from` is een veldsleutel of een positie in de invoer van `fields`,
 * onbekende starts vallen weg, de rest wordt gesorteerd op veldpositie, de eerste stap begint bij het eerste veld,
 * hoogstens 10 stappen, en één stap of minder is geen stappenformulier.
 *
 * @param mixed                     $steps     Invoer.
 * @param list<array<string,mixed>> $fields    Opgeschoonde velden.
 * @param array<int,string>         $positions Invoerpositie in fields => opgeschoonde veldsleutel (alleen velden die bleven).
 * @param list<string>              $warnings  Waarschuwingen; er komen er bij.
 * @return list<array{key: string, title: string, from: string}>
 */
function _ww_form_sanitize_steps( $steps, array $fields, array $positions, array &$warnings ): array {
	if ( ! is_array( $steps ) || ! $fields ) {
		return array();
	}
	$field_keys = array_column( $fields, 'key' );
	$input      = array_values( array_filter( $steps, 'is_array' ) );

	$found = array();
	foreach ( $input as $step ) {
		$from  = $step['from'] ?? '';
		$title = _ww_form_text( $step['title'] ?? '', 200 );
		if ( is_int( $from ) || ( is_string( $from ) && ctype_digit( $from ) ) ) {
			$from = $positions[ (int) $from ] ?? '';
		}
		$index = is_string( $from ) ? array_search( $from, $field_keys, true ) : false;
		if ( false === $index ) {
			$warnings[] = sprintf(
				/* translators: %s: titel van de stap. */
				__( 'Stap "%s" is weggelaten: het veld waar hij begint, bestaat niet.', 'webwerckt-base' ),
				'' !== $title ? $title : _ww_form_string( $step['from'] ?? '' )
			);
			continue;
		}
		if ( isset( $found[ $index ] ) ) {
			continue;
		}
		$found[ $index ] = array(
			'key'   => _ww_form_string( $step['key'] ?? '' ),
			'title' => $title,
		);
	}
	ksort( $found );

	if ( count( $found ) > 10 ) {
		$found      = array_slice( $found, 0, 10, true );
		$warnings[] = __( 'Een formulier heeft hoogstens 10 stappen; de rest is weggelaten.', 'webwerckt-base' );
	}

	if ( count( $found ) < 2 ) {
		if ( count( $input ) > 1 ) {
			$warnings[] = __( 'Een formulier met één stap is een gewoon formulier; de stappen zijn weggelaten.', 'webwerckt-base' );
		}
		return array();
	}

	// Eerst de meegestuurde sleutels vastleggen, pas daarna nieuwe maken: zo neemt een nieuwe stap nooit de sleutel
	// van een bestaande stap over die verderop staat.
	$keys = array();
	foreach ( $found as $index => $step ) {
		if ( '' !== $step['key'] ) {
			$keys[ $index ] = _ww_form_key( $step['key'], $keys, 'stap' );
		}
	}
	foreach ( $found as $index => $step ) {
		if ( ! isset( $keys[ $index ] ) ) {
			$keys[ $index ] = _ww_form_key( $step['title'], $keys, 'stap' );
		}
	}

	$clean = array();
	foreach ( $found as $index => $step ) {
		$clean[] = array(
			'key'   => $keys[ $index ],
			'title' => $step['title'],
			'from'  => $field_keys[ 0 === count( $clean ) ? 0 : $index ],
		);
	}
	return $clean;
}

/**
 * Verdeelt de velden over de stappen: elke stap loopt van zijn `from`-veld tot het veld vóór de volgende stap.
 *
 * @param array<string,mixed> $config Opgeschoonde configuratie.
 * @return list<array{step: array{key: string, title: string, from: string}, fields: list<array<string,mixed>>}>
 */
function _ww_form_step_groups( array $config ): array {
	$groups = array();
	foreach ( _ww_form_array( $config['steps'] ?? array() ) as $step ) {
		$groups[] = array(
			'step'   => $step,
			'fields' => array(),
		);
	}
	if ( ! $groups ) {
		return array();
	}
	$current = 0;
	foreach ( _ww_form_array( $config['fields'] ?? array() ) as $field ) {
		foreach ( $groups as $n => $group ) {
			if ( $group['step']['from'] === $field['key'] ) {
				$current = $n;
				break;
			}
		}
		$groups[ $current ]['fields'][] = $field;
	}
	return $groups;
}

/**
 * Of een veld een e-mailveld is (regel met input email), eventueel ook verplicht.
 *
 * @param list<array<string,mixed>> $fields   Opgeschoonde velden.
 * @param string                    $key      Veldsleutel.
 * @param bool                      $required Moet het veld verplicht zijn.
 */
function _ww_form_is_email_field( array $fields, string $key, bool $required ): bool {
	foreach ( $fields as $field ) {
		if ( $key === $field['key'] ) {
			return 'line' === $field['type'] && 'email' === $field['input'] && ( ! $required || $field['required'] );
		}
	}
	return false;
}

/**
 * De tags in een tekst, zonder dubbelen.
 *
 * @return list<string>
 */
function _ww_form_tags_in( string $text ): array {
	preg_match_all( '/\{([a-z][a-z0-9_]*)\}/', $text, $matches );
	return array_values( array_unique( $matches[1] ) );
}

/**
 * Schoont een configuratie op en geeft waarschuwingen (die blokkeren niets). Dé ingang voor alles wat een configuratie
 * opslaat: de builder, de ability en de tests. Ontbrekende delen krijgen de standaard.
 *
 * @param mixed $config Configuratie als array (uit json_decode( ..., true )).
 * @return array{config: array<string,mixed>, warnings: list<string>}
 */
function ww_form_sanitize( $config ): array {
	$default  = _ww_form_default_config();
	$warnings = array();
	if ( ! is_array( $config ) ) {
		$config = array();
	}

	$unknown_keys = array_diff( array_map( 'strval', array_keys( $config ) ), array_keys( $default ) );
	if ( $unknown_keys ) {
		$warnings[] = sprintf(
			/* translators: %s: lijst onderdelen, bijvoorbeeld "notify, success". */
			__( 'Deze onderdelen van de configuratie bestaan niet en zijn weggelaten: %s.', 'webwerckt-base' ),
			implode( ', ', array_map( 'sanitize_key', array_slice( array_values( $unknown_keys ), 0, 20 ) ) )
		);
	}

	// Velden.
	$fields = array();
	$taken  = array();
	$positions = array();
	foreach ( array_values( _ww_form_array( $config['fields'] ?? array() ) ) as $i => $field ) {
		if ( count( $fields ) >= 50 ) {
			break;
		}
		if ( is_array( $field ) ) {
			$raw   = $field;
			$field = _ww_form_sanitize_field( $field, $taken );
			if ( null !== $field && 'number' === $field['type']
				&& ( _ww_form_number_setting_invalid( $raw['min'] ?? null ) || _ww_form_number_setting_invalid( $raw['max'] ?? null ) || _ww_form_number_setting_invalid( $raw['step'] ?? null, true ) ) ) {
				$warnings[] = sprintf(
					/* translators: %s: label van het veld. */
					__( 'Bij het veld %s is een minimum, maximum of stapgrootte geen bruikbaar getal (hoogstens 15 cijfers, waarvan 6 na de komma); die instelling is weggelaten.', 'webwerckt-base' ),
					$field['label']
				);
			}
			if ( null !== $field ) {
				if ( 'number' === $field['type'] && null !== $field['min'] && null !== $field['max'] && $field['max'] < $field['min'] ) {
					$field['max'] = null;
					$warnings[]   = sprintf(
						/* translators: %s: label van het veld. */
						__( 'Bij het veld %s is het maximum kleiner dan het minimum; het maximum is weggelaten.', 'webwerckt-base' ),
						$field['label']
					);
				}
				$condition = _ww_form_sanitize_condition( $raw['condition'] ?? null, $fields, wp_strip_all_tags( $field['label'] ), $warnings );
				if ( null !== $condition ) {
					$field['condition'] = $condition;
				}
				$fields[]        = $field;
				$positions[ $i ] = $field['key'];
			}
		}
	}
	if ( ! $fields ) {
		$warnings[] = __( 'Dit formulier heeft geen velden en wordt niet weergegeven.', 'webwerckt-base' );
	}

	$steps = _ww_form_sanitize_steps( $config['steps'] ?? array(), $fields, $positions, $warnings );

	$submit_label = _ww_form_text( $config['submit_label'] ?? '', 200 );

	// Mail.
	$mail    = _ww_form_array( $config['mail'] ?? array() );
	$notify  = _ww_form_array( $mail['notify'] ?? array() ) + $default['mail']['notify'];
	$confirm = _ww_form_array( $mail['confirm'] ?? array() ) + $default['mail']['confirm'];

	$to = array();
	foreach ( explode( ',', _ww_form_string( $notify['to'] ) ) as $address ) {
		$address = sanitize_email( trim( $address ) );
		if ( '' !== $address && is_email( $address ) && ! in_array( $address, $to, true ) ) {
			$to[] = $address;
		}
	}
	$reply_to = _ww_form_string( $notify['reply_to_field'] );
	$notify   = array(
		'enabled'        => _ww_form_bool( $notify['enabled'], true ),
		'to'             => implode( ', ', $to ),
		'subject'        => _ww_form_text( $notify['subject'], 200 ),
		'body'           => mb_substr( sanitize_textarea_field( _ww_form_string( $notify['body'] ) ), 0, 10000 ),
		'reply_to_field' => _ww_form_is_email_field( $fields, $reply_to, false ) ? $reply_to : '',
	);

	$to_field = _ww_form_string( $confirm['to_field'] );
	$enabled  = _ww_form_bool( $confirm['enabled'], false );
	if ( ! _ww_form_is_email_field( $fields, $to_field, true ) ) {
		$to_field = '';
		if ( $enabled ) {
			$enabled    = false;
			$warnings[] = __( 'De bevestiging aan de inzender is uitgezet: kies als ontvanger een verplicht e-mailveld.', 'webwerckt-base' );
		}
	}
	if ( $enabled ) {
		foreach ( $fields as $candidate ) {
			if ( $candidate['key'] === $to_field && isset( $candidate['condition'] ) ) {
				$warnings[] = sprintf(
					/* translators: %s: label van het veld. */
					__( 'De bevestiging gaat naar het veld %s, en dat heeft een voorwaarde: is het verborgen, dan gaat er geen bevestiging uit.', 'webwerckt-base' ),
					wp_strip_all_tags( $candidate['label'] )
				);
			}
		}
	}
	$confirm = array(
		'enabled'  => $enabled,
		'to_field' => $to_field,
		'subject'  => _ww_form_text( $confirm['subject'], 200 ),
		'body'     => mb_substr( sanitize_textarea_field( _ww_form_string( $confirm['body'] ) ), 0, 10000 ),
	);

	// Na versturen.
	$after   = _ww_form_array( $config['after'] ?? array() ) + $default['after'];
	$page_id = _ww_form_int( $after['page_id'], 0, PHP_INT_MAX, 0 );
	$page    = $page_id ? get_post( $page_id ) : null;
	if ( ! $page || 'page' !== $page->post_type ) {
		$page    = null;
		$page_id = 0;
	}
	// Een volledige http(s)-URL of een pad met één / ervoor (//host is geen pad). De controle ook na esc_url_raw(),
	// want die maakt van /\/host, /%0a/host en /<tab>/host een //host.
	$pattern = '#^(https?://|/(?!/))#i';
	$url     = _ww_form_string( $after['url'] );
	$url     = preg_match( $pattern, $url ) ? mb_substr( esc_url_raw( $url, array( 'http', 'https' ) ), 0, 2048 ) : '';
	$url     = preg_match( $pattern, $url ) ? $url : '';
	$type = 'redirect' === $after['type'] ? 'redirect' : 'message';
	if ( 'redirect' === $type && $page && 'publish' !== $page->post_status ) {
		$warnings[] = sprintf(
			/* translators: %s: titel van de pagina. */
			__( 'Na versturen wordt doorgestuurd naar "%s", maar die pagina is niet gepubliceerd.', 'webwerckt-base' ),
			get_the_title( $page )
		);
	}
	if ( 'redirect' === $type && ! ( $page && 'publish' === $page->post_status ) && '' === $url ) {
		$type = 'message';
	}
	$after = array(
		'type'    => $type,
		'message' => _ww_form_kses(
			$after['message'],
			array(
				'a'      => array( 'href' => true ),
				'strong' => array(),
				'em'     => array(),
				'p'      => array(),
				'br'     => array(),
			),
			2000
		),
		'page_id' => $page_id,
		'url'     => $url,
	);

	// Opslag.
	$storage = _ww_form_array( $config['storage'] ?? array() ) + $default['storage'];

	$store = _ww_form_bool( $storage['store'], true );
	if ( ! $store && _ww_form_has_file_field( array( 'fields' => $fields ) ) ) {
		$store      = true;
		$warnings[] = __( 'Een formulier met een uploadveld slaat inzendingen altijd op.', 'webwerckt-base' );
	}

	// PDF van de inzending. Een sjabloonnaam volgt de regels van een veldsleutel (a-z, cijfers en _, begint met een letter, hoogstens 40 tekens; geen pad); de naam hoeft nog niet te bestaan.
	$pdf          = _ww_form_array( $config['pdf'] ?? array() ) + $default['pdf'];
	$pdf_template = _ww_form_string( $pdf['template'] );
	$pdf_template = 1 === preg_match( '/^[a-z][a-z0-9_]{0,39}\z/', $pdf_template ) ? $pdf_template : '';
	$pdf_filename = _ww_form_text( $pdf['filename'], 200 );
	if ( '' !== $pdf_template && function_exists( '_ww_form_pdf_template_file' ) && '' === _ww_form_pdf_template_file( $pdf_template ) ) {
		$warnings[] = sprintf(
			/* translators: %s: naam van het sjabloon. */
			__( 'Het PDF-sjabloon "%s" staat niet in het child-thema; de PDF gebruikt de standaardopmaak.', 'webwerckt-base' ),
			$pdf_template
		);
	}

	$clean = array(
		'version'      => 1,
		'fields'       => $fields,
		'steps'        => $steps,
		'recaptcha'    => _ww_form_bool( $config['recaptcha'] ?? null, true ),
		'submit_label' => '' !== $submit_label ? $submit_label : $default['submit_label'],
		'mail'         => array(
			'notify'  => $notify,
			'confirm' => $confirm,
		),
		'after'        => $after,
		'storage'      => array(
			'store'            => $store,
			'retention_months' => _ww_form_int( $storage['retention_months'], 1, 120, 12 ),
		),
		'pdf'          => array(
			'enabled'        => _ww_form_bool( $pdf['enabled'], false ),
			'template'       => $pdf_template,
			'filename'       => '' !== $pdf_filename ? $pdf_filename : $default['pdf']['filename'],
			'attach_notify'  => _ww_form_bool( $pdf['attach_notify'], true ),
			'attach_confirm' => _ww_form_bool( $pdf['attach_confirm'], false ),
		),
	);

	if ( ! $clean['storage']['store'] && ! $notify['enabled'] ) {
		$warnings[] = __( 'Inzendingen worden niet bewaard en er gaat geen melding uit: elke inzending mislukt. Zet het opslaan of de melding aan.', 'webwerckt-base' );
	}

	// Tags in de mails.
	$known   =array_merge( _ww_form_builtin_tags(), array_column( $fields, 'key' ) );
	$allowed = _ww_form_confirm_allowed( $clean );
	$unknown = array();
	foreach ( array( $notify['subject'], $notify['body'], $confirm['subject'], $confirm['body'] ) as $text ) {
		$unknown = array_merge( $unknown, array_diff( _ww_form_tags_in( $text ), $known ) );
	}
	$denied = array_diff( _ww_form_tags_in( $confirm['subject'] . "\n" . $confirm['body'] ), array_keys( $allowed ), $unknown );
	if ( $unknown ) {
		$warnings[] = sprintf(
			/* translators: %s: lijst tags, bijvoorbeeld "{naam}, {telefoon}". */
			__( 'De mail gebruikt tags van velden die niet bestaan: %s. Die blijven leeg.', 'webwerckt-base' ),
			'{' . implode( '}, {', array_unique( $unknown ) ) . '}'
		);
	}
	if ( $denied && ! _ww_form_recaptcha_active( $clean ) ) {
		$warnings[] = sprintf(
			/* translators: %s: lijst tags, bijvoorbeeld "{alle_velden}, {bericht}". */
			__( 'Deze tags mogen niet in de bevestiging aan de inzender en blijven daar leeg: %s.', 'webwerckt-base' ),
			'{' . implode( '}, {', $denied ) . '}'
		);
	}

	return array(
		'config'   => $clean,
		'warnings' => $warnings,
	);
}

/**
 * De tags die in de bevestiging aan de inzender mogen: tag => 'full', of 'short' voor een tekstregel (hoogstens 40
 * tekens en leeg als hij op een link of e-mailadres lijkt). Een bot kan elk adres invullen; daarom niet {alle_velden},
 * {pagina}, tekstvakken en e-mail- of telefoonregels.
 *
 * @param array<string,mixed> $config Opgeschoonde configuratie.
 * @return array<string,string>
 */
function _ww_form_confirm_allowed( array $config ): array {
	$allowed = array(
		'formulier' => 'full',
		'site'      => 'full',
		'datum'     => 'full',
	);
	foreach ( _ww_form_array( $config['fields'] ?? array() ) as $field ) {
		if ( in_array( $field['type'], array( 'select', 'choice', 'checkbox', 'number' ), true ) ) {
			$allowed[ $field['key'] ] = 'full';
		} elseif ( 'line' === $field['type'] && 'text' === $field['input'] ) {
			$allowed[ $field['key'] ] = 'short';
		}
	}
	return $allowed;
}

/**
 * Het bedankbericht na versturen; is het leeg (door de redacteur gewist), dan het standaardbericht.
 *
 * @param array<string,mixed> $config Opgeschoonde configuratie.
 */
function _ww_form_after_message( array $config ): string {
	$message = _ww_form_string( _ww_form_array( $config['after'] ?? array() )['message'] ?? '' );
	if ( '' === trim( wp_strip_all_tags( $message ) ) ) {
		$message = _ww_form_default_config()['after']['message'];
	}
	return $message;
}

/**
 * De configuratie van een formulier, opgeschoond; null als dit geen ww_form is.
 *
 * @return array<string,mixed>|null
 */
function _ww_form_config( int $form_id ): ?array {
	if ( WW_FORM_POST_TYPE !== get_post_type( $form_id ) ) {
		return null;
	}
	return ww_form_sanitize( get_post_meta( $form_id, WW_FORM_META, true ) )['config'];
}

/**
 * Schoont een configuratie op en bewaart hem als array. wp_slash, omdat update_post_meta() ook in arrays de
 * backslashes weghaalt.
 *
 * @param array<mixed> $config Configuratie.
 * @return list<string> Waarschuwingen.
 */
function _ww_form_save_config( int $form_id, array $config ): array {
	$result = ww_form_sanitize( $config );
	// Een vertaling krijgt getalinstellingen en voorwaarden uit het formulier in de standaardtaal (Meertalig).
	$source = _ww_form_logic_source( $form_id );
	$origin = $source > 0 ? _ww_form_config( $source ) : null;
	if ( null !== $origin ) {
		$locked = ww_form_sanitize( _ww_form_logic_apply( $result['config'], $origin ) );
		$result = array(
			'config'   => $locked['config'],
			'warnings' => array_values( array_unique( array_merge( $result['warnings'], $locked['warnings'] ) ) ),
		);
	}
	update_post_meta( $form_id, WW_FORM_META, wp_slash( $result['config'] ) );
	_ww_form_logic_sync( $form_id, $result['config'] );
	// Met een bestandsveld meteen de afgeschermde map, zodat de eerste uploads hem niet tegelijk hoeven te maken.
	if ( in_array( 'file', array_column( $result['config']['fields'], 'type' ), true ) ) {
		_ww_form_files_base( true );
	}
	return $result['warnings'];
}

/**
 * De leesbare waarde van een veld: het label van de optie(s) gescheiden door ", ", Ja of Nee bij een vinkje, anders
 * de tekst zelf, bij een bestandsveld de namen met grootte ("Cv Jan.pdf (178 KB)"). Een waarde die geen optie (meer)
 * is, blijft staan zoals hij is.
 *
 * @param array<string,mixed> $field Opgeschoond veld.
 * @param mixed               $value Waarde uit de inzending.
 */
function _ww_form_display_value( array $field, $value ): string {
	$type = $field['type'] ?? '';
	if ( 'checkbox' === $type ) {
		return '1' === _ww_form_string( $value ) ? __( 'Ja', 'webwerckt-base' ) : __( 'Nee', 'webwerckt-base' );
	}
	if ( 'number' === $type ) {
		$number = _ww_form_string( $value );
		return '' === $number ? '' : _ww_form_number_format( $number, $field );
	}
	if ( 'select' === $type || 'choice' === $type ) {
		$labels = array_column( _ww_form_array( $field['options'] ?? array() ), 'label', 'value' );
		$shown  = array();
		foreach ( is_array( $value ) ? $value : array( $value ) as $one ) {
			$one = _ww_form_string( $one );
			if ( '' !== $one ) {
				$shown[] = $labels[ $one ] ?? $one;
			}
		}
		return implode( ', ', $shown );
	}
	if ( 'file' === $type ) {
		$shown = array();
		foreach ( is_array( $value ) ? $value : array() as $item ) {
			$name = is_array( $item ) ? _ww_form_string( $item['name'] ?? '' ) : '';
			if ( '' !== $name ) {
				$size    = (int) ( $item['size'] ?? 0 );
				$shown[] = $size > 0 ? $name . ' (' . size_format( $size ) . ')' : $name;
			}
		}
		return implode( ', ', $shown );
	}
	return _ww_form_string( $value );
}

/**
 * Zoekt een formulier op ID of slug. Met Meertalig actief (beslissing 0043) wordt een slug in de standaardtaal
 * opgezocht en komt de vertaling in de huidige taal van de module als die gepubliceerd is
 * (_ww_form_translation_resolve()); in de uit-stand geeft een slug ook het formulier van de standaardtaal. Geeft 0 als
 * het geen gepubliceerd formulier met velden is.
 *
 * @param int|string $form Post-ID of slug.
 */
function _ww_form_resolve( int|string $form ): int {
	return _ww_form_resolve_config( $form )[0];
}

/**
 * Als _ww_form_resolve(), met de opgeschoonde configuratie erbij, zodat wie het formulier toont hem niet nog eens
 * opschoont. Niet gevonden: array( 0, null ).
 *
 * @param int|string $form Post-ID of slug.
 * @return array{0:int,1:array<string,mixed>|null} Formulier-ID en configuratie.
 */
function _ww_form_resolve_config( int|string $form ): array {
	$none      = array( 0, null );
	$languages = _ww_languages_active();
	if ( is_int( $form ) || ctype_digit( $form ) ) {
		$id = (int) $form;
	} else {
		$slug = sanitize_title( $form );
		if ( '' === $slug ) {
			return $none;
		}
		$args = array(
			// post_name__in en niet name: met name is de query enkelvoudig en laat WP_Query de tax_query hieronder weg.
			'post_name__in'    => array( $slug ),
			'post_type'        => WW_FORM_POST_TYPE,
			'post_status'      => 'publish',
			'posts_per_page'   => 1,
			'fields'           => 'ids',
			'no_found_rows'    => true,
			'suppress_filters' => true,
			'lang'             => '', // Met Meertalig: in alle talen zoeken; de vertaling komt hieronder.
		);
		// Ook in de uit-stand: een vertaling houdt de slug van de bron, dus zonder taalvoorwaarde kan de slug haar vinden.
		// Zonder taalterm hoort een formulier bij de standaardtaal, dus een site zonder termen merkt hier niets van.
		if ( taxonomy_exists( 'ww_language' ) && '' !== _ww_default_language() ) {
			$args['tax_query'] = _ww_languages_tax_query( _ww_default_language() ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- een formulier op slug, in de standaardtaal.
		}
		$ids = get_posts( $args );
		$id  = (int) ( $ids[0] ?? 0 );
	}
	if ( $id <= 0 ) {
		return $none;
	}

	if ( $languages ) {
		$id = _ww_form_translation_resolve( $id );
	}

	if ( 'publish' !== get_post_status( $id ) ) {
		return $none;
	}
	$config = _ww_form_config( $id );
	return $config && $config['fields'] ? array( $id, $config ) : $none;
}
