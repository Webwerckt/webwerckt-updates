<?php
/**
 * Redirects: het zijpaneel, de weergaven en hun inhoud (beslissing 0031).
 *
 * Het scherm heeft drie onderdelen (Redirects, 404-logboek, Importeren en exporteren) in een eigen zijpaneel naast het
 * WordPress-menu; op mobiel neemt een uitklapper het paneel over. Het formulier voor toevoegen en bewerken is een vierde
 * weergave binnen Redirects. De acties zelf staan in inc/redirects-admin.php.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * De onderdelen van het scherm, op slug (?tab=). De sleutel '404' is voor PHP een getal.
 *
 * @return array<int|string,string>
 */
function _ww_redirects_admin_sections(): array {
	return array(
		'redirects' => __( 'Redirects', 'webwerckt-base' ),
		'404'       => __( '404-logboek', 'webwerckt-base' ),
		'io'        => __( 'Importeren en exporteren', 'webwerckt-base' ),
	);
}

/**
 * De weergave van dit verzoek: list, form, 404 of io. Een onbekende tab is de lijst.
 */
function _ww_redirects_admin_view(): string {
	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- alleen een weergave kiezen.
	$tab = isset( $_GET['tab'] ) ? _ww_data_to_string( wp_unslash( $_GET['tab'] ) ) : '';
	if ( '404' === $tab ) {
		return '404';
	}
	if ( 'io' === $tab ) {
		return 'io';
	}
	$posted = _ww_redirects_admin_form();
	if ( ( null !== $posted && array() !== $posted ) || isset( $_GET['new'] ) || isset( $_GET['edit'] ) || isset( $_GET['source'] ) ) {
		return 'form';
	}
	// phpcs:enable
	return 'list';
}

/**
 * De aantallen voor het paneel en de weergaven.
 *
 * @return array{total:int,manual:int,import:int,slug:int,log:int,new404:int}
 */
function _ww_redirects_admin_counts(): array {
	global $wpdb;
	$counts = array(
		'total'  => 0,
		'manual' => 0,
		'import' => 0,
		'slug'   => 0,
		'log'    => 0,
		'new404' => 0,
	);
	$rows   = $wpdb->get_results( 'SELECT origin, COUNT(*) AS n FROM ' . _ww_redirects_table() . ' GROUP BY origin' ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_redirects_table().
	foreach ( (array) $rows as $row ) {
		$n                = (int) $row->n;
		$counts['total'] += $n;
		if ( in_array( $row->origin, array( 'manual', 'import', 'slug' ), true ) ) {
			$counts[ $row->origin ] += $n;
		}
	}
	$counts['log']    = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . _ww_404_log_table() ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_404_log_table().
	$counts['new404'] = _ww_404_log_new_count();
	return $counts;
}

/**
 * De stip en de tekst over het aantal actieve redirects.
 *
 * @param array<string,int> $counts Uit _ww_redirects_admin_counts().
 * @return string Geëscapete HTML.
 */
function _ww_redirects_render_status( array $counts ): string {
	if ( $counts['total'] > 0 ) {
		$dot   = 'ok';
		$label = sprintf(
			/* translators: %d: aantal redirects. */
			_n( '%d redirect actief', '%d redirects actief', $counts['total'], 'webwerckt-base' ),
			$counts['total']
		);
	} else {
		$dot   = 'none';
		$label = __( 'Nog geen redirects', 'webwerckt-base' );
	}
	return '<span class="ww-redirects-dot ww-redirects-dot--' . $dot . '" aria-hidden="true"></span>' . esc_html( $label );
}

/**
 * De onderdelen als lijst met links; het actieve krijgt aria-current. Twee vormen: panel (in het zijpaneel, met een
 * Dashicon) en menu (een uitklapper voor mobiel, met het actieve onderdeel in de summary).
 *
 * @param string            $active  Actief onderdeel (redirects, 404 of io).
 * @param array<string,int> $counts  Uit _ww_redirects_admin_counts().
 * @param string            $variant panel of menu.
 * @return string Geëscapete HTML.
 */
function _ww_redirects_render_nav( string $active, array $counts, string $variant ): string {
	$icons  = array(
		'redirects' => 'dashicons-list-view',
		'404'       => 'dashicons-editor-unlink',
		'io'        => 'dashicons-randomize',
	);
	$labels = _ww_redirects_admin_sections();
	$items  = '';
	foreach ( $labels as $slug => $label ) {
		$slug  = (string) $slug; // De sleutel '404' is voor PHP een getal.
		$url   = _ww_redirects_admin_url( 'redirects' === $slug ? array() : array( 'tab' => $slug ) );
		$count = '';
		if ( 'redirects' === $slug ) {
			$count = '<span class="ww-redirects-count">' . esc_html( number_format_i18n( $counts['total'] ) ) . '</span>';
		} elseif ( '404' === $slug ) {
			$count = $counts['new404'] > 0
				? '<span class="ww-redirects-count ww-redirects-count--warn">' . esc_html(
					sprintf(
						/* translators: %s: aantal nieuwe paden. */
						__( '%s nieuw', 'webwerckt-base' ),
						number_format_i18n( $counts['new404'] )
					)
				) . '</span>'
				: '<span class="ww-redirects-count">' . esc_html( number_format_i18n( $counts['log'] ) ) . '</span>';
		}
		$icon   = 'panel' === $variant ? '<span class="dashicons ' . esc_attr( $icons[ $slug ] ) . '" aria-hidden="true"></span>' : '';
		$items .= '<li><a href="' . esc_url( $url ) . '"' . ( $slug === $active ? ' aria-current="page"' : '' ) . '>' . $icon . '<span class="ww-redirects-nav__label">' . esc_html( $label ) . '</span>' . $count . '</a></li>';
	}
	if ( 'panel' === $variant ) {
		return '<ul class="ww-redirects-panel__nav">' . $items . '</ul>';
	}
	return '<details class="ww-redirects-menu"><summary><span>' . esc_html__( 'Onderdeel', 'webwerckt-base' ) . '</span> <b>' . esc_html( $labels[ $active ] ?? '' ) . '</b></summary><ul>' . $items . '</ul></details>';
}

/**
 * Het kaartje in het paneel: nieuwe kapotte links van de laatste week, of dat er geen zijn.
 *
 * @param array<string,int> $counts Uit _ww_redirects_admin_counts().
 * @return string Geëscapete HTML.
 */
function _ww_redirects_render_panel_card( array $counts ): string {
	if ( $counts['new404'] > 0 ) {
		$title = sprintf(
			/* translators: %s: aantal nieuwe kapotte links. */
			_n( '%s nieuwe kapotte link', '%s nieuwe kapotte links', $counts['new404'], 'webwerckt-base' ),
			number_format_i18n( $counts['new404'] )
		);
		$body  = '<p>' . esc_html__( "Deze week zochten bezoekers pagina's die niet bestaan.", 'webwerckt-base' ) . '</p>'
			. '<p><a href="' . esc_url( _ww_redirects_admin_url( array( 'tab' => '404' ) ) ) . '">' . esc_html__( 'Bekijk het 404-logboek', 'webwerckt-base' ) . '</a></p>';
	} else {
		$title = __( 'Geen kapotte links', 'webwerckt-base' );
		$body  = '<p>' . esc_html__( 'Bezoekers vonden de laatste week alles wat ze zochten.', 'webwerckt-base' ) . '</p>';
	}
	return '<div class="ww-redirects-panel__card"><p><strong>' . esc_html( $title ) . '</strong></p>' . $body . '</div>';
}

/**
 * De queryvariabelen van de lijst zoals hij nu getoond wordt (weergave, zoekterm en pagina), voor de links die terug
 * moeten naar dezelfde lijst.
 *
 * @return array<string,string>
 */
function _ww_redirects_list_args(): array {
	$args   = array( 'tab' => 'redirects' );
	$origin = WW_Redirects_List_Table::current_origin();
	if ( '' !== $origin ) {
		$args['origin'] = $origin;
	}
	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- alleen een link terug naar de lijst.
	$search = isset( $_GET['s'] ) ? sanitize_text_field( _ww_data_to_string( wp_unslash( $_GET['s'] ) ) ) : '';
	$paged   = isset( $_GET['paged'] ) ? absint( _ww_data_to_string( wp_unslash( $_GET['paged'] ) ) ) : 0;
	$orderby = isset( $_GET['orderby'] ) ? sanitize_key( _ww_data_to_string( wp_unslash( $_GET['orderby'] ) ) ) : '';
	$order   = isset( $_GET['order'] ) ? sanitize_key( _ww_data_to_string( wp_unslash( $_GET['order'] ) ) ) : '';
	// phpcs:enable
	if ( '' !== $search ) {
		$args['s'] = $search;
	}
	// De sortering mee, anders staat de regel na Verwijderen op een andere pagina en blijft de bevestiging weg.
	if ( in_array( $orderby, array( 'source', 'hits', 'last_hit' ), true ) ) {
		$args['orderby'] = $orderby;
	}
	if ( in_array( $order, array( 'asc', 'desc' ), true ) ) {
		$args['order'] = $order;
	}
	if ( $paged > 1 ) {
		$args['paged'] = (string) $paged;
	}
	return $args;
}

/**
 * De weergave Redirects: de weergaven per herkomst, zoeken en de tabel; zonder regels een uitnodiging om er een te
 * maken of een lijst te importeren.
 */
function _ww_redirects_render_list(): string {
	if ( 0 === _ww_redirects_admin_counts()['total'] ) {
		return '<div class="ww-redirects-empty">'
			. '<h2>' . esc_html__( 'Nog geen redirects', 'webwerckt-base' ) . '</h2>'
			. '<p>' . esc_html__( 'Een redirect stuurt bezoekers van een oude URL naar een nieuwe, zodat ze geen "niet gevonden" zien en Google de nieuwe pagina leert kennen.', 'webwerckt-base' ) . '</p>'
			. '<p>' . esc_html__( 'Verander je de URL van een pagina, dan maakt het thema de redirect zelf. Verhuis je een oude site? Importeer dan een lijst.', 'webwerckt-base' ) . '</p>'
			. '<p class="ww-redirects-buttons"><a class="button button-primary" href="' . esc_url( _ww_redirects_admin_url( array( 'tab' => 'redirects', 'new' => '1' ) ) ) . '">' . esc_html__( 'Redirect toevoegen', 'webwerckt-base' ) . '</a> '
			. '<a class="button" href="' . esc_url( _ww_redirects_admin_url( array( 'tab' => 'io' ) ) ) . '">' . esc_html__( 'Lijst importeren', 'webwerckt-base' ) . '</a></p>'
			. '</div>';
	}

	$table = new WW_Redirects_List_Table();
	$table->prepare_items();
	$origin  = WW_Redirects_List_Table::current_origin();
	$confirm = $table->confirm_id();
	$action  = _ww_redirects_admin_url( _ww_redirects_list_args() );

	ob_start();
	$table->views();

	echo '<form method="get">';
	echo '<input type="hidden" name="page" value="' . esc_attr( WW_REDIRECTS_SCREEN ) . '">';
	echo '<input type="hidden" name="tab" value="redirects">';
	if ( '' !== $origin ) {
		echo '<input type="hidden" name="origin" value="' . esc_attr( $origin ) . '">';
	}
	$table->search_box( __( 'Zoek op oude of nieuwe URL', 'webwerckt-base' ), 'ww-redirects' );
	echo '</form>';

	echo '<form method="post" action="' . esc_url( $action ) . '">';
	$table->display();
	// Na de tabel, zodat deze nonce die van de tabel zelf (bulk-…) overschrijft: ze delen de veldnaam _wpnonce.
	wp_nonce_field( 'ww_redirects_bulk-delete' );
	echo '</form>';

	if ( $confirm > 0 ) {
		// De knop "Ja, verwijderen" in de bevestigingsrij hoort via form= bij dit formulier.
		echo '<form id="ww-redirects-delete" method="post" action="' . esc_url( $action ) . '">';
		echo '<input type="hidden" name="ww_redirects_action" value="delete">';
		echo '<input type="hidden" name="id" value="' . esc_attr( (string) $confirm ) . '">';
		wp_nonce_field( 'ww_redirects_delete', '_wpnonce', false );
		echo '</form>';
	}
	return (string) ob_get_clean();
}

/**
 * Hoeveel pagina's en berichten de paginakiezer bij de nieuwe URL hoogstens voorstelt.
 */
const WW_REDIRECTS_TARGET_SUGGESTIONS = 300;

/**
 * De suggesties voor de nieuwe URL: eerst de gepubliceerde pagina's op titel, dan de gepubliceerde berichten van de
 * andere publieke berichttypes, de nieuwste eerst. Het pad is relatief aan home_url(), zoals een doelpad in een regel.
 *
 * @param int $limit Hoeveel hoogstens.
 * @return list<array{path:string,title:string}>
 */
function _ww_redirects_target_suggestions( int $limit = WW_REDIRECTS_TARGET_SUGGESTIONS ): array {
	if ( $limit < 1 ) {
		return array();
	}
	$pages = get_posts(
		array(
			'post_type'     => 'page',
			'post_status'   => 'publish',
			'orderby'       => 'title',
			'order'         => 'ASC',
			'numberposts'   => $limit,
			'fields'        => 'ids',
			'no_found_rows' => true,
		)
	);
	$ids   = array_map( 'intval', $pages );
	$left  = $limit - count( $ids );
	$types = array_values( array_diff( get_post_types( array( 'public' => true ) ), array( 'attachment', 'page' ) ) );
	if ( $left > 0 && array() !== $types ) {
		$posts = get_posts(
			array(
				'post_type'     => $types,
				'post_status'   => 'publish',
				'orderby'       => 'date',
				'order'         => 'DESC',
				'numberposts'   => $left,
				'fields'        => 'ids',
				'no_found_rows' => true,
			)
		);
		$ids   = array_merge( $ids, array_map( 'intval', $posts ) );
	}

	// Berichten en termen (voor de permalink) in één keer in de cache, niet per id in de lus.
	$prime = array_values( array_unique( array_filter( $ids ) ) );
	if ( array() !== $prime ) {
		_prime_post_caches( $prime, true, false );
	}

	$home  = untrailingslashit( (string) wp_parse_url( home_url(), PHP_URL_PATH ) );
	$list  = array();
	$seen  = array();
	foreach ( $ids as $id ) {
		$link = get_permalink( $id );
		if ( ! is_string( $link ) || '' === $link ) {
			continue;
		}
		$path = (string) wp_parse_url( $link, PHP_URL_PATH );
		if ( '' !== $home && str_starts_with( $path, $home ) ) {
			$path = substr( $path, strlen( $home ) );
		}
		$path = '' === $path ? '/' : $path;
		if ( isset( $seen[ $path ] ) ) {
			continue;
		}
		$seen[ $path ] = true;
		$title         = trim( wp_strip_all_tags( get_the_title( $id ) ) );
		$list[]        = array(
			'path'  => $path,
			'title' => '' === $title ? $path : html_entity_decode( $title, ENT_QUOTES, 'UTF-8' ),
		);
	}
	return $list;
}

/**
 * Of het formulier uit het 404-logboek kwam (?ww_from=404, of de bewaarde invoer na een fout).
 */
function _ww_redirects_form_from_log(): bool {
	$posted = _ww_redirects_admin_form();
	if ( null !== $posted && array() !== $posted ) {
		return '404' === ( $posted['from'] ?? '' );
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen de terugweg kiezen.
	return isset( $_GET['ww_from'] ) && '404' === _ww_data_to_string( wp_unslash( $_GET['ww_from'] ) );
}

/**
 * De waarden van het formulier: eerst de bewaarde invoer na een fout, dan de regel van ?edit=, dan de bron van
 * ?source= (Redirect maken in het 404-logboek).
 *
 * @return array{id:int,source:string,target:string,status:int,match_type:string}
 */
function _ww_redirects_form_values(): array {
	$values = array(
		'id'         => 0,
		'source'     => '',
		'target'     => '',
		'status'     => 301,
		'match_type' => 'exact',
	);
	$posted = _ww_redirects_admin_form();
	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- alleen een formulier vullen.
	if ( null !== $posted && array() !== $posted ) {
		$values = array(
			'id'         => (int) ( $posted['id'] ?? 0 ),
			'source'     => _ww_data_to_string( $posted['source'] ?? '' ),
			'target'     => _ww_data_to_string( $posted['target'] ?? '' ),
			'status'     => (int) ( $posted['status'] ?? 301 ),
			'match_type' => _ww_data_to_string( $posted['match_type'] ?? 'exact' ),
		);
	} elseif ( isset( $_GET['edit'] ) ) {
		$rule = _ww_redirects_admin_get( absint( _ww_data_to_string( wp_unslash( $_GET['edit'] ) ) ) );
		if ( null !== $rule ) {
			$values = array(
				'id'         => (int) $rule->id,
				'source'     => (string) $rule->source,
				'target'     => (string) $rule->target,
				'status'     => (int) $rule->status,
				'match_type' => (string) $rule->match_type,
			);
		}
	} elseif ( isset( $_GET['source'] ) ) {
		$values['source'] = trim( _ww_data_to_string( wp_unslash( $_GET['source'] ) ) );
	}
	// phpcs:enable
	if ( ! in_array( $values['status'], array( 301, 302, 410 ), true ) ) {
		$values['status'] = 301;
	}
	return $values;
}

/**
 * De weergave van het formulier (toevoegen of bewerken), in gewone taal: oude URL, wat er moet gebeuren, nieuwe URL en
 * een samenvatting die het script invult.
 */
function _ww_redirects_render_form(): string {
	$values   = _ww_redirects_form_values();
	$from_log = _ww_redirects_form_from_log();
	$editing  = $values['id'] > 0;
	$host     = (string) wp_parse_url( home_url(), PHP_URL_HOST );
	$back     = _ww_redirects_admin_url( $from_log ? array( 'tab' => '404' ) : array() );
	$html     = '';

	if ( $from_log && '' !== $values['source'] ) {
		$hits  = _ww_404_log_hits( $values['source'] );
		$path  = '<strong>' . esc_html( $values['source'] ) . '</strong>';
		$text  = $hits > 0
			? sprintf(
				/* translators: 1: pad, 2: aantal keer. */
				esc_html( _n( 'Bezoekers zochten %1$s %2$s keer tevergeefs. Kies waar ze heen moeten; na opslaan verdwijnt het pad uit het 404-logboek.', 'Bezoekers zochten %1$s %2$s keer tevergeefs. Kies waar ze heen moeten; na opslaan verdwijnt het pad uit het 404-logboek.', $hits, 'webwerckt-base' ) ),
				$path,
				esc_html( number_format_i18n( $hits ) )
			)
			: sprintf(
				/* translators: %s: pad. */
				esc_html__( 'Kies waar bezoekers van %s heen moeten.', 'webwerckt-base' ),
				$path
			);
		$html .= '<div class="notice notice-info inline"><p>' . $text . '</p></div>';
	}

	$html .= '<form method="post" class="ww-redirects-form" action="' . esc_url( _ww_redirects_admin_url( array( 'tab' => 'redirects' ) ) ) . '">';
	$html .= '<input type="hidden" name="ww_redirects_action" value="save">';
	$html .= '<input type="hidden" name="ww_id" value="' . esc_attr( (string) $values['id'] ) . '">';
	if ( $from_log ) {
		$html .= '<input type="hidden" name="ww_from" value="404">';
	}
	$html .= wp_nonce_field( 'ww_redirects_save', '_wpnonce', true, false );
	$html .= '<div class="ww-redirects-box"><table class="form-table" role="presentation"><tbody>';

	// Oude URL.
	$html .= '<tr><th scope="row"><label for="ww-source">' . esc_html__( 'Oude URL', 'webwerckt-base' ) . '</label></th><td>';
	$html .= '<span class="ww-redirects-prefixed"><span class="ww-redirects-host">' . esc_html( $host ) . '</span>';
	$html .= '<input type="text" id="ww-source" name="ww_source" class="regular-text code" required placeholder="/oude-pagina/" value="' . esc_attr( $values['source'] ) . '"></span>';
	$html .= '<p class="description">' . esc_html__( 'Het pad dat bezoekers nu nog gebruiken. Hoofdletters en alles na een ? tellen niet mee.', 'webwerckt-base' ) . '</p>';
	$html .= '<p class="ww-redirects-check"><label><input type="checkbox" name="ww_match_type" value="prefix"' . checked( $values['match_type'], 'prefix', false ) . '> ' . esc_html__( 'Ook alles eronder doorsturen', 'webwerckt-base' ) . '</label></p>';
	$html .= '<p class="description">' . esc_html__( 'Bijvoorbeeld /oud-portfolio/project-a/ en /oud-portfolio/project-b/ in één keer.', 'webwerckt-base' ) . '</p>';
	$html .= '</td></tr>';

	// Wat moet er gebeuren?
	$choices = array(
		301 => array( __( 'Permanent doorsturen (301)', 'webwerckt-base' ), __( 'De pagina is verhuisd en komt niet terug. Meestal de goede keuze.', 'webwerckt-base' ) ),
		302 => array( __( 'Tijdelijk doorsturen (302)', 'webwerckt-base' ), __( 'Bijvoorbeeld tijdens een actie of verbouwing. De oude pagina komt later terug.', 'webwerckt-base' ) ),
		410 => array( __( 'Pagina is weg (410)', 'webwerckt-base' ), __( 'Er is geen vervanger. Google haalt de pagina sneller uit de zoekresultaten dan bij "niet gevonden".', 'webwerckt-base' ) ),
	);
	$html   .= '<tr><th scope="row">' . esc_html__( 'Wat moet er gebeuren?', 'webwerckt-base' ) . '</th><td><fieldset><legend class="screen-reader-text">' . esc_html__( 'Wat moet er gebeuren?', 'webwerckt-base' ) . '</legend>';
	foreach ( $choices as $code => $choice ) {
		$html .= '<label class="ww-redirects-choice"><input type="radio" name="ww_status" value="' . esc_attr( (string) $code ) . '"' . checked( $values['status'], $code, false ) . '>';
		$html .= '<span><span class="ww-redirects-choice__label">' . esc_html( $choice[0] ) . '</span><span class="ww-redirects-choice__hint">' . esc_html( $choice[1] ) . '</span></span></label>';
	}
	$html .= '</fieldset></td></tr>';

	// Nieuwe URL.
	$html .= '<tr><th scope="row"><label for="ww-target">' . esc_html__( 'Nieuwe URL', 'webwerckt-base' ) . '</label></th><td>';
	// De paginakiezer: de eigen suggestielijst van de browser. Het veld blijft een gewoon tekstveld.
	$suggestions = _ww_redirects_target_suggestions();
	$datalist    = '';
	foreach ( $suggestions as $suggestion ) {
		$datalist .= '<option value="' . esc_attr( $suggestion['path'] ) . '" label="' . esc_attr( $suggestion['title'] ) . '">' . esc_html( $suggestion['title'] ) . '</option>';
	}
	$html .= '<input type="text" id="ww-target" name="ww_target" class="regular-text code"' . ( '' === $datalist ? '' : ' list="ww-target-pages"' ) . ' autocomplete="off" placeholder="' . esc_attr__( 'Typ een paginanaam of /pad/', 'webwerckt-base' ) . '" value="' . esc_attr( $values['target'] ) . '">';
	if ( '' !== $datalist ) {
		$html .= '<datalist id="ww-target-pages">' . $datalist . '</datalist>';
	}
	$html .= '<p class="description">' . esc_html__( 'Kies een pagina van deze site, of plak een volledige URL naar een andere site. Leeg bij Pagina is weg.', 'webwerckt-base' ) . '</p>';
	$html .= '</td></tr>';

	$html .= '</tbody></table>';
	$html .= '<p id="ww-redirect-summary" class="ww-redirects-summary" hidden></p>';
	$html .= '</div>';

	$html .= '<p class="submit ww-redirects-buttons"><button type="submit" class="button button-primary">' . esc_html( $editing ? __( 'Wijzigingen opslaan', 'webwerckt-base' ) : __( 'Redirect opslaan', 'webwerckt-base' ) ) . '</button> ';
	$html .= '<a class="button" href="' . esc_url( $back ) . '">' . esc_html__( 'Annuleren', 'webwerckt-base' ) . '</a></p>';
	$html .= '</form>';
	return $html;
}

/**
 * De weergave 404-logboek: inleiding, zoeken, de tabel, de uitleg bij "eigen site" en Logboek leegmaken (een
 * uitklapper met een bevestiging, zonder script).
 */
function _ww_redirects_render_log(): string {
	$table = new WW_404_Log_List_Table();
	$table->prepare_items();
	$log  = _ww_redirects_admin_counts()['log'];
	$here = _ww_redirects_admin_url( array( 'tab' => '404' ) );

	ob_start();
	echo '<p class="ww-redirects-intro">' . esc_html__( "URL's op deze site die bezoekers probeerden en die niet bestaan, de laatste 30 dagen. Bots tellen niet mee. Maak van een pad een redirect, dan verdwijnt het hier vanzelf.", 'webwerckt-base' ) . '</p>';

	echo '<form method="get">';
	echo '<input type="hidden" name="page" value="' . esc_attr( WW_REDIRECTS_SCREEN ) . '">';
	echo '<input type="hidden" name="tab" value="404">';
	$table->search_box( __( 'Zoek op pad', 'webwerckt-base' ), 'ww-404-log' );
	echo '</form>';

	echo '<form method="post" action="' . esc_url( $here ) . '">';
	$table->display();
	// Na de tabel, zodat deze nonce die van de tabel zelf (bulk-…) overschrijft: ze delen de veldnaam _wpnonce.
	wp_nonce_field( 'ww_redirects_log-bulk-delete' );
	echo '</form>';

	if ( $table->has_internal ) {
		echo '<p class="ww-redirects-note">' . sprintf(
			/* translators: %s: het label "eigen site". */
			esc_html__( '%s betekent dat een link op je eigen site naar een pagina wijst die niet bestaat. Een redirect helpt, maar de link zelf aanpassen is beter.', 'webwerckt-base' ),
			'<strong>' . esc_html__( 'eigen site', 'webwerckt-base' ) . '</strong>'
		) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hierboven geëscapet.
	}

	if ( $log > 0 ) {
		// Buiten het bulkformulier: een formulier in een formulier laat de browser weg.
		echo '<details class="ww-redirects-confirm"><summary class="button-link button-link-delete">' . esc_html__( 'Logboek leegmaken…', 'webwerckt-base' ) . '</summary>';
		echo '<div class="ww-redirects-confirm__body"><p>' . esc_html(
			sprintf(
				/* translators: %s: aantal paden. */
				_n( '%s pad uit het logboek halen? Komt een bezoeker er opnieuw op, dan verschijnt het pad weer.', 'Alle %s paden uit het logboek halen? Komt een bezoeker er opnieuw op, dan verschijnt het pad weer.', $log, 'webwerckt-base' ),
				number_format_i18n( $log )
			)
		) . '</p>';
		echo '<form method="post" action="' . esc_url( $here ) . '">';
		echo '<input type="hidden" name="ww_redirects_action" value="log-clear">';
		wp_nonce_field( 'ww_redirects_log-clear', '_wpnonce', true );
		echo '<button type="submit" class="button button-primary">' . esc_html__( 'Ja, leegmaken', 'webwerckt-base' ) . '</button> ';
		echo '<a class="button-link" href="' . esc_url( $here ) . '">' . esc_html__( 'Annuleren', 'webwerckt-base' ) . '</a>';
		echo '</form></div></details>';
	}
	return (string) ob_get_clean();
}

/**
 * De stappen van de import bovenaan het vak: 1 Bestand kiezen, 2 Controleren, 3 Klaar.
 *
 * @param int $current Huidige stap, 1 tot en met 3.
 * @return string Geëscapete HTML.
 */
function _ww_redirects_render_steps( int $current ): string {
	$steps = array(
		1 => __( 'Bestand kiezen', 'webwerckt-base' ),
		2 => __( 'Controleren', 'webwerckt-base' ),
		3 => __( 'Klaar', 'webwerckt-base' ),
	);
	$html  = '<ol class="ww-redirects-steps">';
	foreach ( $steps as $number => $label ) {
		$state = $number < $current || 3 === $current ? 'done' : ( $number === $current ? 'current' : 'todo' );
		$html .= '<li class="is-' . $state . '"' . ( $number === $current ? ' aria-current="step"' : '' ) . '><span class="ww-redirects-steps__dot" aria-hidden="true">' . ( 'done' === $state ? '✓' : esc_html( (string) $number ) ) . '</span>' . esc_html( $label ) . '</li>';
	}
	return $html . '</ol>';
}

/**
 * Stap 2 van de import: per regel wat er zou gebeuren, met een knop om het echt te doen.
 *
 * @return string Geëscapete HTML.
 */
function _ww_redirects_render_import_preview(): string {
	$here  = _ww_redirects_admin_url( array( 'tab' => 'io' ) );
	$rules = get_transient( 'ww_redirects_import_' . get_current_user_id() );
	if ( ! is_array( $rules ) ) {
		return '<div class="notice notice-warning inline"><p>' . esc_html__( 'Het voorbeeld is verlopen: kies het bestand opnieuw.', 'webwerckt-base' ) . '</p></div>'
			. '<p><a class="button" href="' . esc_url( $here ) . '">' . esc_html__( 'Opnieuw beginnen', 'webwerckt-base' ) . '</a></p>';
	}

	$result = _ww_redirects_import( $rules, true );
	$totals = $result['totals'];
	$rows   = count( $result['rows'] );
	$chips  = array(
		/* translators: %s: aantal nieuwe regels. */
		'new'       => array( 'good', _n( '%s nieuw', '%s nieuw', $totals['new'], 'webwerckt-base' ) ),
		/* translators: %s: aantal regels dat wordt bijgewerkt. */
		'update'    => array( 'info', _n( '%s bijwerken', '%s bijwerken', $totals['update'], 'webwerckt-base' ) ),
		/* translators: %s: aantal ongewijzigde regels. */
		'unchanged' => array( 'plain', _n( '%s ongewijzigd', '%s ongewijzigd', $totals['unchanged'], 'webwerckt-base' ) ),
		/* translators: %s: aantal regels met een fout. */
		'error'     => array( 'bad', _n( '%s met een fout', '%s met een fout', $totals['error'], 'webwerckt-base' ) ),
	);
	$labels = array(
		'new'       => array( 'good', __( 'Nieuw', 'webwerckt-base' ) ),
		'update'    => array( 'info', __( 'Bijwerken', 'webwerckt-base' ) ),
		'unchanged' => array( 'plain', __( 'Ongewijzigd', 'webwerckt-base' ) ),
		'error'     => array( 'bad', __( 'Fout', 'webwerckt-base' ) ),
	);

	$html  = '<p>' . esc_html(
		sprintf(
			/* translators: %s: aantal regels. */
			_n( '%s regel gelezen. Er is nog niets opgeslagen.', '%s regels gelezen. Er is nog niets opgeslagen.', $rows, 'webwerckt-base' ),
			number_format_i18n( $rows )
		)
	) . '</p>';
	$html .= '<p class="ww-redirects-chips">';
	foreach ( $chips as $key => $chip ) {
		$html .= '<span class="ww-redirects-chip ww-redirects-chip--' . $chip[0] . '">' . esc_html( sprintf( $chip[1], number_format_i18n( $totals[ $key ] ) ) ) . '</span> ';
	}
	$html .= '</p>';

	$html .= '<table class="widefat striped ww-redirects-preview"><thead><tr><th scope="col">' . esc_html__( 'Regel', 'webwerckt-base' ) . '</th><th scope="col">' . esc_html__( 'Oude URL', 'webwerckt-base' ) . '</th><th scope="col">' . esc_html__( 'Wat er gebeurt', 'webwerckt-base' ) . '</th></tr></thead><tbody>';
	foreach ( array_slice( $result['rows'], 0, 200, true ) as $index => $row ) {
		$line   = (int) ( $rules[ $index ]['line'] ?? 0 );
		$label  = $labels[ $row['result'] ] ?? array( 'plain', (string) $row['result'] );
		$reason = (string) ( $row['message'] ?? '' );
		$html  .= '<tr><td>' . esc_html( (string) $line ) . '</td><td><code>' . esc_html( (string) $row['source'] ) . '</code></td><td><span class="ww-redirects-chip ww-redirects-chip--' . $label[0] . '">' . esc_html( $label[1] ) . '</span>'
			. ( '' === $reason ? '' : '<span class="ww-redirects-reason">' . esc_html( $reason ) . '</span>' ) . '</td></tr>';
	}
	$html .= '</tbody></table>';
	if ( $rows > 200 ) {
		$html .= '<p>' . esc_html(
			sprintf(
				/* translators: %d: aantal regels dat niet getoond wordt. */
				__( '... en nog %d regels.', 'webwerckt-base' ),
				$rows - 200
			)
		) . '</p>';
	}

	$apply = $totals['new'] + $totals['update'];
	$html .= '<form method="post" class="ww-redirects-buttons ww-redirects-apply" action="' . esc_url( $here ) . '">';
	if ( $apply > 0 ) {
		$html .= '<input type="hidden" name="ww_redirects_action" value="import-apply">';
		$html .= wp_nonce_field( 'ww_redirects_import-apply', '_wpnonce', true, false );
		$html .= '<button type="submit" class="button button-primary">' . esc_html(
			sprintf(
				/* translators: %s: aantal regels dat wordt opgeslagen. */
				_n( '%s regel importeren', '%s regels importeren', $apply, 'webwerckt-base' ),
				number_format_i18n( $apply )
			)
		) . '</button> ';
	}
	$html .= '<a class="button-link" href="' . esc_url( $here ) . '">' . esc_html__( 'Annuleren', 'webwerckt-base' ) . '</a>';
	if ( $totals['error'] > 0 ) {
		$html .= '<span class="ww-redirects-muted ww-redirects-apply__note">' . esc_html__( 'Regels met een fout worden overgeslagen.', 'webwerckt-base' ) . '</span>';
	}
	$html .= '</form>';
	return $html;
}

/**
 * De weergave Importeren en exporteren: twee vakken naast elkaar. Importeren gaat in drie stappen (?ww_import=preview
 * is stap 2, ?ww_imported=1 stap 3).
 */
function _ww_redirects_render_io(): string {
	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- alleen een stap kiezen.
	$step = 1;
	if ( isset( $_GET['ww_import'] ) && 'preview' === $_GET['ww_import'] ) {
		$step = 2;
	} elseif ( isset( $_GET['ww_imported'] ) && '1' === $_GET['ww_imported'] ) {
		$step = 3;
	}
	// phpcs:enable
	$here  = _ww_redirects_admin_url( array( 'tab' => 'io' ) );
	$total = _ww_redirects_admin_counts()['total'];

	$html  = '<div class="ww-redirects-io">';
	$html .= '<section class="ww-redirects-box ww-redirects-io__import"><h2>' . esc_html__( 'Importeren', 'webwerckt-base' ) . '</h2>';
	$html .= _ww_redirects_render_steps( $step );

	if ( 2 === $step ) {
		$html .= _ww_redirects_render_import_preview();
	} elseif ( 3 === $step ) {
		$html .= '<p>' . esc_html__( 'De import is klaar. De nieuwe redirects staan in de lijst met herkomst Import.', 'webwerckt-base' ) . '</p>';
		$html .= '<p class="ww-redirects-buttons"><a class="button button-primary" href="' . esc_url(
			_ww_redirects_admin_url(
				array(
					'tab'    => 'redirects',
					'origin' => 'import',
				)
			)
		) . '">' . esc_html__( 'Bekijk de geïmporteerde redirects', 'webwerckt-base' ) . '</a> ';
		$html .= '<a class="button-link" href="' . esc_url( $here ) . '">' . esc_html__( 'Nog een bestand importeren', 'webwerckt-base' ) . '</a></p>';
	} else {
		$html .= '<p>' . esc_html__( "Verhuis je een oude site? Zet de oude en nieuwe URL's in een CSV-bestand. Je ziet eerst wat er gebeurt; er wordt pas iets opgeslagen als je dat bevestigt.", 'webwerckt-base' ) . '</p>';
		$html .= '<form method="post" enctype="multipart/form-data" action="' . esc_url( $here ) . '">';
		$html .= '<input type="hidden" name="ww_redirects_action" value="import-preview">';
		$html .= wp_nonce_field( 'ww_redirects_import-preview', '_wpnonce', true, false );
		$html .= '<div class="ww-redirects-file"><label for="ww-csv">' . esc_html__( 'CSV-bestand', 'webwerckt-base' ) . '</label> <input type="file" id="ww-csv" name="ww_csv" accept=".csv,text/csv"></div>';
		$html .= '<details class="ww-redirects-more"><summary>' . esc_html__( 'Of plak de regels', 'webwerckt-base' ) . '</summary>';
		$html .= '<label class="screen-reader-text" for="ww-csv-text">' . esc_html__( 'De regels', 'webwerckt-base' ) . '</label>';
		$html .= '<textarea id="ww-csv-text" name="ww_csv_text" rows="5" class="large-text code" placeholder="/oud/,/nieuw/,301"></textarea></details>';
		$html .= '<details class="ww-redirects-more"><summary>' . esc_html__( 'Hoe ziet het bestand eruit?', 'webwerckt-base' ) . '</summary>';
		$html .= '<pre class="ww-redirects-example">bron,doel,status,type' . "\n" . '/oud/home.html,/,301' . "\n" . '/oud/blog/,/blog/,301,prefix' . "\n" . '/oud/vacature.html,,410</pre>';
		$html .= '<p class="description">' . esc_html__( 'Status (301, 302 of 410) en type (exact of prefix) mogen leeg blijven: dan wordt het 301 en exact. Komma of puntkomma, UTF-8, hoogstens 5000 regels.', 'webwerckt-base' ) . '</p></details>';
		$html .= '<p class="ww-redirects-buttons"><button type="submit" class="button button-primary">' . esc_html__( 'Controleren', 'webwerckt-base' ) . '</button></p>';
		$html .= '</form>';
	}
	$html .= '</section>';

	$html .= '<section class="ww-redirects-box ww-redirects-io__export"><h2>' . esc_html__( 'Exporteren', 'webwerckt-base' ) . '</h2>';
	$html .= '<p>' . esc_html(
		sprintf(
			/* translators: %s: aantal redirects. */
			_n( 'Alle %s redirect als CSV, in hetzelfde formaat als de import. Handig als back-up of om naar een andere site over te zetten.', 'Alle %s redirects als CSV, in hetzelfde formaat als de import. Handig als back-up of om naar een andere site over te zetten.', $total, 'webwerckt-base' ),
			number_format_i18n( $total )
		)
	) . '</p>';
	$html .= '<p class="ww-redirects-buttons">' . ( $total > 0
		? '<a class="button" href="' . esc_url( _ww_redirects_admin_action_url( 'export' ) ) . '">' . esc_html__( 'CSV downloaden', 'webwerckt-base' ) . '</a>'
		: '<button type="button" class="button" disabled>' . esc_html__( 'CSV downloaden', 'webwerckt-base' ) . '</button>' ) . '</p>';
	$html .= '<p class="ww-redirects-filename">' . esc_html( _ww_redirects_export_filename() ) . '</p>';
	$html .= '</section></div>';
	return $html;
}

/**
 * Of het formulier een bestaande regel bewerkt (na een fout bij opslaan, of met ?edit= van een regel die bestaat).
 */
function _ww_redirects_admin_editing(): bool {
	$posted = _ww_redirects_admin_form();
	if ( null !== $posted && array() !== $posted ) {
		return (int) ( $posted['id'] ?? 0 ) > 0;
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen een titel kiezen.
	return isset( $_GET['edit'] ) && null !== _ww_redirects_admin_get( absint( _ww_data_to_string( wp_unslash( $_GET['edit'] ) ) ) );
}

/**
 * Toont het scherm: het zijpaneel en de gekozen weergave.
 */
function _ww_redirects_admin_render(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
	require_once __DIR__ . '/class-ww-redirects-list-table.php';
	require_once __DIR__ . '/class-ww-404-log-list-table.php';

	$view    = _ww_redirects_admin_view();
	$section = in_array( $view, array( '404', 'io' ), true ) ? $view : 'redirects';
	$counts  = _ww_redirects_admin_counts();
	$status  = _ww_redirects_render_status( $counts );

	if ( 'form' === $view ) {
		$title = _ww_redirects_admin_editing() ? __( 'Redirect bewerken', 'webwerckt-base' ) : __( 'Redirect toevoegen', 'webwerckt-base' );
	} else {
		$title = _ww_redirects_admin_sections()[ $section ];
	}

	// De weergave eerst: de tabellen lezen hun query vóór de kop er staat, en zo staat alles in één volgorde.
	$renderers = array(
		'list' => '_ww_redirects_render_list',
		'form' => '_ww_redirects_render_form',
		'404'  => '_ww_redirects_render_log',
		'io'   => '_ww_redirects_render_io',
	);
	$content   = $renderers[ $view ]();

	echo '<div class="wrap ww-redirects"><div class="ww-redirects-layout">';

	echo '<nav class="ww-redirects-panel" aria-label="' . esc_attr__( 'Onderdelen van Redirects', 'webwerckt-base' ) . '">';
	echo '<p class="ww-redirects-panel__title">' . esc_html__( 'Redirects', 'webwerckt-base' ) . '</p>';
	echo '<p class="ww-redirects-panel__status">' . $status . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_redirects_render_status() escapet.
	echo _ww_redirects_render_nav( $section, $counts, 'panel' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_redirects_render_nav() escapet.
	echo _ww_redirects_render_panel_card( $counts ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_redirects_render_panel_card() escapet.
	echo '<p class="ww-redirects-panel__foot"><span class="dashicons dashicons-info-outline" aria-hidden="true"></span><span>' . esc_html__( 'Verander je de URL van een pagina, dan maakt het thema zelf een redirect van de oude URL.', 'webwerckt-base' ) . '</span></p>';
	echo '</nav>';

	echo '<div class="ww-redirects-main">';
	if ( 'form' === $view ) {
		echo _ww_redirects_render_back_link(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_redirects_render_back_link() escapet.
	}
	echo '<h1 class="wp-heading-inline">' . esc_html( $title ) . '</h1>';
	if ( 'list' === $view && $counts['total'] > 0 ) {
		echo ' <a class="page-title-action" href="' . esc_url( _ww_redirects_admin_url( array( 'tab' => 'redirects', 'new' => '1' ) ) ) . '">' . esc_html__( 'Redirect toevoegen', 'webwerckt-base' ) . '</a>';
	}
	echo '<hr class="wp-header-end">';
	settings_errors( 'ww_redirects' );
	echo '<div class="ww-redirects-pickers">' . _ww_redirects_render_nav( $section, $counts, 'menu' ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_redirects_render_nav() escapet.
	echo '<p class="ww-redirects-status-line">' . $status . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_redirects_render_status() escapet.
	echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- de weergaven escapen zelf.
	echo '</div>';

	echo '</div></div>';
}

/**
 * De link terug boven het formulier.
 *
 * @return string Geëscapete HTML.
 */
function _ww_redirects_render_back_link(): string {
	if ( _ww_redirects_form_from_log() ) {
		return '<p class="ww-redirects-back"><a href="' . esc_url( _ww_redirects_admin_url( array( 'tab' => '404' ) ) ) . '">← ' . esc_html__( 'Terug naar het 404-logboek', 'webwerckt-base' ) . '</a></p>';
	}
	return '<p class="ww-redirects-back"><a href="' . esc_url( _ww_redirects_admin_url() ) . '">← ' . esc_html__( 'Alle redirects', 'webwerckt-base' ) . '</a></p>';
}
