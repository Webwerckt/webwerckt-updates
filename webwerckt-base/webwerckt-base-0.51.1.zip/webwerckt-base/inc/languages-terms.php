<?php
/**
 * Meertalig: termen per taal (beslissing 0043). Een extra taal heeft per term een eigen naam, slug en beschrijving in
 * termmeta; de gewone term blijft de standaardtaal. Dit bestand bevat de opslag en het lezen op de frontend.
 *
 * @package webwerckt-base
 */

defined( 'ABSPATH' ) || exit;

/**
 * De taxonomieën die per taal vertaalbaar zijn: die van de vertaalbare post types, behalve ww_language.
 *
 * @return string[]
 */
function _ww_translatable_taxonomies(): array {
	$taxonomies = array();
	foreach ( _ww_translatable_post_types() as $post_type ) {
		$taxonomies = array_merge( $taxonomies, get_object_taxonomies( $post_type ) );
	}

	/**
	 * Filtert de vertaalbare taxonomieën.
	 *
	 * @param string[] $taxonomies Taxonomienamen.
	 */
	$taxonomies = apply_filters( 'ww_translatable_taxonomies', array_values( array_unique( $taxonomies ) ) );
	$taxonomies = array_filter( (array) $taxonomies, 'is_string' );

	return array_values( array_diff( array_unique( $taxonomies ), array( 'ww_language' ) ) );
}

/**
 * Of een taxonomie vertaalbaar is.
 */
function _ww_is_translatable_taxonomy( string $taxonomy ): bool {
	return in_array( $taxonomy, _ww_translatable_taxonomies(), true );
}

/**
 * De vertaling van een term in een taal: name, slug en description, lege strings zonder vertaling.
 *
 * @return array{name:string,slug:string,description:string}
 */
function _ww_term_translation( int $term_id, string $lang ): array {
	$stored = get_term_meta( $term_id, '_ww_term_' . $lang, true );
	$stored = is_array( $stored ) ? $stored : array();
	$result = array(
		'name'        => '',
		'slug'        => '',
		'description' => '',
	);
	foreach ( $result as $key => $value ) {
		$result[ $key ] = isset( $stored[ $key ] ) && is_string( $stored[ $key ] ) ? $stored[ $key ] : '';
	}
	return $result;
}

/**
 * Vlag: de termfilters (get_term, get_terms) doen niets. Aan tijdens het opslaan van een vertaling en het opzoeken van
 * een term, zodat daar altijd de gewone waarden gelezen worden.
 *
 * @param bool|null $set Nieuwe stand, of null om alleen te lezen.
 */
function _ww_languages_terms_raw( ?bool $set = null ): bool {
	static $raw = false;
	if ( null !== $set ) {
		$raw = $set;
	}
	return $raw;
}

/**
 * Of een andere term in deze taxonomie de slug al heeft, als vertaalde slug in deze taal of als gewone slug.
 */
function _ww_term_slug_in_use( string $slug, string $taxonomy, string $lang, int $term_id ): bool {
	$previous = _ww_languages_terms_raw();
	_ww_languages_terms_raw( true );
	try {
		$found = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
				'exclude'    => array( $term_id ),
				'fields'     => 'ids',
				'number'     => 1,
				'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- één opzoeking bij het opslaan.
					array(
						'key'   => '_ww_term_slug_' . $lang,
						'value' => $slug,
					),
				),
			)
		);
		$plain = get_term_by( 'slug', $slug, $taxonomy );
	} finally {
		_ww_languages_terms_raw( $previous );
	}

	if ( is_array( $found ) && array() !== $found ) {
		return true;
	}
	return $plain instanceof WP_Term && $plain->term_id !== $term_id;
}

/**
 * Bewaart de vertaling van een term in een extra taal. $data heeft name, slug en description, elk optioneel: een
 * ontbrekende sleutel blijft zoals hij was en '' wist dat veld. Zonder enige waarde verdwijnt de meta.
 *
 * @param array<string,mixed> $data Nieuwe waarden.
 * @return true|WP_Error
 */
function _ww_term_save_translation( int $term_id, string $lang, array $data ): true|WP_Error {
	if ( '' === $lang || ! in_array( $lang, _ww_extra_language_codes(), true ) ) {
		return new WP_Error( 'ww_term_lang', __( 'Onbekende taal voor een termvertaling.', 'webwerckt-base' ) );
	}

	$previous = _ww_languages_terms_raw();
	_ww_languages_terms_raw( true );
	try {
		$term = get_term( $term_id );
	} finally {
		_ww_languages_terms_raw( $previous );
	}
	if ( ! $term instanceof WP_Term || ! _ww_is_translatable_taxonomy( $term->taxonomy ) ) {
		return new WP_Error( 'invalid_term', __( 'Deze term kan niet vertaald worden.', 'webwerckt-base' ) );
	}

	$values = _ww_term_translation( $term_id, $lang );
	if ( isset( $data['name'] ) && is_string( $data['name'] ) ) {
		$values['name'] = sanitize_text_field( $data['name'] );
	}
	if ( isset( $data['slug'] ) && is_string( $data['slug'] ) ) {
		$values['slug'] = sanitize_title( $data['slug'] );
	}
	if ( isset( $data['description'] ) && is_string( $data['description'] ) ) {
		$values['description'] = trim( wp_kses_post( $data['description'] ) );
	}

	if ( '' !== $values['slug'] && _ww_term_slug_in_use( $values['slug'], $term->taxonomy, $lang, $term_id ) ) {
		return new WP_Error( 'ww_term_slug_taken', __( 'Deze slug is al in gebruik door een andere term.', 'webwerckt-base' ) );
	}

	$values = array_filter( $values, static fn( string $value ): bool => '' !== $value );
	if ( array() === $values ) {
		delete_term_meta( $term_id, '_ww_term_' . $lang );
	} else {
		update_term_meta( $term_id, '_ww_term_' . $lang, wp_slash( $values ) );
	}
	if ( isset( $values['slug'] ) ) {
		update_term_meta( $term_id, '_ww_term_slug_' . $lang, $values['slug'] );
	} else {
		delete_term_meta( $term_id, '_ww_term_slug_' . $lang );
	}

	clean_term_cache( $term_id, $term->taxonomy );
	do_action( '_ww_purge_all' );
	return true;
}

/**
 * De extra taal waarin termen getoond worden, of '' (standaardtaal, admin, WP-CLI en cron, REST behalve het
 * kaarten-endpoint, Meertalig uit).
 */
function _ww_term_display_language(): string {
	return _ww_settings_language( null );
}

/**
 * Of de aanroep van get_term() uit wp_unique_term_slug() komt. Die functie zet bij een botsing de slug van de ouder
 * achter de nieuwe slug, en dat moet de gewone slug zijn (die wordt bewaard), ook bij het invoegen of verplaatsen van een
 * term op een verzoek in een extra taal. Zonder vlag die kan blijven hangen: de aanroepstapel is de enige grens.
 */
function _ww_languages_in_unique_term_slug(): bool {
	foreach ( debug_backtrace( DEBUG_BACKTRACE_IGNORE_ARGS, 15 ) as $frame ) { // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_debug_backtrace -- alleen de functienaam van de aanroeper.
		if ( 'wp_unique_term_slug' === $frame['function'] ) {
			return true;
		}
	}
	return false;
}

/**
 * Filter get_term: een kopie van de term met de vertaling erin, terugval per veld. Het gecachte object blijft zoals
 * het was. De kopie krijgt de gewone waarden mee in ->data: dat leest wp_update_term() om de bestaande waarden over te
 * nemen, nog vóór enige actie van het opslaan, dus een vertaling wordt nooit in de gewone term teruggeschreven.
 *
 * @param mixed $term Term of fout.
 * @return mixed
 */
function _ww_languages_filter_term( mixed $term ): mixed {
	if ( ! $term instanceof WP_Term || _ww_languages_terms_raw() || property_exists( $term, 'data' ) ) {
		return $term;
	}
	$lang = _ww_term_display_language();
	if ( '' === $lang ) {
		return $term;
	}
	return _ww_languages_translate_term( $term, $lang, _ww_translatable_taxonomies() );
}

/**
 * De vertaalde kopie van een term voor _ww_languages_filter_term() en _ww_languages_filter_terms(), met de taal en de
 * vertaalbare taxonomieën al bepaald (bij get_terms één keer per resultaat, niet per term).
 *
 * @param WP_Term  $term       Term.
 * @param string   $lang       Extra taal waarin termen getoond worden.
 * @param string[] $taxonomies Vertaalbare taxonomieën (_ww_translatable_taxonomies()).
 */
function _ww_languages_translate_term( WP_Term $term, string $lang, array $taxonomies ): WP_Term {
	if ( property_exists( $term, 'data' ) || ! in_array( $term->taxonomy, $taxonomies, true ) ) {
		return $term;
	}
	$translation = array_filter( _ww_term_translation( (int) $term->term_id, $lang ), static fn( string $value ): bool => '' !== $value );
	if ( array() === $translation ) {
		return $term;
	}
	if ( _ww_languages_in_unique_term_slug() ) {
		return $term;
	}

	// Naast de vertaalde velden een eigen eigenschap data met de gewone waarden (WP_Term staat dynamische eigenschappen
	// toe, en de getter ->data wordt dan niet meer aangeroepen).
	$copy = clone $term;
	foreach ( array_merge( $translation, array( 'data' => $term->data ) ) as $field => $value ) {
		$copy->$field = $value;
	}
	return $copy;
}

/**
 * Filter get_terms: dezelfde vertaling voor de objecten in een resultaat (ids en tellingen blijven zoals ze zijn). De
 * taal en de vertaalbare taxonomieën worden één keer per resultaat bepaald, bij de eerste term.
 *
 * @param mixed $terms Resultaat van get_terms().
 * @return mixed
 */
function _ww_languages_filter_terms( mixed $terms ): mixed {
	if ( ! is_array( $terms ) || _ww_languages_terms_raw() ) {
		return $terms;
	}
	$lang = _ww_term_display_language();
	if ( '' === $lang ) {
		return $terms;
	}
	$taxonomies = null;
	foreach ( $terms as $key => $term ) {
		if ( $term instanceof WP_Term ) {
			$taxonomies  ??= _ww_translatable_taxonomies();
			$terms[ $key ] = _ww_languages_translate_term( $term, $lang, $taxonomies );
		}
	}
	return $terms;
}

/**
 * Zoekt een term op slug in een taal: eerst als vertaalde slug in die taal, anders als gewone slug. Geeft de term met de
 * gewone waarden (de termfilters staan tijdens het opzoeken uit).
 */
function _ww_term_find_by_slug( string $taxonomy, string $slug, string $lang ): ?WP_Term {
	if ( '' === $slug ) {
		return null;
	}
	$previous = _ww_languages_terms_raw();
	_ww_languages_terms_raw( true );
	$found = null;
	try {
		if ( _ww_languages_active() && in_array( $lang, _ww_extra_language_codes(), true ) && _ww_is_translatable_taxonomy( $taxonomy ) ) {
			$terms = get_terms(
				array(
					'taxonomy'   => $taxonomy,
					'hide_empty' => false,
					'number'     => 1,
					'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- één opzoeking per slug.
						array(
							'key'   => '_ww_term_slug_' . $lang,
							'value' => $slug,
						),
					),
				)
			);
			if ( is_array( $terms ) && isset( $terms[0] ) ) {
				$found = $terms[0];
			}
		}
		if ( null === $found ) {
			$plain = get_term_by( 'slug', $slug, $taxonomy );
			$found = $plain instanceof WP_Term ? $plain : null;
		}
	} finally {
		_ww_languages_terms_raw( $previous );
	}
	return $found;
}

/**
 * Zet slugs in een tax-lijst (taxonomie => slug of slugs) van de huidige taal om naar gewone slugs, voor een query.
 * Een slug die niet bekend is blijft staan.
 *
 * @param array<mixed> $tax Taxonomie => slug(s).
 * @return array<mixed>
 */
function _ww_term_plain_tax( array $tax ): array {
	$lang = ww_current_language();
	if ( ! _ww_languages_active() || ! in_array( $lang, _ww_extra_language_codes(), true ) ) {
		return $tax;
	}
	foreach ( $tax as $taxonomy => $slugs ) {
		$list = array();
		foreach ( (array) $slugs as $slug ) {
			$term   = is_scalar( $slug ) ? _ww_term_find_by_slug( sanitize_key( (string) $taxonomy ), sanitize_title( (string) $slug ), $lang ) : null;
			$list[] = $term instanceof WP_Term ? $term->slug : $slug;
		}
		$tax[ $taxonomy ] = is_array( $slugs ) ? $list : $list[0];
	}
	return $tax;
}

/**
 * Filter term_link (na de kern): is de term als gewone term meegegeven, dan komt de vertaalde slug in plaats van de laatste
 * slug in het pad. Voorouders komen via get_term() al vertaald binnen.
 *
 * @param mixed $link     Adres.
 * @param mixed $term     Term.
 * @param mixed $taxonomy Taxonomie.
 * @return mixed
 */
function _ww_languages_term_link( mixed $link, mixed $term = null, mixed $taxonomy = '' ): mixed {
	$lang = _ww_term_display_language();
	if ( ! is_string( $link ) || ! $term instanceof WP_Term || ! is_string( $taxonomy ) || '' === $lang || ! _ww_is_translatable_taxonomy( $taxonomy ) ) {
		return $link;
	}
	$translated = _ww_term_translation( (int) $term->term_id, $lang )['slug'];
	if ( '' === $translated || $translated === $term->slug ) {
		return $link;
	}
	$pattern = '#(?<=[/=])' . preg_quote( $term->slug, '#' ) . '(?=[/?\#&]|$)#';
	if ( ! preg_match_all( $pattern, $link, $matches, PREG_OFFSET_CAPTURE ) ) {
		return $link;
	}
	$last = $matches[0][ count( $matches[0] ) - 1 ];
	return substr_replace( $link, $translated, (int) $last[1], strlen( $last[0] ) );
}

/**
 * Filter request (na de routing van de kern): de query var van een vertaalbare taxonomie krijgt de gewone slug als de
 * waarde een vertaalde slug in de taal van het verzoek is. Bij een hiërarchisch pad (ouder/kind) per niveau.
 *
 * @param array<string,mixed> $vars Query vars.
 * @return array<string,mixed>
 */
function _ww_languages_term_request( array $vars ): array {
	$lang = _ww_languages_request_language();
	if ( ! in_array( $lang, _ww_extra_language_codes(), true ) ) {
		return $vars;
	}
	foreach ( _ww_translatable_taxonomies() as $taxonomy ) {
		$query_var = get_taxonomy( $taxonomy )->query_var ?? false;
		if ( ! is_string( $query_var ) || '' === $query_var || ! isset( $vars[ $query_var ] ) || ! is_string( $vars[ $query_var ] ) ) {
			continue;
		}
		$segments = array();
		foreach ( explode( '/', $vars[ $query_var ] ) as $segment ) {
			$term       = _ww_term_find_by_slug( $taxonomy, $segment, $lang );
			$segments[] = $term instanceof WP_Term ? $term->slug : $segment;
		}
		$vars[ $query_var ] = implode( '/', $segments );
	}
	return $vars;
}

/**
 * Actie template_redirect (prioriteit 1): een termarchief op een extra taal met de gewone slug, terwijl de term een
 * vertaalde slug heeft, gaat met een 301 naar het adres met de vertaalde slug.
 */
function _ww_languages_term_redirect(): void {
	if ( '' === _ww_term_display_language() || ! ( is_tax() || is_category() || is_tag() ) || is_feed() || ! get_option( 'permalink_structure' ) ) {
		return;
	}
	$term = get_queried_object();
	if ( ! $term instanceof WP_Term || ! _ww_is_translatable_taxonomy( $term->taxonomy ) ) {
		return;
	}
	$link = get_term_link( $term );
	if ( ! is_string( $link ) ) {
		return;
	}
	$uri     = isset( $_SERVER['REQUEST_URI'] ) && is_string( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- alleen vergeleken met het pad van de termlink.
	$request = trailingslashit( (string) wp_parse_url( $uri, PHP_URL_PATH ) );
	$target  = trailingslashit( (string) wp_parse_url( $link, PHP_URL_PATH ) );
	if ( '/' === $target || str_starts_with( $request, $target ) ) {
		return;
	}

	$query = (string) wp_parse_url( $uri, PHP_URL_QUERY );
	$url   = ww_paged_url( $link, (int) get_query_var( 'paged' ) ) . ( '' !== $query ? '?' . $query : '' );
	if ( wp_safe_redirect( $url, 301, 'Webwerckt' ) ) {
		exit;
	}
}

/**
 * Het adres van het huidige termarchief per taal (taalcode => URL), voor de taalwisselaar en hreflang: per taal de slug
 * van die taal (per niveau bij een hiërarchisch pad; zonder vertaling de gewone slug), het voorvoegsel van die taal en
 * het paginanummer. Null als dit geen archief van een term van een vertaalbare taxonomie is, of zonder mooie permalinks;
 * dan geldt het adres van het verzoek met een ander voorvoegsel.
 *
 * @param string[] $codes Taalcodes.
 * @return array<string,string>|null
 */
function _ww_languages_term_archive_urls( array $codes ): ?array {
	if ( ! _ww_languages_active() || ! ( is_tax() || is_category() || is_tag() ) || ! get_option( 'permalink_structure' ) ) {
		return null;
	}
	$term = get_queried_object();
	if ( ! $term instanceof WP_Term || ! _ww_is_translatable_taxonomy( $term->taxonomy ) ) {
		return null;
	}

	// De gewone link en de gewone slugs van de term en (bij een hiërarchisch pad) zijn voorouders, van boven naar beneden.
	$previous = _ww_languages_terms_raw();
	_ww_languages_terms_raw( true );
	try {
		$link     = get_term_link( (int) $term->term_id, $term->taxonomy );
		$taxonomy = get_taxonomy( $term->taxonomy );
		$chain    = array( (int) $term->term_id );
		if ( $taxonomy instanceof WP_Taxonomy && is_array( $taxonomy->rewrite ) && ! empty( $taxonomy->rewrite['hierarchical'] ) ) {
			$chain = array_merge( array_reverse( array_map( 'intval', get_ancestors( (int) $term->term_id, $term->taxonomy, 'taxonomy' ) ) ), $chain );
		}
		$plain = array();
		foreach ( $chain as $id ) {
			$level   = get_term( $id, $term->taxonomy );
			$plain[] = $level instanceof WP_Term ? $level->slug : '';
		}
	} finally {
		_ww_languages_terms_raw( $previous );
	}
	if ( ! is_string( $link ) || in_array( '', $plain, true ) ) {
		return null;
	}

	// De laatste segmenten van het pad zijn de keten; de termlink-filters kunnen daar al een vertaalde slug hebben gezet.
	$parts    = explode( '?', $link, 2 );
	$segments = explode( '/', $parts[0] );
	$filled   = array_keys( array_filter( $segments, static fn( string $segment ): bool => '' !== $segment ) );
	$filled   = array_slice( $filled, -count( $chain ) );
	if ( count( $filled ) !== count( $chain ) ) {
		return null;
	}

	$paged = (int) get_query_var( 'paged' );
	$urls  = array();
	foreach ( $codes as $code ) {
		$extra = in_array( $code, _ww_extra_language_codes(), true );
		foreach ( $chain as $level => $id ) {
			$translated                     = $extra ? _ww_term_translation( $id, $code )['slug'] : '';
			$segments[ $filled[ $level ] ] = '' !== $translated ? $translated : $plain[ $level ];
		}
		$url           = implode( '/', $segments ) . ( isset( $parts[1] ) ? '?' . $parts[1] : '' );
		$urls[ $code ] = ww_paged_url( _ww_languages_relink( $url, $code ), $paged );
	}
	return $urls;
}

/**
 * Hangt de termfilters op. De filters kijken per aanroep naar de taal van het verzoek, dus het maakt niet uit hoe vroeg
 * dit draait.
 */
function _ww_languages_boot_terms(): void {
	add_filter( 'get_term', '_ww_languages_filter_term' );
	add_filter( 'get_terms', '_ww_languages_filter_terms' );
	add_filter( 'term_link', '_ww_languages_term_link', 11, 3 );
	add_filter( 'request', '_ww_languages_term_request', 11 );
	add_action( 'template_redirect', '_ww_languages_term_redirect', 1 );
	add_action( 'admin_init', '_ww_languages_terms_admin_hooks' );
}

/**
 * Hangt de admin-haken van de termen op voor elke vertaalbare taxonomie: het blok op het bewerkscherm, het opslaan en de
 * kolom Talen. Draait op admin_init, als alle taxonomieën geregistreerd zijn.
 */
function _ww_languages_terms_admin_hooks(): void {
	foreach ( _ww_translatable_taxonomies() as $taxonomy ) {
		add_action( $taxonomy . '_edit_form_fields', '_ww_languages_term_fields', 20, 2 );
		add_action( 'edited_' . $taxonomy, '_ww_languages_term_save', 10, 1 );
		add_filter( 'manage_edit-' . $taxonomy . '_columns', '_ww_languages_term_columns' );
		add_filter( 'manage_' . $taxonomy . '_custom_column', '_ww_languages_term_column', 10, 3 );
	}
	add_action( 'admin_notices', '_ww_languages_term_notice' );
}

/**
 * Sleutel van de transient met de meldingen van het opslaan van termvertalingen, per term en gebruiker.
 */
function _ww_languages_term_notice_key( int $term_id ): string {
	return 'ww_term_translation_' . $term_id . '_' . get_current_user_id();
}

/**
 * Actie {taxonomy}_edit_form_fields: per extra taal een blok met naam, slug en beschrijving.
 *
 * @param mixed $term     Term.
 * @param mixed $taxonomy Taxonomie.
 */
function _ww_languages_term_fields( mixed $term, mixed $taxonomy = '' ): void {
	if ( ! $term instanceof WP_Term || ! is_string( $taxonomy ) || ! _ww_languages_active() || ! _ww_is_translatable_taxonomy( $taxonomy ) ) {
		return;
	}
	wp_nonce_field( 'ww_term_translation_' . $term->term_id, 'ww_term_translation_nonce', false );
	foreach ( _ww_extra_language_codes() as $code ) {
		$language = _ww_language( $code );
		$values   = _ww_term_translation( (int) $term->term_id, $code );
		$prefix   = 'ww_term_translation[' . $code . ']';
		$id       = 'ww-term-translation-' . $code;
		echo '<tr class="form-field"><th scope="row" colspan="2"><h2 style="margin:1em 0 0;">';
		/* translators: %s: naam van de taal */
		echo esc_html( sprintf( __( 'Vertaling: %s', 'webwerckt-base' ), $language['name'] ?? $code ) );
		echo '</h2></th></tr>';
		printf(
			'<tr class="form-field"><th scope="row"><label for="%1$s-name">%2$s</label></th><td><input type="text" name="%3$s[name]" id="%1$s-name" value="%4$s" size="40"></td></tr>',
			esc_attr( $id ),
			esc_html__( 'Naam', 'webwerckt-base' ),
			esc_attr( $prefix ),
			esc_attr( $values['name'] )
		);
		printf(
			'<tr class="form-field"><th scope="row"><label for="%1$s-slug">%2$s</label></th><td><input type="text" name="%3$s[slug]" id="%1$s-slug" value="%4$s" size="40"></td></tr>',
			esc_attr( $id ),
			esc_html__( 'Slug', 'webwerckt-base' ),
			esc_attr( $prefix ),
			esc_attr( $values['slug'] )
		);
		printf(
			'<tr class="form-field"><th scope="row"><label for="%1$s-description">%2$s</label></th><td><textarea name="%3$s[description]" id="%1$s-description" rows="5" cols="50">%4$s</textarea></td></tr>',
			esc_attr( $id ),
			esc_html__( 'Beschrijving', 'webwerckt-base' ),
			esc_attr( $prefix ),
			esc_textarea( $values['description'] )
		);
	}
}

/**
 * Actie edited_{taxonomy}: bewaart de vertalingen uit het formulier, met een nonce en het recht edit_term. Een weigering
 * komt als melding op het bewerkscherm van de term (transient, één keer getoond).
 *
 * @param int|string $term_id Term.
 */
function _ww_languages_term_save( $term_id ): void {
	$term_id = (int) $term_id;
	$nonce   = isset( $_POST['ww_term_translation_nonce'] ) && is_string( $_POST['ww_term_translation_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['ww_term_translation_nonce'] ) ) : '';
	if ( '' === $nonce || ! wp_verify_nonce( $nonce, 'ww_term_translation_' . $term_id ) || ! _ww_languages_active() || ! current_user_can( 'edit_term', $term_id ) ) {
		return;
	}
	$input = isset( $_POST['ww_term_translation'] ) && is_array( $_POST['ww_term_translation'] ) ? wp_unslash( $_POST['ww_term_translation'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- elke waarde wordt in _ww_term_save_translation() schoongemaakt.

	$errors = array();
	foreach ( _ww_extra_language_codes() as $code ) {
		if ( ! isset( $input[ $code ] ) || ! is_array( $input[ $code ] ) ) {
			continue;
		}
		$result = _ww_term_save_translation(
			$term_id,
			$code,
			array(
				'name'        => $input[ $code ]['name'] ?? '',
				'slug'        => $input[ $code ]['slug'] ?? '',
				'description' => $input[ $code ]['description'] ?? '',
			)
		);
		if ( $result instanceof WP_Error ) {
			$errors[] = $result->get_error_message();
		}
	}

	$key = _ww_languages_term_notice_key( $term_id );
	if ( array() !== $errors ) {
		set_transient( $key, $errors, 60 );
	} else {
		delete_transient( $key );
	}
}

/**
 * Toont de weigeringen van de laatste opslag één keer op het bewerkscherm van die term.
 */
function _ww_languages_term_notice(): void {
	$screen = get_current_screen();
	$term   = isset( $_GET['tag_ID'] ) ? absint( _ww_data_to_string( wp_unslash( $_GET['tag_ID'] ) ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen lezen welke term getoond wordt.
	if ( ! $screen instanceof WP_Screen || 'term' !== $screen->base || $term <= 0 ) {
		return;
	}
	$key    = _ww_languages_term_notice_key( $term );
	$errors = get_transient( $key );
	if ( ! is_array( $errors ) ) {
		return;
	}
	delete_transient( $key );
	foreach ( $errors as $error ) {
		printf( '<div class="notice notice-error"><p>%s</p></div>', esc_html( _ww_data_to_string( $error ) ) );
	}
}

/**
 * Filter manage_edit-{taxonomy}_columns: de kolom Talen achter de naam.
 *
 * @param mixed $columns Kolommen.
 * @return mixed
 */
function _ww_languages_term_columns( mixed $columns ): mixed {
	if ( ! is_array( $columns ) || ! _ww_languages_active() ) {
		return $columns;
	}
	$out = array();
	foreach ( $columns as $key => $label ) {
		$out[ $key ] = $label;
		if ( 'name' === $key ) {
			$out['ww_languages'] = __( 'Talen', 'webwerckt-base' );
		}
	}
	if ( ! isset( $out['ww_languages'] ) ) {
		$out['ww_languages'] = __( 'Talen', 'webwerckt-base' );
	}
	return $out;
}

/**
 * Filter manage_{taxonomy}_custom_column: de codes van de talen waarvoor een naam is ingevuld.
 *
 * @param mixed $content Inhoud tot nu toe.
 * @param mixed $column  Kolom.
 * @param mixed $term_id Term.
 * @return mixed
 */
function _ww_languages_term_column( mixed $content, mixed $column, mixed $term_id ): mixed {
	if ( 'ww_languages' !== $column || ! is_int( $term_id ) || ! _ww_languages_active() ) {
		return $content;
	}
	$codes = array();
	foreach ( _ww_extra_language_codes() as $code ) {
		if ( '' !== _ww_term_translation( $term_id, $code )['name'] ) {
			$codes[] = esc_html( $code );
		}
	}
	return $content . implode( ' ', $codes );
}
