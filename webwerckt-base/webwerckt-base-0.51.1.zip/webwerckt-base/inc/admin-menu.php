<?php
/**
 * De linkerbalk van het beheer in drie blokken, met een lijn ertussen (beslissing 0035):
 *
 * 1. Inhoud: Pagina's, Berichten, Media en de post types (van de parent, het child-thema en plugins).
 * 2. Webwerckt: de functies van het thema (Site-instellingen, Talen, Formulieren, Mail, Redirects, Pagina cache,
 *    Activiteitenlog). Talen staat er alleen met het vinkje Meertalig aan.
 * 3. WordPress: Weergave of Menu's, Plugins, Gebruikers, Extra, Instellingen en de menu's van andere plugins, in de
 *    volgorde die WordPress ze geeft.
 *
 * Dashboard blijft bovenaan. De volgorde komt uit het filter menu_order, dus de registraties houden hun eigen
 * positie. Een child-thema zet een item in een ander blok met het filter `ww_admin_menu_groups`.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// De scheiding tussen het Webwerckt-blok en WordPress. WordPress herkent een scheiding aan het voorvoegsel separator.
const WW_ADMIN_MENU_SEPARATOR = 'separator-webwerckt';

/**
 * Het blok per menu-item, in de volgorde binnen het blok. Een post type dat hier niet staat, komt bij de inhoud;
 * elk ander item bij WordPress.
 *
 * @return array<string,string> Slug van het hoofdmenu => content, webwerckt of wordpress.
 */
function _ww_admin_menu_groups(): array {
	$defaults = array(
		'edit.php?post_type=page'               => 'content',
		'edit.php'                              => 'content',
		'upload.php'                            => 'content',
		WW_SETTINGS_SCREEN                      => 'webwerckt',
		WW_LANGUAGES_PAGE                       => 'webwerckt',
		'edit.php?post_type=' . WW_FORM_POST_TYPE => 'webwerckt',
		WW_MAIL_LOG_PAGE                        => 'webwerckt',
		WW_REDIRECTS_SCREEN                     => 'webwerckt',
		WW_SEO_SCREEN                           => 'webwerckt',
		WW_PAGE_CACHE_ADMIN_PAGE                => 'webwerckt',
		WW_IMAGES_ADMIN_PAGE                    => 'webwerckt',
		WW_STATS_PAGE                           => 'webwerckt',
		WW_ACTIVITY_PAGE                        => 'webwerckt',
		WW_FIELDS_PAGE                          => 'webwerckt',
	);

	/*
	 * Filter ww_admin_menu_groups: het blok per menu-item, als slug van het hoofdmenu => content, webwerckt of
	 * wordpress. Een item dat eerder staat, staat ook eerder in zijn blok; een item dat hier niet staat, houdt de
	 * volgorde van WordPress, na de items die er wel staan. Een onbekend blok telt niet mee.
	 */
	$groups = apply_filters( 'ww_admin_menu_groups', $defaults );
	if ( ! is_array( $groups ) ) {
		return $defaults;
	}

	$valid = array();
	foreach ( $groups as $slug => $group ) {
		if ( is_string( $slug ) && in_array( $group, array( 'content', 'webwerckt', 'wordpress' ), true ) ) {
			$valid[ $slug ] = $group;
		}
	}
	return $valid;
}

/**
 * Zet de menu-items in de volgorde van de drie blokken (filter menu_order). Elke slug komt precies één keer terug:
 * WordPress zet een slug die ontbreekt achteraan. Een lege groep geeft twee scheidingen na elkaar; WordPress haalt
 * de tweede weg.
 *
 * @param mixed $order Slugs van de hoofdmenu's in de volgorde van WordPress.
 * @return mixed
 */
function _ww_admin_menu_order( $order ) {
	if ( ! is_array( $order ) ) {
		return $order;
	}

	$groups   = _ww_admin_menu_groups();
	$rank     = array_flip( array_keys( $groups ) );
	$fixed    = array( 'index.php', 'separator1', 'separator2', WW_ADMIN_MENU_SEPARATOR, 'separator-last' );
	$present  = array_flip( array_filter( $order, 'is_string' ) );
	$blocks   = array(
		'content'   => array(),
		'webwerckt' => array(),
		'wordpress' => array(),
	);
	$position = 0;

	foreach ( $order as $slug ) {
		if ( ! is_string( $slug ) || in_array( $slug, $fixed, true ) ) {
			continue;
		}
		if ( isset( $groups[ $slug ] ) ) {
			$group = $groups[ $slug ];
		} else {
			$group = str_starts_with( $slug, 'edit.php?post_type=' ) ? 'content' : 'wordpress';
		}
		$blocks[ $group ][] = array( $rank[ $slug ] ?? PHP_INT_MAX, $position++, $slug );
	}

	$sorted = array();
	foreach ( array( array( 'index.php', 'separator1' ), 'content', array( 'separator2' ), 'webwerckt', array( WW_ADMIN_MENU_SEPARATOR ), 'wordpress', array( 'separator-last' ) ) as $part ) {
		if ( is_array( $part ) ) {
			foreach ( $part as $slug ) {
				if ( isset( $present[ $slug ] ) ) {
					$sorted[] = $slug;
				}
			}
			continue;
		}
		$items = $blocks[ $part ];
		usort( $items, static fn( array $a, array $b ): int => array( $a[0], $a[1] ) <=> array( $b[0], $b[1] ) );
		foreach ( $items as $item ) {
			$sorted[] = $item[2];
		}
	}
	return $sorted;
}
add_filter( 'custom_menu_order', '__return_true' );
add_filter( 'menu_order', '_ww_admin_menu_order' );

/**
 * Een scheiding na het Webwerckt-blok, en een lijn op de scheidingen tussen de blokken. De scheiding onder het
 * Dashboard blijft de witruimte van WordPress.
 */
function _ww_admin_menu_separators(): void {
	global $menu;
	if ( ! is_array( $menu ) ) {
		$menu = array(); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- het menu van WordPress zelf.
	}
	foreach ( $menu as $index => $item ) {
		if ( 'separator2' === ( $item[2] ?? '' ) ) {
			$menu[ $index ][4] = trim( _ww_data_to_string( $item[4] ?? '' ) . ' ww-menu-separator' ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- het menu van WordPress zelf.
		}
	}
	$menu[] = array( '', 'read', WW_ADMIN_MENU_SEPARATOR, '', 'wp-menu-separator ww-menu-separator' ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- het menu van WordPress zelf.
}
add_action( 'admin_menu', '_ww_admin_menu_separators' );

/**
 * De lijn: een dunne, half doorzichtige streep, licht op de donkere menu's en donker bij het kleurenschema Licht.
 * In een ingeklapt menu blijft hij staan.
 */
function _ww_admin_menu_style(): void {
	wp_add_inline_style(
		'admin-menu',
		'#adminmenu li.ww-menu-separator{height:auto;margin:0;padding:6px 0}'
		. '#adminmenu li.ww-menu-separator div.separator{height:0;margin:0 10px;border-top:1px solid rgba(255,255,255,.2)}'
		. '.admin-color-light #adminmenu li.ww-menu-separator div.separator{border-top-color:rgba(0,0,0,.15)}'
	);
}
add_action( 'admin_enqueue_scripts', '_ww_admin_menu_style' );

/**
 * Schermen die van Extra of Instellingen naar een eigen hoofditem zijn verhuisd, per oude ouder.
 *
 * @return array<string,string[]>
 */
function _ww_admin_menu_moved_screens(): array {
	return array(
		'tools.php' => array( WW_REDIRECTS_SCREEN, WW_ACTIVITY_PAGE, WW_MAIL_LOG_PAGE ),
	);
}

/**
 * Het nieuwe adres van een verhuisd scherm onder zijn oude adres (zoals tools.php?page=ww-redirects), of ''.
 *
 * @param array<string,mixed> $query De queryvariabelen van het verzoek.
 */
function _ww_admin_menu_moved_url( array $query ): string {
	global $pagenow;
	$page  = _ww_data_to_string( $query['page'] ?? '' );
	$moved = _ww_admin_menu_moved_screens();
	if ( ! is_string( $pagenow ) || '' === $page || ! in_array( $page, $moved[ $pagenow ] ?? array(), true ) ) {
		return '';
	}
	$args = array();
	foreach ( $query as $key => $value ) {
		if ( is_string( $value ) ) {
			$args[ (string) $key ] = rawurlencode( $value );
		}
	}
	return add_query_arg( $args, admin_url( 'admin.php' ) );
}

/**
 * Stuurt een oude bladwijzer (een GET) naar het nieuwe adres. Meestal toont WordPress het scherm ook onder het oude
 * adres, maar dan licht het verkeerde menu op (admin_init); soms weigert het het oude adres al in wp-admin/menu.php,
 * vóór admin_init, en roept dan admin_page_access_denied aan.
 */
function _ww_admin_menu_redirect_moved(): void {
	if ( 'GET' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) || wp_doing_ajax() ) {
		return;
	}
	$url = _ww_admin_menu_moved_url( wp_unslash( $_GET ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- alleen doorsturen; de waarden gaan gecodeerd mee naar het nieuwe scherm, dat ze zelf controleert.
	if ( '' !== $url && wp_safe_redirect( $url ) ) {
		exit;
	}
}
add_action( 'admin_init', '_ww_admin_menu_redirect_moved' );
add_action( 'admin_page_access_denied', '_ww_admin_menu_redirect_moved' );
