<?php
/**
 * llms.txt uitleveren: /llms.txt voor de standaardtaal en /en/llms.txt voor een zichtbare extra taal (het voorvoegsel
 * haalt de routing van Meertalig er al af, inc/languages-routing.php; een verborgen taal is niet routeerbaar en geeft
 * dus een 404). De tekst komt uit inc/llms.php en wordt per taal een uur bewaard in een transient, die bij elke
 * wijziging leeg gaat.
 *
 * Of het bestand er is, wordt bij elk verzoek bepaald (_ww_llms_enabled()), nooit bewaard: Zoekmachines ontmoedigen uit
 * zetten werkt dus zonder opslaan. De pagina-cache bewaart alleen text/html, dus dit antwoord komt er niet in.
 *
 * @package webwerckt-base
 */

defined( 'ABSPATH' ) || exit;

const WW_LLMS_QUERY_VAR = 'ww_llms';
const WW_LLMS_TRANSIENT = 'ww_llms_txt_';

/**
 * Regel voor /llms.txt (zonder slash erachter).
 */
function _ww_llms_rewrite(): void {
	add_rewrite_rule( '^llms\.txt$', 'index.php?' . WW_LLMS_QUERY_VAR . '=1', 'top' );
}
add_action( 'init', '_ww_llms_rewrite' );

/**
 * Filter query_vars: laat WordPress de query var kennen.
 *
 * @param mixed $vars Bekende query vars.
 * @return mixed
 */
function _ww_llms_query_vars( $vars ) {
	if ( is_array( $vars ) ) {
		$vars[] = WW_LLMS_QUERY_VAR;
	}
	return $vars;
}
add_filter( 'query_vars', '_ww_llms_query_vars' );

/**
 * De taal van dit verzoek: '' voor de standaardtaal of zonder Meertalig, anders de code van de extra taal.
 */
function _ww_llms_language(): string {
	return _ww_llms_normalize_language( _ww_languages_request_language() );
}

/**
 * De tekst van één taal, uit de transient of nieuw gebouwd. Een uur als vangnet voor een wijziging die geen purge
 * geeft (zoals de ondertitel in de talenlijst).
 */
function _ww_llms_text( string $lang ): string {
	$key  = WW_LLMS_TRANSIENT . ( '' !== $lang ? $lang : 'default' );
	$text = get_transient( $key );
	if ( is_string( $text ) ) {
		return $text;
	}
	$text = _ww_llms_build( $lang );
	set_transient( $key, $text, HOUR_IN_SECONDS );
	return $text;
}

/**
 * Verwijdert de bewaarde tekst van de standaardtaal en van elke extra taal.
 */
function _ww_llms_flush(): void {
	delete_transient( WW_LLMS_TRANSIENT . 'default' );
	foreach ( _ww_extra_language_codes() as $code ) {
		delete_transient( WW_LLMS_TRANSIENT . $code );
	}
}
add_action( '_ww_purge_all', '_ww_llms_flush' );
add_action( '_ww_purge_post_type', '_ww_llms_flush' );
add_action( '_ww_purge_post', '_ww_llms_flush' );

/**
 * Opslaan van alleen meta van het scherm SEO (of via de abilities) geeft geen purge: de transient gaat hier leeg.
 *
 * @param mixed $meta_id   Meta-ID.
 * @param mixed $object_id Post-ID.
 * @param mixed $meta_key  Sleutel.
 */
function _ww_llms_flush_on_meta( $meta_id, $object_id, $meta_key ): void {
	if ( is_string( $meta_key ) && str_starts_with( $meta_key, 'ww_seo_' ) ) {
		_ww_llms_flush();
	}
}
add_action( 'updated_post_meta', '_ww_llms_flush_on_meta', 10, 3 );
add_action( 'added_post_meta', '_ww_llms_flush_on_meta', 10, 3 );
add_action( 'deleted_post_meta', '_ww_llms_flush_on_meta', 10, 3 );

/**
 * Het antwoord voor dit verzoek: de tekst, of null voor een 404 (uit, ontmoedigd of naast een SEO-plugin).
 */
function _ww_llms_response(): ?string {
	if ( ! _ww_llms_enabled() ) {
		return null;
	}
	return _ww_llms_text( _ww_llms_language() );
}

/**
 * Action template_redirect, prioriteit 1 (vóór redirect_canonical): levert llms.txt uit of geeft een 404.
 */
function _ww_llms_serve(): void {
	if ( ! get_query_var( WW_LLMS_QUERY_VAR ) ) {
		return;
	}
	// Geen pagina voor een paginacache (LiteSpeed): het antwoord is platte tekst, ook de 404.
	do_action( 'ww_cacheable', false, 'llms.txt' );
	$text = _ww_llms_response();
	if ( null === $text ) {
		global $wp_query;
		$wp_query->set_404();
		status_header( 404 );
		nocache_headers();
		return;
	}
	status_header( 200 );
	header( 'Content-Type: text/plain; charset=utf-8' );
	header( 'X-Content-Type-Options: nosniff' );
	header( 'Cache-Control: no-cache' );
	echo $text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- platte tekst, geen HTML.
	exit;
}
add_action( 'template_redirect', '_ww_llms_serve', 1 );

/**
 * De adressen van llms.txt per taal voor het scherm: taalcode (of '' zonder Meertalig) => adres.
 *
 * @return array<string,string>
 */
function _ww_llms_urls(): array {
	if ( ! _ww_languages_active() ) {
		return array( '' => home_url( '/llms.txt' ) );
	}
	$urls = array();
	foreach ( array_merge( array( _ww_default_language() ), _ww_visible_language_codes() ) as $code ) {
		$urls[ $code ] = _ww_languages_home( $code ) . 'llms.txt';
	}
	return $urls;
}
