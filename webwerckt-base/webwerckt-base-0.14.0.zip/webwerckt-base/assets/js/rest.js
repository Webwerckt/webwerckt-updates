// Gedeeld door load-more.js en filter.js: het kaarten-endpoint aanroepen en wijzigingen melden.

const ROUTE = '/ww/v1/cards';

// Data-attributen kunnen via een tekstveld in de pagina komen (wp_kses_post laat data-* door),
// dus alleen ons eigen endpoint op dit domein wordt aangeroepen: geen HTML van een vreemde server.
export function endpointUrl(value) {
	let url;
	try {
		url = new URL(value, window.location.href);
	} catch (error) {
		return null;
	}
	const isOurRoute = url.pathname.endsWith(`/wp-json${ROUTE}`) || url.searchParams.get('rest_route') === ROUTE;
	return url.origin === window.location.origin && isOurRoute ? url : null;
}

// Lijst met kaarten van een post type: het element met data-ww-list.
export function listFor(postType) {
	return document.querySelector(`[data-ww-list="${CSS.escape(postType)}"]`);
}

// Taxonomie => term-slug uit een JSON-data-attribuut; bij onzin een leeg filter.
export function parseTax(value) {
	try {
		const tax = JSON.parse(value || '{}');
		return tax && typeof tax === 'object' && !Array.isArray(tax) ? tax : {};
	} catch (error) {
		return {};
	}
}

// Haalt één pagina kaarten op: { html, has_more, next_url, total }.
// Het endpoint komt van de pagina met de taal erin (?lang=en of /en/wp-json/...); die blijft staan,
// zodat de kaarten in de taal van de pagina komen.
export async function fetchCards(endpoint, postType, page, tax, signal) {
	const url = new URL(endpoint);
	url.searchParams.set('post_type', postType);
	url.searchParams.set('page', String(page));
	for (const [name, value] of Object.entries(tax)) {
		url.searchParams.set(`tax[${name}]`, String(value));
	}

	const response = await fetch(url, { headers: { Accept: 'application/json' }, signal });
	if (!response.ok) {
		throw new Error(`HTTP ${response.status}`);
	}
	return response.json();
}

// Kaart-HTML als losse elementen, zonder scripts uit te voeren.
export function parseCards(html) {
	const template = document.createElement('template');
	template.innerHTML = typeof html === 'string' ? html : '';
	return template.content;
}

// Meldt een wijziging aan schermlezers via één verborgen aria-live-regio.
export function announce(message) {
	let region = document.querySelector('[data-ww-live]');
	if (!region) {
		region = document.createElement('div');
		region.dataset.wwLive = '';
		region.setAttribute('aria-live', 'polite');
		region.setAttribute('role', 'status');
		region.style.cssText =
			'position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap';
		document.body.append(region);
	}
	region.textContent = message;
}
