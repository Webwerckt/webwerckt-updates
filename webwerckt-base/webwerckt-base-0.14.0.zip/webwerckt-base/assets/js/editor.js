// Visueel bewerken: het zijpaneel boven de pagina in het iframe (ADR 0019).
// De pagina (editor-frame.js) meldt welk element is aangeklikt; dit script toont de velden ervan, laat wijzigingen
// direct in de pagina zien en slaat ze in één keer op via ww/v1/editor/{id}. Na het opslaan laadt de pagina
// opnieuw, zodat PHP alles weer zelf rendert. Het paneel is er alleen als er een element, een sectie of de
// pagina-instellingen zijn gekozen; opslaan staat in de balk. Een sectie toont zijn schakelaar en de velden die
// nergens in de pagina gemarkeerd zijn (relaties bijvoorbeeld); wat bij geen sectie hoort, staat in de
// pagina-instellingen.

const root = document.querySelector('[data-ww-editor]');
const data = JSON.parse(document.getElementById('ww-editor-data').textContent);
const { strings, fields } = data;
const frame = root.querySelector('[data-ww-editor-frame]');
const canvas = root.querySelector('[data-ww-editor-canvas]');
const panel = root.querySelector('[data-ww-editor-panel]');
const panelTitle = root.querySelector('[data-ww-editor-panel-title]');
const pageToggle = root.querySelector('[data-ww-editor-page]');
const fieldsBox = root.querySelector('[data-ww-editor-fields]');
const actionsBox = root.querySelector('[data-ww-editor-actions]');

// Veldnaam => nieuwe waarde, alleen voor velden die afwijken van wat is opgeslagen.
const changes = new Map();
// Veldnaam => voorbeeld-URL van een net gekozen foto.
const previews = new Map();
// ID van het tekstvak => veldnaam, voor de WYSIWYG-editors die nu in het paneel staan.
const editors = new Map();
// Post-ID => bericht (titel, gepubliceerd) voor relatievelden, uit de velden en uit zoekresultaten.
const items = new Map();
let post = data.post;
// De velden van het aangeklikte element, of de gekozen sectie; zonder die twee toont het paneel de
// pagina-instellingen als die open staan.
let selected = null;
let section = null;
let pageOpen = false;
// Wat de pagina in het iframe meldt: welke velden er gemarkeerd zijn en welke secties er staan.
let marks = new Set();
let sections = [];
let scrollY = 0;
let busy = false;
let message = data.lockedBy ? strings.locked.replace('%s', data.lockedBy) : '';

// Velden die in de pagina zelf staan; titel en slug staan altijd in de pagina-instellingen.
const PAGE_FIELDS = ['post_title', 'post_name'];
const INPUT_TYPES = { text: 'text', slug: 'text', email: 'email', phone: 'tel', number: 'number' };
// Wat je in een linkveld typt, telt meteen als link als het er een lijkt; anders zoekt het veld een pagina.
const LOOKS_LIKE_LINK = /^([a-z]+:|\/|#)|\./i;

function send(payload) {
	frame.contentWindow?.postMessage(payload, data.origin);
}

function valueOf(name) {
	return changes.has(name) ? changes.get(name) : fields[name].value;
}

// Gelijk, ook voor de lijst met ID's van een relatie.
function same(a, b) {
	return a === b || JSON.stringify(a) === JSON.stringify(b);
}

function remember(list) {
	list.forEach((item) => items.set(item.id, item));
}

/*
 * Secties.
 */

function toggleOf(name) {
	return `${data.prefix}${name}_enabled`;
}

// De sectie van de pagina waar een veld bij hoort: {voorvoegsel}{sectie} of {voorvoegsel}{sectie}_…, de langste
// naam als er meer passen (hero en hero_extra).
function ownerOf(name) {
	return sections
		.filter((item) => item.source === 'page' && (name === data.prefix + item.name || name.startsWith(`${data.prefix}${item.name}_`)))
		.reduce((best, item) => (!best || item.name.length > best.length ? item.name : best), null);
}

// Velden van een sectie die nergens in de pagina te klikken zijn, de schakelaar eerst.
function sectionFields(name) {
	const own = Object.keys(fields).filter((field) => !marks.has(field) && ownerOf(field) === name);
	return own.sort((a, b) => (b === toggleOf(name)) - (a === toggleOf(name)));
}

// Velden die nergens gemarkeerd zijn en bij geen sectie horen.
function otherFields() {
	return Object.keys(fields).filter((field) => !PAGE_FIELDS.includes(field) && !marks.has(field) && !ownerOf(field));
}

// De naam van een sectie: wat de meeste veldlabels voor de dubbele punt hebben ('Diensten: titel'), anders het label
// van de schakelaar ('Diensten tonen'), anders de sectienaam.
function sectionLabel(name) {
	const counts = new Map();
	Object.keys(fields)
		.filter((field) => ownerOf(field) === name)
		.forEach((field) => {
			const [head, ...rest] = fields[field].label.split(':');
			if (rest.length > 0 && head.trim()) {
				counts.set(head.trim(), (counts.get(head.trim()) || 0) + 1);
			}
		});
	const best = [...counts].sort((a, b) => b[1] - a[1])[0];
	return best?.[0] || fields[toggleOf(name)]?.label || name;
}

function sectionInfo() {
	return Object.fromEntries(
		sections.map(({ name, source }) => {
			if (source === 'settings') {
				return [name, { settings: true }];
			}
			const toggle = toggleOf(name);
			const off = Object.hasOwn(fields, toggle) && !valueOf(toggle);
			return [name, { label: sectionLabel(name), editable: sectionFields(name).length > 0, off }];
		})
	);
}

// Wat de pagina toont voor een waarde: tekst zoals hij is, een foto als URL, WYSIWYG als HTML met alinea's
// (Pods bewaart de tekst zonder <p>, net als het gewone bewerkscherm).
function display(name) {
	const value = valueOf(name);
	// Een relatie toont de pagina pas na opslaan: de kaarten rendert PHP.
	if (fields[name].type === 'pick') {
		return null;
	}
	if (fields[name].type === 'wysiwyg') {
		return { html: window.wp.editor.autop(value || '') };
	}
	if (fields[name].type !== 'file') {
		return value;
	}
	return { url: value ? previews.get(name) || fields[name].preview : '' };
}

function change(name, value) {
	if (same(value, fields[name].value)) {
		changes.delete(name);
	} else {
		changes.set(name, value);
	}
	message = '';
	send({ type: 'value', name, value: display(name) });
	if (sections.some((item) => toggleOf(item.name) === name)) {
		send({ type: 'sections', sections: sectionInfo() });
	}
	if (name === 'post_title') {
		root.querySelector('[data-ww-editor-title]').textContent = value;
	}
	renderActions();
}

/*
 * Velden.
 */

function element(tag, props = {}, children = []) {
	const node = Object.assign(document.createElement(tag), props);
	node.append(...children);
	return node;
}

function textControl(name, field, id) {
	const multiline = field.type === 'paragraph';
	const input = element(multiline ? 'textarea' : 'input', { id, className: multiline ? 'large-text' : 'regular-text' });
	if (multiline) {
		input.rows = 5;
	} else {
		input.type = INPUT_TYPES[field.type];
	}
	input.value = valueOf(name) ?? '';
	input.addEventListener('input', () => change(name, input.value));
	return input;
}

// Tekst als HTML: TinyMCE met de editor-style van het child-thema, gestart door renderFields() zodra het tekstvak
// in het paneel staat. De codeweergave schrijft direct in het tekstvak.
function wysiwygControl(name, field, id) {
	const textarea = element('textarea', { id, className: 'wp-editor-area', rows: 12 });
	textarea.value = valueOf(name) ?? '';
	textarea.addEventListener('input', () => change(name, textarea.value));
	editors.set(id, name);
	return textarea;
}

function startEditor(id, name) {
	window.wp.editor.initialize(id, {
		tinymce: {
			wpautop: true,
			toolbar1: 'formatselect,bold,italic,bullist,numlist,link,unlink,undo,redo',
			toolbar2: '',
			block_formats: strings.blockFormats,
			content_css: data.editorStyles.join(','),
			setup(editor) {
				editor.on('input change undo redo ExecCommand', () => change(name, window.wp.editor.getContent(id)));
				// Het eerste veld van het aangeklikte element krijgt de focus, ook als dat deze editor is.
				editor.on('init', () => selected?.[0] === name && editor.focus());
			},
		},
		quicktags: { buttons: 'strong,em,link,ul,ol,li' },
		mediaButtons: true,
	});
	// Media toevoegen zet de foto in de editor die hier actief is.
	window.wpActiveEditor = id;
}

function stopEditors() {
	editors.forEach((name, id) => window.wp.editor.remove(id));
	editors.clear();
}

// Titel uit de zoekresultaten van WordPress, met entiteiten (&#8211;) als gewone tekens.
function plainText(html) {
	return new DOMParser().parseFromString(html, 'text/html').body.textContent || '';
}

// Linkveld: zoek een pagina of bericht van de site, of typ zelf een URL, tel: of mailto:.
function linkControl(name, field, id) {
	const input = element('input', { id, type: 'text', className: 'regular-text', placeholder: strings.searchLink, autocomplete: 'off' });
	const results = element('ul', { className: 'ww-editor__results' });
	input.value = valueOf(name) ?? '';

	const pick = (url) => {
		input.value = url;
		change(name, url);
		results.replaceChildren();
	};
	const search = async (term) => {
		if (term.length < 2 || LOOKS_LIKE_LINK.test(term)) {
			results.replaceChildren();
			return;
		}
		try {
			const query = new URLSearchParams({ search: term, type: 'post', per_page: '8' });
			const items = await window.wp.apiFetch({ path: `/wp/v2/search?${query}` });
			if (input.value.trim() !== term) {
				return;
			}
			results.replaceChildren(
				...items.map((item) =>
					element('li', {}, [
						element('button', { type: 'button', className: 'button-link', onclick: () => pick(item.url) }, [
							element('span', { textContent: plainText(item.title) }),
							element('span', { className: 'ww-editor__result-url', textContent: item.url }),
						]),
					])
				)
			);
			if (items.length === 0) {
				results.replaceChildren(element('li', { className: 'description', textContent: strings.noResults }));
			}
		} catch (error) {
			results.replaceChildren();
		}
	};

	let timer;
	input.addEventListener('input', () => {
		const term = input.value.trim();
		if (term === '' || LOOKS_LIKE_LINK.test(term)) {
			change(name, term);
		}
		clearTimeout(timer);
		timer = setTimeout(() => search(term), 250);
	});
	return element('div', { className: 'ww-editor__link' }, [input, results]);
}

function booleanControl(name, field, id) {
	const input = element('input', { id, type: 'checkbox', checked: Boolean(valueOf(name)) });
	input.addEventListener('change', () => change(name, input.checked));
	return input;
}

function imageControl(name, field) {
	const box = element('div', { className: 'ww-editor__image' });
	const render = () => {
		const { url } = display(name);
		const buttons = [element('button', { type: 'button', className: 'button', textContent: strings.chooseImage, onclick: choose })];
		if (url) {
			buttons.push(element('button', { type: 'button', className: 'button-link ww-editor__remove', textContent: strings.removeImage, onclick: remove }));
		}
		box.replaceChildren(...(url ? [element('img', { src: url, alt: '' })] : []), element('p', {}, buttons));
	};
	const choose = () => {
		const media = window.wp.media({
			title: field.label,
			library: { type: 'image' },
			multiple: false,
			button: { text: strings.useImage },
		});
		media.on('select', () => {
			const attachment = media.state().get('selection').first().toJSON();
			const sizes = attachment.sizes || {};
			previews.set(name, (sizes.large || sizes.full || attachment).url);
			change(name, attachment.id);
			render();
		});
		media.open();
	};
	const remove = () => {
		change(name, 0);
		render();
	};
	render();
	return box;
}

function itemTitle(item) {
	return `${item.title || strings.untitled}${item.published ? '' : ` (${strings.notPublished})`}`;
}

function iconButton(icon, label, onclick, disabled = false) {
	return element('button', { type: 'button', className: 'button-link ww-editor__item-button', disabled, onclick }, [
		element('span', { className: `dashicons dashicons-${icon}` }),
		element('span', { className: 'screen-reader-text', textContent: label }),
	]);
}

function relationIds(name) {
	const value = valueOf(name);
	if (fields[name].multiple) {
		return Array.isArray(value) ? [...value] : [];
	}
	return value ? [value] : [];
}

// Relatie: de gekozen berichten in hun volgorde, te slepen of met de pijltjes te verplaatsen, en zoeken om er een
// toe te voegen. Bij één waarde vervangt een gekozen bericht het vorige.
function relationControl(name, field, id) {
	const list = element('ol', { className: 'ww-editor__items' });
	const input = element('input', { id, type: 'search', className: 'regular-text', placeholder: strings.addItem, autocomplete: 'off' });
	const results = element('ul', { className: 'ww-editor__results' });
	let dragged = null;

	const render = () => {
		const ids = relationIds(name);
		if (ids.length === 0) {
			list.replaceChildren(element('li', { className: 'description', textContent: strings.noItems }));
			return;
		}
		list.replaceChildren(
			...ids.map((itemId, index) => {
				const item = items.get(itemId) || { id: itemId, title: '', published: true };
				const buttons = field.multiple
					? [
							iconButton('arrow-up-alt2', strings.moveUp, () => move(index, index - 1, 0), index === 0),
							iconButton('arrow-down-alt2', strings.moveDown, () => move(index, index + 1, 1), index === ids.length - 1),
						]
					: [];
				const row = element('li', { className: 'ww-editor__item', draggable: field.multiple }, [
					element('span', { className: 'ww-editor__item-title', textContent: itemTitle(item) }),
					...buttons,
					iconButton('no-alt', strings.removeItem, () => set(ids.filter((other) => other !== itemId))),
				]);
				row.addEventListener('dragstart', (event) => {
					dragged = index;
					event.dataTransfer.effectAllowed = 'move';
					event.dataTransfer.setData('text/plain', String(itemId));
				});
				row.addEventListener('dragover', (event) => dragged !== null && event.preventDefault());
				row.addEventListener('drop', (event) => {
					event.preventDefault();
					if (dragged !== null && dragged !== index) {
						move(dragged, index);
					}
					dragged = null;
				});
				row.addEventListener('dragend', () => (dragged = null));
				return row;
			})
		);
	};
	const set = (ids, focus) => {
		change(name, field.multiple ? ids : (ids[0] ?? 0));
		render();
		// Na verplaatsen houdt de knop de focus, op de nieuwe plek.
		if (focus) {
			list.children[focus.index]?.querySelectorAll('button')[focus.button]?.focus();
		}
	};
	const move = (from, to, button) => {
		const ids = relationIds(name);
		ids.splice(to, 0, ...ids.splice(from, 1));
		set(ids, button === undefined ? null : { index: to, button });
	};
	const add = (itemId) => {
		set(field.multiple ? [...relationIds(name), itemId] : [itemId]);
		input.value = '';
		results.replaceChildren();
		input.focus();
	};
	const search = async () => {
		const term = input.value.trim();
		try {
			const query = new URLSearchParams({ field: name, search: term });
			const found = await window.wp.apiFetch({ path: `${data.endpoint}/items?${query}` });
			if (input.value.trim() !== term) {
				return;
			}
			remember(found);
			const chosen = relationIds(name);
			const options = found.filter((item) => !chosen.includes(item.id));
			results.replaceChildren(
				...options.map((item) => element('li', {}, [element('button', { type: 'button', className: 'button-link', textContent: itemTitle(item), onclick: () => add(item.id) })]))
			);
			if (options.length === 0) {
				results.replaceChildren(element('li', { className: 'description', textContent: strings.noMatches }));
			}
		} catch (error) {
			results.replaceChildren();
		}
	};

	let timer;
	input.addEventListener('input', () => {
		clearTimeout(timer);
		timer = setTimeout(search, 250);
	});
	input.addEventListener('focus', search);
	render();
	return element('div', { className: 'ww-editor__relation' }, [list, input, results, element('p', { className: 'description', textContent: strings.afterSave })]);
}

// Invoer per soort veld; een bestandsveld is alleen als één foto te bewerken, een relatie alleen met berichten.
const CONTROLS = {
	...Object.fromEntries(Object.keys(INPUT_TYPES).map((type) => [type, textControl])),
	paragraph: textControl,
	website: linkControl,
	wysiwyg: wysiwygControl,
	boolean: booleanControl,
	image: imageControl,
	pick: relationControl,
};

function kindOf(field) {
	if (field.type === 'pick') {
		return field.editable ? 'pick' : '';
	}
	if (field.type !== 'file') {
		return field.type;
	}
	return field.images && !field.multiple ? 'image' : '';
}

function control(name) {
	const field = fields[name];
	const id = `ww-editor-${name}`;
	const kind = kindOf(field);
	const build = Object.hasOwn(CONTROLS, kind) ? CONTROLS[kind] : null;
	const input = build ? build(name, field, id) : element('p', { className: 'description', textContent: strings.notYet });
	// Een foto of een veld zonder invoer heeft een kop in plaats van een label; een vinkje staat vóór zijn label.
	const label =
		build && kind !== 'image'
			? element('label', { htmlFor: id, className: 'ww-editor__label', textContent: field.label })
			: element('p', { className: 'ww-editor__label', textContent: field.label });
	return kind === 'boolean'
		? element('div', { className: 'ww-editor__field ww-editor__field--check' }, [input, label])
		: element('div', { className: 'ww-editor__field' }, [label, input]);
}

// Wat het paneel toont: de velden van het element, van de sectie, of de pagina-instellingen met daaronder de
// overige velden.
function panelContent() {
	if (selected) {
		return { title: strings.edit, controls: selected.map(control) };
	}
	if (section) {
		return { title: sectionLabel(section), controls: sectionFields(section).map(control) };
	}
	if (!pageOpen) {
		return null;
	}
	const other = otherFields();
	const rest = other.length > 0 ? [element('h3', { className: 'ww-editor__group', textContent: strings.other }), ...other.map(control)] : [];
	return { title: strings.page, controls: [...PAGE_FIELDS.map(control), ...rest, element('p', { className: 'description', textContent: strings.hint })] };
}

function renderFields() {
	stopEditors();
	const content = panelContent();
	pageToggle.setAttribute('aria-expanded', String(!selected && !section && pageOpen));
	// TinyMCE start pas als het paneel zichtbaar is; in een verborgen paneel meet hij zich verkeerd.
	panel.hidden = !content;
	if (!content) {
		fieldsBox.replaceChildren();
		return;
	}
	panelTitle.textContent = content.title;
	fieldsBox.replaceChildren(...content.controls);
	editors.forEach((name, id) => startEditor(id, name));
	if (selected || section) {
		fieldsBox.querySelector('input, textarea:not(.wp-editor-area), .ww-editor__image button')?.focus();
	}
}

// Een element of sectie kiezen sluit de pagina-instellingen; niets kiezen sluit het paneel, of toont de
// pagina-instellingen.
function select(names, page = false, sectionName = null) {
	selected = names && names.length > 0 ? names : null;
	section = selected ? null : sectionName;
	pageOpen = !selected && !section && page;
	if (!selected && !section) {
		send({ type: 'deselect' });
	}
	renderFields();
}

function togglePage() {
	select(null, !pageOpen);
	if (pageOpen) {
		fieldsBox.querySelector('input')?.focus();
	}
}

/*
 * Opslaan.
 */

function button(text, status, primary) {
	return element('button', {
		type: 'button',
		className: primary ? 'button button-primary' : 'button',
		textContent: text,
		disabled: busy || (changes.size === 0 && status !== 'publish'),
		onclick: () => save(status),
	});
}

function renderActions() {
	root.querySelector('[data-ww-editor-status]').textContent = post.published ? strings.published : strings.draft;
	const count = busy ? strings.saving : message || (changes.size ? strings.changes.replace('%d', String(changes.size)) : strings.noChanges);
	const buttons = post.published
		? [button(strings.update, '', true)]
		: [button(strings.saveDraft, '', !data.canPublish), ...(data.canPublish ? [button(strings.publish, 'publish', true)] : [])];
	actionsBox.replaceChildren(element('p', { className: 'ww-editor__message', role: 'status', textContent: count }), element('p', { className: 'ww-editor__buttons' }, buttons));
}

// Wat de gebruiker tijdens het opslaan nog verandert, is niet verstuurd en blijft dus als wijziging staan.
async function save(status) {
	const sent = new Map(changes);
	const body = { fields: {}, post: {}, status };
	sent.forEach((value, name) => {
		(PAGE_FIELDS.includes(name) ? body.post : body.fields)[name] = value;
	});
	busy = true;
	renderActions();
	try {
		const result = await window.wp.apiFetch({ path: data.endpoint, method: 'POST', data: body });
		post = result.post;
		Object.assign(fields, result.fields);
		Object.values(result.fields).forEach((field) => remember(field.items || []));
		sent.forEach((value, name) => {
			if (changes.get(name) === value) {
				changes.delete(name);
				previews.delete(name);
			}
		});
		message = strings.saved;
		root.querySelector('[data-ww-editor-view]').href = post.link;
		frame.src = post.frame;
		renderFields();
	} catch (error) {
		message = error?.message || strings.error;
	}
	busy = false;
	renderActions();
}

/*
 * Berichten van de pagina in het iframe.
 */

window.addEventListener('message', (event) => {
	if (event.source !== frame.contentWindow || event.origin !== data.origin) {
		return;
	}
	const { type } = event.data || {};
	if (type === 'ready') {
		marks = new Set((event.data.marks || []).filter((name) => typeof name === 'string'));
		sections = (event.data.sections || []).filter((item) => typeof item?.name === 'string');
		// Welke velden het paneel toont, hangt af van wat de pagina markeert. Na het opslaan staat dezelfde sectie
		// weer open, als hij er nog is.
		if (section && !sectionInfo()[section]?.editable) {
			select(null);
		} else if (section || pageOpen) {
			renderFields();
		}
		const labels = Object.fromEntries(Object.entries(fields).map(([name, field]) => [name, { label: field.label, type: field.type }]));
		const frameStrings = { hidden: strings.hidden, inSettings: strings.inSettings };
		send({ type: 'fields', fields: labels, strings: frameStrings, sections: sectionInfo(), scroll: scrollY, selected, section });
		changes.forEach((value, name) => send({ type: 'value', name, value: display(name) }));
	} else if (type === 'select') {
		select((event.data.fields || []).filter((name) => Object.hasOwn(fields, name)));
	} else if (type === 'section') {
		if (sectionInfo()[event.data.name]?.editable) {
			select(null, false, event.data.name);
		}
	} else if (type === 'scroll') {
		scrollY = Number(event.data.y) || 0;
	}
});

root.querySelectorAll('[data-ww-device]').forEach((toggle, index, all) => {
	toggle.addEventListener('click', () => {
		all.forEach((other) => other.setAttribute('aria-pressed', String(other === toggle)));
		canvas.dataset.wwDevice = toggle.dataset.wwDevice;
	});
});

pageToggle.addEventListener('click', togglePage);
root.querySelector('[data-ww-editor-close]').addEventListener('click', () => select(null));

document.addEventListener('keydown', (event) => {
	if (event.key === 'Escape' && !panel.hidden && !document.querySelector('.media-modal')?.offsetParent) {
		select(null);
	}
});

window.addEventListener('beforeunload', (event) => {
	if (changes.size > 0) {
		event.preventDefault();
		event.returnValue = strings.leave;
	}
});

Object.values(fields).forEach((field) => remember(field.items || []));
renderFields();
renderActions();
