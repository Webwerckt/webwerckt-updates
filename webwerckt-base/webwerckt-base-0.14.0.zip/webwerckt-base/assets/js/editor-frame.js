// Visueel bewerken, in de pagina in het iframe (ADR 0019): maakt de elementen met data-ww-edit aanklikbaar, meldt
// een klik aan het zijpaneel (editor.js) en toont wijzigingen direct. Het zijpaneel stuurt eerst de velden van de
// pagina; een markering voor een onbekend veld blijft gewoon tekst. Secties van ww_section() staan tussen twee
// HTML-commentaren; bij hover krijgt een sectie een knop die zijn schakelaar en overige velden opent.

const config = JSON.parse(document.getElementById('ww-editor-frame-data').textContent);
const EMPTY_IMAGE = 'data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%2F%3E';
// Gewone links: http(s), mailto, tel, een pad, een anker of leeg. Geen javascript: of data:.
const SAFE_URL = /^(https?:|mailto:|tel:|\/|#|$)/i;
// Wat de WYSIWYG-editor maakt, met de attributen per element. Elk element mag class en style hebben.
const ALLOWED_HTML = {
	p: [],
	h2: [],
	h3: [],
	h4: [],
	strong: [],
	b: [],
	em: [],
	i: [],
	del: [],
	span: [],
	br: [],
	blockquote: [],
	ul: [],
	ol: [],
	li: [],
	a: ['href', 'target', 'rel'],
	img: ['src', 'alt', 'width', 'height'],
};
const URL_ATTRS = ['href', 'src'];
// Deze elementen vallen met hun inhoud weg; een ander onbekend element laat zijn inhoud staan.
const DROPPED = ['script', 'style', 'template', 'iframe', 'object', 'embed', 'noscript'];
// <!--ww-section:{naam}:{bron}--> ... <!--/ww-section:{naam}-->, uit ww_section().
const SECTION_START = /^ww-section:([a-z0-9_-]+):(page|settings)$/;

let fields = {};
// Sectienaam => wat het zijpaneel erover meldt: label, of hij te bewerken is, of hij uit staat, of hij in de
// Site-instellingen staat. Een sectie die het paneel niet noemt, krijgt geen knop.
let sectionInfo = {};
let strings = {};
const badge = document.createElement('ww-edit-badge');
badge.hidden = true;
const sectionBadge = document.createElement('ww-section-badge');
sectionBadge.hidden = true;
document.body.append(badge, sectionBadge);

// Sectienaam => bron en de elementen tussen de commentaren. Die elementen krijgen data-ww-section, zodat een
// element in de pagina zijn sectie vindt met closest().
const sections = findSections();

function send(payload) {
	window.parent.postMessage(payload, config.origin);
}

function findSections() {
	const found = new Map();
	const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_COMMENT);
	for (let comment = walker.nextNode(); comment; comment = walker.nextNode()) {
		const match = SECTION_START.exec(comment.data);
		if (!match) {
			continue;
		}
		const [, name, source] = match;
		const section = found.get(name) || { source, nodes: [] };
		for (let node = comment.nextSibling; node && !(node.nodeType === Node.COMMENT_NODE && node.data === `/ww-section:${name}`); node = node.nextSibling) {
			if (node.nodeType === Node.ELEMENT_NODE) {
				node.dataset.wwSection = name;
				section.nodes.push(node);
			}
		}
		found.set(name, section);
	}
	return found;
}

// Alle veldnamen van een element, in volgorde: de eerste is de inhoud, de rest attributen.
function namesOf(node) {
	return (node.dataset.wwEdit || '').split(' ').filter(Boolean);
}

// De veldnamen van een element die het zijpaneel kent.
function knownNamesOf(node) {
	return namesOf(node).filter((name) => Object.hasOwn(fields, name));
}

function decorate() {
	document.querySelectorAll('[data-ww-edit]').forEach((node) => {
		const known = knownNamesOf(node);
		if (known.length > 0) {
			node.dataset.wwEditable = '';
			node.dataset.wwLabel = known.map((name) => fields[name].label).join(' + ');
		} else {
			delete node.dataset.wwEditable;
		}
	});
}

// Een uitgezette sectie staat er in de editor toch, gedimd.
function decorateSections() {
	sections.forEach(({ nodes }, name) => nodes.forEach((node) => node.toggleAttribute('data-ww-section-off', Boolean(sectionInfo[name]?.off))));
}

// Kiest een element of een sectie; de rest is dan niet meer gekozen.
function select(node, section = null) {
	document.querySelectorAll('[data-ww-selected]').forEach((other) => delete other.dataset.wwSelected);
	document.querySelectorAll('[data-ww-section-selected]').forEach((other) => delete other.dataset.wwSectionSelected);
	if (node) {
		node.dataset.wwSelected = '';
	}
	sections.get(section)?.nodes.forEach((other) => (other.dataset.wwSectionSelected = ''));
}

// HTML uit de WYSIWYG-editor, opnieuw opgebouwd met alleen de elementen en attributen van ALLOWED_HTML. Het is de
// eigen tekst van de gebruiker en PHP filtert hem bij het tonen toch, maar dit frame heeft dezelfde herkomst als de
// admin: een voorbeeld hoort niets uit te voeren of te laden. Een allowlist, omdat een lijst met verboden dingen
// nooit compleet is.
function cleanHtml(html) {
	return cleanChildren(new DOMParser().parseFromString(html, 'text/html').body);
}

function cleanChildren(parent) {
	return Array.from(parent.childNodes).flatMap((node) => {
		if (node.nodeType === Node.TEXT_NODE) {
			return [document.createTextNode(node.data)];
		}
		if (node.nodeType !== Node.ELEMENT_NODE || DROPPED.includes(node.localName)) {
			return [];
		}
		const children = cleanChildren(node);
		if (!Object.hasOwn(ALLOWED_HTML, node.localName)) {
			return children;
		}
		const copy = document.createElement(node.localName);
		[...ALLOWED_HTML[node.localName], 'class', 'style'].forEach((name) => {
			const value = node.getAttribute(name);
			if (value !== null && (!URL_ATTRS.includes(name) || SAFE_URL.test(value))) {
				copy.setAttribute(name, value);
			}
		});
		copy.append(...children);
		return [copy];
	});
}

// Toont een wijziging direct. Na het opslaan laadt het zijpaneel de pagina opnieuw; dan rendert PHP het echt.
function apply(name, value) {
	document.querySelectorAll('[data-ww-edit]').forEach((node) => {
		const index = namesOf(node).indexOf(name);
		if (index === -1) {
			return;
		}
		if (node instanceof HTMLImageElement) {
			node.removeAttribute('srcset');
			node.removeAttribute('sizes');
			node.src = value?.url || EMPTY_IMAGE;
			node.toggleAttribute('data-ww-empty', !value?.url);
		} else if (index > 0) {
			// Een link op het element zelf of eromheen (een tegel met het label erin). Alleen gewone links; bij
			// opslaan escapet PHP de URL toch zelf.
			const link = node.closest('[href]');
			if (link && SAFE_URL.test(String(value ?? ''))) {
				link.setAttribute('href', String(value ?? ''));
			}
		} else if (typeof value?.html === 'string') {
			node.replaceChildren(...cleanHtml(value.html));
		} else if (typeof value === 'string') {
			node.innerText = value;
		}
	});
}

// Het gemarkeerde element onder de muis. Een foto onder een overlay telt ook: een pseudo-element van de sectie
// (dan bevat het aangeklikte element de foto) of een lege overlay zonder tekst. Een tekst die zelf niet gemarkeerd
// is, laat de foto eronder met rust; anders zou een klik op een titel de foto kiezen.
function targetOf(event) {
	const direct = event.target.closest('[data-ww-editable]');
	if (direct) {
		return direct;
	}
	const below = document.elementsFromPoint(event.clientX, event.clientY).find((node) => node.matches('[data-ww-editable]'));
	return below && (event.target.contains(below) || event.target.textContent.trim() === '') ? below : null;
}

function hover(node) {
	document.querySelectorAll('[data-ww-hover]').forEach((other) => other !== node && delete other.dataset.wwHover);
	badge.hidden = !node;
	if (!node) {
		return;
	}
	node.dataset.wwHover = '';
	const rect = node.getBoundingClientRect();
	badge.textContent = `✎ ${node.dataset.wwLabel}`;
	badge.style.top = `${Math.max(0, rect.top + window.scrollY - 24)}px`;
	badge.style.left = `${Math.max(0, rect.left + window.scrollX)}px`;
}

// De knop van een sectie, rechtsboven in de sectie: de naam, en of hij verborgen is of in de Site-instellingen staat.
function hoverSection(name) {
	const info = sectionInfo[name];
	sectionBadge.hidden = !info;
	if (!info) {
		delete sectionBadge.dataset.wwSectionName;
		return;
	}
	const rects = (sections.get(name)?.nodes || []).map((node) => node.getBoundingClientRect()).filter((rect) => rect.width > 0);
	if (rects.length === 0) {
		sectionBadge.hidden = true;
		return;
	}
	const top = Math.min(...rects.map((rect) => rect.top));
	const right = Math.max(...rects.map((rect) => rect.right));
	sectionBadge.dataset.wwSectionName = name;
	sectionBadge.toggleAttribute('data-ww-clickable', Boolean(info.editable));
	sectionBadge.textContent = info.settings ? strings.inSettings : `⚙ ${info.label}${info.off ? ` · ${strings.hidden}` : ''}`;
	sectionBadge.style.top = `${Math.max(0, top + window.scrollY + 8)}px`;
	sectionBadge.style.left = `${Math.max(0, right + window.scrollX - 8 - sectionBadge.offsetWidth)}px`;
}

document.addEventListener(
	'click',
	(event) => {
		if (event.target === sectionBadge) {
			event.preventDefault();
			event.stopPropagation();
			const name = sectionBadge.dataset.wwSectionName;
			if (sectionInfo[name]?.editable) {
				select(null, name);
				send({ type: 'section', name });
			}
			return;
		}
		const node = targetOf(event);
		// Geen links volgen of formulieren versturen: de pagina staat hier alleen om te bewerken.
		if (node || event.target.closest('a[href]')) {
			event.preventDefault();
		}
		if (!node) {
			return;
		}
		event.stopPropagation();
		select(node);
		send({ type: 'select', fields: namesOf(node) });
	},
	true
);

document.addEventListener('submit', (event) => event.preventDefault(), true);

document.addEventListener('mousemove', (event) => {
	hover(targetOf(event));
	// Op de knop zelf blijft de sectie gekozen; de knop staat buiten de sectie in de body.
	if (event.target !== sectionBadge) {
		hoverSection(event.target.closest('[data-ww-section]')?.dataset.wwSection);
	}
});
document.addEventListener('mouseleave', () => {
	hover(null);
	hoverSection(null);
});

let scrollQueued = false;
window.addEventListener('scroll', () => {
	if (scrollQueued) {
		return;
	}
	scrollQueued = true;
	requestAnimationFrame(() => {
		scrollQueued = false;
		send({ type: 'scroll', y: window.scrollY });
	});
});

window.addEventListener('message', (event) => {
	if (event.source !== window.parent || event.origin !== config.origin) {
		return;
	}
	const { type } = event.data || {};
	if (type === 'fields') {
		fields = event.data.fields || {};
		strings = event.data.strings || {};
		sectionInfo = event.data.sections || {};
		decorate();
		decorateSections();
		// Na het opslaan laadt de pagina opnieuw: dezelfde plek en hetzelfde element of dezelfde sectie als daarvoor.
		window.scrollTo(0, Number(event.data.scroll) || 0);
		const names = (event.data.selected || []).join(' ');
		select(names ? Array.from(document.querySelectorAll('[data-ww-edit]')).find((node) => node.dataset.wwEdit === names) : null, event.data.section);
	} else if (type === 'sections') {
		sectionInfo = event.data.sections || {};
		decorateSections();
	} else if (type === 'value') {
		apply(event.data.name, event.data.value);
	} else if (type === 'deselect') {
		select(null);
	}
});

// Het zijpaneel bepaalt welke velden nergens gemarkeerd zijn; die horen bij hun sectie of bij de pagina.
send({
	type: 'ready',
	marks: [...new Set(Array.from(document.querySelectorAll('[data-ww-edit]')).flatMap(namesOf))],
	sections: Array.from(sections, ([name, { source }]) => ({ name, source })),
});
