// Filteren zonder herladen: progressive enhancement op gewone links naar taxonomie-archieven.
// Zonder JavaScript (of bij een fout) opent de link het gefilterde archief, dat Google ook indexeert.
// Eén actieve term tegelijk; de meer-laden-knop van dezelfde lijst gaat mee met het filter.

import { announce, endpointUrl, fetchCards, listFor, parseCards } from 'ww-rest';

const SELECTOR = '[data-ww-filter]';
const LINK = 'a[data-ww-term]';

// Lopende aanvraag per post type: een nieuwe klik breekt de vorige af, zodat het laatste filter wint.
const requests = new Map();

function linksFor(postType) {
	return document.querySelectorAll(`[data-ww-filter="${CSS.escape(postType)}"] ${LINK}`);
}

// "Alle" heeft een lege term en is actief in elke groep zodra er geen filter is.
function isLinkFor(link, taxonomy, term) {
	return link.dataset.wwTerm === term && (term === '' || link.dataset.wwTaxonomy === taxonomy);
}

function markCurrent(postType, taxonomy, term) {
	for (const link of linksFor(postType)) {
		if (isLinkFor(link, taxonomy, term)) {
			link.setAttribute('aria-current', 'page');
		} else {
			link.removeAttribute('aria-current');
		}
	}
}

function updateLoadMore(postType, tax, data) {
	const button = document.querySelector(`[data-ww-load-more="${CSS.escape(postType)}"]`);
	if (!button) {
		return;
	}
	button.dataset.wwPage = '1';
	button.dataset.wwTax = JSON.stringify(tax);
	if (data.next_url) {
		button.href = data.next_url;
	}
	button.hidden = !data.has_more;
}

async function applyFilter(container, taxonomy, term, url, addToHistory) {
	const postType = container.dataset.wwFilter;
	const list = listFor(postType);
	const endpoint = endpointUrl(container.dataset.wwEndpoint || '');
	if (!list || !endpoint) {
		window.location.href = url;
		return;
	}

	requests.get(postType)?.abort();
	const request = new AbortController();
	requests.set(postType, request);

	const tax = term ? { [taxonomy]: term } : {};
	list.setAttribute('aria-busy', 'true');
	try {
		const data = await fetchCards(endpoint, postType, 1, tax, request.signal);
		list.replaceChildren(parseCards(data.html));
		list.removeAttribute('aria-busy');
		markCurrent(postType, taxonomy, term);
		updateLoadMore(postType, tax, data);
		if (addToHistory && container.dataset.wwHistory) {
			history.pushState({ wwFilter: postType, taxonomy, term }, '', url);
		}
		announce((container.dataset.wwResults || '%d').replace('%d', String(data.total ?? 0)));
	} catch (error) {
		if (error.name !== 'AbortError') {
			// Terugvallen op het gewone taxonomie-archief.
			window.location.href = url;
		}
	}
}

function init(container) {
	container.addEventListener('click', (event) => {
		const link = event.target.closest(LINK);
		const opensElsewhere = event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey;
		if (!link || !container.contains(link) || opensElsewhere) {
			return;
		}
		event.preventDefault();
		applyFilter(container, link.dataset.wwTaxonomy || '', link.dataset.wwTerm || '', link.href, true);
	});
}

// Terug en vooruit in de browser: het filter van die stap opnieuw toepassen.
function initHistory(container) {
	const postType = container.dataset.wwFilter;
	const current = container.querySelector(`${LINK}[aria-current="page"]`);
	history.replaceState(
		{
			...history.state,
			wwFilter: postType,
			taxonomy: current?.dataset.wwTaxonomy || '',
			term: current?.dataset.wwTerm || '',
		},
		''
	);

	window.addEventListener('popstate', (event) => {
		const state = event.state;
		if (!state || state.wwFilter !== postType) {
			return;
		}
		const shown = container.querySelector(`${LINK}[aria-current="page"]`);
		if (!shown || !isLinkFor(shown, state.taxonomy, state.term)) {
			applyFilter(container, state.taxonomy, state.term, window.location.href, false);
		}
	});
}

const containers = Array.from(document.querySelectorAll(SELECTOR));
containers.forEach(init);

const historyContainer = containers.find((container) => container.dataset.wwHistory);
if (historyContainer) {
	initHistory(historyContainer);
}
