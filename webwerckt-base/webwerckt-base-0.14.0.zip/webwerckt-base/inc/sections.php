<?php
/**
 * Secties die per pagina aan of uit staan; de volgorde ligt vast in het template.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Staat een sectie aan? Ontbreekt de schakelaar `child_{sectie}_enabled`, dan wel.
 * Secties en hun schakelaars horen bij het child-thema, dus de schakelaar heeft het child-voorvoegsel.
 *
 * @param string $name   Sectienaam, bijvoorbeeld 'hero'.
 * @param string $source 'page' (veld van de huidige pagina) of 'settings' (Site-instellingen).
 */
function ww_section_enabled( string $name, string $source = 'page' ): bool {
	$field = _ww_child_prefix() . $name . '_enabled';
	$value = 'settings' === $source ? _ww_data_get_setting( $field ) : _ww_data_get( $field );

	return null === $value ? true : _ww_data_to_bool( $value );
}

/**
 * Toont een sectie als hij aan staat, via template-parts/section-{naam}.php van het child-thema.
 *
 * In Visueel bewerken (ADR 0019) staat de sectie tussen twee HTML-commentaren, zodat de editor weet welke elementen
 * erbij horen, en staat een uitgezette sectie van de pagina er toch: de editor toont hem gedimd, zodat hij weer aan
 * te zetten is. Een sectie uit de Site-instellingen blijft weg als hij uit staat; die is hier niet te bewerken.
 *
 * @param string $name   Sectienaam, bijvoorbeeld 'hero'.
 * @param string $source 'page' of 'settings'.
 */
function ww_section( string $name, string $source = 'page' ): void {
	$slug = sanitize_key( $name );
	if ( '' === $slug ) {
		return;
	}
	$source  = 'settings' === $source ? 'settings' : 'page';
	$editing = _ww_editor_marks( 0 );
	if ( ! ( $editing && 'page' === $source ) && ! ww_section_enabled( $slug, $source ) ) {
		return;
	}
	if ( $editing ) {
		echo '<!--ww-section:' . esc_html( $slug . ':' . $source ) . '-->';
	}
	get_template_part( 'template-parts/section', $slug );
	if ( $editing ) {
		echo '<!--/ww-section:' . esc_html( $slug ) . '-->';
	}
}
