<?php
/**
 * LiteSpeed Cache: tags en purges. Alles zijn hooks; zonder actieve plugin gebeurt er niets.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Cache-tag van een post type, bijvoorbeeld 'ww_service'.
 */
function _ww_cache_tag_name( string $post_type ): string {
	return 'ww_' . sanitize_key( $post_type );
}

/**
 * Voegt de pagina die nu wordt opgebouwd toe aan de tag van een post type.
 */
function _ww_cache_tag( string $post_type ): void {
	if ( '' === $post_type ) {
		return;
	}
	do_action( 'litespeed_tag_add', _ww_cache_tag_name( $post_type ) );
}

/**
 * Leegt alleen de pagina's met de tag van het post type van een opgeslagen of verwijderd item.
 */
function _ww_cache_purge_post( int $post_id ): void {
	if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
		return;
	}
	$post_type = get_post_type( $post_id );
	if ( $post_type ) {
		do_action( 'litespeed_purge', _ww_cache_tag_name( $post_type ) );
	}
}
add_action( 'deleted_post', '_ww_cache_purge_post' );

/**
 * Opgeslagen, gepubliceerd, teruggezet naar concept of naar de prullenbak: leegt de tag als het item voor
 * of na de wijziging zichtbaar is voor bezoekers. Een concept of auto-draft staat op geen enkele openbare
 * pagina, dus tussentijds opslaan laat de cache staan.
 *
 * @param mixed $new_status Nieuwe status.
 * @param mixed $old_status Vorige status ('new' bij een nieuw bericht).
 * @param mixed $post       Bericht.
 */
function _ww_cache_purge_on_status( $new_status, $old_status, $post ): void {
	if ( ! $post instanceof WP_Post ) {
		return;
	}
	if ( is_post_status_viewable( (string) $new_status ) || is_post_status_viewable( (string) $old_status ) ) {
		_ww_cache_purge_post( $post->ID );
	}
}
add_action( 'transition_post_status', '_ww_cache_purge_on_status', 10, 3 );

/**
 * Term aangemaakt, gewijzigd of verwijderd: pagina's met de tags van de post types van die taxonomie leeg,
 * want daar staan de termen als filterlinks of labels.
 *
 * @param mixed $term_id  Term-ID.
 * @param mixed $tt_id    Term-taxonomie-ID.
 * @param mixed $taxonomy Taxonomie; een hook kan van alles doorgeven, dus pas na controle een string.
 */
function _ww_cache_purge_term( $term_id, $tt_id, $taxonomy ): void {
	$object = is_string( $taxonomy ) ? get_taxonomy( $taxonomy ) : false;
	foreach ( $object ? $object->object_type : array() as $post_type ) {
		do_action( 'litespeed_purge', _ww_cache_tag_name( (string) $post_type ) );
	}
}
add_action( 'created_term', '_ww_cache_purge_term', 10, 3 );
add_action( 'edited_term', '_ww_cache_purge_term', 10, 3 );
add_action( 'delete_term', '_ww_cache_purge_term', 10, 3 );

/**
 * Leegt de pagina's die een menu tonen (ww_menu()) als een bericht of term in een menu staat.
 * Menu-items zelf zijn berichten: opslaan of verwijderen leegt de tag al via de purges hierboven.
 *
 * @param string $object_type 'post_type' of 'taxonomy'.
 */
function _ww_cache_purge_menu_of( string $object_type, int $object_id, string $taxonomy = '' ): void {
	if ( array() !== wp_get_associated_nav_menu_items( $object_id, $object_type, $taxonomy ) ) {
		do_action( 'litespeed_purge', _ww_cache_tag_name( 'nav_menu_item' ) );
	}
}

/**
 * Titel, slug, ouder of status van een bericht gewijzigd: het menu toont zijn titel en URL, of verbergt het.
 *
 * @param mixed $post_id Bericht-ID.
 * @param mixed $after   Bericht na de wijziging.
 * @param mixed $before  Bericht voor de wijziging.
 */
function _ww_cache_purge_menu_on_post_update( $post_id, $after, $before ): void {
	if ( ! $after instanceof WP_Post || ! $before instanceof WP_Post ) {
		return;
	}
	$changed = $after->post_title !== $before->post_title
		|| $after->post_name !== $before->post_name
		|| $after->post_parent !== $before->post_parent
		|| $after->post_status !== $before->post_status;
	if ( $changed ) {
		_ww_cache_purge_menu_of( 'post_type', (int) $post_id );
	}
}
add_action( 'post_updated', '_ww_cache_purge_menu_on_post_update', 10, 3 );

/**
 * Term gewijzigd: het menu toont zijn naam en URL.
 *
 * @param mixed $term_id  Term-ID.
 * @param mixed $tt_id    Term-taxonomie-ID.
 * @param mixed $taxonomy Taxonomie.
 */
function _ww_cache_purge_menu_on_term_edit( $term_id, $tt_id, $taxonomy ): void {
	if ( is_string( $taxonomy ) ) {
		_ww_cache_purge_menu_of( 'taxonomy', (int) $term_id, $taxonomy );
	}
}
add_action( 'edited_term', '_ww_cache_purge_menu_on_term_edit', 10, 3 );

/**
 * Ander menu op een menulocatie (menuscherm of Customizer): de pagina's met een menu leeg.
 * Een filter, omdat set_theme_mod() alleen hier de oude en nieuwe waarde samen doorgeeft; de waarde blijft gelijk.
 *
 * @param mixed $value     Nieuwe menulocaties.
 * @param mixed $old_value Vorige menulocaties.
 * @return mixed
 */
function _ww_cache_purge_on_menu_locations( $value, $old_value ) {
	if ( $value !== $old_value ) {
		do_action( 'litespeed_purge', _ww_cache_tag_name( 'nav_menu_item' ) );
	}
	return $value;
}
add_filter( 'pre_set_theme_mod_nav_menu_locations', '_ww_cache_purge_on_menu_locations', 10, 2 );

/**
 * Leegt de hele cache.
 */
function _ww_cache_purge_all(): void {
	do_action( 'litespeed_purge_all' );
}

/**
 * Optie van de Site-instellingen gewijzigd: hele cache leeg, want ze staan op elke pagina.
 *
 * @param mixed $option Naam van de optie; een hook kan van alles doorgeven, dus pas na controle een string.
 */
function _ww_cache_purge_on_settings_save( $option ): void {
	$prefix = _ww_settings_prefix();
	if ( '' !== $prefix && is_string( $option ) && str_starts_with( $option, $prefix ) ) {
		_ww_cache_purge_all();
	}
}
add_action( 'added_option', '_ww_cache_purge_on_settings_save' );
add_action( 'updated_option', '_ww_cache_purge_on_settings_save' );
add_action( 'deleted_option', '_ww_cache_purge_on_settings_save' );

/**
 * Update van de parent: hele cache leeg.
 *
 * @param mixed               $upgrader   WP_Upgrader.
 * @param array<string,mixed> $hook_extra Gegevens over de update.
 */
function _ww_cache_purge_on_upgrade( $upgrader, $hook_extra ): void {
	$is_theme_update = 'theme' === ( $hook_extra['type'] ?? '' );
	if ( $is_theme_update && in_array( WW_BASE_SLUG, (array) ( $hook_extra['themes'] ?? array() ), true ) ) {
		_ww_cache_purge_all();
	}
}
add_action( 'upgrader_process_complete', '_ww_cache_purge_on_upgrade', 10, 2 );
