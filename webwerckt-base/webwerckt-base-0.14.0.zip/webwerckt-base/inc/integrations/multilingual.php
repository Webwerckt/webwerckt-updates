<?php
/**
 * Koppelingen met WPML, Polylang en TranslatePress (besluit 0015). Alles hangt aan hooks en klassen van
 * die plugins: zonder vertaalplugin gebeurt er niets en breekt er niets.
 *
 * - Site-instellingen: wpml-config.xml in de parent noemt de velden van de parent (WPML en Polylang lezen
 *   dat bestand). De tekstvelden die het child-thema toevoegt (`site_settings_child_*`) komen er hier bij.
 * - Kaarten-endpoint: TranslatePress vertaalt de kaart-HTML in het antwoord, net als de rest van de pagina.
 *   WPML en Polylang krijgen de taal via ?lang= (inc/rest.php).
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Veldtypes met tekst om te vertalen. Een foto (attachment-ID) of ja/nee is in elke taal hetzelfde.
const WW_TRANSLATABLE_FIELD_TYPES = array( 'text', 'paragraph', 'wysiwyg', 'website', 'email', 'phone' );

/**
 * Optienamen van de vertaalbare velden die het child-thema aan de Site-instellingen toevoegt.
 *
 * @return string[]
 */
function _ww_child_setting_options(): array {
	$options = array();
	foreach ( _ww_pods_setting_fields() as $field ) {
		$name = _ww_data_to_string( $field['name'] ?? '' );
		if ( _ww_has_child_prefix( $name ) && in_array( $field['type'] ?? '', WW_TRANSLATABLE_FIELD_TYPES, true ) ) {
			$options[] = _ww_settings_prefix() . $name;
		}
	}
	return $options;
}

/**
 * WPML: voegt de velden van het child-thema toe aan de admin-texts uit wpml-config.xml.
 *
 * @param mixed $config Ingelezen wpml-config.xml-bestanden.
 * @return mixed
 */
function _ww_wpml_config_child_settings( $config ) {
	if ( ! is_array( $config ) ) {
		return $config;
	}

	$keys = $config['wpml-config']['admin-texts']['key'] ?? array();
	$keys = is_array( $keys ) ? $keys : array();
	// Is er maar één sleutel, dan staat die niet in een lijst.
	if ( isset( $keys['attr'] ) ) {
		$keys = array( $keys );
	}
	foreach ( _ww_child_setting_options() as $option ) {
		$keys[] = array( 'attr' => array( 'name' => $option ) );
	}

	$config['wpml-config']['admin-texts']['key'] = $keys;
	return $config;
}
add_filter( 'wpml_config_array', '_ww_wpml_config_child_settings' );

/**
 * Polylang: maakt de velden van het child-thema vertaalbaar onder Talen → Vertalingen, zoals Polylang
 * dat zelf doet voor de admin-texts uit wpml-config.xml. Polylang heeft geen filter op dat bestand.
 */
function _ww_polylang_child_settings(): void {
	// pll_init: Polylang heeft talen en zijn API geladen.
	if ( ! did_action( 'pll_init' ) || ! class_exists( 'PLL_Translate_Option' ) ) {
		return;
	}
	foreach ( _ww_child_setting_options() as $option ) {
		new PLL_Translate_Option( $option, array(), array( 'context' => 'themes/' . get_template() ) );
	}
}
// Na de registraties van het child-thema in after_setup_theme, vóór de frontend opties leest.
add_action( 'init', '_ww_polylang_child_settings' );

/**
 * TranslatePress: vertaalt de kaart-HTML van het kaarten-endpoint. TranslatePress haalt de taal uit de
 * URL (/en/wp-json/ww/v1/cards) en slaat de standaardtaal over.
 *
 * @param mixed $config REST-route => sleutels om te vertalen.
 * @return mixed
 */
function _ww_translatepress_rest_config( $config ) {
	if ( is_array( $config ) ) {
		$config['ww/v1/cards'] = array( 'html' );
	}
	return $config;
}
add_filter( 'trp_rest_api_translation_config', '_ww_translatepress_rest_config' );
