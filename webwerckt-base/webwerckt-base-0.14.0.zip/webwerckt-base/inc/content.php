<?php
/**
 * Kopie van de tekstvelden naar post_content, zodat wat in WordPress in die kolom kijkt ook met velden werkt:
 * de zoekfunctie, excerpts, de automatische beschrijving van The SEO Framework, de RSS-feed en plugins.
 *
 * Google leest post_content niet: die ziet de pagina zoals het child-thema hem rendert. post_content wordt
 * nooit direct bewerkt; alleen bij post types zonder editor, zodat tekst uit een editor nooit wordt overschreven.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Lichte HTML die in de kopie blijft staan: structuur voor RSS en plugins, geen afbeeldingen, scripts of opmaak.
 *
 * @return array<string,array<string,bool>>
 */
function _ww_content_allowed_html(): array {
	$tags = array_fill_keys( array( 'p', 'br', 'h2', 'h3', 'h4', 'ul', 'ol', 'li', 'strong', 'em' ), array() );
	return $tags + array( 'a' => array( 'href' => true ) );
}

/**
 * De tekstvelden van een bericht als lichte HTML, in de volgorde van de configuratie.
 */
function _ww_content_from_fields( int $post_id ): string {
	$post_type = (string) get_post_type( $post_id );
	$parts     = array();
	foreach ( _ww_pods_fields( $post_type, $post_id ) as $field ) {
		$type  = _ww_data_to_string( $field['type'] ?? '' );
		$value = trim( _ww_data_to_string( _ww_data_get_stored( _ww_data_to_string( $field['name'] ?? '' ), $post_id ) ) );
		if ( '' === $value || ! in_array( $type, array( 'text', 'paragraph', 'wysiwyg' ), true ) ) {
			continue;
		}
		$parts[] = 'text' === $type ? '<p>' . $value . '</p>' : trim( wpautop( $value ) );
	}

	// Scripts en stijlen met inhoud en al weg, zodat er geen code als tekst achterblijft; shortcodes ook (geen formulier in de zoekindex).
	$html = (string) preg_replace( '@<(script|style)[^>]*?>.*?</\1>@si', '', strip_shortcodes( implode( "\n", $parts ) ) );
	return trim( wp_kses( $html, _ww_content_allowed_html() ) );
}

/**
 * Zet de kopie in post_content na het opslaan. Draait na Pods (die bewaart de velden in save_post)
 * en vóór WordPress de revisie maakt (wp_after_insert_post, prioriteit 9), zodat de revisie de kopie bevat.
 * Schrijft rechtstreeks in de tabel, zodat er geen tweede opslag met eigen hooks en revisie volgt.
 *
 * @param int $post_id Bericht-ID.
 */
function _ww_content_sync( $post_id ): void {
	$post_id = (int) $post_id;
	$post    = get_post( $post_id );
	if ( ! $post instanceof WP_Post || wp_is_post_revision( $post ) || wp_is_post_autosave( $post ) || post_type_supports( $post->post_type, 'editor' ) ) {
		return;
	}
	if ( array() === _ww_pods_fields( $post->post_type ) ) {
		return;
	}

	$content = _ww_content_from_fields( $post_id );
	if ( $content === $post->post_content ) {
		return;
	}

	global $wpdb;
	$wpdb->update( $wpdb->posts, array( 'post_content' => $content ), array( 'ID' => $post_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	clean_post_cache( $post_id );
}
add_action( 'wp_after_insert_post', '_ww_content_sync', 5 );
