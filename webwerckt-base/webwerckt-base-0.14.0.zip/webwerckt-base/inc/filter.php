<?php
/**
 * Filteren op taxonomie: elke filterlink is een gewoon taxonomie-archief (/projecten-categorie/web/),
 * zodat filters zonder JavaScript werken en Google elke gefilterde lijst kan indexeren.
 * Met JavaScript wisselt assets/js/filter.js de lijst via het REST-endpoint, zonder te herladen.
 *
 * Er is één actieve term tegelijk: een filterlink vervangt het huidige filter, ook over taxonomieën heen.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * URL van een lijst met dit filter (niet ge-escaped): het termarchief bij één term,
 * anders het archief van het post type met de termen als queryvariabelen.
 * Met een vertaalplugin is het de URL in de huidige taal; de slugs zijn dan die van termen in die taal.
 *
 * @param array<string,string|string[]> $tax Taxonomie => term-slug.
 */
function ww_filter_url( string $post_type, array $tax = array() ): string {
	$archive = get_post_type_archive_link( $post_type );
	$archive = is_string( $archive ) ? $archive : '';

	$terms = array();
	foreach ( _ww_tax_query( $post_type, $tax ) as $clause ) {
		$term = get_term_by( 'slug', $clause['terms'][0], $clause['taxonomy'] );
		if ( $term instanceof WP_Term ) {
			$terms[] = $term;
		}
	}

	if ( 1 === count( $terms ) ) {
		$link = get_term_link( $terms[0] );
		return is_string( $link ) ? $link : $archive;
	}

	$query_vars = array();
	foreach ( $terms as $term ) {
		$query_var = get_taxonomy( $term->taxonomy )->query_var ?? false;
		if ( is_string( $query_var ) && '' !== $query_var ) {
			$query_vars[ $query_var ] = $term->slug;
		}
	}
	return array() !== $query_vars && '' !== $archive ? add_query_arg( $query_vars, $archive ) : $archive;
}

/**
 * URL van pagina $page van een lijst (niet ge-escaped), met of zonder mooie permalinks.
 */
function ww_paged_url( string $url, int $page ): string {
	global $wp_rewrite;

	if ( '' === $url || $page <= 1 ) {
		return $url;
	}
	if ( ! $wp_rewrite instanceof WP_Rewrite || ! $wp_rewrite->using_permalinks() ) {
		return add_query_arg( 'paged', $page, $url );
	}

	$parts = explode( '?', $url, 2 );
	$paged = user_trailingslashit( trailingslashit( $parts[0] ) . $wp_rewrite->pagination_base . '/' . $page, 'paged' );
	return isset( $parts[1] ) ? $paged . '?' . $parts[1] : $paged;
}

/**
 * Filterlinks voor één taxonomie van een aangemeld archief: eventueel "alle", dan elke term.
 *
 * Elk item is een term uit _ww_term_item() plus `attrs`: de data-ww-attributen voor het filterscript
 * en `aria-current="page"` op de actieve link. Gebruik binnen een element met ww_filter_attrs():
 *
 *     <a href="<?php echo $link['url']; ?>" <?php echo $link['attrs']; ?>><?php echo $link['name']; ?></a>
 *
 * @param string              $all_label Tekst van de link naar de ongefilterde lijst; '' laat hem weg.
 * @param array<string,mixed> $args      Zie ww_terms().
 * @return array<int,array<string,mixed>>
 */
function ww_filter_links( string $post_type, string $taxonomy, string $all_label = '', array $args = array() ): array {
	if ( array() === _ww_archive_config( $post_type ) || ! is_object_in_taxonomy( $post_type, $taxonomy ) ) {
		return array();
	}

	$links = array();
	foreach ( ww_terms( $taxonomy, $args ) as $term ) {
		$links[] = $term + array( 'attrs' => _ww_filter_link_attrs( $taxonomy, $term['slug'], $term['current'] ) );
	}

	if ( '' !== $all_label ) {
		$current = ! get_queried_object() instanceof WP_Term;
		array_unshift(
			$links,
			array(
				'id'      => 0,
				'name'    => esc_html( $all_label ),
				'slug'    => '',
				'url'     => esc_url( ww_filter_url( $post_type ) ),
				// Met dezelfde query als de lijst, dus alleen de huidige taal; wp_count_posts() telt alle talen.
				'count'   => _ww_query_ids( $post_type, array( 'limit' => 1, 'lang' => _ww_current_language() ) )['total'],
				'current' => $current,
				'attrs'   => _ww_filter_link_attrs( '', '', $current ),
			)
		);
	}
	return $links;
}

/**
 * Attributen van één filterlink. De link naar "alle" heeft een lege taxonomie en term.
 */
function _ww_filter_link_attrs( string $taxonomy, string $slug, bool $current ): string {
	$attrs = _ww_html_attrs(
		array(
			'taxonomy' => $taxonomy,
			'term'     => $slug,
		)
	);
	return $current ? $attrs . ' aria-current="page"' : $attrs;
}

/**
 * Markeert het element rond de filterlinks en laadt het filterscript:
 * `<nav <?php echo ww_filter_attrs( 'project' ); ?>>`.
 *
 * Op het archief van dit post type zet het script de URL van het gekozen filter in de adresbalk;
 * in een sectie op een gewone pagina filtert het alleen de lijst.
 */
function ww_filter_attrs( string $post_type ): string {
	if ( array() === _ww_archive_config( $post_type ) ) {
		return '';
	}

	_ww_enqueue_module( 'filter' );

	$attrs = array(
		'filter'   => $post_type,
		'endpoint' => _ww_cards_endpoint(),
		/* translators: %d: aantal gevonden items. */
		'results'  => __( '%d resultaten', 'webwerckt-base' ),
	);
	if ( _ww_archive_post_type() === $post_type ) {
		$attrs['history'] = '1';
	}
	return _ww_html_attrs( $attrs );
}

/**
 * Een taxonomie-archief van een aangemeld post type gebruikt het archieftemplate van dat post type
 * (archive-{post_type}.php, of home.php voor berichten), zodat de lijst en al zijn filters één template delen.
 * Een eigen template voor de taxonomie of term in het child-thema gaat nog steeds voor.
 *
 * @param string[] $templates Templatenamen, van specifiek naar algemeen.
 * @return string[]
 */
function _ww_filter_archive_template( array $templates ): array {
	$post_type = _ww_archive_post_type();
	if ( '' === $post_type ) {
		return $templates;
	}

	$template = 'post' === $post_type ? 'home.php' : "archive-{$post_type}.php";
	// Vóór het algemene taxonomy.php; category.php en tag.php zijn al per taxonomie en blijven voorgaan.
	$position = 'taxonomy.php' === end( $templates ) ? count( $templates ) - 1 : count( $templates );
	array_splice( $templates, $position, 0, array( $template ) );
	return $templates;
}
add_filter( 'taxonomy_template_hierarchy', '_ww_filter_archive_template' );
add_filter( 'category_template_hierarchy', '_ww_filter_archive_template' );
add_filter( 'tag_template_hierarchy', '_ww_filter_archive_template' );
