<?php
/**
 * Taal en vertalingen: de themastrings als .po/.mo en de huidige taal van een vertaalplugin.
 *
 * De bronstrings zijn Nederlands; een vertaling staat in languages/{locale}.mo (sjabloon: languages/webwerckt-base.pot).
 * De huidige taal komt via de filters van WPML, die Polylang ook kent. TranslatePress zet de taal in de URL
 * (/en/...), dus links en rest_url() hebben hem daar al; zie inc/integrations/multilingual.php.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Laadt de vertaling van de themastrings. Een bestand in wp-content/languages/themes/ gaat voor.
 */
function _ww_load_textdomain(): void {
	load_theme_textdomain( 'webwerckt-base', get_template_directory() . '/languages' );
}
add_action( 'after_setup_theme', '_ww_load_textdomain' );

/**
 * Code van de huidige taal volgens WPML of Polylang ('en'), of '' zonder vertaalplugin.
 */
function _ww_current_language(): string {
	$lang = apply_filters( 'wpml_current_language', null );
	return is_string( $lang ) ? sanitize_key( $lang ) : '';
}
