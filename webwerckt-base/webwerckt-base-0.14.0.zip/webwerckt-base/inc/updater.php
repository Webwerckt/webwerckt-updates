<?php
/**
 * Updatecheck: leest webwerckt-base.json van updates.webwerckt.nl (gemaakt door de release-workflow)
 * en meldt WordPress een update zodra daar een hoger versienummer staat.
 *
 * Een update wordt alleen geïnstalleerd van het eigen updatedomein en met een geldige
 * ed25519-handtekening, zodat een overgenomen domein of repo geen code op klantsites kan zetten.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Alle downloads moeten hier beginnen.
const WW_UPDATES_BASE = 'https://updates.webwerckt.nl/webwerckt-base/';

// Publieke sleutel waarmee de release-workflow de zip ondertekent (secret UPDATES_SIGNING_KEY).
const WW_UPDATES_PUBLIC_KEY = '0vaV2toyr99nwGw78GymVHvHf4cByybv7PSmIbKLu2Q=';

/**
 * Adres van het JSON-bestand met de nieuwste versie.
 */
function _ww_updates_url(): string {
	return WW_UPDATES_BASE . 'webwerckt-base.json';
}

/**
 * Controleert het JSON-antwoord en geeft de gegevens terug, of array() als het niet klopt.
 *
 * @param mixed $data Gedecodeerde JSON.
 * @return array<string,string>
 */
function _ww_updater_parse( mixed $data ): array {
	if ( ! is_array( $data ) ) {
		return array();
	}

	$info = array(
		'version'      => _ww_data_to_string( $data['version'] ?? '' ),
		'download_url' => _ww_data_to_string( $data['download_url'] ?? '' ),
		'signature'    => _ww_data_to_string( $data['signature'] ?? '' ),
		'details_url'  => esc_url_raw( _ww_data_to_string( $data['details_url'] ?? '' ) ),
		'requires'     => _ww_data_to_string( $data['requires'] ?? '' ),
		'requires_php' => _ww_data_to_string( $data['requires_php'] ?? '' ),
	);

	$valid = preg_match( '/^\d+\.\d+\.\d+$/', $info['version'] )
		&& str_starts_with( $info['download_url'], WW_UPDATES_BASE )
		&& '' !== $info['signature'];

	return $valid ? $info : array();
}

/**
 * Haalt de gegevens van de nieuwste versie op, 12 uur gecachet. Bij een fout: lege array (1 uur gecachet).
 *
 * @return array<string,string>
 */
function _ww_updater_fetch(): array {
	$cached = get_site_transient( 'ww_update_info' );
	if ( is_array( $cached ) ) {
		return $cached;
	}

	$info     = array();
	$response = wp_remote_get( _ww_updates_url(), array( 'timeout' => 5 ) );
	if ( ! is_wp_error( $response ) && 200 === wp_remote_retrieve_response_code( $response ) ) {
		$info = _ww_updater_parse( json_decode( wp_remote_retrieve_body( $response ), true ) );
	}

	set_site_transient( 'ww_update_info', $info, array() === $info ? HOUR_IN_SECONDS : 12 * HOUR_IN_SECONDS );
	return $info;
}

/**
 * Is er een nieuwere versie die op deze site kan draaien?
 *
 * @param array<string,string> $info    Uit _ww_updater_fetch().
 * @param string               $current Geïnstalleerde versie.
 */
function _ww_updater_is_newer( array $info, string $current ): bool {
	if ( '' === ( $info['version'] ?? '' ) || ! version_compare( $info['version'], $current, '>' ) ) {
		return false;
	}
	$requires_php = $info['requires_php'] ?? '';
	return '' === $requires_php || version_compare( PHP_VERSION, $requires_php, '>=' );
}

/**
 * Zet de update in de WordPress-updatelijst voor thema's.
 *
 * Haalt eerst elke andere update voor de parent en het actieve child-thema weg: een thema met
 * dezelfde naam op wordpress.org mag onze thema's nooit overschrijven.
 *
 * @param mixed $transient Waarde van update_themes.
 * @return mixed
 */
function _ww_updater_inject( $transient ) {
	if ( ! is_object( $transient ) ) {
		return $transient;
	}

	unset( $transient->response[ WW_BASE_SLUG ] );
	if ( WW_BASE_SLUG === get_template() ) {
		// Het actieve thema is ons child-thema; dat wordt alleen via Git uitgerold.
		unset( $transient->response[ get_stylesheet() ] );
	}

	$info = _ww_updater_fetch();
	if ( empty( $transient->checked ) || ! _ww_updater_is_newer( $info, WW_BASE_VERSION ) ) {
		return $transient;
	}

	$transient->response[ WW_BASE_SLUG ] = array(
		'theme'        => WW_BASE_SLUG,
		'new_version'  => $info['version'],
		'url'          => $info['details_url'],
		'package'      => $info['download_url'],
		'requires'     => $info['requires'],
		'requires_php' => $info['requires_php'],
	);
	return $transient;
}
add_filter( 'pre_set_site_transient_update_themes', '_ww_updater_inject' );

/**
 * Wat de release-workflow ondertekent: slug, versie en de SHA-256 van de zip.
 *
 * Door de versie mee te ondertekenen kan een overgenomen domein geen oudere, ooit geldig
 * ondertekende zip aanbieden als nieuwe versie (downgrade naar een kwetsbare versie).
 *
 * @param string $data    Inhoud van de zip.
 * @param string $version Versie die het update-JSON aankondigt.
 */
function _ww_updater_signed_message( string $data, string $version ): string {
	return WW_BASE_SLUG . "\n" . $version . "\n" . hash( 'sha256', $data );
}

/**
 * Klopt de ed25519-handtekening van deze bestandsinhoud voor deze versie?
 *
 * @param string $data       Inhoud van de zip.
 * @param string $version    Aangekondigde versie.
 * @param string $signature  Handtekening, base64.
 * @param string $public_key Publieke sleutel, base64.
 */
function _ww_updater_signature_valid( string $data, string $version, string $signature, string $public_key = WW_UPDATES_PUBLIC_KEY ): bool {
	$signature  = base64_decode( $signature, true );
	$public_key = base64_decode( $public_key, true );
	if ( false === $signature || false === $public_key || '' === $version ) {
		return false;
	}

	try {
		return sodium_crypto_sign_verify_detached( $signature, _ww_updater_signed_message( $data, $version ), $public_key );
	} catch ( SodiumException $e ) {
		return false;
	}
}

/**
 * Downloadt een update van de parent zelf en installeert hem alleen met een geldige handtekening.
 *
 * Draait als laatste filter, zodat geen ander filter de gecontroleerde zip nog vervangt. Heeft een ander filter
 * (een backup- of beheerplugin) het pakket al gedownload, dan wordt dat bestand gecontroleerd; anders zou de
 * handtekening afhangen van welke plugins er actief zijn.
 *
 * @param mixed               $reply      false, of een eerder resultaat van een ander filter.
 * @param string              $package    Download-URL.
 * @param mixed               $upgrader   WP_Upgrader.
 * @param array<string,mixed> $hook_extra Gegevens over de update.
 * @return mixed Pad naar de gecontroleerde zip, een WP_Error, of $reply voor andere pakketten.
 */
function _ww_updater_verify_download( $reply, $package, $upgrader = null, $hook_extra = array() ) {
	$package = _ww_data_to_string( $package );
	$is_ours = WW_BASE_SLUG === ( $hook_extra['theme'] ?? '' ) || str_starts_with( $package, WW_UPDATES_BASE );
	// Een fout van een ander filter breekt de update al af.
	if ( ! $is_ours || is_wp_error( $reply ) ) {
		return $reply;
	}

	$info = _ww_updater_fetch();
	if ( '' === $package || ( $info['download_url'] ?? '' ) !== $package ) {
		_ww_updater_discard( $reply );
		return _ww_updater_rejected();
	}

	$file = false === $reply ? download_url( $package, 300 ) : $reply;
	if ( is_wp_error( $file ) ) {
		return $file;
	}
	$file = _ww_data_to_string( $file );
	if ( '' === $file || ! is_file( $file ) || ! _ww_updater_signature_valid( (string) file_get_contents( $file ), $info['version'], $info['signature'] ) ) {
		_ww_updater_discard( $file );
		return _ww_updater_rejected();
	}
	return $file;
}

/**
 * Gooit een geweigerde download weg, ook als een ander filter hem heeft neergezet.
 *
 * @param mixed $file Pad naar het bestand, of iets anders (dan gebeurt er niets).
 */
function _ww_updater_discard( $file ): void {
	if ( is_string( $file ) && '' !== $file && is_file( $file ) ) {
		wp_delete_file( $file );
	}
}

/**
 * Foutmelding voor een geweigerde update; zegt niet welke controle faalde.
 */
function _ww_updater_rejected(): WP_Error {
	return new WP_Error( 'ww_update_rejected', __( 'Update van Webwerckt Base geweigerd: herkomst of handtekening klopt niet.', 'webwerckt-base' ) );
}
add_filter( 'upgrader_pre_download', '_ww_updater_verify_download', PHP_INT_MAX, 4 );

/**
 * Is $new een patch van $current (1.2.3 naar 1.2.4)? Een minor- of major-versie is dat niet.
 */
function _ww_updater_is_patch( string $current, string $new ): bool {
	$from = explode( '.', $current );
	$to   = explode( '.', $new );
	return 3 === count( $from ) && 3 === count( $to )
		&& $from[0] === $to[0] && $from[1] === $to[1]
		&& version_compare( $new, $current, '>' );
}

/**
 * Patches (beveiligingsfixes) installeren zich automatisch; minor- en major-versies installeert de beheerder
 * bewust via ManageWP of de admin, wat de instelling voor automatische updates ook is.
 *
 * @param mixed $update Of WordPress zou updaten.
 * @param mixed $item   De update (object met theme en new_version).
 * @return mixed
 */
function _ww_updater_auto_update( $update, $item ) {
	if ( ! is_object( $item ) || WW_BASE_SLUG !== ( $item->theme ?? '' ) ) {
		return $update;
	}
	return _ww_updater_is_patch( WW_BASE_VERSION, _ww_data_to_string( $item->new_version ?? '' ) );
}
add_filter( 'auto_update_theme', '_ww_updater_auto_update', 10, 2 );

/**
 * Na een update de gecachete gegevens weggooien.
 */
function _ww_updater_reset(): void {
	delete_site_transient( 'ww_update_info' );
}
add_action( 'upgrader_process_complete', '_ww_updater_reset' );
