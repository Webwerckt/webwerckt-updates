<?php
/**
 * Stylesheets van het thema als één verkleind bestand per pagina, zonder buildstap (beslissing 0020).
 *
 * Alle stylesheets uit de map van de parent en het child-thema gaan, in de volgorde van hun afhankelijkheden, samen
 * in één bestand in uploads/ww-assets/. PHP maakt het aan bij het eerste verzoek dat het nodig heeft; de naam is een
 * hash van de bronbestanden, dus na een wijziging of deploy ontstaat vanzelf een nieuw bestand. CSS van plugins en
 * JavaScript blijven los.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Zo lang blijft een vervangen bestand staan, voor pagina's en browsers die nog naar het vorige wijzen.
const WW_STYLES_KEEP = WEEK_IN_SECONDS;

/**
 * Of de stylesheets samengaan: niet met SCRIPT_DEBUG (dan de losse, leesbare bestanden), en niet als een
 * child-thema het uitzet.
 */
function _ww_combine_styles_enabled(): bool {
	if ( is_admin() || ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ) {
		return false;
	}
	/**
	 * Zet het samenvoegen en verkleinen van de stylesheets uit, bijvoorbeeld voor een site waar het iets breekt.
	 *
	 * @param bool $combine Standaard true.
	 */
	return (bool) apply_filters( 'ww_combine_styles', true );
}

/**
 * Pad en URL van een stylesheet uit de map van de parent of het child-thema, of null voor CSS van elders, met een
 * ander mediatype dan all, met een voorwaarde of met een rechts-naar-links-variant.
 *
 * @param _WP_Dependency $style Geregistreerde stylesheet.
 * @return array{file:string,url:string}|null
 */
function _ww_theme_style( _WP_Dependency $style ): ?array {
	$media = $style->args ?? 'all';
	if ( ! is_string( $style->src ) || ! in_array( $media, array( 'all', '' ), true ) || array() !== array_intersect_key( $style->extra, array_flip( array( 'conditional', 'alt', 'rtl' ) ) ) ) {
		return null;
	}
	$url  = (string) strtok( $style->src, '?#' );
	$dirs = array(
		get_stylesheet_directory_uri() => get_stylesheet_directory(),
		get_template_directory_uri()   => get_template_directory(),
	);
	foreach ( $dirs as $dir_url => $dir ) {
		if ( str_starts_with( $url, $dir_url . '/' ) && str_ends_with( $url, '.css' ) ) {
			$file = $dir . substr( $url, strlen( $dir_url ) );
			return is_file( $file ) ? array(
				'file' => $file,
				'url'  => $url,
			) : null;
		}
	}
	return null;
}

/**
 * Voegt de stylesheets van het thema samen tot één handle, ww-styles, net voordat WordPress de head afdrukt.
 * Elke samengevoegde handle blijft bestaan als alias zonder bestand die van ww-styles afhangt: CSS die ervan
 * afhangt, komt er nog steeds na, en inline CSS van wp_add_inline_style() staat direct na het bestand.
 * Lukt het schrijven niet, dan verandert er niets en laden de losse bestanden.
 */
function _ww_combine_styles(): void {
	if ( ! _ww_combine_styles_enabled() ) {
		return;
	}
	$styles = wp_styles();
	// Een kopie berekent de volgorde, zodat de echte wachtrij onaangeroerd blijft.
	$order = clone $styles;
	$order->all_deps( $order->queue );

	$sources = array();
	foreach ( $order->to_do as $handle ) {
		$style  = $styles->registered[ $handle ] ?? null;
		$source = $style ? _ww_theme_style( $style ) : null;
		if ( $source ) {
			$sources[ $handle ] = $source;
		}
	}
	if ( array() === $sources ) {
		return;
	}

	$handles = array_keys( $sources );
	$deps    = array();
	foreach ( $handles as $handle ) {
		$deps = array_merge( $deps, $styles->registered[ $handle ]->deps );
	}
	$deps = array_values( array_unique( array_diff( $deps, $handles ) ) );
	// Hangt CSS van elders van het thema af en het thema weer van die CSS, dan kan het niet in één bestand.
	foreach ( $deps as $dep ) {
		if ( _ww_style_needs( $styles, $dep, $handles ) ) {
			return;
		}
	}

	$url = _ww_styles_bundle( $sources );
	if ( '' === $url ) {
		return;
	}
	wp_register_style( 'ww-styles', $url, $deps, null );
	foreach ( $handles as $handle ) {
		$extra = $styles->registered[ $handle ]->extra;
		wp_deregister_style( $handle );
		wp_register_style( $handle, false, array( 'ww-styles' ), null );
		$styles->registered[ $handle ]->extra = $extra;
	}
}
add_action( 'wp_print_styles', '_ww_combine_styles', PHP_INT_MAX );

/**
 * Of een stylesheet, direct of via zijn eigen afhankelijkheden, een van deze handles nodig heeft.
 *
 * @param WP_Styles       $styles  Stylesheets van WordPress.
 * @param string          $handle  Stylesheet om te controleren.
 * @param string[]        $handles Handles waarnaar gezocht wordt.
 * @param array<string,1> $seen    Al bekeken handles, tegen kringverwijzingen.
 */
function _ww_style_needs( WP_Styles $styles, string $handle, array $handles, array &$seen = array() ): bool {
	foreach ( $styles->registered[ $handle ]->deps ?? array() as $dep ) {
		if ( in_array( $dep, $handles, true ) ) {
			return true;
		}
		if ( ! isset( $seen[ $dep ] ) ) {
			$seen[ $dep ] = 1;
			if ( _ww_style_needs( $styles, $dep, $handles, $seen ) ) {
				return true;
			}
		}
	}
	return false;
}

/**
 * URL van het samengevoegde bestand voor deze stylesheets, of '' als het niet te maken is.
 * De naam is een hash van de paden, URL's, wijzigingsdatums en groottes van de bronbestanden en de parent-versie.
 *
 * @param array<string,array{file:string,url:string}> $sources Handle => bronbestand, in de volgorde van afdrukken.
 */
function _ww_styles_bundle( array $sources ): string {
	$parts = array( WW_BASE_VERSION );
	foreach ( $sources as $source ) {
		$parts[] = array( $source['file'], $source['url'], filemtime( $source['file'] ), filesize( $source['file'] ) );
	}
	$name    = substr( md5( (string) wp_json_encode( $parts ) ), 0, 12 ) . '.css';
	$uploads = wp_get_upload_dir();
	$path    = $uploads['basedir'] . '/ww-assets/' . $name;

	if ( ! is_file( $path ) && ! _ww_write_styles( $path, $sources ) ) {
		return '';
	}
	_ww_styles_track( md5( implode( ',', array_keys( $sources ) ) ), $name );
	return $uploads['baseurl'] . '/ww-assets/' . $name;
}

/**
 * Schrijft de verkleinde, samengevoegde CSS. Eerst naar een tijdelijk bestand en dan hernoemen, zodat een
 * gelijktijdig verzoek nooit een half bestand krijgt. Zonder schrijfrechten false.
 *
 * @param string                                      $path    Doelbestand.
 * @param array<string,array{file:string,url:string}> $sources Bronbestanden, in de volgorde van afdrukken.
 */
function _ww_write_styles( string $path, array $sources ): bool {
	$dir = dirname( $path );
	if ( ! wp_mkdir_p( $dir ) || ! wp_is_writable( $dir ) ) {
		return false;
	}
	$css = '';
	foreach ( $sources as $source ) {
		$content = file_get_contents( $source['file'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- lokaal themabestand.
		if ( false === $content ) {
			return false;
		}
		$root = (string) wp_parse_url( dirname( $source['url'] ), PHP_URL_PATH );
		$css .= _ww_minify_css( _ww_css_root_urls( $content, $root ) ) . "\n";
	}

	$tmp = $path . '.' . wp_generate_password( 8, false ) . '.tmp';
	if ( false === file_put_contents( $tmp, $css ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- gegenereerde cache, net als LiteSpeed.
		return false;
	}
	if ( ! rename( $tmp, $path ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename
		wp_delete_file( $tmp );
	}
	return is_file( $path );
}

/**
 * Maakt relatieve url()'s in CSS root-relatief: '../img/a.svg' in assets/css/ wordt
 * '/wp-content/themes/x/assets/img/a.svg'. Zo wijzen ze vanuit uploads/ww-assets/ naar hetzelfde bestand, op elk
 * domein, en sluiten ze aan op een preload van dat bestand. data:, #, absolute en root-relatieve URL's blijven staan.
 *
 * @param string $css  CSS.
 * @param string $root Root-relatief pad van de map van het bronbestand, zoals '/wp-content/themes/x/assets/css'.
 */
function _ww_css_root_urls( string $css, string $root ): string {
	return (string) preg_replace_callback(
		'/url\(\s*(["\']?)(.*?)\1\s*\)/is',
		static function ( array $match ) use ( $root ): string {
			if ( '' === $match[2] || preg_match( '~^([a-z][a-z0-9+.-]*:|/|#)~i', $match[2] ) ) {
				return $match[0];
			}
			$path = array();
			foreach ( explode( '/', rtrim( $root, '/' ) . '/' . $match[2] ) as $segment ) {
				if ( '..' === $segment ) {
					if ( count( $path ) > 1 ) {
						array_pop( $path );
					}
				} elseif ( '.' !== $segment ) {
					$path[] = $segment;
				}
			}
			return 'url(' . $match[1] . implode( '/', $path ) . $match[1] . ')';
		},
		$css
	);
}

/**
 * Verkleint CSS: commentaar weg, witruimte samengevoegd, geen spaties rond { } ; , > ~ en na een dubbele punt, en
 * geen ; voor een }. Strings en url()'s blijven precies zoals ze zijn. Spaties rond + en - blijven: calc() heeft ze
 * nodig. Een spatie vóór een dubbele punt ook: '.a :hover' is iets anders dan '.a:hover'.
 *
 * @param string $css CSS.
 */
function _ww_minify_css( string $css ): string {
	$strings = '"(?:[^"\\\\]|\\\\.)*"|\'(?:[^\'\\\\]|\\\\.)*\'|url\(\s*[^\'")]*\)';
	$css     = (string) preg_replace_callback( '~(' . $strings . ')|/\*.*?\*/~s', static fn( array $match ): string => $match[1] ?? '', $css );
	$parts   = preg_split( '~(' . $strings . ')~s', $css, -1, PREG_SPLIT_DELIM_CAPTURE ) ?: array( $css );
	foreach ( $parts as $index => $part ) {
		// De even delen staan tussen de strings; de oneven delen zijn de strings zelf.
		if ( 0 === $index % 2 ) {
			$part            = (string) preg_replace( '/\s+/', ' ', $part );
			$part            = (string) preg_replace( '/ ?([{};,>~]) ?/', '$1', $part );
			$parts[ $index ] = str_replace( array( ': ', ';}' ), array( ':', '}' ), $part );
		}
	}
	return trim( implode( '', $parts ) );
}

/**
 * Opgeslagen stand: het huidige bestand per set stylesheets, en wanneer een vorig bestand is vervangen.
 *
 * @return array{current:array<string,string>,replaced:array<string,int>}
 */
function _ww_styles_state(): array {
	$state = get_option( 'ww_styles' );
	return array(
		'current'  => is_array( $state['current'] ?? null ) ? array_map( '_ww_data_to_string', $state['current'] ) : array(),
		'replaced' => is_array( $state['replaced'] ?? null ) ? array_map( 'intval', $state['replaced'] ) : array(),
	);
}

/**
 * Houdt per set stylesheets het huidige bestand bij. Is het een ander bestand dan de vorige keer (een deploy, een
 * update of een terugdraai), dan leegt de parent de paginacache, zodat gecachte pagina's naar het nieuwe bestand
 * wijzen. Het vorige blijft nog WW_STYLES_KEEP staan en wordt daarna opgeruimd.
 *
 * @param string $set  Hash van de handles in de set.
 * @param string $name Bestandsnaam van het samengevoegde bestand.
 */
function _ww_styles_track( string $set, string $name ): void {
	$state = _ww_styles_state();
	$old   = $state['current'][ $set ] ?? '';
	if ( $old === $name ) {
		return;
	}
	$state['current'][ $set ] = $name;
	unset( $state['replaced'][ $name ] );
	if ( '' !== $old ) {
		$state['replaced'][ $old ] = time();
	}
	update_option( 'ww_styles', $state, true );

	if ( '' !== $old ) {
		_ww_cache_purge_all();
		wp_schedule_single_event( time() + WW_STYLES_KEEP + HOUR_IN_SECONDS, 'ww_styles_cleanup' );
	}
}

/**
 * Verwijdert samengevoegde bestanden die langer dan WW_STYLES_KEEP geleden zijn vervangen, behalve als een andere
 * set ze nog gebruikt.
 */
function _ww_styles_cleanup(): void {
	$state = _ww_styles_state();
	$dir   = wp_get_upload_dir()['basedir'] . '/ww-assets/';
	foreach ( $state['replaced'] as $name => $time ) {
		if ( time() - $time < WW_STYLES_KEEP ) {
			continue;
		}
		if ( preg_match( '/^[0-9a-f]{12}\.css$/', (string) $name ) && ! in_array( $name, $state['current'], true ) ) {
			wp_delete_file( $dir . $name );
		}
		unset( $state['replaced'][ $name ] );
	}
	update_option( 'ww_styles', $state, true );
}
add_action( 'ww_styles_cleanup', '_ww_styles_cleanup' );
