<?php
/**
 * Taxonomieën: termen ophalen als gewone arrays, voor labels op kaarten en filterlinks.
 *
 * Elke term wordt een array met id, name (ge-escaped), slug, url (ge-escaped), count en current,
 * zodat het child-thema alleen HTML schrijft.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Een term als array voor het child-thema.
 *
 * @return array{id:int,name:string,slug:string,url:string,count:int,current:bool}
 */
function _ww_term_item( WP_Term $term ): array {
	$link    = get_term_link( $term );
	$current = get_queried_object();

	return array(
		'id'      => (int) $term->term_id,
		'name'    => esc_html( $term->name ),
		'slug'    => esc_attr( $term->slug ),
		'url'     => is_string( $link ) ? esc_url( $link ) : '',
		'count'   => (int) $term->count,
		'current' => $current instanceof WP_Term && $current->term_id === $term->term_id,
	);
}

/**
 * Publieke taxonomie, of null als die niet bestaat of niet publiek is.
 */
function _ww_public_taxonomy( string $taxonomy ): ?WP_Taxonomy {
	$object = '' !== $taxonomy ? get_taxonomy( $taxonomy ) : false;
	return $object instanceof WP_Taxonomy && $object->public ? $object : null;
}

/**
 * Termen van een taxonomie, bijvoorbeeld voor een filter of een lijst met categorieën.
 *
 * @param array<string,mixed> $args hide_empty (standaard true), limit (standaard alle), orderby (standaard name), order.
 * @return array<int,array<string,mixed>> Zie _ww_term_item().
 */
function ww_terms( string $taxonomy, array $args = array() ): array {
	$object = _ww_public_taxonomy( $taxonomy );
	if ( null === $object ) {
		return array();
	}

	$query_args = array(
		'taxonomy'   => $taxonomy,
		'hide_empty' => (bool) ( $args['hide_empty'] ?? true ),
		'number'     => max( 0, (int) ( $args['limit'] ?? 0 ) ),
		'orderby'    => sanitize_key( _ww_data_to_string( $args['orderby'] ?? '' ) ) ?: 'name',
		'order'      => 'DESC' === strtoupper( _ww_data_to_string( $args['order'] ?? '' ) ) ? 'DESC' : 'ASC',
	);

	/**
	 * Laat het child-thema de termquery bijsturen (bijvoorbeeld alleen hoofdcategorieën met parent => 0).
	 *
	 * @param array<string,mixed> $query_args get_terms()-argumenten.
	 * @param string              $taxonomy   Taxonomie.
	 */
	$terms = get_terms( (array) apply_filters( 'ww_terms_args', $query_args, $taxonomy ) );
	if ( ! is_array( $terms ) ) {
		return array();
	}

	foreach ( $object->object_type as $post_type ) {
		_ww_cache_tag( (string) $post_type );
	}
	return array_values( array_map( '_ww_term_item', array_filter( $terms, static fn( $term ) => $term instanceof WP_Term ) ) );
}

/**
 * Termen van één bericht, bijvoorbeeld de categorieën op een kaart.
 *
 * @param int $post_id Bericht-ID; 0 is het huidige bericht.
 * @return array<int,array<string,mixed>> Zie _ww_term_item().
 */
function ww_post_terms( string $taxonomy, int $post_id = 0 ): array {
	$post_id = $post_id > 0 ? $post_id : _ww_current_id();
	if ( $post_id <= 0 || null === _ww_public_taxonomy( $taxonomy ) ) {
		return array();
	}

	$terms = get_the_terms( $post_id, $taxonomy );
	return is_array( $terms ) ? array_values( array_map( '_ww_term_item', $terms ) ) : array();
}
