<?php
/**
 * Velden gaan mee in WordPress-revisies (WP 6.4+, via register_post_meta).
 *
 * Een revisie ontstaat als titel, tekst, uittreksel of een van deze geregistreerde velden verandert
 * (WordPress vergelijkt revisie-meta sinds 6.4 zelf).
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registreert de Pods-velden van elk publiek post type als revisie-meta. Niet voor bezoekers: revisies ontstaan
 * alleen bij opslaan, en voorbeelden bekijkt een ingelogde gebruiker. Het zoeken van de velden kost een paar ms.
 *
 * @param bool|null $visitor Of dit een bezoeker is; null bepaalt het met _ww_is_visitor_request().
 */
function _ww_register_revision_meta( ?bool $visitor = null ): void {
	if ( $visitor ?? _ww_is_visitor_request() ) {
		return;
	}
	foreach ( get_post_types( array( 'public' => true ) ) as $post_type ) {
		if ( ! post_type_supports( $post_type, 'revisions' ) ) {
			continue;
		}

		/**
		 * Veldnamen die in revisies meegaan.
		 *
		 * @param string[] $fields    Enkelvoudige Pods-velden.
		 * @param string   $post_type Post type.
		 */
		$fields = (array) apply_filters( 'ww_revision_fields', _ww_pods_revision_fields( $post_type ), $post_type );

		foreach ( $fields as $field ) {
			register_post_meta(
				$post_type,
				(string) $field,
				array(
					'type'              => 'string',
					'single'            => true,
					'show_in_rest'      => false,
					'revisions_enabled' => true,
				)
			);
		}
	}
}
add_action( 'init', '_ww_register_revision_meta', 99 );
