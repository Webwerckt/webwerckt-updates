<?php
/**
 * Generieke lijsten: ww_get_posts(), kaarten, archieven met paginering en meer laden.
 *
 * Geen functie per post type: een nieuw post type vraagt alleen een registratie
 * en een template-part `template-parts/card-{post_type}.php` in het child-thema.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Zonder limit hooguit zoveel items, zodat een lijst op een grote site niet alle berichten met al hun velden laadt.
const WW_LOOP_MAX = 100;

/**
 * Register van archieven per post type. Alleen ww_register_archive() schrijft hierin.
 *
 * @param string              $post_type Post type om te registreren; '' leest alleen.
 * @param array<string,mixed> $config    Instellingen van dat archief.
 * @return array<string,array<string,mixed>>
 */
function _ww_archive_registry( string $post_type = '', array $config = array() ): array {
	static $archives = array();

	if ( '' !== $post_type ) {
		$archives[ $post_type ] = $config;
	}
	return $archives;
}

/**
 * Meldt een post type aan als archief (paginering en eventueel meer laden).
 *
 * @param array<string,mixed> $config per_page (standaard 9), load_more (standaard false), orderby, order.
 */
function ww_register_archive( string $post_type, array $config = array() ): void {
	// Na parse_request is de hoofdquery van deze pagina al opgebouwd zonder dit archief.
	_ww_warn_if_too_late( __FUNCTION__, 'parse_request' );
	$config += array(
		'per_page'  => 9,
		'load_more' => false,
		'orderby'   => 'menu_order',
		'order'     => 'ASC',
	);
	$config['per_page'] = max( 1, (int) $config['per_page'] );

	_ww_archive_registry( $post_type, $config );
}

/**
 * Instellingen van een aangemeld archief, of array() als het post type niet is aangemeld.
 *
 * @return array<string,mixed>
 */
function _ww_archive_config( string $post_type ): array {
	return _ww_archive_registry()[ $post_type ] ?? array();
}

/**
 * Query-argumenten voor sortering.
 *
 * @return array<string,string>
 */
function _ww_order_args( string $orderby, string $order ): array {
	return array(
		'orderby' => 'menu_order' === $orderby ? 'menu_order title' : ( sanitize_key( $orderby ) ?: 'date' ),
		'order'   => 'DESC' === strtoupper( $order ) ? 'DESC' : 'ASC',
	);
}

/**
 * Taxonomie-filter van korte argumenten naar een tax_query.
 *
 * @param array<string,string|string[]> $tax Taxonomie => term-slug(s).
 * @return array<int,array<string,mixed>>
 */
function _ww_tax_query( string $post_type, array $tax ): array {
	$query = array();
	foreach ( $tax as $taxonomy => $terms ) {
		$taxonomy = sanitize_key( (string) $taxonomy );
		// Alleen tekst en getallen: een geneste array zou sanitize_title() laten crashen.
		$terms = array_map( 'strval', array_filter( (array) $terms, 'is_scalar' ) );
		$terms = array_values( array_filter( array_map( 'sanitize_title', $terms ) ) );
		if ( array() !== $terms && is_object_in_taxonomy( $post_type, $taxonomy ) ) {
			$query[] = array(
				'taxonomy' => $taxonomy,
				'field'    => 'slug',
				'terms'    => $terms,
			);
		}
	}
	return $query;
}

/**
 * Haalt post-ID's op, optioneel per pagina. Gebruikt door ww_get_posts() en het REST-endpoint.
 *
 * Haalt hele berichten op (geen fields => ids), zodat berichten, velden en termen van alle items
 * in een paar query's in de cache staan en een kaart geen eigen query's per item doet.
 *
 * Zonder limit hooguit WW_LOOP_MAX items. Er komt er één extra mee: is die er, dan is de lijst afgekapt
 * en meldt WordPress (met WP_DEBUG aan) dat het child-thema een limit hoort mee te geven.
 *
 * @param array<string,mixed> $args  limit, tax, orderby, order, paged, lang (taalcode van WPML of Polylang).
 * @param bool                $count Totaal en aantal pagina's tellen (een extra query); zonder telling zijn
 *                                   total het aantal gevonden ID's en max_pages 0.
 * @return array{ids:int[],max_pages:int,total:int}
 */
function _ww_query_ids( string $post_type, array $args = array(), bool $count = true ): array {
	if ( '' === $post_type || ! post_type_exists( $post_type ) ) {
		return array(
			'ids'       => array(),
			'max_pages' => 0,
			'total'     => 0,
		);
	}

	$limit  = (int) ( $args['limit'] ?? -1 );
	$capped = $limit < 1;
	$tax    = is_array( $args['tax'] ?? null ) ? _ww_tax_query( $post_type, $args['tax'] ) : array();

	$query_args = array(
		'post_type'           => $post_type,
		'post_status'         => 'publish',
		'posts_per_page'      => $capped ? WW_LOOP_MAX + 1 : $limit,
		'paged'               => max( 1, (int) ( $args['paged'] ?? 1 ) ),
		'no_found_rows'       => $capped || ! $count,
		'ignore_sticky_posts' => true,
	) + _ww_order_args(
		_ww_data_to_string( $args['orderby'] ?? '' ) ?: 'menu_order',
		_ww_data_to_string( $args['order'] ?? '' )
	);
	if ( array() !== $tax ) {
		$query_args['tax_query'] = $tax; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
	}
	// Polylang filtert hierop (in REST-verzoeken niet vanzelf); WPML filtert op de huidige taal en negeert lang.
	$lang = _ww_data_to_string( $args['lang'] ?? '' );
	if ( '' !== $lang ) {
		$query_args['lang'] = $lang;
	}

	/**
	 * Laat het child-thema de query bijsturen.
	 *
	 * @param array<string,mixed> $query_args WP_Query-argumenten.
	 * @param string              $post_type  Post type.
	 */
	$query = new WP_Query( (array) apply_filters( 'ww_loop_args', $query_args, $post_type ) );
	_ww_cache_tag( $post_type );

	// Via ww_loop_args kan fields => ids terugkomen; _ww_data_item_id() kent beide vormen.
	$ids = array_map( '_ww_data_item_id', $query->posts );
	// Niet afkappen als het child-thema het aantal via ww_loop_args zelf heeft gekozen.
	$capped = $capped && WW_LOOP_MAX + 1 === (int) $query->get( 'posts_per_page' );
	if ( $capped && count( $ids ) > WW_LOOP_MAX ) {
		$ids = array_slice( $ids, 0, WW_LOOP_MAX );
		_doing_it_wrong(
			'ww_get_posts',
			esc_html( sprintf( 'Er zijn meer dan %1$d items van %2$s; zonder limit geeft ww_get_posts() er %1$d. Geef een limit mee.', WW_LOOP_MAX, $post_type ) ),
			'0.4.0'
		);
	}

	return array(
		'ids'       => $ids,
		'max_pages' => (int) $query->max_num_pages,
		'total'     => $capped || ! $count ? count( $ids ) : (int) $query->found_posts,
	);
}

/**
 * Post-ID's van een post type, zonder paginering en zonder telling, met de uitgelichte afbeeldingen al geladen.
 *
 * @param array<string,mixed> $args limit (standaard alle), tax, orderby (standaard menu_order), order.
 * @return int[]
 */
function ww_get_posts( string $post_type, array $args = array() ): array {
	unset( $args['paged'] );
	$ids = _ww_query_ids( $post_type, $args, false )['ids'];
	_ww_prime_thumbnails( $ids );
	return $ids;
}

/**
 * Kaart van één item als HTML, uit template-parts/card-{post_type}.php.
 */
function _ww_card_html( int $post_id ): string {
	$post = $post_id > 0 ? get_post( $post_id ) : null;
	if ( ! $post instanceof WP_Post || ! _ww_data_is_published( $post->ID ) ) {
		return '';
	}

	$previous = $GLOBALS['post'] ?? null;
	_ww_set_current_post( $post );
	ob_start();
	get_template_part( 'template-parts/card', $post->post_type );
	$html = (string) ob_get_clean();

	// Het vorige bericht terugzetten, niet dat van de hoofdquery: een kaart kan in een andere kaart staan.
	if ( $previous instanceof WP_Post ) {
		_ww_set_current_post( $previous );
	} else {
		wp_reset_postdata();
	}

	_ww_cache_tag( $post->post_type );
	return $html;
}

/**
 * Maakt een bericht het huidige bericht voor template-tags en ww_field().
 */
function _ww_set_current_post( WP_Post $post ): void {
	// phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
	$GLOBALS['post'] = $post;
	setup_postdata( $post );
}

/**
 * Toont de kaart van één item.
 */
function ww_card( int $post_id ): void {
	echo _ww_card_html( $post_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- child-thema escaped in de template-part.
}

/**
 * Toont alle kaarten van een post type.
 *
 * @param array<string,mixed> $args Zie ww_get_posts().
 */
function ww_render_loop( string $post_type, array $args = array() ): void {
	foreach ( ww_get_posts( $post_type, $args ) as $post_id ) {
		ww_card( $post_id );
	}
}

/**
 * Post type van het huidige archief (alleen als het via ww_register_archive() is aangemeld).
 * Werkt voor post type-archieven, de blogpagina (post) en taxonomie-archieven van dat post type.
 */
function _ww_archive_post_type( ?WP_Query $query = null ): string {
	$query = $query ?? _ww_main_query();
	if ( null === $query ) {
		return '';
	}

	$candidates = array();
	$term       = $query->get_queried_object();
	if ( $query->is_post_type_archive() ) {
		$candidates = (array) $query->get( 'post_type' );
	} elseif ( $query->is_home() ) {
		$candidates = array( 'post' );
	} elseif ( $term instanceof WP_Term ) {
		$candidates = get_taxonomy( $term->taxonomy )->object_type ?? array();
	}

	foreach ( $candidates as $type ) {
		if ( array() !== _ww_archive_config( (string) $type ) ) {
			return (string) $type;
		}
	}
	return '';
}

/**
 * Aantal items per pagina en sortering toepassen op de hoofdquery van een archief.
 */
function _ww_apply_archive_query( WP_Query $query ): void {
	// Feeds houden het aantal en de volgorde van WordPress (posts_per_rss, nieuwste eerst).
	if ( is_admin() || ! $query->is_main_query() || $query->is_feed() ) {
		return;
	}
	$post_type = _ww_archive_post_type( $query );
	$config    = _ww_archive_config( $post_type );
	if ( array() === $config ) {
		return;
	}

	// Een taxonomie kan aan meer post types hangen; het gefilterde archief toont alleen dit post type.
	$query->set( 'post_type', $post_type );
	$query->set( 'posts_per_page', $config['per_page'] );
	foreach ( _ww_order_args( (string) $config['orderby'], (string) $config['order'] ) as $key => $value ) {
		$query->set( $key, $value );
	}
}
add_action( 'pre_get_posts', '_ww_apply_archive_query' );

/**
 * Post-ID's van de hoofdquery van het huidige archief.
 *
 * @return int[]
 */
function ww_archive_ids(): array {
	$query = _ww_main_query();
	if ( null === $query ) {
		return array();
	}
	_ww_cache_tag( _ww_archive_post_type( $query ) );
	$ids = array_map( 'intval', wp_list_pluck( $query->posts, 'ID' ) );
	_ww_prime_thumbnails( $ids );
	return $ids;
}

/**
 * URL van de volgende archiefpagina, of '' als er geen is.
 */
function ww_next_page_url(): string {
	$query = _ww_main_query();
	$next  = $query ? max( 1, (int) $query->get( 'paged' ) ) + 1 : 0;
	if ( null === $query || $next > (int) $query->max_num_pages ) {
		return '';
	}
	return esc_url( get_pagenum_link( $next ) );
}

/**
 * Navigatie van het archief: meer laden of gewone paginering, HTML uit het child-thema.
 */
function ww_pagination(): void {
	$load_more = ! empty( _ww_archive_config( _ww_archive_post_type() )['load_more'] );
	get_template_part( $load_more ? 'template-parts/load-more' : 'template-parts/pagination' );
}

/**
 * Markeert de lijst met kaarten, voor meer laden: `<div <?php echo ww_list_attrs( 'project' ); ?>>`.
 */
function ww_list_attrs( string $post_type ): string {
	return _ww_html_attrs( array( 'list' => $post_type ) );
}

/**
 * Markeert de knop voor meer laden en laadt het script. De knop zelf is een gewone link naar de volgende pagina.
 *
 * Op een archief komen post type, pagina en taxonomie uit de hoofdquery; in een sectie
 * op een gewone pagina geef je ze mee. Op een archief zonder volgende pagina krijgt de knop
 * `hidden`, zodat het filterscript hem na een filterwissel weer kan tonen.
 *
 * @param string               $post_type Post type; leeg is dat van het huidige archief.
 * @param array<string,string> $tax       Taxonomie => term-slug om te filteren.
 */
function ww_load_more_attrs( string $post_type = '', array $tax = array() ): string {
	$archive   = _ww_archive_post_type();
	$post_type = '' !== $post_type ? $post_type : $archive;
	if ( array() === _ww_archive_config( $post_type ) ) {
		return '';
	}

	$term = get_queried_object();
	if ( array() === $tax && $term instanceof WP_Term ) {
		$tax = array( $term->taxonomy => $term->slug );
	}

	_ww_enqueue_module( 'load-more' );

	$attrs = _ww_html_attrs(
		array(
			'load-more' => $post_type,
			'endpoint'  => _ww_cards_endpoint(),
			'page'      => (string) max( 1, (int) get_query_var( 'paged' ) ),
			'tax'       => (string) wp_json_encode( $tax ),
			/* translators: %d: aantal toegevoegde items. */
			'added'     => __( '%d items toegevoegd', 'webwerckt-base' ),
		)
	);
	$is_last_page = $archive === $post_type && '' === ww_next_page_url();
	return $is_last_page ? $attrs . ' hidden' : $attrs;
}
