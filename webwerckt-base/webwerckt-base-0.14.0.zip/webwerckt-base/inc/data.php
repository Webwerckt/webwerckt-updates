<?php
/**
 * Datalaag: leest velden rechtstreeks uit post meta en opties.
 *
 * Pods (en ook ACF) slaat velden op als gewone post meta onder de veldnaam en Site-instellingen
 * als opties. Zo werkt de frontend ook zonder actieve veldplugin; de plugin is alleen nodig om te bewerken.
 * Alle functies geven gewone PHP-waarden terug.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Voorvoegsel van de opties van de Site-instellingen (Pods: '{pod}_', ACF: 'options_').
 */
function _ww_settings_prefix(): string {
	return (string) apply_filters( 'ww_settings_prefix', 'site_settings_' );
}

/**
 * Voorvoegsel van alle velden en veldgroepen uit het child-thema (`child_hero_title`), zodat ze nooit
 * samenvallen met velden van de parent, ook niet met velden die de parent later toevoegt.
 */
function _ww_child_prefix(): string {
	return 'child_';
}

/**
 * Ruwe veldwaarde van een bericht, of null als het veld leeg of onbekend is.
 *
 * @param string $field   Veldnaam.
 * @param int    $post_id Bericht-ID; 0 is het huidige bericht.
 */
function _ww_data_get( string $field, int $post_id = 0 ): mixed {
	if ( '' === $field ) {
		return null;
	}

	$post_id = $post_id > 0 ? $post_id : _ww_current_id();
	if ( $post_id <= 0 || ! get_post_type( $post_id ) ) {
		return null;
	}
	// Net als de inhoud blijven velden van een bericht met wachtwoord verborgen tot het wachtwoord is ingevuld.
	if ( post_password_required( $post_id ) ) {
		return null;
	}

	return _ww_data_get_stored( $field, $post_id );
}

/**
 * Opgeslagen veldwaarde van een bericht, of null, zonder te kijken wie hem mag zien. Alleen voor
 * verwerking bij het opslaan (zoals de kopie naar post_content), nooit voor weergave.
 */
function _ww_data_get_stored( string $field, int $post_id ): mixed {
	if ( '' === $field || $post_id <= 0 ) {
		return null;
	}
	return _ww_data_empty_to_null( _ww_data_meta_value( get_post_meta( $post_id, $field, false ) ) );
}

/**
 * Ruwe waarde van een veld uit de Site-instellingen, of null.
 */
function _ww_data_get_setting( string $field ): mixed {
	if ( '' === $field ) {
		return null;
	}

	return _ww_data_empty_to_null( get_option( _ww_settings_prefix() . $field, null ) );
}

/**
 * Laadt alle opties van de Site-instellingen in één query, vóór het template ze leest. Zonder persistente
 * object-cache kost anders elke optie die niet automatisch wordt geladen of nog niet bestaat (een veld dat nooit
 * is opgeslagen, een ontbrekende sectieschakelaar) een eigen query. Opties die al geladen zijn, slaat WordPress over.
 * Twee opties die WordPress zelf op elke pagina leest en niet automatisch laadt, gaan in dezelfde query mee.
 */
function _ww_prime_settings(): void {
	$options = array( 'site_logo', 'https_migration_required' );
	foreach ( _ww_pods_setting_fields() as $field ) {
		$options[] = _ww_settings_prefix() . _ww_data_to_string( $field['name'] ?? '' );
	}
	wp_prime_option_caches( $options );
}
add_action( 'template_redirect', '_ww_prime_settings' );

/**
 * Eén waarde uit de meta-rijen van een veld.
 *
 * Pods slaat een relatie met meerdere items op als één rij per ID; ACF als één rij met een array.
 * Meerdere rijen worden daarom een lijst, één rij blijft de waarde zelf.
 *
 * @param array<int,mixed> $rows Uitkomst van get_post_meta( ..., false ).
 */
function _ww_data_meta_value( array $rows ): mixed {
	return count( $rows ) > 1 ? array_values( $rows ) : ( $rows[0] ?? null );
}

/**
 * Een leeg veld ('', array(), false) wordt null, zodat "leeg" overal hetzelfde betekent.
 */
function _ww_data_empty_to_null( mixed $value ): mixed {
	return in_array( $value, array( '', array(), false ), true ) ? null : $value;
}

/**
 * Bericht-ID van de huidige pagina of lus.
 */
function _ww_current_id(): int {
	$id = (int) get_the_ID();
	return $id > 0 ? $id : (int) get_queried_object_id();
}

/**
 * Zet een veldwaarde om naar een string ('' als het geen tekst of getal is).
 */
function _ww_data_to_string( mixed $value ): string {
	return is_scalar( $value ) ? (string) $value : '';
}

/**
 * ID van één item: een getal, een array met 'ID' of 'id', of een object met ID (0 als er geen is).
 */
function _ww_data_item_id( mixed $item ): int {
	if ( is_array( $item ) ) {
		$item = $item['ID'] ?? $item['id'] ?? 0;
	} elseif ( is_object( $item ) ) {
		$item = $item->ID ?? 0;
	}
	return is_numeric( $item ) ? max( 0, (int) $item ) : 0;
}

/**
 * Zet een relatieveld om naar een array met unieke post-ID's.
 *
 * @return int[]
 */
function _ww_data_to_ids( mixed $value ): array {
	// Eén item (ook een array met 'ID' of 'id') wordt een lijst van één.
	if ( ! is_array( $value ) || isset( $value['ID'] ) || isset( $value['id'] ) ) {
		$value = array( $value );
	}
	$ids = array_filter( array_map( '_ww_data_item_id', $value ) );
	return array_values( array_unique( $ids ) );
}

/**
 * Is dit bericht voor bezoekers zichtbaar? Concepten, privé, gepland en prullenbak niet.
 * Een bijlage telt altijd mee: het bestand zelf is openbaar, ook als het bij een concept hoort.
 */
function _ww_data_is_published( int $post_id ): bool {
	$post = $post_id > 0 ? get_post( $post_id ) : null;
	if ( ! $post instanceof WP_Post ) {
		return false;
	}
	return 'attachment' === $post->post_type || is_post_status_viewable( (string) get_post_status( $post ) );
}

/**
 * Zet een foto-veld om naar een attachment-ID (0 als er geen foto is).
 */
function _ww_data_to_attachment_id( mixed $value ): int {
	return _ww_data_to_ids( $value )[0] ?? 0;
}

/**
 * Zet een veldwaarde om naar een bool (ja/nee-veld).
 */
function _ww_data_to_bool( mixed $value ): bool {
	if ( is_string( $value ) ) {
		return ! in_array( strtolower( trim( $value ) ), array( '', '0', 'false', 'no', 'nee' ), true );
	}
	return (bool) $value;
}
