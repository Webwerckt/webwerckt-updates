<?php
/**
 * Standaarden en opschoning: theme supports, wp_head-rommel, emoji, blok-CSS, speculative loading, afbeeldingsformaten.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// De bestandseditor in WordPress staat uit: elke wijziging loopt via Git.
if ( ! defined( 'DISALLOW_FILE_EDIT' ) ) {
	define( 'DISALLOW_FILE_EDIT', true );
}

/**
 * Theme supports.
 */
function _ww_setup_theme(): void {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' )
	);
}
add_action( 'after_setup_theme', '_ww_setup_theme' );

/**
 * Haalt rommel uit wp_head en zet emoji-scripts uit.
 */
function _ww_cleanup_head(): void {
	remove_action( 'wp_head', 'rsd_link' );
	remove_action( 'wp_head', 'wlwmanifest_link' );
	remove_action( 'wp_head', 'wp_generator' );
	remove_action( 'wp_head', 'wp_shortlink_wp_head' );
	remove_action( 'wp_head', 'rest_output_link_wp_head' );
	remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
	remove_action( 'template_redirect', 'wp_shortlink_header', 11 );

	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
	remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
	remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
	remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
	add_filter( 'emoji_svg_url', '__return_false' );
}
add_action( 'init', '_ww_cleanup_head' );

/**
 * Geen CSS van blokken en global styles op de frontend: de editor staat uit en het child-thema rendert geen blokken.
 * Voor WordPress 6.9 is dat de hele block-library; daarna nog een basisbestand, classic-theme-styles en de
 * inline CSS-variabelen van global styles, die WordPress in de footer klaarzet (prioriteit 1) en naar de head verplaatst.
 */
function _ww_dequeue_block_styles(): void {
	/**
	 * Laadt de CSS van blokken toch, voor een child-thema dat wel blokken toont.
	 *
	 * @param bool $load Standaard false.
	 */
	if ( apply_filters( 'ww_block_styles', false ) ) {
		return;
	}
	foreach ( array( 'wp-block-library', 'wp-block-library-theme', 'classic-theme-styles', 'global-styles', 'wp-global-styles-placeholder' ) as $handle ) {
		wp_dequeue_style( $handle );
	}
}
add_action( 'wp_enqueue_scripts', '_ww_dequeue_block_styles', 100 );
add_action( 'wp_footer', '_ww_dequeue_block_styles', 2 );

/**
 * Laat WordPress de global styles niet eens berekenen: dat leest de opgeslagen stijlen van het thema
 * (vier query's per pagina), ook als _ww_dequeue_block_styles() het resultaat daarna weghaalt.
 * Zonder theme.json leveren ook de lettertypen uit theme.json niets op, dus die hoeven niet gelezen.
 */
function _ww_skip_global_styles(): void {
	/** Dit filter staat beschreven bij _ww_dequeue_block_styles(). */
	if ( apply_filters( 'ww_block_styles', false ) ) {
		return;
	}
	remove_action( 'wp_enqueue_scripts', 'wp_enqueue_global_styles' );
	remove_action( 'wp_footer', 'wp_enqueue_global_styles', 1 );
	if ( ! wp_theme_has_theme_json() ) {
		remove_action( 'wp_head', 'wp_print_font_faces', 50 );
		remove_action( 'wp_head', 'wp_print_font_faces_from_style_variations', 50 );
	}
}
add_action( 'wp_head', '_ww_skip_global_styles', 0 );

/**
 * Registreert voor bezoekers geen blokken, blokpatronen, block bindings, iconen en lettertypecollecties: het
 * child-thema rendert geen blokken en de editor staat uit. Dat scheelt een groot deel van init (op de testsite
 * 10 tot 25 ms) en de twee transient-query's van de patronen in het thema. In de admin, de REST API en voor
 * ingelogde gebruikers blijft alles geregistreerd. Ook dit volgt het filter ww_block_styles.
 *
 * Op naam, zodat blokken die WordPress later toevoegt ook wegblijven.
 *
 * @param bool|null $visitor Of dit een bezoeker is; null bepaalt het met _ww_is_visitor_request().
 */
function _ww_skip_block_registration( ?bool $visitor = null ): void {
	/** Dit filter staat beschreven bij _ww_dequeue_block_styles(). */
	if ( apply_filters( 'ww_block_styles', false ) || ! ( $visitor ?? _ww_is_visitor_request() ) ) {
		return;
	}
	global $wp_filter;
	$pattern = '/^(register_block_core_|register_core_block_|register_legacy_post_comments_block$|wp_register_core_block_metadata_collection$|_register_block_bindings_|_register_(core|theme)_block_patterns|_wp_register_default_(icons|icon_collections|font_collections)$|WP_Block_Supports::init$)/';
	foreach ( $wp_filter['init']->callbacks ?? array() as $priority => $callbacks ) {
		foreach ( $callbacks as $callback ) {
			$function = $callback['function'];
			$name     = is_array( $function ) && is_string( $function[0] ?? null ) ? $function[0] . '::' . _ww_data_to_string( $function[1] ?? '' ) : $function;
			if ( is_string( $name ) && preg_match( $pattern, $name ) ) {
				remove_action( 'init', $function, $priority );
			}
		}
	}
}
add_action( 'init', '_ww_skip_block_registration', -1 );

/**
 * Speculative loading (WordPress 6.8+): de browser haalt een pagina al op zodra de muis even op een link staat,
 * in plaats van pas bij het klikken. De pagina komt meestal uit de LiteSpeed-cache, en prefetch voert geen
 * JavaScript uit, dus statistieken tellen niets dubbel. Staat het uit (null, zoals voor ingelogde gebruikers),
 * dan blijft het uit.
 *
 * @param mixed $config Instelling van WordPress.
 * @return mixed
 */
function _ww_speculation_rules( $config ) {
	if ( ! is_array( $config ) ) {
		return $config;
	}
	return array(
		'mode'      => 'prefetch',
		'eagerness' => 'moderate',
	);
}
add_filter( 'wp_speculation_rules_configuration', '_ww_speculation_rules' );

/**
 * Zet overbodige standaardformaten van WordPress uit; het child-thema registreert zijn eigen formaten.
 *
 * @param array<string,array<string,mixed>> $sizes
 * @return array<string,array<string,mixed>>
 */
function _ww_remove_default_image_sizes( array $sizes ): array {
	unset( $sizes['medium_large'], $sizes['1536x1536'], $sizes['2048x2048'] );
	return $sizes;
}
add_filter( 'intermediate_image_sizes_advanced', '_ww_remove_default_image_sizes' );
