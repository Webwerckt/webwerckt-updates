<?php
/**
 * Abilities (WordPress 6.9+) waarmee een AI-agent via de MCP Adapter of de REST API een site inricht:
 * berichten zoeken en als concept aanmaken, het paginatemplate kiezen, de velden van een bericht en de
 * Site-instellingen lezen en schrijven, menu's lezen en vullen, en afbeeldingen zoeken, uploaden en bijwerken (beslissing 0018).
 *
 * - De velden komen uit de Pods-configuratie van parent en child-thema. Een bericht krijgt alleen de velden die
 *   ook in de admin bij zijn paginatemplate staan; onbekende velden en verkeerde waarden worden geweigerd.
 * - Schrijven loopt via Pods (de invoerlaag) en daarna wp_update_post(), net als "Bijwerken" in de admin:
 *   revisie, de kopie naar post_content en het legen van de cache gaan zo vanzelf mee.
 * - Elke ability controleert de rechten die de admin ook vraagt. Schrijven kan alleen als WW_ABILITIES_WRITE_HOST
 *   in wp-config.php gelijk is aan de host van de site (het staging-slot). Na een verhuizing naar het live
 *   domein klopt de host niet meer en staat schrijven vanzelf uit; lezen blijft werken.
 * - Nieuwe berichten zijn altijd een concept: publiceren gebeurt in de admin.
 * - Uploaden neemt alleen afbeeldingen aan en loopt via media_handle_sideload(), net als de uploader in de admin.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Categorie van de abilities.
 */
function _ww_abilities_register_category(): void {
	wp_register_ability_category(
		'webwerckt',
		array(
			'label'       => __( 'Webwerckt-site', 'webwerckt-base' ),
			'description' => __( 'Content, velden, Site-instellingen en menu\'s van een site met webwerckt-base.', 'webwerckt-base' ),
		)
	);
}
add_action( 'wp_abilities_api_categories_init', '_ww_abilities_register_category' );

/**
 * Registreert één ability in de categorie webwerckt, beschikbaar voor de REST API en de MCP Adapter.
 *
 * @param array<string,mixed> $input_schema JSON Schema van de invoer.
 * @param callable            $execute      Voert de ability uit.
 * @param callable            $permission   Mag de huidige gebruiker dit (bool of WP_Error)?
 * @param bool                $readonly     Leest alleen.
 * @param bool                $destructive  Kan bestaande gegevens vervangen of verwijderen.
 * @param bool                $idempotent   Twee keer dezelfde aanroep geeft hetzelfde resultaat.
 */
function _ww_register_ability( string $name, string $label, string $description, array $input_schema, callable $execute, callable $permission, bool $readonly, bool $destructive = false, bool $idempotent = true ): void {
	wp_register_ability(
		'webwerckt/' . $name,
		array(
			'label'               => $label,
			'description'         => $description,
			'category'            => 'webwerckt',
			'input_schema'        => $input_schema,
			// Het staging-slot hier en niet in de permissiecheck: WordPress geeft de melding van een geweigerde
			// permissie niet door aan de aanroeper, en dan weet de agent niet waarom schrijven niet lukt.
			'execute_callback'    => $readonly ? $execute : static fn( $input = array() ) => _ww_abilities_write_lock() ?? $execute( $input ),
			'permission_callback' => $permission,
			'meta'                => array(
				'public'      => true,
				// MCP Adapter 0.6+ leidt dit af van public; oudere versies lezen alleen mcp.public.
				'mcp'         => array( 'public' => true ),
				'annotations' => array(
					'readonly'    => $readonly,
					'destructive' => $destructive,
					'idempotent'  => $idempotent,
				),
			),
		)
	);
}

/**
 * JSON Schema van een object met deze eigenschappen.
 *
 * @param array<string,array<string,mixed>> $properties Eigenschappen.
 * @param string[]                          $required   Verplichte eigenschappen.
 * @return array<string,mixed>
 */
function _ww_abilities_schema( array $properties, array $required = array() ): array {
	return array(
		'type'                 => 'object',
		'properties'           => $properties,
		'required'             => $required,
		'additionalProperties' => false,
		'default'              => array(),
	);
}

/**
 * Registreert de abilities.
 */
function _ww_abilities_register(): void {
	$post_id = array(
		'type'        => 'integer',
		'minimum'     => 1,
		'description' => 'ID van het bericht of de pagina.',
	);
	$fields  = array(
		'type'                 => 'object',
		'minProperties'        => 1,
		'additionalProperties' => true,
		'description'          => 'Veldnaam => waarde. Tekst als string, ja/nee als boolean, een foto als attachment-ID, een relatie als lijst met post-ID\'s; null of een lege string maakt het veld leeg.',
	);

	_ww_register_ability(
		'list-posts',
		__( 'Berichten zoeken', 'webwerckt-base' ),
		__( 'Geeft berichten van een post type (page, post, service, …) met ID, titel, status, paginatemplate en link. Ook concepten. Gebruik de ID bij webwerckt/get-fields en webwerckt/update-fields.', 'webwerckt-base' ),
		_ww_abilities_schema(
			array(
				'post_type' => array( 'type' => 'string' ),
				'search'    => array( 'type' => 'string' ),
				'per_page'  => array(
					'type'    => 'integer',
					'minimum' => 1,
					'maximum' => 100,
					'default' => 20,
				),
			),
			array( 'post_type' )
		),
		'_ww_ability_list_posts',
		'_ww_ability_can_list_posts',
		true
	);

	_ww_register_ability(
		'create-post',
		__( 'Concept aanmaken', 'webwerckt-base' ),
		__( 'Maakt een nieuw bericht als concept, eventueel met een paginatemplate (alleen voor beheerders). Publiceren gebeurt in de admin.', 'webwerckt-base' ),
		_ww_abilities_schema(
			array(
				'post_type' => array( 'type' => 'string' ),
				'title'     => array(
					'type'      => 'string',
					'minLength' => 1,
				),
				'template'  => array(
					'type'        => 'string',
					'description' => 'Bestandsnaam van het paginatemplate, bijvoorbeeld page-home.php.',
				),
			),
			array( 'post_type', 'title' )
		),
		'_ww_ability_create_post',
		'_ww_ability_can_create_post',
		false
	);

	_ww_register_ability(
		'set-template',
		__( 'Paginatemplate kiezen', 'webwerckt-base' ),
		__( 'Zet het paginatemplate van een pagina (bijvoorbeeld page-home.php, of default voor de tekstpagina). Het template bepaalt welke velden de pagina heeft. Alleen voor beheerders.', 'webwerckt-base' ),
		_ww_abilities_schema(
			array(
				'post_id'  => $post_id,
				'template' => array( 'type' => 'string' ),
			),
			array( 'post_id', 'template' )
		),
		'_ww_ability_set_template',
		'_ww_ability_can_set_template',
		false
	);

	_ww_register_ability(
		'get-fields',
		__( 'Velden lezen', 'webwerckt-base' ),
		__( 'Geeft de velden van een bericht zoals de admin ze toont bij zijn paginatemplate: naam, label, type en huidige waarde. Lees dit vóór webwerckt/update-fields.', 'webwerckt-base' ),
		_ww_abilities_schema( array( 'post_id' => $post_id ), array( 'post_id' ) ),
		'_ww_ability_get_fields',
		'_ww_ability_can_edit_post',
		true
	);

	_ww_register_ability(
		'update-fields',
		__( 'Velden opslaan', 'webwerckt-base' ),
		__( 'Slaat velden van een bericht op, alleen velden die webwerckt/get-fields voor dat bericht noemt. Werkt als Bijwerken in de admin (revisie, zoekindex, cache). Geeft de velden daarna terug.', 'webwerckt-base' ),
		_ww_abilities_schema(
			array(
				'post_id' => $post_id,
				'fields'  => $fields,
			),
			array( 'post_id', 'fields' )
		),
		'_ww_ability_update_fields',
		'_ww_ability_can_edit_post',
		false
	);

	_ww_register_ability(
		'get-settings',
		__( 'Site-instellingen lezen', 'webwerckt-base' ),
		__( 'Geeft de velden van de Site-instellingen (contactgegevens, social media, velden van het child-thema) met label, type en huidige waarde.', 'webwerckt-base' ),
		_ww_abilities_schema( array() ),
		'_ww_ability_get_settings',
		'_ww_ability_can_edit_settings',
		true
	);

	_ww_register_ability(
		'update-settings',
		__( 'Site-instellingen opslaan', 'webwerckt-base' ),
		__( 'Slaat velden van de Site-instellingen op, alleen velden die webwerckt/get-settings noemt. Leegt daarna de cache van de site.', 'webwerckt-base' ),
		_ww_abilities_schema( array( 'fields' => $fields ), array( 'fields' ) ),
		'_ww_ability_update_settings',
		'_ww_ability_can_edit_settings',
		false
	);

	_ww_register_ability(
		'get-menus',
		__( 'Menu\'s lezen', 'webwerckt-base' ),
		__( 'Geeft alle menulocaties van het thema met het menu dat erop staat en zijn items als boom.', 'webwerckt-base' ),
		_ww_abilities_schema( array() ),
		'_ww_ability_get_menus',
		'_ww_ability_can_edit_menus',
		true
	);

	_ww_register_ability(
		'set-menu',
		__( 'Menu vullen', 'webwerckt-base' ),
		__( 'Vervangt de items van het menu op een menulocatie (maakt het menu aan als er nog geen is). Elk item heeft een post_id (een pagina of bericht) of een url, een optionele title en optioneel children. Alleen voor beheerders.', 'webwerckt-base' ),
		_ww_abilities_schema(
			array(
				'location' => array( 'type' => 'string' ),
				'items'    => array(
					'type'  => 'array',
					'items' => array( 'type' => 'object' ),
				),
			),
			array( 'location', 'items' )
		),
		'_ww_ability_set_menu',
		'_ww_ability_can_edit_menus',
		false,
		true
	);

	_ww_register_ability(
		'upload-media',
		__( 'Afbeelding uploaden', 'webwerckt-base' ),
		__( 'Zet een afbeelding (jpg, png, gif, webp of avif) in de mediabibliotheek, uit base64-data of van een openbare URL, met een alt-tekst. Geeft de attachment-ID voor een fotoveld in webwerckt/update-fields. Elke aanroep maakt een nieuwe bijlage.', 'webwerckt-base' ),
		_ww_abilities_schema(
			array(
				'filename' => array(
					'type'        => 'string',
					'minLength'   => 1,
					'description' => 'Bestandsnaam met extensie, bijvoorbeeld hero-bestelbussen.jpg.',
				),
				'data'     => array(
					'type'        => 'string',
					'description' => 'Inhoud van het bestand als base64, eventueel als data-URL. Gebruik data of url.',
				),
				'url'      => array(
					'type'        => 'string',
					'description' => 'Openbare https-URL van de afbeelding. Gebruik data of url.',
				),
				'alt'      => array(
					'type'        => 'string',
					'description' => 'Alt-tekst: wat er op de foto staat. Leeg voor een decoratieve afbeelding.',
				),
				'title'    => array(
					'type'        => 'string',
					'description' => 'Titel in de mediabibliotheek; standaard de bestandsnaam.',
				),
			),
			array( 'filename' )
		),
		'_ww_ability_upload_media',
		'_ww_ability_can_upload_media',
		false,
		false,
		false
	);

	_ww_register_ability(
		'list-media',
		__( 'Afbeeldingen zoeken', 'webwerckt-base' ),
		__( 'Zoekt afbeeldingen in de mediabibliotheek op titel of bestandsnaam, nieuwste eerst, met ID, URL, alt-tekst, afmetingen en de beschikbare formaten. Gebruik de ID in een fotoveld bij webwerckt/update-fields; zoek eerst hier voordat je een foto opnieuw uploadt.', 'webwerckt-base' ),
		_ww_abilities_schema(
			array(
				'search'   => array(
					'type'        => 'string',
					'description' => 'Woord uit de titel of de bestandsnaam; leeg voor de nieuwste afbeeldingen.',
				),
				'per_page' => array(
					'type'    => 'integer',
					'minimum' => 1,
					'maximum' => 100,
					'default' => 20,
				),
			)
		),
		'_ww_ability_list_media',
		'_ww_ability_can_upload_media',
		true
	);

	_ww_register_ability(
		'update-media',
		__( 'Afbeelding bijwerken', 'webwerckt-base' ),
		__( 'Past de alt-tekst en/of de titel van een afbeelding in de mediabibliotheek aan, net als in de admin. Velden die je weglaat blijven zoals ze zijn; een lege alt-tekst maakt de afbeelding decoratief. Zoek de ID met webwerckt/list-media.', 'webwerckt-base' ),
		_ww_abilities_schema(
			array(
				'id'    => array(
					'type'        => 'integer',
					'minimum'     => 1,
					'description' => 'ID van de afbeelding.',
				),
				'alt'   => array(
					'type'        => 'string',
					'description' => 'Alt-tekst: wat er op de foto staat. Leeg voor een decoratieve afbeelding.',
				),
				'title' => array(
					'type'      => 'string',
					'minLength' => 1,
				),
			),
			array( 'id' )
		),
		'_ww_ability_update_media',
		'_ww_ability_can_edit_media',
		false
	);
}
add_action( 'wp_abilities_api_init', '_ww_abilities_register' );

/*
 * Staging-slot en rechten. De permissiechecks vragen dezelfde rechten als de admin.
 */

/**
 * Fout als schrijven niet mag, anders null. Schrijven mag alleen als de verwachte host is ingesteld en
 * gelijk is aan de host van de site.
 *
 * @param string $expected Host uit WW_ABILITIES_WRITE_HOST ('' als hij niet is ingesteld).
 * @param string $host     Host van home_url().
 */
function _ww_abilities_write_error( string $expected, string $host ): ?WP_Error {
	if ( '' === $expected ) {
		return new WP_Error( 'ww_abilities_locked', __( 'Schrijven via abilities staat uit. Zet op een staging-site define( \'WW_ABILITIES_WRITE_HOST\', \'<host van de site>\' ); in wp-config.php.', 'webwerckt-base' ), array( 'status' => 403 ) );
	}
	if ( strtolower( $expected ) !== strtolower( $host ) ) {
		/* translators: 1: host van de site, 2: host uit WW_ABILITIES_WRITE_HOST. */
		return new WP_Error( 'ww_abilities_wrong_host', sprintf( __( 'Schrijven via abilities staat uit: deze site is %1$s, maar WW_ABILITIES_WRITE_HOST is %2$s.', 'webwerckt-base' ), $host, $expected ), array( 'status' => 403 ) );
	}
	return null;
}

/**
 * Het staging-slot voor deze site: fout als schrijven niet mag, anders null.
 */
function _ww_abilities_write_lock(): ?WP_Error {
	$expected = defined( 'WW_ABILITIES_WRITE_HOST' ) ? _ww_data_to_string( constant( 'WW_ABILITIES_WRITE_HOST' ) ) : '';
	return _ww_abilities_write_error( $expected, (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
}

/**
 * Het bericht uit de invoer, of null. Alleen van een post type dat de abilities kennen (_ww_abilities_type_object()):
 * interne post types zoals user_request (privacyverzoeken, de titel is een e-mailadres) hebben vaak de rechten
 * van gewone berichten, zodat een Redacteur ze anders kon lezen.
 *
 * @param mixed $input Invoer van de ability.
 */
function _ww_abilities_post( $input ): ?WP_Post {
	$post = get_post( is_array( $input ) ? absint( $input['post_id'] ?? 0 ) : 0 );
	return $post instanceof WP_Post && null !== _ww_abilities_type_object( $post->post_type ) ? $post : null;
}

/**
 * Het post type uit de invoer, als de abilities het kennen (_ww_abilities_type_object()), of null.
 *
 * @param mixed $input Invoer van de ability.
 */
function _ww_abilities_post_type( $input ): ?WP_Post_Type {
	return _ww_abilities_type_object( is_array( $input ) ? sanitize_key( _ww_data_to_string( $input['post_type'] ?? '' ) ) : '' );
}

/**
 * Een post type met content dat in de admin te bewerken is (show_ui), of null. Bijlagen, menu-items en de
 * interne post types van WordPress (wp_block, wp_template, …) niet.
 */
function _ww_abilities_type_object( string $name ): ?WP_Post_Type {
	$object = get_post_type_object( $name );
	$intern = in_array( $name, array( 'attachment', 'nav_menu_item' ), true ) || str_starts_with( $name, 'wp_' );
	return $object instanceof WP_Post_Type && $object->show_ui && ! $intern ? $object : null;
}

/**
 * Mag de gebruiker berichten van dit post type bekijken in de admin?
 *
 * @param mixed $input Invoer van de ability.
 */
function _ww_ability_can_list_posts( $input ): bool {
	$type = _ww_abilities_post_type( $input );
	return null !== $type && current_user_can( $type->cap->edit_posts );
}

/**
 * Mag de gebruiker een concept van dit post type maken (en zo nodig het template kiezen)?
 *
 * @param mixed $input Invoer van de ability.
 */
function _ww_ability_can_create_post( $input ): bool {
	$type     = _ww_abilities_post_type( $input );
	$template = _ww_data_to_string( is_array( $input ) ? ( $input['template'] ?? '' ) : '' );
	return null !== $type && current_user_can( $type->cap->create_posts ) && ( '' === $template || current_user_can( 'edit_theme_options' ) );
}

/**
 * Mag de gebruiker dit bericht bewerken (en dus zijn velden lezen en opslaan)?
 *
 * @param mixed $input Invoer van de ability.
 */
function _ww_ability_can_edit_post( $input ): bool {
	$post = _ww_abilities_post( $input );
	return null !== $post && current_user_can( 'edit_post', $post->ID );
}

/**
 * Mag de gebruiker het template van dit bericht kiezen? Net als in de admin alleen een beheerder.
 *
 * @param mixed $input Invoer van de ability.
 */
function _ww_ability_can_set_template( $input ): bool {
	return current_user_can( 'edit_theme_options' ) && _ww_ability_can_edit_post( $input );
}

/**
 * Mag de gebruiker de Site-instellingen bewerken? De beheerder, of wie het recht van een instellingen-pod heeft
 * (de Redacteur, zie _ww_pods_grant_settings_cap()).
 */
function _ww_ability_can_edit_settings(): bool {
	return array() !== _ww_abilities_setting_fields();
}

/**
 * Mag de gebruiker menu's bekijken? Alleen de beheerder: de klant krijgt edit_theme_options alleen op het menuscherm.
 */
function _ww_ability_can_edit_menus(): bool {
	return current_user_can( 'edit_theme_options' );
}

/**
 * Mag de gebruiker bestanden uploaden (en dus de mediabibliotheek bekijken)? Net als "Media" in de admin.
 */
function _ww_ability_can_upload_media(): bool {
	return current_user_can( 'upload_files' );
}

/**
 * De afbeelding uit de invoer, of null. Alleen afbeeldingen, net als bij list-media en upload-media.
 *
 * @param mixed $input Invoer van de ability.
 */
function _ww_abilities_image( $input ): ?WP_Post {
	$post = get_post( is_array( $input ) ? absint( $input['id'] ?? 0 ) : 0 );
	return $post instanceof WP_Post && 'attachment' === $post->post_type && wp_attachment_is_image( $post ) ? $post : null;
}

/**
 * Mag de gebruiker deze afbeelding bewerken? Hetzelfde recht als "Bijlage bewerken" in de admin.
 *
 * @param mixed $input Invoer van de ability.
 */
function _ww_ability_can_edit_media( $input ): bool {
	$image = _ww_abilities_image( $input );
	return null !== $image && current_user_can( 'edit_post', $image->ID );
}

/*
 * Berichten en templates.
 */

/**
 * Een bericht als array voor de antwoorden.
 *
 * @return array<string,mixed>
 */
function _ww_abilities_post_summary( WP_Post $post ): array {
	return array(
		'id'        => $post->ID,
		'post_type' => $post->post_type,
		'title'     => get_the_title( $post ),
		'status'    => $post->post_status,
		'template'  => (string) get_page_template_slug( $post ) ?: 'default',
		'link'      => (string) get_permalink( $post ),
		'edit_link' => (string) get_edit_post_link( $post, 'raw' ),
	);
}

/**
 * Berichten van een post type, nieuwste eerst.
 *
 * @param array<string,mixed> $input post_type, search, per_page.
 * @return array<string,mixed>
 */
function _ww_ability_list_posts( array $input ): array {
	$query = new WP_Query(
		array(
			'post_type'      => sanitize_key( _ww_data_to_string( $input['post_type'] ?? '' ) ),
			'post_status'    => array( 'publish', 'future', 'draft', 'pending', 'private' ),
			'perm'           => 'editable',
			's'              => sanitize_text_field( _ww_data_to_string( $input['search'] ?? '' ) ),
			'posts_per_page' => min( 100, max( 1, absint( $input['per_page'] ?? 20 ) ) ),
			'orderby'        => 'date',
			'order'          => 'DESC',
			'no_found_rows'  => true,
		)
	);
	return array( 'posts' => array_map( '_ww_abilities_post_summary', array_filter( $query->posts, static fn( $post ): bool => $post instanceof WP_Post ) ) );
}

/**
 * Fout als het template niet bij dit bericht past, anders null. 'default' is de tekstpagina.
 */
function _ww_abilities_template_error( WP_Post $post, string $template ): ?WP_Error {
	$templates = array_keys( wp_get_theme()->get_page_templates( $post, $post->post_type ) );
	if ( 'default' === $template || in_array( $template, $templates, true ) ) {
		return null;
	}
	/* translators: 1: template, 2: beschikbare templates. */
	return new WP_Error( 'ww_abilities_template', sprintf( __( 'Template %1$s bestaat niet voor dit bericht. Kies uit: default, %2$s.', 'webwerckt-base' ), $template, implode( ', ', $templates ) ), array( 'status' => 400 ) );
}

/**
 * Maakt een concept, eventueel met template.
 *
 * @param array<string,mixed> $input post_type, title, template.
 * @return array<string,mixed>|WP_Error
 */
function _ww_ability_create_post( array $input ) {
	$template = _ww_data_to_string( $input['template'] ?? '' );
	$post_id  = wp_insert_post(
		array(
			'post_type'   => sanitize_key( _ww_data_to_string( $input['post_type'] ?? '' ) ),
			'post_title'  => sanitize_text_field( _ww_data_to_string( $input['title'] ?? '' ) ),
			'post_status' => 'draft',
		),
		true
	);
	if ( is_wp_error( $post_id ) ) {
		return $post_id;
	}
	if ( '' !== $template ) {
		$result = _ww_ability_set_template(
			array(
				'post_id'  => $post_id,
				'template' => $template,
			)
		);
		if ( is_wp_error( $result ) ) {
			return $result;
		}
	}
	$post = get_post( $post_id );
	return $post instanceof WP_Post ? _ww_abilities_post_summary( $post ) : new WP_Error( 'ww_abilities_post', __( 'Het concept is niet aangemaakt.', 'webwerckt-base' ) );
}

/**
 * Zet het paginatemplate.
 *
 * @param array<string,mixed> $input post_id, template.
 * @return array<string,mixed>|WP_Error
 */
function _ww_ability_set_template( array $input ) {
	$post     = _ww_abilities_post( $input );
	$template = _ww_data_to_string( $input['template'] ?? '' );
	if ( null === $post ) {
		return new WP_Error( 'ww_abilities_post', __( 'Bericht niet gevonden.', 'webwerckt-base' ), array( 'status' => 404 ) );
	}
	$error = _ww_abilities_template_error( $post, $template );
	if ( null !== $error ) {
		return $error;
	}

	$result = wp_update_post(
		array(
			'ID'            => $post->ID,
			'page_template' => $template,
		),
		true
	);
	if ( is_wp_error( $result ) ) {
		return $result;
	}
	$post = get_post( $post->ID );
	return $post instanceof WP_Post ? _ww_abilities_post_summary( $post ) : new WP_Error( 'ww_abilities_post', __( 'Bericht niet gevonden.', 'webwerckt-base' ) );
}

/*
 * Velden en Site-instellingen.
 */

/**
 * Velden van een bericht bij zijn template, op naam.
 *
 * @return array<string,array<string,mixed>>
 */
function _ww_abilities_post_fields( WP_Post $post ): array {
	return array_column( _ww_pods_fields( $post->post_type, $post->ID ), null, 'name' );
}

/**
 * Velden van de Site-instellingen die de gebruiker mag bewerken, op naam.
 *
 * @return array<string,array<string,mixed>>
 */
function _ww_abilities_setting_fields(): array {
	$admin  = current_user_can( 'edit_theme_options' );
	$fields = array_filter(
		_ww_pods_setting_fields(),
		static fn( array $field ): bool => $admin || current_user_can( 'pods_edit_' . _ww_data_to_string( $field['pod'] ?? '' ) )
	);
	return array_column( $fields, null, 'name' );
}

/**
 * Is dit veld er een met meerdere waarden (relatie of bestanden)?
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 */
function _ww_abilities_is_multi( array $field ): bool {
	$format = 'pick' === ( $field['type'] ?? '' ) ? ( $field['pick_format_type'] ?? 'single' ) : ( $field['file_format_type'] ?? 'single' );
	return 'multi' === $format;
}

/**
 * Opgeslagen waarde als gewone waarde voor het antwoord: ID's voor relaties en foto's, bool voor ja/nee, anders tekst.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @param mixed               $raw   Opgeslagen waarde.
 * @return mixed
 */
function _ww_abilities_value( array $field, $raw ) {
	$type = _ww_data_to_string( $field['type'] ?? '' );
	if ( 'pick' === $type || 'file' === $type ) {
		$ids = _ww_data_to_ids( $raw );
		return _ww_abilities_is_multi( $field ) ? $ids : ( $ids[0] ?? 0 );
	}
	if ( 'boolean' === $type ) {
		return _ww_data_to_bool( $raw );
	}
	return _ww_data_to_string( $raw );
}

/**
 * Velden met label, type en waarde voor het antwoord.
 *
 * @param array<string,array<string,mixed>> $fields Velden op naam.
 * @param callable                          $read   Geeft de opgeslagen waarde van een veldnaam.
 * @return array<int,array<string,mixed>>
 */
function _ww_abilities_describe( array $fields, callable $read ): array {
	$out = array();
	foreach ( $fields as $name => $field ) {
		$item = array(
			'name'  => $name,
			'label' => _ww_data_to_string( $field['label'] ?? '' ),
			'type'  => _ww_data_to_string( $field['type'] ?? '' ),
			'value' => _ww_abilities_value( $field, $read( $name ) ),
		);
		if ( 'pick' === $item['type'] ) {
			$item['post_type'] = _ww_data_to_string( $field['pick_val'] ?? '' );
		}
		if ( in_array( $item['type'], array( 'pick', 'file' ), true ) ) {
			$item['multiple'] = _ww_abilities_is_multi( $field );
		}
		$out[] = $item;
	}
	return $out;
}

/**
 * ID's uit de invoer van een relatie- of bestandsveld, of een fout.
 *
 * @param mixed $value Invoer: één ID, een lijst met ID's, of leeg.
 * @return int[]|WP_Error
 */
function _ww_abilities_input_ids( $value ) {
	if ( null === $value || '' === $value ) {
		return array();
	}
	$list = is_array( $value ) ? $value : array( $value );
	$ids  = array();
	foreach ( $list as $id ) {
		if ( ! is_int( $id ) && ! ( is_string( $id ) && ctype_digit( $id ) ) ) {
			return new WP_Error( 'ww_abilities_value', __( 'Verwacht een post-ID of een lijst met post-ID\'s.', 'webwerckt-base' ) );
		}
		$ids[] = (int) $id;
	}
	return array_values( array_unique( array_filter( $ids ) ) );
}

/**
 * Fout als een ID niet het verwachte soort bericht is, anders null.
 *
 * @param int[]  $ids       Post-ID's.
 * @param string $post_type Verwacht post type ('attachment' voor bestanden).
 * @param bool   $images    Alleen afbeeldingen.
 */
function _ww_abilities_ids_error( array $ids, string $post_type, bool $images ): ?WP_Error {
	foreach ( $ids as $id ) {
		$post = get_post( $id );
		$ok   = $post instanceof WP_Post && $post_type === $post->post_type && 'trash' !== $post->post_status && ( ! $images || wp_attachment_is_image( $post ) );
		if ( ! $ok ) {
			/* translators: 1: post-ID, 2: verwacht soort bericht. */
			return new WP_Error( 'ww_abilities_value', sprintf( __( 'ID %1$d is geen %2$s.', 'webwerckt-base' ), $id, $images ? 'afbeelding' : $post_type ) );
		}
	}
	return null;
}

/**
 * Invoerwaarde van een veld, gecontroleerd en klaar voor Pods, of een fout.
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @param mixed               $value Invoer.
 * @return mixed
 */
function _ww_abilities_input_value( array $field, $value ) {
	$type = _ww_data_to_string( $field['type'] ?? '' );

	if ( 'pick' === $type || 'file' === $type ) {
		if ( 'pick' === $type && 'post_type' !== ( $field['pick_object'] ?? '' ) ) {
			return new WP_Error( 'ww_abilities_value', __( 'Alleen relaties met berichten zijn te bewerken.', 'webwerckt-base' ) );
		}
		$ids = _ww_abilities_input_ids( $value );
		if ( is_wp_error( $ids ) ) {
			return $ids;
		}
		if ( ! _ww_abilities_is_multi( $field ) && count( $ids ) > 1 ) {
			return new WP_Error( 'ww_abilities_value', __( 'Dit veld heeft één waarde.', 'webwerckt-base' ) );
		}
		$error = 'pick' === $type
			? _ww_abilities_ids_error( $ids, _ww_data_to_string( $field['pick_val'] ?? '' ), false )
			: _ww_abilities_ids_error( $ids, 'attachment', 'images' === ( $field['file_type'] ?? 'images' ) );
		if ( null !== $error ) {
			return $error;
		}
		return _ww_abilities_is_multi( $field ) ? $ids : ( $ids[0] ?? '' );
	}

	if ( 'boolean' === $type ) {
		if ( ! is_bool( $value ) && ! in_array( $value, array( 0, 1, '0', '1' ), true ) ) {
			return new WP_Error( 'ww_abilities_value', __( 'Verwacht true of false.', 'webwerckt-base' ) );
		}
		return (int) (bool) $value;
	}

	if ( null === $value ) {
		return '';
	}
	if ( ! is_string( $value ) && ! is_int( $value ) && ! is_float( $value ) ) {
		return new WP_Error( 'ww_abilities_value', __( 'Verwacht tekst.', 'webwerckt-base' ) );
	}
	if ( 'email' === $type && '' !== $value && ! is_email( (string) $value ) ) {
		return new WP_Error( 'ww_abilities_value', __( 'Geen geldig e-mailadres.', 'webwerckt-base' ) );
	}
	return (string) $value;
}

/**
 * Alle invoerwaarden gecontroleerd tegen de toegestane velden: de waarden klaar voor Pods, of de eerste fout.
 *
 * @param mixed                             $input   Invoer (veldnaam => waarde).
 * @param array<string,array<string,mixed>> $allowed Toegestane velden op naam.
 * @return array<string,mixed>|WP_Error
 */
function _ww_abilities_input_fields( $input, array $allowed ) {
	$data = array();
	foreach ( is_array( $input ) ? $input : array() as $name => $value ) {
		$name = (string) $name;
		if ( ! isset( $allowed[ $name ] ) ) {
			/* translators: 1: veldnaam, 2: toegestane velden. */
			return new WP_Error( 'ww_abilities_field', sprintf( __( 'Onbekend veld %1$s. Velden: %2$s.', 'webwerckt-base' ), $name, implode( ', ', array_keys( $allowed ) ) ), array( 'status' => 400 ) );
		}
		$clean = _ww_abilities_input_value( $allowed[ $name ], $value );
		if ( is_wp_error( $clean ) ) {
			/* translators: 1: veldnaam, 2: foutmelding. */
			return new WP_Error( 'ww_abilities_value', sprintf( __( 'Veld %1$s: %2$s', 'webwerckt-base' ), $name, $clean->get_error_message() ), array( 'status' => 400 ) );
		}
		$data[ $name ] = $clean;
	}
	return $data;
}

/**
 * Slaat waarden op via Pods, de invoerlaag. Geeft null of een fout.
 *
 * @param array<string,mixed> $data Veldnaam => waarde.
 */
function _ww_abilities_pods_save( string $pod, int $id, array $data ): ?WP_Error {
	if ( ! function_exists( 'pods' ) ) {
		return new WP_Error( 'ww_abilities_pods', __( 'De plugin Pods is niet actief.', 'webwerckt-base' ), array( 'status' => 503 ) );
	}
	try {
		$item  = $id > 0 ? pods( $pod, $id ) : pods( $pod );
		$saved = is_object( $item ) ? $item->save( $data ) : false;
	} catch ( Throwable $e ) {
		/* translators: %s: foutmelding van Pods. */
		return new WP_Error( 'ww_abilities_pods', sprintf( __( 'Pods kon niet opslaan: %s', 'webwerckt-base' ), $e->getMessage() ), array( 'status' => 400 ) );
	}
	return false === $saved || is_wp_error( $saved ) ? new WP_Error( 'ww_abilities_pods', __( 'Pods kon niet opslaan.', 'webwerckt-base' ), array( 'status' => 400 ) ) : null;
}

/**
 * Velden van een bericht met hun waarden.
 *
 * @param array<string,mixed> $input post_id.
 * @return array<string,mixed>|WP_Error
 */
function _ww_ability_get_fields( array $input ) {
	$post = _ww_abilities_post( $input );
	if ( null === $post ) {
		return new WP_Error( 'ww_abilities_post', __( 'Bericht niet gevonden.', 'webwerckt-base' ), array( 'status' => 404 ) );
	}
	return array(
		'post'   => _ww_abilities_post_summary( $post ),
		'fields' => _ww_abilities_describe( _ww_abilities_post_fields( $post ), static fn( string $name ) => _ww_data_get_stored( $name, $post->ID ) ),
	);
}

/**
 * Slaat velden van een bericht op en werkt het bericht bij zoals "Bijwerken" in de admin.
 *
 * @param array<string,mixed> $input post_id, fields.
 * @return array<string,mixed>|WP_Error
 */
function _ww_ability_update_fields( array $input ) {
	$post = _ww_abilities_post( $input );
	if ( null === $post ) {
		return new WP_Error( 'ww_abilities_post', __( 'Bericht niet gevonden.', 'webwerckt-base' ), array( 'status' => 404 ) );
	}
	$data = _ww_abilities_input_fields( $input['fields'] ?? array(), _ww_abilities_post_fields( $post ) );
	if ( is_wp_error( $data ) ) {
		return $data;
	}
	$error = _ww_abilities_pods_save( $post->post_type, $post->ID, $data );
	if ( null !== $error ) {
		return $error;
	}

	$result = _ww_update_post( array( 'ID' => $post->ID ) );
	return is_wp_error( $result ) ? $result : _ww_ability_get_fields( array( 'post_id' => $post->ID ) );
}

/**
 * Site-instellingen met hun waarden.
 *
 * @return array<string,mixed>
 */
function _ww_ability_get_settings(): array {
	return array( 'fields' => _ww_abilities_describe( _ww_abilities_setting_fields(), '_ww_data_get_setting' ) );
}

/**
 * Slaat Site-instellingen op, per instellingen-pod. De cache leegt zich bij het opslaan van de opties (inc/integrations/litespeed.php).
 *
 * @param array<string,mixed> $input fields.
 * @return array<string,mixed>|WP_Error
 */
function _ww_ability_update_settings( array $input ) {
	$allowed = _ww_abilities_setting_fields();
	$data    = _ww_abilities_input_fields( $input['fields'] ?? array(), $allowed );
	if ( is_wp_error( $data ) ) {
		return $data;
	}

	$per_pod = array();
	foreach ( $data as $name => $value ) {
		$per_pod[ _ww_data_to_string( $allowed[ $name ]['pod'] ?? '' ) ][ $name ] = $value;
	}
	foreach ( $per_pod as $pod => $values ) {
		$error = _ww_abilities_pods_save( $pod, 0, $values );
		if ( null !== $error ) {
			return $error;
		}
	}
	return _ww_ability_get_settings();
}

/*
 * Menu's.
 */

/**
 * Een menu-item als array voor het antwoord, nog zonder kinderen.
 *
 * @param object{ID:int,title:string,url:string,object:string,object_id:int|string} $item Menu-item uit wp_get_nav_menu_items().
 * @return array<string,mixed>
 */
function _ww_abilities_menu_item( object $item ): array {
	return array(
		'id'        => (int) $item->ID,
		'title'     => $item->title,
		'url'       => $item->url,
		'object'    => $item->object,
		'object_id' => (int) $item->object_id,
		'children'  => array(),
	);
}

/**
 * De items van een menu als boom.
 *
 * @return array<int,array<string,mixed>>
 */
function _ww_abilities_menu_tree( int $menu_id ): array {
	$items    = $menu_id > 0 ? wp_get_nav_menu_items( $menu_id, array( 'update_post_term_cache' => false ) ) : false;
	$items    = is_array( $items ) ? $items : array();
	$ids      = wp_list_pluck( $items, 'ID' );
	$branches = array();
	foreach ( $items as $item ) {
		$parent = (int) $item->menu_item_parent;
		$branches[ in_array( $parent, $ids, true ) ? $parent : 0 ][] = _ww_abilities_menu_item( $item );
	}
	return _ww_menu_branch( $branches, 0 );
}

/**
 * Alle menulocaties met hun menu en items.
 *
 * @return array<string,mixed>
 */
function _ww_ability_get_menus(): array {
	$assigned  = get_nav_menu_locations();
	$locations = array();
	foreach ( get_registered_nav_menus() as $location => $label ) {
		$menu_id     = absint( $assigned[ $location ] ?? 0 );
		$locations[] = array(
			'location' => $location,
			'label'    => $label,
			'menu_id'  => $menu_id,
			'items'    => _ww_abilities_menu_tree( $menu_id ),
		);
	}
	return array( 'locations' => $locations );
}

/**
 * Menu-items uit de invoer, gecontroleerd en klaar voor wp_update_nav_menu_item(), of een fout. Hooguit drie niveaus.
 *
 * @param mixed $items Invoer.
 * @return array<int,array<string,mixed>>|WP_Error
 */
function _ww_abilities_menu_input( $items, int $depth = 1 ) {
	if ( ! is_array( $items ) || $depth > 3 ) {
		return new WP_Error( 'ww_abilities_menu', __( 'Menu-items zijn een lijst, hooguit drie niveaus diep.', 'webwerckt-base' ), array( 'status' => 400 ) );
	}
	$out = array();
	foreach ( $items as $item ) {
		$item  = is_array( $item ) ? $item : array();
		$title = sanitize_text_field( _ww_data_to_string( $item['title'] ?? '' ) );
		$id    = absint( $item['post_id'] ?? 0 );
		$url   = _ww_data_to_string( $item['url'] ?? '' );
		$post  = $id > 0 ? get_post( $id ) : null;

		if ( $post instanceof WP_Post && ! in_array( $post->post_type, array( 'revision', 'nav_menu_item', 'attachment' ), true ) && 'trash' !== $post->post_status ) {
			$args = array(
				'menu-item-type'      => 'post_type',
				'menu-item-object'    => $post->post_type,
				'menu-item-object-id' => $post->ID,
				'menu-item-title'     => $title,
			);
		} elseif ( 0 === $id && '' !== $title && ( str_starts_with( $url, '/' ) || wp_http_validate_url( $url ) ) ) {
			$args = array(
				'menu-item-type'  => 'custom',
				'menu-item-url'   => esc_url_raw( str_starts_with( $url, '/' ) ? home_url( $url ) : $url ),
				'menu-item-title' => $title,
			);
		} else {
			return new WP_Error( 'ww_abilities_menu', __( 'Elk menu-item heeft een bestaand post_id, of een title met een url (https://… of /pad/).', 'webwerckt-base' ), array( 'status' => 400 ) );
		}

		$children = _ww_abilities_menu_input( $item['children'] ?? array(), $depth + 1 );
		if ( is_wp_error( $children ) ) {
			return $children;
		}
		$out[] = array(
			'args'     => $args + array( 'menu-item-status' => 'publish' ),
			'children' => $children,
		);
	}
	return $out;
}

/**
 * Voegt gecontroleerde items toe aan een menu, met hun kinderen.
 *
 * @param array<int,array<string,mixed>> $items Uit _ww_abilities_menu_input().
 */
function _ww_abilities_menu_add( int $menu_id, array $items, int $parent = 0 ): ?WP_Error {
	foreach ( $items as $item ) {
		$args    = (array) $item['args'];
		$item_id = wp_update_nav_menu_item( $menu_id, 0, $args + array( 'menu-item-parent-id' => $parent ) );
		if ( is_wp_error( $item_id ) ) {
			return $item_id;
		}
		$error = _ww_abilities_menu_add( $menu_id, (array) $item['children'], (int) $item_id );
		if ( null !== $error ) {
			return $error;
		}
	}
	return null;
}

/**
 * Het menu op een locatie, of een nieuw menu met de naam van de locatie dat er meteen op komt.
 *
 * @return int|WP_Error
 */
function _ww_abilities_menu_for( string $location, string $label ) {
	$assigned = get_nav_menu_locations();
	$menu     = wp_get_nav_menu_object( absint( $assigned[ $location ] ?? 0 ) ) ?: wp_get_nav_menu_object( $label );
	$menu_id  = $menu instanceof WP_Term ? $menu->term_id : wp_create_nav_menu( $label );
	if ( is_wp_error( $menu_id ) ) {
		return $menu_id;
	}
	$assigned[ $location ] = (int) $menu_id;
	set_theme_mod( 'nav_menu_locations', $assigned );
	return (int) $menu_id;
}

/**
 * Vervangt de items van het menu op een locatie. Alles wordt eerst gecontroleerd, zodat een fout het menu niet leeg achterlaat.
 *
 * @param array<string,mixed> $input location, items.
 * @return array<string,mixed>|WP_Error
 */
function _ww_ability_set_menu( array $input ) {
	$location   = sanitize_key( _ww_data_to_string( $input['location'] ?? '' ) );
	$registered = get_registered_nav_menus();
	if ( ! isset( $registered[ $location ] ) ) {
		/* translators: 1: menulocatie, 2: bestaande locaties. */
		return new WP_Error( 'ww_abilities_menu', sprintf( __( 'Menulocatie %1$s bestaat niet. Locaties: %2$s.', 'webwerckt-base' ), $location, implode( ', ', array_keys( $registered ) ) ), array( 'status' => 400 ) );
	}
	$items = _ww_abilities_menu_input( $input['items'] ?? null );
	if ( is_wp_error( $items ) ) {
		return $items;
	}

	$menu_id = _ww_abilities_menu_for( $location, $registered[ $location ] );
	if ( is_wp_error( $menu_id ) ) {
		return $menu_id;
	}
	foreach ( wp_get_nav_menu_items( $menu_id, array( 'post_status' => 'any' ) ) ?: array() as $old ) {
		wp_delete_post( $old->ID, true );
	}
	$error = _ww_abilities_menu_add( $menu_id, $items );
	if ( null !== $error ) {
		return $error;
	}

	return array(
		'location' => $location,
		'menu_id'  => $menu_id,
		'items'    => _ww_abilities_menu_tree( $menu_id ),
	);
}

/*
 * Media.
 */

/**
 * Afbeeldingstypen die de ability aanneemt, als extensies => MIME-type voor wp_check_filetype_and_ext(). Geen SVG:
 * dat is code, en WordPress staat het zelf ook niet toe.
 *
 * @return array<string,string>
 */
function _ww_abilities_image_mimes(): array {
	return array_intersect( get_allowed_mime_types(), array( 'image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/avif' ) );
}

/**
 * Zet de invoer in een tijdelijk bestand: base64-data, of een download van een https-URL. Geeft het pad of een fout.
 *
 * @param array<string,mixed> $input data of url.
 * @return string|WP_Error
 */
function _ww_abilities_media_tmp( array $input ) {
	$data = _ww_data_to_string( $input['data'] ?? '' );
	$url  = _ww_data_to_string( $input['url'] ?? '' );
	if ( ( '' === $data ) === ( '' === $url ) ) {
		return new WP_Error( 'ww_abilities_media', __( 'Geef data (base64) of url, niet allebei.', 'webwerckt-base' ), array( 'status' => 400 ) );
	}

	if ( '' !== $url ) {
		if ( 'https' !== wp_parse_url( $url, PHP_URL_SCHEME ) || ! wp_http_validate_url( $url ) ) {
			return new WP_Error( 'ww_abilities_media', __( 'De url moet een openbare https-URL zijn.', 'webwerckt-base' ), array( 'status' => 400 ) );
		}
		// download_url() gebruikt wp_safe_remote_get(): geen adressen op het eigen netwerk.
		return download_url( $url, 30 );
	}

	$binary = base64_decode( (string) preg_replace( '/^data:[^,]*;base64,|\s+/', '', $data ), true );
	if ( false === $binary || '' === $binary ) {
		return new WP_Error( 'ww_abilities_media', __( 'De data is geen geldige base64.', 'webwerckt-base' ), array( 'status' => 400 ) );
	}
	if ( strlen( $binary ) > wp_max_upload_size() ) {
		/* translators: %s: uploadlimiet, bijvoorbeeld 64 MB. */
		return new WP_Error( 'ww_abilities_media', sprintf( __( 'Het bestand is groter dan de uploadlimiet van de site (%s).', 'webwerckt-base' ), size_format( wp_max_upload_size() ) ), array( 'status' => 413 ) );
	}
	$tmp = wp_tempnam( 'ww-upload' );
	if ( false === file_put_contents( $tmp, $binary ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- tijdelijk bestand, net als download_url().
		return new WP_Error( 'ww_abilities_media', __( 'Het tijdelijke bestand kon niet worden geschreven.', 'webwerckt-base' ), array( 'status' => 500 ) );
	}
	return $tmp;
}

/**
 * Een bijlage als array voor het antwoord.
 *
 * @return array<string,mixed>
 */
function _ww_abilities_media_summary( int $id ): array {
	$meta  = wp_get_attachment_metadata( $id );
	$meta  = is_array( $meta ) ? $meta : array();
	$sizes = array();
	foreach ( array_keys( (array) ( $meta['sizes'] ?? array() ) ) as $size ) {
		$src = wp_get_attachment_image_src( $id, (string) $size );
		if ( is_array( $src ) ) {
			$sizes[ (string) $size ] = array(
				'url'    => $src[0],
				'width'  => $src[1],
				'height' => $src[2],
			);
		}
	}
	return array(
		'id'       => $id,
		'title'    => get_the_title( $id ),
		'url'      => (string) wp_get_attachment_url( $id ),
		'filename' => wp_basename( (string) get_attached_file( $id ) ),
		'mime'     => (string) get_post_mime_type( $id ),
		'width'    => absint( $meta['width'] ?? 0 ),
		'height'   => absint( $meta['height'] ?? 0 ),
		'alt'      => _ww_data_to_string( get_post_meta( $id, '_wp_attachment_image_alt', true ) ),
		'sizes'    => (object) $sizes,
	);
}

/**
 * Afbeeldingen uit de mediabibliotheek, nieuwste eerst, gezocht op titel of bestandsnaam.
 *
 * @param array<string,mixed> $input search, per_page.
 * @return array<string,mixed>
 */
function _ww_ability_list_media( array $input = array() ): array {
	// Zoeken op bestandsnaam doet WordPress alleen in de mediabibliotheek van de admin; hier zetten we het aan.
	// WP_Query haalt het filter na gebruik zelf weer weg, dus het geldt alleen voor deze query.
	add_filter( 'wp_allow_query_attachment_by_filename', '__return_true' );
	$query = new WP_Query(
		array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'post_mime_type' => 'image',
			's'              => sanitize_text_field( _ww_data_to_string( $input['search'] ?? '' ) ),
			'posts_per_page' => min( 100, max( 1, absint( $input['per_page'] ?? 20 ) ) ),
			'orderby'        => 'date',
			'order'          => 'DESC',
			'fields'         => 'ids',
			'no_found_rows'  => true,
		)
	);
	return array( 'media' => array_map( static fn( $id ): array => _ww_abilities_media_summary( (int) $id ), $query->posts ) );
}

/**
 * Past de alt-tekst en/of de titel van een afbeelding aan. Een veld dat ontbreekt blijft staan.
 *
 * @param array<string,mixed> $input id, alt, title.
 * @return array<string,mixed>|WP_Error
 */
function _ww_ability_update_media( array $input ) {
	$image = _ww_abilities_image( $input );
	if ( null === $image ) {
		return new WP_Error( 'ww_abilities_media', __( 'Afbeelding niet gevonden.', 'webwerckt-base' ), array( 'status' => 404 ) );
	}
	if ( ! array_key_exists( 'alt', $input ) && ! array_key_exists( 'title', $input ) ) {
		return new WP_Error( 'ww_abilities_media', __( 'Geef alt, title of allebei.', 'webwerckt-base' ), array( 'status' => 400 ) );
	}

	$title = sanitize_text_field( _ww_data_to_string( $input['title'] ?? '' ) );
	if ( '' !== $title ) {
		$result = wp_update_post(
			array(
				'ID'         => $image->ID,
				'post_title' => $title,
			),
			true
		);
		if ( is_wp_error( $result ) ) {
			return $result;
		}
	}
	if ( array_key_exists( 'alt', $input ) ) {
		update_post_meta( $image->ID, '_wp_attachment_image_alt', sanitize_text_field( _ww_data_to_string( $input['alt'] ) ) );
	}
	return _ww_abilities_media_summary( $image->ID );
}

/**
 * Zet een afbeelding in de mediabibliotheek zoals de uploader van de admin: met de formaten van het thema en de
 * metadata. Alleen afbeeldingen; het echte type van het bestand telt, niet alleen de extensie.
 *
 * @param array<string,mixed> $input filename, data of url, alt, title.
 * @return array<string,mixed>|WP_Error
 */
function _ww_ability_upload_media( array $input ) {
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';

	$tmp = _ww_abilities_media_tmp( $input );
	if ( is_wp_error( $tmp ) ) {
		return $tmp;
	}

	$filename = sanitize_file_name( _ww_data_to_string( $input['filename'] ?? '' ) );
	$check    = wp_check_filetype_and_ext( $tmp, $filename, _ww_abilities_image_mimes() );
	if ( empty( $check['type'] ) ) {
		wp_delete_file( $tmp );
		return new WP_Error( 'ww_abilities_media', __( 'Alleen afbeeldingen (jpg, png, gif, webp, avif), en de extensie moet bij de inhoud passen.', 'webwerckt-base' ), array( 'status' => 400 ) );
	}

	$title = sanitize_text_field( _ww_data_to_string( $input['title'] ?? '' ) );
	$id    = media_handle_sideload(
		array(
			'name'     => $check['proper_filename'] ?: $filename,
			'tmp_name' => $tmp,
		),
		0,
		null,
		'' !== $title ? array( 'post_title' => $title ) : array()
	);
	if ( is_wp_error( $id ) ) {
		wp_delete_file( $tmp );
		return $id;
	}

	$alt = sanitize_text_field( _ww_data_to_string( $input['alt'] ?? '' ) );
	if ( '' !== $alt ) {
		update_post_meta( $id, '_wp_attachment_image_alt', $alt );
	}
	return _ww_abilities_media_summary( $id );
}
