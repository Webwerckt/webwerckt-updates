<?php
/**
 * Visueel bewerken (ADR 0019): een adminscherm met de pagina in een iframe en een zijpaneel. Klik je in de pagina
 * op een gemarkeerd element (ww_edit_attrs(), ww_image()), dan toont het zijpaneel de velden ervan; een sectie
 * (ww_section()) toont zijn schakelaar, relaties en de velden die nergens in de pagina gemarkeerd zijn. Wijzigingen
 * gaan in één keer naar de REST-route ww/v1/editor/{id}, die opslaat zoals "Bijwerken" in de admin.
 *
 * De klant (inc/admin.php) ziet alleen Visueel bewerken; een beheerder houdt ook het gewone bewerkscherm.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Slug van het adminscherm en de queryparameter van de pagina in het iframe.
const WW_EDITOR_PAGE  = 'ww-visual-editor';
const WW_EDITOR_PARAM = 'ww-edit';

/*
 * Markeren in de pagina.
 */

/**
 * Attribuut dat een element in Visueel bewerken aanklikbaar maakt voor deze velden van de huidige pagina; buiten
 * de editor ''. Het eerste veld is de inhoud van het element, de andere velden zijn attributen (de href van een knop).
 *
 * @param string ...$fields Veldnamen, of post_title voor de titel van de pagina.
 */
function ww_edit_attrs( string ...$fields ): string {
	$names = array_filter( array_map( 'sanitize_key', $fields ) );
	if ( array() === $names || ! _ww_editor_marks( 0 ) ) {
		return '';
	}
	return _ww_html_attrs( array( 'edit' => implode( ' ', $names ) ) );
}

/**
 * ID van de pagina die in deze frontend-request in het iframe van de editor staat, anders 0.
 * Pas betrouwbaar vanaf de actie wp: dan is de hoofdquery bekend.
 */
function _ww_editor_post_id(): int {
	if ( ! isset( $_GET[ WW_EDITOR_PARAM ] ) || is_admin() || ! did_action( 'wp' ) || ! is_singular() ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen lezen; het recht wordt hieronder gecontroleerd.
		return 0;
	}
	$post = get_queried_object();
	return $post instanceof WP_Post && _ww_editor_can_edit( $post ) ? $post->ID : 0;
}

/**
 * Hoort een veld van dit bericht een markering te krijgen? Alleen in de editor en alleen voor de pagina die
 * bewerkt wordt, niet voor een kaart of relatie van een ander bericht op die pagina.
 *
 * @param int $post_id Bericht-ID van het veld; 0 is het huidige bericht.
 */
function _ww_editor_marks( int $post_id ): bool {
	$editing = _ww_editor_post_id();
	return 0 !== $editing && ( $post_id ?: _ww_current_id() ) === $editing;
}

/**
 * Leeg vlak in plaats van een foto, zodat een leeg fotoveld in de editor aan te klikken is. Zo groot als het
 * afbeeldingsformaat; zonder vaste hoogte 16:9.
 *
 * @param string               $size Geregistreerd afbeeldingsformaat.
 * @param array<string,string> $attr Attributen, met data-ww-edit.
 */
function _ww_editor_image_placeholder( string $size, array $attr ): string {
	$sizes  = wp_get_registered_image_subsizes();
	$width  = (int) ( $sizes[ $size ]['width'] ?? 0 ) ?: 1200;
	$height = (int) ( $sizes[ $size ]['height'] ?? 0 ) ?: (int) round( $width * 9 / 16 );
	$svg    = sprintf( '<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d"/>', $width, $height );

	$attr = array(
		'src'           => 'data:image/svg+xml,' . rawurlencode( $svg ),
		'width'         => (string) $width,
		'height'        => (string) $height,
		'alt'           => '',
		'data-ww-empty' => '',
	) + $attr;

	$html = '';
	foreach ( $attr as $name => $value ) {
		$html .= sprintf( ' %s="%s"', esc_attr( $name ), esc_attr( $value ) );
	}
	return '<img' . $html . '>';
}

/*
 * De pagina in het iframe.
 */

/**
 * Kan deze pagina visueel bewerkt worden? Voorlopig alleen pagina's (ADR 0019, fase 1).
 */
function _ww_editor_supports( WP_Post $post ): bool {
	return 'page' === $post->post_type && 'trash' !== $post->post_status;
}

/**
 * Mag de huidige gebruiker deze pagina visueel bewerken?
 */
function _ww_editor_can_edit( WP_Post $post ): bool {
	return _ww_editor_supports( $post ) && current_user_can( 'edit_post', $post->ID );
}

/**
 * Mag de huidige gebruiker berichten van dit type publiceren?
 */
function _ww_editor_can_publish( WP_Post $post ): bool {
	$type = get_post_type_object( $post->post_type );
	return $type instanceof WP_Post_Type && current_user_can( $type->cap->publish_posts );
}

/**
 * Zet de pagina in editormodus: zonder adminbalk, niet in de cache, alleen in een frame van dezelfde site, met het
 * script dat klikken doorgeeft aan het zijpaneel.
 */
function _ww_editor_frame_setup(): void {
	if ( 0 === _ww_editor_post_id() ) {
		return;
	}
	add_filter( 'show_admin_bar', '__return_false' );
	nocache_headers();
	send_frame_options_header();
	do_action( 'litespeed_control_set_nocache', 'ww visual editor' );
	add_action( 'wp_enqueue_scripts', '_ww_editor_frame_assets' );
	add_action( 'wp_footer', '_ww_editor_frame_data' );
}
add_action( 'wp', '_ww_editor_frame_setup' );

/**
 * Script en stijl van de editormodus.
 */
function _ww_editor_frame_assets(): void {
	wp_enqueue_style( 'ww-editor-frame', _ww_asset_url( 'css/editor-frame.css' ), array(), WW_BASE_VERSION );
	wp_enqueue_script_module( 'ww-editor-frame', _ww_asset_url( 'js/editor-frame.js' ), array(), WW_BASE_VERSION );
}

/**
 * Gegevens voor editor-frame.js: naar welke herkomst het berichten stuurt (het adminscherm).
 */
function _ww_editor_frame_data(): void {
	_ww_editor_print_json( 'ww-editor-frame-data', array( 'origin' => _ww_origin( admin_url() ) ) );
}

/**
 * Herkomst (schema, host en eventueel poort) van een URL, voor postMessage.
 */
function _ww_origin( string $url ): string {
	$parts = wp_parse_url( $url );
	if ( ! is_array( $parts ) || empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
		return '';
	}
	return $parts['scheme'] . '://' . $parts['host'] . ( isset( $parts['port'] ) ? ':' . $parts['port'] : '' );
}

/**
 * Print gegevens voor een script als JSON in een script-element, veilig binnen HTML.
 *
 * @param array<string,mixed> $data
 */
function _ww_editor_print_json( string $id, array $data ): void {
	printf(
		'<script type="application/json" id="%s">%s</script>',
		esc_attr( $id ),
		wp_json_encode( $data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON met < en & als \u-codes.
	);
}

/*
 * Knoppen en links in de admin.
 */

/**
 * URL van de visuele editor voor een bericht.
 */
function _ww_editor_url( int $post_id ): string {
	return add_query_arg(
		array(
			'page' => WW_EDITOR_PAGE,
			'post' => $post_id,
		),
		admin_url( 'admin.php' )
	);
}

/**
 * Zet Visueel bewerken vooraan bij een pagina in de tabel. De klant ziet de gewone Bewerken-link niet meer.
 *
 * @param array<string,string> $actions Acties per sleutel, als HTML.
 * @return array<string,string>
 */
function _ww_editor_row_actions( array $actions, WP_Post $post ): array {
	if ( ! _ww_editor_can_edit( $post ) ) {
		return $actions;
	}
	if ( _ww_is_client() ) {
		unset( $actions['edit'] );
	}
	$link = sprintf( '<a href="%s">%s</a>', esc_url( _ww_editor_url( $post->ID ) ), esc_html__( 'Visueel bewerken', 'webwerckt-base' ) );
	return array( 'ww_visual_edit' => $link ) + $actions;
}
add_filter( 'page_row_actions', '_ww_editor_row_actions', 10, 2 );

/**
 * Elke bewerklink naar een pagina (titel in de tabel, "Pagina bewerken" in de adminbalk) wijst voor de klant naar
 * de visuele editor. Het gewone scherm blijft bereikbaar via de URL: dit is opruimen, geen beveiliging.
 *
 * @param mixed $link    Bewerklink van WordPress.
 * @param mixed $post_id Bericht-ID.
 * @param mixed $context 'display' geeft een link met &amp;.
 * @return mixed
 */
function _ww_editor_edit_link( $link, $post_id, $context ) {
	$post = get_post( (int) $post_id );
	if ( ! $post instanceof WP_Post || ! _ww_editor_supports( $post ) || ! _ww_is_client() ) {
		return $link;
	}
	$url = _ww_editor_url( $post->ID );
	return 'display' === $context ? esc_url( $url ) : $url;
}
add_filter( 'get_edit_post_link', '_ww_editor_edit_link', 10, 3 );

/**
 * Visueel bewerken in de adminbalk op een pagina, voor wie ook het gewone bewerkscherm heeft. Bij de klant wijst
 * "Pagina bewerken" er al naartoe.
 */
function _ww_editor_admin_bar( WP_Admin_Bar $bar ): void {
	$post = get_queried_object();
	if ( is_admin() || _ww_is_client() || ! $post instanceof WP_Post || ! _ww_editor_can_edit( $post ) ) {
		return;
	}
	$bar->add_node(
		array(
			'id'    => 'ww-visual-edit',
			'title' => esc_html__( 'Visueel bewerken', 'webwerckt-base' ),
			'href'  => _ww_editor_url( $post->ID ),
		)
	);
}
add_action( 'admin_bar_menu', '_ww_editor_admin_bar', 81 );

/*
 * Het adminscherm.
 */

/**
 * Registreert het scherm zonder menu-item: je komt er via de knop bij een pagina.
 */
function _ww_editor_register_page(): void {
	$hook = add_submenu_page( '', __( 'Visueel bewerken', 'webwerckt-base' ), '', 'edit_pages', WW_EDITOR_PAGE, '_ww_editor_render' );
	if ( false !== $hook ) {
		add_action( 'load-' . $hook, '_ww_editor_load' );
	}
}
add_action( 'admin_menu', '_ww_editor_register_page' );

/**
 * De pagina uit de URL van het scherm, als de gebruiker hem visueel mag bewerken; anders null.
 */
function _ww_editor_requested_post(): ?WP_Post {
	$post = get_post( isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen lezen; het recht wordt hieronder gecontroleerd.
	return $post instanceof WP_Post && _ww_editor_can_edit( $post ) ? $post : null;
}

/**
 * Vóór de uitvoer van het scherm: rechten, vergrendeling en scripts.
 */
function _ww_editor_load(): void {
	$post = _ww_editor_requested_post();
	if ( null === $post ) {
		wp_die( esc_html__( 'Deze pagina bestaat niet of je mag hem niet bewerken.', 'webwerckt-base' ), 403 );
	}
	if ( ! wp_check_post_lock( $post->ID ) ) {
		wp_set_post_lock( $post->ID );
	}
	// Een scherm zonder menu-item heeft geen titel voor het tabblad van de browser.
	$GLOBALS['title'] = __( 'Visueel bewerken', 'webwerckt-base' ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- de titel van admin-header.php.

	wp_enqueue_media( array( 'post' => $post->ID ) );
	wp_enqueue_editor();
	wp_enqueue_script( 'wp-api-fetch' );
	wp_enqueue_style( 'ww-editor', _ww_asset_url( 'css/editor.css' ), array(), WW_BASE_VERSION );
	wp_enqueue_script_module( 'ww-editor', _ww_asset_url( 'js/editor.js' ), array(), WW_BASE_VERSION );
}

/**
 * Het scherm: een balk met de knoppen om op te slaan, de pagina in een iframe en het zijpaneel dat erboven zweeft
 * zodra er iets is gekozen. editor.js vult het paneel.
 */
function _ww_editor_render(): void {
	$post = _ww_editor_requested_post();
	if ( null === $post ) {
		return;
	}
	$locked = wp_check_post_lock( $post->ID );
	$data   = _ww_editor_data( $post ) + array(
		'lockedBy'     => $locked ? get_the_author_meta( 'display_name', $locked ) : '',
		// De editor-style van het child-thema (add_editor_style()), zodat WYSIWYG-tekst eruitziet als op de site.
		'editorStyles' => array_values( get_editor_stylesheets() ),
		// Velden van sectie {naam} beginnen met {voorvoegsel}{naam}_, de schakelaar is {voorvoegsel}{naam}_enabled.
		'prefix'       => _ww_child_prefix(),
		'strings'      => _ww_editor_strings(),
	);
	?>
	<div class="ww-editor" data-ww-editor>
		<header class="ww-editor__bar">
			<a class="ww-editor__back" href="<?php echo esc_url( admin_url( 'edit.php?post_type=page' ) ); ?>">
				<span aria-hidden="true">&larr;</span> <?php esc_html_e( 'Pagina\'s', 'webwerckt-base' ); ?>
			</a>
			<h1 class="ww-editor__title" data-ww-editor-title><?php echo esc_html( get_the_title( $post ) ); ?></h1>
			<span class="ww-editor__status" data-ww-editor-status></span>
			<div class="ww-editor__devices" role="group" aria-label="<?php esc_attr_e( 'Schermformaat', 'webwerckt-base' ); ?>">
				<button type="button" class="button" data-ww-device="" aria-pressed="true"><?php esc_html_e( 'Desktop', 'webwerckt-base' ); ?></button>
				<button type="button" class="button" data-ww-device="tablet" aria-pressed="false"><?php esc_html_e( 'Tablet', 'webwerckt-base' ); ?></button>
				<button type="button" class="button" data-ww-device="mobile" aria-pressed="false"><?php esc_html_e( 'Mobiel', 'webwerckt-base' ); ?></button>
			</div>
			<button type="button" class="button" aria-expanded="false" aria-controls="ww-editor-panel" data-ww-editor-page><?php esc_html_e( 'Pagina-instellingen', 'webwerckt-base' ); ?></button>
			<a class="ww-editor__view" href="<?php echo esc_url( (string) get_permalink( $post ) ); ?>" target="_blank" rel="noopener" data-ww-editor-view><?php esc_html_e( 'Bekijk pagina', 'webwerckt-base' ); ?></a>
			<div class="ww-editor__actions" data-ww-editor-actions></div>
		</header>
		<div class="ww-editor__main">
			<div class="ww-editor__canvas" data-ww-editor-canvas>
				<iframe class="ww-editor__frame" src="<?php echo esc_url( $data['post']['frame'] ); ?>" title="<?php esc_attr_e( 'Voorbeeld van de pagina', 'webwerckt-base' ); ?>" data-ww-editor-frame></iframe>
			</div>
			<aside class="ww-editor__panel" id="ww-editor-panel" aria-labelledby="ww-editor-panel-title" hidden data-ww-editor-panel>
				<div class="ww-editor__panel-head">
					<h2 class="ww-editor__panel-title" id="ww-editor-panel-title" data-ww-editor-panel-title></h2>
					<button type="button" class="button-link ww-editor__close" data-ww-editor-close>
						<span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
						<span class="screen-reader-text"><?php esc_html_e( 'Sluiten', 'webwerckt-base' ); ?></span>
					</button>
				</div>
				<div class="ww-editor__fields" data-ww-editor-fields></div>
			</aside>
		</div>
		<?php _ww_editor_print_json( 'ww-editor-data', $data ); ?>
	</div>
	<?php
}

/**
 * Gegevens van de pagina en haar velden voor het zijpaneel; ook het antwoord na opslaan.
 *
 * @return array<string,mixed>
 */
function _ww_editor_data( WP_Post $post ): array {
	return array(
		'post'       => array(
			'id'        => $post->ID,
			'title'     => $post->post_title,
			'slug'      => $post->post_name,
			'status'    => $post->post_status,
			'published' => _ww_editor_is_published( $post ),
			'link'      => (string) get_permalink( $post ),
			'frame'     => add_query_arg( WW_EDITOR_PARAM, '1', (string) get_preview_post_link( $post ) ),
		),
		'fields'     => _ww_editor_fields( $post ),
		'canPublish' => _ww_editor_can_publish( $post ),
		'endpoint'   => '/ww/v1/editor/' . $post->ID,
		'origin'     => _ww_origin( home_url() ),
	);
}

/**
 * Staat de pagina live (of ingepland, of privé)? Dan bestaat er geen concept meer naast.
 */
function _ww_editor_is_published( WP_Post $post ): bool {
	return in_array( $post->post_status, array( 'publish', 'future', 'private' ), true );
}

/**
 * Velden van de pagina voor het zijpaneel: label, type en waarde, plus titel en slug. Een foto krijgt een
 * voorbeeld-URL. Alleen de velden van zijn template (dezelfde als de abilities, ADR 0018).
 *
 * @return array<string,array<string,mixed>>
 */
function _ww_editor_fields( WP_Post $post ): array {
	$fields = array(
		'post_title' => array(
			'label' => __( 'Titel', 'webwerckt-base' ),
			'type'  => 'text',
			'value' => $post->post_title,
		),
		'post_name'  => array(
			'label' => __( 'Slug (laatste deel van de URL)', 'webwerckt-base' ),
			'type'  => 'slug',
			'value' => $post->post_name,
		),
	);
	foreach ( _ww_abilities_post_fields( $post ) as $name => $field ) {
		$stored = _ww_data_get_stored( $name, $post->ID );
		$item   = array(
			'label' => _ww_data_to_string( $field['label'] ?? $name ),
			'type'  => _ww_data_to_string( $field['type'] ?? '' ),
			// Een sectie zonder opgeslagen schakelaar staat aan (ww_section_enabled()); het vinkje dus ook.
			'value' => null === $stored && _ww_editor_is_toggle( $name ) ? true : _ww_abilities_value( $field, $stored ),
		);
		if ( 'file' === $item['type'] ) {
			$item['multiple'] = _ww_abilities_is_multi( $field );
			$item['images']   = 'images' === ( $field['file_type'] ?? 'images' );
			$item['preview']  = is_int( $item['value'] ) ? (string) wp_get_attachment_image_url( $item['value'], 'medium' ) : '';
		}
		if ( 'pick' === $item['type'] ) {
			$item = _ww_editor_pick_field( $field, $item );
		}
		$fields[ $name ] = $item;
	}
	return $fields;
}

/**
 * Is dit veld de schakelaar van een sectie, child_{sectie}_enabled?
 */
function _ww_editor_is_toggle( string $name ): bool {
	return str_starts_with( $name, _ww_child_prefix() ) && str_ends_with( $name, '_enabled' );
}

/**
 * Een relatieveld voor het zijpaneel: de gekozen berichten in hun volgorde, met titel. Een bericht dat niet meer
 * bestaat of in de prullenbak ligt, valt weg; opslaan zou het weigeren (dezelfde controle als de abilities).
 *
 * @param array<string,mixed> $field Veld uit de configuratie.
 * @param array<string,mixed> $item  Label, type en waarde (ID of lijst met ID's).
 * @return array<string,mixed>
 */
function _ww_editor_pick_field( array $field, array $item ): array {
	$multiple = _ww_abilities_is_multi( $field );
	$items    = array();
	foreach ( _ww_data_to_ids( $item['value'] ) as $id ) {
		$post = get_post( $id );
		if ( $post instanceof WP_Post && _ww_data_to_string( $field['pick_val'] ?? '' ) === $post->post_type && 'trash' !== $post->post_status ) {
			$items[] = _ww_editor_item( $post );
		}
	}
	$ids = array_column( $items, 'id' );

	return array(
		'value'    => $multiple ? $ids : ( $ids[0] ?? 0 ),
		'multiple' => $multiple,
		// Alleen relaties met berichten zijn te bewerken, net als bij de abilities.
		'editable' => 'post_type' === ( $field['pick_object'] ?? '' ),
		'items'    => $items,
	) + $item;
}

/**
 * Een bericht in een relatie: ID, titel en of bezoekers het zien.
 *
 * @return array{id:int,title:string,published:bool}
 */
function _ww_editor_item( WP_Post $post ): array {
	return array(
		'id'        => $post->ID,
		'title'     => $post->post_title,
		'published' => 'publish' === $post->post_status,
	);
}

/**
 * Teksten van het zijpaneel, vertaalbaar via het vertaalsjabloon van de parent.
 *
 * @return array<string,string>
 */
function _ww_editor_strings(): array {
	return array(
		'page'         => __( 'Pagina-instellingen', 'webwerckt-base' ),
		'edit'         => __( 'Bewerken', 'webwerckt-base' ),
		'hint'         => __( 'Klik in de pagina op een tekst of foto om hem te bewerken.', 'webwerckt-base' ),
		'draft'        => __( 'Concept', 'webwerckt-base' ),
		'published'    => __( 'Gepubliceerd', 'webwerckt-base' ),
		'saveDraft'    => __( 'Opslaan als concept', 'webwerckt-base' ),
		'publish'      => __( 'Publiceren', 'webwerckt-base' ),
		'update'       => __( 'Bijwerken', 'webwerckt-base' ),
		'saving'       => __( 'Bezig met opslaan…', 'webwerckt-base' ),
		'saved'        => __( 'Opgeslagen.', 'webwerckt-base' ),
		'error'        => __( 'Opslaan is niet gelukt.', 'webwerckt-base' ),
		/* translators: %d: aantal wijzigingen. */
		'changes'      => __( '%d wijziging(en) nog niet opgeslagen', 'webwerckt-base' ),
		'noChanges'    => __( 'Geen wijzigingen', 'webwerckt-base' ),
		/* translators: %s: naam van de gebruiker. */
		'locked'       => __( '%s heeft deze pagina ook open. Wie het laatst opslaat, overschrijft de ander.', 'webwerckt-base' ),
		'chooseImage'  => __( 'Kies een foto', 'webwerckt-base' ),
		'useImage'     => __( 'Gebruik deze foto', 'webwerckt-base' ),
		'removeImage'  => __( 'Foto weghalen', 'webwerckt-base' ),
		'notYet'       => __( 'Dit veld kun je hier nog niet bewerken.', 'webwerckt-base' ),
		'searchLink'   => __( 'Zoek een pagina of typ een URL', 'webwerckt-base' ),
		'noResults'    => __( 'Niets gevonden. Typ een volledige URL, bijvoorbeeld https://…', 'webwerckt-base' ),
		/* translators: Opmaakkeuzes van de teksteditor, in het formaat van TinyMCE: label=element, gescheiden door ;. */
		'blockFormats' => __( 'Alinea=p;Kop 2=h2;Kop 3=h3;Kop 4=h4', 'webwerckt-base' ),
		'leave'        => __( 'Je hebt wijzigingen die nog niet zijn opgeslagen.', 'webwerckt-base' ),
		'other'        => __( 'Overige velden', 'webwerckt-base' ),
		'hidden'       => __( 'verborgen', 'webwerckt-base' ),
		'inSettings'   => __( 'Staat in Site-instellingen', 'webwerckt-base' ),
		'addItem'      => __( 'Zoek om toe te voegen', 'webwerckt-base' ),
		'noItems'      => __( 'Nog niets gekozen.', 'webwerckt-base' ),
		'noMatches'    => __( 'Niets gevonden.', 'webwerckt-base' ),
		'untitled'     => __( '(geen titel)', 'webwerckt-base' ),
		'notPublished' => __( 'niet gepubliceerd', 'webwerckt-base' ),
		'moveUp'       => __( 'Omhoog', 'webwerckt-base' ),
		'moveDown'     => __( 'Omlaag', 'webwerckt-base' ),
		'removeItem'   => __( 'Weghalen', 'webwerckt-base' ),
		'afterSave'    => __( 'In de pagina zichtbaar na opslaan.', 'webwerckt-base' ),
	);
}

/*
 * Opslaan.
 */

/**
 * Fout voor een pagina die niet (meer) bestaat.
 */
function _ww_editor_not_found(): WP_Error {
	return new WP_Error( 'ww_editor_post', __( 'Pagina niet gevonden.', 'webwerckt-base' ), array( 'status' => 404 ) );
}

/**
 * Registreert POST ww/v1/editor/{id}: velden, titel en slug opslaan, en eventueel publiceren. Status '' bewaart
 * de pagina zoals hij is (concept of gepubliceerd), 'publish' publiceert een concept.
 */
function _ww_editor_register_route(): void {
	$schema_arg = array(
		'validate_callback' => 'rest_validate_request_arg',
		'sanitize_callback' => 'rest_sanitize_request_arg',
	);

	register_rest_route(
		'ww/v1',
		'/editor/(?P<id>\d+)',
		array(
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => '_ww_editor_save',
			'permission_callback' => '_ww_editor_can_save',
			'args'                => array(
				'id'     => $schema_arg + array( 'type' => 'integer' ),
				'fields' => $schema_arg + array(
					'type'    => 'object',
					'default' => array(),
				),
				'post'   => $schema_arg + array(
					'type'                 => 'object',
					'default'              => array(),
					'properties'           => array(
						'post_title' => array(
							'type'      => 'string',
							'maxLength' => 1000,
						),
						'post_name'  => array(
							'type'      => 'string',
							'maxLength' => 200,
						),
					),
					'additionalProperties' => false,
				),
				'status' => $schema_arg + array(
					'type'    => 'string',
					'enum'    => array( '', 'publish' ),
					'default' => '',
				),
			),
		)
	);

	register_rest_route(
		'ww/v1',
		'/editor/(?P<id>\d+)/items',
		array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => '_ww_editor_items',
			'permission_callback' => '_ww_editor_can_save',
			'args'                => array(
				'id'     => $schema_arg + array( 'type' => 'integer' ),
				'field'  => $schema_arg + array(
					'type'     => 'string',
					'required' => true,
				),
				'search' => $schema_arg + array(
					'type'      => 'string',
					'maxLength' => 200,
					'default'   => '',
				),
			),
		)
	);
}
add_action( 'rest_api_init', '_ww_editor_register_route' );

/**
 * GET ww/v1/editor/{id}/items: berichten om aan een relatieveld van de pagina toe te voegen, van het post type van
 * dat veld. Zonder zoekterm de eerste op titel. Wie berichten van dat type niet mag bewerken, ziet alleen wat
 * gepubliceerd is. Een eigen route, omdat de zoekroute van WordPress alleen publieke post types kent.
 *
 * @return array<int,array<string,mixed>>|WP_Error
 */
function _ww_editor_items( WP_REST_Request $request ) {
	$post = get_post( (int) $request->get_param( 'id' ) );
	if ( ! $post instanceof WP_Post ) {
		return _ww_editor_not_found();
	}
	$field = _ww_abilities_post_fields( $post )[ (string) $request->get_param( 'field' ) ] ?? null;
	$type  = is_array( $field ) && 'pick' === ( $field['type'] ?? '' ) && 'post_type' === ( $field['pick_object'] ?? '' )
		? get_post_type_object( _ww_data_to_string( $field['pick_val'] ?? '' ) )
		: null;
	if ( ! $type instanceof WP_Post_Type ) {
		return new WP_Error( 'ww_editor_field', __( 'Dit veld is geen relatie van deze pagina.', 'webwerckt-base' ), array( 'status' => 400 ) );
	}

	$search = sanitize_text_field( (string) $request->get_param( 'search' ) );
	$query  = new WP_Query(
		array(
			'post_type'           => $type->name,
			'post_status'         => current_user_can( $type->cap->edit_posts ) ? array( 'publish', 'future', 'draft', 'pending', 'private' ) : 'publish',
			'perm'                => 'readable',
			's'                   => $search,
			'orderby'             => '' === $search ? 'title' : 'relevance',
			'order'               => 'ASC',
			'posts_per_page'      => 20,
			'no_found_rows'       => true,
			'ignore_sticky_posts' => true,
		)
	);
	return array_values( array_map( '_ww_editor_item', array_filter( $query->posts, static fn( $item ): bool => $item instanceof WP_Post ) ) );
}

/**
 * Mag de gebruiker deze pagina visueel bewerken? De nonce van de REST API (X-WP-Nonce) logt hem in.
 */
function _ww_editor_can_save( WP_REST_Request $request ): bool {
	$post = get_post( (int) $request->get_param( 'id' ) );
	return $post instanceof WP_Post && _ww_editor_can_edit( $post );
}

/**
 * Slaat de wijzigingen op zoals "Bijwerken" in de admin: velden via Pods (gecontroleerd zoals bij de abilities),
 * daarna titel, slug en status met wp_update_post(), dus één revisie, de kopie naar post_content en het legen van
 * de cache. Geeft de nieuwe gegevens van de pagina, of een fout.
 *
 * @return array<string,mixed>|WP_Error
 */
function _ww_editor_save( WP_REST_Request $request ) {
	$post = get_post( (int) $request->get_param( 'id' ) );
	if ( ! $post instanceof WP_Post ) {
		return _ww_editor_not_found();
	}
	$update = _ww_editor_post_update( $post, (array) $request->get_param( 'post' ), (string) $request->get_param( 'status' ) );
	if ( is_wp_error( $update ) ) {
		return $update;
	}
	$fields = _ww_abilities_input_fields( $request->get_param( 'fields' ), _ww_abilities_post_fields( $post ) );
	if ( is_wp_error( $fields ) ) {
		return $fields;
	}
	if ( array() !== $fields ) {
		$error = _ww_abilities_pods_save( $post->post_type, $post->ID, $fields );
		if ( null !== $error ) {
			return $error;
		}
	}

	$result = _ww_update_post( $update );
	if ( is_wp_error( $result ) ) {
		return $result;
	}
	// De vergrendeling staat in de admin-include, die de REST API niet laadt.
	require_once ABSPATH . 'wp-admin/includes/post.php';
	wp_set_post_lock( $post->ID );
	$post = get_post( $post->ID );
	return $post instanceof WP_Post ? _ww_editor_data( $post ) : _ww_editor_not_found();
}

/**
 * Gegevens voor wp_update_post(): titel, slug en status, of een fout. Publiceren vraagt het recht daarvoor.
 *
 * Alles wat wp_update_post() zou weigeren, wordt hier al geweigerd: de velden zijn dan nog niet opgeslagen, zodat
 * een fout nooit half opslaat. Een lege titel is zo'n fout, want een pagina zonder titel en tekst slaat WordPress
 * niet op.
 *
 * @param array<string,mixed> $input  post_title en post_name.
 * @param string              $status '' of 'publish'.
 * @return array<string,mixed>|WP_Error
 */
function _ww_editor_post_update( WP_Post $post, array $input, string $status ) {
	$publish = 'publish' === $status && ! _ww_editor_is_published( $post );
	if ( $publish && ! _ww_editor_can_publish( $post ) ) {
		return new WP_Error( 'ww_editor_status', __( 'Je mag deze pagina niet publiceren.', 'webwerckt-base' ), array( 'status' => 403 ) );
	}

	$update = array( 'ID' => $post->ID );
	if ( isset( $input['post_title'] ) ) {
		$update['post_title'] = sanitize_text_field( _ww_data_to_string( $input['post_title'] ) );
		if ( '' === $update['post_title'] ) {
			return new WP_Error( 'ww_editor_title', __( 'Geef de pagina een titel.', 'webwerckt-base' ), array( 'status' => 400 ) );
		}
	}
	if ( isset( $input['post_name'] ) ) {
		$update['post_name'] = sanitize_title( _ww_data_to_string( $input['post_name'] ) );
	}
	if ( $publish ) {
		$update['post_status'] = 'publish';
	}
	return $update;
}
