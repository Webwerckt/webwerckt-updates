<?php
/**
 * REST-endpoint voor meer laden: GET /wp-json/ww/v1/cards.
 *
 * Publieke GET zonder nonce (een nonce verloopt in pagina's uit de cache).
 * Geeft alleen publieke items van post types die via ww_register_archive() zijn aangemeld.
 * Met een vertaalplugin geeft het de kaarten in de taal van de pagina (zie _ww_cards_endpoint()).
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Grenzen aan publieke invoer, zodat elke combinatie een redelijke query en cache-item blijft.
const WW_REST_MAX_PAGE = 1000;
const WW_REST_MAX_TAX  = 3;

/**
 * Registreert de route. Alle argumenten worden tegen hun schema gevalideerd (type, grenzen),
 * zodat verkeerde invoer een 400 geeft en nooit de code in gaat.
 */
function _ww_register_rest_routes(): void {
	$schema_arg = array(
		'validate_callback' => 'rest_validate_request_arg',
		'sanitize_callback' => 'rest_sanitize_request_arg',
	);

	register_rest_route(
		'ww/v1',
		'/cards',
		array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => '_ww_rest_cards',
			'permission_callback' => '__return_true',
			'args'                => array(
				'post_type' => $schema_arg + array(
					'type'     => 'string',
					'required' => true,
					'pattern'  => '^[a-z0-9_-]{1,20}$',
				),
				'page'      => $schema_arg + array(
					'type'    => 'integer',
					'default' => 2,
					'minimum' => 1,
					'maximum' => WW_REST_MAX_PAGE,
				),
				'tax'       => $schema_arg + array(
					'type'                 => 'object',
					'default'              => array(),
					'maxProperties'        => WW_REST_MAX_TAX,
					'additionalProperties' => array(
						'type'      => 'string',
						'maxLength' => 200,
					),
				),
				'lang'      => $schema_arg + array(
					'type'    => 'string',
					'pattern' => '^[a-z0-9_-]{2,20}$',
				),
			),
		)
	);
}
add_action( 'rest_api_init', '_ww_register_rest_routes' );

/**
 * URL van het kaarten-endpoint voor de scripts, met de taal van de pagina, zodat meer laden en filteren
 * kaarten in die taal geven. WPML en Polylang krijgen hem als ?lang=; TranslatePress zet de taal al in
 * de URL zelf (/en/wp-json/...). Elke taal heeft zo een eigen URL, ook in de cache.
 */
function _ww_cards_endpoint(): string {
	$lang = _ww_current_language();
	$url  = rest_url( 'ww/v1/cards' );
	return '' === $lang ? $url : add_query_arg( 'lang', $lang, $url );
}

/**
 * Geeft de kaarten van één pagina terug als `{ html, has_more, next_url, total }`.
 *
 * next_url is de gewone URL van de volgende pagina met hetzelfde filter (of ''), voor de href
 * van de meer-laden-knop; total is het aantal items met dit filter.
 *
 * @param WP_REST_Request $request Verzoek.
 * @return WP_REST_Response|WP_Error
 */
function _ww_rest_cards( WP_REST_Request $request ) {
	$lang = (string) $request->get_param( 'lang' );
	if ( '' !== $lang ) {
		// WPML zet hiermee de taal van de query's en links; Polylang leest ?lang= in REST zelf en kent deze actie ook.
		do_action( 'wpml_switch_language', $lang );
	}

	$post_type = (string) $request->get_param( 'post_type' );
	$config    = _ww_archive_config( $post_type );
	$object    = get_post_type_object( $post_type );

	if ( array() === $config || ! $object || ! $object->public ) {
		return new WP_Error( 'ww_invalid_post_type', __( 'Onbekend post type.', 'webwerckt-base' ), array( 'status' => 404 ) );
	}

	$page = max( 1, (int) $request->get_param( 'page' ) );
	// Alleen publieke taxonomieën: anders verraadt het endpoint welke items in een interne term zitten.
	$tax    = array_filter(
		(array) $request->get_param( 'tax' ),
		static fn( $taxonomy ) => null !== _ww_public_taxonomy( (string) $taxonomy ),
		ARRAY_FILTER_USE_KEY
	);
	$result = _ww_query_ids(
		$post_type,
		array(
			'limit'   => $config['per_page'],
			'paged'   => $page,
			'tax'     => $tax,
			'orderby' => $config['orderby'],
			'order'   => $config['order'],
			// De taal zoals de vertaalplugin hem heeft vastgesteld (een onbekende code wordt de standaardtaal).
			'lang'    => _ww_current_language(),
		)
	);
	$has_more = $page < $result['max_pages'];
	_ww_prime_thumbnails( $result['ids'] );

	// Cachebaar, ook als "Cache REST API" in LiteSpeed uit staat: het antwoord is publiek en draagt de tags van het post type.
	do_action( 'litespeed_control_set_cacheable', 'ww/v1/cards' );

	return rest_ensure_response(
		array(
			'html'     => implode( '', array_map( '_ww_card_html', $result['ids'] ) ),
			'has_more' => $has_more,
			'next_url' => $has_more ? esc_url_raw( ww_paged_url( ww_filter_url( $post_type, $tax ), $page + 1 ) ) : '',
			'total'    => $result['total'],
		)
	);
}
