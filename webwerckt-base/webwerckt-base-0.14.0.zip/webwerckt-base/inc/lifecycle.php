<?php
/**
 * Levenscyclus van de thema's: wat er moet gebeuren na een deploy of update, en of parent en child bij elkaar passen.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Springt de vingerafdruk binnen deze tijd terug naar de vorige, dan is dat geen deploy maar een registratie die per request verschilt.
const WW_REWRITE_FLAP_WINDOW = 10 * MINUTE_IN_SECONDS;

/**
 * Vingerafdruk van alles wat de rewrite rules bepaalt: de versies van parent en child en de URL's
 * van alle post types en taxonomieën (ook die van het child-thema, van plugins en van register_post_type_args).
 */
function _ww_rewrite_fingerprint(): string {
	$theme = wp_get_theme();
	$urls  = array();
	foreach ( get_post_types( array(), 'objects' ) as $name => $object ) {
		if ( false !== $object->rewrite ) {
			$urls[ 'post_type:' . $name ] = array( $object->rewrite['slug'] ?? $name, $object->has_archive );
		}
	}
	foreach ( get_taxonomies( array(), 'objects' ) as $name => $object ) {
		if ( false !== $object->rewrite ) {
			$urls[ 'taxonomy:' . $name ] = $object->rewrite['slug'] ?? $name;
		}
	}
	ksort( $urls );

	return md5( (string) wp_json_encode( array( WW_BASE_VERSION, $theme->get_stylesheet(), $theme->get( 'Version' ), $urls ) ) );
}

/**
 * Opgeslagen vingerafdruk: de huidige, de vorige en wanneer hij voor het laatst veranderde.
 * Versie 0.3.0 en ouder bewaarden alleen de huidige, als string.
 *
 * @return array{current:string,previous:string,time:int}
 */
function _ww_stored_fingerprint(): array {
	$stored = get_option( 'ww_rewrite_fingerprint' );
	if ( ! is_array( $stored ) ) {
		$stored = array( 'current' => $stored );
	}
	return array(
		'current'  => _ww_data_to_string( $stored['current'] ?? '' ),
		'previous' => _ww_data_to_string( $stored['previous'] ?? '' ),
		'time'     => (int) ( $stored['time'] ?? 0 ),
	);
}

/**
 * Na een deploy of update (de vingerafdruk is veranderd): cache leeg en rewrite rules verversen.
 * Zo werkt een nieuwe URL ook als een deploy het versienummer van het child-thema vergeet.
 * Niet tijdens een themavoorbeeld in de Customizer: daar is tijdelijk een ander thema actief.
 *
 * Springt de vingerafdruk kort na een wijziging terug naar de vorige, dan verschillen de URL's per request
 * (bijvoorbeeld een plugin die een post type alleen in de admin registreert). Dan gebeurt er niets tot
 * WW_REWRITE_FLAP_WINDOW voorbij is: elke keer legen zou de cache nooit warm laten worden.
 */
function _ww_check_rewrite_fingerprint(): void {
	if ( is_customize_preview() ) {
		return;
	}

	$current = _ww_rewrite_fingerprint();
	$stored  = _ww_stored_fingerprint();
	if ( $stored['current'] === $current ) {
		return;
	}
	if ( $stored['previous'] === $current && time() - $stored['time'] < WW_REWRITE_FLAP_WINDOW ) {
		_doing_it_wrong(
			__FUNCTION__,
			esc_html( 'De post types of taxonomieën verschillen per request, bijvoorbeeld door een plugin die ze alleen in de admin registreert. De cache wordt daarom hooguit eens per 10 minuten geleegd.' ),
			'0.4.0'
		);
		return;
	}

	$stored = array(
		'current'  => $current,
		'previous' => $stored['current'],
		'time'     => time(),
	);
	update_option( 'ww_rewrite_fingerprint', $stored, true );
	_ww_cache_purge_all();
	flush_rewrite_rules( false );
}
add_action( 'wp_loaded', '_ww_check_rewrite_fingerprint' );

/**
 * Minimale parent-versie die het child-thema vraagt met `define( 'WW_REQUIRES_BASE', '1.3.0' );`
 * bovenaan zijn functions.php, of '' als het niets vraagt of de waarde geen versie is.
 */
function _ww_required_base_version(): string {
	$required = defined( 'WW_REQUIRES_BASE' ) ? _ww_data_to_string( constant( 'WW_REQUIRES_BASE' ) ) : '';
	return 1 === preg_match( '/^\d+\.\d+\.\d+$/', $required ) ? $required : '';
}

/**
 * Melding voor de beheerder als de parent ouder is dan het child-thema vraagt, of '' als alles klopt.
 * Staat de update al klaar, dan met een knop om meteen bij te werken.
 *
 * @param string $required Gevraagde versie.
 * @param string $current  Geïnstalleerde versie van de parent.
 * @param bool   $can_update Staat er een update van de parent klaar?
 */
function _ww_requires_base_message( string $required, string $current, bool $can_update ): string {
	if ( '' === $required || version_compare( $current, $required, '>=' ) ) {
		return '';
	}

	$text = sprintf(
		/* translators: 1: gevraagde versie, 2: geïnstalleerde versie. */
		__( 'Dit child-thema heeft Webwerckt Base %1$s of nieuwer nodig, maar %2$s is geïnstalleerd. Onderdelen van de site kunnen fouten geven tot de parent is bijgewerkt.', 'webwerckt-base' ),
		$required,
		$current
	);
	$action = $can_update
		? sprintf(
			'<a class="button button-primary" href="%s">%s</a>',
			esc_url( wp_nonce_url( self_admin_url( 'update.php?action=upgrade-theme&theme=' . WW_BASE_SLUG ), 'upgrade-theme_' . WW_BASE_SLUG ) ),
			esc_html__( 'Webwerckt Base nu bijwerken', 'webwerckt-base' )
		)
		: esc_html__( 'Er staat nog geen nieuwere versie klaar op het updatedomein.', 'webwerckt-base' );

	return sprintf( '<div class="notice notice-error"><p>%s</p><p>%s</p></div>', esc_html( $text ), $action );
}

/**
 * Toont de melding in de admin. Vraagt het child-thema een nieuwere parent, dan kijkt WordPress
 * hooguit eens per uur opnieuw naar updates, zodat een net uitgebrachte versie meteen te installeren is.
 */
function _ww_requires_base_notice(): void {
	$required = _ww_required_base_version();
	if ( '' === $required || version_compare( WW_BASE_VERSION, $required, '>=' ) || ! current_user_can( 'update_themes' ) ) {
		return;
	}

	if ( false === get_site_transient( 'ww_requires_base_check' ) ) {
		set_site_transient( 'ww_requires_base_check', 1, HOUR_IN_SECONDS );
		_ww_updater_reset();
		wp_update_themes();
	}

	$updates = get_site_transient( 'update_themes' );
	$ready   = is_object( $updates ) && isset( $updates->response[ WW_BASE_SLUG ] );
	echo _ww_requires_base_message( $required, WW_BASE_VERSION, $ready ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- ge-escaped in _ww_requires_base_message().
}
add_action( 'admin_notices', '_ww_requires_base_notice' );
