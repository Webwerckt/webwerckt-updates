<?php
/**
 * Menu's: de items van een WordPress-menu als geneste arrays, zodat het child-thema alleen HTML schrijft (regel 67).
 * Het child-thema registreert zijn menulocaties zelf met register_nav_menus().
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Items van het menu op een menulocatie, als boom. Zonder menu op die locatie: array().
 *
 * Elk item is een array met id, title (ge-escaped), url (ge-escaped), attrs (ge-escaped: `aria-current="page"`
 * op het huidige item, target en rel bij "in nieuw tabblad openen", title), classes (de CSS-klassen uit het
 * menuscherm, ge-escaped), current, ancestor (een dieper item is het huidige) en children (dezelfde vorm):
 *
 *     <a href="<?php echo $item['url']; ?>" <?php echo $item['attrs']; ?>><?php echo $item['title']; ?></a>
 *
 * @param string $location Menulocatie uit register_nav_menus().
 * @return array<int,array<string,mixed>>
 */
function ww_menu( string $location ): array {
	if ( ! isset( get_registered_nav_menus()[ $location ] ) ) {
		_doing_it_wrong(
			'ww_menu',
			esc_html( sprintf( 'De menulocatie %s bestaat niet; registreer hem met register_nav_menus() in het child-thema.', $location ) ),
			'0.5.0'
		);
		return array();
	}

	$menus = get_nav_menu_locations();
	$items = empty( $menus[ $location ] ) ? false : wp_get_nav_menu_items( $menus[ $location ], array( 'update_post_term_cache' => false ) );
	if ( ! is_array( $items ) || array() === $items ) {
		return array();
	}

	_ww_cache_tag( 'nav_menu_item' );

	// De eigen klassen bewaren: WordPress voegt er hieronder current-menu-item en dergelijke aan toe.
	$classes = array();
	foreach ( $items as $item ) {
		$classes[ $item->ID ] = esc_attr( implode( ' ', array_filter( (array) $item->classes ) ) );
	}
	// Zelfde bepaling van het huidige item en zijn voorouders als wp_nav_menu(), ook voor archieven en de homepage.
	_wp_menu_item_classes_by_context( $items );

	$ids      = wp_list_pluck( $items, 'ID' );
	$branches = array();
	foreach ( $items as $item ) {
		$parent = (int) $item->menu_item_parent;
		// Een item waarvan de ouder niet (meer) zichtbaar is, komt op het hoogste niveau, net als in wp_nav_menu().
		$branches[ in_array( $parent, $ids, true ) ? $parent : 0 ][] = _ww_menu_item( $item, $classes[ $item->ID ] );
	}
	return _ww_menu_branch( $branches, 0 );
}

/**
 * Een menu-item als array, nog zonder kinderen.
 *
 * @param object{ID:int,title:string,url:string,target:string,xfn:string,attr_title:string,current?:bool,current_item_ancestor?:bool} $item
 *        Menu-item uit wp_get_nav_menu_items(), na _wp_menu_item_classes_by_context().
 * @param string $classes Ge-escapete eigen klassen.
 * @return array<string,mixed>
 */
function _ww_menu_item( object $item, string $classes ): array {
	$current = ! empty( $item->current );
	return array(
		'id'       => (int) $item->ID,
		'title'    => esc_html( $item->title ),
		'url'      => esc_url( $item->url ),
		'attrs'    => _ww_menu_link_attrs( $current, $item->target, $item->xfn, $item->attr_title ),
		'classes'  => $classes,
		'current'  => $current,
		'ancestor' => ! empty( $item->current_item_ancestor ),
		'children' => array(),
	);
}

/**
 * De items onder één ouder, met hun kinderen. Begint bij 0, dus een kring van ouders wordt nooit bereikt.
 *
 * @param array<int,array<int,array<string,mixed>>> $branches Items per ID van hun ouder.
 * @return array<int,array<string,mixed>>
 */
function _ww_menu_branch( array $branches, int $parent ): array {
	$out = array();
	foreach ( $branches[ $parent ] ?? array() as $item ) {
		$item['children'] = _ww_menu_branch( $branches, (int) $item['id'] );
		$out[]            = $item;
	}
	return $out;
}

/**
 * Ge-escapete attributen van de link van een menu-item.
 *
 * @param bool   $current Het huidige item.
 * @param string $target  '_blank' bij "in nieuw tabblad openen".
 * @param string $xfn     Linkrelatie uit het menuscherm.
 * @param string $title   Titelattribuut uit het menuscherm.
 */
function _ww_menu_link_attrs( bool $current, string $target, string $xfn, string $title ): string {
	$attrs  = array();
	$is_new = '_blank' === $target;
	$rel    = trim( $xfn . ( $is_new ? ' noopener' : '' ) );

	if ( $current ) {
		$attrs[] = 'aria-current="page"';
	}
	if ( $is_new ) {
		$attrs[] = 'target="_blank"';
	}
	if ( '' !== $rel ) {
		$attrs[] = sprintf( 'rel="%s"', esc_attr( $rel ) );
	}
	if ( '' !== $title ) {
		$attrs[] = sprintf( 'title="%s"', esc_attr( $title ) );
	}
	return implode( ' ', $attrs );
}
