<?php
/**
 * Plugin Name: Webwerckt Base: frontend zonder Pods
 * Description: Laadt Pods niet voor bezoekers op de frontend: het thema webwerckt-base leest velden zonder Pods. Het thema installeert en ververst dit bestand zelf; aanpassen heeft geen zin.
 *
 * Pods is alleen de invoerlaag in de admin (beslissing 0003). Op de frontend kost het toch zo'n 18 query's en een
 * deel van init, ook als de pagina daarna niets van Pods gebruikt. Een thema laadt pas na de plugins, daarom staat
 * deze keuze in een mu-plugin. Pods blijft geladen in de admin, bij AJAX, cron, WP-CLI, XML-RPC, de REST API
 * (behalve het endpoint ww/v1 van meer laden), bij elk verzoek dat geen GET of HEAD is en voor ingelogde gebruikers.
 *
 * Gebruikt het child-thema Pods toch op de frontend, zet dan in wp-config.php: define( 'WW_FRONTEND_PODS', true );
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Is dit een verzoek van een bezoeker op de frontend van webwerckt-base, waarvoor Pods niet hoeft te laden?
 */
function _ww_frontend_without_pods(): bool {
	if ( ( defined( 'WW_FRONTEND_PODS' ) && WW_FRONTEND_PODS ) || 'webwerckt-base' !== get_template() ) {
		return false;
	}
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'WP_CLI' ) && WP_CLI ) || ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) ) {
		return false;
	}
	if ( defined( 'LOGGED_IN_COOKIE' ) && isset( $_COOKIE[ LOGGED_IN_COOKIE ] ) ) {
		return false;
	}
	$method = strtoupper( (string) ( $_SERVER['REQUEST_METHOD'] ?? 'GET' ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	if ( 'GET' !== $method && 'HEAD' !== $method ) {
		return false;
	}
	if ( 'wp-login.php' === ( $GLOBALS['pagenow'] ?? '' ) ) {
		return false;
	}

	// De REST API houdt Pods (velden in de editor, apps), behalve het eigen endpoint van meer laden.
	$route = isset( $_GET['rest_route'] ) ? '/' . ltrim( (string) $_GET['rest_route'], '/' ) : null; // phpcs:ignore WordPress.Security
	if ( null === $route ) {
		$path   = (string) wp_parse_url( (string) ( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$prefix = '/' . trim( rest_get_url_prefix(), '/' );
		$at     = strpos( $path . '/', $prefix . '/' );
		$route  = false === $at ? null : '/' . ltrim( substr( $path, $at + strlen( $prefix ) ), '/' );
	}
	return null === $route || str_starts_with( $route, '/ww/v1/' );
}

/**
 * Haalt Pods uit de lijst met actieve plugins, alleen voor dit verzoek; de opgeslagen lijst blijft gelijk.
 *
 * @param mixed $plugins Actieve plugins (pad ten opzichte van de pluginmap).
 * @return mixed
 */
function _ww_skip_pods_on_frontend( mixed $plugins ): mixed {
	if ( ! is_array( $plugins ) || ! _ww_frontend_without_pods() ) {
		return $plugins;
	}
	return array_values( array_diff( $plugins, array( 'pods/init.php' ) ) );
}
add_filter( 'option_active_plugins', '_ww_skip_pods_on_frontend' );

/**
 * Slaat code tijdens dit verzoek de (gefilterde) lijst met actieve plugins op, dan blijft Pods erin staan.
 *
 * @param mixed $plugins Nieuwe lijst.
 * @return mixed
 */
function _ww_keep_pods_when_saving( mixed $plugins ): mixed {
	if ( ! is_array( $plugins ) || ! _ww_frontend_without_pods() || in_array( 'pods/init.php', $plugins, true ) ) {
		return $plugins;
	}
	remove_filter( 'option_active_plugins', '_ww_skip_pods_on_frontend' );
	$stored = get_option( 'active_plugins' );
	add_filter( 'option_active_plugins', '_ww_skip_pods_on_frontend' );
	if ( is_array( $stored ) && in_array( 'pods/init.php', $stored, true ) ) {
		$plugins[] = 'pods/init.php';
	}
	return $plugins;
}
add_filter( 'pre_update_option_active_plugins', '_ww_keep_pods_when_saving' );
