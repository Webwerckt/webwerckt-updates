<?php
/**
 * Activiteitenlog: de velden van een regel in groepen en het detail van één regel (beslissing 0033).
 *
 * Het detail is geëscapete HTML voor het venster (<dialog>) en voor de weergave zonder JavaScript. De velden komen in
 * vier groepen: Standaard, velden uit de configuratie van het type, categorieën en tags, en velden zonder label. Alleen de namen van
 * de velden worden bewaard, nooit wat erin stond.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * De vaste labels van de velden van een bericht, een bijlage of een formulier.
 *
 * @return array<string,string>
 */
function _ww_activity_std_field_labels(): array {
	return array(
		'post_title'     => __( 'Titel', 'webwerckt-base' ),
		'post_name'      => __( 'Slug', 'webwerckt-base' ),
		'post_excerpt'   => __( 'Samenvatting', 'webwerckt-base' ),
		'post_content'   => __( 'Inhoud', 'webwerckt-base' ),
		'featured_image' => __( 'Uitgelichte afbeelding', 'webwerckt-base' ),
		'page_template'  => __( 'Paginatemplate', 'webwerckt-base' ),
		'form_config'    => __( 'Formulier', 'webwerckt-base' ),
		'alt'            => __( 'Alt-tekst', 'webwerckt-base' ),
		'post_date'      => __( 'Publicatiedatum', 'webwerckt-base' ),
		'post_parent'    => __( 'Hoofdpagina', 'webwerckt-base' ),
		'menu_order'     => __( 'Volgorde', 'webwerckt-base' ),
		'post_password'  => __( 'Wachtwoord', 'webwerckt-base' ),
	);
}

/**
 * De velden van een regel in groepen, in de volgorde std, pods, tax en other. Alleen groepen met velden. De labels
 * komen uit de vaste lijst, uit de Pods-configuratie, uit een bestaande taxonomie of zijn de sleutel zelf.
 *
 * @param object $row Regel uit de tabel.
 * @return array<string,list<array{key:string,label:string}>>
 */
function _ww_activity_field_groups( object $row ): array {
	$keys = json_decode( _ww_data_to_string( $row->fields ?? '' ), true );
	if ( ! is_array( $keys ) ) {
		return array();
	}

	$type    = _ww_data_to_string( $row->object_type ?? '' );
	$subtype = _ww_data_to_string( $row->object_subtype ?? '' );
	$std     = _ww_activity_std_field_labels();

	$pods = array();
	if ( 'post' === $type && '' !== $subtype ) {
		$pods = _ww_pods_fields( $subtype, max( 0, (int) ( $row->object_id ?? 0 ) ) );
	} elseif ( 'settings' === $type ) {
		$pods = _ww_pods_setting_fields();
	}
	$pod_labels = array();
	foreach ( $pods as $field ) {
		$name  = _ww_data_to_string( $field['name'] ?? '' );
		$label = _ww_data_to_string( $field['label'] ?? '' );
		if ( '' !== $name && '' !== $label && ! isset( $pod_labels[ $name ] ) ) {
			$pod_labels[ $name ] = $label;
		}
	}

	$groups = array(
		'std'   => array(),
		'pods'  => array(),
		'tax'   => array(),
		'other' => array(),
	);
	foreach ( $keys as $key ) {
		$key      = _ww_data_to_string( $key );
		$taxonomy = taxonomy_exists( $key ) ? get_taxonomy( $key ) : null;
		if ( isset( $std[ $key ] ) ) {
			$groups['std'][] = array(
				'key'   => $key,
				'label' => $std[ $key ],
			);
		} elseif ( isset( $pod_labels[ $key ] ) ) {
			$groups['pods'][] = array(
				'key'   => $key,
				'label' => $pod_labels[ $key ],
			);
		} elseif ( $taxonomy instanceof WP_Taxonomy ) {
			$groups['tax'][] = array(
				'key'   => $key,
				'label' => (string) $taxonomy->labels->singular_name,
			);
		} else {
			$groups['other'][] = array(
				'key'   => $key,
				'label' => $key,
			);
		}
	}
	return array_filter( $groups );
}

/**
 * De labels van alle velden van een regel, groep na groep.
 *
 * @param object                                                 $row    Regel uit de tabel.
 * @param array<string,list<array{key:string,label:string}>>|null $groups Uitkomst van _ww_activity_field_groups() voor deze regel, of null.
 * @return string[]
 */
function _ww_activity_field_labels( object $row, ?array $groups = null ): array {
	$labels = array();
	foreach ( $groups ?? _ww_activity_field_groups( $row ) as $fields ) {
		foreach ( $fields as $field ) {
			$labels[] = $field['label'];
		}
	}
	return $labels;
}

/**
 * Waarom een regel geen velden heeft, in gewone woorden.
 *
 * @param object $row Regel uit de tabel.
 */
function _ww_activity_empty_reason( object $row ): string {
	$type   = _ww_data_to_string( $row->object_type ?? '' );
	$action = _ww_data_to_string( $row->action ?? '' );
	if ( 'option' === $type ) {
		return __( 'Een WordPress-instelling heeft geen losse velden: de hele instelling is in één keer gewijzigd.', 'webwerckt-base' );
	}
	if ( 'bulk' === $type ) {
		return __( 'Er veranderde te veel tegelijk om elke wijziging apart te bewaren. Deze regel telt de rest van die batch.', 'webwerckt-base' );
	}
	if ( 'menu' === $type ) {
		return __( 'Bij een menu wordt bewaard dát het menu wijzigde, niet welke items.', 'webwerckt-base' );
	}
	if ( 'imported' === $action ) {
		return __( 'Een import staat als één regel in het log, voor de hele lijst tegelijk.', 'webwerckt-base' );
	}
	if ( 'uploaded' === $action ) {
		return __( 'Bij een upload worden geen velden bewaard. Pas je daarna de alt-tekst of titel aan, dan zie je dat als eigen regel.', 'webwerckt-base' );
	}
	return __( 'Bij deze actie verandert alleen de status van het item, niet de inhoud. Er zijn geen velden bewaard.', 'webwerckt-base' );
}

/**
 * De kleur van het actielabel: good, warn, bad of '' (neutraal).
 *
 * @param string $action Actie van de regel.
 */
function _ww_activity_action_class( string $action ): string {
	switch ( $action ) {
		case 'created':
		case 'duplicated':
		case 'published':
		case 'restored':
		case 'uploaded':
		case 'imported':
			return 'good';
		case 'unpublished':
			return 'warn';
		case 'trashed':
		case 'deleted':
			return 'bad';
	}
	return '';
}

/**
 * De titel van het venster: "{Actielabel}: {titel}" (niet geëscaped).
 *
 * @param object $row Regel uit de tabel.
 */
function _ww_activity_entry_title( object $row ): string {
	$title = trim( _ww_data_to_string( $row->object_title ?? '' ) );
	return _ww_activity_action_label( _ww_data_to_string( $row->action ?? '' ) ) . ': ' . ( '' !== $title ? $title : __( '(zonder titel)', 'webwerckt-base' ) );
}

/**
 * Het detail van één regel als geëscapete HTML: feiten, velden of de reden dat er geen zijn, een opmerking en acties.
 *
 * @param object                                                                                         $row    Regel uit de tabel.
 * @param array{actor:string,user:int,type:string,object:string,s:string,paged:int,period:int,entry:int} $args   Uit _ww_activity_query_args().
 * @param array<string,int>|null                                                                         $counts Aantallen per soort:id uit _ww_activity_object_counts(), of null om zelf te tellen.
 * @param string|null                                                                                    $link   Uitkomst van _ww_activity_object_link() voor deze regel, of null.
 * @param array<string,list<array{key:string,label:string}>>|null                                        $groups Uitkomst van _ww_activity_field_groups() voor deze regel, of null.
 */
function _ww_activity_entry_detail( object $row, array $args, ?array $counts = null, ?string $link = null, ?array $groups = null ): string {
	global $wpdb;

	$type    = _ww_data_to_string( $row->object_type ?? '' );
	$subtype = _ww_data_to_string( $row->object_subtype ?? '' );
	$action  = _ww_data_to_string( $row->action ?? '' );
	$actor   = _ww_data_to_string( $row->actor ?? '' );
	$id      = max( 0, (int) ( $row->object_id ?? 0 ) );

	// Feiten.
	$time = strtotime( _ww_data_to_string( $row->created ?? '' ) . ' UTC' );
	$when = '&mdash;';
	if ( false !== $time ) {
		$ago  = sprintf(
			/* translators: %s: tijdsduur, zoals 5 minuten. */
			__( '%s geleden', 'webwerckt-base' ),
			human_time_diff( $time )
		);
		$when = esc_html( wp_date( 'j M Y, H:i', $time ) ) . '<small>' . esc_html( $ago ) . '</small>';
	}
	$user_name = _ww_activity_user_label( $row );
	if ( 'agent' === $actor ) {
		$name = _ww_activity_who_name( $row );
		$how  = '' !== $user_name
			? sprintf(
				/* translators: %s: naam van de gebruiker wiens applicatiewachtwoord de agent gebruikt. */
				__( 'Agent, met het applicatiewachtwoord van %s', 'webwerckt-base' ),
				$user_name
			)
			: __( 'Agent, met een applicatiewachtwoord', 'webwerckt-base' );
	} elseif ( 'cli' === $actor ) {
		$name = __( 'WP-CLI', 'webwerckt-base' );
		$how  = __( 'Via de opdrachtregel op de server', 'webwerckt-base' );
	} else {
		$name = $user_name;
		$how  = __( 'Ingelogd in het beheer', 'webwerckt-base' );
	}
	$html = '<dl class="ww-activity-facts">'
		. '<div><dt>' . esc_html__( 'Wanneer', 'webwerckt-base' ) . '</dt><dd>' . $when . '</dd></div>'
		. '<div><dt>' . esc_html__( 'Wie', 'webwerckt-base' ) . '</dt><dd>' . ( '' !== $name ? esc_html( $name ) : '&mdash;' ) . '<small>' . esc_html( $how ) . '</small></dd></div>'
		. '<div><dt>' . esc_html__( 'Soort', 'webwerckt-base' ) . '</dt><dd>' . esc_html( _ww_activity_object_label( $row ) ) . '</dd></div>'
		. '</dl>';

	// Velden, of de reden dat er geen zijn.
	$groups = $groups ?? _ww_activity_field_groups( $row );
	$total  = 0;
	foreach ( $groups as $fields ) {
		$total += count( $fields );
	}
	if ( $total > 0 ) {
		if ( 'settings' === $type ) {
			$pages      = _ww_settings_pages();
			$pods_label = sprintf(
				/* translators: %s: naam van de pagina met site-instellingen. */
				__( 'Velden van %s', 'webwerckt-base' ),
				WW_SEO_SCREEN === $subtype ? 'llms.txt' : ( $pages[ $subtype ] ?? $subtype )
			);
		} else {
			$pods_label = sprintf(
				/* translators: %s: soort van het item, zoals Pagina. */
				__( 'Velden van %s', 'webwerckt-base' ),
				_ww_activity_object_label( $row )
			);
		}
		$group_labels = array(
			'std'   => __( 'Standaard', 'webwerckt-base' ),
			'pods'  => $pods_label,
			'tax'   => __( 'Categorieën en tags', 'webwerckt-base' ),
			'other' => __( 'Zonder label', 'webwerckt-base' ),
		);

		$html .= '<h3>' . esc_html(
			sprintf(
				/* translators: %d: aantal gewijzigde velden. */
				__( 'Gewijzigde velden (%d)', 'webwerckt-base' ),
				$total
			)
		) . '</h3>';
		if ( $total > 8 ) {
			$html .= '<input type="search" class="ww-activity-field-filter" data-ww-field-filter hidden placeholder="' . esc_attr__( 'Zoek een veld', 'webwerckt-base' ) . '" aria-label="' . esc_attr__( 'Zoek een veld', 'webwerckt-base' ) . '">';
		}
		foreach ( $groups as $group => $fields ) {
			$html .= '<div class="ww-activity-field-group"><h4>' . esc_html( $group_labels[ $group ] ) . ' <span>' . esc_html( (string) count( $fields ) ) . '</span></h4><ul class="ww-activity-fields">';
			foreach ( $fields as $field ) {
				$needle = mb_strtolower( $field['label'] . ' ' . $field['key'] );
				$html  .= '<li data-field="' . esc_attr( $needle ) . '">';
				if ( 'other' === $group ) {
					$html .= '<code>' . esc_html( $field['key'] ) . '</code>';
				} else {
					$html .= '<span>' . esc_html( $field['label'] ) . '</span><code>' . esc_html( $field['key'] ) . '</code>';
				}
				$html .= '</li>';
			}
			$html .= '</ul></div>';
		}
		$html .= '<p class="ww-activity-note description">' . esc_html__( 'Alleen de namen van de velden worden bewaard, niet wat erin stond. De technische naam staat er klein achter.', 'webwerckt-base' ) . '</p>';
	} else {
		$html .= '<p class="ww-activity-empty"><span class="dashicons dashicons-info-outline" aria-hidden="true"></span> ' . esc_html( _ww_activity_empty_reason( $row ) ) . '</p>';
	}

	// Acties.
	$actions = '';
	$link    = $link ?? _ww_activity_object_link( $row );
	if ( '' !== $link ) {
		$text     = 'settings' === $type
			? sprintf(
				/* translators: %s: naam van de pagina met site-instellingen. */
				__( 'Naar %s', 'webwerckt-base' ),
				_ww_data_to_string( $row->object_title ?? '' )
			)
			: sprintf(
				/* translators: %s: soort van het item, zoals Pagina. */
				__( '%s bewerken', 'webwerckt-base' ),
				_ww_activity_object_label( $row )
			);
		$actions .= '<a class="button button-primary" href="' . esc_url( $link ) . '">' . esc_html( $text ) . '</a>';
		if ( 'post' === $type && $id > 0 ) {
			$revisions = wp_get_post_revisions(
				$id,
				array(
					'fields'         => 'ids',
					'posts_per_page' => 1,
				)
			);
			if ( array() !== $revisions ) {
				$first    = (int) reset( $revisions );
				$actions .= '<a class="button" href="' . esc_url( admin_url( 'revision.php?revision=' . $first ) ) . '">' . esc_html__( 'Revisies vergelijken', 'webwerckt-base' ) . '</a>';
			}
		}
	} elseif ( ! in_array( $type, array( 'option', 'bulk' ), true ) && 'imported' !== $action ) {
		$actions .= '<span class="ww-activity-gone description">' . esc_html__( 'Dit item bestaat niet meer of ligt in de prullenbak.', 'webwerckt-base' ) . '</span>';
	}

	$object = $type . ':' . $id;
	if ( $id > 0 && $args['object'] !== $object && _ww_activity_ready() ) {
		if ( null !== $counts ) {
			$count = (int) ( $counts[ $object ] ?? 0 );
		} else {
			// Telt precies wat de link laat zien: dit item in de huidige periode, geen andere filters.
			$link_args = array_merge(
				_ww_activity_query_args( array() ),
				array(
					'object' => $object,
					'period' => $args['period'],
				)
			);
			list( $sql_where, $values ) = _ww_activity_admin_where( $link_args );
			$count_sql                  = 'SELECT COUNT(*) FROM ' . _ww_activity_table() . $sql_where;
			$count                      = (int) $wpdb->get_var( array() === $values ? $count_sql : $wpdb->prepare( $count_sql, $values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- tabelnaam uit _ww_activity_table(), de voorwaarden zijn vaste teksten met placeholders.
		}
		if ( $count > 1 ) {
			$url      = _ww_activity_admin_url(
				array(
					'object' => $object,
					'period' => (string) $args['period'],
				)
			);
			$actions .= '<a href="' . esc_url( $url ) . '">' . esc_html(
				sprintf(
					/* translators: %d: aantal regels van dit item in het log. */
					__( 'Alle activiteit van dit item (%d)', 'webwerckt-base' ),
					$count
				)
			) . '</a>';
		}
	}
	if ( '' !== $actions ) {
		$html .= '<p class="ww-activity-actions">' . $actions . '</p>';
	}
	return $html;
}

/**
 * Het lege venster voor het detail van een regel, één keer per pagina. activity-entries.js vult het uit de <template>
 * van de regel; zonder JavaScript blijft het dicht.
 */
function _ww_activity_entry_dialog(): string {
	return '<dialog class="ww-activity-dialog" id="ww-activity-entry-dialog" aria-labelledby="ww-activity-entry-dialog-title" data-pos-format="' . esc_attr(
		/* translators: 1: plaats van de regel op de pagina, 2: aantal regels op de pagina. */
		__( '%1$s van %2$s', 'webwerckt-base' )
	) . '">'
		. '<div class="ww-activity-dialog__head"><h2 id="ww-activity-entry-dialog-title"></h2>'
		. '<button type="button" class="ww-activity-dialog__close" data-ww-close aria-label="' . esc_attr__( 'Sluiten', 'webwerckt-base' ) . '"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></button></div>'
		. '<div class="ww-activity-dialog__body" data-ww-body></div>'
		. '<div class="ww-activity-dialog__foot"><button type="button" class="button" data-ww-prev>' . esc_html__( '‹ Nieuwer', 'webwerckt-base' ) . '</button>'
		. '<span data-ww-pos></span><button type="button" class="button" data-ww-next>' . esc_html__( 'Ouder ›', 'webwerckt-base' ) . '</button></div>'
		. '</dialog>';
}

/**
 * Het dagkopje boven de regels van één dag, in de tijdzone van de site (HTML, al geëscaped): "Vandaag <span>vrijdag
 * 14 november</span>", "Gisteren <span>…</span>" of "Dinsdag 11 november".
 *
 * @param string $created Moment uit de tabel (UTC, Y-m-d H:i:s).
 */
function _ww_activity_day_label( string $created ): string {
	$time = strtotime( $created . ' UTC' );
	if ( false === $time ) {
		return '';
	}
	$zone      = wp_timezone();
	$day       = wp_date( 'Y-m-d', $time, $zone );
	$today     = new DateTimeImmutable( 'today', $zone );
	$long      = (string) wp_date( 'l j F', $time, $zone );
	if ( $day === $today->format( 'Y-m-d' ) ) {
		return esc_html__( 'Vandaag', 'webwerckt-base' ) . ' <span>' . esc_html( mb_strtolower( $long ) ) . '</span>';
	}
	if ( $day === $today->modify( '-1 day' )->format( 'Y-m-d' ) ) {
		return esc_html__( 'Gisteren', 'webwerckt-base' ) . ' <span>' . esc_html( mb_strtolower( $long ) ) . '</span>';
	}
	return esc_html( mb_strtoupper( mb_substr( $long, 0, 1 ) ) . mb_substr( $long, 1 ) );
}

/**
 * De link naar het detail van één regel: het scherm met de huidige filters (zonder lege waarden, zonder paged) en
 * entry={id}.
 *
 * @param array{actor:string,user:int,type:string,object:string,s:string,paged:int,period:int,entry:int} $args Uit _ww_activity_query_args().
 * @param int                                                                                              $id   Id van de regel.
 */
function _ww_activity_entry_url( array $args, int $id ): string {
	return add_query_arg( 'entry', (string) $id, _ww_activity_filter_url( $args ) );
}

/**
 * De URL van het scherm met de filters van nu en daaroverheen $changes. Lege waarden, paged en entry vallen weg, net
 * als period als die 30 (de standaard) is. Zo komt er nooit iets anders in de link dan wat _ww_activity_query_args()
 * heeft goedgekeurd.
 *
 * @param array{actor:string,user:int,type:string,object:string,s:string,paged:int,period:int,entry:int} $args    Uit _ww_activity_query_args().
 * @param array<string,int|string>                                                                       $changes Te wijzigen waarden.
 */
function _ww_activity_filter_url( array $args, array $changes = array() ): string {
	$merged = array_merge( $args, $changes );
	unset( $merged['paged'], $merged['entry'] );
	if ( 30 === (int) $merged['period'] ) {
		unset( $merged['period'] );
	}
	$query = array();
	foreach ( $merged as $key => $value ) {
		$value = (string) $value;
		if ( '' !== $value && '0' !== $value ) {
			$query[ (string) $key ] = $value;
		}
	}
	return _ww_activity_admin_url( $query );
}

/**
 * De keuzes van Wie of Soort, met hun Dashicon.
 *
 * @param string $group actor of type.
 * @return array<string,array{label:string,icon:string}>
 */
function _ww_activity_nav_items( string $group ): array {
	if ( 'actor' === $group ) {
		return array(
			''      => array(
				'label' => __( 'Iedereen', 'webwerckt-base' ),
				'icon'  => 'dashicons-list-view',
			),
			'human' => array(
				'label' => __( 'Mensen', 'webwerckt-base' ),
				'icon'  => 'dashicons-groups',
			),
			'agent' => array(
				'label' => __( 'Agents', 'webwerckt-base' ),
				'icon'  => 'dashicons-superhero-alt',
			),
			'cli'   => array(
				'label' => __( 'WP-CLI', 'webwerckt-base' ),
				'icon'  => 'dashicons-editor-code',
			),
		);
	}
	$icons = array(
		'post'       => 'dashicons-admin-page',
		'attachment' => 'dashicons-admin-media',
		'menu'       => 'dashicons-menu',
		'settings'   => 'dashicons-admin-generic',
		'option'     => 'dashicons-admin-settings',
		'redirect'   => 'dashicons-randomize',
		'bulk'       => 'dashicons-ellipsis',
	);
	$items = array(
		'' => array(
			'label' => __( 'Alle soorten', 'webwerckt-base' ),
			'icon'  => 'dashicons-list-view',
		),
	);
	foreach ( _ww_activity_type_labels() as $slug => $label ) {
		$items[ $slug ] = array(
			'label' => $label,
			'icon'  => $icons[ $slug ] ?? 'dashicons-ellipsis',
		);
	}
	return $items;
}

/**
 * De keuzes van Wie (actor) of Soort (type) als links met hun aantal. Twee vormen: panel (in het zijpaneel, met een
 * Dashicon) en menu (een uitklapper voor mobiel, met de keuze van nu in de summary). Bij Wie krijgt de actieve link
 * aria-current="page"; bij Soort aria-current="true", en die link haalt het filter weg.
 *
 * @param string                                                                                         $group   actor of type.
 * @param array{actor:string,user:int,type:string,object:string,s:string,paged:int,period:int,entry:int} $args    Uit _ww_activity_query_args().
 * @param array{actor:array<string,int>,type:array<string,int>}                                          $counts  Uit _ww_activity_admin_counts().
 * @param string                                                                                         $variant panel of menu.
 * @return string Geëscapete HTML.
 */
function _ww_activity_render_nav( string $group, array $args, array $counts, string $variant ): string {
	$group  = 'type' === $group ? 'type' : 'actor';
	$active = $args[ $group ];
	$items  = '';
	$label  = '';
	foreach ( _ww_activity_nav_items( $group ) as $slug => $item ) {
		$slug      = (string) $slug;
		$is_active = $slug === $active;
		if ( 'type' === $group ) {
			$url     = _ww_activity_filter_url( $args, array( 'type' => $is_active ? '' : $slug ) );
			$current = $is_active ? ' aria-current="true"' : '';
		} else {
			$url     = _ww_activity_filter_url( $args, array( 'actor' => $slug ) );
			$current = $is_active ? ' aria-current="page"' : '';
		}
		if ( $is_active ) {
			$label = $item['label'];
		}
		$count  = (int) ( $counts[ $group ][ $slug ] ?? 0 );
		$icon   = 'panel' === $variant ? '<span class="dashicons ' . esc_attr( $item['icon'] ) . '" aria-hidden="true"></span>' : '';
		$items .= '<li><a href="' . esc_url( $url ) . '"' . $current . ( 0 === $count ? ' class="is-zero"' : '' ) . '>' . $icon
			. '<span class="ww-activity-nav__label">' . esc_html( $item['label'] ) . '</span>'
			. '<span class="ww-activity-count">' . esc_html( number_format_i18n( $count ) ) . '</span></a></li>';
	}
	if ( 'panel' === $variant ) {
		return '<ul class="ww-activity-panel__nav" aria-labelledby="ww-activity-group-' . esc_attr( $group ) . '">' . $items . '</ul>';
	}
	$summary = 'type' === $group ? __( 'Soort', 'webwerckt-base' ) : __( 'Wie', 'webwerckt-base' );
	return '<details class="ww-activity-menu"><summary><span>' . esc_html( $summary ) . '</span> <b>' . esc_html( $label ) . '</b></summary><ul>' . $items . '</ul></details>';
}

/**
 * De periode als drie links: Vandaag, 7 dagen en 30 dagen. De actieve krijgt aria-current="page". panel staat in de
 * kop van de inhoud, menu in de uitklapper Filters op mobiel.
 *
 * @param array{actor:string,user:int,type:string,object:string,s:string,paged:int,period:int,entry:int} $args    Uit _ww_activity_query_args().
 * @param string                                                                                         $variant panel of menu.
 * @return string Geëscapete HTML.
 */
function _ww_activity_render_period( array $args, string $variant ): string {
	$periods = array(
		1  => __( 'Vandaag', 'webwerckt-base' ),
		7  => __( '7 dagen', 'webwerckt-base' ),
		30 => __( '30 dagen', 'webwerckt-base' ),
	);
	$links   = '';
	foreach ( $periods as $days => $label ) {
		$links .= '<a class="button" href="' . esc_url( _ww_activity_filter_url( $args, array( 'period' => $days ) ) ) . '"' . ( $days === $args['period'] ? ' aria-current="page"' : '' ) . '>' . esc_html( $label ) . '</a>';
	}
	return '<div class="ww-activity-period ww-activity-period--' . ( 'menu' === $variant ? 'menu' : 'panel' ) . '" role="group" aria-label="' . esc_attr__( 'Periode', 'webwerckt-base' ) . '">' . $links . '</div>';
}

/**
 * Het label en de titel van het object van het filter object (soort:id), uit de laatste regel van dat object in het
 * log. Zonder regel: het label van de soort en de titel van het bericht, als dat er nog is.
 *
 * @param string $object Soort:id, al gecontroleerd door _ww_activity_query_args().
 * @return array{label:string,title:string}
 */
function _ww_activity_object_summary( string $object ): array {
	global $wpdb;
	list( $type, $id ) = array_pad( explode( ':', $object ), 2, '0' );
	$id                = (int) $id;
	$row               = null;
	if ( _ww_activity_ready() ) {
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . _ww_activity_table() . ' WHERE object_type = %s AND object_id = %d ORDER BY id DESC LIMIT 1', $type, $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_activity_table().
	}
	if ( is_object( $row ) ) {
		$label = _ww_activity_object_label( $row );
		$title = trim( _ww_data_to_string( $row->object_title ?? '' ) );
	} else {
		$label = _ww_activity_type_labels()[ $type ] ?? __( 'Overig', 'webwerckt-base' );
		$title = in_array( $type, array( 'post', 'attachment' ), true ) && $id > 0 ? trim( get_the_title( $id ) ) : '';
	}
	return array(
		'label' => $label,
		'title' => '' !== $title ? $title : __( '(zonder titel)', 'webwerckt-base' ),
	);
}

/**
 * De filterlabels onder de tabelbalk: "Gefilterd op" en per filter een label met een link die alleen dat filter
 * weghaalt. Soort staat alleen op mobiel als label; op desktop staat hij in het paneel. Bij twee of meer volgt "Alles
 * tonen". Zonder filter een lege string.
 *
 * @param array{actor:string,user:int,type:string,object:string,s:string,paged:int,period:int,entry:int} $args  Uit _ww_activity_query_args().
 * @param array<int,string>|null                                                                         $users Uitkomst van _ww_activity_admin_users(), of null om ze zelf te lezen.
 * @return string Geëscapete HTML.
 */
function _ww_activity_render_chips( array $args, ?array $users = null ): string {
	$chips = array();
	if ( '' !== $args['object'] ) {
		$summary = _ww_activity_object_summary( $args['object'] );
		$chips[] = array(
			'label'  => $summary['label'],
			'value'  => $summary['title'],
			'change' => array( 'object' => '' ),
			'mobile' => false,
		);
	}
	if ( $args['user'] > 0 ) {
		$users   = $users ?? _ww_activity_admin_users();
		$user    = get_userdata( $args['user'] );
		$name    = $users[ $args['user'] ] ?? ( false !== $user ? $user->display_name : '#' . $args['user'] );
		$chips[] = array(
			'label'  => __( 'Gebruiker', 'webwerckt-base' ),
			'value'  => $name,
			'change' => array( 'user' => 0 ),
			'mobile' => false,
		);
	}
	if ( '' !== $args['s'] ) {
		$chips[] = array(
			'label'  => __( 'Titel bevat', 'webwerckt-base' ),
			'value'  => $args['s'],
			'change' => array( 's' => '' ),
			'mobile' => false,
		);
	}
	if ( '' !== $args['type'] ) {
		$chips[] = array(
			'label'  => __( 'Soort', 'webwerckt-base' ),
			'value'  => _ww_activity_type_labels()[ $args['type'] ] ?? $args['type'],
			'change' => array( 'type' => '' ),
			'mobile' => true,
		);
	}
	if ( array() === $chips ) {
		return '';
	}

	$desktop = 0;
	$html    = '';
	foreach ( $chips as $chip ) {
		if ( ! $chip['mobile'] ) {
			++$desktop;
		}
		$remove = sprintf(
			/* translators: %s: naam van het filter, zoals Gebruiker. */
			__( 'Filter %s weghalen', 'webwerckt-base' ),
			$chip['label']
		);
		$html  .= ' <span class="ww-activity-chip' . ( $chip['mobile'] ? ' ww-activity-mobile-only' : '' ) . '"><b>' . esc_html( $chip['label'] ) . ':</b> ' . esc_html( $chip['value'] )
			. '<a class="ww-activity-chip__remove" href="' . esc_url( _ww_activity_filter_url( $args, $chip['change'] ) ) . '" aria-label="' . esc_attr( $remove ) . '"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></a></span>';
	}
	if ( count( $chips ) > 1 ) {
		$all   = _ww_activity_filter_url(
			$args,
			array(
				'object' => '',
				'user'   => 0,
				's'      => '',
				'type'   => '',
			)
		);
		$html .= ' <a class="ww-activity-chips__all' . ( $desktop < 2 ? ' ww-activity-mobile-only' : '' ) . '" href="' . esc_url( $all ) . '">' . esc_html__( 'Alles tonen', 'webwerckt-base' ) . '</a>';
	}
	return '<div class="ww-activity-chips' . ( 0 === $desktop ? ' ww-activity-mobile-only' : '' ) . '"><span class="ww-activity-chips__lead">' . esc_html__( 'Gefilterd op', 'webwerckt-base' ) . '</span>' . $html . '</div>';
}

/**
 * Het kaartje Vandaag in het paneel.
 *
 * @return string Geëscapete HTML.
 */
function _ww_activity_render_today_card(): string {
	$today = _ww_activity_today_summary();
	if ( $today['count'] > 0 ) {
		$text = sprintf(
			/* translators: 1: aantal wijzigingen vandaag, 2: daarvan door een agent, 3: tijd van de laatste (H:i). */
			_n(
				'%1$s wijziging, waarvan %2$s door een agent. Laatste om %3$s.',
				'%1$s wijzigingen, waarvan %2$s door een agent. Laatste om %3$s.',
				$today['count'],
				'webwerckt-base'
			),
			number_format_i18n( $today['count'] ),
			number_format_i18n( $today['agents'] ),
			$today['last']
		);
	} else {
		$text = __( 'Vandaag nog niets gewijzigd.', 'webwerckt-base' );
	}
	return '<div class="ww-activity-panel__card"><strong>' . esc_html__( 'Vandaag', 'webwerckt-base' ) . '</strong><p>' . esc_html( $text ) . '</p></div>';
}

/**
 * Het zijpaneel: kop, Wie, Soort, het kaartje Vandaag en de voet.
 *
 * @param array{actor:string,user:int,type:string,object:string,s:string,paged:int,period:int,entry:int} $args   Uit _ww_activity_query_args().
 * @param array{actor:array<string,int>,type:array<string,int>}                                          $counts Uit _ww_activity_admin_counts().
 * @return string Geëscapete HTML.
 */
function _ww_activity_render_panel( array $args, array $counts ): string {
	$days = _ww_activity_admin_retention_days();
	return '<nav class="ww-activity-panel" aria-label="' . esc_attr__( 'Weergaven van het activiteitenlog', 'webwerckt-base' ) . '">'
		. '<div class="ww-activity-panel__head"><p class="ww-activity-panel__title">' . esc_html__( 'Activiteitenlog', 'webwerckt-base' ) . '</p>'
		. '<p class="ww-activity-panel__sub">' . esc_html(
			sprintf(
				/* translators: %d: aantal dagen dat het log regels bewaart. */
				_n( 'Wie wat wijzigde, %d dag', 'Wie wat wijzigde, %d dagen', $days, 'webwerckt-base' ),
				$days
			)
		) . '</p></div>'
		. '<p class="ww-activity-panel__group" id="ww-activity-group-actor">' . esc_html__( 'Wie', 'webwerckt-base' ) . '</p>'
		. _ww_activity_render_nav( 'actor', $args, $counts, 'panel' )
		. '<p class="ww-activity-panel__group ww-activity-panel__group--sep" id="ww-activity-group-type">' . esc_html__( 'Soort', 'webwerckt-base' ) . '</p>'
		. _ww_activity_render_nav( 'type', $args, $counts, 'panel' )
		. _ww_activity_render_today_card()
		. '<p class="ww-activity-panel__foot"><span class="dashicons dashicons-info-outline" aria-hidden="true"></span><span>' . esc_html(
			sprintf(
				/* translators: %d: aantal dagen dat het log regels bewaart. */
				_n( 'Alleen de namen van velden worden bewaard, nooit wat erin stond. Regels ouder dan %d dag verdwijnen vanzelf.', 'Alleen de namen van velden worden bewaard, nooit wat erin stond. Regels ouder dan %d dagen verdwijnen vanzelf.', $days, 'webwerckt-base' ),
				$days
			)
		) . '</span></p>'
		. '</nav>';
}

/**
 * De grijze regel onder de titel: de periode en "nieuwste eerst", zoals "16 okt t/m 14 nov 2026 · nieuwste eerst".
 *
 * @param int $period 1, 7 of 30 dagen.
 */
function _ww_activity_range_text( int $period ): string {
	$today = new DateTimeImmutable( 'today', wp_timezone() );
	$end   = (string) wp_date( 'j M Y', $today->getTimestamp() );
	if ( $period <= 1 ) {
		$range = $end;
	} else {
		// 30 dagen is "alles wat het log bewaart": begin dan bij de bewaartermijn.
		$days  = $period >= 30 ? _ww_activity_admin_retention_days() : $period;
		$start = $today->modify( '-' . ( $days - 1 ) . ' days' );
		$range = sprintf(
			/* translators: 1: eerste dag van de periode, 2: laatste dag. */
			__( '%1$s t/m %2$s', 'webwerckt-base' ),
			(string) wp_date( $start->format( 'Y' ) === $today->format( 'Y' ) ? 'j M' : 'j M Y', $start->getTimestamp() ),
			$end
		);
	}
	return sprintf(
		/* translators: %s: de periode, zoals 16 okt t/m 14 nov 2026. */
		__( '%s · nieuwste eerst', 'webwerckt-base' ),
		$range
	);
}
