<?php
/**
 * Mail in het beheer (beslissing 0034): het hoofditem Mail met Logboek en Instellingen, alleen voor beheerders.
 *
 * De lijst staat in WW_Mail_Log_List_Table, het detail toont alle kolommen van een regel. Elke actie (opnieuw versturen,
 * verwijderen, ook als bulkactie) komt binnen op admin_init met ww_mail_log_action, een nonce (ww_mail_log_{actie}) en het
 * recht manage_options, en stuurt daarna terug naar de lijst met een melding. Alles wat uit de log komt (adressen,
 * onderwerp, tekst, fout) is ongecontroleerd en wordt ge-escaped; de tekst van de mail staat in een <pre>, nooit als HTML.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const WW_MAIL_LOG_PAGE     = 'ww-mail-log';
const WW_MAIL_LOG_PER_PAGE = 50;
const WW_MAIL_LOG_ACTIONS  = array( 'resend', 'delete', 'bulk-resend', 'bulk-delete' );

/**
 * Voegt het hoofditem Mail toe, in het Webwerckt-blok (beslissing 0035), zonder submenu: Logboek en Instellingen zijn
 * onderdelen binnen het scherm (?tab=). Mislukte mails sinds Gezien staan als bolletje achter de menutitel.
 */
function _ww_mail_log_menu(): void {
	$title = __( 'Mail', 'webwerckt-base' );
	if ( current_user_can( 'manage_options' ) && _ww_mail_log_ready() ) {
		$count = _ww_mail_failed_unseen()['count'];
		if ( $count > 0 ) {
			$title .= ' <span class="awaiting-mod">' . esc_html( number_format_i18n( $count ) ) . '</span>';
		}
	}
	add_menu_page(
		__( 'Mail', 'webwerckt-base' ),
		$title,
		'manage_options',
		WW_MAIL_LOG_PAGE,
		'_ww_mail_admin_render',
		'dashicons-email-alt'
	);
}
add_action( 'admin_menu', '_ww_mail_log_menu' );

/**
 * URL van het scherm, eventueel met extra queryvariabelen.
 *
 * @param array<string,string> $args Queryvariabelen.
 */
function _ww_mail_log_url( array $args = array() ): string {
	return add_query_arg( array_map( 'rawurlencode', array( 'page' => WW_MAIL_LOG_PAGE ) + $args ), admin_url( 'admin.php' ) );
}

/**
 * Een link naar een actie met een nonce.
 *
 * @param string               $action Actie uit WW_MAIL_LOG_ACTIONS.
 * @param array<string,string> $args   Extra queryvariabelen.
 */
function _ww_mail_log_action_url( string $action, array $args = array() ): string {
	return wp_nonce_url( _ww_mail_log_url( array( 'ww_mail_log_action' => $action ) + $args ), 'ww_mail_log_' . $action );
}

/**
 * Datum en tijd in de tijdzone van de site, uit een UTC-tijd van de database.
 *
 * @param string $utc Tijd als Y-m-d H:i:s in UTC.
 */
function _ww_mail_log_date( string $utc ): string {
	$time = strtotime( $utc . ' UTC' );
	return false === $time ? '' : wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $time );
}

/**
 * De naam van een aansluiting zoals de log hem bewaarde (server, wp-mail-smtp of het id van een aansluiting).
 *
 * @param string $id Bewaard id.
 */
function _ww_mail_log_transport_label( string $id ): string {
	if ( 'server' === $id ) {
		return __( 'Server', 'webwerckt-base' );
	}
	if ( 'wp-mail-smtp' === $id ) {
		return __( 'WP Mail SMTP', 'webwerckt-base' );
	}
	$transports = _ww_mail_transports();
	return isset( $transports[ $id ] ) ? $transports[ $id ]->label() : $id;
}

/**
 * De regels voor de tabel, nieuwste eerst: filter op status, zoeken in ontvangers en onderwerp, en een pagina.
 *
 * @param array{status?:string,search?:string,page?:int,per_page?:int} $args Filters.
 * @return array{items:list<object>,total:int}
 */
function _ww_mail_log_query( array $args ): array {
	global $wpdb;
	if ( ! _ww_mail_log_ready() ) {
		return array(
			'items' => array(),
			'total' => 0,
		);
	}
	$table    = _ww_mail_log_table();
	$status   = $args['status'] ?? '';
	$search   = $args['search'] ?? '';
	$per_page = max( 1, $args['per_page'] ?? WW_MAIL_LOG_PER_PAGE );
	$offset   = max( 0, ( $args['page'] ?? 1 ) - 1 ) * $per_page;

	$where  = array();
	$values = array();
	if ( in_array( $status, array( 'sent', 'failed' ), true ) ) {
		$where[]  = 'status = %s';
		$values[] = $status;
	}
	if ( '' !== $search ) {
		$like     = '%' . $wpdb->esc_like( $search ) . '%';
		$where[]  = '(recipients LIKE %s OR subject LIKE %s)';
		$values[] = $like;
		$values[] = $like;
	}
	$sql_where = array() === $where ? '' : ' WHERE ' . implode( ' AND ', $where );

	$count_sql = "SELECT COUNT(*) FROM $table$sql_where";
	$total     = (int) ( array() === $values ? $wpdb->get_var( $count_sql ) : $wpdb->get_var( $wpdb->prepare( $count_sql, $values ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- tabelnaam uit _ww_mail_log_table(), waarden voorbereid.

	// Alle kolommen behalve message (mediumtext): de lijst toont de tekst niet.
	$list_sql = "SELECT id, created, recipients, subject, headers, attachments, transport, status, error, provider_id, resent_of FROM $table$sql_where ORDER BY id DESC LIMIT %d OFFSET %d";
	$rows     = $wpdb->get_results( $wpdb->prepare( $list_sql, array_merge( $values, array( $per_page, $offset ) ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- tabelnaam uit _ww_mail_log_table(), waarden voorbereid.

	return array(
		'items' => array_map( '_ww_mail_log_decode', array_values( array_filter( (array) $rows, 'is_object' ) ) ),
		'total' => $total,
	);
}

/**
 * Een waarde voor in een mailheader: zonder regeleinden, zodat opgeslagen tekst nooit een extra header kan inbrengen.
 *
 * @param mixed $value Waarde uit de log.
 */
function _ww_mail_log_header_value( $value ): string {
	return is_string( $value ) ? trim( str_replace( array( "\r", "\n", "\0" ), '', $value ) ) : '';
}

/**
 * De adressen van een lijst als schone teksten, zonder lege waarden.
 *
 * @param mixed $list Lijst uit de log.
 * @return list<string>
 */
function _ww_mail_log_clean_addresses( $list ): array {
	$clean = array();
	foreach ( is_array( $list ) ? $list : array() as $address ) {
		$address = _ww_mail_log_header_value( $address );
		if ( '' !== $address ) {
			$clean[] = $address;
		}
	}
	return $clean;
}

/**
 * Stuurt een regel opnieuw: wp_mail() met dezelfde ontvangers, onderwerp, tekst en headers (CC, BCC, Reply-To en
 * Content-Type), zonder bijlagen. Het Van-adres volgt de instellingen van nu. De nieuwe regel in de log krijgt resent_of.
 * Elke waarde uit de log wordt van regeleinden ontdaan voordat ze een header wordt.
 *
 * @param int $id Id van de oorspronkelijke regel.
 * @return bool Of wp_mail() de mail heeft verstuurd.
 */
function _ww_mail_log_resend( int $id ): bool {
	$row = _ww_mail_log_get( $id );
	if ( null === $row ) {
		return false;
	}
	$to = _ww_mail_log_clean_addresses( $row->recipients['to'] );
	if ( array() === $to ) {
		return false;
	}

	$headers = array();
	foreach ( array(
		'Cc'       => $row->recipients['cc'],
		'Bcc'      => $row->recipients['bcc'],
		'Reply-To' => $row->headers['reply_to'],
	) as $name => $list ) {
		$list = _ww_mail_log_clean_addresses( $list );
		if ( array() !== $list ) {
			$headers[] = $name . ': ' . implode( ', ', $list );
		}
	}
	$content_type = _ww_mail_log_header_value( $row->headers['content_type'] );
	if ( '' !== $content_type ) {
		$headers[] = 'Content-Type: ' . $content_type;
	}

	_ww_mail_log_resent_of( $id );
	try {
		return (bool) wp_mail( $to, (string) $row->subject, (string) $row->message, $headers );
	} finally {
		// Ook als een pre_wp_mail-filter de mail onderschept: het id mag nooit naar de volgende mail lekken.
		_ww_mail_log_resent_of( 0 );
	}
}

/**
 * Meldt iets op het scherm en stuurt terug naar de lijst (de melding reist mee in een transient, zoals bij options.php).
 *
 * @param string $message Tekst.
 * @param string $type    success, error, warning of info.
 */
function _ww_mail_log_done( string $message, string $type = 'success' ): void {
	add_settings_error( 'ww_mail_log', 'ww_mail_log_' . $type, esc_html( $message ), $type );
	set_transient( 'settings_errors', get_settings_errors(), 30 );

	if ( wp_safe_redirect( _ww_mail_log_url( array( 'settings-updated' => 'true' ) ) ) ) {
		exit;
	}
}

/**
 * De regels die een actie raakt: ids[] uit het formulier van de tabel, of id uit de link.
 *
 * @return int[]
 */
function _ww_mail_log_action_ids(): array {
	// phpcs:disable WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput -- de nonce is gecontroleerd in _ww_mail_log_handle_action(); alleen getallen worden gebruikt.
	$raw = isset( $_POST['ids'] ) && is_array( $_POST['ids'] ) ? wp_unslash( $_POST['ids'] ) : array();
	$ids = array_map( static fn( $value ): int => absint( _ww_data_to_string( $value ) ), $raw );
	$one = isset( $_GET['id'] ) ? absint( _ww_data_to_string( wp_unslash( $_GET['id'] ) ) ) : 0;
	// phpcs:enable
	if ( $one > 0 ) {
		$ids[] = $one;
	}
	return array_values( array_unique( array_filter( $ids ) ) );
}

/**
 * Voert de actie uit het verzoek uit (admin_init). Zie WW_MAIL_LOG_ACTIONS.
 */
function _ww_mail_log_handle_action(): void {
	// phpcs:disable WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput -- de nonce wordt hieronder per actie gecontroleerd.
	$action = isset( $_REQUEST['ww_mail_log_action'] ) ? sanitize_key( _ww_data_to_string( wp_unslash( $_REQUEST['ww_mail_log_action'] ) ) ) : '';
	if ( '' === $action && ! wp_doing_ajax() && isset( $_REQUEST['page'] ) && WW_MAIL_LOG_PAGE === _ww_data_to_string( wp_unslash( $_REQUEST['page'] ) ) ) {
		// Het keuzelijstje boven en onder de tabel stuurt zijn keuze als action en action2, alleen op dit scherm.
		foreach ( array( 'action', 'action2' ) as $key ) {
			$chosen = isset( $_REQUEST[ $key ] ) ? sanitize_key( _ww_data_to_string( wp_unslash( $_REQUEST[ $key ] ) ) ) : '';
			if ( in_array( $chosen, array( 'bulk-resend', 'bulk-delete' ), true ) ) {
				$action = $chosen;
				break;
			}
		}
	}
	// phpcs:enable
	if ( ! in_array( $action, WW_MAIL_LOG_ACTIONS, true ) ) {
		return;
	}

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Je hebt geen rechten om het logboek te beheren.', 'webwerckt-base' ), 403 );
	}
	// De tabel heeft twee bulkacties en één keuzelijstje: elke actie heeft daarom een eigen nonce-veld.
	$nonce_arg = isset( $_REQUEST[ '_ww_nonce_' . $action ] ) ? '_ww_nonce_' . $action : '_wpnonce'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- alleen de naam van het veld; de nonce zelf wordt hieronder gecontroleerd.
	check_admin_referer( 'ww_mail_log_' . $action, $nonce_arg );

	$ids = _ww_mail_log_action_ids();
	if ( array() === $ids ) {
		_ww_mail_log_done( __( 'Er is geen regel gekozen.', 'webwerckt-base' ), 'warning' );
		return;
	}

	if ( 'delete' === $action || 'bulk-delete' === $action ) {
		$count = _ww_mail_log_delete( $ids );
		_ww_mail_log_done(
			sprintf(
				/* translators: %d: aantal regels. */
				_n( '%d regel verwijderd.', '%d regels verwijderd.', $count, 'webwerckt-base' ),
				$count
			)
		);
		return;
	}

	$sent   = 0;
	$failed = 0;
	foreach ( $ids as $id ) {
		if ( _ww_mail_log_resend( $id ) ) {
			++$sent;
		} else {
			++$failed;
		}
	}
	$message = sprintf(
		/* translators: %d: aantal mails. */
		_n( '%d mail opnieuw verstuurd.', '%d mails opnieuw verstuurd.', $sent, 'webwerckt-base' ),
		$sent
	);
	if ( $failed > 0 ) {
		$message .= ' ' . sprintf(
			/* translators: %d: aantal mails. */
			_n( '%d mail is mislukt: zie het logboek.', '%d mails zijn mislukt: zie het logboek.', $failed, 'webwerckt-base' ),
			$failed
		);
	}
	_ww_mail_log_done( $message, 0 === $failed ? 'success' : 'warning' );
}
add_action( 'admin_init', '_ww_mail_log_handle_action' );

/**
 * Toont het scherm: de lijst, of het detail bij &id=<id>.
 */
function _ww_mail_log_render(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Je hebt geen rechten om het logboek te bekijken.', 'webwerckt-base' ), 403 );
	}
	// De router beslist: de lijst of, alleen zonder tab, het detail bij &id=.
	$view = _ww_mail_admin_view();
	echo _ww_mail_admin_render_view( 'detail' === $view ? 'detail' : 'log' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- de weergaven escapen zelf.
}

/*
 * Melding bij mislukte mail (alleen manage_options, niet in Visueel bewerken).
 */

/**
 * Het aantal mislukte mails sinds de laatste keer Gezien, de tijd (UTC) van de eerste daarvan en het hoogste id. Eén
 * query op de index van status; de tabel is dan al klaar.
 *
 * @return array{count:int,first:string,last:int}
 */
function _ww_mail_failed_unseen(): array {
	global $wpdb;
	$table = _ww_mail_log_table();
	$row   = $wpdb->get_row( $wpdb->prepare( "SELECT COUNT(*) AS total, MIN(created) AS first, MAX(id) AS last FROM $table WHERE status = 'failed' AND id > %d", absint( get_option( 'ww_mail_failed_seen', 0 ) ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_mail_log_table().
	return array(
		'count' => is_array( $row ) ? (int) $row['total'] : 0,
		'first' => is_array( $row ) && is_string( $row['first'] ) ? $row['first'] : '',
		'last'  => is_array( $row ) ? (int) $row['last'] : 0,
	);
}

/**
 * Toont de melding op admin_notices.
 */
function _ww_mail_failed_notice(): void {
	if ( ! current_user_can( 'manage_options' ) || WW_EDITOR_PAGE === _ww_query_key( 'page' ) || ! _ww_mail_log_ready() ) {
		return;
	}
	$unseen = _ww_mail_failed_unseen();
	if ( $unseen['count'] < 1 ) {
		return;
	}
	$text = sprintf(
		/* translators: 1: aantal mails, 2: datum en tijd van de eerste. */
		_n( '%1$d mail niet verstuurd sinds %2$s.', '%1$d mails niet verstuurd sinds %2$s.', $unseen['count'], 'webwerckt-base' ),
		$unseen['count'],
		_ww_mail_log_date( $unseen['first'] )
	);
	// Het hoogste id van nu gaat mee: een mail die mislukt na het tonen blijft na Gezien gemeld.
	$seen = wp_nonce_url( add_query_arg( 'ww_mail_failed_seen', (string) $unseen['last'], admin_url() ), 'ww_mail_failed_seen' );
	printf(
		'<div class="notice notice-error"><p>%1$s <a href="%2$s">%3$s</a> <a href="%4$s">%5$s</a></p></div>',
		esc_html( $text ),
		esc_url( _ww_mail_log_url( array( 'status' => 'failed' ) ) ),
		esc_html__( 'Bekijk de mislukte mails', 'webwerckt-base' ),
		esc_url( $seen ),
		esc_html__( 'Gezien', 'webwerckt-base' )
	);
}
add_action( 'admin_notices', '_ww_mail_failed_notice' );

/**
 * De actie Gezien (admin_init): zet ww_mail_failed_seen op het id uit de link (het hoogste failed-id toen de melding
 * werd getoond), nooit hoger dan het hoogste failed-id van nu en nooit lager dan de oude waarde, en stuurt terug. Nonce
 * en recht zijn verplicht.
 */
function _ww_mail_failed_seen_handle(): void {
	$seen = absint( _ww_query_key( 'ww_mail_failed_seen' ) );
	if ( $seen < 1 ) {
		return;
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Je hebt geen rechten om het logboek te beheren.', 'webwerckt-base' ), 403 );
	}
	check_admin_referer( 'ww_mail_failed_seen' );

	if ( _ww_mail_log_ready() ) {
		global $wpdb;
		$table = _ww_mail_log_table();
		$max   = (int) $wpdb->get_var( "SELECT MAX(id) FROM $table WHERE status = 'failed'" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- tabelnaam uit _ww_mail_log_table().
		$old   = absint( get_option( 'ww_mail_failed_seen', 0 ) );
		$new   = max( $old, min( $seen, $max ) );
		if ( $new !== $old ) {
			update_option( 'ww_mail_failed_seen', $new, false );
		}
	}
	if ( wp_safe_redirect( remove_query_arg( array( 'ww_mail_failed_seen', '_wpnonce' ), wp_get_referer() ? wp_get_referer() : admin_url() ) ) ) {
		exit;
	}
}
add_action( 'admin_init', '_ww_mail_failed_seen_handle' );

/*
 * Mail › Instellingen en de testmail (alleen manage_options).
 *
 * Het formulier gaat via de Settings API naar options.php. Geheimen zitten in een eigen POST-array (ww_mail_secret,
 * ww_mail_secret_remove) en worden nooit als instelling geregistreerd: options.php roept de sanitize bij de eerste
 * add_option twee keer aan, en versleutelen in een sanitize zou dan dubbel gebeuren. _ww_mail_save_secrets() schrijft ze
 * één keer per opslaan via _ww_mail_set_secret(), aangeroepen vanuit pre_update_option_ww_mail_settings (dat filter loopt
 * precies één keer per update_option()). Een geheim komt nooit in de HTML: het scherm toont alleen de toestand.
 */

const WW_MAIL_SETTINGS_PAGE    = 'ww-mail';
const WW_MAIL_SETTINGS_GROUP   = 'ww_mail';
const WW_MAIL_SETTINGS_OPTIONS = array( 'ww_mail_transport', 'ww_mail_from', 'ww_mail_from_name', 'ww_mail_from_force', 'ww_mail_settings' );

/**
 * URL van Mail › Instellingen: het tabblad settings van het scherm Mail.
 *
 * @param array<string,string> $args Queryvariabelen.
 */
function _ww_mail_settings_url( array $args = array() ): string {
	return add_query_arg( array_map( 'rawurlencode', array( 'page' => WW_MAIL_LOG_PAGE, 'tab' => 'settings' ) + $args ), admin_url( 'admin.php' ) );
}

/**
 * Het nieuwe adres voor een verzoek aan het oude scherm Instellingen (page=ww-mail onder admin.php of
 * options-general.php), met alle andere tekstwaarden mee; anders ''.
 *
 * @param array<string,mixed> $query De queryvariabelen van het verzoek.
 */
function _ww_mail_old_settings_url( array $query ): string {
	global $pagenow;
	if ( ! in_array( $pagenow, array( 'admin.php', 'options-general.php' ), true ) || WW_MAIL_SETTINGS_PAGE !== _ww_data_to_string( $query['page'] ?? '' ) ) {
		return '';
	}
	$args = array();
	foreach ( $query as $key => $value ) {
		if ( is_string( $value ) && 'page' !== $key ) {
			$args[ (string) $key ] = $value;
		}
	}
	return _ww_mail_settings_url( $args );
}

/**
 * Stuurt een oude bladwijzer van Mail › Instellingen (een GET) naar het tabblad. Soms weigert WordPress het oude adres
 * al vóór admin_init en roept dan admin_page_access_denied aan.
 */
function _ww_mail_admin_redirect_old_settings(): void {
	if ( 'GET' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) || wp_doing_ajax() ) {
		return;
	}
	$url = _ww_mail_old_settings_url( wp_unslash( $_GET ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- alleen doorsturen; het nieuwe scherm controleert de waarden zelf.
	if ( '' !== $url && wp_safe_redirect( $url ) ) {
		exit;
	}
}
add_action( 'admin_init', '_ww_mail_admin_redirect_old_settings' );
add_action( 'admin_page_access_denied', '_ww_mail_admin_redirect_old_settings' );

/**
 * Registreert de instellingen van de groep ww_mail (admin_init). De geheimen horen er bewust niet bij.
 */
function _ww_mail_register_settings(): void {
	$settings = array(
		'ww_mail_transport'  => array(
			'type'              => 'string',
			'sanitize_callback' => '_ww_mail_sanitize_transport',
			'default'           => '',
		),
		'ww_mail_from'       => array(
			'type'              => 'string',
			'sanitize_callback' => '_ww_mail_sanitize_from',
			'default'           => '',
		),
		'ww_mail_from_name'  => array(
			'type'              => 'string',
			'sanitize_callback' => '_ww_mail_sanitize_from_name',
			'default'           => '',
		),
		'ww_mail_from_force' => array(
			'type'              => 'string',
			'sanitize_callback' => '_ww_mail_sanitize_from_force',
			'default'           => '1',
		),
		'ww_mail_settings'   => array(
			'type'              => 'array',
			'sanitize_callback' => '_ww_mail_sanitize_settings_option',
			'default'           => array(),
		),
	);
	foreach ( $settings as $option => $args ) {
		register_setting( WW_MAIL_SETTINGS_GROUP, $option, $args + array( 'show_in_rest' => false ) );
	}
}
add_action( 'admin_init', '_ww_mail_register_settings' );

/**
 * Zet autoload zoals de spec het wil zodra een optie voor het eerst wordt aangemaakt (options.php geeft geen autoload
 * mee): alleen de aansluiting laadt mee, de rest niet.
 *
 * @param string $option Naam van de optie.
 */
function _ww_mail_option_autoload( string $option ): void {
	wp_set_option_autoload( $option, 'ww_mail_transport' === $option );
}
foreach ( WW_MAIL_SETTINGS_OPTIONS as $ww_mail_option ) {
	add_action( 'add_option_' . $ww_mail_option, '_ww_mail_option_autoload' );
}
unset( $ww_mail_option );

/**
 * Sanitize van ww_mail_transport: '' (Geen) of een geregistreerde aansluiting. Staat WW_MAIL_TRANSPORT in wp-config.php,
 * dan heeft het formulier geen keuzelijst en blijft de opgeslagen keuze staan. Een opgeslagen aansluiting die niet meer
 * bestaat blijft ook staan als het formulier haar ongewijzigd terugstuurt: opslaan om een andere reden mag de site niet
 * stil naar de server laten overstappen.
 *
 * @param mixed $value Invoer.
 */
function _ww_mail_sanitize_transport( $value ): string {
	$old = get_option( 'ww_mail_transport', '' );
	$old = is_string( $old ) ? $old : '';
	if ( null !== _ww_mail_constant( 'WW_MAIL_TRANSPORT' ) && null === $value ) {
		return $old;
	}
	$id = sanitize_key( _ww_data_to_string( $value ) );
	if ( '' === $id ) {
		return '';
	}
	return ( isset( _ww_mail_transports()[ $id ] ) || sanitize_key( $old ) === $id ) ? $id : '';
}

/**
 * Sanitize van ww_mail_from: een geldig adres, of '' met een melding.
 *
 * @param mixed $value Invoer.
 */
function _ww_mail_sanitize_from( $value ): string {
	$from = trim( _ww_data_to_string( $value ) );
	if ( '' === $from ) {
		return '';
	}
	if ( is_email( $from ) ) {
		return sanitize_email( $from );
	}
	// Bij de eerste add_option loopt de sanitize twee keer; de tweede keer is de waarde al leeg.
	add_settings_error( 'ww_mail_from', 'ww_mail_from_invalid', esc_html__( 'Het Van-adres is geen geldig e-mailadres en is leeggemaakt.', 'webwerckt-base' ), 'error' );
	return '';
}

/**
 * Sanitize van ww_mail_from_name.
 *
 * @param mixed $value Invoer.
 */
function _ww_mail_sanitize_from_name( $value ): string {
	return sanitize_text_field( _ww_data_to_string( $value ) );
}

/**
 * Sanitize van ww_mail_from_force: '1' of '0' (een leeg vinkje komt als null binnen).
 *
 * @param mixed $value Invoer.
 */
function _ww_mail_sanitize_from_force( $value ): string {
	return '1' === _ww_data_to_string( $value ) ? '1' : '0';
}

/**
 * Sanitize van ww_mail_settings zoals register_setting() hem aanroept.
 *
 * @param mixed $value Invoer.
 * @return array<string,array<string,mixed>>
 */
function _ww_mail_sanitize_settings_option( $value ): array {
	return _ww_mail_sanitize_settings( is_array( $value ) ? $value : array() );
}

/**
 * Maakt de velden per aansluiting schoon volgens settings(): een getal 1–65535 (anders de standaard), een keuze alleen
 * uit de opties (anders de standaard), tekst via sanitize_text_field. Geheime velden en onbekende aansluitingen vallen weg.
 *
 * @param array<mixed> $input Invoer, per id van een aansluiting.
 * @return array<string,array<string,mixed>>
 */
function _ww_mail_sanitize_settings( array $input ): array {
	$clean = array();
	foreach ( _ww_mail_transports() as $id => $transport ) {
		$values = isset( $input[ $id ] ) && is_array( $input[ $id ] ) ? $input[ $id ] : array();
		$fields = array();
		foreach ( $transport->settings() as $field ) {
			$name = _ww_data_to_string( $field['name'] ?? '' );
			if ( '' === $name || ! empty( $field['secret'] ) ) {
				continue;
			}
			$default = $field['default'] ?? '';
			$raw     = array_key_exists( $name, $values ) ? $values[ $name ] : $default;
			$type    = $field['type'] ?? 'text';

			if ( 'number' === $type ) {
				$number          = filter_var( is_scalar( $raw ) ? trim( (string) $raw ) : '', FILTER_VALIDATE_INT );
				$fields[ $name ] = ( false !== $number && $number >= 1 && $number <= 65535 ) ? $number : $default;
			} elseif ( 'select' === $type ) {
				$options         = isset( $field['options'] ) && is_array( $field['options'] ) ? array_map( 'strval', array_keys( $field['options'] ) ) : array();
				$choice          = _ww_data_to_string( $raw );
				$fields[ $name ] = in_array( $choice, $options, true ) ? $choice : $default;
			} else {
				$fields[ $name ] = sanitize_text_field( _ww_data_to_string( $raw ) );
			}
		}
		if ( array() !== $fields ) {
			$clean[ $id ] = $fields;
		}
	}
	return $clean;
}

/**
 * De geheime velden van een aansluiting: naam => veld.
 *
 * @param WW_Mail_Transport $transport Aansluiting.
 * @return array<string,array<string,mixed>>
 */
function _ww_mail_secret_fields( WW_Mail_Transport $transport ): array {
	$secret = array();
	foreach ( $transport->settings() as $field ) {
		$name = _ww_data_to_string( $field['name'] ?? '' );
		if ( '' !== $name && ! empty( $field['secret'] ) ) {
			$secret[ $name ] = $field;
		}
	}
	return $secret;
}

/**
 * De constante die voor een veld voorgaat, of null.
 *
 * @param array<string,mixed> $field Veld uit settings().
 */
function _ww_mail_field_constant( array $field ): ?string {
	$constant = $field['constant'] ?? null;
	return is_string( $constant ) && '' !== $constant ? $constant : null;
}

/**
 * Slaat de geheimen uit het formulier op: een nieuwe waarde vervangt de oude, leeg laat de oude staan, het vinkje
 * Verwijderen haalt hem weg (het vinkje wint). Velden met een constante en onbekende velden worden genegeerd.
 *
 * @param array<mixed> $input  Nieuwe waarden, per aansluiting en veld (ww_mail_secret).
 * @param array<mixed> $remove Vinkjes Verwijderen, per aansluiting en veld (ww_mail_secret_remove).
 */
function _ww_mail_save_secrets( array $input, array $remove = array() ): void {
	foreach ( _ww_mail_transports() as $id => $transport ) {
		foreach ( _ww_mail_secret_fields( $transport ) as $name => $field ) {
			$constant = _ww_mail_field_constant( $field );
			if ( null !== $constant && null !== _ww_mail_constant( $constant ) ) {
				continue;
			}
			if ( '1' === _ww_data_to_string( $remove[ $id ][ $name ] ?? '' ) ) {
				_ww_mail_set_secret( $id, $name, null );
				continue;
			}
			// Geen sanitize_text_field: dat zou tekens als < en %xx uit een wachtwoord halen. Alleen regeleinden en nul-tekens
			// gaan weg, en witruimte aan begin en eind (een geplakte sleutel met een spatie erachter geeft anders een 401).
			$value = trim( str_replace( array( "\r", "\n", "\0" ), '', _ww_data_to_string( $input[ $id ][ $name ] ?? '' ) ) );
			if ( '' !== $value ) {
				_ww_mail_set_secret( $id, $name, $value );
				_ww_mail_note_secret_saved( $id, $name );
			}
		}
	}
}

/**
 * Slaat de geheimen op als het formulier van dit scherm via options.php wordt opgeslagen (pre_update_option_ww_mail_settings,
 * dat precies één keer per update_option() loopt). Controleert zelf de nonce van de groep en het recht. Geeft de waarde
 * ongewijzigd terug.
 *
 * @param mixed $value Nieuwe waarde van ww_mail_settings.
 * @return mixed
 */
function _ww_mail_save_secrets_from_request( $value ) {
	// phpcs:disable WordPress.Security.ValidatedSanitizedInput, WordPress.Security.NonceVerification -- de nonce wordt hieronder gecontroleerd; geheimen worden bewust niet met sanitize_text_field bewerkt.
	if ( ! isset( $_POST['option_page'] ) || WW_MAIL_SETTINGS_GROUP !== $_POST['option_page'] || ! current_user_can( 'manage_options' ) ) {
		return $value;
	}
	$nonce = isset( $_POST['_wpnonce'] ) ? _ww_data_to_string( wp_unslash( $_POST['_wpnonce'] ) ) : '';
	if ( ! wp_verify_nonce( $nonce, WW_MAIL_SETTINGS_GROUP . '-options' ) ) {
		return $value;
	}
	$input  = isset( $_POST['ww_mail_secret'] ) && is_array( $_POST['ww_mail_secret'] ) ? wp_unslash( $_POST['ww_mail_secret'] ) : array();
	$remove = isset( $_POST['ww_mail_secret_remove'] ) && is_array( $_POST['ww_mail_secret_remove'] ) ? wp_unslash( $_POST['ww_mail_secret_remove'] ) : array();
	// phpcs:enable
	_ww_mail_save_secrets( $input, $remove );
	return $value;
}
add_filter( 'pre_update_option_ww_mail_settings', '_ww_mail_save_secrets_from_request' );

/**
 * De toestand van een geheim veld als tekst voor het scherm. Nooit de waarde zelf: alleen de laatste 4 tekens, en dat
 * alleen bij een geheim van minstens 12 tekens.
 *
 * @param string              $id    Id van de aansluiting.
 * @param string              $name  Naam van het veld.
 * @param array<string,mixed> $field Veld uit settings().
 */
function _ww_mail_secret_state_text( string $id, string $name, array $field ): string {
	$state = _ww_mail_secret_state( $id, $name, _ww_mail_field_constant( $field ) );
	switch ( $state ) {
		case 'constant':
			return __( 'Staat in wp-config.php', 'webwerckt-base' );
		case 'unreadable':
			return __( 'Moet opnieuw worden ingevoerd (de sleutels van de site zijn veranderd)', 'webwerckt-base' );
		case 'set':
			$secret = (string) _ww_mail_secret( $id, $name );
			if ( mb_strlen( $secret ) < 12 ) {
				return __( 'Ingesteld', 'webwerckt-base' );
			}
			/* translators: %s: de laatste 4 tekens van het geheim. */
			return sprintf( __( 'Ingesteld (eindigt op …%s)', 'webwerckt-base' ), mb_substr( $secret, -4 ) );
		default:
			return '';
	}
}

/**
 * Eén veld van een aansluiting als rij van de tabel.
 *
 * @param string              $id    Id van de aansluiting.
 * @param array<string,mixed> $field Veld uit settings().
 */
function _ww_mail_render_field( string $id, array $field ): void {
	$name  = _ww_data_to_string( $field['name'] ?? '' );
	$label = _ww_data_to_string( $field['label'] ?? $name );
	$type  = _ww_data_to_string( $field['type'] ?? 'text' );
	$html  = 'ww-mail-' . $id . '-' . $name;

	echo '<tr><th scope="row"><label for="' . esc_attr( $html ) . '">' . esc_html( $label ) . '</label></th><td>';

	if ( ! empty( $field['secret'] ) ) {
		$constant = _ww_mail_field_constant( $field );
		$state    = _ww_mail_secret_state( $id, $name, $constant );
		$text     = _ww_mail_secret_state_text( $id, $name, $field );
		if ( 'constant' === $state ) {
			echo '<p>' . esc_html( $text ) . '</p>';
		} else {
			$bad = 'unreadable' === $state;
			echo '<div class="ww-mail-secret" data-ww-mail-secret>';
			if ( '' !== $text ) {
				echo '<span class="ww-mail-secret__state' . ( $bad ? ' ww-mail-secret__state--bad' : '' ) . '">' . esc_html( $text ) . '</span>';
				if ( ! $bad ) {
					// Verborgen tot mail-admin.js het veld verbergt: zonder JavaScript staat het veld gewoon open.
					echo '<button type="button" class="button ww-mail-secret__replace" hidden>' . esc_html__( 'Vervangen', 'webwerckt-base' ) . '</button>';
				}
			}
			echo '<input type="password" class="regular-text ww-mail-secret__input" id="' . esc_attr( $html ) . '" name="' . esc_attr( 'ww_mail_secret[' . $id . '][' . $name . ']' ) . '" value="" autocomplete="new-password">';
			if ( '' !== $text ) {
				echo '<label class="ww-mail-secret__remove"><input type="checkbox" name="' . esc_attr( 'ww_mail_secret_remove[' . $id . '][' . $name . ']' ) . '" value="1"> ' . esc_html__( 'Verwijderen bij opslaan', 'webwerckt-base' ) . '</label>';
			}
			echo '</div>';
		}
		echo '</td></tr>';
		return;
	}

	// Een gewoon veld met een constante (WW_MAIL_SMTP_HOST): de waarde uit wp-config.php, niet te wijzigen.
	$constant = _ww_mail_field_constant( $field );
	$fixed    = null !== $constant ? _ww_mail_constant( $constant ) : null;
	if ( null !== $fixed ) {
		echo '<p><code>' . esc_html( $fixed ) . '</code> &middot; ' . esc_html__( 'Staat in wp-config.php', 'webwerckt-base' ) . '</p></td></tr>';
		return;
	}

	$value     = _ww_mail_setting( $id, $name, $field['default'] ?? '' );
	$value     = is_scalar( $value ) ? (string) $value : '';
	$attribute = 'ww_mail_settings[' . $id . '][' . $name . ']';
	if ( 'select' === $type ) {
		echo '<select id="' . esc_attr( $html ) . '" name="' . esc_attr( $attribute ) . '">';
		foreach ( (array) ( $field['options'] ?? array() ) as $key => $option_label ) {
			echo '<option value="' . esc_attr( (string) $key ) . '"' . selected( $value, (string) $key, false ) . '>' . esc_html( _ww_data_to_string( $option_label ) ) . '</option>';
		}
		echo '</select>';
	} elseif ( 'number' === $type ) {
		echo '<input type="number" class="small-text" min="1" max="65535" id="' . esc_attr( $html ) . '" name="' . esc_attr( $attribute ) . '" value="' . esc_attr( $value ) . '">';
	} else {
		echo '<input type="text" class="regular-text" id="' . esc_attr( $html ) . '" name="' . esc_attr( $attribute ) . '" value="' . esc_attr( $value ) . '">';
	}
	echo '</td></tr>';
}

/**
 * Een vak van het scherm Instellingen: kop, ondertitel en inhoud, als string.
 *
 * @param string $title   Kop.
 * @param string $sub     Ondertitel.
 * @param string $inner   Geëscapete HTML van de inhoud.
 * @param string $classes Extra klassen.
 * @param string $anchor  Id van het vak, of ''.
 * @return string Geëscapete HTML.
 */
function _ww_mail_render_box( string $title, string $sub, string $inner, string $classes = '', string $anchor = '' ): string {
	return '<section class="ww-mail-box' . ( '' !== $classes ? ' ' . esc_attr( $classes ) : '' ) . '"' . ( '' !== $anchor ? ' id="' . esc_attr( $anchor ) . '"' : '' ) . '>'
		. '<h2>' . esc_html( $title ) . '</h2><p class="ww-mail-box__sub">' . esc_html( $sub ) . '</p><div class="ww-mail-box__in">' . $inner . '</div></section>';
}

/**
 * De keuze van de aansluiting als radiokaarten, of (met WW_MAIL_TRANSPORT in wp-config.php) de vaste regel, als string.
 *
 * @param array<string,WW_Mail_Transport> $transports Beschikbare aansluitingen.
 * @param string                          $active     Id van de gekozen aansluiting.
 * @param string|null                     $constant   Waarde van WW_MAIL_TRANSPORT, of null.
 * @return string Geëscapete HTML.
 */
function _ww_mail_render_transport_choices( array $transports, string $active, ?string $constant ): string {
	if ( null !== $constant ) {
		$label = isset( $transports[ $active ] ) ? $transports[ $active ]->label() : $constant;
		return '<div class="ww-mail-fixed"><p>' . sprintf(
			/* translators: 1: naam van de aansluiting, 2: de naam van de constante. */
			esc_html__( '%1$s is vastgezet in wp-config.php (%2$s). Pas het daar aan om een andere aansluiting te kiezen.', 'webwerckt-base' ),
			'<strong>' . esc_html( $label ) . '</strong>',
			'<code>WW_MAIL_TRANSPORT</code>'
		) . '</p></div>';
	}

	$known = array(
		''      => array( __( 'De server', 'webwerckt-base' ), __( 'Werkt zonder iets in te stellen, maar komt vaker in de spam terecht.', 'webwerckt-base' ) ),
		'smtp'  => array( __( 'SMTP', 'webwerckt-base' ), __( 'Via de mailserver van je provider, met een gebruiker en een wachtwoord.', 'webwerckt-base' ) ),
		'brevo' => array( __( 'Brevo', 'webwerckt-base' ), __( 'Via Brevo, met een API-sleutel. Verstuurt alleen vanaf een geverifieerd adres of domein.', 'webwerckt-base' ) ),
	);
	$cards = array( '' => $known[''] );
	foreach ( $transports as $id => $transport ) {
		$cards[ $id ] = $known[ $id ] ?? array( $transport->label(), '' );
	}
	if ( '' !== $active && ! isset( $transports[ $active ] ) ) {
		/* translators: %s: id van de aansluiting. */
		$cards[ $active ] = array( sprintf( __( '%s (niet beschikbaar)', 'webwerckt-base' ), $active ), '' );
	}

	$html = '<fieldset class="ww-mail-choices"><legend class="screen-reader-text">' . esc_html__( 'Aansluiting', 'webwerckt-base' ) . '</legend>';
	foreach ( $cards as $id => $card ) {
		$id    = (string) $id;
		$html .= '<label class="ww-mail-choice"><input type="radio" name="ww_mail_transport" value="' . esc_attr( $id ) . '"' . checked( $active, $id, false ) . '><b>' . esc_html( $card[0] ) . '</b>'
			. ( '' !== $card[1] ? '<span>' . esc_html( $card[1] ) . '</span>' : '' ) . '</label>';
	}
	return $html . '</fieldset>';
}

/**
 * Toont het scherm Mail › Instellingen: drie vakken (aansluiting, afzender, testmail). Het ene formulier (Settings API)
 * bewaart de eerste twee; de testmail heeft een eigen formulier. WordPress toont meldingen alleen vanzelf boven schermen
 * onder Instellingen (options-head.php), dus dit scherm roept settings_errors() zelf aan; na opslaan geeft dat ook
 * "Instellingen opgeslagen". Zonder JavaScript werkt alles; mail-admin.js voegt alleen gemak toe.
 */
function _ww_mail_render_settings(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Je hebt geen rechten om de mailinstellingen te beheren.', 'webwerckt-base' ), 403 );
	}

	$transports = _ww_mail_transports();
	$constant   = _ww_mail_constant( 'WW_MAIL_TRANSPORT' );
	$active     = sanitize_key( _ww_mail_transport_id() );
	$unknown    = '' !== $active && ! isset( $transports[ $active ] );
	// Een andere mailplugin verstuurt de mail: de vakken zijn gedimd, maar niet disabled (options.php zou de opties leegmaken).
	$off = '' !== _ww_mail_foreign_mailer() ? 'ww-mail-box--off' : '';

	echo '<h1>' . esc_html__( 'Instellingen', 'webwerckt-base' ) . '</h1>';
	echo '<hr class="wp-header-end">';
	settings_errors( 'general' );
	settings_errors( 'ww_mail_from' );
	echo _ww_mail_admin_notices( 'settings' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_mail_admin_notices() escapet.
	if ( $unknown ) {
		/* translators: %s: id van de aansluiting. */
		echo '<div class="notice notice-error inline"><p>' . esc_html( sprintf( __( 'Aansluiting %s is niet beschikbaar.', 'webwerckt-base' ), $active ) ) . '</p></div>';
	}
	foreach ( _ww_mail_unreadable_secrets() as $text ) {
		echo '<div class="notice notice-error inline"><p>' . esc_html( $text ) . '</p></div>';
	}

	echo '<form method="post" action="' . esc_url( admin_url( 'options.php' ) ) . '">';
	settings_fields( WW_MAIL_SETTINGS_GROUP );

	// Vak 1: alle aansluitingen staan in het formulier; alleen de velden van de gekozen aansluiting zijn zichtbaar.
	$inner = _ww_mail_render_transport_choices( $transports, $active, $constant );
	foreach ( array_merge( array( '' ), array_keys( $transports ) ) as $id ) {
		$id        = (string) $id;
		$transport = $transports[ $id ] ?? null;
		$fields    = null === $transport ? array() : $transport->settings();
		if ( '' !== $id && ( null === $transport || array() === $fields ) ) {
			continue;
		}
		$inner .= '<div class="ww-mail-transport-fields" data-ww-mail-transport="' . esc_attr( $id ) . '"' . ( $id === $active ? '' : ' hidden' ) . '>';
		if ( null === $transport ) {
			$inner .= '<p class="description">' . esc_html__( 'Geen instellingen nodig. Stuur hieronder een testmail om te zien of hij aankomt, en kijk ook in de spammap.', 'webwerckt-base' ) . '</p>';
		} else {
			$inner .= '<h3>' . esc_html( $transport->label() ) . '</h3><table class="form-table" role="presentation"><tbody>';
			ob_start();
			foreach ( $fields as $field ) {
				_ww_mail_render_field( $id, $field );
			}
			$inner .= (string) ob_get_clean() . '</tbody></table>';
		}
		$inner .= '</div>';
	}
	echo _ww_mail_render_box( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_mail_render_box() escapet; $inner is hierboven ge-escaped opgebouwd.
		__( 'Hoe verstuurt de site mail?', 'webwerckt-base' ),
		__( 'De aansluiting voor alle mail: formulieren, wachtwoorden en meldingen van WordPress.', 'webwerckt-base' ),
		$inner,
		$off
	);

	// Vak 2: de afzender, met een voorbeeld van wat ontvangers zien.
	$from         = get_option( 'ww_mail_from', '' );
	$from         = is_string( $from ) ? $from : '';
	$from_name    = get_option( 'ww_mail_from_name', '' );
	$from_name    = is_string( $from_name ) ? $from_name : '';
	$shown_from   = _ww_mail_from_address();
	$shown_from   = '' !== $shown_from ? $shown_from : _ww_mail_wordpress_from();
	$default_from = '<' . _ww_mail_wordpress_from() . '>';

	ob_start();
	echo '<table class="form-table" role="presentation"><tbody>';
	echo '<tr><th scope="row"><label for="ww_mail_from_name">' . esc_html__( 'Naam', 'webwerckt-base' ) . '</label></th><td>';
	echo '<input type="text" class="regular-text" id="ww_mail_from_name" name="ww_mail_from_name" value="' . esc_attr( $from_name ) . '" placeholder="' . esc_attr( wp_specialchars_decode( (string) get_option( 'blogname', '' ), ENT_QUOTES ) ) . '">';
	echo '<p class="description">' . esc_html__( 'Leeg: de naam van de site.', 'webwerckt-base' ) . '</p></td></tr>';
	echo '<tr><th scope="row"><label for="ww_mail_from">' . esc_html__( 'E-mailadres', 'webwerckt-base' ) . '</label></th><td>';
	echo '<input type="email" class="regular-text" id="ww_mail_from" name="ww_mail_from" value="' . esc_attr( $from ) . '">';
	echo '<p class="description">' . esc_html__( 'Leeg: het standaardadres van WordPress.', 'webwerckt-base' ) . ' ' . esc_html__( 'Brevo verstuurt alleen vanaf een adres of domein dat je in Brevo hebt geverifieerd.', 'webwerckt-base' ) . '</p></td></tr>';
	echo '<tr><th scope="row">' . esc_html__( 'Altijd gebruiken', 'webwerckt-base' ) . '</th><td>';
	echo '<label><input type="checkbox" name="ww_mail_from_force" value="1"' . checked( _ww_mail_from_forced(), true, false ) . '> ';
	echo esc_html__( 'Ook als een plugin of formulier een ander Van-adres zet (Reply-To blijft staan).', 'webwerckt-base' ) . '</label></td></tr>';
	echo '</tbody></table>';
	echo '<p class="ww-mail-preview" data-default="' . esc_attr( $default_from ) . '"><span class="ww-mail-preview__k">' . esc_html__( 'Ontvangers zien:', 'webwerckt-base' ) . '</span> <b id="ww-mail-preview-name">' . esc_html( _ww_mail_from_name_value() ) . '</b> <span id="ww-mail-preview-address">' . esc_html( '<' . $shown_from . '>' ) . '</span></p>';
	$inner = (string) ob_get_clean();
	echo _ww_mail_render_box( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_mail_render_box() escapet; $inner is hierboven ge-escaped opgebouwd.
		__( 'Afzender', 'webwerckt-base' ),
		__( 'Wat ontvangers zien als afzender van de mail.', 'webwerckt-base' ),
		$inner,
		$off
	);

	submit_button();
	echo '</form>';

	// Vak 3: de testmail, met zijn resultaat erin.
	ob_start();
	// Niet settings_errors(): zonder "inline" verplaatst common.js de melding naar boven, uit dit vak.
	foreach ( get_settings_errors( 'ww_mail' ) as $notice ) {
		$type = 'updated' === $notice['type'] ? 'success' : (string) $notice['type'];
		echo '<div class="notice notice-' . esc_attr( $type ) . ' inline"><p>' . wp_kses_post( (string) $notice['message'] ) . '</p></div>';
	}
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	echo '<input type="hidden" name="action" value="ww_mail_test">';
	wp_nonce_field( 'ww_mail_test' );
	echo '<label for="ww_mail_test_to">' . esc_html__( 'Aan', 'webwerckt-base' ) . '</label> ';
	echo '<input type="email" class="regular-text" id="ww_mail_test_to" name="ww_mail_test_to" value="' . esc_attr( (string) get_option( 'admin_email', '' ) ) . '" required> ';
	submit_button( __( 'Testmail versturen', 'webwerckt-base' ), 'secondary', 'submit', false );
	echo '</form>';
	$inner = (string) ob_get_clean();
	echo _ww_mail_render_box( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_mail_render_box() escapet; $inner is hierboven ge-escaped opgebouwd.
		__( 'Testmail versturen', 'webwerckt-base' ),
		__( 'Verstuurt een korte mail met de opgeslagen instellingen. Hij komt ook in het logboek.', 'webwerckt-base' ),
		$inner,
		'',
		'ww-mail-test'
	);
}

/**
 * Naam van de aansluiting die nu de mail verstuurt, voor in de testmail.
 */
function _ww_mail_active_label(): string {
	if ( '' !== _ww_mail_foreign_mailer() ) {
		return __( 'WP Mail SMTP', 'webwerckt-base' );
	}
	$id = _ww_mail_transport_id();
	if ( '' === $id ) {
		return __( 'Geen (de server)', 'webwerckt-base' );
	}
	$transport = _ww_mail_transport();
	return null === $transport ? $id : $transport->label();
}

/**
 * Verstuurt de testmail via de gewone weg (dus ook in de log).
 *
 * @param string $to Adres.
 * @return true|string True, of de foutmelding uit wp_mail_failed.
 */
function _ww_mail_send_test( string $to ): true|string {
	$site    = wp_specialchars_decode( (string) get_bloginfo( 'name' ), ENT_QUOTES );
	$message = sprintf(
		/* translators: 1: naam van de site, 2: naam van de aansluiting, 3: datum en tijd. */
		__( "Dit is een testmail van %1\$s.\n\nAansluiting: %2\$s\nVerstuurd op: %3\$s", 'webwerckt-base' ),
		$site,
		_ww_mail_active_label(),
		wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) )
	);

	$error    = '';
	$listener = static function ( $wp_error ) use ( &$error ): void {
		if ( is_wp_error( $wp_error ) ) {
			$error = $wp_error->get_error_message();
		}
	};
	add_action( 'wp_mail_failed', $listener );
	try {
		/* translators: %s: naam van de site. */
		$sent = wp_mail( $to, sprintf( __( 'Testmail van %s', 'webwerckt-base' ), $site ), $message );
	} finally {
		remove_action( 'wp_mail_failed', $listener );
	}
	if ( $sent ) {
		return true;
	}
	return '' !== $error ? $error : __( 'De mail is niet verstuurd.', 'webwerckt-base' );
}

/**
 * Verstuurt de testmail (admin-post.php, action ww_mail_test) en stuurt terug naar het scherm met het resultaat.
 */
function _ww_mail_test_handle(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Je hebt geen rechten om een testmail te versturen.', 'webwerckt-base' ), 403 );
	}
	check_admin_referer( 'ww_mail_test' );

	$to = isset( $_POST['ww_mail_test_to'] ) ? sanitize_email( _ww_data_to_string( wp_unslash( $_POST['ww_mail_test_to'] ) ) ) : '';
	if ( '' === $to || ! is_email( $to ) ) {
		$message = __( 'Vul een geldig e-mailadres in voor de testmail.', 'webwerckt-base' );
		$type    = 'error';
	} else {
		$result = _ww_mail_send_test( $to );
		if ( true === $result ) {
			/* translators: %s: e-mailadres. */
			$message = sprintf( __( 'Testmail verstuurd naar %s.', 'webwerckt-base' ), $to );
			$type    = 'success';
		} else {
			/* translators: %s: foutmelding. */
			$message = sprintf( __( 'De testmail is niet verstuurd: %s', 'webwerckt-base' ), $result );
			$type    = 'error';
		}
	}

	$html = esc_html( $message );
	if ( 'success' === $type ) {
		$html .= ' <a href="' . esc_url( _ww_mail_log_url() ) . '">' . esc_html__( 'Bekijk in het logboek', 'webwerckt-base' ) . '</a>';
	}
	add_settings_error( 'ww_mail', 'ww_mail_test', $html, $type );
	set_transient( 'settings_errors', get_settings_errors(), 30 );
	if ( wp_safe_redirect( _ww_mail_settings_url( array( 'settings-updated' => 'true' ) ) . '#ww-mail-test' ) ) {
		exit;
	}
}
add_action( 'admin_post_ww_mail_test', '_ww_mail_test_handle' );
