<?php
/**
 * SEO in de admin (ADR 0024): een teller onder de SEO-titel en -beschrijving, een kolom SEO in de berichtenlijst en
 * een test in Site-status. Alle drie gebruiken hetzelfde oordeel (_ww_seo_post_report()), met de grenzen van
 * _ww_seo_length_limits() in inc/seo.php. Naast een SEO-plugin doet dit bestand niets.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Post types waarvan de pod de groep SEO heeft.
 *
 * @return string[]
 */
function _ww_seo_admin_post_types(): array {
	if ( ! _ww_seo_enabled() ) {
		return array();
	}
	return array_values(
		array_filter(
			_ww_seo_post_types(),
			static fn( string $type ): bool => in_array( 'ww_seo_title', array_column( _ww_pods_fields( $type ), 'name' ), true )
		)
	);
}

/**
 * Het SEO-oordeel over één bericht: noindex, en voor titel en beschrijving de lengte van het eigen veld (missing,
 * short, long of good); de voorpagina telt de homepagetitel en -beschrijving uit de Site-instellingen mee. Afbeelding: good met een eigen of uitgelichte afbeelding, anders missing.
 *
 * @return array{noindex:bool,title:string,description:string,image:string}
 */
function _ww_seo_post_report( int $post_id ): array {
	$image = _ww_data_to_attachment_id( _ww_data_get_stored( 'ww_seo_image', $post_id ) ) ?: (int) get_post_thumbnail_id( $post_id );
	$title       = _ww_data_to_string( _ww_data_get_stored( 'ww_seo_title', $post_id ) );
	$description = _ww_data_to_string( _ww_data_get_stored( 'ww_seo_description', $post_id ) );
	// De voorpagina (met Meertalig ook haar vertalingen) valt terug op de homepagetitel en -beschrijving uit de
	// Site-instellingen in haar taal (_ww_seo_own_title()).
	if ( '' === _ww_plain_text( $title ) ) {
		$title = _ww_seo_front_page_setting( $post_id, 'seo_home_title' ) ?? $title;
	}
	if ( '' === _ww_plain_text( $description ) ) {
		$description = _ww_seo_front_page_setting( $post_id, 'seo_home_description' ) ?? $description;
	}
	return array(
		'noindex'     => _ww_seo_post_noindex( $post_id ),
		'title'       => _ww_seo_length_status( 'title', $title ),
		'description' => _ww_seo_length_status( 'description', $description ),
		'image'       => $image > 0 ? 'good' : 'missing',
	);
}

/**
 * De homepagetitel of -beschrijving uit de Site-instellingen voor een voorpagina, als gewone tekst, in de taal van de
 * pagina: dezelfde tekst die de site op die pagina toont (_ww_seo_own_title() en _ww_seo_description() lezen de
 * instelling in de huidige taal). Met Meertalig is ook een vertaling van de voorpagina (/en/) een voorpagina.
 *
 * @param int    $post_id Het bericht.
 * @param string $setting seo_home_title of seo_home_description.
 * @return string|null null als het bericht geen voorpagina is, '' als de instelling leeg is.
 */
function _ww_seo_front_page_setting( int $post_id, string $setting ): ?string {
	if ( $post_id <= 0 || 'page' !== get_option( 'show_on_front' ) ) {
		return null;
	}
	$lang = '';
	if ( _ww_languages_active() ) {
		if ( ! _ww_languages_is_front_page( $post_id ) ) {
			return null;
		}
		$lang = _ww_post_language( $post_id );
	} elseif ( (int) get_option( 'page_on_front' ) !== $post_id ) {
		// Zonder Meertalig telt een oude vertaalkoppeling niet: alleen de voorpagina zelf.
		return null;
	}
	return _ww_plain_text( _ww_data_to_string( _ww_data_get_setting( $setting, $lang ) ) );
}

/**
 * Woorden bij een oordeel, voor de kolom en de teller.
 *
 * @return array<string,string>
 */
function _ww_seo_status_labels(): array {
	return array(
		'missing' => __( 'ontbreekt', 'webwerckt-base' ),
		'short'   => __( 'te kort', 'webwerckt-base' ),
		'long'    => __( 'te lang', 'webwerckt-base' ),
		'good'    => __( 'goed', 'webwerckt-base' ),
	);
}

/**
 * Kleuren van de teller en de kolom.
 */
function _ww_seo_admin_css(): string {
	return '.ww-seo-count{margin:4px 0 0;font-weight:600}'
		. '.ww-seo-badges{display:flex;gap:4px}'
		. '.ww-seo-badge{display:inline-block;min-width:1.6em;padding:0 4px;border-radius:3px;text-align:center;font-weight:600;color:#fff}'
		. '[data-ww-seo="missing"]{background:#d63638;color:#fff}'
		. '[data-ww-seo="short"],[data-ww-seo="long"]{background:#dba617;color:#1d2327}'
		. '[data-ww-seo="good"]{background:#00a32a;color:#fff}'
		. '.ww-seo-count[data-ww-seo]{background:none}'
		. '.ww-seo-count[data-ww-seo="missing"]{color:#d63638}.ww-seo-count[data-ww-seo="short"],.ww-seo-count[data-ww-seo="long"]{color:#996800}.ww-seo-count[data-ww-seo="good"]{color:#008a20}'
		. '.column-ww_seo{width:7.5em}';
}

/**
 * Teller op het bewerkscherm en kleuren in de berichtenlijst, bij post types met de groep SEO.
 *
 * @param string $hook Admin-scherm.
 */
function _ww_seo_admin_enqueue( $hook ): void {
	if ( ! in_array( $hook, array( 'post.php', 'post-new.php', 'edit.php' ), true ) ) {
		return;
	}
	$screen = get_current_screen();
	if ( ! $screen instanceof WP_Screen || ! in_array( $screen->post_type, _ww_seo_admin_post_types(), true ) ) {
		return;
	}
	wp_register_style( 'ww-seo-admin', false, array(), WW_BASE_VERSION );
	wp_enqueue_style( 'ww-seo-admin' );
	wp_add_inline_style( 'ww-seo-admin', _ww_seo_admin_css() );
	if ( 'edit.php' === $hook ) {
		return;
	}

	$post = get_post();
	_ww_seo_admin_counter_script( $post instanceof WP_Post ? $post->ID : 0 );
}
add_action( 'admin_enqueue_scripts', '_ww_seo_admin_enqueue' );

/**
 * De instellingen van de teller (assets/js/seo-admin.js, window.wwSeo): grenzen, de sitenaam achter een lege titel en
 * de woorden. Voor het bewerkscherm en het formulier op het scherm SEO.
 *
 * Bij de voorpagina (met Meertalig ook een vertaling ervan) ook home: de homepagetitel en -beschrijving uit de
 * Site-instellingen in de taal van de pagina (_ww_seo_front_page_setting()). Een leeg veld valt daarop terug, en de
 * teller beoordeelt dan die tekst, net als _ww_seo_post_report() voor de kolom en het overzicht. Zonder terugval is
 * een leeg veld "ontbreekt", ook als WordPress er zelf iets van maakt: hetzelfde oordeel als de kolom.
 *
 * @param int $post_id Het bericht op het scherm, of 0.
 * @return array<string,mixed>
 */
function _ww_seo_admin_config( int $post_id = 0 ): array {
	$config = array(
		'limits' => _ww_seo_length_limits(),
		'suffix' => ' ' . _ww_data_to_string( _ww_seo_title_separator( '-' ) ) . ' ' . _ww_plain_text( get_bloginfo( 'name' ) ),
		'labels' => _ww_seo_status_labels() + array(
			/* translators: 1: aantal tekens, 2: maximum, 3: oordeel. */
			'count'        => __( '%1$d van %2$d tekens: %3$s', 'webwerckt-base' ),
			/* translators: %1$d: aantal tekens. */
			'fallback'     => __( 'Ontbreekt. Leeg, dus de titel van de pagina met de sitenaam (%1$d tekens).', 'webwerckt-base' ),
			'fallbackText' => __( 'Ontbreekt. Leeg, dus het begin van de tekst van de pagina.', 'webwerckt-base' ),
			/* translators: 1: aantal tekens, 2: oordeel. */
			'fallbackHome' => __( 'Leeg, dus de tekst uit de Site-instellingen: %1$d tekens, %2$s', 'webwerckt-base' ),
		),
	);
	$home_title = _ww_seo_front_page_setting( $post_id, 'seo_home_title' );
	if ( null !== $home_title ) {
		$config['home'] = array(
			'title'       => $home_title,
			'description' => (string) _ww_seo_front_page_setting( $post_id, 'seo_home_description' ),
		);
	}
	return $config;
}

/**
 * Laadt de teller met zijn instellingen en kleuren.
 *
 * @param int $post_id Het bericht op het scherm, of 0.
 */
function _ww_seo_admin_counter_script( int $post_id = 0 ): void {
	if ( ! wp_style_is( 'ww-seo-admin' ) ) {
		wp_register_style( 'ww-seo-admin', false, array(), WW_BASE_VERSION );
		wp_enqueue_style( 'ww-seo-admin' );
		wp_add_inline_style( 'ww-seo-admin', _ww_seo_admin_css() );
	}
	wp_enqueue_script( 'ww-seo-admin', _ww_asset_url( 'js/seo-admin.js' ), array(), WW_BASE_VERSION, array( 'in_footer' => true ) );
	wp_add_inline_script( 'ww-seo-admin', 'window.wwSeo = ' . wp_json_encode( _ww_seo_admin_config( $post_id ), JSON_HEX_TAG | JSON_HEX_AMP ) . ';', 'before' );
}

/**
 * Meldt de kolom SEO aan bij elk post type met de groep SEO.
 */
function _ww_seo_admin_columns(): void {
	foreach ( _ww_seo_admin_post_types() as $type ) {
		add_filter( "manage_{$type}_posts_columns", '_ww_seo_add_column' );
		add_action( "manage_{$type}_posts_custom_column", '_ww_seo_render_column', 10, 2 );
	}
}
add_action( 'admin_init', '_ww_seo_admin_columns' );

/**
 * De kolom SEO, na de titel.
 *
 * @param mixed $columns Kolommen van WordPress.
 * @return mixed
 */
function _ww_seo_add_column( $columns ) {
	if ( ! is_array( $columns ) ) {
		return $columns;
	}
	$out = array();
	foreach ( $columns as $key => $label ) {
		$out[ $key ] = $label;
		if ( 'title' === $key ) {
			$out['ww_seo'] = __( 'SEO', 'webwerckt-base' );
		}
	}
	return $out + array( 'ww_seo' => __( 'SEO', 'webwerckt-base' ) );
}

/**
 * De HTML van de kolom SEO voor één bericht: drie aanduidingen (titel, beschrijving, afbeelding), of noindex. De meta
 * van de lijst heeft WordPress al in één query geladen.
 */
function _ww_seo_column_html( int $post_id ): string {
	$report = _ww_seo_post_report( $post_id );
	if ( $report['noindex'] ) {
		return '<span title="' . esc_attr__( 'Verborgen voor zoekmachines (noindex)', 'webwerckt-base' ) . '">noindex</span>';
	}
	$labels = _ww_seo_status_labels();
	$parts  = array(
		'title'       => array( __( 'T', 'webwerckt-base' ), __( 'Titel', 'webwerckt-base' ) ),
		'description' => array( __( 'B', 'webwerckt-base' ), __( 'Beschrijving', 'webwerckt-base' ) ),
		'image'       => array( __( 'A', 'webwerckt-base' ), __( 'Afbeelding', 'webwerckt-base' ) ),
	);
	$html   = '';
	foreach ( $parts as $key => $part ) {
		$status = $report[ $key ];
		$text   = $part[1] . ': ' . $labels[ $status ];
		$html  .= sprintf(
			'<span class="ww-seo-badge" data-ww-seo="%1$s" title="%2$s" aria-hidden="true">%3$s</span><span class="screen-reader-text">%2$s</span>',
			esc_attr( $status ),
			esc_attr( $text ),
			esc_html( $part[0] )
		);
	}
	return '<span class="ww-seo-badges">' . $html . '</span>';
}

/**
 * Vult de kolom SEO.
 *
 * @param string $column  Kolom.
 * @param int    $post_id Bericht-ID.
 */
function _ww_seo_render_column( $column, $post_id ): void {
	if ( 'ww_seo' === $column ) {
		echo _ww_seo_column_html( (int) $post_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- ge-escaped in _ww_seo_column_html().
	}
}

/**
 * Per post type met de groep SEO: hoeveel gepubliceerde berichten (zonder noindex) een titel, beschrijving of
 * afbeelding missen, en hoeveel een titel of beschrijving van een verkeerde lengte hebben.
 *
 * @return array<string,array{label:string,total:int,title:int,description:int,image:int,length:int}>
 */
function _ww_seo_missing_counts(): array {
	$out = array();
	foreach ( _ww_seo_admin_post_types() as $type ) {
		$ids = get_posts(
			array(
				'post_type'      => $type,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		$prime = array_values( array_filter( array_map( 'intval', $ids ), static fn( int $id ): bool => $id > 0 ) );
		if ( array() !== $prime ) {
			// Berichten en velden in één keer: get_post_thumbnail_id() leest het bericht zelf.
			_prime_post_caches( $prime, false, true );
		}
		$object = get_post_type_object( $type );
		$counts = array(
			'label'       => $object instanceof WP_Post_Type ? (string) $object->labels->name : $type,
			'total'       => 0,
			'title'       => 0,
			'description' => 0,
			'image'       => 0,
			'length'      => 0,
		);
		foreach ( $ids as $id ) {
			$report = _ww_seo_post_report( (int) $id );
			if ( $report['noindex'] ) {
				continue;
			}
			++$counts['total'];
			$counts['title']       += (int) ( 'missing' === $report['title'] );
			$counts['description'] += (int) ( 'missing' === $report['description'] );
			$counts['image']       += (int) ( 'missing' === $report['image'] );
			$counts['length']      += (int) ( array() !== array_intersect( array( 'short', 'long' ), array( $report['title'], $report['description'] ) ) );
		}
		$out[ $type ] = $counts;
	}
	return $out;
}

/**
 * Test in Site-status: doet het thema de SEO, en missen pagina's een titel, beschrijving of afbeelding?
 *
 * @return array<string,mixed>
 */
function _ww_seo_health(): array {
	$badge  = __( 'SEO', 'webwerckt-base' );
	$plugin = _ww_seo_plugin();
	if ( '' !== $plugin ) {
		/* translators: %s: naam van de SEO-plugin. */
		$text = sprintf( __( '%s is actief. Het thema zet daarom geen titels, beschrijvingen, canonical, Open Graph of sitemap-filters (beslissing 0024). Zet de plugin uit om de SEO van het thema te gebruiken.', 'webwerckt-base' ), $plugin );
		return _ww_health_result( 'ww_seo', __( 'SEO komt van een plugin', 'webwerckt-base' ), 'recommended', '<p>' . esc_html( $text ) . '</p>', $badge );
	}
	if ( ! _ww_seo_enabled() ) {
		return _ww_health_result( 'ww_seo', __( 'SEO van het thema staat uit', 'webwerckt-base' ), 'recommended', '<p>' . esc_html__( 'Het filter ww_seo zet de SEO van het thema uit, en er is geen SEO-plugin.', 'webwerckt-base' ) . '</p>', $badge );
	}

	$lines = array();
	foreach ( _ww_seo_missing_counts() as $counts ) {
		if ( 0 === $counts['title'] + $counts['description'] + $counts['image'] + $counts['length'] ) {
			continue;
		}
		/* translators: 1: post type, 2: aantal pagina's, 3: zonder titel, 4: zonder beschrijving, 5: zonder afbeelding, 6: verkeerde lengte. */
		$lines[] = sprintf( __( '%1$s (%2$d): %3$d zonder eigen titel, %4$d zonder eigen beschrijving, %5$d zonder afbeelding, %6$d met een titel of beschrijving van een verkeerde lengte.', 'webwerckt-base' ), $counts['label'], $counts['total'], $counts['title'], $counts['description'], $counts['image'], $counts['length'] );
	}
	$text = '<p>' . esc_html__( 'Het thema zet titels, beschrijvingen, canonical, robots, Open Graph en de sitemap. De kolom SEO in de berichtenlijsten toont per pagina wat er ontbreekt.', 'webwerckt-base' ) . '</p>';
	$link = '<p><a href="' . esc_url( _ww_seo_admin_url() ) . '">' . esc_html__( 'Alle meldingen', 'webwerckt-base' ) . '</a></p>';
	if ( array() === $lines ) {
		return _ww_health_result( 'ww_seo', __( 'Alle pagina\'s hebben een eigen titel, beschrijving en afbeelding', 'webwerckt-base' ), 'good', $text . $link, $badge );
	}
	$text .= '<ul><li>' . implode( '</li><li>', array_map( 'esc_html', $lines ) ) . '</li></ul>' . $link;
	return _ww_health_result( 'ww_seo', __( 'Pagina\'s missen een eigen titel, beschrijving of afbeelding', 'webwerckt-base' ), 'recommended', $text, $badge );
}

/**
 * Meldt de test in Site-status aan.
 *
 * @param array<string,array<string,mixed>> $tests Tests van WordPress.
 * @return array<string,array<string,mixed>>
 */
function _ww_seo_health_test( array $tests ): array {
	$tests['direct']['ww_seo'] = array(
		'label' => __( 'SEO', 'webwerckt-base' ),
		'test'  => '_ww_seo_health',
	);
	return $tests;
}
add_filter( 'site_status_tests', '_ww_seo_health_test' );
