<?php
/**
 * Activiteitenlog (beslissing 0033): tabel, actor, buffer per verzoek en schrijven.
 *
 * Het thema houdt 30 dagen bij wie (mens, agent of WP-CLI) welke inhoud en instellingen heeft veranderd. Gebeurtenissen
 * komen in een buffer, één regel per object; op shutdown gaat de buffer met één INSERT naar de tabel {prefix}ww_activity.
 * Het schema wordt bij admin_init en na een themawissel aangelegd, net als bij redirects en formulieren. Het log laat een
 * opslag nooit mislukken. Tijden staan in UTC. Er worden nooit veldwaarden, IP-adressen of user agents bewaard.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const WW_ACTIVITY_DB_VERSION  = '1';
const WW_ACTIVITY_MAX_OBJECTS = 500;
const WW_ACTIVITY_MAX_FIELDS  = 50;
const WW_ACTIVITY_CLEANUP_HOOK = 'ww_activity_cleanup';

/**
 * Naam van de tabel met activiteit.
 */
function _ww_activity_table(): string {
	global $wpdb;
	return $wpdb->prefix . 'ww_activity';
}

/**
 * Legt de tabel aan (of werkt hem bij) en bewaart de schemaversie.
 */
function _ww_activity_install(): void {
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';

	dbDelta(
		'CREATE TABLE ' . _ww_activity_table() . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  created datetime NOT NULL,
  user_id bigint(20) unsigned NOT NULL DEFAULT 0,
  user_name varchar(250) NOT NULL DEFAULT '',
  actor varchar(10) NOT NULL DEFAULT '',
  agent varchar(190) NOT NULL DEFAULT '',
  action varchar(20) NOT NULL DEFAULT '',
  object_type varchar(20) NOT NULL DEFAULT '',
  object_subtype varchar(100) NOT NULL DEFAULT '',
  object_id bigint(20) unsigned NOT NULL DEFAULT 0,
  object_title varchar(250) NOT NULL DEFAULT '',
  fields text NOT NULL,
  PRIMARY KEY  (id),
  KEY created (created),
  KEY user_id (user_id),
  KEY actor (actor),
  KEY object (object_type,object_id)
) " . $wpdb->get_charset_collate() . ';'
	);

	// Alleen als de tabel er echt is, is het schema klaar. Een SELECT in plaats van SHOW TABLES: die laat tijdelijke tabellen (de testsuite) niet zien.
	$suppressed = $wpdb->suppress_errors( true );
	$complete   = false !== $wpdb->query( 'SELECT 1 FROM ' . _ww_activity_table() . ' LIMIT 1' ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_activity_table().
	$wpdb->suppress_errors( $suppressed );
	if ( ! $complete ) {
		return;
	}

	update_option( 'ww_activity_db_version', WW_ACTIVITY_DB_VERSION, true );
	wp_set_option_autoload( 'ww_activity_db_version', true );
}

/**
 * Is de tabel aangelegd voor deze schemaversie? Leest alleen de optie.
 */
function _ww_activity_ready(): bool {
	return WW_ACTIVITY_DB_VERSION === (string) get_option( 'ww_activity_db_version' );
}

add_action(
	'admin_init',
	static function (): void {
		if ( ! _ww_activity_ready() ) {
			_ww_activity_install();
		}
	}
);
add_action( 'after_switch_theme', '_ww_activity_install' );

/**
 * Interne toestand per verzoek: de buffer, de objecten die boven het maximum kwamen en de bewaarde actor.
 *
 * @return array{buffer:array<string,array<string,mixed>>,overflow:array<string,true>,added:array<string,true>,actor:array{user:int,value:?array<string,mixed>}|null}
 */
function &_ww_activity_state(): array {
	static $state = array(
		'buffer'   => array(),
		'overflow' => array(),
		'added'    => array(),
		'actor'    => null,
	);
	return $state;
}

/**
 * Wie doet dit? Null betekent niets loggen (cron, of niemand ingelogd). Per verzoek bewaard, per gebruiker.
 *
 * @return array{actor:string,agent:string,user_id:int,user_name:string}|null
 */
function _ww_activity_actor(): ?array {
	$state   = &_ww_activity_state();
	$user_id = (int) get_current_user_id();
	if ( null !== $state['actor'] && $state['actor']['user'] === $user_id ) {
		return $state['actor']['value'];
	}

	$value = null;
	if ( $user_id > 0 && ! wp_doing_cron() ) {
		$actor = 'human';
		$agent = '';
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			$actor = 'cli';
		} else {
			$uuid = function_exists( 'rest_get_authenticated_app_password' ) ? rest_get_authenticated_app_password() : null;
			if ( is_string( $uuid ) && '' !== $uuid ) {
				$actor = 'agent';
				$item  = WP_Application_Passwords::get_user_application_password( $user_id, $uuid );
				if ( is_array( $item ) ) {
					$agent = mb_substr( $item['name'], 0, 190 );
				}
			}
		}
		$value = array(
			'actor'     => $actor,
			'agent'     => $agent,
			'user_id'   => $user_id,
			'user_name' => mb_substr( (string) wp_get_current_user()->display_name, 0, 250 ),
		);
	}

	$state['actor'] = array(
		'user'  => $user_id,
		'value' => $value,
	);
	return $value;
}

/**
 * Voegt een gebeurtenis toe aan de buffer van dit verzoek. Doet niets zonder actor en gooit nooit een fout.
 *
 * @param string     $type    post, attachment, menu, settings, option, redirect of bulk.
 * @param int|string $id      Object-ID; bij settings de slug van de pagina, bij opties de optienaam.
 * @param string     $action  created, duplicated, updated, published, unpublished, trashed, restored, deleted, uploaded of imported.
 * @param array<int,mixed> $fields  Namen van de gewijzigde velden.
 * @param string     $subtype Post type, settings-pagina, optienaam of ''.
 * @param string     $title   Titel van het object op dit moment.
 */
function _ww_activity_add( string $type, int|string $id, string $action, array $fields = array(), string $subtype = '', string $title = '' ): void {
	try {
		static $rank = array(
			'deleted'     => 10,
			'trashed'     => 9,
			'restored'    => 8,
			'duplicated'  => 7,
			'created'     => 6,
			'published'   => 5,
			'unpublished' => 4,
			'uploaded'    => 3,
			'imported'    => 2,
			'updated'     => 1,
		);
		if ( '' === $type || ! isset( $rank[ $action ] ) || null === _ww_activity_actor() ) {
			return;
		}

		$state = &_ww_activity_state();
		$key   = $type . ':' . $id;
		$names = array();
		foreach ( $fields as $field ) {
			if ( is_string( $field ) && '' !== $field ) {
				$names[] = $field;
			}
		}

		if ( ! isset( $state['buffer'][ $key ] ) ) {
			if ( count( $state['buffer'] ) >= WW_ACTIVITY_MAX_OBJECTS ) {
				$state['overflow'][ $key ] = true;
				return;
			}
			$state['buffer'][ $key ] = array(
				'type'    => $type,
				'id'      => ( is_int( $id ) || ctype_digit( $id ) ) ? max( 0, (int) $id ) : 0,
				'subtype' => $subtype,
				'action'  => $action,
				'fields'  => array_values( array_unique( $names ) ),
				'title'   => $title,
			);
			return;
		}

		$entry       = &$state['buffer'][ $key ];
		$was_deleted = 'deleted' === $entry['action'];
		if ( $rank[ $action ] > $rank[ $entry['action'] ] ) {
			$entry['action'] = $action;
		}
		$entry['fields'] = array_values( array_unique( array_merge( $entry['fields'], $names ) ) );
		if ( '' !== $subtype && '' === $entry['subtype'] ) {
			$entry['subtype'] = $subtype;
		}
		// De titel volgt de laatste gebeurtenis, behalve na verwijderen: dan blijft die van vóór het verwijderen staan.
		if ( '' !== $title && ! $was_deleted ) {
			$entry['title'] = $title;
		}
	} catch ( \Throwable $e ) {
		return;
	}
}

/**
 * Schrijft de buffer met één INSERT en leegt hem. Zonder tabel of met een andere schemaversie gebeurt er niets.
 */
function _ww_activity_flush(): void {
	try {
		global $wpdb;
		$state    = &_ww_activity_state();
		$buffer   = $state['buffer'];
		$overflow = count( $state['overflow'] );
		$state['buffer']   = array();
		$state['overflow'] = array();

		if ( array() === $buffer && 0 === $overflow ) {
			return;
		}
		$actor = _ww_activity_actor();
		if ( null === $actor || ! _ww_activity_ready() ) {
			return;
		}

		$now    = gmdate( 'Y-m-d H:i:s' );
		$values = array();
		$row    = static function ( string $type, string $subtype, int $object_id, string $action, string $title, array $fields ) use ( $wpdb, $actor, $now ): string {
			return (string) $wpdb->prepare(
				'(%s,%d,%s,%s,%s,%s,%s,%s,%d,%s,%s)',
				$now,
				$actor['user_id'],
				$actor['user_name'],
				$actor['actor'],
				$actor['agent'],
				$action,
				$type,
				mb_substr( $subtype, 0, 100 ),
				$object_id,
				mb_substr( $title, 0, 250 ),
				(string) ( wp_json_encode( $fields, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ?: '[]' )
			);
		};

		foreach ( $buffer as $entry ) {
			$fields = $entry['fields'];
			if ( 'updated' === $entry['action'] && array() === $fields && in_array( $entry['type'], array( 'post', 'attachment' ), true ) ) {
				continue;
			}
			if ( 'deleted' === $entry['action'] ) {
				$fields = array();
			} elseif ( count( $fields ) > WW_ACTIVITY_MAX_FIELDS ) {
				$fields   = array_slice( $fields, 0, WW_ACTIVITY_MAX_FIELDS );
				$fields[] = '…';
			}
			$values[] = $row( $entry['type'], $entry['subtype'], $entry['id'], $entry['action'], $entry['title'], $fields );
		}
		if ( $overflow > 0 ) {
			/* translators: %d: aantal objecten dat niet apart in het log staat. */
			$values[] = $row( 'bulk', '', 0, 'updated', sprintf( __( 'en %d meer', 'webwerckt-base' ), $overflow ), array() );
		}
		if ( array() === $values ) {
			return;
		}

		$result = $wpdb->query( // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- waarden zijn per rij met prepare() opgebouwd.
			'INSERT INTO ' . _ww_activity_table() . ' (created,user_id,user_name,actor,agent,action,object_type,object_subtype,object_id,object_title,fields) VALUES ' . implode( ',', $values )
		);
		if ( false === $result ) {
			error_log( 'ww activity: ' . $wpdb->last_error ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- het log mag een opslag niet laten mislukken.
		}
	} catch ( \Throwable $e ) {
		error_log( 'ww activity: ' . $e->getMessage() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- het log mag een opslag niet laten mislukken.
	}
}
add_action( 'shutdown', '_ww_activity_flush', 1 );

/**
 * Leegt de buffer en de bewaarde actor. Alleen voor tests.
 */
function _ww_activity_reset(): void {
	$state             = &_ww_activity_state();
	$state['buffer']   = array();
	$state['overflow'] = array();
	$state['added']    = array();
	$state['actor']    = null;
}

/**
 * De buffer van dit verzoek, alleen lezen. Voor tests.
 *
 * @return array<string,array<string,mixed>>
 */
function _ww_activity_buffer(): array {
	return _ww_activity_state()['buffer'];
}

/**
 * Wordt dit post type gelogd? Media hebben een eigen soort (attachment) en vallen hier buiten.
 */
function _ww_activity_post_type_logged( string $post_type ): bool {
	if ( '' === $post_type ) {
		return false;
	}
	$ignored = array( 'revision', 'nav_menu_item', 'customize_changeset', 'oembed_cache', 'user_request', 'wp_global_styles', 'attachment' );
	/**
	 * Post types die niet in het activiteitenlog komen, bovenop de vaste lijst.
	 *
	 * @param string[] $extra Post types.
	 */
	$extra = apply_filters( 'ww_activity_ignore_post_types', array() );
	$ignored = array_merge( $ignored, array_filter( $extra, 'is_string' ) );
	return ! in_array( $post_type, $ignored, true );
}

/**
 * Veldnaam in het log voor een metasleutel, of null als de sleutel genegeerd wordt.
 */
function _ww_activity_meta_name( string $key ): ?string {
	if ( '' === $key ) {
		return null;
	}
	$names = array(
		'_thumbnail_id'    => 'featured_image',
		'_wp_page_template' => 'page_template',
		'_ww_form'         => 'form_config',
	);
	if ( '_' === $key[0] && ! isset( $names[ $key ] ) ) {
		return null;
	}
	/**
	 * Metasleutels die niet in het activiteitenlog komen.
	 *
	 * @param string[] $keys Sleutels.
	 */
	$ignored = apply_filters( 'ww_activity_ignore_meta', array() );
	if ( in_array( $key, $ignored, true ) ) {
		return null;
	}
	return $names[ $key ] ?? $key;
}

/**
 * Het bericht als het gelogd moet worden: geen revisie of autosave, geen auto-draft en een gelogd post type.
 *
 * @param mixed $post Bericht of bericht-ID.
 */
function _ww_activity_loggable_post( $post ): ?WP_Post {
	$post = is_numeric( $post ) ? get_post( (int) $post ) : $post;
	if ( ! $post instanceof WP_Post || 'auto-draft' === $post->post_status ) {
		return null;
	}
	if ( ! _ww_activity_post_type_logged( $post->post_type ) || wp_is_post_revision( $post ) || wp_is_post_autosave( $post ) ) {
		return null;
	}
	return $post;
}

/**
 * Statuswijziging: aangemaakt, gepubliceerd, offline gehaald, in de prullenbak of teruggezet.
 *
 * @param mixed $new_status Nieuwe status.
 * @param mixed $old_status Oude status.
 * @param mixed $post       Bericht.
 */
function _ww_activity_on_transition( $new_status, $old_status, $post ): void {
	try {
		if ( null === _ww_activity_actor() || ! is_string( $new_status ) || ! is_string( $old_status ) || $new_status === $old_status ) {
			return;
		}
		$post = _ww_activity_loggable_post( $post );
		if ( null === $post ) {
			return;
		}
		$action = null;
		if ( in_array( $old_status, array( 'new', 'auto-draft' ), true ) ) {
			$action = 'created';
		} elseif ( 'trash' === $new_status ) {
			$action = 'trashed';
		} elseif ( 'trash' === $old_status ) {
			$action = 'restored';
		} elseif ( 'publish' === $new_status ) {
			$action = 'published';
		} elseif ( 'publish' === $old_status ) {
			$action = 'unpublished';
		}
		if ( null === $action ) {
			return;
		}
		_ww_activity_add( 'post', $post->ID, $action, array(), $post->post_type, $post->post_title );
	} catch ( \Throwable $e ) {
		return;
	}
}
add_action( 'transition_post_status', '_ww_activity_on_transition', 10, 3 );

/**
 * Bericht bijgewerkt: de kolommen die verschillen (van het wachtwoord alleen de naam).
 *
 * @param mixed $post_id Bericht-ID.
 * @param mixed $after   Bericht na de wijziging.
 * @param mixed $before  Bericht ervoor.
 */
function _ww_activity_on_post_updated( $post_id, $after, $before ): void {
	try {
		if ( null === _ww_activity_actor() || ! $after instanceof WP_Post || ! $before instanceof WP_Post || null === _ww_activity_loggable_post( $after ) ) {
			return;
		}
		// De slug verandert vanzelf bij prullenbak, terugzetten en de eerste publicatie: dat is geen bewerking.
		$slug_is_automatic = 'trash' === $after->post_status || 'trash' === $before->post_status || '' === $before->post_name;
		// Een concept zonder vaste datum (post_date_gmt leeg) krijgt bij de eerste publicatie de datum van nu: ook geen bewerking.
		$date_is_automatic = '0000-00-00 00:00:00' === $before->post_date_gmt && '0000-00-00 00:00:00' !== $after->post_date_gmt;
		$fields            = array();
		foreach ( array( 'post_title', 'post_name', 'post_excerpt', 'post_content', 'post_parent', 'menu_order', 'post_date', 'post_password' ) as $column ) {
			if ( ( 'post_name' === $column && $slug_is_automatic ) || ( 'post_date' === $column && $date_is_automatic ) ) {
				continue;
			}
			if ( (string) $after->$column !== (string) $before->$column ) {
				$fields[] = $column;
			}
		}
		if ( array() !== $fields ) {
			_ww_activity_add( 'post', $after->ID, 'updated', $fields, $after->post_type, $after->post_title );
		}
	} catch ( \Throwable $e ) {
		return;
	}
}
add_action( 'post_updated', '_ww_activity_on_post_updated', 10, 3 );

/**
 * Metawijziging op een bericht: de sleutel als veldnaam.
 *
 * @param mixed $meta_ids  Meta-ID('s); niet gebruikt.
 * @param mixed $object_id Bericht-ID.
 * @param mixed $meta_key  Sleutel.
 */
function _ww_activity_on_meta( $meta_ids, $object_id, $meta_key ): void {
	try {
		if ( null === _ww_activity_actor() || ! is_string( $meta_key ) || ! is_numeric( $object_id ) || '_wp_attachment_image_alt' === $meta_key ) {
			return;
		}
		$name = _ww_activity_meta_name( $meta_key );
		$post = null === $name ? null : _ww_activity_loggable_post( (int) $object_id );
		if ( null === $name || null === $post ) {
			return;
		}
		_ww_activity_add( 'post', $post->ID, 'updated', array( $name ), $post->post_type, $post->post_title );
	} catch ( \Throwable $e ) {
		return;
	}
}
add_action( 'added_post_meta', '_ww_activity_on_meta', 10, 3 );
add_action( 'updated_post_meta', '_ww_activity_on_meta', 10, 3 );
add_action( 'deleted_post_meta', '_ww_activity_on_meta', 10, 3 );

/**
 * Termen van een bericht gewijzigd: alleen als de term-ID's echt verschillen.
 *
 * @param mixed $object_id   Bericht-ID.
 * @param mixed $terms       Niet gebruikt.
 * @param mixed $tt_ids      Nieuwe term-taxonomie-ID's.
 * @param mixed $taxonomy    Taxonomie.
 * @param mixed $append      Of de termen worden toegevoegd in plaats van vervangen.
 * @param mixed $old_tt_ids  Oude term-taxonomie-ID's.
 */
function _ww_activity_on_terms( $object_id, $terms, $tt_ids, $taxonomy, $append = false, $old_tt_ids = array() ): void {
	try {
		if ( null === _ww_activity_actor() || ! is_numeric( $object_id ) || ! is_array( $tt_ids ) || ! is_array( $old_tt_ids ) || ! is_string( $taxonomy ) || '' === $taxonomy ) {
			return;
		}
		$new = array_map( 'intval', $tt_ids );
		$old = array_map( 'intval', $old_tt_ids );
		sort( $new );
		sort( $old );
		// Bij toevoegen (append) geeft core de oude termen niet door: dan telt alleen of er echt een koppeling bij kwam.
		$state     = &_ww_activity_state();
		$key       = (int) $object_id . ':' . $taxonomy;
		$was_added = isset( $state['added'][ $key ] );
		unset( $state['added'][ $key ] );
		if ( $append ? ! $was_added : $new === $old ) {
			return;
		}
		$post = _ww_activity_loggable_post( (int) $object_id );
		if ( null === $post ) {
			return;
		}
		_ww_activity_add( 'post', $post->ID, 'updated', array( $taxonomy ), $post->post_type, $post->post_title );
	} catch ( \Throwable $e ) {
		return;
	}
}
add_action( 'set_object_terms', '_ww_activity_on_terms', 10, 6 );

/**
 * Onthoudt dat er een nieuwe koppeling tussen bericht en term bij kwam (core meldt dat vlak vóór set_object_terms).
 *
 * @param mixed $object_id Bericht-ID.
 * @param mixed $tt_id     Term-taxonomie-ID; niet gebruikt.
 * @param mixed $taxonomy  Taxonomie.
 */
function _ww_activity_on_term_added( $object_id, $tt_id, $taxonomy = '' ): void {
	try {
		if ( is_numeric( $object_id ) && is_string( $taxonomy ) && '' !== $taxonomy ) {
			$state                                                 = &_ww_activity_state();
			$state['added'][ (int) $object_id . ':' . $taxonomy ] = true;
		}
	} catch ( \Throwable $e ) {
		return;
	}
}
add_action( 'added_term_relationship', '_ww_activity_on_term_added', 10, 3 );

/**
 * Bericht definitief verwijderd: de titel van vóór het verwijderen.
 *
 * @param mixed $post_id Bericht-ID.
 * @param mixed $post    Bericht.
 */
function _ww_activity_on_delete( $post_id, $post = null ): void {
	try {
		if ( null === _ww_activity_actor() ) {
			return;
		}
		$post = _ww_activity_loggable_post( $post instanceof WP_Post ? $post : $post_id );
		if ( null === $post ) {
			return;
		}
		_ww_activity_add( 'post', $post->ID, 'deleted', array(), $post->post_type, $post->post_title );
	} catch ( \Throwable $e ) {
		return;
	}
}
add_action( 'before_delete_post', '_ww_activity_on_delete', 10, 2 );

/**
 * Het bijlage-bericht, of null als het geen (bestaande) bijlage is.
 *
 * @param mixed $post Bijlage of bijlage-ID.
 */
function _ww_activity_attachment( $post ): ?WP_Post {
	$post = is_numeric( $post ) ? get_post( (int) $post ) : $post;
	return ( $post instanceof WP_Post && 'attachment' === $post->post_type ) ? $post : null;
}

/**
 * Bestand geüpload.
 *
 * @param mixed $post_id Bijlage-ID.
 */
function _ww_activity_on_attachment_added( $post_id ): void {
	try {
		if ( null === _ww_activity_actor() ) {
			return;
		}
		$post = _ww_activity_attachment( $post_id );
		if ( null !== $post ) {
			_ww_activity_add( 'attachment', $post->ID, 'uploaded', array(), '', $post->post_title );
		}
	} catch ( \Throwable $e ) {
		return;
	}
}
add_action( 'add_attachment', '_ww_activity_on_attachment_added' );

/**
 * Bijlage bijgewerkt: titel, bijschrift of beschrijving die verschilt.
 *
 * @param mixed $post_id Bijlage-ID.
 * @param mixed $after   Bijlage na de wijziging.
 * @param mixed $before  Bijlage ervoor.
 */
function _ww_activity_on_attachment_updated( $post_id, $after, $before ): void {
	try {
		if ( null === _ww_activity_actor() || null === _ww_activity_attachment( $after ) || ! $before instanceof WP_Post ) {
			return;
		}
		$fields = array();
		foreach ( array( 'post_title', 'post_excerpt', 'post_content' ) as $column ) {
			if ( (string) $after->$column !== (string) $before->$column ) {
				$fields[] = $column;
			}
		}
		if ( array() !== $fields ) {
			_ww_activity_add( 'attachment', $after->ID, 'updated', $fields, '', $after->post_title );
		}
	} catch ( \Throwable $e ) {
		return;
	}
}
add_action( 'attachment_updated', '_ww_activity_on_attachment_updated', 10, 3 );

/**
 * Alternatieve tekst van een afbeelding gewijzigd (meta, dus buiten attachment_updated).
 *
 * @param mixed $meta_ids  Niet gebruikt.
 * @param mixed $object_id Bijlage-ID.
 * @param mixed $meta_key  Sleutel.
 */
function _ww_activity_on_attachment_meta( $meta_ids, $object_id, $meta_key ): void {
	try {
		if ( null === _ww_activity_actor() || '_wp_attachment_image_alt' !== $meta_key || ! is_numeric( $object_id ) ) {
			return;
		}
		$post = _ww_activity_attachment( (int) $object_id );
		if ( null !== $post ) {
			_ww_activity_add( 'attachment', $post->ID, 'updated', array( 'alt' ), '', $post->post_title );
		}
	} catch ( \Throwable $e ) {
		return;
	}
}
add_action( 'added_post_meta', '_ww_activity_on_attachment_meta', 10, 3 );
add_action( 'updated_post_meta', '_ww_activity_on_attachment_meta', 10, 3 );
add_action( 'deleted_post_meta', '_ww_activity_on_attachment_meta', 10, 3 );

/**
 * Bijlage verwijderd: de titel van vóór het verwijderen (de haak loopt vóór het wissen).
 *
 * @param mixed $post_id Bijlage-ID.
 * @param mixed $post    Bijlage.
 */
function _ww_activity_on_attachment_deleted( $post_id, $post = null ): void {
	try {
		if ( null === _ww_activity_actor() ) {
			return;
		}
		$post = _ww_activity_attachment( $post instanceof WP_Post ? $post : $post_id );
		if ( null !== $post ) {
			_ww_activity_add( 'attachment', $post->ID, 'deleted', array(), '', $post->post_title );
		}
	} catch ( \Throwable $e ) {
		return;
	}
}
add_action( 'delete_attachment', '_ww_activity_on_attachment_deleted', 10, 2 );

/**
 * Naam van een menu (term) op dit moment, of '' als het niet bestaat.
 *
 * @param mixed $menu_id Menu-ID.
 */
function _ww_activity_menu_name( $menu_id ): string {
	$menu = is_numeric( $menu_id ) ? wp_get_nav_menu_object( (int) $menu_id ) : false;
	return ( $menu instanceof WP_Term ) ? $menu->name : '';
}

/**
 * Een menu is aangemaakt of bijgewerkt. Items opslaan geeft dezelfde rij; de buffer voegt alles samen.
 * Een menu zonder veldnamen blijft staan (de uitzondering in _ww_activity_flush()).
 *
 * @param mixed  $menu_id Menu-ID.
 * @param string $action  created of updated.
 */
function _ww_activity_menu_event( $menu_id, string $action ): void {
	try {
		if ( ! is_numeric( $menu_id ) || (int) $menu_id <= 0 ) {
			return;
		}
		_ww_activity_add( 'menu', (int) $menu_id, $action, array(), '', _ww_activity_menu_name( $menu_id ) );
	} catch ( \Throwable $e ) {
		return;
	}
}

/**
 * Menu aangemaakt.
 *
 * @param mixed $menu_id Menu-ID.
 */
function _ww_activity_on_menu_created( $menu_id ): void {
	_ww_activity_menu_event( $menu_id, 'created' );
}
add_action( 'wp_create_nav_menu', '_ww_activity_on_menu_created' );

/**
 * Menu bijgewerkt (naam of items).
 *
 * @param mixed $menu_id Menu-ID.
 */
function _ww_activity_on_menu_updated( $menu_id ): void {
	_ww_activity_menu_event( $menu_id, 'updated' );
}
add_action( 'wp_update_nav_menu', '_ww_activity_on_menu_updated' );
add_action( 'wp_update_nav_menu_item', '_ww_activity_on_menu_updated' );

/**
 * Menunamen die vlak voor het verwijderen zijn bewaard; wp_delete_nav_menu draait pas als de term al weg is.
 * Zonder argumenten geeft de functie de bewaarde namen; met argumenten bewaart hij de naam van een menu.
 *
 * @param mixed $term     Term-ID.
 * @param mixed $taxonomy Taxonomie.
 * @return array<int,string>
 */
function _ww_activity_menu_names( $term = null, $taxonomy = null ): array {
	static $names = array();
	if ( 'nav_menu' === $taxonomy && is_numeric( $term ) ) {
		$names[ (int) $term ] = _ww_activity_menu_name( $term );
	}
	return $names;
}

/**
 * Haak vóór het wissen van een term: onthoud de menunaam.
 *
 * @param mixed $term     Term-ID.
 * @param mixed $taxonomy Taxonomie.
 */
function _ww_activity_on_pre_delete_term( $term, $taxonomy ): void {
	try {
		_ww_activity_menu_names( $term, $taxonomy );
	} catch ( \Throwable $e ) {
		return;
	}
}
add_action( 'pre_delete_term', '_ww_activity_on_pre_delete_term', 10, 2 );

/**
 * Menu verwijderd, met de naam van vóór het verwijderen.
 *
 * @param mixed $menu_id Menu-ID.
 */
function _ww_activity_on_menu_deleted( $menu_id ): void {
	try {
		if ( ! is_numeric( $menu_id ) || (int) $menu_id <= 0 ) {
			return;
		}
		$names = _ww_activity_menu_names();
		_ww_activity_add( 'menu', (int) $menu_id, 'deleted', array(), '', $names[ (int) $menu_id ] ?? '' );
	} catch ( \Throwable $e ) {
		return;
	}
}
add_action( 'wp_delete_nav_menu', '_ww_activity_on_menu_deleted' );

/**
 * Themamods veranderd: alleen het verschil in menulocaties wordt gelogd, als optie nav_menu_locations.
 *
 * @param mixed $option Optienaam.
 * @param mixed $old    Oude waarde (bij een nieuwe optie leeg).
 * @param mixed $new    Nieuwe waarde.
 */
function _ww_activity_on_theme_mods( $option, $old, $new ): void {
	try {
		// Dezelfde naam als set_theme_mod() gebruikt: de optie 'stylesheet' (get_stylesheet() kent een filter).
		if ( 'theme_mods_' . get_option( 'stylesheet' ) !== $option ) {
			return;
		}
		$old_locations = ( is_array( $old ) && isset( $old['nav_menu_locations'] ) && is_array( $old['nav_menu_locations'] ) ) ? $old['nav_menu_locations'] : array();
		$new_locations = ( is_array( $new ) && isset( $new['nav_menu_locations'] ) && is_array( $new['nav_menu_locations'] ) ) ? $new['nav_menu_locations'] : array();
		$fields        = array();
		foreach ( array_unique( array_merge( array_keys( $old_locations ), array_keys( $new_locations ) ) ) as $location ) {
			if ( (int) ( $old_locations[ $location ] ?? 0 ) !== (int) ( $new_locations[ $location ] ?? 0 ) ) {
				$fields[] = (string) $location;
			}
		}
		if ( array() !== $fields ) {
			_ww_activity_add( 'option', 'nav_menu_locations', 'updated', $fields, 'nav_menu_locations', 'nav_menu_locations' );
		}
	} catch ( \Throwable $e ) {
		return;
	}
}
add_action( 'updated_option', '_ww_activity_on_theme_mods', 10, 3 );

/**
 * Een nieuwe optie theme_mods_{stylesheet} (eerste keer opslaan): alles telt als nieuw.
 *
 * @param mixed $option Optienaam.
 * @param mixed $value  Waarde.
 */
function _ww_activity_on_theme_mods_added( $option, $value ): void {
	_ww_activity_on_theme_mods( $option, array(), $value );
}
add_action( 'added_option', '_ww_activity_on_theme_mods_added', 10, 2 );

/**
 * Opties buiten de Site-instellingen die gelogd worden: de vaste lijst uit de spec plus het filter.
 *
 * @return string[]
 */
function _ww_activity_options(): array {
	$options = array( 'blogname', 'blogdescription', 'show_on_front', 'page_on_front', 'page_for_posts', 'permalink_structure', 'site_icon' );
	if ( defined( 'WW_PAGE_CACHE_PRELOAD_OPTION' ) ) {
		$options[] = WW_PAGE_CACHE_PRELOAD_OPTION;
	} else {
		$options[] = 'ww_page_cache_preload';
	}
	/**
	 * Opties die in het activiteitenlog komen, bovenop de vaste lijst.
	 *
	 * @param string[] $options Optienamen.
	 */
	$extra = apply_filters( 'ww_activity_options', $options );
	return array_values( array_filter( $extra, 'is_string' ) );
}

/**
 * De settings-pagina van een veld van de Site-instellingen; onbekend is Overige. Per verzoek bewaard.
 *
 * @param string $field Veldnaam zonder voorvoegsel.
 */
function _ww_activity_settings_page( string $field ): string {
	static $map = null;
	if ( null === $map ) {
		$map   = array();
		$pages = _ww_settings_pages();
		foreach ( _ww_settings_groups() as $group ) {
			$page   = _ww_settings_group_page( $group, $pages );
			$fields = is_array( $group['fields'] ?? null ) ? $group['fields'] : array();
			foreach ( $fields as $item ) {
				$name = is_array( $item ) ? _ww_data_to_string( $item['name'] ?? '' ) : '';
				if ( '' !== $name && ! isset( $map[ $name ] ) ) {
					$map[ $name ] = $page;
				}
			}
		}
	}
	return $map[ $field ] ?? WW_SETTINGS_OTHER;
}

/**
 * Een optie is toegevoegd, gewijzigd of verwijderd: een instelling van een settings-pagina, een optie van de lijst of niets.
 *
 * @param mixed $name Optienaam.
 */
function _ww_activity_option_event( $name ): void {
	try {
		if ( ! is_string( $name ) || '' === $name ) {
			return;
		}
		$prefix = _ww_settings_prefix();
		if ( '' !== $prefix && str_starts_with( $name, $prefix ) && strlen( $name ) > strlen( $prefix ) ) {
			$field = substr( $name, strlen( $prefix ) );
			$page  = _ww_activity_settings_page( $field );
			$pages = _ww_settings_pages();
			if ( '' === $page ) {
				// Een veld van een eigen scherm (ww_screen): nu alleen llms.txt op het scherm SEO.
				_ww_activity_add( 'settings', WW_SEO_SCREEN, 'updated', array( $field ), WW_SEO_SCREEN, __( 'SEO', 'webwerckt-base' ) );
				return;
			}
			_ww_activity_add( 'settings', $page, 'updated', array( $field ), $page, $pages[ $page ] ?? $page );
			return;
		}
		if ( in_array( $name, _ww_activity_options(), true ) ) {
			_ww_activity_add( 'option', $name, 'updated', array(), $name, $name );
		}
	} catch ( \Throwable $e ) {
		return;
	}
}

/**
 * Optie gewijzigd: alleen als de waarde echt verschilt.
 *
 * @param mixed $name Optienaam.
 * @param mixed $old  Oude waarde.
 * @param mixed $new  Nieuwe waarde.
 */
function _ww_activity_on_option_updated( $name, $old = null, $new = null ): void {
	if ( $old !== $new ) {
		_ww_activity_option_event( $name );
	}
}
add_action( 'updated_option', '_ww_activity_on_option_updated', 10, 3 );

/**
 * Optie toegevoegd.
 *
 * @param mixed $name Optienaam.
 */
function _ww_activity_on_option_added( $name ): void {
	_ww_activity_option_event( $name );
}
add_action( 'added_option', '_ww_activity_on_option_added' );

/**
 * Optie verwijderd (WordPress roept dit alleen na een geslaagde verwijdering aan).
 *
 * @param mixed $name Optienaam.
 */
function _ww_activity_on_option_deleted( $name ): void {
	_ww_activity_option_event( $name );
}
add_action( 'deleted_option', '_ww_activity_on_option_deleted' );

/**
 * Of er een redirect-import loopt: dan logt de import zelf één regel en slaat ww_redirect_saved over.
 *
 * @param bool|null $set Zet de vlag; null leest alleen.
 */
function _ww_activity_importing( ?bool $set = null ): bool {
	static $importing = false;
	if ( null !== $set ) {
		$importing = $set;
	}
	return $importing;
}

/**
 * Een redirect-import begint (interne actie).
 */
function _ww_activity_on_import_start(): void {
	_ww_activity_importing( true );
}
add_action( '_ww_redirects_import_start', '_ww_activity_on_import_start' );

/**
 * Een redirectregel is opgeslagen.
 *
 * @param mixed $id     Id van de regel.
 * @param mixed $rule   De opgeslagen regel.
 * @param mixed $is_new Nieuw of bijgewerkt.
 */
function _ww_activity_on_redirect_saved( $id, $rule = array(), $is_new = false ): void {
	try {
		if ( _ww_activity_importing() || ! is_array( $rule ) ) {
			return;
		}
		_ww_activity_add( 'redirect', (int) $id, $is_new ? 'created' : 'updated', array(), '', (string) ( $rule['source'] ?? '' ) );
	} catch ( \Throwable $e ) {
		return;
	}
}
add_action( 'ww_redirect_saved', '_ww_activity_on_redirect_saved', 10, 3 );

/**
 * Een redirectregel is verwijderd.
 *
 * @param mixed $id     Id van de regel.
 * @param mixed $source De bron van de regel.
 */
function _ww_activity_on_redirect_deleted( $id, $source = '' ): void {
	try {
		_ww_activity_add( 'redirect', (int) $id, 'deleted', array(), '', is_string( $source ) ? $source : '' );
	} catch ( \Throwable $e ) {
		return;
	}
}
add_action( 'ww_redirect_deleted', '_ww_activity_on_redirect_deleted', 10, 2 );

/**
 * Een import is klaar: één regel met het aantal, en de vlag gaat weer uit (ook bij 0 regels, dan is er niets te loggen).
 *
 * @param mixed $count Aantal opgeslagen regels.
 */
function _ww_activity_on_redirects_imported( $count ): void {
	_ww_activity_importing( false );
	try {
		$count = (int) $count;
		if ( $count < 1 ) {
			return;
		}
		/* translators: %d: aantal geïmporteerde redirectregels. */
		_ww_activity_add( 'redirect', 'import', 'imported', array(), '', sprintf( _n( '%d regel', '%d regels', $count, 'webwerckt-base' ), $count ) );
	} catch ( \Throwable $e ) {
		return;
	}
}
add_action( 'ww_redirects_imported', '_ww_activity_on_redirects_imported' );

/**
 * Ruimt op: verwijdert regels ouder dan de bewaartermijn (standaard 30 dagen), in porties van 1000, tot ze weg zijn
 * (hoogstens een halve minuut per run).
 */
function _ww_activity_cleanup(): void {
	global $wpdb;
	if ( ! _ww_activity_ready() ) {
		return;
	}
	$days   = max( 1, (int) apply_filters( 'ww_activity_retention_days', 30 ) );
	$cutoff = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
	$table  = _ww_activity_table();

	// Door tot alles van vóór de bewaartermijn weg is; met een plafond van 20 porties groeide de tabel sneller dan hij
	// leegliep (L7 van de security-audit van 2026-11-25). Na een halve minuut gaat de volgende run verder.
	$until = microtime( true ) + 30;
	do {
		$deleted = $wpdb->query( $wpdb->prepare( "DELETE FROM $table WHERE created < %s LIMIT 1000", $cutoff ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- tabelnaam uit _ww_activity_table().
	} while ( is_int( $deleted ) && 1000 === $deleted && microtime( true ) < $until );
}
add_action( WW_ACTIVITY_CLEANUP_HOOK, '_ww_activity_cleanup' );

/**
 * Plant de dagelijkse opruiming in bij een adminbezoek.
 */
function _ww_activity_schedule(): void {
	if ( ! wp_next_scheduled( WW_ACTIVITY_CLEANUP_HOOK ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', WW_ACTIVITY_CLEANUP_HOOK );
	}
}
add_action( 'admin_init', '_ww_activity_schedule' );

/**
 * Haalt de opruiming weg bij een themawissel.
 */
function _ww_activity_unschedule(): void {
	wp_clear_scheduled_hook( WW_ACTIVITY_CLEANUP_HOOK );
}
add_action( 'switch_theme', '_ww_activity_unschedule' );
