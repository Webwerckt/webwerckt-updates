<?php
/**
 * Frontend-basis voor child-thema's: lazy loading van afbeeldingen, versie-URL voor themabestanden,
 * de klasse js, preload en inline scripts. Alleen op de frontend; de beheeromgeving en de
 * REST API blijven zoals WordPress ze doet.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'wp_get_loading_optimization_attributes', '_ww_lazy_images', 10, 4 );
add_action( 'wp_head', '_ww_js_class', 0 );
add_action( 'wp_head', '_ww_print_preloads', 2 );
add_action( 'wp_head', '_ww_favicon_replace_site_icon', 0 );
add_action( 'wp_head', '_ww_favicon', 3 );
add_action( 'wp_footer', '_ww_print_inline_scripts', 20 );

/**
 * Geeft elke afbeelding loading="lazy" en haalt fetchpriority weg. Ongewijzigd blijven: aanroepen die zelf loading of
 * fetchpriority meegeven (de hero van ww_image()), iframes en afbeeldingen in de inhoud van een bericht, ook die een
 * shortcode als [gallery] maakt (the_content, widget_text_content en widget_block_content): daar telt WordPress zelf
 * welke afbeelding boven de vouw staat.
 *
 * @param array<string,string> $loading_attrs Voorstel van WordPress.
 * @param string               $tag_name      Tag, bijvoorbeeld img of iframe.
 * @param array<string,mixed>  $attr          Attributen van de aanroep.
 * @param string               $context       Context van de aanroep.
 * @return array<string,string>
 */
function _ww_lazy_images( array $loading_attrs, string $tag_name, array $attr, string $context ): array {
	if ( is_admin() || wp_is_serving_rest_request() ) {
		return $loading_attrs;
	}
	/**
	 * Zet het lazy loading van het thema uit; WordPress bepaalt dan zelf loading en fetchpriority.
	 *
	 * @param bool $enabled Standaard true.
	 */
	if ( ! apply_filters( 'ww_lazy_images', true ) ) {
		return $loading_attrs;
	}
	if ( 'img' !== $tag_name || 'the_content' === $context || isset( $attr['loading'] ) || isset( $attr['fetchpriority'] ) ) {
		return $loading_attrs;
	}
	if ( doing_filter( 'the_content' ) || doing_filter( 'widget_text_content' ) || doing_filter( 'widget_block_content' ) ) {
		return $loading_attrs;
	}
	unset( $loading_attrs['fetchpriority'] );
	$loading_attrs['loading'] = 'lazy';
	return $loading_attrs;
}

/**
 * Zoekt een themabestand: eerst in het child-thema, dan in de parent.
 *
 * @param string $path Pad ten opzichte van de themamap, bijvoorbeeld assets/img/x.svg.
 * @return string Absoluut pad, of '' als het bestand nergens bestaat.
 */
function _ww_theme_asset_file( string $path ): string {
	$path = ltrim( $path, '/' );
	// Alleen bestanden in de themamap: een pad met .. kan eruit (vermoeden uit de security-audit van 2026-11-25).
	if ( 1 === preg_match( '#(^|[/\\\\])\.\.([/\\\\]|$)#', $path ) ) {
		return '';
	}
	foreach ( array( get_stylesheet_directory(), get_template_directory() ) as $dir ) {
		if ( is_file( $dir . '/' . $path ) ) {
			return $dir . '/' . $path;
		}
	}
	return '';
}

/**
 * URL van een themabestand (child-thema, anders parent) met de wijzigingstijd van het bestand als versie. Bestaat het
 * bestand nergens, dan de URL in het child-thema met de versie van het child-thema.
 *
 * @param string $path Pad ten opzichte van de themamap.
 * @return string
 */
function _ww_theme_asset_url( string $path ): string {
	$path = ltrim( $path, '/' );
	$file = _ww_theme_asset_file( $path );
	if ( '' === $file ) {
		if ( WP_DEBUG ) {
			_doing_it_wrong( __FUNCTION__, esc_html( sprintf( 'Themabestand %s bestaat niet in het child-thema of de parent.', $path ) ), '0.20.0' );
		}
		return get_stylesheet_directory_uri() . '/' . $path . '?ver=' . rawurlencode( (string) wp_get_theme()->get( 'Version' ) );
	}
	$base = ( get_stylesheet_directory() . '/' . $path ) === $file ? get_stylesheet_directory_uri() : get_template_directory_uri();
	return $base . '/' . $path . '?ver=' . (int) filemtime( $file );
}

/**
 * Zet de klasse js op het html-element, zo vroeg mogelijk in de head.
 */
function _ww_js_class(): void {
	if ( is_admin() ) {
		return;
	}
	wp_print_inline_script_tag( "document.documentElement.classList.add('js');" );
}

/**
 * Zorgt dat wachtrij en vlag van ww_inline_script() bestaan.
 */
function _ww_inline_scripts_state(): void {
	if ( ! isset( $GLOBALS['ww_inline_scripts'] ) ) {
		$GLOBALS['ww_inline_scripts'] = array(
			'done'  => false,
			'items' => array(),
		);
	}
}

/**
 * Zet een klein script uit het child-thema (of de parent) inline onderaan de pagina. Aanroepen kan tot de parent de
 * scripts afdrukt (wp_footer, prioriteit 20); elk bestand wordt één keer afgedrukt, in de volgorde van aanroepen.
 *
 * @param string $path   Pad ten opzichte van de themamap, bijvoorbeeld assets/js/menu.js.
 * @param bool   $module Of het script type="module" krijgt.
 */
function ww_inline_script( string $path, bool $module = false ): void {
	if ( is_admin() ) {
		return;
	}
	_ww_inline_scripts_state();
	if ( $GLOBALS['ww_inline_scripts']['done'] ) {
		_doing_it_wrong( __FUNCTION__, esc_html( sprintf( 'Het script %s is te laat aangeroepen: de scripts zijn al afgedrukt. Roep ww_inline_script() aan vóór wp_footer.', $path ) ), '0.20.0' );
		return;
	}
	$file = _ww_theme_asset_file( $path );
	if ( '' === $file ) {
		if ( WP_DEBUG ) {
			_doing_it_wrong( __FUNCTION__, esc_html( sprintf( 'Het script %s bestaat niet in het child-thema of de parent.', $path ) ), '0.20.0' );
		}
		return;
	}
	if ( ! isset( $GLOBALS['ww_inline_scripts']['items'][ $file ] ) ) {
		$GLOBALS['ww_inline_scripts']['items'][ $file ] = $module;
	}
}

/**
 * Drukt de met ww_inline_script() aangevraagde scripts af en zet daarna de vlag.
 */
function _ww_print_inline_scripts(): void {
	if ( is_admin() ) {
		return;
	}
	_ww_inline_scripts_state();
	$GLOBALS['ww_inline_scripts']['done'] = true;
	foreach ( $GLOBALS['ww_inline_scripts']['items'] as $file => $module ) {
		$code = file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- lokaal themabestand.
		if ( false === $code || '' === trim( $code ) ) {
			if ( WP_DEBUG ) {
				_doing_it_wrong( 'ww_inline_script', esc_html( sprintf( 'Het script %s is leeg of niet te lezen.', basename( $file ) ) ), '0.20.0' );
			}
			continue;
		}
		wp_print_inline_script_tag( $code, $module ? array( 'type' => 'module' ) : array() );
	}
	$GLOBALS['ww_inline_scripts']['items'] = array();
}

/**
 * Zorgt dat wachtrij en vlag van ww_preload() bestaan.
 */
function _ww_preloads_state(): void {
	if ( ! isset( $GLOBALS['ww_preloads'] ) ) {
		$GLOBALS['ww_preloads'] = array(
			'done'  => false,
			'items' => array(),
		);
	}
}

/**
 * Vraagt een preload aan voor een lettertype of afbeelding uit het child-thema (of de parent), of voor een volledige
 * URL. De URL krijgt bewust geen versie: de browser gebruikt een preload alleen als de URL precies gelijk is aan die
 * uit de CSS. Aanroepen kan tot de parent de links afdrukt (wp_head, prioriteit 2), dus ook in de eigen functie op
 * wp_enqueue_scripts. Dezelfde URL komt één keer; een tweede aanroep vult $args aan.
 *
 * Een pad dat nergens bestaat geeft bij WP_DEBUG een melding; de link met de URL in het child-thema wordt dan toch afgedrukt,
 * net als bij _ww_theme_asset_url().
 *
 * Een hero als img via ww_image( …, true ) heeft geen preload nodig: de browser vindt hem in de HTML.
 *
 * @param string              $path Pad ten opzichte van de themamap (assets/fonts/x.woff2) of een volledige URL.
 * @param array<string,mixed> $args Attributen die worden toegevoegd of overschreven; false haalt een attribuut weg, true geeft er een zonder waarde.
 */
function ww_preload( string $path, array $args = array() ): void {
	if ( is_admin() ) {
		return;
	}
	_ww_preloads_state();
	if ( $GLOBALS['ww_preloads']['done'] ) {
		_doing_it_wrong( __FUNCTION__, esc_html( sprintf( 'De preload van %s is te laat aangevraagd: de links zijn al afgedrukt. Roep ww_preload() aan vóór wp_head, bijvoorbeeld op wp_enqueue_scripts.', $path ) ), '0.20.0' );
		return;
	}

	if ( preg_match( '#^(https?:)?//#i', $path ) ) {
		$url      = $path;
		$ext_path = (string) wp_parse_url( $path, PHP_URL_PATH );
	} else {
		$path     = ltrim( $path, '/' );
		$file     = _ww_theme_asset_file( $path );
		$base     = ( '' !== $file && ( get_stylesheet_directory() . '/' . $path ) !== $file ) ? get_template_directory_uri() : get_stylesheet_directory_uri();
		$url      = $base . '/' . $path;
		$ext_path = $path;
		if ( '' === $file && WP_DEBUG ) {
			_doing_it_wrong( __FUNCTION__, esc_html( sprintf( 'Het bestand %s bestaat niet in het child-thema of de parent; de preload verwijst naar het child-thema.', $path ) ), '0.20.0' );
		}
	}

	$types = array(
		'woff2' => array( 'font', 'font/woff2' ),
		'woff'  => array( 'font', 'font/woff' ),
		'svg'   => array( 'image', 'image/svg+xml' ),
		'webp'  => array( 'image', 'image/webp' ),
		'avif'  => array( 'image', 'image/avif' ),
		'png'   => array( 'image', 'image/png' ),
		'jpg'   => array( 'image', 'image/jpeg' ),
		'jpeg'  => array( 'image', 'image/jpeg' ),
	);
	$ext   = strtolower( pathinfo( $ext_path, PATHINFO_EXTENSION ) );
	if ( ! isset( $types[ $ext ] ) ) {
		_doing_it_wrong( __FUNCTION__, esc_html( sprintf( 'Van %s is geen preload te maken: alleen woff2, woff, svg, webp, avif, png, jpg en jpeg.', $path ) ), '0.20.0' );
		return;
	}

	$attrs = array(
		'rel'  => 'preload',
		'href' => $url,
		'as'   => $types[ $ext ][0],
		'type' => $types[ $ext ][1],
	);
	if ( 'font' === $types[ $ext ][0] ) {
		$attrs['crossorigin'] = true;
	} else {
		$attrs['fetchpriority'] = 'high';
	}

	if ( isset( $GLOBALS['ww_preloads']['items'][ $url ] ) ) {
		$attrs = $GLOBALS['ww_preloads']['items'][ $url ];
	}
	$GLOBALS['ww_preloads']['items'][ $url ] = array_merge( $attrs, $args );
}

/**
 * Drukt de met ww_preload() aangevraagde links af en zet daarna de vlag.
 */
function _ww_print_preloads(): void {
	if ( is_admin() ) {
		return;
	}
	_ww_preloads_state();
	$GLOBALS['ww_preloads']['done'] = true;
	$order                          = array( 'rel', 'href', 'as', 'type', 'crossorigin', 'fetchpriority', 'media' );
	foreach ( $GLOBALS['ww_preloads']['items'] as $attrs ) {
		$sorted = array();
		foreach ( $order as $key ) {
			if ( array_key_exists( $key, $attrs ) ) {
				$sorted[ $key ] = $attrs[ $key ];
			}
		}
		$sorted += $attrs;

		$html = '';
		foreach ( $sorted as $name => $value ) {
			$name = (string) $name;
			if ( false === $value || null === $value || ! preg_match( '/^[a-z][a-z0-9:_.-]*$/i', $name ) ) {
				continue;
			}
			if ( true === $value ) {
				$html .= ' ' . $name;
			} elseif ( 'href' === $name ) {
				$html .= ' href="' . esc_url( (string) $value ) . '"';
			} else {
				$html .= ' ' . $name . '="' . esc_attr( (string) $value ) . '"';
			}
		}
		echo '<link' . $html . ">\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- namen gecontroleerd, waarden ge-escaped.
	}
	$GLOBALS['ww_preloads']['items'] = array();
}

/**
 * Geeft de favicon-bestanden uit assets/favicon/ van het child-thema die bestaan.
 *
 * Alleen het child-thema telt; het parent-thema levert geen favicon.
 *
 * @return array<string,string> Bestandsnaam => URL met versie.
 */
function _ww_favicon_files(): array {
	$files = array();
	foreach ( array( 'favicon.ico', 'favicon.svg', 'favicon-192.png', 'apple-touch-icon.png' ) as $name ) {
		if ( is_file( get_stylesheet_directory() . '/assets/favicon/' . $name ) ) {
			$files[ $name ] = _ww_theme_asset_url( 'assets/favicon/' . $name );
		}
	}
	return $files;
}

/**
 * Haalt het site-icoon van WordPress van wp_head als het child-thema eigen favicon-bestanden heeft.
 */
function _ww_favicon_replace_site_icon(): void {
	if ( is_admin() || array() === _ww_favicon_files() ) {
		return;
	}
	remove_action( 'wp_head', 'wp_site_icon', 99 );
}

/**
 * Drukt de links af voor de favicon-bestanden van het child-thema.
 */
function _ww_favicon(): void {
	if ( is_admin() ) {
		return;
	}
	$attrs = array(
		'favicon.ico'          => ' sizes="32x32"',
		'favicon.svg'          => ' type="image/svg+xml"',
		'favicon-192.png'      => ' type="image/png" sizes="192x192"',
		'apple-touch-icon.png' => '',
	);
	foreach ( _ww_favicon_files() as $name => $url ) {
		$rel = 'apple-touch-icon.png' === $name ? 'apple-touch-icon' : 'icon';
		echo '<link rel="' . $rel . '" href="' . esc_url( $url ) . '"' . $attrs[ $name ] . ">\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- vaste waarden, URL ge-escaped.
	}
}
