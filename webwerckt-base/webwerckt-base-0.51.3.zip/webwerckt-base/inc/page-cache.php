<?php
/**
 * Paginacache: bewaren en legen (beslissing 0028). Serveren doet de mu-plugin met inc/page-cache-serve.php.
 *
 * Een pagina komt in de cache als een bezoeker zonder login hem opent: het thema vangt de HTML op in de
 * outputbuffer van WordPress (wp_finalized_template_enhancement_output_buffer, sinds WordPress 6.9) en schrijft
 * hem met een meta.json in wp-content/cache/ww-pages/{host}/{pad}/. Wat er leeg moet, meldt inc/cache.php.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const WW_PAGE_CACHE_MAX_AGE   = DAY_IN_SECONDS;
const WW_PAGE_CACHE_MU_PLUGIN = 'webwerckt-base-page-cache.php';
const WW_PAGE_CACHE_CRON_HOOK = 'ww_page_cache_cleanup';

// Indeling van de cachemap. Wijkt de opgeslagen indeling af, dan gaat de cache bij het volgende adminbezoek of de
// volgende cron leeg. Versie 2 (beslissing 0029): page.html naast index.html.
const WW_PAGE_CACHE_FORMAT        = 2;
const WW_PAGE_CACHE_FORMAT_OPTION = 'ww_page_cache_format';

// Headers die met de pagina mee bewaard worden. Link alleen voor rel=canonical of alternate.
const WW_PAGE_CACHE_KEEP_HEADERS = array( 'content-type', 'content-language', 'x-robots-tag', 'link' );

/**
 * Wat de pagina die nu wordt opgebouwd over de cache meldt. Met $reset weer leeg (tests).
 *
 * @return array{key:?string,path:string,host:string,nocache:bool,ttl:int,types:array<string,true>,pages:int}
 */
function &_ww_page_cache_state( bool $reset = false ): array {
	static $state = null;
	if ( null === $state || $reset ) {
		$state = array(
			'key'     => null,
			'path'    => '',
			'host'    => '',
			'nocache' => false,
			'ttl'     => 0,
			'types'   => array(),
			'pages'   => 0,
		);
	}
	return $state;
}

/**
 * Een lijst op de pagina (_ww_query_ids()) heeft zoveel pagina's: dan bestaat /pagina/page/N/ tot dat aantal.
 *
 * @param int $pages Aantal pagina's van de lijst.
 */
function _ww_page_cache_note_pages( int $pages ): void {
	$state = &_ww_page_cache_state();
	if ( $pages > $state['pages'] ) {
		$state['pages'] = $pages;
	}
}

/**
 * Bestaat het paginanummer van dit verzoek? Op een archief geeft WordPress zelf een 404 voorbij de laatste pagina.
 * Op een losse pagina of een bericht geeft /pagina/page/N/ voor elke N een 200 met dezelfde inhoud; die komt alleen
 * in de cache als een lijst op de pagina zoveel pagina's heeft. Anders kan een bezoeker de schijf vullen met een map
 * per N (M2 van de security-audit van 2026-11-25).
 */
function _ww_page_cache_page_number_exists(): bool {
	$paged = (int) get_query_var( 'paged' );
	return ! is_singular() || $paged <= 1 || $paged <= _ww_page_cache_state()['pages'];
}

/**
 * Waarom de cache uit staat, of '' als hij aan staat: de redenen van de mu-plugin, plus het filter ww_page_cache en
 * een ontbrekende mu-plugin (dan leest niets de bestanden, dus schrijft het thema ze ook niet).
 */
function _ww_page_cache_status(): string {
	$reason = _ww_page_cache_off_reason();
	if ( '' !== $reason ) {
		return $reason;
	}
	/**
	 * Zet de paginacache van het thema aan of uit. Uit: het thema schrijft niets meer en leegt de cache bij het
	 * volgende adminbezoek. Om ook het serveren te stoppen: define( 'WW_PAGE_CACHE', false ) in wp-config.php; staan
	 * de regels in .htaccess (beslissing 0029), open dan nog één keer de admin, of leeg de cache.
	 *
	 * @param bool $enabled Standaard true.
	 */
	if ( ! apply_filters( 'ww_page_cache', true ) ) {
		return 'filter';
	}
	if ( ! is_readable( trailingslashit( WPMU_PLUGIN_DIR ) . WW_PAGE_CACHE_MU_PLUGIN ) ) {
		return 'mu-plugin';
	}
	return '';
}

/**
 * Begint met opvangen als deze pagina in de cache mag: de outputbuffer van WordPress start vanzelf zodra er een
 * callback aan de actie hangt (vóór wp_before_include_template).
 */
function _ww_page_cache_start(): void {
	if ( is_user_logged_in() || is_preview() || is_feed() || is_robots() || is_trackback() || is_embed() || is_favicon() ) {
		return;
	}
	if ( is_singular() && post_password_required() ) {
		return;
	}
	$current = _ww_page_cache_current();
	if ( null === $current || '' !== _ww_page_cache_status() || ! _ww_page_cache_storable_uri( _ww_data_to_string( $_SERVER['REQUEST_URI'] ?? '' ) ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- alleen gekeken of er een querystring is.
		return;
	}
	$state         = &_ww_page_cache_state();
	$state['key']  = $current['key'];
	$state['path'] = $current['path'];
	$state['host'] = $current['host'];
	add_action( 'wp_finalized_template_enhancement_output_buffer', '_ww_page_cache_store_output' );
}
add_action( 'template_redirect', '_ww_page_cache_start', 1000 );

/**
 * Mag de pagina van deze URL worden opgeslagen? Alleen zonder querystring. Met genegeerde parameters (utm_source en
 * dergelijke) komt een pagina wel uit de cache, maar opslaan zou die parameters voor iedereen bewaren: links die de
 * querystring van het verzoek overnemen, zoals die van get_pagenum_link() (paginering, meer laden), krijgen ze mee.
 *
 * @param string $uri REQUEST_URI.
 */
function _ww_page_cache_storable_uri( string $uri ): bool {
	$parts = explode( '?', $uri, 2 );
	return ! isset( $parts[1] ) || '' === $parts[1];
}

/**
 * ww_cacheable met false: deze pagina niet bewaren (404, zoeken, Visueel bewerken).
 *
 * @param mixed $cacheable Of het antwoord in de cache mag.
 */
function _ww_page_cache_note_cacheable( $cacheable ): void {
	if ( ! $cacheable ) {
		$state            = &_ww_page_cache_state();
		$state['nocache'] = true;
	}
}
add_action( 'ww_cacheable', '_ww_page_cache_note_cacheable' );

/**
 * ww_cache_ttl: deze pagina hoogstens zo lang bewaren (openingstijden).
 *
 * @param mixed $seconds Seconden.
 */
function _ww_page_cache_note_ttl( $seconds ): void {
	$seconds = absint( $seconds );
	$state   = &_ww_page_cache_state();
	if ( $seconds > 0 && ( 0 === $state['ttl'] || $seconds < $state['ttl'] ) ) {
		$state['ttl'] = $seconds;
	}
}
add_action( 'ww_cache_ttl', '_ww_page_cache_note_ttl' );

/**
 * ww_shows_post_type: deze pagina toont items van dit post type (voor het legen per post type).
 *
 * @param mixed $post_type Post type.
 */
function _ww_page_cache_note_post_type( $post_type = '' ): void {
	$post_type = _ww_data_to_string( $post_type );
	if ( '' !== $post_type ) {
		$state                          = &_ww_page_cache_state();
		$state['types'][ $post_type ] = true;
	}
}
add_action( 'ww_shows_post_type', '_ww_page_cache_note_post_type' );

/**
 * Mag dit antwoord in de cache? Een 200 met text/html, zonder Set-Cookie of Cache-Control no-store/private, en een
 * volledige pagina. Los van headers_list() en http_response_code(), zodat het te testen is.
 *
 * @param string[] $headers Verstuurde headers ("Naam: waarde").
 */
function _ww_page_cache_should_store( int $status, array $headers, string $html ): bool {
	if ( 200 !== $status ) {
		return false;
	}
	$type = null;
	foreach ( $headers as $header ) {
		$parts = explode( ':', $header, 2 );
		$name  = strtolower( trim( $parts[0] ) );
		if ( 'set-cookie' === $name ) {
			return false;
		}
		// Een plugin die zegt dat de pagina persoonlijk is of niet bewaard mag worden (nocache_headers() en dergelijke):
		// niet opslaan (L2 van de security-audit van 2026-11-25).
		if ( 'cache-control' === $name && 1 === preg_match( '/(^|[\s,])(no-store|private)([\s,=]|$)/i', $parts[1] ?? '' ) ) {
			return false;
		}
		if ( 'content-type' === $name && null === $type ) {
			$type = strtolower( trim( (string) strtok( $parts[1] ?? '', ';' ) ) );
		}
	}
	if ( null !== $type && 'text/html' !== $type ) {
		return false;
	}
	return str_ends_with( strtolower( rtrim( $html ) ), '</html>' );
}

/**
 * De headers die met de pagina mee bewaard worden.
 *
 * @param string[] $headers Verstuurde headers.
 * @return string[]
 */
function _ww_page_cache_keep_headers( array $headers ): array {
	$keep = array();
	foreach ( $headers as $header ) {
		$name = strtolower( trim( explode( ':', $header, 2 )[0] ) );
		if ( ! in_array( $name, WW_PAGE_CACHE_KEEP_HEADERS, true ) ) {
			continue;
		}
		if ( 'link' === $name && ! preg_match( '/rel="?(canonical|alternate)"?/i', $header ) ) {
			continue;
		}
		$keep[] = $header;
	}
	return $keep;
}

/**
 * Hoe lang een pagina hoogstens bewaard blijft, in seconden.
 */
function _ww_page_cache_max_age(): int {
	/**
	 * Hoe lang een pagina hoogstens in de paginacache blijft. Een pagina die ww_cache_ttl meldt, korter.
	 *
	 * @param int $seconds Standaard een dag.
	 */
	return max( 60, (int) apply_filters( 'ww_page_cache_max_age', WW_PAGE_CACHE_MAX_AGE ) );
}

/**
 * Bewaart de opgebouwde pagina. Draait in de outputbuffer: geen uitvoer, geen ob_*-functies, en nooit een fout naar
 * de bezoeker.
 *
 * @param mixed $output De HTML die naar de bezoeker gaat.
 */
function _ww_page_cache_store_output( $output ): void {
	try {
		$state = _ww_page_cache_state();
		if ( null === $state['key'] || $state['nocache'] || ( defined( 'DONOTCACHEPAGE' ) && DONOTCACHEPAGE ) || ! _ww_page_cache_page_number_exists() ) {
			return;
		}
		$headers = headers_list();
		$status  = http_response_code();
		if ( ! is_string( $output ) || ! _ww_page_cache_should_store( false === $status ? 200 : (int) $status, $headers, $output ) ) {
			return;
		}
		if ( ! headers_sent() ) {
			header( _ww_page_cache_timing_header( 'MISS' ) );
		}
		$types   = array_values( array_unique( array_merge( array_map( 'strval', array_keys( $state['types'] ) ), _ww_page_cache_archive_types() ) ) );
		$post_id = is_singular() ? (int) get_queried_object_id() : 0;
		sort( $types );
		// Begonnen vóór een purge (een opslag tijdens het opbouwen): dan is deze HTML al oud.
		$started = _ww_page_cache_request_time();
		if ( _ww_page_cache_is_stale( $started, $types, $post_id, _ww_page_cache_marker() ) ) {
			return;
		}
		$max_age = _ww_page_cache_max_age();
		$ttl     = $state['ttl'] > 0 ? min( $state['ttl'], $max_age ) : $max_age;
		$scheme  = (string) wp_parse_url( home_url(), PHP_URL_SCHEME );
		$written = _ww_page_cache_write(
			$state['key'],
			$output,
			array(
				'url'        => $scheme . '://' . $state['host'] . $state['path'],
				'path'       => $state['path'],
				'created'    => $started,
				'expires'    => time() + $ttl,
				'post_id'    => $post_id,
				'post_types' => $types,
				'headers'    => _ww_page_cache_keep_headers( $headers ),
				// Een eigen, kortere bewaartijd (ww_cache_ttl): dan niet statisch, zie _ww_page_cache_html_name().
				'ttl'        => $state['ttl'] > 0 && $ttl < $max_age ? $ttl : 0,
			)
		);
		// Tijdens het schrijven geleegd: de server kijkt niet naar de marker, dus de pagina zelf weer weg. De marker
		// opnieuw lezen: een ander verzoek kan hem intussen hebben bijgewerkt.
		$marker_after = _ww_page_cache_marker();
		if ( $written && _ww_page_cache_is_stale( $started, $types, $post_id, $marker_after ) ) {
			_ww_page_cache_unlink( _ww_page_cache_dir() . '/' . $state['key'] );
		}
	} catch ( Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch -- een cache die niet schrijft, is geen fout voor de bezoeker.
		unset( $e );
	}
}

/**
 * Post types van het archief dat nu wordt getoond: het archief van een post type, de blogpagina, of een termarchief
 * (de post types van zijn taxonomie). Ook een leeg archief moet leeg als er een item bijkomt, en dan heeft geen kaart
 * ww_shows_post_type gemeld.
 *
 * @return string[]
 */
function _ww_page_cache_archive_types(): array {
	if ( is_post_type_archive() ) {
		return array_values( array_filter( array_map( 'strval', (array) get_query_var( 'post_type' ) ) ) );
	}
	if ( is_home() ) {
		return array( 'post' );
	}
	if ( is_category() || is_tag() || is_tax() ) {
		$term     = get_queried_object();
		$taxonomy = $term instanceof WP_Term ? get_taxonomy( $term->taxonomy ) : false;
		return $taxonomy ? array_values( array_map( 'strval', $taxonomy->object_type ) ) : array();
	}
	return array();
}

/**
 * Begin van dit verzoek, als microtime.
 */
function _ww_page_cache_request_time(): float {
	$time = $_SERVER['REQUEST_TIME_FLOAT'] ?? null;
	return is_numeric( $time ) ? (float) $time : microtime( true );
}

/**
 * Schrijft een pagina en zijn meta.json, elk atomisch (eerst een tijdelijk bestand, dan hernoemen). Eerst de regels
 * van de cachemap en meta.json, dan de HTML: een index.html kan de server zonder PHP sturen, dus die mag er nooit
 * staan zonder meta.json (dan vindt legen hem niet) of zonder de headers uit de regels.
 *
 * @param array<string,mixed> $meta Gegevens over de pagina.
 */
function _ww_page_cache_write( string $key, string $html, array $meta ): bool {
	$root = _ww_page_cache_dir();
	$dir  = $root . '/' . $key;
	if ( ! wp_mkdir_p( $dir ) || ! _ww_page_cache_dir_rules( $root ) ) {
		return false;
	}
	$path         = is_string( $meta['path'] ?? null ) ? $meta['path'] : '';
	$headers      = array_values( array_filter( (array) ( $meta['headers'] ?? array() ), 'is_string' ) );
	$file         = _ww_page_cache_html_name( $path, $headers, (int) ( $meta['ttl'] ?? 0 ) );
	$meta['file'] = $file;
	$html        .= "\n<!-- ww page cache " . gmdate( 'Y-m-d H:i:s' ) . " UTC -->\n";
	if ( ! _ww_page_cache_put( $dir . '/meta.json', (string) wp_json_encode( $meta ) ) ) {
		return false;
	}
	// De andere naam weg: een pagina die nu wel een header als X-Robots-Tag heeft, mag niet meer statisch uit de cache.
	@unlink( $dir . '/' . ( WW_PAGE_CACHE_STATIC_FILE === $file ? WW_PAGE_CACHE_PHP_FILE : WW_PAGE_CACHE_STATIC_FILE ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink, WordPress.PHP.NoSilencedErrors -- de eigen cachemap.
	if ( ! _ww_page_cache_put( $dir . '/' . $file, $html ) ) {
		return false;
	}
	// Tussen meta.json en de HTML geleegd: dan zou de HTML zonder meta.json blijven staan, en nooit meer weggaan.
	clearstatcache();
	if ( ! is_file( $dir . '/meta.json' ) ) {
		_ww_page_cache_unlink( $dir );
		return false;
	}
	return true;
}

/**
 * Naam van de HTML: index.html als de server hem ook zonder PHP mag sturen, anders page.html. Statisch alleen bij een
 * pad met een slash aan het eind (de regels in .htaccess zoeken alleen daar, zodat `/diensten` nooit dezelfde pagina
 * krijgt als `/diensten/`) en als er geen andere bewaarde header is dan Content-Type text/html in UTF-8: een statisch
 * bestand krijgt alleen de headers uit de regels van de cachemap, en een X-Robots-Tag: noindex mag niet wegvallen.
 *
 * Ook via PHP:
 * - een pad met een %-code: de server decodeert de URL voordat hij het bestand zoekt, de sleutel niet, dus
 *   `/caf%25C3%25A9/` zou anders de pagina van `/caf%C3%A9/` krijgen;
 * - een pagina met een eigen, kortere bewaartijd (ww_cache_ttl, zoals openingstijden): zonder PHP kijkt niemand naar
 *   de verloopdatum, en blijft de pagina staan tot de opruiming van elk uur.
 *
 * @param string[] $headers Bewaarde headers (_ww_page_cache_keep_headers()).
 * @param int      $ttl     Eigen bewaartijd in seconden, of 0 voor de gewone.
 */
function _ww_page_cache_html_name( string $path, array $headers, int $ttl = 0 ): string {
	if ( ! str_ends_with( $path, '/' ) || str_contains( $path, '%' ) || $ttl > 0 ) {
		return WW_PAGE_CACHE_PHP_FILE;
	}
	foreach ( $headers as $header ) {
		$parts = explode( ':', $header, 2 );
		if ( 'content-type' !== strtolower( trim( $parts[0] ) ) || ! preg_match( '#^text/html\s*(;\s*charset="?utf-8"?\s*)?$#i', trim( $parts[1] ?? '' ) ) ) {
			return WW_PAGE_CACHE_PHP_FILE;
		}
	}
	return WW_PAGE_CACHE_STATIC_FILE;
}

/**
 * Regels voor de bestanden in de cachemap, in een .htaccess in die map: tekenset en headers voor een pagina die de
 * server zonder PHP stuurt, en meta.json en tijdelijke bestanden niet op te vragen. Cache-Control: no-cache, omdat de
 * server bij een statisch bestand Last-Modified meestuurt: zonder zou de browser de pagina zelf een tijd bewaren, en is
 * een geleegde pagina niet meteen bij de bezoeker (beslissing 0022). Alleen directives van AllowOverride FileInfo.
 *
 * @return string[]
 */
function _ww_page_cache_dir_rules_lines(): array {
	return array(
		'# Webwerckt Base: paginacache (beslissing 0029). Het thema schrijft dit bestand zelf; aanpassen heeft geen zin.',
		'AddDefaultCharset UTF-8',
		'<IfModule mod_headers.c>',
		'Header set Cache-Control "no-cache"',
		'Header set X-WW-Cache "STATIC"',
		'Header set Server-Timing "ww-cache;desc=\"STATIC\""',
		'</IfModule>',
		'<IfModule mod_rewrite.c>',
		'RewriteEngine On',
		'RewriteRule (^|/)(meta\.json|page\.html|[^/]+\.tmp)$ - [F]',
		'</IfModule>',
	);
}

/**
 * Zet de .htaccess in de cachemap neer als hij er niet (meer) is: na een purge is de map nieuw.
 */
function _ww_page_cache_dir_rules( string $root ): bool {
	$file = $root . '/.htaccess';
	return is_file( $file ) || _ww_page_cache_put( $file, implode( "\n", _ww_page_cache_dir_rules_lines() ) . "\n" );
}

/**
 * Verwijdert één bewaarde pagina: eerst de HTML (die kan de server zonder PHP sturen), dan meta.json.
 */
function _ww_page_cache_unlink( string $dir ): void {
	// phpcs:disable WordPress.WP.AlternativeFunctions, WordPress.PHP.NoSilencedErrors -- de eigen cachemap.
	@unlink( $dir . '/' . WW_PAGE_CACHE_STATIC_FILE );
	@unlink( $dir . '/' . WW_PAGE_CACHE_PHP_FILE );
	@unlink( $dir . '/meta.json' );
	// phpcs:enable
}

/**
 * Schrijft een bestand atomisch.
 */
function _ww_page_cache_put( string $file, string $data ): bool {
	$tmp = $file . '.' . wp_generate_password( 8, false ) . '.tmp';
	// phpcs:disable WordPress.WP.AlternativeFunctions, WordPress.PHP.NoSilencedErrors -- gegenereerde cache, net als de samengevoegde CSS.
	if ( false === @file_put_contents( $tmp, $data, LOCK_EX ) ) {
		return false;
	}
	if ( ! @rename( $tmp, $file ) ) {
		@unlink( $tmp );
		return false;
	}
	// phpcs:enable
	return true;
}

/**
 * Leegt de hele cache. Eerst het moment van de purge vastleggen: een pagina die daarvoor werd opgebouwd, is oud, ook
 * als hij nog na deze purge wordt geschreven. Dan de map hernoemen (een bezoeker ziet meteen een lege cache, nooit een
 * halve) en verwijderen. Lukt het hernoemen niet, dan meteen ter plekke verwijderen: de regels in .htaccess kijken niet
 * naar de marker. Ook achtergebleven mappen van een eerdere purge gaan weg.
 */
function _ww_page_cache_flush(): void {
	$dir = _ww_page_cache_dir();
	_ww_page_cache_mark( 'all' );
	// phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename, WordPress.PHP.NoSilencedErrors -- lukt het niet, dan ter plekke.
	if ( is_dir( $dir ) && ! @rename( $dir, $dir . '-trash-' . wp_generate_password( 8, false ) ) ) {
		_ww_page_cache_rmdir( $dir );
	}
	foreach ( glob( $dir . '-trash-*', GLOB_ONLYDIR ) ?: array() as $trash ) {
		_ww_page_cache_rmdir( $trash );
	}
}

/**
 * Verwijdert een map met alles erin.
 */
function _ww_page_cache_rmdir( string $dir ): void {
	$items = new RecursiveIteratorIterator(
		new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ),
		RecursiveIteratorIterator::CHILD_FIRST
	);
	// phpcs:disable WordPress.WP.AlternativeFunctions, WordPress.PHP.NoSilencedErrors -- de eigen cachemap.
	foreach ( $items as $item ) {
		if ( $item instanceof SplFileInfo ) {
			$item->isDir() && ! $item->isLink() ? @rmdir( $item->getPathname() ) : @unlink( $item->getPathname() );
		}
	}
	@rmdir( $dir );
	// phpcs:enable
}

/**
 * Legt het moment van een purge vast in de marker: van alles ('all'), van een post type of van een bericht. Een
 * pagina die daarvoor werd opgebouwd, komt dan nooit meer uit de cache, ook als hij nog na de purge wordt geschreven.
 * Oude regels gaan eruit: een purge van langer dan de maximale bewaartijd geleden, of van vóór de laatste 'all',
 * raakt geen enkele bewaarde pagina meer.
 *
 * @param string     $scope 'all', 'types' of 'posts'.
 * @param string|int $id    Post type of bericht-ID (niet bij 'all').
 */
function _ww_page_cache_mark( string $scope, $id = '' ): void {
	if ( ! wp_mkdir_p( dirname( _ww_page_cache_dir() ) ) ) {
		return;
	}
	$now    = microtime( true );
	$marker = _ww_page_cache_marker();
	if ( 'all' === $scope ) {
		$marker['all'] = $now;
	} elseif ( 'types' === $scope ) {
		$marker['types'][ (string) $id ] = $now;
	} else {
		$marker['posts'][ (int) $id ] = $now;
	}
	$oldest = max( $marker['all'], $now - _ww_page_cache_max_age() );
	$keep   = static fn( float $time ): bool => $time > $oldest;

	$marker['types'] = array_filter( $marker['types'], $keep );
	$marker['posts'] = array_filter( $marker['posts'], $keep );
	if ( _ww_page_cache_put( _ww_page_cache_marker_file(), WW_PAGE_CACHE_MARKER_GUARD . (string) wp_json_encode( $marker ) ) ) {
		wp_delete_file( _ww_page_cache_old_marker_file() );
	}
}

/**
 * Verwijdert de bewaarde pagina's waarvan de meta.json aan de voorwaarde voldoet. Eerst de HTML, dan meta.json: de
 * server kan de HTML zonder PHP sturen en kijkt alleen of het bestand er is. Leest alle meta.json-bestanden; bij een
 * paar honderd pagina's is dat snel genoeg (open vraag 3 van de spec).
 *
 * @param callable(array<string,mixed>):bool $matches Voorwaarde op de meta.json.
 * @return int Aantal verwijderde pagina's.
 */
function _ww_page_cache_delete_where( callable $matches ): int {
	$root = _ww_page_cache_dir();
	if ( ! is_dir( $root ) ) {
		return 0;
	}
	$deleted = 0;
	$files   = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $root, FilesystemIterator::SKIP_DOTS ) );
	foreach ( $files as $file ) {
		if ( ! $file instanceof SplFileInfo || 'meta.json' !== $file->getFilename() ) {
			continue;
		}
		$meta = json_decode( (string) file_get_contents( $file->getPathname() ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- de eigen cachemap.
		if ( ! is_array( $meta ) || $matches( $meta ) ) {
			_ww_page_cache_unlink( $file->getPath() );
			++$deleted;
		}
	}
	return $deleted;
}

/**
 * Leegt de hele cache (_ww_purge_all, en bij een ander thema).
 */
function _ww_page_cache_purge_all(): void {
	_ww_page_cache_flush();
}
add_action( '_ww_purge_all', '_ww_page_cache_purge_all', 10, 0 );
add_action( 'switch_theme', '_ww_page_cache_purge_all', 10, 0 );

/**
 * Leegt de pagina's die items van dit post type tonen (_ww_purge_post_type). Een archief telt mee voor zijn post
 * type, ook als het leeg was.
 *
 * @param mixed $post_type Post type.
 */
function _ww_page_cache_purge_post_type( $post_type ): void {
	$post_type = _ww_data_to_string( $post_type );
	if ( '' === $post_type ) {
		return;
	}
	_ww_page_cache_mark( 'types', $post_type );
	_ww_page_cache_delete_where( static fn( array $meta ): bool => in_array( $post_type, (array) ( $meta['post_types'] ?? array() ), true ) );
}
add_action( '_ww_purge_post_type', '_ww_page_cache_purge_post_type' );

/**
 * Leegt de eigen pagina van een bericht (_ww_purge_post), ook onder een oude URL na een gewijzigde slug: de pagina is
 * te vinden aan het bericht-ID in de meta.json.
 *
 * @param mixed $post_id Bericht-ID.
 */
function _ww_page_cache_purge_post( $post_id ): void {
	$post_id = absint( $post_id );
	if ( 0 === $post_id ) {
		return;
	}
	_ww_page_cache_mark( 'posts', $post_id );
	_ww_page_cache_delete_where( static fn( array $meta ): bool => $post_id === (int) ( $meta['post_id'] ?? 0 ) );
}
add_action( '_ww_purge_post', '_ww_page_cache_purge_post' );

/**
 * Ruimt verlopen pagina's op (elk uur, via de cron). Zonder PHP kijkt niemand naar de verloopdatum: een pagina die de
 * server statisch stuurt, blijft staan tot deze opruiming, dus hoogstens een uur langer dan zijn geldigheid (met een
 * echte cron die minstens elk uur draait).
 */
function _ww_page_cache_cleanup(): void {
	$root = _ww_page_cache_dir();
	if ( ! is_dir( $root ) ) {
		return;
	}
	$files = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $root, FilesystemIterator::SKIP_DOTS ) );
	foreach ( $files as $file ) {
		if ( ! $file instanceof SplFileInfo ) {
			continue;
		}
		$name = $file->getFilename();
		// Een HTML zonder meta.json is altijd een wees (meta.json komt eerst): weg, de server zou hem blijven sturen.
		if ( in_array( $name, array( WW_PAGE_CACHE_STATIC_FILE, WW_PAGE_CACHE_PHP_FILE ), true ) && ! is_file( $file->getPath() . '/meta.json' ) ) {
			_ww_page_cache_unlink( $file->getPath() );
			continue;
		}
		if ( 'meta.json' !== $name ) {
			continue;
		}
		$meta = json_decode( (string) file_get_contents( $file->getPathname() ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- de eigen cachemap.
		if ( ! is_array( $meta ) || (int) ( $meta['expires'] ?? 0 ) <= time() ) {
			_ww_page_cache_unlink( $file->getPath() );
		}
	}
	foreach ( glob( $root . '-trash-*', GLOB_ONLYDIR ) ?: array() as $trash ) {
		_ww_page_cache_rmdir( $trash );
	}
}
add_action( WW_PAGE_CACHE_CRON_HOOK, '_ww_page_cache_cleanup' );

/**
 * Leegt de cache als hij in een oudere indeling staat (WW_PAGE_CACHE_FORMAT). Zo stuurt de server na een update nooit
 * een index.html van vóór beslissing 0029 statisch, die nu page.html had moeten heten.
 */
function _ww_page_cache_format_check(): void {
	if ( WW_PAGE_CACHE_FORMAT === (int) get_option( WW_PAGE_CACHE_FORMAT_OPTION ) ) {
		return;
	}
	if ( is_dir( _ww_page_cache_dir() ) ) {
		_ww_page_cache_flush();
	}
	update_option( WW_PAGE_CACHE_FORMAT_OPTION, WW_PAGE_CACHE_FORMAT, false );
}

/**
 * Bij een adminbezoek: de genegeerde parameters en extra hosts bijwerken voor de mu-plugin, de opruiming elk uur
 * plannen, en de cache legen als hij uit staat of in een oude indeling.
 */
function _ww_page_cache_admin_sync(): void {
	_ww_page_cache_format_check();
	/**
	 * Parameters die niet meetellen voor de sleutel van de paginacache; een * aan het eind is een voorvoegsel.
	 * Elke andere parameter in de URL slaat de cache over.
	 *
	 * @param string[] $params Standaard utm_*, gclid, fbclid, msclkid en dergelijke.
	 */
	$params = array_values( array_filter( (array) apply_filters( 'ww_page_cache_ignored_params', WW_PAGE_CACHE_IGNORED_PARAMS ), 'is_string' ) );
	if ( get_option( WW_PAGE_CACHE_PARAMS_OPTION ) !== $params ) {
		update_option( WW_PAGE_CACHE_PARAMS_OPTION, $params, true );
	}
	/**
	 * Hosts naast die van de site-URL waarvoor de paginacache geldt, bijvoorbeeld een tweede domein met dezelfde site.
	 * Met poort als die afwijkt: 'example.de' of 'example.de:8080'. Elke andere Host-header slaat de cache over.
	 *
	 * @param string[] $hosts Standaard geen.
	 */
	$hosts = array_values( array_map( 'strtolower', array_filter( (array) apply_filters( 'ww_page_cache_hosts', array() ), 'is_string' ) ) );
	if ( get_option( WW_PAGE_CACHE_HOSTS_OPTION ) !== $hosts ) {
		update_option( WW_PAGE_CACHE_HOSTS_OPTION, $hosts, true );
	}
	_ww_page_cache_schedule();
	if ( '' !== _ww_page_cache_status() && is_dir( _ww_page_cache_dir() ) ) {
		_ww_page_cache_flush();
	}
}
add_action( 'admin_init', '_ww_page_cache_admin_sync', 20 );

/**
 * Plant de opruiming elk uur, ook op een site die nog de dagelijkse opruiming van vóór beslissing 0029 had.
 */
function _ww_page_cache_schedule(): void {
	if ( 'hourly' !== wp_get_schedule( WW_PAGE_CACHE_CRON_HOOK ) ) {
		wp_clear_scheduled_hook( WW_PAGE_CACHE_CRON_HOOK );
		wp_schedule_event( time() + 5 * MINUTE_IN_SECONDS, 'hourly', WW_PAGE_CACHE_CRON_HOOK );
	}
}

/**
 * Ander thema: de opruiming hoeft niet meer.
 */
function _ww_page_cache_unschedule(): void {
	wp_clear_scheduled_hook( WW_PAGE_CACHE_CRON_HOOK );
}
add_action( 'switch_theme', '_ww_page_cache_unschedule' );

/**
 * Alle bewaarde pagina's, voor het menu Pagina cache: sleutel (map ten opzichte van de cache), URL, tijden, post
 * types, bericht, grootte in bytes en of de server hem zonder PHP mag sturen. Ook verlopen pagina's, tot de opruiming
 * ze weghaalt.
 *
 * @return list<array{key:string,url:string,created:float,expires:int,post_types:string[],post_id:int,size:int}>
 */
function _ww_page_cache_entries(): array {
	$root = _ww_page_cache_dir();
	if ( ! is_dir( $root ) ) {
		return array();
	}
	$entries = array();
	$files   = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $root, FilesystemIterator::SKIP_DOTS ) );
	foreach ( $files as $file ) {
		if ( ! $file instanceof SplFileInfo || 'meta.json' !== $file->getFilename() ) {
			continue;
		}
		$meta = json_decode( (string) file_get_contents( $file->getPathname() ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- de eigen cachemap.
		$html = is_array( $meta ) ? $file->getPath() . '/' . _ww_page_cache_html_file( $meta ) : '';
		if ( ! is_array( $meta ) || ! is_file( $html ) ) {
			continue;
		}
		$key       = ltrim( str_replace( '\\', '/', substr( $file->getPath(), strlen( $root ) ) ), '/' );
		$entries[] = array(
			'key'        => $key,
			'url'        => is_string( $meta['url'] ?? null ) ? $meta['url'] : '',
			'created'    => (float) ( $meta['created'] ?? 0 ),
			'expires'    => (int) ( $meta['expires'] ?? 0 ),
			'post_types' => array_values( array_filter( (array) ( $meta['post_types'] ?? array() ), 'is_string' ) ),
			'post_id'    => (int) ( $meta['post_id'] ?? 0 ),
			'size'       => (int) filesize( $html ) + (int) $file->getSize(),
		);
	}
	return $entries;
}

/**
 * Leegt één bewaarde pagina, op zijn sleutel. Alleen een sleutel die een bestaande pagina in de cachemap is; een
 * pagina die nu net wordt opgebouwd, komt na het legen ook niet uit de cache (de marker, als hij bij een bericht hoort).
 *
 * @return bool Of er een pagina was.
 */
function _ww_page_cache_purge_key( string $key ): bool {
	if ( ! preg_match( '#^[a-z0-9._-]+(/[A-Za-z0-9\-._~%]+)*$#', $key ) || preg_match( '#(^|/)\.#', $key ) ) {
		return false;
	}
	$dir  = _ww_page_cache_dir() . '/' . $key;
	$meta = _ww_page_cache_read_meta( $dir );
	if ( null === $meta ) {
		return false;
	}
	$post_id = (int) ( $meta['post_id'] ?? 0 );
	if ( $post_id > 0 ) {
		_ww_page_cache_mark( 'posts', $post_id );
	}
	_ww_page_cache_unlink( $dir );
	return true;
}

/**
 * Leegt de pagina's van een pad (_ww_purge_path), bij een voorvoegsel ook alles eronder. Het pad is het verzoekpad in kleine
 * letters, met slash en inclusief het pad van de site-URL bij een submap-installatie; de pagina's bewaren hun pad zoals
 * de bezoeker het vroeg, dus daar vergelijken we in kleine letters.
 *
 * @param mixed $path   Verzoekpad in kleine letters, bijvoorbeeld /oud/ (bij een submap-installatie /submap/oud/).
 * @param mixed $prefix Ook alle paden eronder legen?
 */
function _ww_page_cache_purge_path( $path, $prefix = false ): void {
	$path   = strtolower( is_string( $path ) ? $path : '' );
	$prefix = (bool) $prefix;
	if ( '' === $path ) {
		return;
	}
	_ww_page_cache_delete_where(
		static function ( array $meta ) use ( $path, $prefix ): bool {
			$page = strtolower( (string) ( $meta['path'] ?? '' ) );
			return $prefix ? str_starts_with( $page, $path ) : $page === $path;
		}
	);
}
add_action( '_ww_purge_path', '_ww_page_cache_purge_path', 10, 2 );
