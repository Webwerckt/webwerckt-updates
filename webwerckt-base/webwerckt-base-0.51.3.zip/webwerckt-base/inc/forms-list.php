<?php
/**
 * De lijst Formulieren (edit.php?post_type=ww_form): kolommen Velden, Inzendingen, Staat op en Code, en de rij-actie
 * Inzendingen. Ontwerp: docs/superpowers/plans/2026-11-14-formulieren-zijpaneel.md.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Per formulier-ID de ID's van de gepubliceerde berichten en pagina's die het formulier plaatsen.
 *
 * Twee query's: op de inhoud en op de velden van een pagina (postmeta, zonder privé-sleutels met _). Op child-thema's
 * staat de shortcode in een veld en haalt de kopie naar post_content hem eruit (inc/content.php). Elke treffer wordt
 * met de shortcode-regex ontleed (_ww_forms_placements_parse()), zodat id="1" niet bij 12 hoort; een bericht telt per
 * formulier één keer. Het resultaat geldt voor één verzoek (niet-blijvende objectcache) en wordt geleegd zodra een
 * bericht of een veld verandert. De berichten zelf komen in één keer in de cache (_prime_post_caches()), zodat de
 * titels en bewerklinks van de kolom Staat op geen query per rij kosten.
 *
 * @return array<int,list<int>>
 */
function _ww_forms_placements(): array {
	global $wpdb;
	$found = false;
	$cache = wp_cache_get( 'placements', 'ww_forms_list', false, $found );
	if ( $found && is_array( $cache ) ) {
		return $cache;
	}

	$types  = array_values( get_post_types( array( 'public' => true ) ) );
	$result = array();
	if ( array() !== $types ) {
		$in   = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		$like = '%' . $wpdb->esc_like( '[ww_form ' ) . '%';
		$rows = array_merge(
			(array) $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_content AS text FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN ($in) AND post_content LIKE %s", array_merge( $types, array( $like ) ) ) ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- tabelnaam van WordPress, placeholders voor de post types.
			(array) $wpdb->get_results( $wpdb->prepare( "SELECT p.ID, m.meta_value AS text FROM {$wpdb->postmeta} m INNER JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE p.post_status = 'publish' AND p.post_type IN ($in) AND m.meta_key NOT LIKE %s AND m.meta_value LIKE %s", array_merge( $types, array( $wpdb->esc_like( '_' ) . '%', $like ) ) ) ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.SlowDBQuery.slow_db_query_meta_key, WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- tabelnamen van WordPress, placeholders voor de post types; één query per verzoek.
		);
		foreach ( $rows as $row ) {
			foreach ( _ww_forms_placements_parse( (string) $row->text ) as $form_id ) {
				$result[ $form_id ][] = (int) $row->ID;
			}
		}
		foreach ( $result as $form_id => $ids ) {
			$ids = array_values( array_unique( $ids ) );
			sort( $ids );
			$result[ $form_id ] = $ids;
		}
		$posts = array_values( array_unique( array_merge( ...array_values( $result ) ) ) );
		if ( array() !== $posts ) {
			_prime_post_caches( $posts, false, false );
		}
	}
	wp_cache_set( 'placements', $result, 'ww_forms_list' );
	return $result;
}
wp_cache_add_non_persistent_groups( array( 'ww_forms_list' ) );

/**
 * De formulier-ID's van de [ww_form]-shortcodes in een tekst. Een slug gaat via get_page_by_path() naar een ID;
 * [[ww_form]] is geëscapet en telt niet.
 *
 * @param string $text Inhoud of waarde van een veld.
 * @return list<int>
 */
function _ww_forms_placements_parse( string $text ): array {
	if ( ! preg_match_all( '/' . get_shortcode_regex( array( 'ww_form' ) ) . '/', $text, $matches, PREG_SET_ORDER ) ) {
		return array();
	}
	$ids = array();
	foreach ( $matches as $match ) {
		if ( '[' === $match[1] && ']' === $match[6] ) {
			continue;
		}
		$atts    = shortcode_parse_atts( $match[3] ); // Zonder attributen geeft WordPress een lege string; isset() op een string met een tekstsleutel is false.
		$form_id = 0;
		if ( isset( $atts['id'] ) && ctype_digit( (string) $atts['id'] ) ) {
			$form_id = (int) $atts['id'];
		} elseif ( isset( $atts['slug'] ) && '' !== (string) $atts['slug'] ) {
			$form    = get_page_by_path( (string) $atts['slug'], OBJECT, WW_FORM_POST_TYPE );
			$form_id = $form instanceof WP_Post ? (int) $form->ID : 0;
		}
		if ( $form_id > 0 ) {
			$ids[] = $form_id;
		}
	}
	return $ids;
}

/**
 * De inzendingen van een formulier voor de lijst en het paneel, zonder spam: alles en de nieuwe, opgeteld over de
 * vertaalgroep (_ww_form_group_ids()). Dat is dezelfde groep die de link naar Inzendingen toont
 * (_ww_form_entries_form_filter()); zonder Meertalig alleen het formulier zelf.
 *
 * @param int $form_id Formulier.
 * @return array{all:int,new:int}
 */
function _ww_forms_group_entry_counts( int $form_id ): array {
	$counts = _ww_form_entries_counts_by_form();
	$sum    = array(
		'all' => 0,
		'new' => 0,
	);
	foreach ( _ww_form_group_ids( $form_id ) as $id ) {
		$sum['all'] += $counts[ $id ]['all'] ?? 0;
		$sum['new'] += $counts[ $id ]['new'] ?? 0;
	}
	return $sum;
}

/**
 * De pagina's waar een formulier op staat, over de vertaalgroep (_ww_form_group_ids()): een pagina met het ID van
 * de bron toont in een andere taal de vertaling (_ww_form_translation_resolve()), dus elk formulier van de groep staat
 * daar. Gesorteerd, elke pagina één keer.
 *
 * @param int $form_id Formulier.
 * @return list<int>
 */
function _ww_forms_group_placements( int $form_id ): array {
	$all = _ww_forms_placements();
	$ids = array();
	foreach ( _ww_form_group_ids( $form_id ) as $id ) {
		$ids = array_merge( $ids, $all[ $id ] ?? array() );
	}
	$ids = array_values( array_unique( $ids ) );
	sort( $ids );
	return $ids;
}

/**
 * De pagina's waar een formulier (of een ander formulier van zijn vertaalgroep) op staat, als links naar bewerken:
 * hoogstens $max, daarna "+{n}". Leeg als het formulier nergens staat. Gedeeld door de kolom Staat op en de kaart
 * Plaatsen op het bewerkscherm.
 *
 * @param int $form_id Formulier.
 * @param int $max     Hoeveel titels hoogstens.
 * @return string Geëscapete HTML.
 */
function _ww_forms_placement_links( int $form_id, int $max = 3 ): string {
	$ids = _ww_forms_group_placements( $form_id );
	if ( array() === $ids ) {
		return '';
	}
	$links = array();
	foreach ( array_slice( $ids, 0, $max ) as $page_id ) {
		$title   = get_the_title( $page_id );
		$title   = '' !== $title ? $title : __( '(zonder titel)', 'webwerckt-base' );
		$edit    = get_edit_post_link( $page_id );
		$links[] = $edit ? sprintf( '<a href="%s">%s</a>', esc_url( $edit ), esc_html( $title ) ) : esc_html( $title );
	}
	$html = implode( ', ', $links );
	if ( count( $ids ) > $max ) {
		$html .= ' <span class="description">+' . esc_html( (string) ( count( $ids ) - $max ) ) . '</span>';
	}
	return $html;
}

/**
 * Leegt de plaatsingen zodra een bericht of een veld verandert.
 */
function _ww_forms_placements_flush(): void {
	wp_cache_delete( 'placements', 'ww_forms_list' );
}
add_action( 'save_post', '_ww_forms_placements_flush' );
add_action( 'deleted_post', '_ww_forms_placements_flush' );
add_action( 'transition_post_status', '_ww_forms_placements_flush' );
add_action( 'added_post_meta', '_ww_forms_placements_flush' );
add_action( 'updated_post_meta', '_ww_forms_placements_flush' );
add_action( 'deleted_post_meta', '_ww_forms_placements_flush' );

/**
 * De kolommen van de lijst: Velden, Inzendingen, Staat op en Code tussen titel en datum.
 *
 * @param array<string,string> $columns Kolommen.
 * @return array<string,string>
 */
function _ww_forms_list_columns( array $columns ): array {
	$mine = array(
		'ww_fields'  => __( 'Velden', 'webwerckt-base' ),
		'ww_entries' => __( 'Inzendingen', 'webwerckt-base' ),
		'ww_pages'   => __( 'Staat op', 'webwerckt-base' ),
		'ww_code'    => __( 'Code', 'webwerckt-base' ),
	);
	$new  = array();
	foreach ( $columns as $key => $label ) {
		if ( 'date' === $key ) {
			$new += $mine;
		}
		$new[ $key ] = $label;
	}
	return array_key_exists( 'ww_fields', $new ) ? $new : $new + $mine;
}
add_filter( 'manage_ww_form_posts_columns', '_ww_forms_list_columns' );

/**
 * De inhoud van een kolom.
 *
 * @param string $column  Kolom.
 * @param int    $post_id Formulier.
 */
function _ww_forms_list_column( string $column, int $post_id ): void {
	switch ( $column ) {
		case 'ww_fields':
			$config = _ww_form_config( $post_id ) ?? array();
			$fields = count( (array) ( $config['fields'] ?? array() ) );
			$steps  = count( (array) ( $config['steps'] ?? array() ) );
			echo esc_html( (string) $fields );
			if ( $steps > 0 ) {
				echo ' <span class="description">' . esc_html(
					sprintf(
						/* translators: %d: aantal stappen. */
						_n( 'in %d stap', 'in %d stappen', $steps, 'webwerckt-base' ),
						$steps
					)
				) . '</span>';
			}
			break;

		case 'ww_entries':
			$counts = _ww_forms_group_entry_counts( $post_id );
			if ( $counts['all'] <= 0 ) {
				echo '&ndash;';
				break;
			}
			// Alleen wie Inzendingen mag openen krijgt een link, net als de rij-actie en het paneel.
			echo current_user_can( 'edit_others_pages' )
				? '<a href="' . esc_url( _ww_forms_entries_url( array( 'form_id' => (string) $post_id ) ) ) . '">' . esc_html( (string) $counts['all'] ) . '</a>'
				: esc_html( (string) $counts['all'] );
			if ( $counts['new'] > 0 ) {
				echo ' <span class="ww-forms-new">' . esc_html(
					sprintf(
						/* translators: %d: aantal nieuwe inzendingen. */
						__( '%d nieuw', 'webwerckt-base' ),
						$counts['new']
					)
				) . '</span>';
			}
			break;

		case 'ww_pages':
			$links = _ww_forms_placement_links( $post_id );
			echo '' !== $links ? $links : '<span class="description">' . esc_html__( 'Nog nergens', 'webwerckt-base' ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- _ww_forms_placement_links() escapet.
			break;

		case 'ww_code':
			$tag = '[ww_form id="' . $post_id . '"]';
			printf(
				'<code>%1$s</code> <button type="button" class="button-link ww-forms-copy" data-ww-copy-text="%1$s" data-ww-copied="%2$s" aria-label="%3$s"><span class="dashicons dashicons-admin-page" aria-hidden="true"></span></button>',
				esc_html( $tag ),
				esc_attr__( 'Gekopieerd', 'webwerckt-base' ),
				esc_attr__( 'Code kopiëren', 'webwerckt-base' )
			);
			break;
	}
}
add_action( 'manage_ww_form_posts_custom_column', '_ww_forms_list_column', 10, 2 );

/**
 * De rij-actie Inzendingen tussen Bewerken en Prullenbak, alleen als het formulier (of zijn vertaalgroep) inzendingen
 * heeft.
 *
 * @param mixed $actions Rij-acties.
 * @param mixed $post    Formulier.
 * @return mixed
 */
function _ww_forms_list_row_actions( $actions, $post = null ) {
	if ( ! is_array( $actions ) || ! $post instanceof WP_Post || WW_FORM_POST_TYPE !== $post->post_type || 'trash' === $post->post_status || ! current_user_can( 'edit_others_pages' ) ) {
		return $actions;
	}
	$count = _ww_forms_group_entry_counts( (int) $post->ID )['all'];
	if ( $count <= 0 ) {
		return $actions;
	}
	$link = '<a href="' . esc_url( _ww_forms_entries_url( array( 'form_id' => (string) $post->ID ) ) ) . '">' . esc_html__( 'Inzendingen', 'webwerckt-base' ) . '</a>';
	$new  = array();
	$done = false;
	foreach ( $actions as $key => $action ) {
		if ( ! $done && in_array( $key, array( 'trash', 'delete' ), true ) ) {
			$new['ww_entries'] = $link;
			$done              = true;
		}
		$new[ $key ] = $action;
	}
	if ( ! $done ) {
		$new['ww_entries'] = $link;
	}
	return $new;
}
add_filter( 'post_row_actions', '_ww_forms_list_row_actions', 10, 2 );

/**
 * Het kopieerscript van de lijst (klein; de builder heeft zijn eigen), alleen op de lijst Formulieren.
 */
function _ww_forms_list_assets(): void {
	$screen = get_current_screen();
	if ( ! $screen || 'edit-' . WW_FORM_POST_TYPE !== $screen->id ) {
		return;
	}
	wp_register_script( 'ww-forms-list', false, array(), WW_BASE_VERSION, array( 'in_footer' => true ) );
	wp_enqueue_script( 'ww-forms-list' );
	wp_add_inline_script(
		'ww-forms-list',
		"document.addEventListener('click',function(e){var b=e.target.closest('[data-ww-copy-text]');if(!b){return;}var i=b.querySelector('.dashicons'),d=function(){b.setAttribute('title',b.dataset.wwCopied);if(i){i.className='dashicons dashicons-yes';}setTimeout(function(){b.removeAttribute('title');if(i){i.className='dashicons dashicons-admin-page';}},2000);};if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(b.dataset.wwCopyText).then(d);}});"
	);
}
add_action( 'admin_enqueue_scripts', '_ww_forms_list_assets' );
