<?php
/**
 * Mail (beslissing 0034): de SMTP-aansluiting.
 *
 * Zet de mailer van WordPress op SMTP met de instellingen van de site en verstuurt de mail zelf. Het wachtwoord komt uit
 * `WW_MAIL_SMTP_PASSWORD` of de versleutelde opslag en komt nooit in een foutmelding.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once dirname( __DIR__ ) . '/class-ww-phpmailer.php';

/**
 * Verstuurt mail via een SMTP-server.
 */
class WW_Mail_Transport_Smtp implements WW_Mail_Transport {

	/**
	 * Id van de aansluiting.
	 */
	public function id(): string {
		return 'smtp';
	}

	/**
	 * Naam op het scherm.
	 */
	public function label(): string {
		return 'SMTP';
	}

	/**
	 * Velddefinities voor het scherm.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public function settings(): array {
		return array(
			array(
				'name'     => 'host',
				'label'    => __( 'Server', 'webwerckt-base' ),
				'type'     => 'text',
				'default'  => '',
				'required' => true,
				'secret'   => false,
				'constant' => 'WW_MAIL_SMTP_HOST',
			),
			array(
				'name'     => 'port',
				'label'    => __( 'Poort', 'webwerckt-base' ),
				'type'     => 'number',
				'default'  => 587,
				'required' => false,
				'secret'   => false,
			),
			array(
				'name'     => 'secure',
				'label'    => __( 'Versleuteling', 'webwerckt-base' ),
				'type'     => 'select',
				'options'  => array(
					'tls' => __( 'TLS (STARTTLS)', 'webwerckt-base' ),
					'ssl' => __( 'SSL', 'webwerckt-base' ),
					''    => __( 'Geen', 'webwerckt-base' ),
				),
				'default'  => 'tls',
				'required' => false,
				'secret'   => false,
			),
			array(
				'name'     => 'username',
				'label'    => __( 'Gebruiker', 'webwerckt-base' ),
				'type'     => 'text',
				'default'  => '',
				'required' => false,
				'secret'   => false,
			),
			array(
				'name'     => 'password',
				'label'    => __( 'Wachtwoord', 'webwerckt-base' ),
				'type'     => 'password',
				'default'  => '',
				'required' => false,
				'secret'   => true,
				'constant' => 'WW_MAIL_SMTP_PASSWORD',
			),
		);
	}

	/**
	 * De server, schoongemaakt.
	 */
	private function host(): string {
		$constant = _ww_mail_constant( 'WW_MAIL_SMTP_HOST' );
		if ( null !== $constant ) {
			return trim( $constant );
		}
		$host = _ww_mail_setting( 'smtp', 'host', '' );
		return is_string( $host ) ? trim( $host ) : '';
	}

	/**
	 * De gebruiker, schoongemaakt.
	 */
	private function username(): string {
		$user = _ww_mail_setting( 'smtp', 'username', '' );
		return is_string( $user ) ? trim( $user ) : '';
	}

	/**
	 * Het wachtwoord, of null als het ontbreekt of niet te lezen is.
	 */
	private function password(): ?string {
		if ( ! $this->constant_password_fits() ) {
			return null;
		}
		return _ww_mail_secret( 'smtp', 'password', 'WW_MAIL_SMTP_PASSWORD' );
	}

	/**
	 * Staat het wachtwoord in wp-config.php en de server niet, dan gaat het wachtwoord alleen naar de server waarmee
	 * het voor het eerst werd gebruikt (optie ww_mail_smtp_password_host). Een beheerder kan de server op het scherm
	 * dus niet op een eigen host zetten om het wachtwoord op te vangen (M5 van de security-audit van 2026-11-25). Een
	 * andere server: zet hem met WW_MAIL_SMTP_HOST in wp-config.php.
	 */
	private function constant_password_fits(): bool {
		if ( null === _ww_mail_constant( 'WW_MAIL_SMTP_PASSWORD' ) || null !== _ww_mail_constant( 'WW_MAIL_SMTP_HOST' ) ) {
			return true;
		}
		$pinned = _ww_data_to_string( get_option( 'ww_mail_smtp_password_host', '' ) );
		return '' === $pinned || strtolower( $this->host() ) === $pinned;
	}

	/**
	 * Legt bij het eerste gebruik van een wachtwoord uit wp-config.php de server vast (zie constant_password_fits()).
	 */
	private function pin_constant_password_host(): void {
		$host = strtolower( $this->host() );
		if ( '' === $host || null === _ww_mail_constant( 'WW_MAIL_SMTP_PASSWORD' ) || null !== _ww_mail_constant( 'WW_MAIL_SMTP_HOST' ) ) {
			return;
		}
		if ( '' === _ww_data_to_string( get_option( 'ww_mail_smtp_password_host', '' ) ) ) {
			update_option( 'ww_mail_smtp_password_host', $host, false );
		}
	}

	/**
	 * Of de server is ingevuld en, bij een gebruiker, ook een leesbaar wachtwoord.
	 */
	public function is_configured(): bool {
		if ( '' === $this->host() ) {
			return false;
		}
		return '' === $this->username() || null !== $this->password();
	}

	/**
	 * Zet de mailer op SMTP volgens de instellingen.
	 *
	 * @param WW_PHPMailer $mail De mailer.
	 */
	public function configure( WW_PHPMailer $mail ): void {
		$port   = (int) _ww_mail_setting( 'smtp', 'port', 587 );
		$secure = _ww_mail_setting( 'smtp', 'secure', 'tls' );
		$secure = ( is_string( $secure ) && in_array( $secure, array( '', 'ssl', 'tls' ), true ) ) ? $secure : 'tls';
		$user   = $this->username();
		if ( '' !== $user ) {
			$this->pin_constant_password_host();
		}

		$mail->isSMTP();
		$mail->Host        = $this->host();
		$mail->Port        = $port > 0 ? $port : 587;
		$mail->SMTPSecure  = $secure;
		$mail->SMTPAutoTLS = '' !== $secure;
		$mail->SMTPAuth    = '' !== $user;
		$mail->Username    = $user;
		$mail->Password    = '' !== $user ? (string) $this->password() : '';
		$mail->SMTPDebug   = 0;
	}

	/**
	 * Verstuurt de mail. `wp_mail()` heeft de mailer als `mail` opgebouwd (zonder To: en Subject: in de header en met Bcc),
	 * dus na het instellen wordt de mail opnieuw opgebouwd voor SMTP.
	 *
	 * @param WW_PHPMailer $mail De mailer, na preSend().
	 * @return true|WP_Error
	 */
	public function send( WW_PHPMailer $mail ): true|WP_Error {
		try {
			$this->configure( $mail );
			if ( ! $mail->preSend() ) {
				return new WP_Error( 'ww_mail_smtp', $mail->ErrorInfo );
			}
			if ( ! $mail->postSend() ) {
				return new WP_Error( 'ww_mail_smtp', $mail->ErrorInfo );
			}
		} catch ( PHPMailer\PHPMailer\Exception $e ) {
			$message = '' !== $mail->ErrorInfo ? $mail->ErrorInfo : $e->getMessage();
			return new WP_Error( 'ww_mail_smtp', $message );
		}
		return true;
	}
}
