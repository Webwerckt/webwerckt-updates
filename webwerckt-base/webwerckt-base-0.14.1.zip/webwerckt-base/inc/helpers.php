<?php
/**
 * Helpers voor child-thema's. Alle uitvoer is hier al ge-escaped.
 *
 * Een helper geeft altijd de afgesproken lege waarde terug, nooit een fatal error:
 * '' voor tekst, 0 voor een foto, array() voor een relatie.
 *
 * @package webwerckt-base
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tekstveld als veilige HTML-string (wp_kses_post). Voor gebruik tussen tags.
 *
 * @param string $name    Veldnaam.
 * @param int    $post_id Bericht-ID; 0 is het huidige bericht.
 */
function ww_field( string $name, int $post_id = 0 ): string {
	return wp_kses_post( _ww_data_to_string( _ww_data_get( $name, $post_id ) ) );
}

/**
 * Meerregelig tekstveld of WYSIWYG-veld als HTML, voor gebruik tussen blokelementen. Doet wat WordPress met
 * de inhoud van een bericht doet, in dezelfde volgorde:
 *
 * - een video-link op een eigen regel wordt een embed (YouTube, Vimeo);
 * - alinea's (Pods bewaart WYSIWYG-tekst zonder <p>-tags en voegt die pas toe bij de eigen weergave);
 * - shortcodes, bijvoorbeeld een formulier;
 * - foto's uit de mediabibliotheek krijgen srcset, sizes, breedte, hoogte en loading="lazy".
 *
 * Shortcodes en embeds draaien na wp_kses_post(), anders zou die hun iframes en formulieren weghalen.
 *
 * @param string $name    Veldnaam.
 * @param int    $post_id Bericht-ID; 0 is het huidige bericht.
 */
function ww_text( string $name, int $post_id = 0 ): string {
	global $wp_embed;

	$html = ww_field( $name, $post_id );
	if ( '' === $html ) {
		return '';
	}
	if ( $wp_embed instanceof WP_Embed ) {
		$html = $wp_embed->autoembed( $wp_embed->run_shortcode( $html ) );
	}
	$html = do_shortcode( shortcode_unautop( wpautop( $html ) ) );
	return wp_filter_content_tags( $html, 'ww_text' );
}

/**
 * Tekstveld als ge-escapete URL, voor href en src.
 */
function ww_url( string $name, int $post_id = 0 ): string {
	return esc_url( _ww_data_to_string( _ww_data_get( $name, $post_id ) ) );
}

/**
 * Tekstveld ge-escaped voor gebruik in een attribuut.
 */
function ww_attr( string $name, int $post_id = 0 ): string {
	return esc_attr( _ww_data_to_string( _ww_data_get( $name, $post_id ) ) );
}

/**
 * Foto-veld als attachment-ID (0 als er geen foto is).
 */
function ww_image_id( string $name, int $post_id = 0 ): int {
	return _ww_data_to_attachment_id( _ww_data_get( $name, $post_id ) );
}

/**
 * Foto-veld als <img> met srcset, sizes, breedte en hoogte.
 *
 * In Visueel bewerken is de foto van de bewerkte pagina aan te klikken, en staat er een leeg vlak als er nog
 * geen foto is (inc/editor.php).
 *
 * @param string               $name    Veldnaam.
 * @param string               $size    Geregistreerd afbeeldingsformaat.
 * @param array<string,string> $attr    Extra attributen, bijvoorbeeld class en alt.
 * @param int                  $post_id Bericht-ID; 0 is het huidige bericht.
 * @param bool                 $hero    Hero-afbeelding: eager laden met hoge prioriteit.
 */
function ww_image( string $name, string $size = 'large', array $attr = array(), int $post_id = 0, bool $hero = false ): string {
	$attachment_id = ww_image_id( $name, $post_id );
	if ( _ww_editor_marks( $post_id ) ) {
		$attr = array( 'data-ww-edit' => sanitize_key( $name ) ) + $attr;
		if ( $attachment_id <= 0 ) {
			return _ww_editor_image_placeholder( $size, $attr );
		}
	}
	return ww_image_by_id( $attachment_id, $size, $attr, $hero );
}

/**
 * Zelfde als ww_image(), maar voor een attachment-ID (bijvoorbeeld de uitgelichte afbeelding).
 *
 * @param array<string,string> $attr
 */
function ww_image_by_id( int $attachment_id, string $size = 'large', array $attr = array(), bool $hero = false ): string {
	if ( $attachment_id <= 0 ) {
		return '';
	}
	if ( $hero ) {
		$attr += array(
			'loading'       => 'eager',
			'fetchpriority' => 'high',
		);
	}
	return wp_get_attachment_image( $attachment_id, $size, false, $attr );
}

/**
 * Relatieveld als array met post-ID's, alleen van items die bezoekers mogen zien.
 *
 * @return int[]
 */
function ww_related( string $name, int $post_id = 0 ): array {
	$ids = _ww_data_to_ids( _ww_data_get( $name, $post_id ) );
	// Alle items, velden en termen in een paar query's, in plaats van een query per item.
	_prime_post_caches( $ids );
	$ids = array_values( array_filter( $ids, '_ww_data_is_published' ) );
	_ww_prime_thumbnails( $ids );

	// De pagina toont deze items, ook als het child-thema hun velden direct leest in plaats van via ww_card():
	// wijzigt een item, dan moet de pagina uit de cache.
	foreach ( array_unique( array_map( 'get_post_type', $ids ) ) as $post_type ) {
		_ww_cache_tag( (string) $post_type );
	}
	// In Visueel bewerken weet de editor zo bij welk veld de kaarten horen (ADR 0019).
	_ww_editor_add_list( 'relation', sanitize_key( $name ), $ids, $post_id );
	return $ids;
}

/**
 * Site-instelling als veilige HTML-string.
 */
function ww_setting( string $name ): string {
	return wp_kses_post( _ww_data_to_string( _ww_data_get_setting( $name ) ) );
}

/**
 * Site-instelling als ge-escapete URL.
 */
function ww_setting_url( string $name ): string {
	return esc_url( _ww_data_to_string( _ww_data_get_setting( $name ) ) );
}

/**
 * Site-instelling als attachment-ID.
 */
function ww_setting_image_id( string $name ): int {
	return _ww_data_to_attachment_id( _ww_data_get_setting( $name ) );
}
